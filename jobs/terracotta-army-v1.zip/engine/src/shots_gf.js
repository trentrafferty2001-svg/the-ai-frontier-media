// Greek fire reel: timeline, captions and shots (props inline).
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { splash2 } from './farm2.js';
import { mountains } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll, romanBuilder } from './rome.js';
import { sea, longship, rideWaves, waveH } from './norse.js';
import { greek } from './classic.js';
import { cityWall } from './rice.js';
import { VO } from './vo_gf.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(9) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This *fire*', 2], ["couldn't be", 2], ['put out', 2], ['with *water*', 2]],
  [['The *Byzantines*', 2], ['called it', 2], ['*sea fire*', 2], ['We call it', 3], ['*Greek fire*', 2]],
  [['Around', 1], ['*672 AD*', 5], ['an engineer', 2], ['named *Kallinikos*', 2], ['*reportedly*', 1], ['brought it to', 3], ['*Constantinople*', 1]],
  [['Just in time', 3], ['because an', 2], ['*Arab fleet*', 2], ['was about to', 3], ['*besiege*', 1], ['the city', 2]],
  [['Byzantine *warships*', 2], ['*pumped*', 1], ['the burning liquid', 3], ['through', 1], ['*bronze tubes*', 2], ['like a', 2], ['*flamethrower*', 1]],
  [['It *clung*', 2], ['to ships', 2], ['and kept *burning*', 3], ['even', 1], ['*on the sea*', 3]],
  [['The enemy fleet', 3], ['was *wrecked*', 2], ['and the city', 3], ['*survived*', 1]],
  [['The *recipe*', 2], ['was a', 2], ['*state secret*', 2], ['known to', 2], ['only a *few*', 3]],
  [['Historians think', 2], ['it was based on', 4], ['*crude oil*', 2], ['but *nobody knows*', 3], ['for sure', 2]],
  [['Within a few', 3], ['*centuries*', 1], ['the *secret*', 2], ['was *lost forever*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
function skyTint(scene, top, mid, hor, floor) { const u = scene.userData.sky.material.uniforms; u.top.value.set(top); u.mid.value.set(mid); u.horizon.value.set(hor); u.floorC.value.set(floor); }

// ---------- props ----------
const bronze = () => new THREE.MeshStandardMaterial({ color: 0xb08040, metalness: 0.85, roughness: 0.35 });
// fire on the water: a patch of flame sprites, smoke and a light; set(k) scales it
function firePatch(scene, { r = 1.5, n = 22, seed = 1 } = {}) {
  const R = R0(seed), g = new THREE.Group(); scene.add(g);
  const fl = [...Array(n)].map((_, i) => { const s = glowSprite(i % 3 ? 0xff7a20 : 0xffc040, 1); g.add(s); return { s, x: (R() - 0.5) * 2 * r, z: (R() - 0.5) * 2 * r, ph: R(), sp: 0.8 + R() * 0.6 }; });
  const sm = [...Array(10)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite().material.map, color: 0x2a2420, transparent: true, opacity: 0, depthWrite: false })); g.add(s); return { s, x: (R() - 0.5) * r, z: (R() - 0.5) * r, ph: R() }; });
  const L = new THREE.PointLight(0xff7a2a, 0, 8 + r * 4, 2); L.position.y = 1; g.add(L);
  g.set = (t, k) => {
    fl.forEach((o, i) => { const a = (t * o.sp + o.ph) % 1; o.s.visible = k > 0.02; o.s.position.set(o.x * (0.6 + 0.4 * k), 0.1 + a * 1.4 * k, o.z * (0.6 + 0.4 * k)); o.s.scale.setScalar((0.7 + 0.6 * Math.sin(Math.PI * a)) * k * (r / 1.5)); o.s.material.opacity = 0.6 * Math.sin(Math.PI * a); });
    sm.forEach((o, i) => { const a = (t * 0.25 + o.ph) % 1; o.s.visible = k > 0.02; o.s.position.set(o.x + a * 1.5, 1.2 + a * 5 * k, o.z); o.s.scale.setScalar((0.8 + a * 3) * k); o.s.material.opacity = 0.45 * Math.sin(Math.PI * a) * k; });
    L.intensity = 3 * Math.min(k, 1.1) * (0.85 + 0.15 * Math.sin(t * 13));
  };
  return g;
}
// a Mediterranean galley: the shared hull with the Viking details removed, a lateen sail and oars
function galley({ L = 16, sail = 0xe8dcc0 } = {}) {
  const s = longship({ L, W: L * 0.22, D: 1.3 });
  s.traverse(o => { if (!o.isMesh) return; const p = o.geometry.parameters || {}; const ty = o.geometry.type;
    if (ty === 'CylinderGeometry' && Math.abs(p.radiusTop - 0.32) < 1e-6 && Math.abs(p.height - 0.04) < 1e-6) o.visible = false; // shields
    if (ty === 'ConeGeometry' && Math.abs(p.radius - 0.2) < 1e-6) o.visible = false; // dragon head
    if (ty === 'SphereGeometry' && Math.abs(p.radius - 0.045) < 1e-6) o.visible = false; // dragon eyes
    if (ty === 'TorusGeometry') o.visible = false; // stern curl
    if (ty === 'PlaneGeometry' && Math.abs(p.width - 6.2) < 1e-6) o.visible = false; // square sail
    if (ty === 'CylinderGeometry' && Math.abs(p.height - 6.4) < 1e-6) o.visible = false; // yard
  });
  const wood = new THREE.MeshStandardMaterial({ color: 0x5a3a20, roughness: 0.8 });
  const yardC = new THREE.LineCurve3(V(-L * 0.28, 2.6, 0.25), V(L * 0.22, 9.0, 0.25));
  s.add(new THREE.Mesh(new THREE.TubeGeometry(yardC, 4, 0.07, 6), wood));
  const sh = new THREE.Shape(); sh.moveTo(-L * 0.28, 2.6); sh.lineTo(L * 0.22, 9.0); sh.quadraticCurveTo(L * 0.12, 4.0, 0.4, 1.7); sh.lineTo(-L * 0.28, 2.6);
  const sl = new THREE.Mesh(new THREE.ShapeGeometry(sh, 16), new THREE.MeshStandardMaterial({ color: sail, roughness: 0.9, side: THREE.DoubleSide, bumpMap: fabricTexture(13), bumpScale: 2 })); sl.position.z = 0.3; s.add(sl);
  for (const z of [-1, 1]) for (let i = 0; i < 9; i++) { const x = -L * 0.32 + i * L * 0.075; const o = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 4.2, 6), wood); o.position.set(x, 0.6, z * (L * 0.11 + 1.2)); o.rotation.x = z * 1.15; s.add(o); }
  return s;
}
// a Byzantine dromon: galley with a red sail and a bronze siphon at the bow
function dromon({ sail = 0x8a2430 } = {}) {
  const s = galley({ L: 18, sail });
  const B = bronze();
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 1.6, 16), B); tube.rotation.z = -Math.PI / 2 + 0.25; tube.position.set(8.6, 2.0, 0); s.add(tube);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), B); head.position.set(9.4, 2.2, 0); s.add(head);
  for (const z of [-0.08, 0.08]) { const ear = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.18, 8), B); ear.position.set(9.3, 2.45, z * 2); s.add(ear); }
  const pump = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.8, 16), B); pump.position.set(7.4, 1.9, 0); s.add(pump);
  s.nozzle = V(9.65, 2.25, 0);
  return shadowAll(s);
}
// a jet of fire from a nozzle along +x (local to `parent` frame given as world points)
function fireJet(scene, n = 40) {
  const sp = [...Array(n)].map((_, i) => { const s = glowSprite(i % 3 ? 0xff8a2a : 0xffd060, 1); scene.add(s); return { s, i }; });
  return (t, from, dir, on, len = 12) => sp.forEach(({ s, i }) => { const a = ((t * 2.2 + i / n) % 1); s.visible = on > 0.02; if (!s.visible) return; const p = from.clone().addScaledVector(dir, a * len * on); p.y -= a * a * 2.5; s.position.copy(p); s.scale.setScalar((0.25 + a * 1.4) * on); s.material.opacity = 0.55 * (1 - a * 0.7); });
}
function nightSea(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.2, 0.05, -0.98], fog: 0.006, shadowSize: 20, envI: 0.45, cloud: 0.55, hemi: 0.2, ...opts });
  sea(scene, { color: 0x1a2a38 });
  fillLight(scene, [-0.4, 0.3, 1], 0.35, 0x8aa0c8);
  return scene;
}
function city(scene, { x = 0, z = -80 } = {}) {
  const w = cityWall({ len: 120, h: 14, d: 8, gate: false }); w.position.set(x, -1, z); scene.add(w);
  const A = archMats();
  [[-20, 12, 9], [8, 16, 11], [30, 10, 7], [-42, 9, 6]].forEach(([dx, h, r]) => { const b = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 24), A.stone); b.position.set(x + dx, h / 2 + 2, z - 22); scene.add(b); const d = new THREE.Mesh(new THREE.SphereGeometry(r, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x8a9aa0, roughness: 0.5, metalness: 0.3 })); d.position.set(x + dx, h + 2, z - 22); scene.add(d); });
  const ham = mountains({ rMin: 160, rMax: 320, height: 26, seed: 9, color: 0x3a4a3a, thetaFrom: Math.PI * 0.75, thetaTo: Math.PI * 1.25 }); scene.add(ham);
}

// ============ S0 hook: water thrown on a burning patch makes it flare ============
function sHook({ makeStage, start: ST }) {
  const tW = at(0, 'water') - ST;
  const scene = nightSea(makeStage);
  const f = firePatch(scene, { r: 1.1, n: 14, seed: 2 });
  const hull = galley(); hull.position.set(-16, 0, -14); hull.rotation.y = 0.4; scene.add(hull);
  const water = [...Array(30)].map((_, i) => { const s = glowSprite(0xbfd8f0, 0.25); s.material.blending = THREE.NormalBlending; scene.add(s); return { s, i }; });
  const spl = splash2(1.8, 5); scene.add(spl);
  const c = cam(40);
  const tThrow = tW - 0.7;
  return {
    scene, camera: c,
    update(t) {
      const flare = 0.8 + 0.45 * easeOut(range(t, tThrow + 0.55, tThrow + 1.0));
      f.set(t, flare);
      water.forEach(({ s, i }) => { const a = range(t, tThrow + i * 0.01, tThrow + 0.55 + i * 0.01); s.visible = a > 0 && a < 1; s.position.set(lerp(6, 0.2, a) + Math.sin(i) * 0.2, 2.5 + Math.sin(Math.PI * a) * 1.8 - a * 2.4, lerp(3, 0.2, a) + Math.cos(i) * 0.2); s.material.opacity = 0.7; });
      spl.visible = t > tThrow + 0.5 && t < tThrow + 1.6; spl.position.set(0, 0.05, 0); spl.update(t - tThrow - 0.5);
      const k = easeInOut(range(t, 0, 2.6));
      const sh = t > tThrow + 0.55 && t < tThrow + 0.9 ? shake(t * 4, 2, 3) : [0, 0, 0];
      place(c, [lerp(5.5, 4.6, k) + sh[0] * 0.05, lerp(2.4, 2.0, k) + sh[1] * 0.05, lerp(10, 8.2, k)], [0, 1.0, 0]);
      return { bloom: 0.3, warm: 1.1, flare: 0, exposure: 0.9 };
    },
  };
}
// ============ S1: a dromon at dusk, siphon on the bow ============
function sDromon({ makeStage }) {
  const scene = nightSea(makeStage, { sunDir: [0.7, 0.08, -0.7] });
  const s = dromon(); scene.add(s);
  const crew = [0, 1, 2].map(i => { const m = romanBuilder({ color: [0x7a2430, 0x2a3a6a, 0x6a5a40][i] }); m.root.position.set(2 - i * 3, 1.2, (i % 2) * 0.8 - 0.4); m.root.rotation.y = Math.PI / 2; s.add(m.root); return m; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      rideWaves(s, 0, 0, 0, t);
      crew.forEach((m, i) => { standPose(m, t + i, {}); m.setMood('happy'); });
      const k = easeInOut(range(t, 0, 3.8));
      place(c, [lerp(18, 14, k), lerp(4, 3.2, k), lerp(9, 11, k)], [lerp(6, 3, k), 2.4, 0]);
      return { bloom: 0.6, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2: Kallinikos arrives at Constantinople's sea walls with a sealed jar ============
function amphora() {
  const prof = [[0, 0], [0.04, 0.02], [0.14, 0.15], [0.16, 0.3], [0.12, 0.45], [0.05, 0.52], [0.05, 0.6], [0, 0.6]].map(([a, b]) => new THREE.Vector2(a, b));
  const m = new THREE.Mesh(new THREE.LatheGeometry(prof, 24), new THREE.MeshStandardMaterial({ color: 0xa8603a, roughness: 0.8, bumpMap: fabricTexture(19), bumpScale: 2 }));
  const seal = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.04, 16), new THREE.MeshStandardMaterial({ color: 0x8a1a1a, roughness: 0.6 })); seal.position.y = 0.61; const g = new THREE.Group(); g.add(m, seal);
  return shadowAll(g);
}
function sKallinikos({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.3, 0.74], fog: 0.004, shadowSize: 4, envI: 0.95, cloud: 0.3 });
  sea(scene, { color: 0x2a4a5a });
  const A = archMats();
  const quay = new THREE.Mesh(new THREE.BoxGeometry(60, 1.5, 12), A.stone); quay.position.set(0, 0.3, -6); quay.receiveShadow = true; scene.add(quay);
  city(scene, { z: -26 });
  const man = greek({ color: 0x5a4a6a }); man.root.position.set(0, 1.05, -1); scene.add(man.root);
  const guard = romanBuilder({ color: 0x7a2430 }); guard.root.position.set(1.5, 1.05, -3); guard.root.rotation.y = -2.4; scene.add(guard.root);
  const jar = amphora(); scene.add(jar);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const walk = Math.min(1, t / 3.5); const s = Math.sin(t * 5);
      man.root.position.z = lerp(-3.2, -0.6, walk); man.root.rotation.y = 0;
      standPose(man, t, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07] }); man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [1.2])); man.grip(0.9, 0.9);
      man.root.updateMatrixWorld(true);
      const jp = wpos(man.root, V(0, 0.75, 0.3)); jar.position.copy(jp).add(V(0, -0.3, 0));
      ikArm(man, 'l', jp.clone().add(V(0.13, 0, 0)), wpos(man.root, V(0.7, 0.2, 0)), V(0, 1, 0));
      ikArm(man, 'r', jp.clone().add(V(-0.13, 0, 0)), wpos(man.root, V(-0.7, 0.2, 0)), V(0, 1, 0));
      standPose(guard, t, { head: [0, 0.3, 0] }); guard.setMood('happy');
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(1.0, 0.7, k), lerp(1.7, 1.9, k), lerp(3.2, 3.6, k)], [lerp(0, 0, k), lerp(1.9, 2.6, k), lerp(-3, -8, k)]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S3: the Arab fleet sails toward the walls at dusk ============
function sFleet({ makeStage }) {
  const scene = nightSea(makeStage, { sunDir: [-0.7, 0.07, -0.7] });
  city(scene, { z: -120 });
  const ships = [...Array(9)].map((_, i) => { const s = galley({ L: 14 }); scene.add(s); return { s, x: -24 + (i % 5) * 12 + (i > 4 ? 6 : 0), z: 10 + Math.floor(i / 5) * 14 }; });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      ships.forEach(({ s, x, z }, i) => rideWaves(s, x, z - t * 2, Math.PI / 2, t + i));
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(-6, -2, k), lerp(5, 7, k), lerp(52, 46, k)], [0, 2, lerp(-20, -40, k)]);
      return { bloom: 0.6, flare: 0.9, warm: 1.2 };
    },
  };
}
// ============ S4: crew works the pump; a jet of fire from the bronze lion head ============
function sJet({ makeStage, start: ST }) {
  const tP = at(4, 'pumped') - ST;
  const scene = nightSea(makeStage);
  const s = dromon(); scene.add(s);
  const pumper = romanBuilder({ color: 0x7a2430 }); pumper.root.position.set(7.0, 1.2, 0.7); pumper.root.rotation.y = Math.PI; s.add(pumper.root);
  const aimer = romanBuilder({ color: 0x2a3a6a }); aimer.root.position.set(8.2, 1.2, -0.6); aimer.root.rotation.y = Math.PI / 2; s.add(aimer.root);
  const lever = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.4, 8), archMats().wood); s.add(lever);
  const jet = fireJet(scene, 46);
  const target = galley({ L: 14 }); scene.add(target);
  const tf = firePatch(scene, { r: 2.5, n: 30, seed: 4 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      rideWaves(s, 0, 0, 0, t); rideWaves(target, 26, 2, 0.4, t + 2);
      s.updateMatrixWorld(true);
      const pumpA = Math.sin(t * 6) * 0.5 * (t > tP - 0.4 ? 1 : 0.2);
      lever.position.set(7.4, 2.4, 0); lever.rotation.set(pumpA, 0, 0);
      standPose(pumper, t, { spine: [0.3, 0, 0] }); pumper.setMood('happy'); pumper.grip(0.95, 0.95);
      pumper.root.updateMatrixWorld(true); lever.updateMatrixWorld(true);
      const lt = wpos(lever, V(0, 0.65, 0)); ikArm(pumper, 'l', lt.clone().add(V(0.05, 0, 0)), wpos(pumper.root, V(0.7, 0.2, 0)), V(0, 1, 0)); ikArm(pumper, 'r', lt.clone().add(V(-0.05, -0.08, 0)), wpos(pumper.root, V(-0.7, 0.2, 0)), V(0, 1, 0));
      standPose(aimer, t, { spine: [0.2, 0, 0], head: [0.1, 0, 0] }); aimer.setMood('happy'); aimer.grip(0.9, 0.9);
      const on = easeOut(range(t, tP - 0.1, tP + 0.4));
      const from = s.localToWorld(s.nozzle.clone()); const dir = s.localToWorld(V(10.6, 2.35, 0.05)).sub(from).normalize();
      jet(t, from, dir, on, 16);
      tf.position.set(23, 0.3, 4); tf.set(t, easeOut(range(t, tP + 0.6, tP + 1.6)) * 1.3);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-7, -5, k), lerp(6.5, 5.5, k), lerp(5.5, 4.5, k)], [lerp(12, 16, k), lerp(1.8, 1.4, k), lerp(0.5, 1.5, k)]);
      return { bloom: 0.45, warm: 1.2, flare: 0 };
    },
  };
}
// ============ S5: fire clings to an enemy ship and spreads across the water ============
function sCling({ makeStage, start: ST }) {
  const tS = at(5, 'sea') - ST;
  const scene = nightSea(makeStage);
  const s = galley({ L: 14 }); scene.add(s);
  const onShip = firePatch(scene, { r: 2.4, n: 30, seed: 6 });
  const onSea = [0, 1, 2, 3].map(i => firePatch(scene, { r: 1.8, n: 18, seed: 10 + i }));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      rideWaves(s, 0, 0, 0.3, t);
      s.updateMatrixWorld(true); onShip.position.copy(s.localToWorld(V(1, 1.2, 0))); onShip.set(t, 1.4);
      onSea.forEach((f, i) => { const a = i / 4 * 6.28 + 0.6; f.position.set(Math.cos(a) * (5 + i), waveH(Math.cos(a) * 5, Math.sin(a) * 5, t) + 0.05, Math.sin(a) * (5 + i)); f.set(t, easeOut(range(t, tS - 1.6 + i * 0.25, tS + i * 0.25))); });
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(12, 10, k), lerp(4, 5.5, k), lerp(12, 15, k)], [0, 1, 0]);
      return { bloom: 0.5, warm: 1.2, flare: 0 };
    },
  };
}
// ============ S6: wide: the burning fleet below the safe city walls ============
function sWrecked({ makeStage, start: ST }) {
  const scene = nightSea(makeStage, { sunDir: [0.7, 0.04, -0.7] });
  city(scene, { z: -70 });
  const fires = [...Array(7)].map((_, i) => { const s = galley({ L: 14 }); scene.add(s); const f = firePatch(scene, { r: 2.6, n: 20, seed: 30 + i }); return { s, f, x: -36 + i * 12, z: -20 + (i % 3) * 9 }; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      fires.forEach(({ s, f, x, z }, i) => { rideWaves(s, x, z, 0.5 + i, t + i); s.position.y -= 0.3 * range(t, 0, 3); f.position.set(x, 0.6, z); f.set(t, 1.3); });
      const k = easeInOut(range(t, 0, 3.2));
      place(c, [lerp(0, 6, k), lerp(14, 22, k), lerp(46, 52, k)], [0, lerp(4, 6, k), -40]);
      return { bloom: 0.8, flare: 0.8, warm: 1.25 };
    },
  };
}
// ============ S7: the secret: a candlelit room, a sealed jar, a locked chest ============
function sSecret({ makeStage }) {
  const scene = makeStage({ shadowSize: 1.4, sunDir: [-1, 2, 1], sun: 0.2, hemi: 0.1 });
  skyTint(scene, 0x0c0806, 0x140e0a, 0x1a120c, 0x0c0806);
  const A = archMats();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), A.stone); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(10, 5), A.stone); wall.position.set(0, 2.5, -1.4); wall.receiveShadow = true; scene.add(wall);
  const table = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.06, 0.8), A.wood); table.position.set(0, 0.85, -0.3); scene.add(shadowAll(table));
  for (const [x, z] of [[-0.6, -0.6], [0.6, -0.6], [-0.6, 0], [0.6, 0]]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.85, 0.06), A.wood); l.position.set(x, 0.42, z); scene.add(shadowAll(l)); }
  const jar = amphora(); jar.position.set(-0.25, 0.88, -0.35); scene.add(jar);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 0.32), A.wood); chest.position.set(0.35, 1.03, -0.4); scene.add(shadowAll(chest));
  const lock = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.1, 0.03), bronze()); lock.position.set(0.35, 1.02, -0.23); scene.add(lock);
  const cnd = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.12, 12), new THREE.MeshStandardMaterial({ color: 0xf0e8d0 })); cnd.position.set(0.05, 0.94, -0.05); scene.add(cnd);
  const flame = glowSprite(0xffc070, 0.06); flame.position.set(0.05, 1.02, -0.05); scene.add(flame);
  const cl = new THREE.PointLight(0xffa860, 2.2, 4, 2); cl.position.set(0.05, 1.05, -0.05); scene.add(cl);
  const men = [0, 1].map(i => { const m = greek({ color: i ? 0x3a2a4a : 0x2a2a3a }); m.root.position.set(i ? 0.75 : -0.75, 0, 0.35); m.root.rotation.y = i ? -2.4 : 2.4; scene.add(m.root); return m; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      flame.scale.setScalar(0.05 + 0.01 * Math.sin(t * 17)); cl.intensity = 2 + 0.3 * Math.sin(t * 13);
      men.forEach((m, i) => { standPose(m, t + i, { spine: [0.15, 0, 0], head: [0.2, i ? 0.4 : -0.4, 0] }); m.setMood('happy'); m.setMouth(i === 0 ? 0.3 * Math.max(0, Math.sin(t * 9)) : 0); m.blink(blinkK(t, [0.9 + i])); });
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(0.3, 0.15, k), lerp(1.5, 1.35, k), lerp(2.2, 1.6, k)], [0, lerp(1.1, 1.05, k), -0.3]);
      return { bloom: 0.8, warm: 1.4, exposure: 1.1 };
    },
  };
}
// ============ S8: crude oil seeping up from the ground, black and glossy ============
function sOil({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.7, 0.25, 0.67], fog: 0.004, shadowSize: 3, envI: 1.0, cloud: 0.3 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(300, 48), new THREE.MeshStandardMaterial({ color: 0xa88a5a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 120, rMax: 300, height: 30, seed: 4, color: 0x9a8058 }));
  const oil = new THREE.Mesh(new THREE.CircleGeometry(1, 48), new THREE.MeshPhysicalMaterial({ color: 0x080606, roughness: 0.05, clearcoat: 1, clearcoatRoughness: 0.02, metalness: 0.2 })); oil.rotation.x = -Math.PI / 2; oil.position.y = 0.01; scene.add(oil);
  const bub = [...Array(8)].map((_, i) => { const b = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), oil.material); scene.add(b); return { b, i }; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const r = 0.8 + 0.25 * easeOut(range(t, 0, 3.5)); oil.scale.set(r, r * 0.8, 1);
      bub.forEach(({ b, i }) => { const a = (t * 0.7 + i / 8) % 1; b.position.set(Math.sin(i * 2.3) * 0.4, 0.01, Math.cos(i * 1.7) * 0.3); b.scale.setScalar(Math.sin(Math.PI * a) + 1e-3); });
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(1.6, 1.0, k), lerp(1.2, 0.8, k), lerp(2.2, 1.6, k)], [0, 0, 0]);
      return { bloom: 0.5, flare: 0.8, warm: 1.25, dof: dofTo([1, 0.8, 1.6], [0, 0, 0], 0.004, 0.008) };
    },
  };
}
// ============ S9: a corroded bronze siphon head half-buried on a beach as the tide washes over ============
function sLost({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.6, 0.12, -0.79], fog: 0.004, shadowSize: 3, envI: 1.0, cloud: 0.35 });
  sea(scene, { color: 0x2a4a5a, scale: 0.4 });
  const beach = new THREE.Mesh(new THREE.BoxGeometry(200, 2, 60), new THREE.MeshStandardMaterial({ color: 0xd8c098, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); beach.position.set(0, -0.7, 32); beach.receiveShadow = true; scene.add(beach);
  const B = new THREE.MeshStandardMaterial({ color: 0x4a7a6a, metalness: 0.5, roughness: 0.7, bumpMap: fabricTexture(19), bumpScale: 4 });
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, 1.6, 16), B); tube.rotation.set(0, 0.6, Math.PI / 2 - 0.1); tube.position.set(0, 0.55, 4); scene.add(shadowAll(tube));
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), B); head.position.set(0.7, 0.62, 3.5); scene.add(shadowAll(head));
  const foam = splash2(1.6, 9); scene.add(foam);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      foam.position.set(0.2, 0.4, 2.4); foam.update((t % 1.8));
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(1.6, 3.2, k), lerp(1.1, 2.4, k), lerp(6.0, 8.6, k)], [lerp(0.3, 0.3, k), lerp(0.55, 0.6, k), lerp(3.8, 3.4, k)]);
      return { bloom: 0.7, flare: 1.2, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sDromon, 'dromon'],
  [ls(2), ls(3), sKallinikos, 'kallinikos'],
  [ls(3), ls(4), sFleet, 'fleet'],
  [ls(4), ls(5), sJet, 'jet'],
  [ls(5), ls(6), sCling, 'cling'],
  [ls(6), ls(7), sWrecked, 'wrecked'],
  [ls(7), ls(8), sSecret, 'secret'],
  [ls(8), ls(9), sOil, 'oil'],
  [ls(9), DURATION + 1, sLost, 'lost'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
