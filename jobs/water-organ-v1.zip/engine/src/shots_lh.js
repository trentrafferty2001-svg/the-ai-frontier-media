// Lighthouse of Alexandria reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { splash2 } from './farm2.js';
import { mountains, birds } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { shadowAll, romanBuilder, canvasTex } from './rome.js';
import { sea } from './norse.js';
import { galley } from './ancientkit.js';
import { VO } from './vo_lh.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Over *2,000 years* ago', 5], ['this *lighthouse*', 2], ['stood more than', 3], ['*a hundred meters* tall', 4]],
  [["It's the *Lighthouse*", 3], ['*of Alexandria*', 2], ['in *Egypt*', 2], ['one of the', 3], ['*Seven Wonders*', 2], ['of the ancient world', 4]],
  [['It was built', 3], ['about *2,300 years* ago', 7], ['on the island', 3], ['of *Pharos*', 2]],
  [['It had *three tiers*', 4], ['a *square* base', 3], ['an *eight-sided* middle', 4], ['and a *round* top', 4]],
  [['At night', 2], ['a *fire* burned', 3], ['at the top', 3], ['to *guide ships*', 3], ['into the harbor', 3]],
  [['By day', 2], ['ancient writers say', 3], ['a *mirror*', 2], ['reflected the *sun*', 3]],
  [['For centuries', 2], ['it was one of', 4], ['the *tallest buildings*', 3], ['*on Earth*', 2]],
  [['Then *earthquakes*', 2], ['*cracked* it', 2], ['and by the', 3], ['*14th century*', 2], ['it was a *ruin*', 4]],
  [['Its *stones*', 2], ['were later used', 3], ['to build a *fortress*', 4], ['that *still stands*', 3], ['on the same spot', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const far = (c, f = 2500) => { c.far = f; c.updateProjectionMatrix(); return c; };

// ---------- materials ----------
let BL_ = null;
function blocks(rx = 1, ry = 1) {
  if (!BL_) { BL_ = canvasTex(256, 256, (x) => { const R = R0(3); x.fillStyle = '#a89a80'; x.fillRect(0, 0, 256, 256); for (let r = 0; r < 8; r++) for (let c = -1; c < 4; c++) { const off = (r % 2) * 40; const g = R(); x.fillStyle = `rgb(${226 + g * 18 | 0},${216 + g * 16 | 0},${196 + g * 14 | 0})`; x.fillRect(c * 80 + off + 2, r * 32 + 2, 76, 28); } }); BL_.wrapS = BL_.wrapT = THREE.RepeatWrapping; }
  const t = BL_.clone(); t.needsUpdate = true; t.repeat.set(rx, ry); return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 2, roughness: 0.85 });
}
const darkM = () => new THREE.MeshStandardMaterial({ color: 0x2a2018, roughness: 1 });
// ---------- the lighthouse: square tier (0..56), octagonal (56..84), round (84..98), lantern + statue (to ~106) ----------
function lighthouse() {
  const g = new THREE.Group(); const D = darkM();
  const sq = new THREE.Group(); g.add(sq);
  const s1 = new THREE.Mesh(new THREE.CylinderGeometry(27 / Math.SQRT2, 31 / Math.SQRT2, 56, 4, 1), blocks(8, 14)); s1.rotation.y = Math.PI / 4; s1.position.y = 28; sq.add(s1);
  const ledge1 = new THREE.Mesh(new THREE.BoxGeometry(30, 1.6, 30), blocks(6, 0.5)); ledge1.position.y = 56.8; sq.add(ledge1);
  for (let r = 0; r < 6; r++) for (let i = 0; i < 4; i++) for (const f of [0, 1, 2, 3]) { const w = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 2.2), D); const a = f * Math.PI / 2; const hw = lerp(15.4, 13.6, (8 + r * 8) / 56) + 0.05; w.position.set(Math.sin(a) * hw + Math.cos(a) * (-9 + i * 6), 8 + r * 8, Math.cos(a) * hw - Math.sin(a) * (-9 + i * 6)); w.rotation.y = a; sq.add(w); }
  const oc = new THREE.Group(); oc.position.y = 57.6; g.add(oc);
  const o1 = new THREE.Mesh(new THREE.CylinderGeometry(10, 11.5, 28, 8, 1), blocks(6, 7)); o1.rotation.y = Math.PI / 8; o1.position.y = 14; oc.add(o1);
  const ledge2 = new THREE.Mesh(new THREE.CylinderGeometry(11.2, 11.2, 1.2, 8), blocks(5, 0.4)); ledge2.rotation.y = Math.PI / 8; ledge2.position.y = 28.6; oc.add(ledge2);
  const rd = new THREE.Group(); rd.position.y = 86.6; g.add(rd);
  const r1 = new THREE.Mesh(new THREE.CylinderGeometry(5.5, 6.2, 12, 24, 1), blocks(4, 3)); r1.position.y = 6; rd.add(r1);
  for (let i = 0; i < 8; i++) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 5, 10), blocks(0.3, 1)); const a = i * Math.PI / 4; c.position.set(Math.cos(a) * 5, 14.5, Math.sin(a) * 5); rd.add(c); }
  const cap = new THREE.Mesh(new THREE.ConeGeometry(6.2, 3, 24), blocks(3, 1)); cap.position.y = 18.5; rd.add(cap);
  const st = new THREE.Group(); st.position.y = 20; rd.add(st);
  const statue = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 1.0, 5, 12), new THREE.MeshStandardMaterial({ color: 0xb8904a, metalness: 0.8, roughness: 0.35 })); statue.position.y = 2.5; st.add(statue); const head = new THREE.Mesh(new THREE.SphereGeometry(0.8, 14, 10), statue.material); head.position.y = 5.6; st.add(head);
  const fireAt = new THREE.Object3D(); fireAt.position.y = 13; rd.add(fireAt);
  g.sq = sq; g.oc = oc; g.rd = rd; g.fireAt = fireAt;
  return shadowAll(g);
}
// stylized flames (lathe tongues) + a warm light
function fire(parent, scale = 1) {
  const FG = new THREE.LatheGeometry([[0, -0.5], [0.2, -0.38], [0.28, -0.12], [0.22, 0.2], [0.1, 0.5], [0, 0.75]].map(([x, y]) => new THREE.Vector2(x, y)), 14);
  const om = new THREE.MeshBasicMaterial({ color: 0xff5a10, transparent: true, opacity: 0.95, depthWrite: false }), im = new THREE.MeshBasicMaterial({ color: 0xffd040, transparent: true, opacity: 0.95, depthWrite: false });
  const R = R0(4); const G = new THREE.Group(); G.scale.setScalar(scale); parent.add(G);
  const T = [...Array(14)].map(() => { const o = new THREE.Mesh(FG, om); const i = new THREE.Mesh(FG, im); i.scale.set(0.55, 0.6, 0.55); i.position.set(0, -0.15, 0.1); o.add(i); const a = R() * 6.28, r = Math.sqrt(R()) * 2.6; o.userData = { x: Math.cos(a) * r, z: Math.sin(a) * r, ph: R() * 6, h: 2 + R() * 2 * (1 - r / 3) }; G.add(o); return o; });
  const glow = glowSprite(0xffb050, 22); G.add(glow); glow.position.y = 2;
  const L = new THREE.PointLight(0xff9a40, 0, 200, 1.5); L.position.y = 2; G.add(L);
  G.set = (t, k = 1) => { G.visible = k > 0.01; T.forEach(o => { const u = o.userData; const fl = 0.75 + 0.25 * Math.sin(t * 11 + u.ph); const hh = u.h * fl * k; o.scale.set(2 * (0.8 + 0.2 * fl), hh, 2 * (0.8 + 0.2 * fl)); o.position.set(u.x, hh * 0.7, u.z); }); glow.material.opacity = 0.7 * k; L.intensity = 600 * k; };
  return G;
}
function harbor(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.4, 0.69], fog: 0.0015, shadowSize: 120, envI: 0.95, cloud: 0.35, ...opts });
  sea(scene, { color: 0x2a6a8a });
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe6c8);
  const isl = new THREE.Mesh(new THREE.CylinderGeometry(55, 62, 4, 40), new THREE.MeshStandardMaterial({ color: 0xc8b48a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); isl.position.y = 0.5; isl.receiveShadow = true; scene.add(isl);
  const plat = new THREE.Mesh(new THREE.BoxGeometry(46, 6, 46), blocks(10, 1.2)); plat.position.y = 3; scene.add(shadowAll(plat));
  // the mainland city across the water
  const city = new THREE.Group(); const R = R0(6); const wm = new THREE.MeshStandardMaterial({ color: 0xe8dcc4, roughness: 0.9 });
  const land = new THREE.Mesh(new THREE.BoxGeometry(1600, 3, 500), new THREE.MeshStandardMaterial({ color: 0xc8b48a, roughness: 1 })); land.position.set(0, 0.5, -520); scene.add(land);
  for (let i = 0; i < 160; i++) { const w = 8 + R() * 14, h = 6 + R() * 16; const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), wm); b.position.set((R() - 0.5) * 900, h / 2 + 2, -300 - R() * 200); city.add(b); }
  scene.add(shadowAll(city));
  const mole = new THREE.Mesh(new THREE.BoxGeometry(14, 3, 240), blocks(1, 20)); mole.position.set(-80, 1.5, -160); scene.add(shadowAll(mole));
  return scene;
}
function ships(scene, n = 5, seed = 2) { const R = R0(seed); return [...Array(n)].map((_, i) => { const s = galley({ L: 16, sail: [0xe8dcc0, 0xa8302a][i % 2] }); s.position.set(120 + R() * 200, 0, 60 + R() * 200); s.rotation.y = Math.PI * 0.8 + R() * 0.3; scene.add(shadowAll(s)); return s; }); }

// ============ S0 hook: low from the sea at dusk, tilt up the tower to the fire ============
function sHook({ makeStage }) {
  const scene = harbor(makeStage, { sunDir: [-0.8, 0.12, 0.6] });
  const lh = lighthouse(); scene.add(lh); const f = fire(lh.fireAt, 1.0);
  const fl = ships(scene, 4, 3); fl.forEach((s, i) => s.position.set(40 + i * 25, 0, 90 + i * 18));
  const c = far(cam(46));
  return {
    scene, camera: c,
    update(t) {
      f.set(t, 1);
      fl.forEach((s, i) => { s.position.x -= 0.05; s.position.y = Math.sin(t * 1.3 + i) * 0.15; });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(40, 70, k), lerp(4, 10, k), lerp(110, 150, k)], [0, lerp(48, 72, k), 0]);
      return { bloom: 0.6, flare: 1.3, warm: 1.35 };
    },
  };
}
// ============ S1: Alexandria's harbor, the lighthouse on its island ============
function sHarbor({ makeStage }) {
  const scene = harbor(makeStage);
  const lh = lighthouse(); scene.add(lh); const f = fire(lh.fireAt, 1.0);
  const fl = ships(scene, 6, 5);
  scene.add(birds(5, { from: [-60, 70, 40], to: [80, 80, -20], spread: 10, scale: 2 }));
  const c = far(cam(44));
  return {
    scene, camera: c,
    update(t) {
      f.set(t, 0.7); fl.forEach((s, i) => { s.position.x -= 0.08; s.position.y = Math.sin(t * 1.3 + i) * 0.15; });
      const k = easeInOut(range(t, 0, 5.4)); const a = lerp(0.2, 0.7, k);
      place(c, [Math.sin(a) * 260, lerp(90, 120, k), Math.cos(a) * 260], [0, 40, -60]);
      return { bloom: 0.5, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2: the tower rising on the island of Pharos ============
function sBuild({ makeStage }) {
  const scene = harbor(makeStage);
  const lh = lighthouse(); scene.add(lh);
  const scaff = new THREE.Group(); const W = new THREE.MeshStandardMaterial({ color: 0x7a5232, roughness: 0.9 });
  for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6; const p = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 60, 6), W); p.position.set(Math.cos(a) * 19, 30, Math.sin(a) * 19); scaff.add(p); } scene.add(scaff);
  const men = [...Array(8)].map((_, i) => { const m = romanBuilder({ color: [0xd8c7a2, 0x9a6a3a][i % 2] }); m.root.scale.setScalar(1.6); m.root.position.set(-20 + i * 5, 6, 26); scene.add(m.root); return m; });
  const c = far(cam(44));
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.4));
      lh.sq.scale.y = lerp(0.3, 1, k); lh.oc.visible = k > 0.7; lh.oc.scale.setScalar(Math.max(0.01, range(k, 0.7, 1))); lh.oc.position.y = 57.6 * lh.sq.scale.y; lh.rd.visible = false;
      scaff.scale.y = lerp(0.35, 1.2, k);
      men.forEach((m, i) => { const s = Math.sin(t * 5 + i); standPose(m, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07] }); m.setMood('happy'); m.root.position.x = -20 + i * 5 + Math.sin(t * 0.5 + i) * 2; });
      place(c, [lerp(70, 85, k), lerp(20, 50, k), lerp(90, 110, k)], [0, lerp(18, 45, k), 0]);
      return { bloom: 0.5, warm: 1.25 };
    },
  };
}
// ============ S3: the three tiers light up one by one ============
function sTiers({ makeStage, start: ST }) {
  const tS = at(3, 'square') - ST, tE = at(3, 'eight') - ST, tR = at(3, 'round') - ST;
  const scene = harbor(makeStage);
  const lh = lighthouse(); scene.add(lh);
  const hi = (grp, col) => { const mats = []; grp.traverse(o => { if (o.isMesh && o.material.map) { o.material = o.material.clone(); mats.push(o.material); } }); return (k) => mats.forEach(m => { m.emissive = new THREE.Color(col); m.emissiveIntensity = 1.3 * k; }); };
  const h1 = hi(lh.sq, 0xff9020), h2 = hi(lh.oc, 0xff9020), h3 = hi(lh.rd, 0xff9020);
  const c = far(cam(42));
  return {
    scene, camera: c,
    update(t) {
      h1(range(t, tS - 0.2, tS + 0.2) * (1 - range(t, tE - 0.2, tE + 0.3))); h2(range(t, tE - 0.2, tE + 0.2) * (1 - range(t, tR - 0.2, tR + 0.3))); h3(range(t, tR - 0.2, tR + 0.2));
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-120, -110, k), lerp(30, 70, k), lerp(150, 140, k)], [0, lerp(40, 70, k), 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S4: night: the fire blazes, ships steer in by its light ============
function sNight({ makeStage }) {
  const scene = harbor(makeStage, { sunDir: [0.6, 0.02, -0.8], cloud: 0.6, envI: 0.35 });
  const lh = lighthouse(); scene.add(lh); const f = fire(lh.fireAt, 1.2);
  const fl = ships(scene, 3, 9); fl.forEach((s, i) => { s.position.set(30 + i * 30, 0, 120 + i * 30); s.rotation.y = Math.PI * 1.1; });
  const c = far(cam(44));
  return {
    scene, camera: c,
    update(t) {
      f.set(t, 1.2); fl.forEach((s, i) => { s.position.x -= 0.12; s.position.z -= 0.2; s.position.y = Math.sin(t * 1.3 + i) * 0.15; });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(70, 50, k), lerp(14, 20, k), lerp(170, 150, k)], [lerp(20, 0, k), lerp(50, 80, k), 0]);
      return { bloom: 0.75, warm: 1.1, exposure: 0.7 };
    },
  };
}
// ============ S5: by day a bronze mirror flashes sunlight out to sea ============
function sMirror({ makeStage, start: ST }) {
  const tS = at(5, 'sun') - ST;
  const scene = harbor(makeStage, { sunDir: [-0.5, 0.6, 0.62] });
  const lh = lighthouse(); scene.add(lh);
  const mir = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.2, 0.3, 32), new THREE.MeshStandardMaterial({ color: 0xd8b060, metalness: 1, roughness: 0.15 })); mir.rotation.set(Math.PI / 2 - 0.3, 0.6, 0); mir.position.y = 2; lh.fireAt.add(mir);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 9, 260, 20, 1, true), new THREE.MeshBasicMaterial({ color: 0xfff0b0, transparent: true, opacity: 0.0, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending })); scene.add(beam);
  const flash = glowSprite(0xfff4c0, 30); scene.add(flash);
  const c = far(cam(42));
  return {
    scene, camera: c,
    update(t) {
      scene.updateMatrixWorld(true); const p = new THREE.Vector3(); mir.getWorldPosition(p);
      const dir = V(0.55, -0.12, 0.83).normalize(); beam.position.copy(p).addScaledVector(dir, 130); beam.quaternion.setFromUnitVectors(V(0, -1, 0), dir.clone().negate());
      const k = range(t, tS - 1.4, tS - 0.6); beam.material.opacity = 0.35 * k; flash.position.copy(p); flash.material.opacity = 0.9 * k * (0.8 + 0.2 * Math.sin(t * 7));
      const kc = easeInOut(range(t, 0, 4));
      place(c, [lerp(40, 55, kc), lerp(95, 100, kc), lerp(60, 80, kc)], [0, lerp(98, 96, kc), 0]);
      return { bloom: 0.7, flare: 1.2, warm: 1.2 };
    },
  };
}
// ============ S6: high above the harbor, the tower towering over tiny ships ============
function sTall({ makeStage }) {
  const scene = harbor(makeStage);
  const lh = lighthouse(); scene.add(lh); const f = fire(lh.fireAt, 1.0);
  const fl = ships(scene, 8, 12);
  const c = far(cam(44));
  return {
    scene, camera: c,
    update(t) {
      f.set(t, 0.6); fl.forEach((s, i) => { s.position.x -= 0.08; });
      const k = easeInOut(range(t, 0, 4.2)); const a = lerp(-0.5, 0.3, k);
      place(c, [Math.sin(a) * lerp(170, 230, k), lerp(150, 190, k), Math.cos(a) * lerp(170, 230, k)], [0, 40, 0]);
      return { bloom: 0.5, warm: 1.25 };
    },
  };
}
// ============ S7: earthquakes crack it; the upper tiers topple into the sea ============
function sQuake({ makeStage, start: ST }) {
  const tC = at(7, 'cracked') - ST, tR = at(7, 'ruin') - ST;
  const scene = harbor(makeStage, { cloud: 0.7 });
  const lh = lighthouse(); scene.add(lh);
  const crackM = new THREE.MeshBasicMaterial({ color: 0x1a120a });
  const cracks = [...Array(5)].map((_, i) => { const pts = []; let x = -8 + i * 4, y = 50 - i * 4; for (let k = 0; k < 10; k++) { pts.push(V(x, y, 14.2)); x += (Math.sin(i * 3 + k) * 1.4); y -= 4; } const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, 0.25, 4), crackM); m.visible = false; lh.sq.add(m); return m; });
  const spl = splash2(30, 4); scene.add(spl);
  const dust = [...Array(30)].map((_, i) => { const s = glowSprite(0xc8b898, 20); s.material.blending = THREE.NormalBlending; scene.add(s); return s; });
  const c = far(cam(44));
  return {
    scene, camera: c,
    update(t) {
      const sh = t < tR ? shake(t * 7, 1.5, 3) : [0, 0, 0];
      lh.position.set(sh[0] * 0.3, 0, sh[1] * 0.3);
      cracks.forEach((m, i) => m.visible = t > tC - 0.3 + i * 0.15);
      const fall = easeIn(range(t, tC + 0.8, tR - 0.2));
      lh.oc.rotation.z = -fall * 1.3; lh.oc.position.set(fall * 40, 57.6 - fall * 60, 0); lh.rd.rotation.z = -fall * 1.6; lh.rd.position.set(fall * 60, 86.6 - fall * 92, 0);
      lh.oc.visible = fall < 0.98; lh.rd.visible = fall < 0.98;
      lh.sq.scale.y = lerp(1, 0.55, range(t, tR - 0.6, tR + 0.4));
      const on = t > tR - 0.3 && t < tR + 2; spl.visible = on; if (on) { spl.position.set(60, 0.1, 0); spl.update(t - tR + 0.3); }
      dust.forEach((s, i) => { const a = range(t, tC + 0.6 + (i % 6) * 0.1, tC + 3.5); s.visible = a > 0 && a < 1; s.position.set(Math.sin(i * 2.1) * 20 + a * 20, 30 + (i % 5) * 8 + a * 10, Math.cos(i * 1.7) * 20); s.material.opacity = 0.5 * (1 - a); });
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(-60, -90, k), lerp(25, 30, k), lerp(160, 190, k)], [lerp(10, 25, k), lerp(50, 35, k), 0]);
      return { bloom: 0.45, warm: 0.95, sat: 0.85 };
    },
  };
}
// ============ S8: the Qaitbay fortress on the same spot today ============
function sFort({ makeStage }) {
  const scene = harbor(makeStage, { sunDir: [-0.6, 0.35, 0.72] });
  const st = blocks(6, 3); const g = new THREE.Group(); scene.add(g);
  const keep = new THREE.Mesh(new THREE.BoxGeometry(30, 22, 30), st); keep.position.y = 17; g.add(keep);
  for (const x of [-15, 15]) for (const z of [-15, 15]) { const t = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 5, 26, 24), st); t.position.set(x, 19, z); g.add(t); const tp = new THREE.Mesh(new THREE.CylinderGeometry(5.2, 5.2, 1.2, 24), st); tp.position.set(x, 32.6, z); g.add(tp); }
  const min = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 2, 12, 12), st); min.position.y = 34; g.add(min);
  for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; const w = new THREE.Mesh(new THREE.BoxGeometry(80, 10, 3), st); w.position.set(Math.sin(a) * 40, 10, Math.cos(a) * 40); w.rotation.y = a; g.add(w); const ct = new THREE.Mesh(new THREE.CylinderGeometry(5, 5.5, 13, 20), st); ct.position.set(Math.sin(a + Math.PI / 4) * 56, 11.5, Math.cos(a + Math.PI / 4) * 56); g.add(ct); }
  shadowAll(g);
  const ghost = lighthouse(); ghost.traverse(o => { if (o.isMesh) { o.material = new THREE.MeshBasicMaterial({ color: 0xbfe0ff, transparent: true, opacity: 0, depthWrite: false }); o.castShadow = false; } }); scene.add(ghost);
  const c = far(cam(44));
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.4)); const a = lerp(0.9, 0.4, k);
      ghost.traverse(o => { if (o.isMesh) o.material.opacity = 0.18 * easeInOut(range(t, 2.0, 3.5)); });
      place(c, [Math.sin(a) * lerp(150, 230, k), lerp(40, 90, k), Math.cos(a) * lerp(150, 230, k)], [0, lerp(15, 45, k), 0]);
      return { bloom: 0.55, flare: 1.1, warm: 1.25 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sHarbor, 'harbor'],
  [ls(2), ls(3), sBuild, 'build'],
  [ls(3), ls(4), sTiers, 'tiers'],
  [ls(4), ls(5), sNight, 'night'],
  [ls(5), ls(6), sMirror, 'mirror'],
  [ls(6), ls(7), sTall, 'tall'],
  [ls(7), ls(8), sQuake, 'quake'],
  [ls(8), DURATION + 1, sFort, 'fort'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
