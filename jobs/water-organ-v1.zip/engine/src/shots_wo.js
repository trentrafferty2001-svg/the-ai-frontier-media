// Hydraulis (water organ) reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { mountains } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { shadowAll, romanBuilder, canvasTex, archMats } from './rome.js';
import { greek } from './classic.js';
import { VO } from './vo_wo.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['The *first pipe organ*', 4], ['over *2,000 years* ago', 5], ['*ran on water*', 3]],
  [['It was the *hydraulis*', 4], ['built by the engineer', 4], ['*Ctesibius*', 1], ['in *Alexandria*', 2]],
  [['Helpers *pumped air*', 3], ['into a chamber', 3], ['standing *upside down*', 3], ['in a *tank of water*', 5]],
  [['The *weight* of the water', 5], ['pressed on that air', 4], ['and kept the pressure', 4], ['*steady*', 1]],
  [['So the pipes played', 4], ['a *smooth, steady note*', 4], ['instead of', 2], ['*stuttering puffs*', 2]],
  [['Pressing a *key*', 3], ['slid open a *valve*', 4], ['and air rushed', 3], ['into a *bronze pipe*', 4]],
  [['It was *loud*', 3], ['and Romans played it', 4], ['at the *games*', 3], ['and in the *arena*', 4]],
  [['In *1992*', 4], ['archaeologists found', 2], ['the remains of one', 4], ['at *Dion*', 2], ['in *Greece*', 2]],
  [['Over the centuries', 3], ['it grew into', 3], ['the *church organ*', 3], ['we know today', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ---------- materials ----------
const bronze = () => new THREE.MeshStandardMaterial({ color: 0xc8964a, metalness: 0.85, roughness: 0.3 });
const wood = (c = 0x6a4626) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.85, bumpMap: fabricTexture(13), bumpScale: 2 });
const waterM = () => new THREE.MeshStandardMaterial({ color: 0x3a9ac8, roughness: 0.1, transparent: true, opacity: 0.6, emissive: 0x0a3a5a, emissiveIntensity: 0.4, depthWrite: false });
// ---------- the organ: tank (x -0.6..0.6, y 0..1.2), wind chest on top, 18 pipes, keys in front (+z), two pumps at the sides ----------
function organ({ cutaway = false } = {}) {
  const g = new THREE.Group(); const B = bronze(); const W = wood();
  const tankM = cutaway ? new THREE.MeshStandardMaterial({ color: 0xc8964a, metalness: 0.6, roughness: 0.3, transparent: true, opacity: 0.18, depthWrite: false, side: THREE.DoubleSide }) : B;
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.66, 1.2, 8, 1, cutaway), tankM); tank.rotation.y = Math.PI / 8; tank.position.y = 0.6; g.add(tank);
  const water = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 1, 32), waterM()); water.visible = cutaway; g.add(water);
  const bell = new THREE.Group(); g.add(bell);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.42, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xa87a3a, metalness: 0.7, roughness: 0.35, side: THREE.DoubleSide, transparent: cutaway, opacity: cutaway ? 0.5 : 1 })); dome.scale.y = 1.3; bell.add(dome);
  const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.25, 32, 1, true), dome.material); skirt.position.y = -0.12; bell.add(skirt);
  bell.position.y = 0.45; bell.visible = cutaway;
  const air = new THREE.Mesh(new THREE.SphereGeometry(0.4, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xe8f6ff, transparent: true, opacity: 0.35, depthWrite: false })); air.scale.y = 1.25; bell.add(air);
  const riser = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.75, 10), B); riser.position.y = 1.0; g.add(riser);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.22, 0.36), W); chest.position.set(0, 1.42, 0); g.add(chest);
  const pipes = []; for (let i = 0; i < 18; i++) { const L = 0.35 + (17 - i) * 0.075; const p = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, L, 10), B); p.position.set(-0.68 + i * 0.08, 1.53 + L / 2, 0); g.add(p); const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.01), new THREE.MeshBasicMaterial({ color: 0x1a1008 })); mouth.position.set(p.position.x, 1.6, 0.026); g.add(mouth); pipes.push(p); }
  const keys = []; for (let i = 0; i < 18; i++) { const k = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.03, 0.28), new THREE.MeshStandardMaterial({ color: 0xe8dcc0, roughness: 0.6 })); k.position.set(-0.68 + i * 0.08, 1.36, 0.32); g.add(k); keys.push(k); }
  const pumps = [-1, 1].map(s => { const pg = new THREE.Group(); pg.position.set(s * 0.95, 0, 0); g.add(pg); const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.9, 16), B); cyl.position.y = 0.45; pg.add(cyl); const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.6, 8), B); rod.position.y = 1.0; pg.add(rod); const lever = new THREE.Group(); lever.position.set(0, 1.3, 0); pg.add(lever); const lv = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.05, 0.05), W); lv.position.x = s * 0.45; lever.add(lv); const post = new THREE.Mesh(new THREE.BoxGeometry(0.06, 1.3, 0.06), W); post.position.set(s * 0.25, -0.65, 0); pg.add(post); const pipeIn = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.45, 8), B); pipeIn.rotation.z = Math.PI / 2; pipeIn.position.set(-s * 0.3, 0.12, 0); pg.add(pipeIn); return { pg, lever, rod }; });
  g.pipes = pipes; g.keys = keys; g.pumps = pumps; g.water = water; g.bell = bell; g.air = air;
  g.set = (t, pumpK = 1, level = 0.8) => {
    pumps.forEach(({ lever, rod }, i) => { const a = Math.sin(t * 4 + i * Math.PI) * 0.3 * pumpK; lever.rotation.z = a; rod.position.y = 1.0 + a * 0.25; });
    water.scale.y = level; water.position.y = 0.04 + level / 2;
  };
  return shadowAll(g);
}
// sound rings rising from the pipe tops
function rings(scene, n = 12, color = 0xffe08a) { const R = [...Array(n)].map((_, i) => { const m = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.012, 6, 32), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0, depthWrite: false })); m.rotation.x = Math.PI / 2; scene.add(m); return m; }); return (t, at, on = 1, steady = true) => R.forEach((m, i) => { const ph = steady ? (t * 0.8 + i / n) % 1 : ((Math.floor(t * 2.5) + i) % 3 === 0 ? (t * 2.5) % 1 : 0); m.position.copy(at).add(V(0, ph * 0.9, 0)); m.scale.setScalar(1 + ph * 4); m.material.opacity = on * 0.75 * (1 - ph) * (steady ? 1 : (ph > 0 ? 1 : 0)); }); }
function hall(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.55, 0.45, 0.7], fog: 0.004, shadowSize: 6, envI: 0.95, cloud: 0.3, ...opts });
  const floor = new THREE.Mesh(new THREE.CircleGeometry(200, 48), new THREE.MeshStandardMaterial({ color: 0xc8b090, roughness: 0.9, bumpMap: fabricTexture(23), bumpScale: 2 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  fillLight(scene, [0.5, 0.4, 1], 0.7, 0xffe6c8);
  return scene;
}
function arena(scene) {
  const A = new THREE.MeshStandardMaterial({ color: 0xd8c8a8, roughness: 0.9, bumpMap: fabricTexture(23), bumpScale: 3 });
  const sand = new THREE.Mesh(new THREE.CircleGeometry(30, 64), new THREE.MeshStandardMaterial({ color: 0xd8b880, roughness: 1 })); sand.rotation.x = -Math.PI / 2; sand.position.y = 0.01; sand.scale.set(1.4, 1, 1); scene.add(sand);
  for (let r = 0; r < 8; r++) { const tier = new THREE.Mesh(new THREE.CylinderGeometry(31 + r * 2.2, 31 + r * 2.2, 1.2, 64, 1, true, Math.PI * 0.15, Math.PI * 1.7), A); tier.scale.set(1.4, 1, 1); tier.position.y = 1.5 + r * 1.2; tier.material.side = THREE.DoubleSide; scene.add(tier); }
  const wallO = new THREE.Mesh(new THREE.CylinderGeometry(50, 50, 16, 64, 1, true, Math.PI * 0.15, Math.PI * 1.7), A); wallO.scale.set(1.4, 1, 1); wallO.position.y = 8; wallO.material.side = THREE.DoubleSide; scene.add(wallO);
  const R = R0(5); const crowd = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.25, 0.5, 4, 8), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 }), 900); const m4 = new THREE.Matrix4(); const col = new THREE.Color();
  for (let i = 0; i < 900; i++) { const r = Math.floor(R() * 8); const a = Math.PI * 0.15 + R() * Math.PI * 1.7; const rad = 31 + r * 2.2 + 0.8; m4.makeTranslation(Math.cos(a) * rad * 1.4, 2.6 + r * 1.2, -Math.sin(a) * rad); crowd.setMatrixAt(i, m4); crowd.setColorAt(i, col.setHex([0xd84a3a, 0xe8dcc0, 0x3a6a9a, 0xe8c040, 0x8a5a3a][i % 5])); }
  scene.add(crowd);
}

// ============ S0 hook: the organ in the arena, the organist plays, sound rings rise ============
function sHook({ makeStage }) {
  const scene = hall(makeStage, { sunDir: [-0.7, 0.25, 0.65], shadowSize: 8 });
  arena(scene);
  const o = organ(); o.position.set(0, 0, 0); scene.add(o);
  const player = romanBuilder({ color: 0xe8dcc0 }); player.root.position.set(0, 0, 0.85); player.root.rotation.y = Math.PI; scene.add(player.root);
  const helpers = [-1, 1].map(s => { const m = romanBuilder({ color: 0x9a6a3a }); m.root.position.set(s * 1.9, 0, 0.1); m.root.rotation.y = -s * Math.PI / 2; scene.add(m.root); return m; });
  const ring = rings(scene, 14);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      o.set(t, 1);
      standPose(player, t, { rSh: [-0.9, 0, 0.2], lSh: [-0.9, 0, -0.2], rEl: [-0.8, 0, 0], lEl: [-0.8, 0, 0], head: [0.1, Math.sin(t) * 0.2, 0] }); player.setMood('happy');
      helpers.forEach((m, i) => { const a = Math.sin(t * 4 + i * Math.PI); standPose(m, t + i, { rSh: [-1.6 - a * 0.4, 0, 0], lSh: [-1.6 - a * 0.4, 0, 0], spine: [0.15 + a * 0.1, 0, 0] }); m.setMood('happy'); });
      o.keys.forEach((k, i) => k.position.y = 1.36 - (Math.sin(t * 6 + i * 1.7) > 0.7 ? 0.02 : 0));
      ring(t, V(0, 2.4, 0), 1, true);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(3.4, 2.6, k), lerp(1.5, 1.9, k), lerp(3.6, 2.8, k)], [-0.1, lerp(1.6, 1.8, k), 0]);
      return { bloom: 0.6, flare: 1.2, warm: 1.3, dof: dofTo([3, 1.7, 3.2], [0, 1.7, 0], 0.003, 0.008) };
    },
  };
}
// ============ S1: Ctesibius in his Alexandrian workshop ============
function sCtesibius({ makeStage }) {
  const scene = hall(makeStage, { sunDir: [-0.4, 0.5, 0.77] });
  const wall = new THREE.Mesh(new THREE.BoxGeometry(14, 5, 0.4), new THREE.MeshStandardMaterial({ color: 0xe8dcc4, roughness: 0.9 })); wall.position.set(0, 2.5, -2.5); scene.add(shadowAll(wall));
  for (let i = 0; i < 4; i++) { const col = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.25, 4.6, 16), new THREE.MeshStandardMaterial({ color: 0xf0e8d8 })); col.position.set(-4.5 + i * 3, 2.3, -2.0); scene.add(shadowAll(col)); }
  const o = organ(); o.position.set(0.6, 0, -0.6); scene.add(o);
  const ct = greek({ color: 0xf2ede0 }); ct.root.position.set(-0.9, 0, 0.3); ct.root.rotation.y = 0.9; scene.add(ct.root);
  const bench = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.8, 0.7), wood()); bench.position.set(-2.4, 0.4, -1.2); scene.add(shadowAll(bench));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      o.set(t, 0.3);
      standPose(ct, t, { rSh: [-1.1, 0, 0], rEl: [-0.5, 0, 0], head: [0.05, -0.3, 0] }); ct.setMood('happy'); ct.blink(blinkK(t, [1.2, 3.1]));
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-1.6, -0.8, k), lerp(1.7, 1.6, k), lerp(4.6, 3.8, k)], [lerp(-0.3, 0, k), 1.3, -0.3]);
      return { bloom: 0.55, warm: 1.25, dof: dofTo([-1.2, 1.6, 4.2], [-0.4, 1.4, 0], 0.003, 0.008) };
    },
  };
}
// ============ S2-S3: cutaway: pumps push air into the upturned bell in the water tank ============
function cutScene(makeStage) {
  const scene = hall(makeStage, { sunDir: [-0.4, 0.6, 0.7] });
  const back = new THREE.Mesh(new THREE.PlaneGeometry(20, 10), new THREE.MeshStandardMaterial({ color: 0x3a3430, roughness: 1 })); back.position.set(0, 5, -3); scene.add(back);
  const o = organ({ cutaway: true }); scene.add(o);
  const helpers = [-1, 1].map(s => { const m = romanBuilder({ color: 0x9a6a3a }); m.root.position.set(s * 1.9, 0, 0.1); m.root.rotation.y = -s * Math.PI / 2; scene.add(m.root); return m; });
  const bub = [...Array(24)].map((_, i) => { const b = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 })); scene.add(b); return b; });
  const arrows = [...Array(6)].map((_, i) => { const a = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.14, 10), new THREE.MeshBasicMaterial({ color: 0xffd040 })); a.rotation.z = Math.PI; scene.add(a); return a; });
  scene.userData = { ...scene.userData, o, helpers, bub, arrows };
  return scene;
}
function sPump({ makeStage, start: ST }) {
  const tU = at(2, 'upside') - ST, tT = at(2, 'tank') - ST;
  const scene = cutScene(makeStage); const { o, helpers, bub } = scene.userData;
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      o.set(t, 1, 0.85);
      helpers.forEach((m, i) => { const a = Math.sin(t * 4 + i * Math.PI); standPose(m, t + i, { rSh: [-1.6 - a * 0.4, 0, 0], lSh: [-1.6 - a * 0.4, 0, 0], spine: [0.15 + a * 0.1, 0, 0] }); m.setMood('happy'); });
      const lvl = lerp(0.42, 0.3, easeInOut(range(t, 0.5, tT))); o.air.scale.y = 1.25; o.bell.position.y = 0.45;
      bub.forEach((b, i) => { const a = (t * 0.9 + i / 24) % 1; const s = i % 2 ? 1 : -1; const P = a < 0.5 ? V(s * lerp(0.75, 0.3, a * 2), 0.12, 0) : V(s * 0.3 * (1 - (a - 0.5) * 2), 0.12 + (a - 0.5) * 2 * 0.5, 0); b.position.copy(P); b.visible = t > 0.3; });
      const k = easeInOut(range(t, 0, tU));
      place(c, [lerp(2.2, 0.9, k), lerp(2.0, 1.0, k), lerp(4.6, 2.9, k)], [0, lerp(1.3, 0.6, k), 0]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
function sPressure({ makeStage, start: ST }) {
  const tW = at(3, 'weight') - ST, tS = at(3, 'steady') - ST;
  const scene = cutScene(makeStage); const { o, helpers, arrows } = scene.userData;
  const flow = [...Array(14)].map(() => { const s = glowSprite(0xbfe8ff, 0.08); scene.add(s); return s; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      o.set(t, 0.8, 0.85);
      helpers.forEach((m, i) => { const a = Math.sin(t * 4 + i * Math.PI); standPose(m, t + i, { rSh: [-1.6 - a * 0.4, 0, 0], lSh: [-1.6 - a * 0.4, 0, 0] }); m.setMood('happy'); });
      arrows.forEach((a, i) => { const ang = i / 6 * Math.PI * 2; const k = range(t, tW - 0.3, tW + 0.3); a.visible = k > 0; a.position.set(Math.cos(ang) * 0.5, 0.85 - ((t * 0.6 + i / 6) % 1) * 0.25, Math.sin(ang) * 0.5 + 0.0); a.scale.setScalar(k); });
      flow.forEach((s, i) => { const a = (t * 0.8 + i / 14) % 1; s.position.set(0, 0.7 + a * 0.75, 0.0); s.visible = t > tS - 1.2; });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(0.9, 1.4, k), lerp(1.0, 1.4, k), lerp(2.9, 3.4, k)], [0, lerp(0.6, 1.0, k), 0]);
      return { bloom: 0.6, warm: 1.15 };
    },
  };
}
// ============ S4: puffs vs a steady note ============
function sSteady({ makeStage, start: ST }) {
  const tP = at(4, 'stuttering') - ST, tS = at(4, 'smooth') - ST;
  const scene = hall(makeStage); const back = new THREE.Mesh(new THREE.PlaneGeometry(20, 10), new THREE.MeshStandardMaterial({ color: 0x3a3430 })); back.position.set(0, 5, -3); scene.add(back);
  const o = organ(); scene.add(o);
  const steadyR = rings(scene, 14, 0xffe08a), puffR = rings(scene, 8, 0xff8a6a);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      o.set(t, 0.6);
      const puff = t > tP - 0.2;
      steadyR(t, V(-0.4, 2.3, 0), puff ? 0 : 1, true); puffR(t, V(-0.4, 2.3, 0), puff ? 1 : 0, false);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(0.6, 0.4, k), lerp(2.2, 2.4, k), lerp(3.2, 2.8, k)], [-0.2, 2.2, 0]);
      return { bloom: 0.65, warm: 1.2 };
    },
  };
}
// ============ S5: a key presses, the slider opens, air rushes into the pipe ============
function sKey({ makeStage, start: ST }) {
  const tK = at(5, 'key') - ST, tV = at(5, 'valve') - ST, tB = at(5, 'bronze') - ST;
  const scene = hall(makeStage); const back = new THREE.Mesh(new THREE.PlaneGeometry(20, 10), new THREE.MeshStandardMaterial({ color: 0x3a3430 })); back.position.set(0, 5, -3); scene.add(back);
  const o = organ(); scene.add(o);
  const slider = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.02, 0.3), new THREE.MeshStandardMaterial({ color: 0x8a6a42 })); scene.add(slider);
  const hole = new THREE.Mesh(new THREE.CircleGeometry(0.022, 16), new THREE.MeshBasicMaterial({ color: 0x0a0604 })); hole.rotation.x = -Math.PI / 2; scene.add(hole);
  const i0 = 8; const px = o.pipes[i0].position.x;
  const air = [...Array(14)].map(() => { const s = glowSprite(0xbfe8ff, 0.05); scene.add(s); return s; });
  const ring = rings(scene, 10);
  const finger = new THREE.Mesh(new THREE.CapsuleGeometry(0.03, 0.12, 4, 10), new THREE.MeshStandardMaterial({ color: 0xd8a07a, roughness: 0.7 })); finger.rotation.x = Math.PI / 2; scene.add(finger);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      o.set(t, 0.4);
      const press = easeInOut(range(t, tK - 0.3, tK + 0.1)); o.keys[i0].position.y = 1.36 - 0.025 * press; finger.position.set(px, 1.44 - 0.025 * press, 0.4);
      const open = easeInOut(range(t, tV - 0.3, tV + 0.2)); slider.position.set(px, 1.535, -0.02 + open * 0.16); hole.position.set(px, 1.532, -0.02);
      air.forEach((s, i) => { const a = (t * 1.2 + i / 14) % 1; s.visible = open > 0.5; s.position.set(px, 1.45 + a * 0.6, 0); });
      ring(t, V(px, 1.53 + o.pipes[i0].geometry.parameters.height + 0.05, 0), range(t, tB - 0.4, tB), true);
      const k = easeInOut(range(t, 0, tB));
      place(c, [lerp(px + 0.6, px + 0.5, k), lerp(1.75, 2.0, k), lerp(1.2, 1.5, k)], [px, lerp(1.45, 1.75, k), 0.05]);
      return { bloom: 0.6, warm: 1.2, dof: dofTo([px + 0.55, 1.85, 1.35], [px, 1.55, 0.05], 0.002, 0.006) };
    },
  };
}
// ============ S6: the arena crowd; the organ plays at the games ============
function sGames({ makeStage }) {
  const scene = hall(makeStage, { sunDir: [-0.6, 0.45, 0.66], shadowSize: 40 });
  arena(scene);
  const o = organ(); o.scale.setScalar(1.4); o.position.set(-6, 0, 12); scene.add(o);
  const ring = rings(scene, 14);
  const ch = new THREE.Group(); const cm = new THREE.MeshStandardMaterial({ color: 0x8a3a2a }); const body = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.8, 1.0), cm); body.position.y = 0.8; ch.add(body); for (const z of [-0.6, 0.6]) { const w = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.06, 8, 20), new THREE.MeshStandardMaterial({ color: 0x4a3020 })); w.position.set(0, 0.5, z); ch.add(w); } for (let i = 0; i < 2; i++) { const h = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.2, 0.5), new THREE.MeshStandardMaterial({ color: [0xe8e0d0, 0x5a3a2a][i] })); h.position.set(2.2, 1.1, -0.4 + i * 0.8); ch.add(h); } scene.add(shadowAll(ch));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      o.set(t, 1); ring(t, V(-6, 3.3, 12), 1, true);
      const a = t * 0.35 + 0.5; ch.position.set(Math.cos(a) * 26 * 1.0, 0, -Math.sin(a) * 18); ch.rotation.y = a - Math.PI / 2 + Math.PI;
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-3.0, -1.5, k), lerp(2.6, 3.4, k), lerp(17.5, 20, k)], [lerp(-6, -5, k), lerp(2.4, 3.0, k), lerp(10, 4, k)]);
      return { bloom: 0.55, flare: 1.1, warm: 1.3 };
    },
  };
}
// ============ S7: Dion, 1992: bronze pipes emerging in an excavation trench ============
function sDig({ makeStage }) {
  const scene = hall(makeStage, { sunDir: [-0.4, 0.6, 0.7] });
  const dirt = new THREE.MeshStandardMaterial({ color: 0x7a5a3e, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 });
  scene.children.find(o => o.geometry && o.geometry.type === 'CircleGeometry').material = new THREE.MeshStandardMaterial({ color: 0x9a7a52, roughness: 1 });
  const pit = new THREE.Mesh(new THREE.BoxGeometry(4, 0.05, 3), dirt); pit.position.set(0, 0.02, 0); scene.add(pit);
  for (const [x, z, w, d] of [[0, -1.55, 4.2, 0.1], [0, 1.55, 4.2, 0.1], [-2.05, 0, 0.1, 3], [2.05, 0, 0.1, 3]]) { const s = new THREE.Mesh(new THREE.BoxGeometry(w, 0.32, d), dirt); s.position.set(x, 0.16, z); scene.add(s); }
  const pipes = new THREE.Group(); const verd = new THREE.MeshStandardMaterial({ color: 0x5a8a6a, metalness: 0.4, roughness: 0.6 });
  for (let i = 0; i < 12; i++) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.4 + (11 - i) * 0.06, 8), verd); p.rotation.z = Math.PI / 2 - 0.1; p.position.set(-0.4 + (0.2 + (11 - i) * 0.03), 0.07, -0.5 + i * 0.07); pipes.add(p); }
  const plate = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.02, 0.6), verd); plate.position.set(0.6, 0.055, 0.4); pipes.add(plate); scene.add(shadowAll(pipes));
  const arch = [0, 1].map(i => { const m = romanBuilder({ color: [0x6a8a9a, 0xd8c8a0][i] }); m.root.position.set(i ? 1.2 : -1.2, 0, i ? -0.8 : 0.9); m.root.rotation.y = i ? -2.2 : 0.8; scene.add(m.root); return m; });
  const dust = [...Array(10)].map(() => { const s = glowSprite(0xc8a878, 0.15); s.material.blending = THREE.NormalBlending; scene.add(s); return s; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      arch.forEach((m, i) => { const s = Math.sin(t * 6 + i); standPose(m, t + i, { spine: [0.7, 0, 0], lHip: [-1.2, 0, 0.1], rHip: [-1.2, 0, -0.1], lKn: [2.0, 0, 0], rKn: [2.0, 0, 0], rSh: [-1.3 + s * 0.2, 0, 0], head: [0.4, 0, 0] }); m.setMood('happy'); m.root.position.y = 0.045 - 0.55; });
      dust.forEach((s, i) => { const a = (t * 0.7 + i / 10) % 1; s.position.set(-0.6 + Math.sin(i) * 0.3, 0.1 + a * 0.4, 0.4); s.material.opacity = 0.5 * (1 - a); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(2.2, 1.4, k), lerp(2.8, 1.9, k), lerp(3.2, 2.4, k)], [0, 0.1, 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S8: a church organ, its pipes rising in a stone nave ============
function sChurch({ makeStage }) {
  const scene = makeStage({ shadowSize: 10, sunDir: [-2, 4, 3], sun: 2.2, envI: 0.7 });
  const u = scene.userData.sky && scene.userData.sky.material.uniforms; if (u) { u.top.value.set(0x1a1612); u.mid.value.set(0x221c16); u.horizon.value.set(0x2a221a); u.floorC.value.set(0x1a1612); }
  const st = new THREE.MeshStandardMaterial({ color: 0xb8ac98, roughness: 0.9, bumpMap: fabricTexture(23), bumpScale: 2 });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 60), new THREE.MeshStandardMaterial({ color: 0x5a4e40, roughness: 0.7 })); floor.rotation.x = -Math.PI / 2; scene.add(floor);
  for (const x of [-6, 6]) for (let i = 0; i < 6; i++) { const col = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.7, 14, 16), st); col.position.set(x, 7, 6 - i * 5); scene.add(shadowAll(col)); }
  const wall = new THREE.Mesh(new THREE.BoxGeometry(14, 22, 1), st); wall.position.set(0, 11, -22); scene.add(wall);
  const case_ = new THREE.Mesh(new THREE.BoxGeometry(9, 2, 2), new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.7 })); case_.position.set(0, 6, -20.5); scene.add(shadowAll(case_));
  const pm = new THREE.MeshStandardMaterial({ color: 0xd8d0c0, metalness: 0.9, roughness: 0.25 });
  const pipes = []; for (let i = 0; i < 31; i++) { const d = Math.abs(i - 15); const L = 9 - d * 0.42; const p = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, L, 14), pm); p.position.set(-4.2 + i * 0.28, 7 + L / 2, -20.5); scene.add(p); pipes.push(p); }
  const win = new THREE.Mesh(new THREE.CircleGeometry(2.2, 32), new THREE.MeshBasicMaterial({ color: 0xffd8a0 })); win.position.set(0, 19, -21.45); scene.add(win);
  const glow = glowSprite(0xffd090, 14); glow.position.set(0, 19, -21); scene.add(glow);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(0.5, 0, k), lerp(2, 4, k), lerp(8, 2, k)], [0, lerp(8, 12, k), -20]);
      return { bloom: 0.7, warm: 1.25 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sCtesibius, 'ctesibius'],
  [ls(2), ls(3), sPump, 'pump'],
  [ls(3), ls(4), sPressure, 'pressure'],
  [ls(4), ls(5), sSteady, 'steady'],
  [ls(5), ls(6), sKey, 'key'],
  [ls(6), ls(7), sGames, 'games'],
  [ls(7), ls(8), sDig, 'dig'],
  [ls(8), DURATION + 1, sChurch, 'church'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
