// The Explainer: how the Panama Canal lifts ships 26 m with no pumps. Timeline, captions and shots.
import * as THREE from 'three';
import { fillLight } from './shots4.js';
import { mountains, birds } from './world.js';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place, kf } from './anim.js';
import { S, L, W, ZC, EDGE, CW, LAKE, yF, yT, lockFlight, culvertSection, containerShip, mule, cable, subwayTrain, lakeTerrain, droughtShore } from './canal.js';
import { VO } from './vo_pc.js';
import { rng } from './textures.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Every *ship*', 2], ['crossing *Panama*', 2], ['climbs a', 2], ['*hill of water*', 3], ['and *no pump*', 3], ['lifts it', 2]],
  [['The middle', 2], ['of the *canal*', 3], ['is a *lake*', 3], ['*26 metres*', 3], ['above the *sea*', 3]],
  [['But ships', 2], ["*can't* sail", 2], ['*uphill*', 1], ['so they enter', 3], ['a *giant*', 2], ['*concrete box*', 2], ['and the *gates*', 3], ['*close* behind them', 3]],
  [['Then *valves*', 2], ['*open*', 1], ['and *lake water*', 3], ['flows *downhill*', 2], ['into the box', 3], ['through *tunnels*', 2], ['big enough', 2], ['to fit', 2], ['a *train*', 2]],
  [['The ship', 2], ['*floats up*', 2], ['about *9 metres*', 3], ['and the', 2], ['*next gate*', 2], ['opens', 1]],
  [['*Three steps*', 2], ['later', 1], ["it's on", 2], ['the *lake*', 2]],
  [['On the', 2], ['*far side*', 2], ['the water', 2], ['*drains out*', 2], ['and the ship', 3], ['*sinks*', 1], ['back down', 2], ['to the *Pacific*', 3]],
  [['*The catch?*', 2], ['Every crossing', 2], ['pours around', 2], ['*200 million*', 3], ['*litres*', 1], ['of *fresh water*', 3], ['into the *sea*', 3]],
  [['So in a', 3], ['*drought*', 1], ['the canal', 2], ['has to *limit*', 3], ['how many *ships*', 3], ['can pass', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const shipX = (i) => i * L + L / 2 + 4;          // ship centre when it sits in chamber i
function stage(makeStage, { preset = 'day', sunDir = [0.5, 0.75, 0.45], shadowSize = 140, shadowAt = [L * 1.5, 10, 0], fog = 0.00045, section = false, terrain = false, cloud = null, hills = true } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt, envI: 0.9, cloud });
  scene.userData.key.shadow.camera.far = 900;
  fillLight(scene, [-0.4, 0.5, -0.8], 0.45, 0xdde8ff);
  const F = lockFlight(scene, { section });
  let T = null;
  if (terrain) T = lakeTerrain(scene);
  else if (hills) scene.add(mountains({ center: [L * 1.5, -2, 0], rMin: 700, rMax: 1500, peaks: 55, height: 90, seed: 5, color: 0x3f6b37 }));
  return { scene, F, T };
}
const C = (fov = 40) => { const c = cam(fov); c.near = 0.3; c.far = 5000; return c; };
// a ship with two forward mules on the quays and tow cables to its bow
function towed(scene, i, lane = 1) {
  const sh = containerShip({ seed: 3 + i }); scene.add(sh);
  const zc = lane * ZC;
  const m1 = mule(), m2 = mule(); scene.add(m1, m2);
  const c1 = cable(), c2 = cable(); scene.add(c1, c2);
  const zIn = lane > 0 ? CW / 2 - 2.5 : -CW / 2 + 2.5, zOut = lane > 0 ? EDGE + 2.5 : -EDGE - 2.5;
  const update = (x, y, ci, heading = 1) => {
    sh.position.set(x, y, zc); sh.rotation.y = heading > 0 ? 0 : Math.PI;
    const mx = x + heading * 40, qy = yT(ci);
    m1.position.set(mx, qy + 0.2, zIn); m2.position.set(mx, qy + 0.2, zOut);
    m1.rotation.y = m2.rotation.y = heading > 0 ? 0 : Math.PI;
    const bx = x + heading * 34, by = y + 6.6;
    c1.set([mx, qy + 3.0, zIn], [bx, by, zc - Math.sign(zc - zIn) * 11.2]);
    c2.set([mx, qy + 3.0, zOut], [bx, by, zc + Math.sign(zOut - zc) * 11.2]);
  };
  return { ship: sh, update };
}
const gateAll = (F, lane, k) => { for (let b = 0; b <= 3; b++) F.gates[`${lane}${b}`].open(k); };

// ============ S0 hook: a ship rises toward the camera on a wall of water ============
function sHook({ makeStage }) {
  const { scene, F } = stage(makeStage, { sunDir: [0.35, 0.7, 0.62], shadowAt: [L * 1.5, 12, ZC], shadowSize: 90 });
  const A = towed(scene, 1, 1);
  const other = containerShip({ seed: 11, hull: 0x3a1f1f }); scene.add(other); other.position.set(shipX(2) - 6, 3 * S, -ZC); F.setLevel('b', 2, 3 * S); F.setLevel('b', 1, S); F.setLevel('b', 0, S);
  F.setLevel('a', 0, 0.4); F.setLevel('a', 2, 2 * S);
  gateAll(F, 'a', 0); gateAll(F, 'b', 0);
  const c = C(36);
  return {
    scene, camera: c,
    update(t) {
      const y = lerp(S + 0.4, 2 * S - 0.6, easeInOut(range(t, 0.0, 4.8)));
      F.setLevel('a', 1, y); A.update(shipX(1), y, 1);
      const k = easeInOut(range(t, 0, 4.8));
      // low 3/4 view from the sea end, outside lane a: sea, the rising ship and the higher chambers read as a staircase of water
      place(c, [lerp(-62, -48, k), lerp(44, 40, k), ZC + lerp(8, 6, k)], [L * 1.45, lerp(9, 13, k), ZC - 2]);
      return { bloom: 0.5, flare: 0.6, warm: 1.15 };
    },
  };
}
// ============ S1: aerial, sea -> three steps -> the lake ============
function sAerial({ makeStage }) {
  const { scene, F } = stage(makeStage, { terrain: true, sunDir: [0.45, 0.62, 0.65], shadowAt: [L * 1.5, 10, 0], shadowSize: 220 });
  const a = containerShip({ seed: 4 }); scene.add(a); a.position.set(shipX(1), 1.5 * S, ZC); F.setLevel('a', 1, 1.5 * S);
  const b = containerShip({ seed: 7, hull: 0x24352a }); scene.add(b); b.position.set(shipX(2), 3 * S, -ZC); F.setLevel('b', 2, 3 * S);
  F.setLevel('a', 0, S); F.setLevel('a', 2, 2 * S); F.setLevel('b', 0, 0); F.setLevel('b', 1, 2 * S);
  gateAll(F, 'a', 0); gateAll(F, 'b', 0); F.gates.b3.open(1);
  const bd = birds(5, { from: [-80, 70, 120], to: [300, 80, 40], spread: 12, speed: 0.06, scale: 3, seed: 3 }); scene.add(bd); scene.userData.updaters.push((t) => bd.update(t));
  const c = C(44);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(-260, -200, k), lerp(230, 250, k), lerp(230, 200, k)], [lerp(1.6 * L, 2.6 * L, k), lerp(0, 14, k), lerp(0, -20, k)]);
      return { bloom: 0.45, flare: 0.5, warm: 1.1 };
    },
  };
}
// ============ S2: the ship sails into the bottom chamber; the gates close behind it ============
function sEnter({ makeStage }) {
  const { scene, F } = stage(makeStage, { sunDir: [0.3, 0.7, 0.65], shadowAt: [L * 0.4, 5, ZC], shadowSize: 110 });
  const A = towed(scene, 0, 1);
  F.setLevel('a', 0, 0); F.setLevel('a', 1, S); F.setLevel('a', 2, 2 * S);
  F.setLevel('b', 0, S); F.setLevel('b', 1, 2 * S); F.setLevel('b', 2, 2 * S);
  const bs = containerShip({ seed: 9, hull: 0x2b2b3b }); scene.add(bs); bs.position.set(shipX(0), S, -ZC);
  gateAll(F, 'b', 0); F.gates.a1.open(0); F.gates.a2.open(0); F.gates.a3.open(0);
  const tClose = at(2, 'gates') - ls(2);
  const c = C(40);
  return {
    scene, camera: c,
    update(t) {
      const x = lerp(-62, shipX(0), easeOut(range(t, 0, tClose - 0.3)));
      A.update(x, 0, x < 0 ? -1 : 0);
      F.gates.a0.open(1 - easeInOut(range(t, tClose - 0.2, tClose + 1.3)));
      const k = easeInOut(range(t, 0, 5.6));
      place(c, [lerp(-150, -135, k), lerp(55, 60, k), lerp(-15, -5, k)], [lerp(5, 25, k), 0, ZC]);
      return { bloom: 0.45, flare: 0.5, warm: 1.1 };
    },
  };
}
// ============ S3: cut-away. Valve opens, lake water runs down the culvert and up into the chamber; a train fits in the tunnel ============
function sCulvert({ makeStage }) {
  const { scene, F } = stage(makeStage, { section: true, sunDir: [0.3, 0.75, 0.6], shadowAt: [2.5 * L, 10, ZC], shadowSize: 120, fog: 0.0006 });
  const X = culvertSection(scene);
  const sh = containerShip({ seed: 5 }); scene.add(sh);
  F.setLevel('a', 0, S); F.setLevel('a', 1, 2 * S); F.setLevel('b', 2, 3 * S);
  gateAll(F, 'a', 0); gateAll(F, 'b', 0);
  const tr = subwayTrain(); scene.add(tr);
  const tv = at(3, 'valves') - ls(3), tTr = at(3, 'big') - ls(3);
  const c = C(38);
  return {
    scene, camera: c,
    update(t) {
      const kv = easeInOut(range(t, tv, tv + 1.0));
      X.setValve(kv);
      const kf1 = easeIn(range(t, tv + 0.5, tv + 2.0));
      X.setFlow(lerp(X.valveX + 0.8, X.X0 + 6, kf1), t, t > tTr - 0.6 && t < tTr + 1.8 ? 0.28 : 0.88);
      X.setRisers(easeOut(range(t, tv + 1.6, tv + 2.3)));
      const lvl = 2 * S + 4.2 * easeInOut(range(t, tv + 2.1, 7.0));
      X.setBoils(range(t, tv + 2.2, tv + 2.6), lvl, t);
      X.setVolume(lvl); F.setLevel('a', 2, lvl);
      sh.position.set(shipX(2), lvl, ZC);
      // flow arrows: down the intake from the start (lake side of the valve), along the culvert once the valve opens, up the risers
      const kMain = 0.2 + 0.8 * kf1;
      X.setArrows(t, kv > 0.3 ? kMain : 0.2, range(t, tv + 1.6, tv + 2.3), t > tTr - 0.8 && t < tTr + 1.6 ? 0 : 0.95);
      // train: glides along the culvert toward the camera while the water is shown faint
      const ktr = range(t, tTr - 0.9, tTr + 1.8);
      tr.visible = ktr > 0 && ktr < 1;
      tr.position.set(lerp(2 * L + 12, 3 * L - 8, easeOut(ktr)), X.cy0 + 0.05, X.culvertZ - 3.0); tr.rotation.y = 0;
      // camera: 3/4 cut-away overview, slow push-in, then low along the tunnel for the train
      const kp = easeInOut(range(t, 0, tTr - 1.0));
      const kt = easeInOut(range(t, tTr - 1.0, tTr + 0.1));
      const p = [lerp(3 * L + 48, 3 * L + 26, kp), lerp(50, 30, kp), lerp(EDGE + 110, EDGE + 72, kp)];
      const l = [lerp(2 * L + 72, 2 * L + 80, kp), lerp(15, 10, kp), EDGE - 12];
      const pT = [3 * L + 14, 6, EDGE + 30], lT = [2 * L + 70, 2.5, EDGE - 5];
      for (let j = 0; j < 3; j++) { p[j] = lerp(p[j], pT[j], kt); l[j] = lerp(l[j], lT[j], kt); }
      place(c, p, l);
      return { bloom: 0.4, warm: 1.05, ao: 0.8 };
    },
  };
}
// ============ S4: the chamber fills, the ship floats up ~9 m, the next gate opens ============
function sRise({ makeStage }) {
  const { scene, F } = stage(makeStage, { sunDir: [0.5, 0.7, 0.5], shadowAt: [L * 0.6, 5, ZC], shadowSize: 120 });
  const A = towed(scene, 0, 1);
  F.setLevel('a', 1, S); F.setLevel('a', 2, 2 * S); F.setLevel('b', 0, 0); F.setLevel('b', 1, S); F.setLevel('b', 2, 3 * S);
  gateAll(F, 'a', 0); gateAll(F, 'b', 0);
  const tg = at(4, 'gate') - ls(4);
  const c = C(42);
  return {
    scene, camera: c,
    update(t) {
      const y = lerp(0.6, S, easeInOut(range(t, 0, tg - 0.1)));
      F.setLevel('a', 0, y); A.update(shipX(0), y, 0);
      F.gates.a1.open(easeInOut(range(t, tg - 0.2, tg + 1.0)));
      const k = easeInOut(range(t, 0, 3.9));
      place(c, [lerp(L * 0.95, L * 0.9, k), lerp(125, 118, k), ZC + lerp(115, 108, k)], [L * 0.5, lerp(0, 5, k), ZC]);
      return { bloom: 0.45, flare: 0.4, warm: 1.1 };
    },
  };
}
// ============ S5: time-lapse up the remaining steps and out onto the lake ============
function sSteps({ makeStage }) {
  const { scene, F } = stage(makeStage, { terrain: true, sunDir: [0.45, 0.65, 0.6], shadowAt: [L * 2, 12, ZC], shadowSize: 200 });
  const sh = containerShip({ seed: 3 }); scene.add(sh);
  F.setLevel('b', 0, S); F.setLevel('b', 1, S); F.setLevel('b', 2, 3 * S); gateAll(F, 'b', 0);
  const D = ls(6) - ls(5);
  // keys (fraction of the shot): move ch0 -> ch1, ch1 fills, move ch1 -> ch2, ch2 fills, move out onto the lake
  const K = [0.0, 0.2, 0.42, 0.6, 0.8, 1.0];
  const c = C(34);
  return {
    scene, camera: c,
    update(t) {
      const u = t / D;
      const seg = (a, b) => smooth(range(u, a, b));
      const x = lerp(lerp(lerp(shipX(0), shipX(1), seg(K[0], K[1])), shipX(2), seg(K[2], K[3])), 3 * L + 110, seg(K[4], K[5]));
      const l1 = lerp(S, 2 * S, seg(K[1], K[2])), l2 = lerp(2 * S, 3 * S, seg(K[3], K[4]));
      F.setLevel('a', 0, S); F.setLevel('a', 1, l1); F.setLevel('a', 2, l2);
      const y = u < K[2] ? (u < K[1] ? S : l1) : (u < K[4] ? (u < K[3] ? 2 * S : l2) : 3 * S);
      sh.position.set(x, y, ZC);
      // gates open only while the ship passes them
      const g = (a, b) => smooth(range(u, a - 0.06, a)) * (1 - smooth(range(u, b, b + 0.06)));
      F.gates.a0.open(0); F.gates.a1.open(g(K[0] + 0.02, K[1] - 0.02)); F.gates.a2.open(g(K[2] + 0.02, K[3] - 0.02)); F.gates.a3.open(smooth(range(u, K[4] - 0.04, K[4])));
      const k = easeInOut(range(t, 0, D));
      place(c, [lerp(1.4 * L, 2.2 * L, k), lerp(78, 86, k), ZC + lerp(185, 175, k)], [lerp(1.6 * L, 2.5 * L, k), lerp(10, 18, k), ZC]);
      return { bloom: 0.45, flare: 0.4, warm: 1.1 };
    },
  };
}
// ============ S6: the far side at golden hour: the chamber drains and the ship sinks back down ============
function sDrain({ makeStage }) {
  const { scene, F } = stage(makeStage, { preset: 'golden', sunDir: [-0.55, 0.32, 0.6], shadowAt: [L * 0.4, 5, ZC], shadowSize: 110 });
  const A = towed(scene, 0, 1);
  F.setLevel('a', 1, S); F.setLevel('a', 2, 2 * S); F.setLevel('b', 0, 0); F.setLevel('b', 1, 2 * S); F.setLevel('b', 2, 3 * S);
  const bs = containerShip({ seed: 13, hull: 0x2a3a4a }); scene.add(bs); bs.position.set(shipX(1), 2 * S, -ZC); bs.rotation.y = Math.PI;
  gateAll(F, 'a', 0); gateAll(F, 'b', 0);
  const tp = at(6, 'pacific') - ls(6);
  const c = C(44);
  return {
    scene, camera: c,
    update(t) {
      const y = lerp(S - 0.3, 0.2, easeInOut(range(t, 0.9, tp - 0.3)));
      F.setLevel('a', 0, y); A.update(shipX(0) + 2, y, 0, -1);
      F.gates.a0.open(easeInOut(range(t, tp - 0.4, tp + 0.9)));
      const k = easeInOut(range(t, 0, 5.1));
      place(c, [lerp(L * 0.95, L * 0.9, k), lerp(34, 31, k), 3.0], [L * 0.1, lerp(2, -2, k), ZC + 2]);
      return { bloom: 0.6, flare: 1.0, warm: 1.35 };
    },
  };
}
// ============ S7: the catch: every lockage dumps lake water into the sea ============
function sDump({ makeStage }) {
  const { scene, F } = stage(makeStage, { sunDir: [0.4, 0.7, 0.6], shadowAt: [-20, 0, 0], shadowSize: 140 });
  F.setLevel('a', 1, 2 * S); F.setLevel('a', 2, 2 * S); F.setLevel('b', 0, S); F.setLevel('b', 1, S); F.setLevel('b', 2, 3 * S);
  gateAll(F, 'a', 0); gateAll(F, 'b', 0);
  const sh = containerShip({ seed: 17 }); scene.add(sh);
  // discharge: foam boils at the outlets + a spreading green-brown plume on the sea
  const cv = document.createElement('canvas'); cv.width = cv.height = 256; const x = cv.getContext('2d'); const R = rng(4);
  for (let i = 0; i < 200; i++) { const r = 6 + R() * 26, a = R() * 6.28, d = Math.pow(R(), 0.7) * 100; x.fillStyle = `rgba(240,250,250,${0.05 + R() * 0.18})`; x.beginPath(); x.arc(128 + Math.cos(a) * d, 128 + Math.sin(a) * d, r, 0, 7); x.fill(); }
  const foamTex = new THREE.CanvasTexture(cv); foamTex.colorSpace = THREE.SRGBColorSpace;
  const cv2 = document.createElement('canvas'); cv2.width = cv2.height = 256; const y2 = cv2.getContext('2d');
  const gr = y2.createRadialGradient(128, 128, 10, 128, 128, 128); gr.addColorStop(0, 'rgba(120,150,110,0.75)'); gr.addColorStop(0.6, 'rgba(110,140,100,0.45)'); gr.addColorStop(1, 'rgba(110,140,100,0)'); y2.fillStyle = gr; y2.fillRect(0, 0, 256, 256);
  const plumeTex = new THREE.CanvasTexture(cv2); plumeTex.colorSpace = THREE.SRGBColorSpace;
  const plume = new THREE.Mesh(new THREE.CircleGeometry(1, 48), new THREE.MeshBasicMaterial({ map: plumeTex, transparent: true, depthWrite: false })); plume.rotation.x = -Math.PI / 2; plume.position.set(-70, 0.12, ZC); scene.add(plume);
  const boils = [];
  for (let i = 0; i < 4; i++) { const m = new THREE.Mesh(new THREE.CircleGeometry(1, 40), new THREE.MeshBasicMaterial({ map: foamTex, transparent: true, depthWrite: false })); m.rotation.x = -Math.PI / 2; m.position.set(-22 - i * 9, 0.2 + i * 0.01, ZC + (i % 2 ? 9 : -9)); scene.add(m); boils.push(m); }
  const c = C(42);
  return {
    scene, camera: c,
    update(t) {
      const y = lerp(S, 0.3, easeInOut(range(t, 0.2, 5.4)));
      F.setLevel('a', 0, y); sh.position.set(shipX(0), y, ZC); sh.rotation.y = Math.PI;
      const k = easeOut(range(t, 0.3, 5.8));
      const s = lerp(25, 150, k); plume.scale.set(s * 1.3, s, 1); plume.position.x = -50 - s * 0.55; plume.material.opacity = 0.9;
      boils.forEach((m, i) => { const ss = (16 + 6 * Math.sin(t * 4 + i * 1.7)) * Math.min(1, t * 2); m.scale.set(ss, ss, 1); m.rotation.z = t * (0.5 + i * 0.2); m.material.opacity = 0.95; });
      const kc = easeInOut(range(t, 0, 5.8));
      place(c, [lerp(-170, -230, kc), lerp(110, 150, kc), lerp(120, 150, kc)], [lerp(-40, -60, kc), 0, ZC - 10]);
      return { bloom: 0.45, flare: 0.4, warm: 1.1 };
    },
  };
}
// ============ S8: drought: the lake drops, stumps and cracked mud show, ships wait at anchor ============
function sDrought({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.3, 0.8, -0.5], fog: 0.0006, shadowSize: 260, shadowAt: [0, LAKE, -60], envI: 0.9, cloud: 0.1 });
  scene.userData.key.shadow.camera.far = 900;
  fillLight(scene, [-0.4, 0.5, 0.8], 0.45, 0xdde8ff);
  const D = droughtShore(scene, { drop: 4.2 });
  const R = rng(31);
  [[-120, 140, 0.4], [10, 190, -0.2], [130, 150, 0.7], [-40, 260, 0.1], [90, 300, 1.1]].forEach(([x, z, r], i) => {
    const s = containerShip({ seed: 21 + i * 2, hull: [0x1d2a3a, 0x3a1f1f, 0x24352a, 0x2a2a3a][i % 4] }); s.position.set(x, LAKE - 4.2, z); s.rotation.y = r; scene.add(s);
  });
  const c = C(42);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.1));
      place(c, [lerp(-30, 10, k), lerp(70, 58, k), lerp(430, 400, k)], [lerp(-10, 10, k), LAKE - 6, -40]);
      return { bloom: 0.5, flare: 0.5, warm: 1.3, sat: 1.05, exposure: 1.05 };
    },
  };
}

// ============ timeline ============
const SH = [sHook, sAerial, sEnter, sCulvert, sRise, sSteps, sDrain, sDump, sDrought];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
