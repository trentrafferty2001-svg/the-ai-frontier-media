// The Explainer: Panama Canal locks. A two-lane flight of three lock chambers (sea -> Gatun Lake),
// mitre gates, container ships, mule locomotives, lake terrain (with a drought mode), a cut-away culvert, a subway train.
// Units are metres. Flight runs along +x: sea for x < 0, chambers i = 0..2 at x in [iL, (i+1)L], lake for x > 3L.
import * as THREE from 'three';
import { rng } from './textures.js';
import { TIME, NOISE, trees, mountains } from './world.js';

export const S = 8.7, L = 110, W = 32, CW = 18, ZC = W / 2 + CW / 2, EDGE = ZC + W / 2, QW = 8;
export const LAKE = 3 * S;
export const yF = (i) => Math.min(Math.max(i, -1), 3) * S - 13;              // floor of chamber i (-1 sea approach, 3 lake approach)
export const yT = (i) => Math.min(Math.max(i + 1, 0), 3) * S + 2.4;          // quay / wall top beside chamber i
export const lanes = [ZC, -ZC];

const canvasTex = (w, h, draw, repeat = null) => {
  const cv = document.createElement('canvas'); cv.width = w * 2; cv.height = h * 2; const cx = cv.getContext('2d'); cx.scale(2, 2); draw(cx, w, h);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat); }
  return t;
};
const shadowAll = (o, cast = true) => { o.traverse(c => { if (c.isMesh) { c.castShadow = cast; c.receiveShadow = true; } }); return o; };

// ---------- materials ----------
// concrete shaded in world space (no stretched UVs): pour lifts, blotches, dark wet stain + green algae below each chamber's top water line
function concreteMat({ base = 0xb9b4aa, wet = true, cut = false } = {}) {
  const m = new THREE.MeshStandardMaterial({ color: base, roughness: 0.92 });
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWPc; varying vec3 vNc;')
      .replace('#include <project_vertex>', '#include <project_vertex>\nvWPc = (modelMatrix * vec4(transformed, 1.0)).xyz; vNc = normalize(mat3(modelMatrix) * objectNormal);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWPc; varying vec3 vNc;\n${NOISE}`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        vec3 p = vWPc; vec3 an = abs(vNc);
        vec2 q = an.y > 0.6 ? p.xz : (an.x > an.z ? p.zy : p.xy);
        float n = fbm(q * 0.11) * 0.6 + fbm(q * 0.9) * 0.4;
        diffuseColor.rgb *= 0.82 + n * 0.36;
        ${cut ? `float hatch = step(0.5, fract((q.x + q.y) * 0.35)); diffuseColor.rgb *= 0.93 + hatch * 0.07;` : ''}
        if (an.y < 0.6) {
          diffuseColor.rgb *= 1.0 - 0.07 * smoothstep(0.0, 0.08, abs(fract(p.y / 1.6) - 0.5) - 0.42);
          ${wet ? `
          float ci = clamp(floor(p.x / ${L.toFixed(1)}), -1.0, 3.0);
          float top = ci < -0.5 ? 1.2 : min(ci + 1.0, 3.0) * ${S.toFixed(2)};
          float streak = fbm(vec2((p.x + p.z) * 0.6, 0.0)) * 0.9;
          float wetk = smoothstep(top + 0.25 + streak, top - 0.35, p.y);
          diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.42, 0.46, 0.40), wetk);
          float alg = wetk * smoothstep(1.6, 0.0, top - p.y) * (0.5 + 0.5 * fbm(q * 1.7));
          diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.20, 0.30, 0.16), alg * 0.55);` : ''}
        }`);
  };
  return m;
}
let CM = null;
export function canalMats() {
  if (CM) return CM;
  const grassTex = canvasTex(256, 256, (x) => {
    x.fillStyle = '#5f8a3a'; x.fillRect(0, 0, 256, 256); const R = rng(4);
    for (let i = 0; i < 1600; i++) { x.fillStyle = `hsla(${80 + R() * 30},${35 + R() * 25}%,${22 + R() * 22}%,0.35)`; x.fillRect(R() * 256, R() * 256, 1 + R() * 4, 1 + R() * 4); }
  }, [40, 40]);
  CM = {
    conc: concreteMat(),
    concDry: concreteMat({ wet: false, base: 0xc4bfb4 }),
    cut: concreteMat({ wet: false, cut: true, base: 0xb4b4ae }),
    earthCut: concreteMat({ wet: false, cut: true, base: 0x9a7650 }),
    grass: new THREE.MeshStandardMaterial({ map: grassTex, roughness: 1 }),
    steel: new THREE.MeshStandardMaterial({ color: 0x8a9692, roughness: 0.6, metalness: 0.35 }),
    rail: new THREE.MeshStandardMaterial({ color: 0x8a8a86, roughness: 0.35, metalness: 0.9 }),
    white: new THREE.MeshStandardMaterial({ color: 0xf2f2ee, roughness: 0.6 }),
    yellow: new THREE.MeshStandardMaterial({ color: 0xe8b830, roughness: 0.6 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x1c2024, roughness: 0.9 }),
  };
  return CM;
}

// canal water: a sky-reflecting surface with moving ripples (and an optional volume box for cut-aways)
export function canalWater({ color = 0x2f6a6c, ripple = 1.0, opacity = 1 } = {}) {
  const m = new THREE.MeshStandardMaterial({ color, roughness: 0.06, metalness: 0.0, transparent: opacity < 1, opacity, depthWrite: true });
  m.userData.uRip = { value: ripple };
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = TIME; sh.uniforms.uRip = m.userData.uRip;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWPw;')
      .replace('#include <project_vertex>', '#include <project_vertex>\nvWPw = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWPw; uniform float uTime, uRip;\n${NOISE}`)
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
        vec2 q = vWPw.xz * 0.35 + vec2(uTime * 0.25, uTime * 0.17);
        float h0 = fbm(q), hx = fbm(q + vec2(0.1, 0.0)), hz = fbm(q + vec2(0.0, 0.1));
        vec2 q2 = vWPw.xz * 1.6 + vec2(-uTime * 0.4, uTime * 0.3);
        float g0 = fbm(q2), gx = fbm(q2 + vec2(0.1, 0.0)), gz = fbm(q2 + vec2(0.0, 0.1));
        vec3 pert = (vec3(h0 - hx, 0.0, h0 - hz) * 0.9 + vec3(g0 - gx, 0.0, g0 - gz) * 0.35) * uRip;
        normal = normalize(normal + (viewMatrix * vec4(pert, 0.0)).xyz);`);
  };
  return m;
}
// water seen from the side in a cut-away: translucent teal with depth darkening
export function volumeMat(opacity = 0.62) {
  return new THREE.MeshStandardMaterial({ color: 0x2a78a0, roughness: 0.2, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide });
}

// ---------- mitre gate: two leaves; open(k) 0 = closed (V pointing upstream, +x), 1 = folded back along the walls ----------
function gatePair(b, zc, M) {
  const g = new THREE.Group();
  const bottom = yF(b), top = (b < 3 ? (b + 1) * S : LAKE) + 1.6, h = top - bottom;
  const th = 0.32, half = W / 2 - 0.9, lw = half / Math.cos(th) + 0.6;
  const leaves = [];
  for (const side of [1, -1]) {
    const pivot = new THREE.Group(); pivot.position.set(b * L + 0.3, 0, zc + side * half);
    const leaf = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.9, h, lw), M.steel); body.position.set(0, bottom + h / 2, -side * lw / 2);
    leaf.add(body);
    // ribs on the downstream face + a white walkway with a rail on top
    for (let k = 1; k < 6; k++) { const r = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, lw - 0.6), M.steel); r.position.set(-1.1, bottom + h * k / 6, -side * lw / 2); leaf.add(r); }
    const walk = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.25, lw), M.white); walk.position.set(0, top + 0.12, -side * lw / 2); leaf.add(walk);
    for (const dx of [-1.1, 1.1]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, lw), M.white); rail.position.set(dx, top + 1.2, -side * lw / 2); leaf.add(rail);
      for (let k = 0; k <= 6; k++) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.0, 0.08), M.white); p.position.set(dx, top + 0.7, -side * (k / 6) * lw); leaf.add(p); }
    }
    pivot.add(leaf); g.add(pivot);
    leaves.push({ pivot, side });
  }
  // +z leaf (side 1) rotates from -th to -pi/2; -z leaf (side -1) from +th to +pi/2
  const open = (k) => { for (const { pivot, side } of leaves) pivot.rotation.y = side > 0 ? -THREE.MathUtils.lerp(th, Math.PI / 2 - 0.02, k) : THREE.MathUtils.lerp(th, Math.PI / 2 - 0.02, k); };
  open(0);
  return { group: g, open };
}

// ---------- the lock flight ----------
// opts.section: cut the world at z = EDGE on the +z side (cut-away view from +z) and build the culvert diorama under chamber 2
export function lockFlight(scene, { section = false, landTrees = true, seaColor = 0x2a6878 } = {}) {
  const M = canalMats(); const root = new THREE.Group(); scene.add(root);
  const box = (x0, x1, y0, y1, z0, z1, mat) => {
    if (x1 - x0 < 0.01 || y1 - y0 < 0.01 || z1 - z0 < 0.01) return null;
    const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), mat);
    m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2); m.castShadow = m.receiveShadow = true; root.add(m); return m;
  };
  const DEEP = -60, ZMAX = section ? EDGE : 900;
  const segs = [[-60, 0, -1], [0, L, 0], [L, 2 * L, 1], [2 * L, 3 * L, 2], [3 * L, 3 * L + 70, 3]];
  for (const [x0, x1, i] of segs) {
    // floor slab under both lanes
    const fz1 = section && (i === 2 || i === 3) ? EDGE - 6 : EDGE;
    const fl = box(x0, x1, DEEP, yF(i), -EDGE, fz1, section ? [M.conc, M.conc, M.conc, M.conc, M.cut, M.conc] : M.conc);
    if (fl && section) fl.material = [M.conc, M.conc, M.conc, M.conc, M.cut, M.conc];
    if (i >= 0 && i <= 2) {
      // centre wall
      box(x0, x1, yF(i), yT(i), -CW / 2, CW / 2, M.conc);
      box(x0, x1, yT(i), yT(i) + 0.05, -CW / 2, CW / 2, M.concDry);
    }
    // outer quays and land (the +z ones are left out in section mode)
    for (const sz of [1, -1]) {
      if (section && sz > 0) continue;
      const zq0 = EDGE, zq1 = EDGE + QW, top = yT(i);
      const lo = sz > 0 ? [zq0, zq1] : [-zq1, -zq0];
      box(x0, x1, DEEP, top, lo[0], lo[1], M.conc);
      const land = sz > 0 ? [zq1, 900] : [-900, -zq1];
      box(x0, x1, DEEP, top - 0.3, land[0], land[1], [M.conc, M.conc, M.grass, M.conc, M.conc, M.conc]);
    }
    if (i >= 0 && i <= 2) for (const zc of lanes) for (const sz of [1, -1]) {
      if (section && zc > 0 && sz > 0) continue;
      // mule rails on the quay tops and the centre wall
      const z = sz > 0 ? (zc > 0 ? EDGE + 2.5 : -CW / 2 + 2.5) : (zc > 0 ? CW / 2 - 2.5 : -EDGE - 2.5);
      for (const dz of [-0.7, 0.7]) box(x0, x1, yT(i), yT(i) + 0.18, z + dz - 0.06, z + dz + 0.06, M.rail);
    }
  }
  // inclines for the mule tracks between chamber levels are hidden under the gate houses: small control houses at each gate
  for (let b = 0; b <= 3; b++) for (const z of [EDGE + QW / 2, -EDGE - QW / 2, 0]) {
    if (section && z > EDGE) continue;
    const yy = yT(Math.min(b, 2));
    const hs = box(b * L - 4, b * L + 4, yy, yy + 4.5, z - 3, z + 3, M.white);
    const rf = box(b * L - 4.6, b * L + 4.6, yy + 4.5, yy + 5.0, z - 3.6, z + 3.6, new THREE.MeshStandardMaterial({ color: 0x9a3a2a, roughness: 0.8 }));
  }
  // sea and lake surfaces
  const seaMat = canalWater({ color: seaColor });
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(3000, section ? 1500 + EDGE : 3000), seaMat); sea.rotation.x = -Math.PI / 2;
  sea.position.set(-1500, 0, section ? (EDGE - 1500) / 2 : 0); sea.receiveShadow = true; root.add(sea);
  const lakeMat = canalWater({ color: 0x2c6a5c });
  const lake = new THREE.Mesh(new THREE.PlaneGeometry(3000, section ? 1500 + EDGE : 3000), lakeMat); lake.rotation.x = -Math.PI / 2;
  lake.position.set(3 * L + 1500, LAKE, section ? (EDGE - 1500) / 2 : 0); lake.receiveShadow = true; root.add(lake);
  // chamber water, per lane
  const cw = {};
  const cMat = canalWater({ color: 0x2f6a6c });
  for (const zc of lanes) for (let i = 0; i < 3; i++) {
    const w = new THREE.Mesh(new THREE.PlaneGeometry(L - 0.2, W - 0.1), cMat); w.rotation.x = -Math.PI / 2;
    w.position.set(i * L + L / 2, i * S, zc); w.receiveShadow = true; root.add(w);
    cw[`${zc > 0 ? 'a' : 'b'}${i}`] = w;
  }
  const vols = {};
  if (section) {
    // ground beyond the flight, cut at z = EDGE, and water volumes so the cut face reads everywhere
    box(-700, -60, DEEP, yF(-1), -900, EDGE, [M.earthCut, M.earthCut, M.earthCut, M.earthCut, M.earthCut, M.earthCut]);
    box(3 * L + 70, 3 * L + 700, DEEP, yF(3), -900, EDGE, [M.earthCut, M.earthCut, M.earthCut, M.earthCut, M.earthCut, M.earthCut]);
    const vm = volumeMat(0.62);
    const vbox = (x0, x1, y0, y1) => { const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, 1, 2 * EDGE - 0.4), vm); m.renderOrder = 2; m.userData.r = [x0, x1, y0]; m.position.set((x0 + x1) / 2, 0, 0.0); m.set = (y) => { m.scale.y = Math.max(0.01, y - y0); m.position.y = (y + y0) / 2; }; m.set(y1); root.add(m); return m; };
    vbox(-700, -0.2, yF(-1), 0); vbox(3 * L + 70, 3 * L + 700, yF(3), LAKE);
    for (let i = 0; i < 2; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(L - 0.4, 1, W - 0.4), vm); m.renderOrder = 2; m.position.set(i * L + L / 2, 0, ZC); m.set = (y) => { m.scale.y = y - yF(i); m.position.y = (y + yF(i)) / 2; }; m.set(i * S); root.add(m); vols[i] = m; }
  }
  const setLevel = (lane, i, y) => { cw[`${lane}${i}`].position.y = y; if (lane === 'a' && vols[i]) vols[i].set(y); };
  // gates
  const gates = {};
  for (const zc of lanes) for (let b = 0; b <= 3; b++) { const gp = gatePair(b, zc, M); shadowAll(gp.group); root.add(gp.group); gates[`${zc > 0 ? 'a' : 'b'}${b}`] = gp; }
  // trees on the land beside the locks
  if (landTrees && !section) {
    const R = rng(21), spots = [];
    for (let k = 0; k < 220; k++) {
      const x = -50 + R() * (3 * L + 110), sz = R() < 0.5 ? 1 : -1, z = sz * (R() < 0.6 && sz < 0 ? EDGE + QW + 12 + R() * 30 : 430 + R() * 220);
      const i = x < 0 ? -1 : x > 3 * L ? 3 : Math.floor(x / L);
      if (Math.abs(x - Math.round(x / L) * L) < 10) continue;
      spots.push([x, yT(i) - 0.3, z]);
    }
    const tr = trees(spots, { seed: 9, scale: 3.2 }); root.add(tr);
  }
  return { root, setLevel, gates, cw, seaMat, lakeMat, sea, lake, vols };
}

// ---------- cut-away diorama under chamber 2 (+z lane): culvert from the lake, valve, risers into the chamber ----------
// Call after lockFlight(scene, { section: true }). Returns setters for valve, culvert water, risers, chamber volume.
export function culvertSection(scene) {
  const M = canalMats(); const g = new THREE.Group(); scene.add(g);
  const z0 = EDGE - 6, z1 = EDGE;
  const X0 = 2 * L, X1 = 3 * L + 70;
  const top = (x) => x < 3 * L ? yF(2) : yF(3);
  const cy0 = yF(2) - 9.0, cy1 = yF(2) - 3.5;          // culvert: 5.5 m high
  const holes = [
    [2 * L + 6, X1 + 1, cy0, cy1],                       // main culvert (runs on past the frame under the lake)
    [3 * L + 9, 3 * L + 15, cy1 - 0.01, yF(3) + 0.01],  // intake shaft up to the lake floor
    [3 * L + 1.5, 3 * L + 3.5, cy1 - 0.01, cy1 + 4.0],   // valve slot
  ];
  const risers = [2 * L + 44, 2 * L + 70, 2 * L + 96].map(x => [x - 1.6, x + 1.6, cy1 - 0.01, yF(2) + 0.01]);
  holes.push(...risers);
  const xs = new Set([X0, X1, 3 * L]), ys = new Set([-60, yF(2), yF(3)]);
  for (const [a, b, c, d] of holes) { xs.add(a); xs.add(b); ys.add(c); ys.add(d); }
  const XS = [...xs].filter(v => v >= X0 && v <= X1).sort((a, b) => a - b), YS = [...ys].sort((a, b) => a - b);
  const inHole = (x, y) => holes.some(([a, b, c, d]) => x > a && x < b && y > c && y < d);
  for (let i = 0; i < XS.length - 1; i++) for (let j = 0; j < YS.length - 1; j++) {
    const xm = (XS[i] + XS[i + 1]) / 2, ym = (YS[j] + YS[j + 1]) / 2;
    if (ym > top(xm) || inHole(xm, ym)) continue;
    const yTop = Math.min(YS[j + 1], top(xm));
    const m = new THREE.Mesh(new THREE.BoxGeometry(XS[i + 1] - XS[i], yTop - YS[j], z1 - z0), [M.conc, M.conc, M.conc, M.conc, M.cut, M.conc]);
    m.position.set(xm, (YS[j] + yTop) / 2, (z0 + z1) / 2); m.receiveShadow = true; g.add(m);
  }
  // dark back wall of the culvert so it reads as a tunnel
  const back = new THREE.Mesh(new THREE.PlaneGeometry(X1 - X0, cy1 - cy0), new THREE.MeshStandardMaterial({ color: 0x3a3632, roughness: 1 }));
  back.position.set((X0 + X1) / 2, (cy0 + cy1) / 2, z0 + 0.02); g.add(back);
  // valve: steel slab that slides up into its slot
  const valve = new THREE.Mesh(new THREE.BoxGeometry(1.6, cy1 - cy0, z1 - z0 - 0.2), M.steel); valve.castShadow = true; g.add(valve);
  const vx = 3 * L + 2.5;
  const setValve = (k) => valve.position.set(vx, (cy0 + cy1) / 2 + k * 4.0, (z0 + z1) / 2);
  setValve(0);
  // flowing water in the culvert: streak texture scrolled toward -x
  const streak = canvasTex(256, 64, (x) => {
    x.fillStyle = '#2b7f8c'; x.fillRect(0, 0, 256, 64); const R = rng(8);
    for (let i = 0; i < 70; i++) { x.fillStyle = `rgba(210,240,250,${0.12 + R() * 0.3})`; x.fillRect(R() * 256, R() * 64, 20 + R() * 70, 1 + R() * 1.5); }
  }, [6, 1]);
  streak.wrapS = streak.wrapT = THREE.RepeatWrapping;
  const flowMat = new THREE.MeshStandardMaterial({ map: streak, roughness: 0.2, transparent: true, opacity: 0.88, depthWrite: false, side: THREE.DoubleSide });
  const flow = new THREE.Mesh(new THREE.PlaneGeometry(1, cy1 - cy0 - 0.2), flowMat); flow.position.z = z1 - 0.3; g.add(flow);
  const intakeX0 = 3 * L + 9;
  // fill: from the valve (when open) leftwards to xEnd; the right part (valve -> past intake) is always full
  const setFlow = (xEnd, t, op = 0.88) => {
    const a = xEnd, b = X1;
    flow.scale.x = b - a; flow.position.set((a + b) / 2, (cy0 + cy1) / 2, z1 - 0.3);
    streak.offset.x = t * 1.6; streak.repeat.set((b - a) / 14, 1); flowMat.opacity = op;
  };
  setFlow(vx + 0.8, 0);
  // water column in the intake shaft (always full from the lake)
  const shaft = new THREE.Mesh(new THREE.PlaneGeometry(6, yF(3) - cy1 + 0.4), flowMat.clone()); shaft.material.map = streak; shaft.position.set(intakeX0 + 3, (cy1 + yF(3)) / 2, z1 - 0.3); shaft.rotation.z = Math.PI / 2; shaft.scale.set((yF(3) - cy1 + 0.4) / 6, 6 / (yF(3) - cy1 + 0.4), 1); g.add(shaft);
  // risers fill upward
  const rMat = flowMat.clone(); rMat.map = streak;
  const rs = risers.map(([a, b]) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(b - a - 0.2, 1), rMat); m.position.set((a + b) / 2, cy1, z1 - 0.3); m.visible = false; g.add(m); return m; });
  const setRisers = (k) => rs.forEach((m) => { const h = (yF(2) - cy1 + 0.2) * k; m.visible = k > 0.01; m.scale.y = Math.max(0.01, h); m.position.y = cy1 + h / 2; });
  // boils on the chamber surface above each riser
  const boilTex = canvasTex(128, 128, (x) => { const R = rng(5); for (let i = 0; i < 60; i++) { const r = 4 + R() * 14, a = R() * 6.28, d = R() * 44; x.fillStyle = `rgba(235,248,250,${0.15 + R() * 0.3})`; x.beginPath(); x.arc(64 + Math.cos(a) * d, 64 + Math.sin(a) * d, r, 0, 7); x.fill(); } });
  const boils = risers.map(([a, b], i) => { const m = new THREE.Mesh(new THREE.CircleGeometry(7, 32), new THREE.MeshBasicMaterial({ map: boilTex, transparent: true, depthWrite: false, opacity: 0 })); m.rotation.x = -Math.PI / 2; m.position.set((a + b) / 2, 0, ZC + 4); g.add(m); return m; });
  const setBoils = (k, level, t) => boils.forEach((m, i) => { m.material.opacity = k * 0.9; m.position.y = level + 0.05; const s = 1 + 0.12 * Math.sin(t * 5 + i); m.scale.set(s, s, 1); m.rotation.z = t * 0.6 + i; });
  // chamber water volume, seen through the cut (front face at z = EDGE)
  const vol = new THREE.Mesh(new THREE.BoxGeometry(L - 0.4, 1, W - 0.4), volumeMat(0.62)); vol.renderOrder = 2; g.add(vol);
  const setVolume = (level) => { const h = level - yF(2); vol.scale.y = h; vol.position.set(2 * L + L / 2, yF(2) + h / 2, ZC); };
  setVolume(2 * S);
  // lake volume over the lake approach floor
  const lv = new THREE.Mesh(new THREE.BoxGeometry(X1 - 3 * L - 0.6, LAKE - yF(3), 2 * EDGE), volumeMat(0.5)); lv.renderOrder = 2;
  lv.position.set((3 * L + 0.3 + X1) / 2, (LAKE + yF(3)) / 2, 0); g.add(lv);
  // flow arrows (chevrons) on the cut face: down the intake, along the culvert, up the risers
  const cy = (cy0 + cy1) / 2;
  const arrowGeo = (() => { const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.lineTo(-1.6, 1.3); sh.lineTo(-1.0, 1.3); sh.lineTo(0.6, 0); sh.lineTo(-1.0, -1.3); sh.lineTo(-1.6, -1.3); sh.lineTo(0, 0); return new THREE.ShapeGeometry(sh); })();
  const aMat = new THREE.MeshBasicMaterial({ color: 0xfff3b0, transparent: true, depthWrite: false, depthTest: false });
  const paths = [
    [[intakeX0 + 3, yF(3) + 6], [intakeX0 + 3, cy], [2 * L + 44, cy]],
    ...risers.map(([a, b]) => [[(a + b) / 2, cy], [(a + b) / 2, yF(2) + 5]]),
  ];
  const plen = (P) => P.slice(1).reduce((s, q, i) => s + Math.hypot(q[0] - P[i][0], q[1] - P[i][1]), 0);
  const arrows = [];
  paths.forEach((P, pi) => { const n = Math.ceil(plen(P) / 7); for (let i = 0; i < n; i++) { const m = new THREE.Mesh(arrowGeo, aMat); m.renderOrder = 5; m.visible = false; g.add(m); arrows.push({ m, P, pi, i, n }); } });
  // k0: main path reveal 0..1 (front of the water), k1: risers reveal 0..1, a: opacity
  const setArrows = (t, k0, k1, a) => {
    aMat.opacity = a;
    for (const A of arrows) {
      const L0 = plen(A.P); let d = ((A.i * 7 + t * 9) % (A.n * 7));
      const lim = (A.pi === 0 ? k0 : k1) * L0;
      if (d > lim || d > L0 || a <= 0.01) { A.m.visible = false; continue; }
      let P = A.P, seg = 0; while (seg < P.length - 2 && d > Math.hypot(P[seg + 1][0] - P[seg][0], P[seg + 1][1] - P[seg][1])) { d -= Math.hypot(P[seg + 1][0] - P[seg][0], P[seg + 1][1] - P[seg][1]); seg++; }
      const [x0, y0] = P[seg], [x1, y1] = P[seg + 1], len = Math.hypot(x1 - x0, y1 - y0), u = Math.min(1, d / len);
      A.m.visible = true; A.m.position.set(x0 + (x1 - x0) * u, y0 + (y1 - y0) * u, z1 + 0.6); A.m.rotation.z = Math.atan2(y1 - y0, x1 - x0); A.m.scale.setScalar(1.3);
    }
  };
  return { group: g, setValve, setFlow, setRisers, setBoils, setVolume, setArrows, valveX: vx, X0, X1, cy0, cy1, culvertZ: z1, intakeX: intakeX0 + 3 };
}

// ---------- container ship (+x forward), origin at the waterline, centre ----------
export function containerShip({ Ls = 96, B = 24, seed = 3, hull = 0x1d2a3a, deckTiers = [3, 5] } = {}) {
  const R = rng(seed); const g = new THREE.Group();
  const shape = new THREE.Shape();
  const hb = B / 2, xs = -Ls / 2, xb = Ls / 2;
  shape.moveTo(xs + 3, -hb); shape.lineTo(xb - 24, -hb);
  shape.bezierCurveTo(xb - 10, -hb, xb - 2, -hb * 0.45, xb, 0);
  shape.bezierCurveTo(xb - 2, hb * 0.45, xb - 10, hb, xb - 24, hb);
  shape.lineTo(xs + 3, hb); shape.quadraticCurveTo(xs, hb, xs, hb - 3); shape.lineTo(xs, -hb + 3); shape.quadraticCurveTo(xs, -hb, xs + 3, -hb);
  const part = (y0, y1, mat, inset = 0) => {
    const geo = new THREE.ExtrudeGeometry(shape, { depth: y1 - y0, bevelEnabled: false, curveSegments: 14 });
    geo.rotateX(-Math.PI / 2); geo.translate(0, y0, 0);
    if (inset) geo.scale(1 - inset / Ls, 1, 1 - inset / B);
    const m = new THREE.Mesh(geo, mat); g.add(m); return m;
  };
  const red = new THREE.MeshStandardMaterial({ color: 0x7a2a24, roughness: 0.75 });
  const dark = new THREE.MeshStandardMaterial({ color: hull, roughness: 0.55, metalness: 0.15 });
  const deckM = new THREE.MeshStandardMaterial({ color: 0x5c6a5a, roughness: 0.9 });
  part(-9, 0.4, red, 1.2); part(0.4, 6, dark); part(6, 6.25, deckM, 0.4);
  // white boot line
  const bl = part(0.35, 0.65, new THREE.MeshStandardMaterial({ color: 0xe8e8e4, roughness: 0.7 }), -0.15);
  // containers: 40 ft boxes, rows across the beam, random tiers, corrugated texture tinted by instance colour
  const ribs = canvasTex(128, 64, (x) => { x.fillStyle = '#fff'; x.fillRect(0, 0, 128, 64); for (let i = 0; i < 128; i += 4) { x.fillStyle = 'rgba(0,0,0,0.22)'; x.fillRect(i, 0, 1.5, 64); } x.fillStyle = 'rgba(0,0,0,0.3)'; x.fillRect(0, 0, 128, 3); x.fillRect(0, 61, 128, 3); });
  const cMat = new THREE.MeshStandardMaterial({ map: ribs, roughness: 0.7 });
  const cl = 12.2, cwd = 2.44, ch = 2.6;
  const pal = [0xc0392b, 0x2471a3, 0xe67e22, 0x7f8c8d, 0x1e8449, 0xf0f0ea, 0x16a085, 0x884ea0, 0xb7950b, 0x5d6d7e];
  const slots = [];
  const bays = []; for (let x = xs + 22; x + cl < xb - 20; x += cl + 0.9) bays.push(x + cl / 2);
  const rows = Math.floor((B - 2.6) / (cwd + 0.08));
  for (const bx of bays) {
    const tiers = deckTiers[0] + Math.floor(R() * (deckTiers[1] - deckTiers[0] + 1));
    for (let r = 0; r < rows; r++) {
      const z = (r - (rows - 1) / 2) * (cwd + 0.08);
      const tt = Math.max(1, tiers - (r === 0 || r === rows - 1 ? Math.floor(R() * 2) : 0));
      for (let k = 0; k < tt; k++) slots.push([bx, 6.25 + ch / 2 + k * (ch + 0.04), z]);
    }
  }
  const inst = new THREE.InstancedMesh(new THREE.BoxGeometry(cl, ch, cwd), cMat, slots.length);
  const mm = new THREE.Matrix4(), c = new THREE.Color();
  slots.forEach(([x, y, z], i) => { mm.makeTranslation(x, y, z); inst.setMatrixAt(i, mm); c.setHex(pal[Math.floor(R() * pal.length)]); c.offsetHSL(0, 0, (R() - 0.5) * 0.08); inst.setColorAt(i, c); });
  g.add(inst);
  // lashing bridges between bays
  for (const bx of bays) { const lb = new THREE.Mesh(new THREE.BoxGeometry(0.5, 4.5, B - 2), new THREE.MeshStandardMaterial({ color: 0xd8d0b0, roughness: 0.7 })); lb.position.set(bx - cl / 2 - 0.45, 6.25 + 2.25, 0); g.add(lb); }
  // superstructure aft: white block with window rows, wider bridge deck, funnel
  const win = canvasTex(128, 128, (x) => { x.fillStyle = '#f3f3ef'; x.fillRect(0, 0, 128, 128); for (let r = 0; r < 6; r++) { x.fillStyle = '#26323e'; for (let i = 0; i < 9; i++) x.fillRect(6 + i * 13.5, 10 + r * 20.5, 8, 7); } });
  win.wrapS = win.wrapT = THREE.RepeatWrapping;
  const wMat = new THREE.MeshStandardMaterial({ map: win, roughness: 0.5 });
  const plain = new THREE.MeshStandardMaterial({ color: 0xf3f3ef, roughness: 0.55 });
  const blk = new THREE.Mesh(new THREE.BoxGeometry(11, 14, B - 5), [plain, wMat, plain, plain, wMat, wMat]); blk.position.set(xs + 10.5, 6.25 + 7, 0); g.add(blk);
  const brW = new THREE.MeshStandardMaterial({ color: 0x1e2a33, roughness: 0.2, metalness: 0.4 });
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(9, 3, B + 0.6), plain); bridge.position.set(xs + 11.5, 6.25 + 15.5, 0); g.add(bridge);
  const bwin = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.3, B - 1), brW); bwin.position.set(xs + 16.05, 6.25 + 15.9, 0); g.add(bwin);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(9.6, 0.4, B + 1.2), plain); roof.position.set(xs + 11.5, 6.25 + 17.2, 0); g.add(roof);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 5, 8), plain); mast.position.set(xs + 11.5, 6.25 + 19.6, 0); g.add(mast);
  const fun = new THREE.Mesh(new THREE.BoxGeometry(5, 7, 5.5), new THREE.MeshStandardMaterial({ color: 0xc8402c, roughness: 0.6 })); fun.position.set(xs + 5.2, 6.25 + 17.5, 0); g.add(fun);
  const funTop = new THREE.Mesh(new THREE.BoxGeometry(5.05, 1.4, 5.55), new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.8 })); funTop.position.set(xs + 5.2, 6.25 + 21.3, 0); g.add(funTop);
  // forecastle and a bow mast
  const fc = new THREE.Mesh(new THREE.BoxGeometry(10, 2.4, B * 0.62), dark); fc.position.set(xb - 13, 6.25 + 1.2, 0); g.add(fc);
  const fm = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.22, 8, 8), new THREE.MeshStandardMaterial({ color: 0xe0c040, roughness: 0.6 })); fm.position.set(xb - 12, 6.25 + 6.4, 0); g.add(fm);
  shadowAll(g);
  return g;
}

// ---------- mule: electric towing locomotive on the quay rails (+x forward) ----------
export function mule() {
  const g = new THREE.Group(); const M = canalMats();
  const body = new THREE.MeshStandardMaterial({ color: 0xb8bec4, roughness: 0.4, metalness: 0.5 });
  const b = new THREE.Mesh(new THREE.BoxGeometry(9, 2.2, 2.9), body); b.position.y = 1.5; g.add(b);
  const cab = new THREE.Mesh(new THREE.BoxGeometry(3, 1.8, 2.8), body); cab.position.set(2.2, 3.4, 0); g.add(cab);
  const cab2 = cab.clone(); cab2.position.x = -2.2; g.add(cab2);
  const glass = new THREE.MeshStandardMaterial({ color: 0x223040, roughness: 0.15, metalness: 0.5 });
  for (const x of [2.2, -2.2]) for (const z of [1.42, -1.42]) { const w = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.9, 0.05), glass); w.position.set(x, 3.6, z); g.add(w); }
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(9.05, 0.35, 2.95), new THREE.MeshStandardMaterial({ color: 0x1f4e9a, roughness: 0.5 })); stripe.position.y = 1.2; g.add(stripe);
  const winch = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 1.2, 14), M.dark); winch.position.set(0, 3.0, 0); g.add(winch);
  for (const x of [-3.2, 3.2]) for (const z of [-0.7, 0.7]) { const wh = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.25, 14), M.dark); wh.rotation.x = Math.PI / 2; wh.position.set(x, 0.42, z); g.add(wh); }
  shadowAll(g);
  return g;
}
// steel tow cable between two world points (a thin box stretched and aimed)
export function cable() {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1, 6), new THREE.MeshStandardMaterial({ color: 0x2a2a2a, roughness: 0.6 }));
  const up = new THREE.Vector3(0, 1, 0), a = new THREE.Vector3(), b = new THREE.Vector3(), d = new THREE.Vector3();
  m.set = (p, q) => { a.set(...p); b.set(...q); d.subVectors(b, a); const len = d.length(); m.scale.set(1, len, 1); m.position.copy(a).addScaledVector(d, 0.5); m.quaternion.setFromUnitVectors(up, d.normalize()); };
  return m;
}

// ---------- subway train (two cars), +x forward ----------
export function subwayTrain() {
  const g = new THREE.Group();
  const win = canvasTex(256, 64, (x) => { x.fillStyle = '#d7dde2'; x.fillRect(0, 0, 256, 64); x.fillStyle = '#1d5fae'; x.fillRect(0, 44, 256, 8); x.fillStyle = '#25303a'; for (let i = 0; i < 7; i++) x.fillRect(12 + i * 35, 12, 24, 20); });
  const wm = new THREE.MeshStandardMaterial({ map: win, roughness: 0.35, metalness: 0.4 });
  const plain = new THREE.MeshStandardMaterial({ color: 0xd7dde2, roughness: 0.35, metalness: 0.4 });
  for (let k = 0; k < 2; k++) {
    const car = new THREE.Mesh(new THREE.BoxGeometry(17, 3.5, 2.9), [plain, plain, plain, plain, wm, wm]);
    car.position.set(-k * 17.6, 1.95, 0); g.add(car);
    const roof = new THREE.Mesh(new THREE.CylinderGeometry(1.45, 1.45, 17, 16, 1, false, 0, Math.PI), plain); roof.rotation.z = Math.PI / 2; roof.rotation.x = -Math.PI / 2; roof.scale.set(1, 1, 0.22); roof.position.set(-k * 17.6, 3.7, 0);
    g.add(roof);
  }
  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.3, 2.0, 2.4), new THREE.MeshStandardMaterial({ color: 0x1d2a35, roughness: 0.2 })); nose.position.set(8.6, 2.6, 0); g.add(nose);
  const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.22, 10, 8), new THREE.MeshBasicMaterial({ color: 0xfff6d0 })); lamp.position.set(8.7, 1.2, 0.8); g.add(lamp); const l2 = lamp.clone(); l2.position.z = -0.8; g.add(l2);
  shadowAll(g);
  return g;
}

// ---------- Gatun Lake terrain: jungle hills, islands, a shallow muddy band that shows in a drought ----------
export function lakeTerrain(scene, { cx = 3 * L + 520, R0 = 430, seed = 6, treesN = 700 } = {}) {
  const R = rng(seed);
  const isl = []; for (let i = 0; i < 7; i++) { const a = R() * 6.28, d = 120 + R() * 220; isl.push([cx + Math.cos(a) * d, Math.sin(a) * d, 25 + R() * 45, 10 + R() * 16]); }
  const wob = []; for (let i = 0; i < 5; i++) wob.push([1 + Math.floor(R() * 6), R() * 6.28, 0.05 + R() * 0.08]);
  const height = (x, z) => {
    const dx = x - cx, dz = z, ang = Math.atan2(dz, dx), r = Math.hypot(dx, dz);
    let rr = R0; for (const [k, p, amp] of wob) rr *= 1 + amp * Math.sin(k * ang + p);
    let s = r - rr;                                                     // distance outside the shoreline
    if (x > 3 * L - 10 && x < cx) s = Math.min(s, Math.abs(z) - 95);    // channel from the locks
    if (x < 3 * L + 60) s = Math.max(s, Math.abs(z) - 66);              // land right beside the lock approach
    const n = 0.5 + 0.5 * Math.sin(x * 0.011 + z * 0.017) * Math.cos(z * 0.009 - x * 0.004);
    let h = LAKE + THREE.MathUtils.clamp(s * 0.075, -9, 2.5) + THREE.MathUtils.smoothstep(s, 25, 150) * (10 + 26 * n);
    for (const [ix, iz, ir, ih] of isl) { const d = Math.hypot(x - ix, z - iz); h = Math.max(h, LAKE + THREE.MathUtils.clamp((ir - d) * 0.09, -9, 2.5) + THREE.MathUtils.smoothstep(ir - d, 10, ir) * ih); }
    h += Math.sin(x * 0.07 + z * 0.05) * 0.5 + Math.sin(x * 0.19 - z * 0.13) * 0.25;
    // meet the flat land beside the lock approach (box tops at yT(3) - 0.3)
    if (Math.abs(z) > 50) h = Math.max(h, yT(3) - 0.3 - Math.max(0, x - (3 * L + 72)) * 0.1 - Math.max(0, 56 - Math.abs(z)) * 0.0);
    else h = Math.min(h, LAKE - 9);
    return h;
  };
  const N = 200, X0 = 3 * L + 70, X1 = cx + 900, Z0 = -950, Z1 = 950;
  const pos = [], col = [], idx = [];
  const jungle = new THREE.Color(0x3d6a2c), jungle2 = new THREE.Color(0x2c5224), mud = new THREE.Color(0x9a7a52), mudDry = new THREE.Color(0xb89868), sub = new THREE.Color(0x4a5a3a);
  for (let j = 0; j <= N; j++) for (let i = 0; i <= N; i++) {
    const x = X0 + (X1 - X0) * i / N, z = Z0 + (Z1 - Z0) * j / N, y = height(x, z);
    pos.push(x, y, z);
    let c;
    if (y > LAKE + 1.2) c = jungle.clone().lerp(jungle2, 0.5 + 0.5 * Math.sin(x * 0.05 + z * 0.08));
    else if (y > LAKE - 5) c = mudDry.clone().lerp(mud, THREE.MathUtils.smoothstep(y, LAKE + 1.2, LAKE - 4));
    else c = sub.clone();
    col.push(c.r, c.g, c.b);
  }
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const a = j * (N + 1) + i, b = a + N + 1; idx.push(a, b, a + 1, b, b + 1, a + 1); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); geo.setIndex(idx); geo.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 });
  // cracked-mud pattern on the exposed band
  mat.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWPt;').replace('#include <project_vertex>', '#include <project_vertex>\nvWPt = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWPt;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float band = smoothstep(${(LAKE + 1.3).toFixed(2)}, ${(LAKE + 0.4).toFixed(2)}, vWPt.y) * smoothstep(${(LAKE - 6).toFixed(2)}, ${(LAKE - 3).toFixed(2)}, vWPt.y);
      vec2 cq = vWPt.xz * 0.9; vec2 ci = floor(cq); vec2 cf = fract(cq); float md = 9.0;
      for (int a = -1; a <= 1; a++) for (int b = -1; b <= 1; b++) { vec2 o = vec2(float(a), float(b)); vec2 pp = o + vec2(hash12(ci + o), hash12(ci + o + 7.3)) - cf; md = min(md, dot(pp, pp)); }
      float md2 = 9.0; for (int a = -1; a <= 1; a++) for (int b = -1; b <= 1; b++) { vec2 o = vec2(float(a), float(b)); vec2 pp = o + vec2(hash12(ci + o), hash12(ci + o + 7.3)) - cf; float d = dot(pp, pp); if (d > md + 0.0001) md2 = min(md2, d); }
      float crack = 1.0 - smoothstep(0.0, 0.05, sqrt(md2) - sqrt(md));
      diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * 0.45, crack * band * 0.8);
      diffuseColor.rgb *= 0.88 + 0.24 * fbm(vWPt.xz * 0.05);`);
  };
  const mesh = new THREE.Mesh(geo, mat); mesh.receiveShadow = true; scene.add(mesh);
  // jungle trees on the higher ground; drowned dead stumps on the shallow band (Gatun Lake really has these)
  const spots = [], stumps = [];
  for (let k = 0; k < treesN * 6 && spots.length < treesN; k++) {
    const x = X0 + R() * (X1 - X0), z = Z0 + R() * (Z1 - Z0), y = height(x, z);
    if (y > LAKE + 2.5 && Math.hypot(x - cx, z) < 800) spots.push([x, y - 0.5, z]);
  }
  for (let k = 0; k < 6000 && stumps.length < 140; k++) {
    const x = X0 + 40 + R() * 700, z = -500 + R() * 1000, y = height(x, z);
    if (y > LAKE - 4.5 && y < LAKE + 0.8) stumps.push([x, y, z]);
  }
  const tr = trees(spots, { seed: 12, scale: 4.2 }); scene.add(tr);
  const stM = new THREE.MeshStandardMaterial({ color: 0x6e6255, roughness: 1 });
  const st = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.35, 0.6, 1, 6), stM, stumps.length);
  const mm = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
  stumps.forEach(([x, y, z], i) => { const h = 3 + R() * 6; e.set((R() - 0.5) * 0.25, 0, (R() - 0.5) * 0.25); q.setFromEuler(e); mm.compose(new THREE.Vector3(x, y + h / 2 - 0.5, z), q, new THREE.Vector3(1, h, 1)); st.setMatrixAt(i, mm); });
  st.castShadow = true; scene.add(st);
  const hills = mountains({ center: [cx - 200, LAKE - 4, 0], rMin: 950, rMax: 1700, peaks: 50, height: 110, seed: 8, color: 0x3f6b37 });
  scene.add(hills);
  return { mesh, height, trees: tr, stumps: st, cx, R0 };
}

// ---------- drought set: a controlled lake shore (gentle mud slope with stumps, jungle above), shoreline at z = 0 for normal level ----------
export function droughtShore(scene, { drop = 4.2 } = {}) {
  const R = rng(17);
  const h = (x, z) => {
    const w = Math.sin(x * 0.012) * 18 + Math.sin(x * 0.031 + 1) * 7;      // wavy shoreline
    const s = -z - w;                                                       // > 0 on land (shore toward -z)
    let y = LAKE + THREE.MathUtils.clamp(s * 0.07, -12, 3) + THREE.MathUtils.smoothstep(s, 40, 220) * (14 + 30 * (0.5 + 0.5 * Math.sin(x * 0.009)));
    y += Math.sin(x * 0.07 - z * 0.05) * 0.3;
    return y;
  };
  const N = 220, X0 = -700, X1 = 700, Z0 = -600, Z1 = 500;
  const pos = [], col = [], idx = [];
  const jungle = new THREE.Color(0x3d6a2c), jungle2 = new THREE.Color(0x2c5224), mud = new THREE.Color(0x8a6a44), mudDry = new THREE.Color(0xb39566), sub = new THREE.Color(0x4a5a3a);
  for (let j = 0; j <= N; j++) for (let i = 0; i <= N; i++) {
    const x = X0 + (X1 - X0) * i / N, z = Z0 + (Z1 - Z0) * j / N, y = h(x, z);
    pos.push(x, y, z);
    const c = y > LAKE + 1.6 ? jungle.clone().lerp(jungle2, 0.5 + 0.5 * Math.sin(x * 0.05 + z * 0.08)) : y > LAKE - drop - 1 ? mudDry.clone().lerp(mud, THREE.MathUtils.smoothstep(y, LAKE + 1.5, LAKE - drop)) : sub.clone();
    col.push(c.r, c.g, c.b);
  }
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { const a = j * (N + 1) + i, b = a + N + 1; idx.push(a, b, a + 1, b, b + 1, a + 1); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); geo.setIndex(idx); geo.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 });
  mat.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWPt;').replace('#include <project_vertex>', '#include <project_vertex>\nvWPt = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWPt;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float band = smoothstep(${(LAKE + 1.6).toFixed(2)}, ${(LAKE + 0.8).toFixed(2)}, vWPt.y);
      vec2 cq = vWPt.xz * 0.45; vec2 ci = floor(cq); vec2 cf = fract(cq); float md = 9.0, md2 = 9.0;
      for (int a = -1; a <= 1; a++) for (int b = -1; b <= 1; b++) { vec2 o = vec2(float(a), float(b)); vec2 pp = o + vec2(hash12(ci + o), hash12(ci + o + 7.3)) - cf; float d = dot(pp, pp); if (d < md) { md2 = md; md = d; } else md2 = min(md2, d); }
      float crack = 1.0 - smoothstep(0.0, 0.06, sqrt(md2) - sqrt(md));
      diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * 0.42, crack * band * 0.85);
      diffuseColor.rgb *= 0.88 + 0.24 * fbm(vWPt.xz * 0.05);`);
  };
  const mesh = new THREE.Mesh(geo, mat); mesh.receiveShadow = true; scene.add(mesh);
  const spots = [], stumps = [];
  for (let k = 0; k < 20000 && spots.length < 900; k++) { const x = X0 + R() * (X1 - X0), z = Z0 + R() * (Z1 - Z0), y = h(x, z); if (y > LAKE + 3) spots.push([x, y - 0.4, z]); }
  for (let k = 0; k < 20000 && stumps.length < 120; k++) { const x = -350 + R() * 700, z = -120 + R() * 200, y = h(x, z); if (y > LAKE - drop - 2.5 && y < LAKE + 0.5) stumps.push([x, y, z]); }
  scene.add(trees(spots, { seed: 12, scale: 4.2 }));
  const st = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.4, 0.7, 1, 6), new THREE.MeshStandardMaterial({ color: 0x6e6255, roughness: 1 }), stumps.length);
  const mm = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
  stumps.forEach(([x, y, z], i) => { const hh = 3 + R() * 7; e.set((R() - 0.5) * 0.25, 0, (R() - 0.5) * 0.25); q.setFromEuler(e); mm.compose(new THREE.Vector3(x, y + hh / 2 - 0.6, z), q, new THREE.Vector3(1, hh, 1)); st.setMatrixAt(i, mm); });
  st.castShadow = true; scene.add(st);
  const water = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), canalWater({ color: 0x2c6a5c })); water.rotation.x = -Math.PI / 2; water.position.y = LAKE - drop; water.receiveShadow = true; scene.add(water);
  // (distant mountain ring removed: its rim showed as a black arc over the shore hill)
  return { height: h, water };
}
