// Zhang Heng seismoscope reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite, sparks } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { soldier, scholar, hills, southArrow } from './chariot.js';
import { seismoscope, hanHall, courtyard, ringWave } from './seis.js';
import { VO } from './vo_zh.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If the *ground shook*', 4], ['*hundreds of kilometers*', 3], ['away', 1], ['could you *know*', 3], ['without *feeling*', 2], ['a thing', 2]],
  [['But almost', 2], ['*2,000 years* ago', 4], ['one *Chinese machine*', 3], ['*could*', 1]],
  [['In the year', 3], ['*132*', 3], ['an *astronomer*', 2], ['named *Zhang Heng*', 3], ['built a huge', 3], ['*bronze jar*', 2]],
  [['*Eight dragons*', 2], ['circled the outside', 3], ['each holding', 2], ['a *bronze ball*', 3], ['in its *mouth*', 3]],
  [['Below each dragon', 3], ['sat a *toad*', 3], ['with its mouth', 3], ['*wide open*', 2]],
  [['When an *earthquake wave*', 4], ['arrived', 1], ['something inside', 2], ['the jar *swung*', 3]],
  [['Historians think', 2], ['it was a', 3], ['*heavy pendulum*', 2]],
  [['It tipped a *lever*', 4], ['and one dragon', 3], ['*dropped its ball*', 3], ['into the *toad* below', 4], ['with a *loud clang*', 4]],
  [['Which dragon', 2], ['dropped it', 2], ['hinted at', 2], ["the quake's *direction*", 3]],
  [['Records say', 2], ['that in *138*', 5], ['the *western dragon*', 3], ['dropped a ball', 3], ['but *nobody*', 2], ['in the capital', 3], ['*felt a thing*', 3]],
  [['*Days later*', 2], ['a *messenger* arrived', 3], ['There had been', 3], ['an *earthquake*', 2], ['far to the *west*', 4], ['in *Longxi*', 2]],
  [['No *original*', 2], ['*survives*', 1], ['and the design', 3], ['inside is still', 3], ['a *mystery*', 2]],
  [['*Modern teams*', 2], ['have built *replicas*', 3], ['from the *old descriptions*', 4]],
  [['An *early warning*', 3], ['*system*', 1], ['made of *bronze*', 3], ['*dragons* and *toads*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
const WEST = 6; // dragon index facing -x (west); i*45deg from +z

function hall(makeStage, { sunDir = [-1, 4, 3], sun = 2.2 } = {}) {
  const scene = makeStage({ shadowSize: 3.5, sunDir, sun });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a1a12); u.mid.value.set(0x3a2418); u.horizon.value.set(0x4a3020); u.floorC.value.set(0x20140c);
  hanHall(scene);
  const lamp = new THREE.PointLight(0xffb060, 3, 8, 1.6); lamp.position.set(1.8, 2.6, 2.2); scene.add(lamp);
  return scene;
}
function yard(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.6, 0.4, 0.7], fog: 0.004, shadowSize: 6, envI: 0.95, ...opts });
  courtyard(scene); fillLight(scene, [0.3, 0.4, 1], 0.5, 0xffe6c8);
  return scene;
}

// ============ S0: a quake far away: rings spread across the hills toward a distant city ============
function sHook({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.5, 0.6], fog: 0.0025, shadowSize: 20, envI: 0.9 });
  hills(scene, { seed: 2 });
  const rings = [0, 1, 2, 3].map(() => { const r = ringWave(); r.position.set(-60, 0.2, -40); scene.add(r); return r; });
  const rocks = [...Array(14)].map((_, i) => { const r = new THREE.Mesh(new THREE.DodecahedronGeometry(0.8 + (i % 3) * 0.4, 0), new THREE.MeshStandardMaterial({ color: 0x7a6a5a, roughness: 1 })); r.castShadow = true; scene.add(r); return r; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      rings.forEach((r, i) => { const u = (t * 0.35 + i * 0.25) % 1; r.set(5 + u * 110, 0.85 * (1 - u)); });
      rocks.forEach((r, i) => { const u = ((t * 0.5 + i * 0.07) % 1); r.position.set(-60 + Math.sin(i * 2) * 8, 18 - u * 18, -40 + Math.cos(i * 3) * 6 + u * 10); r.rotation.set(u * 6 + i, u * 4, 0); });
      const s = shake(t, 3, 1);
      const k = easeInOut(range(t, 0, 5.8));
      place(c, [lerp(30, 20, k) + s[0], lerp(28, 22, k) + s[1], lerp(60, 48, k)], [-30, 4, -20]);
      return { bloom: 0.5, warm: 1.1 };
    },
  };
}
// ============ S1: reveal: the bronze machine in a dark hall ============
function sReveal({ makeStage }) {
  const scene = hall(makeStage);
  const S = seismoscope(); scene.add(S);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(0.6, 1.4, k), lerp(0.6, 2.0, k), lerp(3.5, 5.6, k)], [0, lerp(1.6, 1.3, k), 0]);
      return { bloom: 0.55, warm: 1.25 };
    },
  };
}
// ============ S2: Zhang Heng beside his instrument ============
function sZhang({ makeStage }) {
  const scene = hall(makeStage);
  const S = seismoscope(); S.position.x = 0.7; scene.add(S);
  const Z = scholar(); Z.root.position.set(-1.1, 0, 1.0); Z.root.rotation.y = 0.6; scene.add(Z.root);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standPose(Z, t, { rSh: [-0.8, 0, -0.5], rEl: [-0.4, 0, 0], head: [0.05, 0.4, 0] }); Z.setMood('happy'); Z.setMouth(0); Z.blink(blinkK(t, [1.4, 4.2]));
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(-0.4, -0.1, k), lerp(1.9, 1.8, k), lerp(10.5, 9.5, k)], [-0.2, 1.2, 0]);
      return { bloom: 0.5, warm: 1.25 };
    },
  };
}
// ============ S3: eight dragons, orbit around the top ============
function sDragons({ makeStage }) {
  const scene = hall(makeStage);
  const S = seismoscope(); scene.add(S);
  const balls = S.dragons.map(d => { const g = glowSprite(0xffe080, 0.25); d.ball.add(g); return g; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      balls.forEach((g, i) => { g.material.opacity = 0.4 + 0.3 * Math.sin(t * 3 + i); });
      const a = lerp(0.3, 1.5, easeInOut(range(t, 0, 5)));
      place(c, [Math.sin(a) * 3.2, 2.6, Math.cos(a) * 3.2], [0, 1.6, 0]);
      return { bloom: 0.6, warm: 1.25 };
    },
  };
}
// ============ S4: a toad, mouth open, below its dragon ============
function sToad({ makeStage }) {
  const scene = hall(makeStage);
  const S = seismoscope(); scene.add(S);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.8));
      place(c, [lerp(1.5, 1.1, k), lerp(1.0, 0.85, k), lerp(2.9, 2.5, k)], [0, lerp(0.35, 0.5, k), 1.3]);
      return { bloom: 0.55, warm: 1.25 };
    },
  };
}
// ============ S5/S6: a wave arrives; cut-away: the pendulum swings ============
function sWave({ makeStage, start: ST }) {
  const tS = at(5, 'swung') - ST;
  const scene = hall(makeStage);
  const S = seismoscope({ cutaway: false }); scene.add(S);
  const ring = ringWave(0xffb040); ring.position.y = 0.02; scene.add(ring);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const u = range(t, 0.2, 2.4); ring.set(lerp(9, 0.3, u), u < 1 ? 0.9 : 0); ring.position.x = lerp(-0.0, 0, u);
      S.cut(easeInOut(range(t, tS - 0.9, tS - 0.2)));
      const sw = easeOut(range(t, tS - 0.5, tS)) * Math.sin((t - tS) * 5) * 0.25; S.swing(0, sw);
      const sh = shake(t, Math.max(0, 1 - Math.abs(t - 2.2)) * 4, 2); S.position.set(sh[0] * 0.5, 0, 0);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(3.0, 2.2, k), lerp(2.6, 1.8, k), lerp(5.0, 3.8, k)], [0, 1.0, 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
function sPend({ makeStage }) {
  const scene = hall(makeStage);
  const S = seismoscope({ cutaway: true }); scene.add(S);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      S.swing(0, Math.sin(t * 4) * 0.22);
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(0.4, 0.2, k), lerp(1.4, 1.2, k), lerp(3.2, 2.6, k)], [0, 1.1, 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S7: the lever tips, the ball drops into the toad: clang ============
function sDrop({ makeStage, start: ST }) {
  const tD = at(7, 'dropped') - ST, tC = at(7, 'clang') - ST;
  const scene = hall(makeStage);
  const S = seismoscope(); scene.add(S);
  const sp = sparks(50, { speed: 1.5, spread: 1.4, life: 0.4, size: 0.03, dir: V(0, 1, 0) }); scene.add(sp);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const u = range(t, tD - 0.1, tC); S.drop(0, u);
      scene.updateMatrixWorld(true); const mp = S.toads[0].localToWorld(S.toads[0].mouthPos.clone()); sp.position.copy(mp); sp.update(t - tC);
      const s = shake(t, Math.max(0, 1 - Math.abs(t - tC) * 4) * 5, 4);
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(1.6, 1.2, k) + s[0], lerp(1.6, 1.2, k) + s[1], lerp(3.6, 3.0, k)], [0, lerp(1.3, 0.8, easeInOut(range(t, tD, tC))), 1.2]);
      return { bloom: 0.65, warm: 1.25 };
    },
  };
}
// ============ S8: top view: the empty dragon points the way ============
function sDir({ makeStage }) {
  const scene = hall(makeStage, { sunDir: [-1, 6, 2] });
  const S = seismoscope(); scene.add(S); S.drop(WEST, 1.0);
  const ar = southArrow(3, 0xffd43b); ar.rotation.y = -Math.PI / 2; ar.position.set(-1.4, 0.15, 0); scene.add(ar);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      ar.scale.setScalar(easeOut(range(t, 0.4, 1.4)) + 0.001);
      place(c, [-0.8, lerp(8.5, 9.5, easeInOut(range(t, 0, 3.4))), 1.6], [-0.8, 0, 0]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
// ============ S9: 138 AD: the western dragon drops a ball; the court feels nothing ============
function sCourt({ makeStage, start: ST }) {
  const tW = at(9, 'western') - ST;
  const scene = yard(makeStage);
  const S = seismoscope(); S.rotation.y = -Math.PI / 2 + 0.5; scene.add(S);
  const men = [scholar(), soldier(0), soldier(1)]; men.forEach(e => scene.add(e.root));
  men[0].root.position.set(2.2, 0, 1.2); men[0].root.rotation.y = -0.8; men[1].root.position.set(-2.6, 0, 0.8); men[1].root.rotation.y = 0.5; men[2].root.position.set(3.2, 0, -1.2); men[2].root.rotation.y = -0.4;
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      S.drop(WEST, range(t, tW + 0.2, tW + 1.0));
      men.forEach((e, i) => { const look = i === 0 ? easeInOut(range(t, tW + 1.0, tW + 1.6)) : 0; standPose(e, t + i, { head: [0, -look * 0.7, 0] }); e.setMood('happy'); e.setMouth(0); e.blink(blinkK(t + i, [1.0, 3.6, 6.0])); });
      const k = easeInOut(range(t, 0, 7));
      place(c, [lerp(1.5, 0.5, k), lerp(2.6, 2.2, k), lerp(9.5, 8.0, k)], [0, 1.2, 0]);
      return { bloom: 0.55, flare: 0.7, warm: 1.3 };
    },
  };
}
// ============ S10: days later a messenger runs in ============
function sRunner({ makeStage, start: ST }) {
  const scene = yard(makeStage, { sunDir: [-0.6, 0.45, 0.6] });
  const S = seismoscope(); S.position.set(-3, 0, -2.5); scene.add(S);
  const R = soldier(2); scene.add(R.root);
  const Z = scholar(); Z.root.position.set(0.8, 0, -1); scene.add(Z.root);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const stop = Math.min(t, 3.6); const z = 9 - stop * 2.3; R.root.position.set(0.2, 0, z); R.root.rotation.y = Math.PI;
      const w = t < 3.6 ? Math.sin(t * 11) : 0;
      standPose(R, t, { spine: [0.25 * (t < 3.6 ? 1 : 0.3), 0, 0], lHip: [w * 0.7, 0, 0.06], rHip: [-w * 0.7, 0, -0.06], lKn: [Math.max(0, -w) * 0.9, 0, 0], rKn: [Math.max(0, w) * 0.9, 0, 0], lSh: [-w * 0.6, 0, 0.12], rSh: [w * 0.6, 0, -0.12] }); R.setMood('happy'); R.setMouth(0);
      standPose(Z, t, { head: [0, 0.2, 0], rSh: [-0.5, 0, -0.3] }); Z.root.rotation.y = 0.2; Z.setMood('happy'); Z.setMouth(0);
      const k = easeInOut(range(t, 0, 5.6));
      place(c, [lerp(3.5, 3.0, k), lerp(2.2, 1.9, k), lerp(4.5, 3.6, k)], [0, 1.2, lerp(3, -0.5, k)]);
      return { bloom: 0.55, flare: 0.6, warm: 1.25 };
    },
  };
}
// ============ S11: the inside is a mystery: cut-away flickers with glowing guesses ============
function sMystery({ makeStage }) {
  const scene = hall(makeStage, { sun: 1.0 });
  const S = seismoscope({ cutaway: true }); scene.add(S);
  const q = glowSprite(0x8ad0ff, 1.6); q.position.y = 1.0; scene.add(q);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      S.swing(Math.sin(t * 2.3) * 0.15, Math.sin(t * 3.1) * 0.15); S.cut(0.6 + 0.4 * Math.sin(t * 2) * 0.5 + 0.2);
      q.material.opacity = 0.35 + 0.2 * Math.sin(t * 4);
      const a = lerp(-0.4, 0.4, easeInOut(range(t, 0, 4.4)));
      place(c, [Math.sin(a) * 4.2, 1.6, Math.cos(a) * 4.2], [0, 1.1, 0]);
      return { bloom: 0.7, warm: 1.0 };
    },
  };
}
// ============ S12: a modern replica in a museum ============
function sReplica({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [0.5, 4, 1.5], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x101418); u.mid.value.set(0x181e26); u.horizon.value.set(0x222a34); u.floorC.value.set(0x0c1014);
  const S = seismoscope(); S.scale.setScalar(0.8); scene.add(S);
  const spot = new THREE.SpotLight(0xfff0d8, 14, 8, 0.55, 0.5, 1.5); spot.position.set(1, 5, 3); spot.target.position.set(0, 1, 0); spot.castShadow = true; scene.add(spot, spot.target);
  const visitor = scholar(); visitor.root.position.set(1.9, 0, 1.6); visitor.root.rotation.y = -2.3; scene.add(visitor.root);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standPose(visitor, t, { head: [0.15, 0, 0] }); visitor.setMood('happy'); visitor.setMouth(0);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-1.5, -1.0, k), lerp(1.6, 1.5, k), lerp(5.5, 4.6, k)], [0.3, 1.0, 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
// ============ S13: sunset in the courtyard ============
function sEnd({ makeStage }) {
  const scene = yard(makeStage, { sunDir: [0.75, 0.13, -0.6] });
  const S = seismoscope(); scene.add(S);
  const b = birds(4, { from: [-20, 10, -20], to: [20, 12, -26], spread: 4, speed: 0.06, scale: 1.4, seed: 7 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.5));
      place(c, [lerp(1.2, 2.5, k), lerp(1.4, 3.0, k), lerp(4.0, 8.5, k)], [0, lerp(1.4, 1.6, k), 0]);
      return { bloom: 0.7, flare: 1.0, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sReveal], [ls(2), ls(3), sZhang], [ls(3), ls(4), sDragons], [ls(4), ls(5), sToad],
  [ls(5), ls(6), sWave], [ls(6), ls(7), sPend], [ls(7), ls(8), sDrop], [ls(8), ls(9), sDir], [ls(9), ls(10), sCourt],
  [ls(10), ls(11), sRunner], [ls(11), ls(12), sMystery], [ls(12), ls(13), sReplica], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
