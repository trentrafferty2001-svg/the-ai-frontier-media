// Hero of Alexandria's temple doors reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { fabricTexture } from './textures.js';
import { greek, medLand } from './classic.js';
import { gearScroll } from './chariot.js';
import { rig, aeolipile, vending, heronMats } from './heron.js';
import { VO } from './vo_hd.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Imagine *lighting a fire*', 4], ['on an *altar*', 3], ['and watching', 2], ['the heavy *temple doors*', 4], ['*swing open*', 2], ['by *themselves*', 2]],
  [["But this wasn't *magic*", 4], ['It was *air*', 3], ['*water* and *rope*', 3]],
  [['About *2,000 years* ago', 5], ['an *engineer*', 2], ['named *Hero*', 2], ['of *Alexandria*', 2], ['described it', 2]],
  [['The altar', 2], ['was *hollow*', 2], ['and *sealed*', 2], ['like a *box*', 3]],
  [['As the *fire* burned', 4], ['the *air* inside', 3], ['*heated up*', 2], ['and *expanded*', 2]],
  [['That air *pushed water*', 4], ['out of a *hidden tank*', 5], ['through a *pipe*', 3], ['and into a *bucket*', 4]],
  [['The bucket', 2], ['got *heavier*', 2], ['and *sank*', 2]],
  [['*Ropes* from the bucket', 4], ['were *wound around*', 3], ['the *door posts*', 3], ['so as it dropped', 4], ['the doors', 2], ['*turned open*', 2]],
  [['When the *fire went out*', 5], ['the air *cooled*', 3], ['and the water', 3], ['was *drawn back*', 3]],
  [['The bucket *rose*', 3], ['and a *counterweight*', 3], ['pulled the doors', 3], ['*shut again*', 2]],
  [['To the *crowd*', 3], ['it looked like', 3], ['the *gods*', 2], ['had opened', 2], ['their own *temple*', 3]],
  [["We *don't know*", 3], ['if any temple', 3], ['*really built one*', 3]],
  [['But Hero also', 3], ['described a', 2], ['*spinning steam ball*', 3], ['and a', 2], ['*coin operated*', 2], ['*holy water machine*', 3]],
  [['*2,000 years* ago', 4], ['he was already', 3], ['dreaming up', 2], ['*automatic machines*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

function site(makeStage, { preset = 'golden', sunDir = [0.6, 0.35, 0.7], cut = false } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog: 0.004, shadowSize: 9, shadowAt: [0, 1, 1], envI: 0.95 });
  if (!cut) medLand(scene, { y: -0.31, seed: 3, groundC: 0xb8a878 });
  const R = rig(); R.cut(cut); scene.add(R);
  fillLight(scene, [0.3, 0.4, 1], 0.6, 0xffe6c8);
  return { scene, R };
}
function underground(makeStage) {
  const scene = makeStage({ shadowSize: 6, sunDir: [3, 6, 5], sun: 2.0 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x3a5070); u.mid.value.set(0x5a6a80); u.horizon.value.set(0x8a7a6a); u.floorC.value.set(0x3a2a20);
  const R = rig(); R.cut(true); scene.add(R);
  fillLight(scene, [0.5, 0.3, 1], 0.9, 0xfff0e0);
  return { scene, R };
}
function crowd(scene, n = 6) { return [...Array(n)].map((_, i) => { const e = greek({ color: [0xf2ede0, 0xd8c8a8, 0xe8d0b0, 0xc8d0e0][i % 4], beard: i % 2 === 0, skin: [0xd8a07a, 0xc08860, 0xe0b090][i % 3] }); e.root.position.set((i % 3 - 1) * 1.2 + (i > 2 ? 0.5 : 0), 0, 5.6 + Math.floor(i / 3) * 1.3); e.root.rotation.y = Math.PI; scene.add(e.root); return e; }); }

// ============ S0: a priest lights the altar; the temple doors swing open by themselves ============
function sHook({ makeStage, start: ST }) {
  const tO = at(0, 'swing') - ST;
  const { scene, R } = site(makeStage, { sunDir: [-0.6, 0.18, 0.75] });
  const ppl = crowd(scene);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const f = easeOut(range(t, 0.6, 1.6)); R.set(easeInOut(range(t, tO - 0.8, tO + 1.6)), f, t);
      ppl.forEach((e, i) => { standPose(e, t + i, { head: [0.1, 0, 0] }); e.setMood('happy'); e.setMouth(0); });
      const k = easeInOut(range(t, 0, 6));
      place(c, [lerp(1.5, 0.8, k), lerp(2.4, 2.1, k), lerp(12, 9.5, k)], [0, 2.0, 0]);
      return { bloom: 0.65, flare: 0.6, warm: 1.35 };
    },
  };
}
// ============ S1: not magic: the ground turns see-through, showing the machine ============
function sReveal({ makeStage }) {
  const { scene, R } = underground(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      R.set(0.5, 1, t);
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(0.5, 2.5, k), lerp(3.5, 0.0, k), lerp(14, 15.5, k)], [0.5, lerp(1.5, -1.2, k), 0]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S2: Hero of Alexandria with his writings ============
function sHero({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [-1, 3, 2], sun: 2.0 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a2016); u.mid.value.set(0x3a2a1c); u.horizon.value.set(0x4a3624); u.floorC.value.set(0x20160e);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0x8a7a64, roughness: 0.9 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const table = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.08, 1.0), new THREE.MeshStandardMaterial({ color: 0x6a4428, roughness: 0.7 })); table.position.set(0.3, 0.9, 0); table.castShadow = table.receiveShadow = true; scene.add(table);
  const sc = gearScroll(); sc.scale.setScalar(0.8); sc.position.set(0.3, 0.95, 0); scene.add(sc);
  const A = aeolipile(); A.scale.setScalar(0.35); A.position.set(0.95, 0.94, -0.25); scene.add(A);
  const H = greek({ beard: true }); H.root.position.set(-0.8, 0, -0.1); H.root.rotation.y = 0.9; scene.add(H.root);
  const lamp = new THREE.PointLight(0xffb060, 2.5, 4, 2); lamp.position.set(0.3, 1.6, 0.8); scene.add(lamp);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      A.spin(t * 4, t);
      standPose(H, t, { spine: [0.2, 0, 0], head: [0.3, 0.2, 0], rSh: [-0.7, 0, -0.3], rEl: [-0.6, 0, 0] }); H.setMood('happy'); H.setMouth(0); H.blink(blinkK(t, [1.5, 4.0]));
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(0.6, 0.3, k), lerp(1.8, 1.7, k), lerp(3.6, 3.0, k)], [-0.1, 1.2, 0]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S3/S4: the hollow, sealed altar; the fire heats the air inside ============
function seeThroughAltar(R) { R.altar.children[0].material = new THREE.MeshPhysicalMaterial({ color: 0xe8dfcc, roughness: 0.3, transparent: true, opacity: 0.35, depthWrite: false }); }
function sAltar({ makeStage }) {
  const { scene, R } = underground(makeStage); seeThroughAltar(R);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      R.set(0, 0, t);
      const k = easeInOut(range(t, 0, 3));
      place(c, [lerp(2.8, 2.4, k), lerp(1.9, 1.6, k), lerp(7.4, 6.6, k)], [0, 0.6, 2.6]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
function sHeat({ makeStage }) {
  const { scene, R } = underground(makeStage); seeThroughAltar(R);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      R.set(0, easeOut(range(t, 0.2, 1.4)), t);
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(2.4, 2.6, k), lerp(1.6, 0.2, k), lerp(6.6, 8.0, k)], [lerp(0.3, 1.0, k), lerp(0.6, -0.7, k), 2.5]);
      return { bloom: 0.7, warm: 1.2 };
    },
  };
}
// ============ S5/S6: water pushed from the tank into the bucket; the bucket sinks ============
function sPush({ makeStage }) {
  const { scene, R } = underground(makeStage);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.set(lerp(0, 0.45, easeInOut(range(t, 0.3, 4.6))), 1, t);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(2.6, 3.4, k), lerp(-1.2, -1.8, k), lerp(9.5, 9.0, k)], [lerp(2.0, 3.0, k), lerp(-1.3, -2.0, k), lerp(2.0, 1.0, k)]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
function sSink({ makeStage }) {
  const { scene, R } = underground(makeStage);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      R.set(lerp(0.45, 0.75, easeInOut(range(t, 0.1, 2.4))), 1, t);
      place(c, [4.4, -2.4, 5.2], [3.6, lerp(-2.6, -3.0, easeInOut(range(t, 0, 2.4))), -0.3]);
      return { bloom: 0.5, warm: 1.1 };
    },
  };
}
// ============ S7: ropes round the door posts: the doors turn open ============
function sTurn({ makeStage }) {
  const { scene, R } = underground(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      R.set(lerp(0.75, 1, easeInOut(range(t, 0.2, 5))), 1, t);
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(3, 1.5, k), lerp(0.5, 3.0, k), lerp(14, 13, k)], [0.5, lerp(-1.6, 1.4, k), -0.3]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S8/S9: the fire dies, water flows back, the counterweight shuts the doors ============
function sCool({ makeStage }) {
  const { scene, R } = underground(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const f = 1 - easeInOut(range(t, 0.2, 1.4)); R.set(lerp(1, 0.55, easeInOut(range(t, 1.2, 4.6))), f, t);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(1.5, 3.0, k), lerp(1.0, -0.8, k), lerp(9.5, 10, k)], [lerp(0.8, 2.4, k), lerp(0.2, -1.8, k), lerp(2, 1.0, k)]);
      return { bloom: 0.5, warm: lerp(1.15, 0.95, 1 - f) };
    },
  };
}
function sShut({ makeStage, start: ST }) {
  const { scene, R } = underground(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      R.set(lerp(0.55, 0, easeInOut(range(t, 0.2, 3.8))), 0, t);
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(-3, 0, k), lerp(-1.5, 2.5, k), lerp(10, 13, k)], [lerp(-2.4, 0, k), lerp(-2.6, 1.4, k), lerp(-0.3, 0, k)]);
      return { bloom: 0.5, warm: 1.0 };
    },
  };
}
// ============ S10: the crowd sees the doors open to the glowing god ============
function sCrowd({ makeStage }) {
  const { scene, R } = site(makeStage, { sunDir: [-0.6, 0.18, 0.75] });
  const ppl = crowd(scene, 6);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.set(1, 1, t);
      ppl.forEach((e, i) => { standPose(e, t + i, { lSh: [-1.6, 0, 0.5], rSh: [-1.6, 0, -0.5], head: [-0.2, 0, 0] }); e.setMood('happy'); e.setMouth(0.6); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(4.5, 4.0, k), lerp(1.6, 1.8, k), lerp(8.5, 8.0, k)], [lerp(-0.5, -1.0, k), 1.9, lerp(3.5, 2.5, k)]);
      return { bloom: 0.65, flare: 0.5, warm: 1.35 };
    },
  };
}
// ============ S11: we don't know if any was built: the temple in fading light ============
function sUnknown({ makeStage }) {
  const { scene, R } = site(makeStage, { preset: 'golden', sunDir: [0.7, 0.08, -0.7] });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.set(0, 0, t);
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-6, -4, k), lerp(3, 2.6, k), lerp(14, 11, k)], [0, 2.6, 0]);
      return { bloom: 0.6, flare: 1.0, warm: 1.2, sat: 0.9 };
    },
  };
}
// ============ S12: the steam ball, then the coin-operated holy-water machine ============
function sOther({ makeStage, start: ST }) {
  const tC = at(12, 'coin') - ST;
  const scene = makeStage({ shadowSize: 2, sunDir: [-1, 3, 2], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a2016); u.mid.value.set(0x3a2a1c); u.horizon.value.set(0x4a3624); u.floorC.value.set(0x20160e);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0x8a7a64, roughness: 0.9 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const A = aeolipile(); A.position.set(-1.0, 0, 0); scene.add(A);
  const Vm = vending(); Vm.position.set(1.0, 0, 0); scene.add(Vm);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      A.spin(t * 6, t); Vm.set(range(t, tC + 0.1, tC + 1.6));
      const x = lerp(-1.0, 1.0, easeInOut(range(t, tC - 0.8, tC)));
      place(c, [x + 0.3, 1.6, 3.4], [x, 1.1, 0]);
      return { bloom: 0.6, warm: 1.25 };
    },
  };
}
// ============ S13: sunset, the doors open, camera pulls back ============
function sEnd({ makeStage }) {
  const { scene, R } = site(makeStage, { sunDir: [-0.6, 0.12, 0.75] });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.set(1, 1, t);
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(0.5, 3, k), lerp(1.8, 4.5, k), lerp(7, 17, k)], [0, lerp(2.2, 2.8, k), 0]);
      return { bloom: 0.7, flare: 0.9, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sReveal], [ls(2), ls(3), sHero], [ls(3), ls(4), sAltar], [ls(4), ls(5), sHeat],
  [ls(5), ls(6), sPush], [ls(6), ls(7), sSink], [ls(7), ls(8), sTurn], [ls(8), ls(9), sCool], [ls(9), ls(10), sShut],
  [ls(10), ls(11), sCrowd], [ls(11), ls(12), sUnknown], [ls(12), ls(13), sOther], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
