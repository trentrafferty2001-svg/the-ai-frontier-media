// Lycurgus Cup reel: the dichroic cage cup, museum plinth, Roman glass workshop, electron microscope, nano specks, sensor chip.
import * as THREE from 'three';
import { fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { glowSprite } from './props.js';

const rng = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const V = (x, y, z) => new THREE.Vector3(x, y, z);

// ---------- dichroic glass: jade green in reflected light, ruby red when lit from inside ----------
export function dichroicMat() {
  const m = new THREE.MeshPhysicalMaterial({ color: 0x7a9a58, roughness: 0.22, clearcoat: 1, clearcoatRoughness: 0.1, sheen: 0.4, sheenColor: new THREE.Color(0xc8e0a0), emissive: 0xff2a0a, emissiveIntensity: 0 });
  const G = new THREE.Color(0x7a9a58), Rd = new THREE.Color(0x3a0602);
  m.setLit = (k) => { m.color.copy(G).lerp(Rd, k); m.emissiveIntensity = k * 0.95; m.emissive.setRGB(0.85, 0.05, 0.02); m.sheen = 0.4 * (1 - k); };
  return m;
}
const gilt = () => new THREE.MeshStandardMaterial({ color: 0xd8b878, metalness: 0.9, roughness: 0.3 });

// ---------- the cage cup: bell-shaped beaker, a king tangled in vines on the outside, gilt rim and foot ----------
// Real cup: 16.5 cm tall, 13.2 cm wide. Units here: metres.
export function lycurgusCup() {
  const g = new THREE.Group();
  const mat = dichroicMat();
  const H = 0.165, Rr = 0.064;
  const prof = [[0, 0.012], [0.03, 0.012], [0.042, 0.022], [0.05, 0.05], [0.057, 0.1], [0.062, 0.14], [Rr, H], [Rr - 0.004, H], [0.058, 0.14], [0.053, 0.1], [0.046, 0.05], [0.038, 0.026], [0, 0.02]].map(([a, b]) => new THREE.Vector2(a, b));
  const body = new THREE.Mesh(new THREE.LatheGeometry(prof, 64), mat); g.add(body);
  const rOut = (y) => { if (y < 0.05) return 0.042 + (y - 0.022) / 0.028 * 0.008; if (y < 0.1) return 0.05 + (y - 0.05) / 0.05 * 0.007; if (y < 0.14) return 0.057 + (y - 0.1) / 0.04 * 0.005; return 0.062 + (y - 0.14) / 0.025 * 0.002; };
  // vines: tubes winding around the outer wall, with leaves and grape clusters
  const R = rng(5);
  for (let v = 0; v < 5; v++) {
    const pts = []; const a0 = Math.PI / 2 + 0.9 + v / 5 * (Math.PI * 2 - 1.8), turns = 0.12 + R() * 0.1, y0 = 0.03 + R() * 0.02, y1 = 0.13 + R() * 0.02;
    for (let i = 0; i <= 30; i++) { const u = i / 30, y = y0 + (y1 - y0) * u, a = a0 + turns * Math.PI * 2 * u * (v % 2 ? 1 : -1) + Math.sin(u * 9 + v) * 0.08; const r = rOut(y) + 0.005; pts.push(V(Math.cos(a) * r, y, Math.sin(a) * r)); }
    const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 60, 0.0028, 8), mat); g.add(tube);
    for (let k = 3; k < 30; k += 5) { const p = pts[k]; const lf = new THREE.Mesh(new THREE.SphereGeometry(0.008, 10, 6), mat); lf.scale.set(1, 0.7, 0.35); lf.position.copy(p).multiplyScalar(1.03); lf.lookAt(p.clone().multiplyScalar(3)); lf.rotateZ(R() * 3); g.add(lf); }
    const gp = pts[18].clone().multiplyScalar(1.04); for (let k = 0; k < 6; k++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.0035, 8, 6), mat); b.position.copy(gp).add(V((R() - 0.5) * 0.006, -k * 0.003, (R() - 0.5) * 0.006)); g.add(b); }
  }
  // the king: a small figure fused to the wall, arms up, wrapped by vines
  const king = romanBuilder();
  king.root.traverse(o => { if (o.isMesh) { o.material = mat; o.castShadow = false; } });
  king.root.scale.setScalar(0.062); king.root.position.set(0, 0.03, rOut(0.08) + 0.001); g.add(king.root);
  king.setPose({ lSh: [-1.6, 0, 0.9], rSh: [-1.5, 0, -1.0], lEl: [-0.9, 0, 0], rEl: [-0.8, 0, 0], head: [-0.2, 0.3, 0.1], spine: [0, 0, 0.15], lHip: [0.2, 0, 0.15], rHip: [-0.2, 0, -0.1], lKn: [0.4, 0, 0] });
  if (king.setMood) king.setMood('happy');
  for (let k = 0; k < 3; k++) { const pts = []; for (let i = 0; i <= 16; i++) { const u = i / 16, a = (u - 0.5) * 0.9 + k * 0.1, y = 0.04 + k * 0.03 + u * 0.03; const r = rOut(y) + 0.012 + Math.sin(u * Math.PI) * 0.008; pts.push(V(Math.sin(a) * r, y, Math.cos(a) * r)); } g.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 30, 0.0024, 8), mat)); }
  // gilt rim with leaf band and gilt open-work foot
  const gm = gilt();
  const rim = new THREE.Mesh(new THREE.TorusGeometry(Rr + 0.002, 0.004, 10, 64), gm); rim.rotation.x = Math.PI / 2; rim.position.y = H; g.add(rim);
  const band = new THREE.Mesh(new THREE.CylinderGeometry(Rr + 0.003, Rr + 0.001, 0.012, 64, 1, true), gm); band.position.y = H - 0.008; g.add(band);
  for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2; const lf = new THREE.Mesh(new THREE.SphereGeometry(0.004, 8, 6), gm); lf.scale.set(1, 1.6, 0.4); lf.position.set(Math.cos(a) * (Rr + 0.004), H - 0.017, Math.sin(a) * (Rr + 0.004)); lf.lookAt(Math.cos(a), H - 0.017, Math.sin(a)); g.add(lf); }
  const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.048, 0.016, 48, 1, true), gm); foot.material = gm.clone(); foot.material.side = THREE.DoubleSide; foot.position.y = 0.008; g.add(foot);
  const footRing = new THREE.Mesh(new THREE.TorusGeometry(0.048, 0.003, 8, 48), gm); footRing.rotation.x = Math.PI / 2; footRing.position.y = 0.001; g.add(footRing);
  // inner lamp (off until set)
  const lamp = new THREE.PointLight(0xff2a10, 0, 0.6, 2); lamp.position.y = 0.07; g.add(lamp);
  const glow = glowSprite(0xff2a10, 0.22); glow.position.y = 0.08; glow.material.opacity = 0; g.add(glow);
  g.mat = mat; g.king = king;
  g.setLit = (k) => { mat.setLit(k); lamp.intensity = k * 0.9; glow.material.opacity = k * 0.35; };
  g.setLit(0);
  g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  return g;
}

// ---------- museum plinth on a dark stage ----------
export function plinth({ w = 0.42, h = 1.0 } = {}) {
  const g = new THREE.Group();
  const m = new THREE.MeshStandardMaterial({ color: 0x23262a, roughness: 0.55 });
  const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), m); b.position.y = h / 2; g.add(b);
  const top = new THREE.Mesh(new THREE.BoxGeometry(w + 0.02, 0.02, w + 0.02), new THREE.MeshStandardMaterial({ color: 0x1a1c1f, roughness: 0.3 })); top.position.y = h + 0.01; g.add(top);
  return shadowAll(g);
}

// ---------- Roman glass furnace: clay dome, glowing mouth, fire ----------
export function furnace() {
  const g = new THREE.Group();
  const clay = new THREE.MeshStandardMaterial({ color: 0x8a5a3a, roughness: 1, bumpMap: fabricTexture(19), bumpScale: 4 });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.8, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2), clay); dome.scale.y = 1.2; dome.position.y = 0.3; g.add(dome);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.9, 0.3, 40), clay); base.position.y = 0.15; g.add(base);
  const mouth = new THREE.Mesh(new THREE.CircleGeometry(0.2, 24), new THREE.MeshBasicMaterial({ color: 0xffa040 })); mouth.position.set(0, 0.75, 0.73); mouth.lookAt(0, 0.75, 3); g.add(mouth);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.21, 0.04, 8, 24), clay); rim.position.copy(mouth.position); rim.lookAt(0, 0.75, 3); g.add(rim);
  const fl = [...Array(6)].map((_, i) => { const s = glowSprite(i % 2 ? 0xff8a2a : 0xffd060, 0.3); s.position.set((i - 2.5) * 0.04, 0.72, 0.76); g.add(s); return s; });
  const light = new THREE.PointLight(0xff8a3a, 4, 5, 2); light.position.set(0, 0.8, 1.0); g.add(light);
  g.update = (t) => { fl.forEach((s, i) => s.scale.setScalar(0.22 + 0.1 * Math.sin(t * 9 + i * 1.7))); light.intensity = 3.6 + 0.6 * Math.sin(t * 11); };
  shadowAll(g);
  return g;
}
export function blowpipe() {
  const g = new THREE.Group();
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 1.3, 10), new THREE.MeshStandardMaterial({ color: 0x3a3a3a, metalness: 0.8, roughness: 0.4 })); pipe.position.y = 0.65; g.add(pipe);
  const gob = new THREE.Mesh(new THREE.SphereGeometry(0.06, 24, 16), new THREE.MeshStandardMaterial({ color: 0xffa040, emissive: 0xff7a20, emissiveIntensity: 2.2, roughness: 0.3 })); gob.scale.y = 1.3; gob.position.y = -0.03; g.add(gob);
  g.gob = gob;
  return shadowAll(g);
}

// ---------- electron microscope (1990): tall column, desk, a screen showing dark specks ----------
export function electronMicroscope() {
  const g = new THREE.Group();
  const grey = new THREE.MeshStandardMaterial({ color: 0xd8dcd8, roughness: 0.5, metalness: 0.2 }), dark = new THREE.MeshStandardMaterial({ color: 0x3a4044, roughness: 0.5 }), steel = new THREE.MeshStandardMaterial({ color: 0xb0b6ba, metalness: 0.8, roughness: 0.3 });
  const desk = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.75, 0.8), grey); desk.position.y = 0.375; g.add(desk);
  const col = [[0.16, 0.5, 1.0], [0.13, 0.35, 1.42], [0.11, 0.3, 1.74], [0.09, 0.3, 2.04]];
  col.forEach(([r, h, y], i) => { const c = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 32), i % 2 ? steel : grey); c.position.set(0.3, y, -0.1); g.add(c); });
  const chamber = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.22, 0.4), dark); chamber.position.set(0.3, 0.86, -0.1); g.add(chamber);
  const tex = canvasTex(256, 256, (x) => { x.fillStyle = '#5a6a5a'; x.fillRect(0, 0, 256, 256); const R = rng(8); for (let i = 0; i < 70; i++) { const r = 3 + R() * 6; x.fillStyle = '#111'; x.beginPath(); x.arc(R() * 256, R() * 256, r, 0, 7); x.fill(); } });
  const mon = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.42, 0.4), new THREE.MeshStandardMaterial({ color: 0xc8c2b0, roughness: 0.6 })); mon.position.set(-0.45, 0.96, -0.05); g.add(mon);
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.38, 0.3), new THREE.MeshBasicMaterial({ map: tex })); scr.position.set(-0.45, 0.96, 0.152); g.add(scr);
  const knobs = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.22), dark); knobs.position.set(0.2, 0.77, 0.22); g.add(knobs);
  g.screen = scr;
  return shadowAll(g);
}

// ---------- nano view: dark green glass with tiny silver and gold specks ----------
export function speckField({ n = 260, size = 3, seed = 3 } = {}) {
  const g = new THREE.Group();
  const R = rng(seed);
  const ag = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 20, 14), new THREE.MeshStandardMaterial({ color: 0xe8ecf0, metalness: 1, roughness: 0.15 }), n);
  const au = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 20, 14), new THREE.MeshStandardMaterial({ color: 0xffc040, metalness: 1, roughness: 0.2 }), Math.round(n * 0.45));
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  const fill = (mesh, cnt) => { for (let i = 0; i < cnt; i++) { const s = 0.03 + R() * 0.04; m4.compose(V((R() - 0.5) * size, (R() - 0.5) * size, (R() - 0.5) * size), q, V(s, s, s)); mesh.setMatrixAt(i, m4); } };
  fill(ag, n); fill(au, Math.round(n * 0.45));
  g.add(ag, au);
  return g;
}

// ---------- nano-cup sensor chip: a grid of tiny cups that shift colour ----------
export function sensorChip({ nx = 22, ny = 30, pitch = 0.012 } = {}) {
  const g = new THREE.Group();
  const plate = new THREE.Mesh(new THREE.BoxGeometry(nx * pitch + 0.02, 0.004, ny * pitch + 0.02), new THREE.MeshPhysicalMaterial({ color: 0xe8f0f4, roughness: 0.1, transmission: 0.4, transparent: true, opacity: 0.7 })); g.add(plate);
  const cups = new THREE.InstancedMesh(new THREE.CylinderGeometry(pitch * 0.38, pitch * 0.3, 0.003, 14), new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.5, roughness: 0.3 }), nx * ny);
  const m4 = new THREE.Matrix4(); const c = new THREE.Color();
  const D = [];
  for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) { const k = i * ny + j; const x = (i - (nx - 1) / 2) * pitch, z = (j - (ny - 1) / 2) * pitch; m4.makeTranslation(x, 0.0035, z); cups.setMatrixAt(k, m4); D.push([x, z]); cups.setColorAt(k, c.set(0x3aa060)); }
  g.add(cups);
  // colour wave spreading from (cx, cz) with radius r
  g.wave = (cx, cz, r) => { D.forEach(([x, z], k) => { const d = Math.hypot(x - cx, z - cz); const f = THREE.MathUtils.clamp((r - d) / 0.02, 0, 1); cups.setColorAt(k, c.set(0x3aa060).lerp(new THREE.Color(0xd8302a), f)); }); cups.instanceColor.needsUpdate = true; };
  return g;
}
export function pipette() {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.014, 0.16, 20), new THREE.MeshStandardMaterial({ color: 0xf0f0f0, roughness: 0.4 })); body.position.y = 0.16; g.add(body);
  const btn = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.02, 14), new THREE.MeshStandardMaterial({ color: 0x2a6ad8, roughness: 0.4 })); btn.position.y = 0.25; g.add(btn);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.08, 16), new THREE.MeshPhysicalMaterial({ color: 0xf8fff0, roughness: 0.1, transmission: 0.6, transparent: true, opacity: 0.8 })); tip.rotation.x = Math.PI; tip.position.y = 0.04; g.add(tip);
  return shadowAll(g);
}
