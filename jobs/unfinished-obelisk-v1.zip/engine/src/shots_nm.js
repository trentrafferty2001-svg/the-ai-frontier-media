// Nilometer reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { palm } from './persia.js';
import { skyline } from './windcatcher.js';
import { egyptian, pyramid } from './egypt.js';
import { nilometer, valley, sacks, scroll, boat, stairNilometer, lvl, CUB, COL0, PIT, RIVZ } from './nilometer.js';
import { VO } from './vo_nm.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['What if', 2], ['your *taxes*', 2], ['depended on', 2], ['how *high*', 2], ['a *river* rose?', 3]],
  [['But in', 2], ['*ancient Egypt*', 2], ['they did', 2], ['and a *stone pit*', 4], ['gave the *answer*', 3]],
  [["It's called a", 3], ['*nilometer*', 1]],
  [['Every *summer*', 2], ['the *Nile flooded*', 3], ['the fields', 2], ['with rich', 2], ['*black mud*', 2]],
  [['*Tunnels*', 1], ['let the *river*', 3], ['flow into', 2], ['a deep *stone pit*', 4], ['beside it', 2]],
  [['In the middle', 3], ['stood a', 2], ['*marble column*', 2], ['marked in *cubits*', 3]],
  [['As the river *rose*', 4], ['the water *climbed*', 3], ['up the column', 3]],
  [['About', 1], ['*sixteen cubits*', 2], ['meant a', 2], ['*perfect flood*', 2], ['and a *big harvest*', 4]],
  [['Much *lower*', 2], ['meant *hunger*', 2], ['and much *higher*', 3], ['could *wash villages*', 3], ['*away*', 1]],
  [['So *officials*', 2], ['read the column', 3], ['and set', 2], ["the year's *taxes*", 3], ['to match', 2]],
  [['When the water', 3], ['reached *sixteen*', 2], ['people *celebrated*', 2]],
  [['The nilometer', 2], ['on *Roda Island*', 3], ['in *Cairo*', 2], ['is more than', 3], ['*1,100 years* old', 4], ['and you can', 3], ['still *walk down*', 3], ['*inside it*', 2]],
  [['Egyptians', 1], ['*measured the Nile*', 3], ['like this', 2], ['for *thousands*', 2], ['of years', 2]],
  [['A *river*', 2], ['a *pit*', 2], ['and a *marble ruler*', 4], ['deciding how much', 3], ['*everyone paid*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function stage(makeStage, { preset = 'golden', sunDir = [-0.5, 0.5, 0.7], shadowSize = 14, shadowAt = [0, 0, 0], fog = 0.003 } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt, envI: 0.95 });
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xffe6c8);
  return scene;
}
function pitScene(makeStage, opts = {}) {
  const scene = stage(makeStage, opts);
  const N = nilometer(scene, opts);
  [[-10, -8, 6], [9, -10, 5.5], [-16, -18, 6.5], [14, -4, 5]].forEach(([x, z, h], i) => { const p = palm(h, i + 13); p.position.set(x, 0, z); scene.add(p); });
  return { scene, N };
}
function person(scene, i, pos, ry = 0) { const F = egyptian(i); F.root.position.set(...pos); F.root.rotation.y = ry; scene.add(F.root); return F; }

// ============ S0: Nile valley, a farmer and an official watching the river ============
function sHook({ makeStage }) {
  const scene = stage(makeStage, { sunDir: [0.5, 0.45, -0.75] });
  const Vl = valley(scene);
  const F = person(scene, 0, [1.5, 0, 1.0], 0.2), O = person(scene, 1, [-0.5, 0, 0.8], -0.2);
  const s = scroll(); scene.add(s);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      Vl.set({ flood: 0, field: 0 });
      standPose(F, t, { lSh: [0.1, 0, 0.2], rSh: [-1.0, 0, -0.4], rEl: [-1.4, 0, 0] }); F.setMood('happy'); F.setMouth(0);
      standPose(O, t, { lSh: [-0.9, 0, 0.3], rSh: [-0.9, 0, -0.3], lEl: [-0.6, 0, 0], rEl: [-0.6, 0, 0], spine: [0.1, 0, 0] }); O.setMood('happy'); O.setMouth(0);
      scene.updateMatrixWorld(true); const a = O.j.lWr.getWorldPosition(V(0, 0, 0)), b = O.j.rWr.getWorldPosition(V(0, 0, 0));
      s.position.copy(a).add(b).multiplyScalar(0.5).add(V(0, 0.05, 0.1)); s.rotation.set(-0.9, 0, 0);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-1.2, -1.6, k), lerp(1.6, 1.9, k), lerp(-2.6, -3.4, k)], [0.6, 1.1, 5]);
      return { bloom: 0.6, flare: 0.3, warm: 1.35 };
    },
  };
}
// ============ S1: the stone pit seen from above, column and water inside ============
function sPitTop({ makeStage }) {
  const { scene, N } = pitScene(makeStage, { building: false, sunDir: [-0.5, 0.8, -0.35] });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      N.set(9 + t * 0.2, t);
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(6, 3.2, k), lerp(9, 5.5, k), lerp(-6, -4.5, k)], [0, lvl(9), 0]);
      return { bloom: 0.35, warm: 1.3 };
    },
  };
}
// ============ S2: "It's called a nilometer": the building with its pointed roof by the river ============
function sName({ makeStage }) {
  const { scene, N } = pitScene(makeStage, { building: true, sunDir: [0.6, 0.35, 0.7] });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      N.set(9, t);
      const a = lerp(0.9, 0.5, easeInOut(range(t, 0, 2.4)));
      place(c, [Math.sin(a) * 18, 4.5, Math.cos(a) * 18 + 2], [0, 4, 0]);
      return { bloom: 0.65, flare: 0.3, warm: 1.35 };
    },
  };
}
// ============ S3: the flood covers the fields, then leaves black mud ============
function sFlood({ makeStage, start: ST }) {
  const scene = stage(makeStage, { sunDir: [-0.5, 0.45, 0.7] });
  const Vl = valley(scene);
  const c = cam(40);
  const tf = at(3, 'flooded') - ST, tm = at(3, 'black') - ST;
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, tf - 0.4, tf + 1.2)) * (1 - easeInOut(range(t, tm - 1.4, tm - 0.1)));
      Vl.set({ flood: k, field: easeInOut(range(t, tf + 0.4, tm - 0.3)) });
      const m = easeInOut(range(t, 0, 4.8));
      place(c, [lerp(-14, -6, m), lerp(14, 11, m), lerp(16, 14, m)], [lerp(-6, 0, m), 0, -12]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S4: cut-away: river water flows through tunnels into the pit ============
function sTunnels({ makeStage }) {
  const { scene, N } = pitScene(makeStage, { cut: true, building: false, sunDir: [0.9, 0.5, 0.3], shadowSize: 18, shadowAt: [0, -5, 4] });
  const glows = [...Array(18)].map(() => { const d = glowSprite(0x9ad8ff, 0.35); scene.add(d); return d; });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const L = 6.5 + t * 0.35; N.set(L, t);
      glows.forEach((d, i) => { const ti = i % 3, ty = N.tunnels[ti]; const u = ((t * 0.45 + i / 6) % 1); d.position.set(0.1, ty, lerp(RIVZ, PIT - 0.2, u)); d.visible = ty < lvl(L) - 0.2; });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(19, 17, k), lerp(-2, -3, k), lerp(5, 3.5, k)], [0, lerp(-4.5, -5.5, k), lerp(4, 3, k)]);
      return { bloom: 0.55, warm: 1.25 };
    },
  };
}
// ============ S5: the marble column, camera tilting up its cubit marks ============
function sColumn({ makeStage }) {
  const { scene, N } = pitScene(makeStage, { cut: true, building: false, sunDir: [0.9, 0.6, 0.2], shadowSize: 10, shadowAt: [0, -5, 0] });
  const lamp = new THREE.PointLight(0xfff0d0, 6, 12, 1.5); lamp.position.set(2.5, -4, 1.5); scene.add(lamp);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      N.set(5.5, t);
      const k = easeInOut(range(t, 0, 4.2)); const y = lerp(COL0 + 4 * CUB, COL0 + 13 * CUB, k);
      place(c, [3.0, y - 0.2, 1.1], [0, y + 0.25, 0]);
      return { bloom: 0.45, warm: 1.25 };
    },
  };
}
// ============ S6: the river rises and water climbs the column (cut-away, wide) ============
function sRise({ makeStage }) {
  const { scene, N } = pitScene(makeStage, { cut: true, building: false, sunDir: [0.9, 0.5, 0.3], shadowSize: 18, shadowAt: [0, -5, 4] });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      N.set(lerp(7, 14.5, easeInOut(range(t, 0.2, 3.2))), t);
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(15, 16, k), lerp(-3, -1.5, k), lerp(-3, 0, k)], [0, lerp(-5, -3.5, k), 1.8]);
      return { bloom: 0.55, warm: 1.25 };
    },
  };
}
// ============ S7: water reaches the 16 mark, the ring glows; ripe fields ============
function sSixteen({ makeStage, start: ST }) {
  const { scene, N } = pitScene(makeStage, { cut: true, building: false, sunDir: [0.9, 0.6, 0.2], shadowSize: 10, shadowAt: [0, -3, 0] });
  const lamp = new THREE.PointLight(0xfff0d0, 6, 12, 1.5); lamp.position.set(2.5, -2, 1.5); scene.add(lamp);
  const c = cam(36);
  const t16 = at(7, 'sixteen') - ST;
  return {
    scene, camera: c,
    update(t) {
      const L = lerp(14.6, 16, easeOut(range(t, 0, t16 + 0.6))); N.set(L, t);
      N.column.glow(easeOut(range(t, t16 + 0.4, t16 + 1.0)) * (0.8 + 0.2 * Math.sin(t * 6)));
      const y = lvl(16);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(3.4, 2.4, k), y + lerp(0.6, 0.3, k), lerp(1.6, 0.8, k)], [0, y + 0.1, 0]);
      return { bloom: 0.7, warm: 1.3 };
    },
  };
}
// ============ S8: too low (dry fields) then too high (village under water) ============
function sExtremes({ makeStage, start: ST }) {
  const scene = stage(makeStage, { sunDir: [-0.4, 0.5, 0.7] });
  const Vl = valley(scene);
  const c = cam(40);
  const th = at(8, 'higher') - ST;
  return {
    scene, camera: c,
    update(t) {
      const hi = easeInOut(range(t, th - 0.2, th + 1.6));
      Vl.set({ flood: hi, field: 0, dryK: t < th - 0.2 ? 1 : 1 - hi, high: hi });
      const m = easeInOut(range(t, 0, th - 0.2)), n = easeInOut(range(t, th - 0.2, th + 2.2));
      if (t < th - 0.2) place(c, [lerp(-10, -8, m), lerp(5, 4.4, m), lerp(6, 4, m)], [-6, 0, -10]);
      else place(c, [lerp(26, 24, n), lerp(5, 6, n), lerp(8, 6, n)], [17, 0.6, -8]);
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S9: an official at the top of the pit reads the column; grain sacks pile up ============
function sTax({ makeStage, start: ST }) {
  const { scene, N } = pitScene(makeStage, { building: false, sunDir: [-0.5, 0.6, 0.6], shadowSize: 10 });
  const O = person(scene, 1, [PIT + 0.4, 0.5, -0.6], -Math.PI / 2 - 0.4), F = person(scene, 0, [PIT + 2.6, 0, -3.2], -0.6);
  const s = scroll(); scene.add(s);
  const S = sacks(20); S.position.set(PIT + 3.6, 0, -4.6); S.rotation.y = -0.5; scene.add(S);
  const c = cam(40);
  const tt = at(9, 'taxes') - ST;
  return {
    scene, camera: c,
    update(t) {
      N.set(16, t); N.column.glow(0.5);
      standPose(O, t, { spine: [0.35, 0, 0], neck: [0.4, 0, 0], lSh: [-0.9, 0, 0.3], rSh: [-0.9, 0, -0.3], lEl: [-0.6, 0, 0], rEl: [-0.6, 0, 0] }); O.setMood('happy'); O.setMouth(0);
      standPose(F, t, { lSh: [-0.6, 0, 0.3], rSh: [-0.6, 0, -0.3] }); F.setMood('happy'); F.setMouth(0);
      scene.updateMatrixWorld(true); const a = O.j.lWr.getWorldPosition(V(0, 0, 0)), b = O.j.rWr.getWorldPosition(V(0, 0, 0));
      s.position.copy(a).add(b).multiplyScalar(0.5).add(V(0, 0.06, 0)); s.lookAt(c.position);
      S.show(easeOut(range(t, tt - 1.0, tt + 1.2)));
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-0.6, 0.0, k), lerp(2.6, 2.3, k), lerp(2.2, 1.6, k)], [PIT + 1.8, 0.9, -2.0]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S10: celebration at dusk: lantern boats, people cheering by the river ============
function sParty({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.8, 0.06, 0.6], fog: 0.004, shadowSize: 14, envI: 0.7 });
  fillLight(scene, [0.3, 0.4, 1], 0.4, 0xffc890);
  const Vl = valley(scene);
  const B = [[-1.8, 7], [1.8, 10], [0.0, 13.5]].map(([x, z], i) => { const b = boat(i); b.position.set(x, 0.1, z); b.rotation.y = 0.3 * i; scene.add(b); return b; });
  const lights = [...Array(26)].map((_, i) => { const d = glowSprite(i % 2 ? 0xffb040 : 0xffe080, 0.7); scene.add(d); return d; });
  const P = [[-1.3, 1.6], [-0.45, 0.6], [0.45, 1.8], [1.3, 0.8], [0.0, 3.0]].map(([x, z], k) => person(scene, k % 3, [x, 0, z], Math.PI + (k - 2) * 0.15));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      Vl.set({ flood: 0.25, field: 0.2 });
      B.forEach((b, i) => { b.position.y = 0.15 + Math.sin(t * 2 + i) * 0.05; b.rotation.z = Math.sin(t * 1.6 + i) * 0.04; });
      lights.forEach((d, i) => { const b = B[i % 3]; const a = i * 2.4 + t * 0.3; d.position.set(b.position.x + Math.cos(a) * 1.4, 1.2 + Math.sin(t * 3 + i) * 0.15 + (i % 4) * 0.5, b.position.z + Math.sin(a) * 0.8); d.material.opacity = 0.7 + 0.3 * Math.sin(t * 5 + i); });
      P.forEach((F, k) => { const j = Math.max(0, Math.sin(t * 5 + k * 1.3)); standPose(F, t, { lSh: [-2.6 - j * 0.3, 0, 0.4], rSh: [-2.6 - j * 0.3, 0, -0.4], lEl: [-0.3, 0, 0], rEl: [-0.3, 0, 0] }); F.root.position.y = j * 0.15; F.setMood('happy'); F.setMouth(0.6); });
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-0.5, 0.5, k), lerp(2.3, 2.6, k), lerp(-4.5, -5.2, k)], [0.5, 1.4, 10]);
      return { bloom: 0.9, flare: 0.3, warm: 1.5 };
    },
  };
}
// ============ S11: Roda Island today (building + Cairo skyline), then down the stairs inside ============
function sRoda({ makeStage, start: ST }) {
  const { scene, N } = pitScene(makeStage, { building: true, sunDir: [-0.6, 0.45, 0.6], shadowSize: 16, fog: 0.005 });
  const city = new THREE.Group(); scene.add(city); skyline(city, { n: 40, r: 80, seed: 9 }); city.position.set(0, 0, -30);
  const lamp = new THREE.PointLight(0xffe0b0, 10, 16, 1.4); lamp.position.set(-1, -3, -1); scene.add(lamp);
  const c = cam(40);
  const tw = at(11, 'and') - ST - 0.1;
  return {
    scene, camera: c,
    update(t) {
      N.set(4, t);
      const inside = t >= tw; N.house.roof.visible = N.house.tip.visible = !inside; city.visible = !inside; lamp.visible = inside;
      if (!inside) { const a = lerp(-0.4, 0.3, easeInOut(range(t, 0, tw))); place(c, [Math.sin(a) * 24, 7, Math.cos(a) * 24 + 6], [0, 4, -4]); }
      else { const k = easeInOut(range(t, tw, tw + 3.0)); place(c, [lerp(-PIT + 0.6, -PIT + 0.6, k), lerp(-0.2, -4.5, k), lerp(-PIT + 1.0, 0.4, k)], [0.6, lerp(-4, -7.5, k), lerp(0.8, 1.6, k)]); }
      return { bloom: 0.6, flare: inside ? 0 : 0.9, warm: 1.3 };
    },
  };
}
// ============ S12: thousands of years: staircase nilometer on the bank, pyramids far away ============
function sAges({ makeStage }) {
  const scene = stage(makeStage, { sunDir: [0.7, 0.15, 0.7], fog: 0.0025 });
  const Vl = valley(scene);
  const St = stairNilometer(); St.position.set(-4, 0, 0.5); St.rotation.y = 0; scene.add(St);
  const P = pyramid(); P.scale.setScalar(0.6); P.position.set(-60, 0, -140); scene.add(P);
  const P2 = pyramid(); P2.scale.setScalar(0.4); P2.position.set(-20, 0, -160); scene.add(P2);
  const b = birds(4, { from: [-20, 12, 10], to: [20, 14, 0], spread: 4, speed: 0.06, scale: 1.4, seed: 4 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      Vl.set({ flood: 0.1 + 0.05 * Math.sin(t), field: 0 });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(2.5, 3.5, k), lerp(2.0, 2.6, k), lerp(8, 9, k)], [-4, 0.6, lerp(2, 0, k)]);
      return { bloom: 0.7, flare: 0.3, warm: 1.4 };
    },
  };
}
// ============ S13: ending: from the column at 16 back out over the river at sunset ============
function sEnd({ makeStage }) {
  const { scene, N } = pitScene(makeStage, { cut: true, building: false, sunDir: [0.8, 0.15, 0.6], shadowSize: 18, shadowAt: [0, -5, 4] });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      N.set(16, t); N.column.glow(0.8);
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(4, 22, k), lerp(lvl(16) + 0.4, 3, k), lerp(1.2, 6, k)], [0, lerp(lvl(16), -3.5, k), lerp(0, 3.5, k)]);
      return { bloom: 0.7, flare: 0.3, warm: 1.4 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sPitTop], [ls(2), ls(3), sName], [ls(3), ls(4), sFlood], [ls(4), ls(5), sTunnels],
  [ls(5), ls(6), sColumn], [ls(6), ls(7), sRise], [ls(7), ls(8), sSixteen], [ls(8), ls(9), sExtremes], [ls(9), ls(10), sTax],
  [ls(10), ls(11), sParty], [ls(11), ls(12), sRoda], [ls(12), ls(13), sAges], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
