// Unfinished obelisk reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, birds } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll, crackPath, ribbon } from './rome.js';
import { egyptian, nile, barge, papyrus } from './egypt.js';
import { palm } from './persia.js';
import { obelisk, quarryBed, doleriteBall, chisel, mallet, pharaoh, graniteMat } from './obelisk.js';
import { VO } from './vo_ob.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This is the', 3], ['*biggest obelisk*', 2], ['ever attempted', 2], ['and it never', 3], ['*left the ground*', 3]],
  [["It's still lying", 3], ['in a *granite*', 3], ['*quarry*', 1], ['in *Aswan*', 2], ['*Egypt*', 1]],
  [['Finished', 1], ['it would have', 3], ['stood about', 2], ['*42 meters*', 3], ['tall', 1], ['and weighed', 2], ['over a', 2], ['*thousand tonnes*', 2]],
  [['*Copper* chisels', 2], ["couldn't cut", 2], ['granite', 1], ['so workers', 2], ['*pounded* it', 2], ['with balls', 2], ['of *dolerite*', 2], ['an even', 2], ['*harder* rock', 2]],
  [['Rows of workers', 3], ['*bashed*', 1], ['deep *trenches*', 2], ['around it', 2], ['bit by bit', 3]],
  [['Then a *crack*', 3], ['appeared', 1], ['running right', 2], ['*across*', 1], ['the stone', 2]],
  [['An obelisk', 2], ['had to be', 3], ['*one solid*', 2], ['*piece*', 1], ['so the', 2], ['whole thing', 2], ['was *abandoned*', 2]],
  [['It was *probably*', 3], ['ordered by', 2], ['*Queen Hatshepsut*', 2], ['about', 1], ['*3,500 years*', 4], ['ago', 1]],
  [['*Today*', 1], ['it shows', 2], ['*exactly*', 1], ['how the Egyptians', 3], ['*carved* these giants', 3], ['because', 1], ['it *failed*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: the Aswan quarry with the obelisk in its trench, the Nile beyond ============
function quarryScene(makeStage, opts = {}, { people = 0, modern = false } = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.42, 0.68], fog: 0.0025, shadowSize: 30, envI: 0.95, cloud: 0.2, ...opts });
  const sand = new THREE.Mesh(new THREE.RingGeometry(80, 500, 64), new THREE.MeshStandardMaterial({ color: 0xc8a070, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); sand.rotation.x = -Math.PI / 2; sand.position.y = -0.02; sand.receiveShadow = true; scene.add(sand);
  const bed = quarryBed(); scene.add(bed);
  const ob = obelisk(); scene.add(ob);
  nile(scene, { z: -120, w: 60, len: 600 });
  [[-40, -96, 7], [-20, -100, 8], [10, -97, 6.5], [35, -99, 7.5], [60, -95, 6], [-65, -98, 7]].forEach(([x, z, h], i) => { const p = palm(h, i + 3); p.position.set(x, 0, z); scene.add(p); });
  const bg = barge(); bg.position.set(20, 0, -125); bg.rotation.y = 0.2; scene.add(bg);
  scene.add(mountains({ rMin: 220, rMax: 380, height: 30, seed: 6, color: 0xb0885a }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  const b = birds(3, { from: [-50, 25, -50], to: [50, 28, -70], spread: 6, speed: 0.04, scale: 2, seed: 4 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const folk = [];
  for (let i = 0; i < people; i++) { const p = egyptian(i); const tint = modern ? [0x2a5a9a, 0xd84a3a, 0x3a8a5a, 0xe8c040][i % 4] : null; if (tint) p.root.traverse(o => { if (o.isMesh && o.material.color && o.material.color.getHex() === [0xf2ece0, 0xe8dcc4, 0xf0e8d8][i % 3]) { o.material = o.material.clone(); o.material.color.set(tint); } }); scene.add(p.root); folk.push(p); }
  return { scene, ob, folk };
}

// ============ S0 hook: aerial over the giant lying in its trench ============
function sHook({ makeStage }) {
  const { scene, folk } = quarryScene(makeStage, {}, { people: 3, modern: true });
  folk.forEach((p, i) => { p.root.position.set(-8 + i * 7, 0, 0.6 - i * 0.5); p.root.rotation.y = 1.4; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((p, i) => { const s = Math.sin(t * 5 + i); standPose(p, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07] }); p.setMood('happy'); p.root.position.x = -8 + i * 7 + t * 0.6; });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-34, -26, k), lerp(30, 18, k), lerp(24, 18, k)], [lerp(-2, 2, k), -1, lerp(0, -1, k)]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S1: low along the obelisk toward its tip, the Nile beyond ============
function sAlong({ makeStage }) {
  const { scene } = quarryScene(makeStage, { sunDir: [0.7, 0.35, -0.6] });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-24, -18, k), lerp(1.6, 2.2, k), lerp(4.5, 3.8, k)], [lerp(10, 22, k), lerp(0.2, 0.6, k), lerp(-1, -2, k)]);
      return { bloom: 0.6, flare: 1.1, warm: 1.3 };
    },
  };
}
// ============ S2: what it would have been: raised upright beside a temple, tiny people at its foot ============
function sRaise({ makeStage, start: ST }) {
  const tS = at(2, 'stood') - ST, tT = at(2, 'thousand') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.55, 0.45, 0.7], fog: 0.002, shadowSize: 30, envI: 0.95, cloud: 0.25 });
  const sand = new THREE.Mesh(new THREE.CircleGeometry(500, 64), new THREE.MeshStandardMaterial({ color: 0xc8a070, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); sand.rotation.x = -Math.PI / 2; sand.receiveShadow = true; scene.add(sand);
  const A = archMats();
  for (const s of [-1, 1]) { const py = new THREE.Mesh(new THREE.BoxGeometry(14, 18, 5), A.stone); py.position.set(s * 12, 9, -10); py.scale.set(1, 1, 1); scene.add(shadowAll(py)); }
  const pivot = new THREE.Group(); pivot.position.set(0, 0, 0); scene.add(pivot);
  const ob = obelisk(); ob.position.set(21, 2.1, 0); pivot.add(ob);
  const plinth = new THREE.Mesh(new THREE.BoxGeometry(6, 1.2, 6), A.stone); plinth.position.set(0, 0.6, 0); scene.add(shadowAll(plinth));
  const folk = [0, 1, 2, 3].map(i => { const p = egyptian(i); p.root.position.set(-4 + i * 2.4, 0, 5 + (i % 2)); p.root.rotation.y = 0.2 * (i - 1.5); scene.add(p.root); return p; });
  scene.add(mountains({ rMin: 220, rMax: 380, height: 30, seed: 6, color: 0xb0885a }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const up = easeInOut(range(t, 0.1, tS + 0.6));
      pivot.rotation.z = up * Math.PI / 2; pivot.position.y = 1.2 * up;
      folk.forEach((p, i) => { standPose(p, t + i, { head: [-0.5 * up, 0, 0], neck: [-0.3 * up, 0, 0] }); p.setMood('happy'); p.setMouth(up > 0.9 ? 0.5 : 0); });
      const sh = t > tT - 0.1 && t < tT + 0.4 ? shake(t * 4, 2, 5) : [0, 0, 0];
      const k = easeInOut(range(t, 0, 4.6));
      const pos = [lerp(6, 5, k) + sh[0] * 0.05, lerp(1.6, 1.5, k) + sh[1] * 0.05, lerp(26, 54, k)], look = [0, lerp(8, 21, k), 0];
      place(c, pos, look);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S3a: copper chisel blunts on granite; S3b: a dolerite ball smashes down ============
function rockFace(makeStage) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.5, 0.7], fog: 0.003, shadowSize: 2, envI: 0.9, cloud: 0.2 });
  const g = new THREE.Mesh(new THREE.BoxGeometry(8, 2, 8), graniteMat(14)); g.position.y = -1; g.receiveShadow = true; scene.add(g);
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  return scene;
}
function chips(scene, n = 16, col = 0xc89080) { return [...Array(n)].map((_, i) => { const m = new THREE.Mesh(new THREE.IcosahedronGeometry(0.012 + (i % 3) * 0.006, 0), new THREE.MeshStandardMaterial({ color: col, roughness: 1 })); m.castShadow = true; scene.add(m); return { m, i, a: i * 2.39, v: 1.2 + (i % 5) * 0.4 }; }); }
function sChisel({ makeStage, start: ST }) {
  const tC = at(3, 'cut') - ST;
  const scene = rockFace(makeStage);
  const blk = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.8, 1.0), graniteMat(1.5)); blk.position.set(0, 0.4, 0.1); blk.castShadow = blk.receiveShadow = true; scene.add(blk);
  const ch = chisel(); ch.scale.setScalar(1.6); scene.add(ch);
  const ml = mallet(); ml.scale.setScalar(1.4); scene.add(ml);
  const man = egyptian(0); man.root.position.set(0, 0, -0.62); scene.add(man.root);
  const fl = chips(scene, 8, 0xc87a4a);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const hits = [0.5, 1.2, tC - 0.05];
      let ph = 0; hits.forEach(h => { ph = Math.max(ph, 1 - Math.min(1, Math.abs(t - h) / 0.25)); });
      const bend = easeOut(range(t, tC - 0.05, tC + 0.15));
      const Y = 0.801;
      ch.position.set(0.05, Y, 0.15); ch.rotation.set(0.15, 0, 0); ch.tip.rotation.z = bend * 0.9; ch.tip.position.x = bend * 0.006; ch.tip.scale.y = 1 - bend * 0.4;
      ml.position.set(0.12, Y + 0.38 + (1 - ph) * 0.25, 0.15); ml.rotation.set(0, 0, 1.5 - (1 - ph) * 0.4);
      standPose(man, t, { spine: [0.45, 0, 0], chest: [0.15, 0, 0], head: [0.3, 0, 0], neck: [0.1, 0, 0] }); man.setMood('happy'); man.setMouth(t > tC ? 0.4 : 0); man.blink(blinkK(t, [0.8])); man.grip(0.95, 0.95);
      man.root.updateMatrixWorld(true); ch.updateMatrixWorld(true); ml.updateMatrixWorld(true);
      ikArm(man, 'l', wpos(ch, V(0, 0.22, 0)), wpos(man.root, V(0.7, 0.2, 0.2)), V(0, 1, 0));
      ikArm(man, 'r', wpos(ml, V(0, -0.2, 0)), wpos(man.root, V(-0.7, 0.2, 0.2)), V(0, 1, 0));
      fl.forEach(({ m, i, a, v }) => { const s = t - tC; m.visible = s > 0 && s < 0.9; m.position.set(0.05 + Math.cos(a) * s * 0.15, Y + 0.01 + Math.max(0, v * s * 0.4 - 2 * s * s), 0.15 + Math.sin(a) * s * 0.15); });
      const k = easeInOut(range(t, 0, 2.2));
      const pos = [lerp(1.7, 1.45, k), lerp(1.45, 1.35, k), lerp(1.9, 1.6, k)], look = [0.05, lerp(1.0, 0.95, k), -0.1];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.2, dof: dofTo(pos, look, 0.012, 0.01) };
    },
  };
}
function sPound({ makeStage, start: ST }) {
  const tP = at(3, 'pounded') - ST, tD = at(3, 'dolerite') - ST;
  const scene = rockFace(makeStage);
  const man = egyptian(1); man.root.position.set(0, 0, -0.55); scene.add(man.root);
  const ball = doleriteBall(0.17); scene.add(ball);
  const ch = chisel(); ch.scale.setScalar(1.5); ch.position.set(0.55, 0.012, 0.55); ch.rotation.set(Math.PI / 2, 0, 0.7); ch.tip.rotation.z = 0.8; ch.tip.scale.y = 0.6; scene.add(ch);
  const tS = at(3, 'so') - ST;
  const fl = chips(scene, 18);
  const dust = [...Array(10)].map((_, i) => { const s = glowSprite(0xd8b090, 0.2); s.material.blending = THREE.NormalBlending; scene.add(s); return { s, i }; });
  const c = cam(36);
  const period = 0.9;
  return {
    scene, camera: c,
    update(t) {
      const ph = ((t - tP + 0.35) / period % 1 + 1) % 1;
      const lift = t < tS ? 0.15 : (ph < 0.6 ? easeOut(ph / 0.6) : 1 - easeIn((ph - 0.6) / 0.4));
      standPose(man, t, { spine: [0.35 - lift * 0.25, 0, 0], chest: [0.1, 0, 0], head: [0.25, 0, 0], lKn: [0.3, 0, 0], rKn: [0.3, 0, 0], lHip: [-0.25, 0, 0.1], rHip: [-0.25, 0, -0.1], drop: -0.05 });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.6, 2.4])); man.grip(0.95, 0.95);
      man.root.updateMatrixWorld(true);
      const bp = V(0, 0.17 + lift * 1.15, 0.0); ball.position.copy(bp); ball.rotation.x = t;
      ikArm(man, 'l', bp.clone().add(V(0.15, 0.04, -0.04)), wpos(man.root, V(0.7, 0.3, 0)), V(0, 1, 0));
      ikArm(man, 'r', bp.clone().add(V(-0.15, 0.04, -0.04)), wpos(man.root, V(-0.7, 0.3, 0)), V(0, 1, 0));
      const since = ph * period - 0.36 * 0 ; const sHit = (ph >= 0 && ph < 0.3) ? ph * period : 99;
      fl.forEach(({ m, i, a, v }) => { const s = sHit; m.visible = s < 0.3 && t > tS; m.position.set(Math.cos(a) * s * 0.8, 0.02 + Math.max(0, v * s - 5 * s * s), Math.sin(a) * s * 0.8 + 0.05); });
      dust.forEach(({ s, i }) => { const a = sHit < 0.3 ? sHit / 0.3 : 1; s.visible = sHit < 0.3 && t > tS; s.position.set(Math.sin(i * 2.1) * 0.3 * a, 0.05 + a * 0.2, Math.cos(i * 1.3) * 0.3 * a + 0.1); s.material.opacity = 0.5 * (1 - a); s.scale.setScalar(0.1 + a * 0.3); });
      const k = easeInOut(range(t, tS - 0.6, tS + 0.4));
      const sh = sHit < 0.1 && t > tS ? shake(t * 6, 1.4, 2) : [0, 0, 0];
      const pos = [lerp(0.85, 1.5, k) + sh[0] * 0.01, lerp(0.22, 1.35, k) + sh[1] * 0.01, lerp(0.95, 2.4, k)], look = [lerp(0.55, 0, k), lerp(0.03, 0.75, k), lerp(0.55, -0.3, k)];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.25, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S4: rows of workers pounding in the trench ============
function sRows({ makeStage }) {
  const { scene } = quarryScene(makeStage, { sunDir: [-0.4, 0.55, 0.73] });
  const men = [], balls = [];
  for (let i = 0; i < 10; i++) { const p = egyptian(i); const side = i % 2 ? 1 : -1; p.root.position.set(-12 + Math.floor(i / 2) * 3.2, -4.4, side * 2.65); p.root.rotation.y = side > 0 ? Math.PI : 0; scene.add(p.root); men.push(p); const b = doleriteBall(0.17); scene.add(b); balls.push(b); }
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      men.forEach((p, i) => {
        const ph = ((t + i * 0.23) / 0.9) % 1; const lift = ph < 0.6 ? easeOut(ph / 0.6) : 1 - easeIn((ph - 0.6) / 0.4);
        standPose(p, t + i, { spine: [0.35 - lift * 0.25, 0, 0], head: [0.25, 0, 0], lKn: [0.3, 0, 0], rKn: [0.3, 0, 0], drop: -0.05 }); p.setMood('happy');
        p.root.updateMatrixWorld(true);
        const bp = wpos(p.root, V(0, 0.17 + lift * 1.1, 0.45)); bp.y = Math.max(bp.y, -4.4 + 0.17); balls[i].position.copy(bp);
        ikArm(p, 'l', bp.clone().add(wpos(p.root, V(0.15, 0, 0)).sub(wpos(p.root, V(0, 0, 0)))), wpos(p.root, V(0.7, 0.3, 0)), V(0, 1, 0));
        ikArm(p, 'r', bp.clone().add(wpos(p.root, V(-0.15, 0, 0)).sub(wpos(p.root, V(0, 0, 0)))), wpos(p.root, V(-0.7, 0.3, 0)), V(0, 1, 0));
      });
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-18, -15, k), lerp(5.5, 4.5, k), 2.55], [lerp(-6, -4, k), -4.3, 2.6]);
      return { bloom: 0.55, flare: 0.8, warm: 1.25 };
    },
  };
}
// ============ S5: the crack runs across the top of the obelisk ============
function sCrack({ makeStage, start: ST }) {
  const tC = at(5, 'crack') - ST, tA = at(5, 'across') - ST;
  const { scene } = quarryScene(makeStage, { sunDir: [-0.5, 0.45, 0.74] });
  const g = new THREE.Group(); g.rotation.x = -Math.PI / 2; g.position.set(4, 0.012, 0); scene.add(g);
  const pts = crackPath(11, { top: 2.15, bottom: -2.15, x0: 0, wander: 0.45, steps: 34 });
  const cr = ribbon(pts, 0.07, new THREE.MeshBasicMaterial({ color: 0x120a08 }), 0); g.add(cr);
  const dust = [...Array(20)].map((_, i) => { const s = glowSprite(0xd8b090, 0.6); s.material.blending = THREE.NormalBlending; scene.add(s); return { s, i }; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const r = easeInOut(range(t, tC - 0.1, tA + 0.4)); cr.reveal(r);
      dust.forEach(({ s, i }) => { const p = pts[Math.min(pts.length - 1, Math.floor(r * (pts.length - 1) * (i / 20)))]; const a = ((t * 0.8 + i / 20) % 1); s.visible = r > 0.05; s.position.set(4 + p[0], 0.1 + a * 0.8, -p[1]); s.material.opacity = 0.35 * (1 - a); s.scale.setScalar(0.3 + a * 0.6); });
      const sh = t > tC - 0.1 && t < tC + 0.5 ? shake(t * 5, 2.4, 9) : [0, 0, 0];
      const k = easeInOut(range(t, 0, 3.0));
      const pos = [lerp(7.5, 6.6, k) + sh[0] * 0.05, lerp(5.2, 4.2, k) + sh[1] * 0.05, lerp(4.5, 3.6, k)], look = [4, 0, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S6: tools down, workers leave; the stone stays ============
function sAbandon({ makeStage, start: ST }) {
  const tA = at(6, 'abandoned') - ST;
  const { scene, folk } = quarryScene(makeStage, { sunDir: [0.6, 0.25, -0.76] }, { people: 5 });
  const g = new THREE.Group(); g.rotation.x = -Math.PI / 2; g.position.set(4, 0.012, 0); scene.add(g);
  g.add(ribbon(crackPath(11, { top: 2.15, bottom: -2.15, x0: 0, wander: 0.45, steps: 34 }), 0.07, new THREE.MeshBasicMaterial({ color: 0x120a08 }), 0));
  const balls = [...Array(6)].map((_, i) => { const b = doleriteBall(0.17); b.position.set(-6 + i * 2.3, 0.17, 3.4 + (i % 2) * 0.6); scene.add(b); return b; });
  folk.forEach((p, i) => { p.root.position.set(-6 + i * 2.5, 0, 4.2); p.root.rotation.y = 0; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((p, i) => { const go = range(t, 0.6 + i * 0.25, 4); const s = Math.sin(t * 5 + i) * (go > 0 ? 1 : 0); standPose(p, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07], head: [0.15, 0, 0] }); p.setMood('happy'); p.root.position.z = 4.2 + go * 9; });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-2, -4, k), lerp(3.2, 12, k), lerp(-6, -12, k)], [lerp(-1, 2, k), lerp(0.5, 0, k), lerp(3, 2, k)]);
      return { bloom: 0.6, flare: 1.0, warm: 1.35 };
    },
  };
}
// ============ S7: Queen Hatshepsut with the plan ============
function sQueen({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.4, 0.77], fog: 0.003, shadowSize: 4, envI: 0.95, cloud: 0.2 });
  const A = archMats();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), A.stone); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  for (let i = 0; i < 6; i++) { const col = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.6, 7, 16), A.stone); col.position.set(-6 + (i % 3) * 6, 3.5, -4 - Math.floor(i / 3) * 5); scene.add(shadowAll(col)); const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.55, 0.8, 16), A.stone); cap.position.set(col.position.x, 7.3, col.position.z); scene.add(shadowAll(cap)); }
  const q = pharaoh(); q.root.position.set(0, 0, 0); q.root.rotation.y = 0.35; scene.add(q.root);
  const scribe = egyptian(2); scribe.root.position.set(1.1, 0, 0.5); scribe.root.rotation.y = -1.6; scene.add(scribe.root);
  const pp = papyrus(); scene.add(pp);
  // distant obelisk model in the background, gilded tip
  const mini = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.4, 9, 4), graniteMat(1)); mini.rotation.y = Math.PI / 4; mini.position.set(-9, 4.5, -14); scene.add(shadowAll(mini));
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.6, 4), new THREE.MeshStandardMaterial({ color: 0xe8c050, metalness: 0.9, roughness: 0.25 })); tip.rotation.y = Math.PI / 4; tip.position.set(-9, 9.3, -14); scene.add(tip);
  fillLight(scene, [0.4, 0.5, 1], 0.8, 0xffe0bc);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standPose(q, t, { head: [0.05, -0.3, 0], rSh: [-0.9, 0, -0.3], rEl: [-0.6, 0, 0] }); q.setMood('happy'); q.setMouth(0); q.blink(blinkK(t, [1.3, 3.6]));
      standPose(scribe, t, { spine: [0.2, 0, 0], head: [0.2, 0, 0] }); scribe.setMood('happy'); scribe.setMouth(0); scribe.grip(0.9, 0.9);
      scribe.root.updateMatrixWorld(true);
      const sp = wpos(scribe.root, V(0, 1.05, 0.38)); pp.position.copy(sp); pp.quaternion.copy(scribe.root.quaternion); pp.rotateX(-0.9); pp.updateMatrixWorld(true);
      ikArm(scribe, 'l', wpos(pp, V(0.18, 0, 0)), wpos(scribe.root, V(0.7, 0.2, 0)), V(0, 1, 0));
      ikArm(scribe, 'r', wpos(pp, V(-0.18, 0, 0)), wpos(scribe.root, V(-0.7, 0.2, 0)), V(0, 1, 0));
      const k = easeInOut(range(t, 0, 4.6));
      const pos = [lerp(0.9, 0.55, k), lerp(1.6, 1.55, k), lerp(3.6, 2.8, k)], look = [lerp(0.2, 0.15, k), lerp(1.3, 1.35, k), 0];
      place(c, pos, look);
      return { bloom: 0.55, flare: 0.9, warm: 1.25, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S8: today: visitors walk along it; pull up and away ============
function sToday({ makeStage }) {
  const { scene, folk } = quarryScene(makeStage, { sunDir: [-0.7, 0.3, 0.65] }, { people: 6, modern: true });
  folk.forEach((p, i) => { p.root.position.set(-14 + i * 3.4, 0, i % 2 ? 3.3 : -3.3); p.root.rotation.y = Math.PI / 2; });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((p, i) => { const s = Math.sin(t * 5 + i); standPose(p, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07], head: [0.15, i % 2 ? 0.5 : -0.5, 0] }); p.setMood('happy'); p.root.position.x = -14 + i * 3.4 + t * 0.5; });
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(-6, -30, k), lerp(3, 34, k), lerp(9, 34, k)], [lerp(-4, 0, k), lerp(0, -2, k), lerp(0, -8, k)]);
      return { bloom: 0.6, flare: 1.1, warm: 1.3 };
    },
  };
}

// ============ timeline ============
const cS = at(3, 'so') - 0.06;
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sAlong, 'along'],
  [ls(2), ls(3), sRaise, 'raise'],
  [ls(3), ls(4), sPound, 'pound'],
  [ls(4), ls(5), sRows, 'rows'],
  [ls(5), ls(6), sCrack, 'crack'],
  [ls(6), ls(7), sAbandon, 'abandon'],
  [ls(7), ls(8), sQueen, 'queen'],
  [ls(8), DURATION + 1, sToday, 'today'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
