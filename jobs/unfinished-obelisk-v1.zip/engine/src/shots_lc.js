// Lycurgus Cup reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { splash2 } from './farm2.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { romanBuilder, archMats, shadowAll } from './rome.js';
import { chemist } from './rice.js';
import { lycurgusCup, plinth, furnace, blowpipe, electronMicroscope, speckField, sensorChip, pipette } from './lyc.js';
import { VO } from './vo_lc.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(10) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This cup', 2], ['turns from', 2], ['*green* to *red*', 3]],
  [['Lit from', 2], ['the front', 2], ['it looks like', 3], ['*green jade*', 2]],
  [['Put a *light*', 3], ['*inside*', 1], ['and it glows', 3], ['*ruby red*', 2]],
  [['*Romans*', 1], ['made it', 2], ['about', 1], ['*1,600 years*', 3], ['ago', 1]],
  [['Its carving', 2], ['shows a *king*', 3], ['from *Greek myth*', 3], ['trapped in', 2], ['a *grapevine*', 2]],
  [['For *centuries*', 2], ['nobody knew', 2], ['how the', 2], ['*color trick*', 2], ['worked', 1]],
  [['In *1990*', 3], ['scientists', 1], ['looked inside', 2], ['with an', 2], ['*electron*', 1], ['*microscope*', 1]],
  [['The glass', 2], ['is scattered with', 3], ['tiny specks', 2], ['of *silver*', 2], ['and *gold*', 2], ['a *thousand times*', 3], ['thinner', 1], ['than a *hair*', 3]],
  [['Light *bouncing*', 2], ['off the specks', 3], ['looks *green*', 2], ['Light *passing*', 2], ['through them', 2], ['looks *red*', 2]],
  [['The Romans', 2], ['probably', 1], ['*stumbled* on it', 3], ['by *accident*', 2]],
  [['*Today*', 1], ['it inspires', 2], ['*sensors*', 1], ['that detect', 2], ['*DNA*', 1], ['and *chemicals*', 2], ['just by', 2], ['*changing color*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
function skyTint(scene, top, mid, hor, floor) { const u = scene.userData.sky.material.uniforms; u.top.value.set(top); u.mid.value.set(mid); u.horizon.value.set(hor); u.floorC.value.set(floor); }

// ============ museum: cup on a black plinth under a spotlight ============
function museum(makeStage, { spot = 1 } = {}) {
  const scene = makeStage({ shadowSize: 0.5, sunDir: [-1.2, 3, 2.2], sun: 0.6, hemi: 0.15 });
  skyTint(scene, 0x0c0d10, 0x14161a, 0x1a1c20, 0x0c0d10);
  scene.children.forEach(o => { if (o.isMesh && o.material && o.material.isShadowMaterial) o.visible = false; });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: 0.35 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const p = plinth(); scene.add(p);
  const cup = lycurgusCup(); cup.position.y = 1.02; scene.add(cup);
  const sp = new THREE.SpotLight(0xfff4e4, 18 * spot, 6, 0.35, 0.5, 1.5); sp.position.set(0.6, 2.6, 1.6); sp.target.position.set(0, 1.1, 0); sp.castShadow = true; scene.add(sp, sp.target);
  const rimL = new THREE.SpotLight(0xd8e8ff, 6, 5, 0.4, 0.6, 1.5); rimL.position.set(-1.2, 1.8, -1.2); rimL.target.position.set(0, 1.1, 0); scene.add(rimL, rimL.target);
  return { scene, cup, sp };
}

// ============ S0 hook: the green cup, a light clicks on inside, it turns red ============
function sHook({ makeStage, start: ST }) {
  const tR = at(0, 'red') - ST, tG = at(0, 'green') - ST;
  const { scene, cup, sp } = museum(makeStage);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, tR - 0.35, tR + 0.1));
      cup.setLit(k); sp.intensity = 18 * (1 - 0.75 * k);
      cup.rotation.y = -0.2 + t * 0.15;
      const kc = easeOut(range(t, 0, 2.6));
      const pos = [lerp(0.05, 0.02, kc), lerp(1.13, 1.12, kc), lerp(0.62, 0.42, kc)], look = [0, 1.1, 0];
      place(c, pos, look);
      return { bloom: 0.5 + k * 0.6, warm: 1.0, dof: dofTo(pos, look, 0.006, 0.006) };
    },
  };
}
// ============ S1: front-lit, green jade; slow orbit ============
function sJade({ makeStage }) {
  const { scene, cup } = museum(makeStage, { spot: 1.2 });
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      cup.setLit(0); cup.rotation.y = 1.2 + t * 0.1;
      const a = lerp(-0.5, 0.2, easeInOut(range(t, 0, 3.0)));
      const pos = [Math.sin(a) * 0.5, 1.16, Math.cos(a) * 0.5], look = [0, 1.1, 0];
      place(c, pos, look);
      return { bloom: 0.4, warm: 0.95, dof: dofTo(pos, look, 0.006, 0.006) };
    },
  };
}
// ============ S2: a little oil lamp lowered inside, the cup glows ruby red ============
function sRuby({ makeStage, start: ST }) {
  const tI = at(2, 'inside') - ST, tG = at(2, 'glows') - ST;
  const { scene, cup, sp } = museum(makeStage);
  const flame = glowSprite(0xffc070, 0.06); scene.add(flame);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      const down = easeInOut(range(t, 0.1, tI + 0.2));
      flame.position.set(0, lerp(1.4, 1.14, down), 0); flame.scale.setScalar(0.05 + 0.01 * Math.sin(t * 17));
      flame.visible = t > 0.1;
      const k = easeInOut(range(t, tI, tG + 0.4));
      cup.setLit(k); sp.intensity = 18 * (1 - 0.8 * k);
      cup.rotation.y = 2.3 + t * 0.12;
      const kc = easeInOut(range(t, 0, 3.0));
      const pos = [lerp(-0.25, -0.12, kc), lerp(1.3, 1.16, kc), lerp(0.5, 0.42, kc)], look = [0, lerp(1.12, 1.1, kc), 0];
      place(c, pos, look);
      return { bloom: 0.5 + k * 0.7, warm: 1.05, dof: dofTo(pos, look, 0.006, 0.006) };
    },
  };
}

// ============ S3 / S9: Roman glass workshop ============
function workshop(makeStage) {
  const scene = makeStage({ shadowSize: 2.2, sunDir: [-0.8, 2.5, 1.4], sun: 0.8, hemi: 0.2 });
  skyTint(scene, 0x2a1e16, 0x3a2a1e, 0x4a3524, 0x2a1e16);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), new THREE.MeshStandardMaterial({ color: 0x5a4434, roughness: 1, bumpMap: fabricTexture(13), bumpScale: 3 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const A = archMats();
  const wall = new THREE.Mesh(new THREE.BoxGeometry(8, 3.4, 0.3), A.stone); wall.position.set(0, 1.7, -1.6); wall.receiveShadow = true; scene.add(wall);
  const f = furnace(); f.position.set(0, 0, -0.6); scene.add(f);
  // shelf of finished glass
  const shelf = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.04, 0.25), A.wood); shelf.position.set(-1.6, 1.3, -1.35); scene.add(shelf);
  const glassCols = [0x8ab8a0, 0x6a9ad0, 0xc8d8b0, 0x5a8a6a, 0x9ac0e0];
  glassCols.forEach((col, i) => { const v = new THREE.Mesh(new THREE.LatheGeometry([[0, 0], [0.05, 0], [0.06, 0.06], [0.03, 0.14], [0.035, 0.18], [0, 0.18]].map(([a, b]) => new THREE.Vector2(a, b)), 20), new THREE.MeshPhysicalMaterial({ color: col, roughness: 0.1, transmission: 0.5, transparent: true, opacity: 0.8 })); v.position.set(-2.1 + i * 0.25, 1.32, -1.35); scene.add(v); });
  fillLight(scene, [0.6, 0.5, 1], 0.35, 0xffd0a0);
  scene.userData.updaters.push((t) => f.update(t));
  return { scene, f };
}
function sWorkshop({ makeStage, start: ST }) {
  const { scene, f } = workshop(makeStage);
  const man = romanBuilder({ color: 0xc8a878 }); man.root.position.set(0.55, 0, 0.75); man.root.rotation.y = -2.4; scene.add(man.root);
  const bp = blowpipe(); scene.add(bp);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      f.update(t);
      standPose(man, t, { spine: [0.2, 0, 0], chest: [0.05, 0, 0], head: [-0.05, 0, 0], neck: [0.1, 0, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.9, 2.5])); man.grip(0.95, 0.95);
      man.root.updateMatrixWorld(true);
      // pipe from his mouth level out to the furnace mouth, turning slowly
      const mouthP = wpos(man.root, V(0, 1.45, 0.35));
      const end = V(0.12 + Math.sin(t * 1.3) * 0.03, 0.82, 0.1 - Math.sin(t * 0.7) * 0.05);
      const dir = mouthP.clone().sub(end); const L = dir.length(); dir.normalize();
      bp.position.copy(end); bp.quaternion.setFromUnitVectors(V(0, 1, 0), dir); bp.scale.set(1, L / 1.3, 1);
      bp.gob.scale.set(1.3 / (L / 1.3) * 0 + 1, 1.3 * 1.3 / L, 1);
      bp.updateMatrixWorld(true);
      ikArm(man, 'l', wpos(bp, V(0, 0.95, 0)), wpos(man.root, V(0.6, 0.6, 0.2)), V(0, 1, 0));
      ikArm(man, 'r', wpos(bp, V(0, 0.75, 0)), wpos(man.root, V(-0.6, 0.4, 0.2)), V(0, 1, 0));
      const k = easeInOut(range(t, 0, 3.1));
      const pos = [lerp(-1.7, -1.4, k), lerp(1.5, 1.45, k), lerp(2.6, 2.3, k)], look = [lerp(0.25, 0.2, k), 1.0, lerp(0.15, 0.1, k)];
      place(c, pos, look);
      return { bloom: 0.7, warm: 1.3, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}

// ============ S4: macro on the carving: the king caught in the vine ============
function sCarving({ makeStage, start: ST }) {
  const { scene, cup } = museum(makeStage, { spot: 1.3 });
  const c = cam(28);
  return {
    scene, camera: c,
    update(t) {
      cup.setLit(0.0); cup.rotation.y = lerp(0.25, -0.1, easeInOut(range(t, 0, 4.0)));
      const k = easeInOut(range(t, 0, 4.0));
      const pos = [lerp(0.06, 0.0, k), lerp(1.12, 1.11, k), lerp(0.38, 0.29, k)], look = [0, lerp(1.1, 1.105, k), 0.05];
      place(c, pos, look);
      return { bloom: 0.4, warm: 1.0, dof: dofTo(pos, look, 0.008, 0.006) };
    },
  };
}

// ============ S5: centuries: a stone treasury, sun and candle light sweep round while the cup sits ============
function sCenturies({ makeStage, start: ST }) {
  const scene = makeStage({ shadowSize: 1.4, sunDir: [-1, 2, 1], sun: 0.3, hemi: 0.12 });
  skyTint(scene, 0x1a1712, 0x241f18, 0x2e281e, 0x1a1712);
  const A = archMats();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), A.stone); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const back = new THREE.Mesh(new THREE.BoxGeometry(5, 3, 0.3), A.stone); back.position.set(0, 1.5, -0.9); back.receiveShadow = true; scene.add(back);
  // window opening in the back wall (bright)
  const win = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.8), new THREE.MeshBasicMaterial({ color: 0xfff0d0 })); win.position.set(0.7, 1.9, -0.74); scene.add(win);
  const table = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.06, 0.5), A.wood); table.position.set(0, 0.85, 0); scene.add(shadowAll(table));
  for (const [x, z] of [[-0.4, -0.2], [0.4, -0.2], [-0.4, 0.2], [0.4, 0.2]]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.82, 0.05), A.wood); l.position.set(x, 0.41, z); scene.add(shadowAll(l)); }
  const cup = lycurgusCup(); cup.position.set(0, 0.88, 0); scene.add(cup);
  // candle
  const cnd = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.12, 12), new THREE.MeshStandardMaterial({ color: 0xf0e8d0 })); cnd.position.set(-0.22, 0.94, 0.08); scene.add(cnd);
  const flame = glowSprite(0xffc070, 0.05); flame.position.set(-0.22, 1.015, 0.08); scene.add(flame);
  const cl = new THREE.PointLight(0xffa860, 0, 2, 2); cl.position.set(-0.22, 1.03, 0.08); scene.add(cl);
  const sun = new THREE.DirectionalLight(0xffe2b0, 2.2); sun.castShadow = true; sun.shadow.mapSize.set(1024, 1024); const sc = sun.shadow.camera; sc.left = sc.bottom = -1.5; sc.right = sc.top = 1.5; scene.add(sun, sun.target);
  // dust motes
  const dust = [...Array(30)].map((_, i) => { const s = glowSprite(0xfff0d0, 0.008); scene.add(s); return { s, i }; });
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      // days pass quickly: sun sweeps, then night with candle, then day again
      const day = (t * 0.7) % 1;
      const a = day * Math.PI;
      const up = Math.sin(a);
      sun.position.set(Math.cos(a) * 2 + 0.7, 1.2 + up * 1.5, -2.0); sun.target.position.set(0, 0.9, 0.3);
      sun.intensity = 2.6 * Math.max(0, up);
      win.material.color.setRGB(0.25 + 0.75 * up, 0.22 + 0.7 * up, 0.18 + 0.6 * up);
      cl.intensity = 0.8 * (1 - up); flame.material.opacity = 0.3 + 0.7 * (1 - up);
      cup.setLit(0); cup.rotation.y = 0.6;
      dust.forEach(({ s, i }) => { s.position.set(Math.sin(i * 7.1 + t * 0.2) * 0.5, 0.9 + ((i * 0.37 + t * 0.05) % 1) * 0.9, Math.cos(i * 3.3) * 0.3); s.material.opacity = 0.5 * up; });
      const k = easeInOut(range(t, 0, 3.3));
      const pos = [lerp(-0.6, -0.4, k), lerp(1.25, 1.15, k), lerp(1.2, 0.9, k)], look = [0, 0.97, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}

// ============ S6: 1990 lab, scientist at an electron microscope ============
function sEM({ makeStage, start: ST }) {
  const tM = at(6, 'microscope') - ST;
  const scene = makeStage({ shadowSize: 1.8, sunDir: [-1.5, 3, 2], sun: 1.8 });
  skyTint(scene, 0xc8ccc4, 0xb8bcb4, 0xa8aca4, 0x8a8e88);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), new THREE.MeshStandardMaterial({ color: 0x8a8e88, roughness: 0.7 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(12, 5), new THREE.MeshStandardMaterial({ color: 0xd8d4c4, roughness: 0.9 })); wall.position.set(0, 2.5, -1.0); scene.add(wall);
  const em = electronMicroscope(); em.position.set(0, 0, -0.45); scene.add(em);
  const man = chemist(); man.root.position.set(-0.35, 0, 0.35); man.root.rotation.y = Math.PI + 0.15; scene.add(man.root);
  fillLight(scene, [0.5, 0.6, 1], 0.7, 0xf4f8ff);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      standPose(man, t, { spine: [0.15, 0, 0], neck: [0.05, 0, 0], head: [0.05, 0.1, 0], rSh: [-0.7, 0, -0.2], rEl: [-1.0, 0, 0], lSh: [-0.5, 0, 0.2], lEl: [-1.1, 0, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.8, 3.0])); man.grip(0.4, 0.4);
      em.screen.material.color.setScalar(0.7 + 0.3 * easeOut(range(t, tM - 1, tM)));
      const k = easeInOut(range(t, 0, 4.5));
      const pos = [lerp(-1.8, -1.45, k), lerp(1.65, 1.6, k), lerp(2.0, 1.7, k)], look = [lerp(-0.1, -0.2, k), lerp(1.2, 1.1, k), -0.4];
      place(c, pos, look);
      return { bloom: 0.35, warm: 0.9, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}

// ============ S7: inside the glass: silver and gold specks, a giant hair drifts past ============
function nanoStage(makeStage) {
  const scene = makeStage({ shadowSize: 1, sunDir: [-1, 2, 2], sun: 2.0, hemi: 0.4 });
  skyTint(scene, 0x0a1a10, 0x10261a, 0x163222, 0x0a1a10);
  scene.children.forEach(o => { if (o.isMesh && o.material && o.material.isShadowMaterial) o.visible = false; });
  scene.fog = new THREE.FogExp2(0x0e2416, 0.35);
  return scene;
}
function sSpecks({ makeStage, start: ST }) {
  const tH = at(7, 'hair') - ST, tT = at(7, 'thousand') - ST, tS = at(7, 'silver') - ST;
  const scene = nanoStage(makeStage);
  const sf = speckField({ n: 320, size: 4, seed: 3 }); scene.add(sf);
  fillLight(scene, [0.4, 0.6, 1], 1.4, 0xf0fff0);
  // the hair: a huge scaly cylinder sliding in across the back
  const hair = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 40, 64), new THREE.MeshStandardMaterial({ color: 0x6a4a2a, roughness: 0.6, bumpMap: fabricTexture(7), bumpScale: 6 }));
  hair.rotation.z = Math.PI / 2 - 0.25; scene.add(hair);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      sf.rotation.y = t * 0.08;
      const hk = easeInOut(range(t, tT - 0.3, tH));
      hair.position.set(lerp(-30, 0, hk), lerp(0.5, 1.0, hk), lerp(-12, -9, hk)); hair.visible = hk > 0;
      // fly in, then pull back so the hair reads as huge next to the specks
      const z = kf(t, [[0, 2.6], [tS, 1.2], [tT, 1.6], [tH + 0.5, 5.5]], easeInOut);
      scene.fog.density = lerp(0.35, 0.06, easeInOut(range(t, tT - 0.3, tH)));
      place(c, [0.2, 0.1, z], [0, 0, 0]);
      return { bloom: 0.5, warm: 1.0, sat: 1.1 };
    },
  };
}

// ============ S8: light bouncing off the specks looks green; passing through looks red ============
function beam(color) { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1, 12), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.85 })); return m; }
function setBeam(b, a, bb, k = 1) { const d = bb.clone().sub(a); const L = d.length() * k; b.position.copy(a).addScaledVector(d.clone().normalize(), L / 2); b.quaternion.setFromUnitVectors(V(0, 1, 0), d.normalize()); b.scale.set(1, Math.max(1e-4, L), 1); b.visible = L > 1e-3; }
function sLight({ makeStage, start: ST }) {
  const tG = at(8, 'green') - ST, tP = at(8, 'passing') - ST, tR = at(8, 'red') - ST, tB = at(8, 'bouncing') - ST;
  const scene = nanoStage(makeStage); scene.fog.density = 0.05;
  // a slab of glass with specks inside
  const slab = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.4, 0.5), new THREE.MeshPhysicalMaterial({ color: 0x5a7a48, roughness: 0.15, transparent: true, opacity: 0.45, clearcoat: 1 })); scene.add(slab);
  const sf = speckField({ n: 70, size: 1, seed: 9 }); sf.scale.set(1.5, 2.2, 0.4); scene.add(sf);
  fillLight(scene, [0.4, 0.6, 1], 1.0, 0xf0fff0);
  // white light in from the front-left, green bounces back out; white light from behind, red comes through
  const inF = beam(0xfffbe8), outG = beam(0x5aff7a), inB = beam(0xfffbe8), outR = beam(0xff3a2a);
  scene.add(inF, outG, inB, outR);
  const hitF = V(0, 0.55, 0.25), srcF = V(-1.6, 1.8, 2.4), outFE = V(1.4, 1.5, 2.6);
  const srcB = V(-1.8, -0.2, -2.6), hitB = V(0, -0.5, -0.25), exB = V(0.1, -0.55, 0.25), outBE = V(1.9, -0.95, 2.6);
  const lamp = glowSprite(0xfffbe8, 0.4); lamp.position.copy(srcF); scene.add(lamp);
  const flashG = glowSprite(0x7aff8a, 0.5), flashR = glowSprite(0xff5a3a, 0.6); flashG.position.copy(hitF); flashR.position.copy(exB); scene.add(flashG, flashR);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const a1 = easeOut(range(t, 0.0, tB + 0.2)), a2 = easeOut(range(t, tB + 0.2, tG + 0.1));
      setBeam(inF, srcF, hitF, a1); setBeam(outG, hitF, outFE, a2);
      flashG.material.opacity = a1 >= 1 ? 0.7 : 0;
      const b1 = easeOut(range(t, tP - 0.3, tP + 0.3)), b2 = easeOut(range(t, tP + 0.3, tR));
      setBeam(inB, srcB, hitB, b1); setBeam(outR, exB, outBE, b2);
      flashR.material.opacity = b1 >= 1 ? 0.8 : 0;
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(2.6, 3.0, k), lerp(0.6, 0.0, k), lerp(4.4, 4.0, k)], [lerp(0, 0.1, k), lerp(0.4, -0.1, k), 0]);
      return { bloom: 0.8, warm: 1.0, sat: 1.15 };
    },
  };
}

// ============ S9: a pinch of metal dust drops into the molten glass ============
function sAccident({ makeStage, start: ST }) {
  const tA = at(9, 'accident') - ST, tS = at(9, 'stumbled') - ST;
  const { scene, f } = workshop(makeStage);
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.12, 0.16, 28, 1, true), new THREE.MeshStandardMaterial({ color: 0x6a4a34, roughness: 1, side: THREE.DoubleSide })); pot.position.set(0.9, 0.98, 0.2); scene.add(shadowAll(pot));
  const stand = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.9, 0.5), archMats().stone); stand.position.set(0.9, 0.45, 0.2); scene.add(shadowAll(stand));
  const melt = new THREE.Mesh(new THREE.CircleGeometry(0.15, 28), new THREE.MeshStandardMaterial({ color: 0xffa040, emissive: 0xff6a20, emissiveIntensity: 1.8 })); melt.rotation.x = -Math.PI / 2; melt.position.set(0.9, 1.03, 0.2); scene.add(melt);
  const man = romanBuilder({ color: 0xc8a878 }); man.root.position.set(1.45, 0, 0.55); man.root.rotation.y = -2.3; scene.add(man.root);
  const R = R0(3);
  const dust = [...Array(40)].map((_, i) => { const s = glowSprite(i % 3 ? 0xe8ecf0 : 0xffd060, 0.012); scene.add(s); return { s, ph: R(), x: (R() - 0.5) * 0.04, z: (R() - 0.5) * 0.04 }; });
  const sparkle = [...Array(14)].map((_, i) => { const s = glowSprite(i % 2 ? 0xffd060 : 0xffffff, 0.03); scene.add(s); return { s, a: R() * 6.28, r: 0.03 + R() * 0.1 }; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      f.update(t);
      standPose(man, t, { spine: [0.15, 0, 0], head: [0.35, 0, 0], neck: [0.1, 0, 0], rSh: [-1.0, 0, -0.1], rEl: [-0.6, 0, 0], lSh: [0.05, 0, 0.2] });
      man.setMood(t > tA ? 'happy' : 'happy'); man.setMouth(t > tA + 0.2 ? 0.6 : 0); man.blink(blinkK(t, [0.7, 2.2])); man.grip(0.2, 0.7);
      man.root.updateMatrixWorld(true);
      const hand = V(0.95, 1.38, 0.24);
      ikArm(man, 'r', hand, wpos(man.root, V(-0.6, 0.2, 0.2)), V(0, 1, 0));
      dust.forEach(({ s, ph, x, z }) => { const a = ((t - tS + 0.2) * 0.9 + ph) % 1; const on = t > tS - 0.2 && t < tA + 0.8; s.visible = on; if (!on) return; s.position.set(hand.x + x, hand.y - 0.05 - a * 0.32, hand.z + z); s.material.opacity = 0.9; });
      sparkle.forEach(({ s, a, r }, i) => { const k = range(t, tA - 0.1, tA + 0.8); s.visible = k > 0 && k < 1; s.position.set(0.9 + Math.cos(a) * r * k * 2, 1.05 + k * 0.15 * (i % 3), 0.2 + Math.sin(a) * r * k * 2); s.material.opacity = 1 - k; });
      melt.material.emissive.setRGB(1, 0.42 - 0.2 * range(t, tA, tA + 0.6), 0.12);
      const k = easeInOut(range(t, 0, 3.0));
      const pos = [lerp(0.2, 0.35, k), lerp(1.75, 1.7, k), lerp(2.6, 2.3, k)], look = [lerp(1.05, 1.1, k), lerp(1.2, 1.15, k), 0.3];
      place(c, pos, look);
      return { bloom: 0.8, warm: 1.3, dof: dofTo(pos, look, 0.003, 0.008) };
    },
  };
}

// ============ S10: a drop lands on a nano-cup sensor chip, colour spreads green -> red ============
function sSensor({ makeStage, start: ST }) {
  const tC = at(10, 'changing') - ST, tD = at(10, 'dna') - ST;
  const scene = makeStage({ shadowSize: 0.4, sunDir: [-1.2, 3, 2], sun: 2.2 });
  skyTint(scene, 0xdde4ea, 0xc8d0d8, 0xb4bec8, 0x9aa4ae);
  const bench = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), new THREE.MeshStandardMaterial({ color: 0x2a2e33, roughness: 0.4 })); bench.rotation.x = -Math.PI / 2; bench.receiveShadow = true; scene.add(bench);
  const chip = sensorChip(); chip.position.y = 0.002; scene.add(chip);
  const pp = pipette(); scene.add(pp);
  const drop = new THREE.Mesh(new THREE.SphereGeometry(0.006, 16, 12), new THREE.MeshPhysicalMaterial({ color: 0xeef8ff, roughness: 0.02, transmission: 0.8, transparent: true, opacity: 0.85 })); scene.add(drop);
  const puddle = new THREE.Mesh(new THREE.CircleGeometry(1, 32), new THREE.MeshPhysicalMaterial({ color: 0xeef8ff, roughness: 0.02, transmission: 0.6, transparent: true, opacity: 0.5 })); puddle.rotation.x = -Math.PI / 2; puddle.position.y = 0.0062; scene.add(puddle);
  fillLight(scene, [0.4, 0.6, 1], 0.8, 0xf4f8ff);
  const tDrop = tD - 0.3;
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      pp.position.set(0.0, lerp(0.12, 0.04, easeInOut(range(t, 0, tDrop - 0.3))), -0.0); pp.rotation.z = 0.15;
      const fall = range(t, tDrop - 0.3, tDrop);
      drop.visible = t > tDrop - 0.35 && t < tDrop; drop.position.set(0.0 + 0.006, lerp(0.035, 0.008, fall * fall), 0);
      const r = easeOut(range(t, tDrop, tDrop + 0.5)) * 0.03;
      puddle.visible = r > 0.001; puddle.scale.setScalar(r + 1e-4);
      chip.wave(0, 0, easeInOut(range(t, tDrop + 0.1, tDrop + 1.6)) * 0.24);
      const k = easeInOut(range(t, 0, 4.0));
      const pos = [lerp(0.08, 0.16, k), lerp(0.14, 0.3, k), lerp(0.2, 0.32, k)], look = [0, 0.01, 0];
      place(c, pos, look);
      return { bloom: 0.45, warm: 0.95, sat: 1.1, dof: dofTo(pos, look, 0.006, 0.006) };
    },
  };
}
// ============ S11: back to the cup, glowing red, slow push ============
function sEnd({ makeStage }) {
  const { scene, cup, sp } = museum(makeStage);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      const k = 0.5 + 0.5 * Math.sin(Math.min(t, 2.4) * 1.3 - 1.57);
      cup.setLit(easeInOut(range(t, 0.2, 1.4))); sp.intensity = 18 * (1 - 0.75 * easeInOut(range(t, 0.2, 1.4)));
      cup.rotation.y = 4.0 + t * 0.15;
      const kc = easeOut(range(t, 0, 3.0));
      place(c, [lerp(0.25, 0.1, kc), lerp(1.2, 1.14, kc), lerp(0.75, 0.5, kc)], [0, 1.1, 0]);
      return { bloom: 1.0, warm: 1.05 };
    },
  };
}

// ============ timeline ============
const cJ = at(10, 'just') - 0.06;
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sJade, 'jade'],
  [ls(2), ls(3), sRuby, 'ruby'],
  [ls(3), ls(4), sWorkshop, 'workshop'],
  [ls(4), ls(5), sCarving, 'carving'],
  [ls(5), ls(6), sCenturies, 'centuries'],
  [ls(6), ls(7), sEM, 'em'],
  [ls(7), ls(8), sSpecks, 'specks'],
  [ls(8), ls(9), sLight, 'light'],
  [ls(9), ls(10), sAccident, 'accident'],
  [ls(10), cJ + 0.12, sSensor, 'sensor'],
  [cJ + 0.12, DURATION + 1, sEnd, 'end'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
