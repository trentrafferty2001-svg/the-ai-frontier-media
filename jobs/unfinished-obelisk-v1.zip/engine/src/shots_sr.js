// Sticky-rice mortar reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { splash2 } from './farm2.js';
import { mountains, trees, ringSpots, birds, waterMaterial } from './world.js';
import { glowSprite } from './props.js';
import { riceBasket } from './props60.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, engineer, quicklimeTrough, shadowAll } from './rome.js';
import { brickMat, cityWall, soupPot, bowl, crystalField, tombMound, archBridge, greatWall, bulldozer, mingWorker, chemist } from './rice.js';
import { VO } from './vo_sr.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(9) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This *wall*', 2], ['is held together', 3], ['with *rice*', 2]],
  [['Not rice', 2], ['*grains*', 1], ['Rice *soup*', 2]],
  [['About', 1], ['*1,500 years*', 3], ['ago', 1], ['Chinese builders', 2], ['began cooking', 2], ['*sticky rice*', 2], ['into a', 2], ['thick *soup*', 2]],
  [['They stirred it', 3], ['into', 1], ['*slaked lime*', 2], ['the usual', 2], ['*mortar*', 1]],
  [['In *2010*', 3], ['*chemists*', 1], ['found the', 2], ['*secret*', 1], ['a *starch*', 2], ['in sticky rice', 3], ['called', 1], ['*amylopectin*', 1]],
  [['It makes', 2], ['the lime grow', 3], ['into tiny', 2], ['*tightly packed*', 2], ['*crystals*', 1], ['instead of', 2], ['*loose* ones', 2]],
  [['So the mortar', 3], ['is *stronger*', 2], ['and lets in', 3], ['less *water*', 2]],
  [['*Ming dynasty*', 2], ['builders', 1], ['used it in', 3], ['city *walls*', 2], ['*tombs*', 1], ['*bridges*', 1], ['and parts of', 3], ['the *Great Wall*', 3]],
  [['One Ming tomb', 3], ['built with it', 3], ['was *reportedly*', 2], ['too strong', 2], ['for a', 2], ['*bulldozer*', 1]],
  [['*Restorers*', 1], ['still use it', 3], ['to repair', 2], ['old buildings', 2], ['*today*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;

// ============ shared: Chinese countryside ============
function chinaLand(scene, { seed = 1, groundC = 0x7e8450, treesN = 30, rT = [40, 110] } = {}) {
  const gm = new THREE.MeshStandardMaterial({ color: groundC, roughness: 1, bumpMap: fabricTexture(23 + seed), bumpScale: 4 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 64), gm); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 120, rMax: 330, height: 46, seed: 4 + seed, color: 0x5f7448 }));
  if (treesN) scene.add(trees(ringSpots(treesN, rT[0], rT[1], 7 + seed, [0, 0, 0], 0, Math.PI * 2, -0.1), { seed: 5 + seed, scale: 1.5 }));
  return ground;
}
function puffs(scene, n, color, opacity = 0.3) {
  const tex = glowSprite().material.map;
  return [...Array(n)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color, transparent: true, opacity: 0, depthWrite: false })); scene.add(s); return { s, i, o: opacity }; });
}

// ============ S0 hook: low angle on the Ming city wall, mortar joints glow on "rice" ============
function walkers(scene, list) {
  return list.map(([x, z, ry, i]) => { const p = mingWorker(i); p.root.position.set(x, 0, z); p.root.rotation.y = ry; scene.add(p.root); return p; });
}
function walkPose(p, t, ph = 0) {
  const s = Math.sin(t * 6 + ph);
  standPose(p, t, { lHip: [s * 0.35, 0, 0.07], rHip: [-s * 0.35, 0, -0.07], lKn: [Math.max(0, -s) * 0.5, 0, 0], rKn: [Math.max(0, s) * 0.5, 0, 0], lSh: [-s * 0.3, 0, 0.16], rSh: [s * 0.3, 0, -0.16] });
  p.setMood('happy'); p.setMouth(0); p.blink(blinkK(t, [1.1 + ph]));
}
function sHook({ makeStage, start: ST }) {
  const tR = at(0, 'rice') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.55, 0.38, 0.74], fog: 0.0025, shadowSize: 14, envI: 0.95, cloud: 0.3 });
  chinaLand(scene, { seed: 2, treesN: 24, rT: [30, 90] });
  const w = cityWall({ len: 70, h: 12, d: 8 }); w.position.set(0, 0, -4); scene.add(w);
  const people = walkers(scene, [[-3.5, 3.2, 0.2, 0], [2.6, 5.5, Math.PI - 0.3, 1]]);
  fillLight(scene, [-0.4, 0.4, 1], 0.6, 0xffe0bc);
  const b = birds(4, { from: [-30, 20, -10], to: [30, 24, -16], spread: 5, speed: 0.06, scale: 1.4, seed: 2 }); scene.add(b);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      b.update(t);
      w.face.setGlow(1.8 * easeOut(range(t, tR - 0.15, tR + 0.25)) * (0.85 + 0.15 * Math.sin(t * 8)));
      people.forEach((p, i) => { walkPose(p, t, i * 1.7); p.root.position.z = (i ? 5.5 - t * 0.5 : 3.2 - t * 0.45); });
      const k = easeInOut(range(t, 0, 2.7));
      const pos = [lerp(-8.5, -6.6, k), lerp(1.1, 1.5, k), lerp(12, 4.6, k)], look = [lerp(-3, -5.2, k), lerp(8.0, 3.6, k), 0];
      place(c, pos, look, 0.03);
      return { bloom: 0.55 + w.face.emissiveIntensity * 0.15, flare: 0.8, warm: 1.2 };
    },
  };
}

// ============ S1: a bowl of grains, then milky rice soup rises over them ============
function kitchenStage(makeStage) {
  const scene = makeStage({ shadowSize: 0.6, sunDir: [-1.2, 2.4, 2.2], sun: 2.4 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2e2620); u.mid.value.set(0x4a3a2c); u.horizon.value.set(0x5e4a36); u.floorC.value.set(0x2a2018);
  const table = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), new THREE.MeshStandardMaterial({ color: 0x5a3e28, roughness: 0.75, bumpMap: fabricTexture(3), bumpScale: 2 })); table.rotation.x = -Math.PI / 2; table.receiveShadow = true; scene.add(table);
  fillLight(scene, [0.8, 0.5, 0.6], 0.5, 0xffc890);
  return scene;
}
function sBowl({ makeStage, start: ST }) {
  const tS = at(1, 'rice', 1) - ST;
  const scene = kitchenStage(makeStage);
  const r = 0.12;
  const bw = bowl({ r, grains: true, soup: true }); scene.add(bw);
  bw.soup.material.color.set(0xf3efe2); bw.soup.material.roughness = 0.25; bw.soup.material.bumpMap = fabricTexture(41); bw.soup.material.bumpScale = 0.6;
  // a few spare grains and a pair of chopsticks on the table
  const gm = new THREE.MeshStandardMaterial({ color: 0xf6f4ec, roughness: 0.5 });
  const RR = R0(9);
  for (let i = 0; i < 24; i++) { const g = new THREE.Mesh(new THREE.SphereGeometry(1, 8, 6), gm); g.scale.set(0.004, 0.004, 0.011); const a = RR() * 6.28, d = 0.17 + RR() * 0.08; g.position.set(Math.cos(a) * d, 0.004, Math.sin(a) * d); g.rotation.y = RR() * 3; g.castShadow = true; scene.add(g); }
  const wood = new THREE.MeshStandardMaterial({ color: 0x7a4a26, roughness: 0.5 });
  for (const s of [0, 1]) { const ch = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.005, 0.24, 8), wood); ch.rotation.set(0, 0, Math.PI / 2); ch.position.set(0.04 + s * 0.012, 0.005, 0.2); ch.rotation.y = 0.3 + s * 0.05; ch.castShadow = true; scene.add(ch); }
  const steam = puffs(scene, 12, 0xffffff, 0.22);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, tS - 0.3, tS + 0.6));
      // soup disc follows the inner wall of the bowl so it never clips through it
      const y = lerp(0.3 * r, 0.66 * r, k);
      const rad = (0.56 * r + (y - 0.18 * r) / (0.54 * r) * 0.39 * r) * 0.98;
      bw.soup.visible = k > 0.01; bw.soup.position.y = y; bw.soup.scale.setScalar(rad / (r * 0.93));
      bw.grains.scale.y = lerp(1, 0.55, k);
      steam.forEach(({ s, i, o }) => { const a = ((t * 0.35 + i / 12) % 1); s.visible = k > 0.2; s.position.set(Math.sin(i * 2.1) * 0.05, r * 0.7 + a * 0.22, Math.cos(i * 1.3) * 0.05); s.scale.setScalar(0.04 + a * 0.1); s.material.opacity = o * k * Math.sin(Math.PI * a); });
      const kc = easeInOut(range(t, 0, 2.2));
      const pos = [lerp(0.05, 0.02, kc), lerp(0.3, 0.24, kc), lerp(0.34, 0.27, kc)], look = [0, 0.06, 0];
      place(c, pos, look);
      return { bloom: 0.4, warm: 1.25, dof: dofTo(pos, look, 0.01, 0.008) };
    },
  };
}

// ============ S2: two Ming workers cook sticky-rice soup in a big iron pot ============
function yardStage(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.55, 0.6, 0.55], fog: 0.004, shadowSize: 2.6, envI: 0.9, cloud: 0.35, ...opts });
  chinaLand(scene, { seed: 7, groundC: 0x8e8058 });
  const w = cityWall({ len: 40, h: 9, d: 6, gate: false }); w.position.set(-4, 0, -16); w.rotation.y = 0.3; scene.add(w);
  fillLight(scene, [0.6, 0.4, 0.9], 0.6);
  return scene;
}
function paddle() {
  const A = archMats(); const g = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.02, 1.3, 10), A.wood); pole.position.y = 0.65; g.add(pole);
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.22, 0.02), A.wood); blade.position.y = 0.0; g.add(blade);
  return shadowAll(g);
}
function sCook({ makeStage, start: ST }) {
  const scene = yardStage(makeStage);
  const pot = soupPot({ r: 0.55 }); pot.position.set(0, 0.38, 0); scene.add(pot);
  const a = mingWorker(0); a.root.position.set(0.95, 0, -0.1); a.root.rotation.y = -Math.PI / 2 - 0.25; scene.add(a.root);
  const b = mingWorker(1); b.root.position.set(-0.9, 0, -0.75); b.root.rotation.y = 0.75; scene.add(b.root);
  const bas = riceBasket(); bas.scale.setScalar(0.9); scene.add(bas);
  const pd = paddle(); scene.add(pd);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      pot.update(t);
      // stirring: paddle blade circles inside the pot, pole leans toward the stirrer
      const ang = t * 2.4;
      const bx = Math.cos(ang) * 0.22, bz = Math.sin(ang) * 0.22, by = 0.38 + 0.3;
      standPose(a, t, { spine: [0.3, 0, 0], chest: [0.1, 0, 0], neck: [0.1, 0, 0], head: [0.3, 0, 0] });
      a.setMood('happy'); a.setMouth(0); a.blink(blinkK(t, [0.8, 3.1])); a.grip(0.95, 0.95);
      a.root.updateMatrixWorld(true);
      const topP = V(0.55, 1.6, -0.05);
      const dir = topP.clone().sub(V(bx, by, bz)).normalize();
      pd.position.set(bx, by, bz); pd.quaternion.setFromUnitVectors(V(0, 1, 0), dir);
      pd.updateMatrixWorld(true);
      ikArm(a, 'l', wpos(pd, V(0, 1.05, 0)), wpos(a.root, V(0.6, 0.8, 0.2)), V(0, 1, 0));
      ikArm(a, 'r', wpos(pd, V(0, 0.75, 0)), wpos(a.root, V(-0.6, 0.5, 0.2)), V(0, 1, 0));
      // second worker holds a basket of rice against the hip
      standPose(b, t, { head: [0.25, -0.2, 0], neck: [0.1, 0, 0] });
      b.setMood('happy'); b.setMouth(0); b.blink(blinkK(t, [1.6])); b.grip(0.9, 0.9);
      b.root.updateMatrixWorld(true);
      const bp = wpos(b.root, V(0, 0.95, 0.38)); bas.position.copy(bp); bas.rotation.set(0, b.root.rotation.y, 0); bas.updateMatrixWorld(true);
      ikArm(b, 'l', wpos(bas, V(0.15, 0.06, 0)), wpos(b.root, V(0.8, 0.3, 0)), V(0, 1, 0));
      ikArm(b, 'r', wpos(bas, V(-0.15, 0.06, 0)), wpos(b.root, V(-0.8, 0.3, 0)), V(0, 1, 0));
      const k = easeInOut(range(t, 0, 5.6));
      const pos = [lerp(-0.5, 0.2, k), lerp(1.95, 1.85, k), lerp(3.9, 3.2, k)], look = [lerp(0.1, 0.2, k), 1.05, -0.2];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.1, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}

// ============ S3: the soup is tipped into a trough of lime ============
function bucketMesh() {
  const A = archMats(); const g = new THREE.Group();
  const b = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.09, 0.2, 20, 1, true), A.wood.clone()); b.material.side = THREE.DoubleSide; g.add(b);
  const bot = new THREE.Mesh(new THREE.CircleGeometry(0.09, 20), A.wood); bot.rotation.x = Math.PI / 2; bot.position.y = -0.1; g.add(bot);
  for (const y of [-0.06, 0.06]) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.105 - y * 0.1, 0.006, 6, 24), new THREE.MeshStandardMaterial({ color: 0x3a3a3a, metalness: 0.6, roughness: 0.4 })); r.rotation.x = Math.PI / 2; r.position.y = y; g.add(r); }
  const w = new THREE.Mesh(new THREE.CircleGeometry(0.1, 20), new THREE.MeshStandardMaterial({ color: 0xf0ece0, roughness: 0.3 })); w.rotation.x = -Math.PI / 2; w.position.y = 0.06; g.add(w); g.userData.soup = w;
  return shadowAll(g);
}
function sLime({ makeStage, start: ST }) {
  const tL = at(3, 'slaked') - ST, tM = at(3, 'mortar') - ST;
  const scene = yardStage(makeStage, { sunDir: [-0.4, 0.55, 0.7] });
  const tr = quicklimeTrough(); scene.add(tr);
  let troughWater = null; tr.traverse(o => { if (o.isMesh && o.material.isMeshPhysicalMaterial) troughWater = o; });
  const man = mingWorker(2); man.root.position.set(-0.2, 0, -0.6); man.root.rotation.y = 0.65; scene.add(man.root);
  const bk = bucketMesh(); scene.add(bk);
  const stream = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.014, 1, 10, 1, true), new THREE.MeshStandardMaterial({ color: 0xf2eee2, roughness: 0.25 })); scene.add(stream);
  const sp = splash2(0.3, 3); scene.add(sp);
  // brick courses waiting for the mortar
  const bm = brickMat(1.2, 0.5);
  const wall = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.55, 0.36), bm); wall.position.set(-1.1, 0.275, 0.3); wall.rotation.y = 0.5; scene.add(shadowAll(wall));
  const c = cam(36);
  const tPour = 0.25;
  return {
    scene, camera: c,
    update(t) {
      const tilt = easeInOut(range(t, tPour - 0.2, tPour + 0.35)) * 1.6 - easeIn(range(t, tM - 0.2, tM + 0.4)) * 0.8;
      standPose(man, t, { spine: [0.25, 0, 0], chest: [0.1, 0, 0], neck: [-0.15, 0, 0], head: [-0.1, -0.35, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.6, 2.4])); man.grip(0.85, 0.85);
      man.root.updateMatrixWorld(true);
      const bp = wpos(man.root, V(0.0, 1.15, 0.5));
      bk.position.copy(bp); bk.quaternion.copy(man.root.quaternion).multiply(new THREE.Quaternion().setFromAxisAngle(V(1, 0, 0), tilt)); bk.updateMatrixWorld(true);
      ikArm(man, 'l', wpos(bk, V(0.11, 0.0, 0)), wpos(man.root, V(0.8, 0.4, 0)), V(0, 0, 1));
      ikArm(man, 'r', wpos(bk, V(-0.11, -0.05, 0)), wpos(man.root, V(-0.8, 0.4, 0)), V(0, 0, 1));
      const lip = wpos(bk, V(0, 0.1, 0.1));
      const pouring = t > tPour + 0.2 && t < tM - 0.05;
      stream.visible = pouring; sp.visible = pouring;
      const level = easeOut(range(t, tPour + 0.2, tM));
      const yb = 0.03 + level * 0.1;
      if (pouring) { stream.position.set(lip.x, (lip.y + yb) / 2, lip.z + 0.02); stream.scale.y = Math.max(0.01, lip.y - yb); sp.position.set(lip.x, yb, lip.z + 0.02); sp.update(((t - tPour) % 0.6)); }
      bk.userData.soup.visible = tilt < 1.2;
      tr.set(level, 0, t);
      if (troughWater) { troughWater.material.color.set(0xeeeae0); troughWater.material.opacity = 0.92; }
      const k = easeInOut(range(t, 0, 3.2));
      const pos = [lerp(2.7, 2.3, k), lerp(1.75, 1.6, k), lerp(2.7, 2.3, k)], look = [lerp(-0.15, -0.1, k), lerp(0.9, 0.8, k), lerp(-0.35, -0.3, k)];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.05, dof: dofTo(pos, look, 0.003, 0.009) };
    },
  };
}

// ============ S4a: 2010 lab, a chemist at a microscope ============
function labStage(makeStage) {
  const scene = makeStage({ shadowSize: 1.6, sunDir: [-1.5, 3, 2], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0xd8dde0); u.mid.value.set(0xc4cbd0); u.horizon.value.set(0xb4bcc2); u.floorC.value.set(0x9aa2a8);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), new THREE.MeshStandardMaterial({ color: 0x9aa0a4, roughness: 0.6 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(12, 5), new THREE.MeshStandardMaterial({ color: 0xdfe4e6, roughness: 0.9 })); wall.position.set(0, 2.5, -1.6); wall.receiveShadow = true; scene.add(wall);
  const top = new THREE.MeshStandardMaterial({ color: 0x2a2e33, roughness: 0.4 }), cab = new THREE.MeshStandardMaterial({ color: 0xe8ecee, roughness: 0.7 });
  const bench = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.05, 0.8), top); bench.position.set(0, 0.92, -0.9); scene.add(bench);
  const body = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.88, 0.76), cab); body.position.set(0, 0.45, -0.9); scene.add(body);
  // shelf with bottles
  const shelf = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.04, 0.3), cab); shelf.position.set(0, 1.75, -1.42); scene.add(shelf);
  const glass = new THREE.MeshPhysicalMaterial({ color: 0xe8f4f6, roughness: 0.05, transmission: 0.6, transparent: true, opacity: 0.55 });
  const brown = new THREE.MeshStandardMaterial({ color: 0x6a3a14, roughness: 0.2 });
  for (let i = 0; i < 9; i++) { const h = 0.16 + (i % 3) * 0.05; const bt = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, h, 16), i % 2 ? glass : brown); bt.position.set(-1.3 + i * 0.32, 1.77 + h / 2, -1.42); scene.add(bt); }
  // flasks on the bench
  for (const [x, col] of [[-1.1, 0xbfe6ff], [-0.85, 0xf4eedc], [1.0, 0xc8f0c0]]) {
    const f = new THREE.Mesh(new THREE.LatheGeometry([[0, 0], [0.09, 0], [0.09, 0.02], [0.03, 0.16], [0.03, 0.24], [0, 0.24]].map(([a, b]) => new THREE.Vector2(a, b)), 24), glass); f.position.set(x, 0.945, -0.8); scene.add(f);
    const liq = new THREE.Mesh(new THREE.LatheGeometry([[0, 0], [0.085, 0], [0.085, 0.02], [0.05, 0.09], [0, 0.09]].map(([a, b]) => new THREE.Vector2(a, b)), 24), new THREE.MeshStandardMaterial({ color: col, roughness: 0.2, transparent: true, opacity: 0.85 })); liq.position.set(x, 0.948, -0.8); scene.add(liq);
  }
  fillLight(scene, [0.5, 0.6, 1], 0.7, 0xf4f8ff);
  shadowAll(scene);
  return scene;
}
function microscope() {
  const g = new THREE.Group();
  const blk = new THREE.MeshStandardMaterial({ color: 0x1e2226, roughness: 0.35, metalness: 0.4 }), wht = new THREE.MeshStandardMaterial({ color: 0xeef0f0, roughness: 0.4 }), chrome = new THREE.MeshStandardMaterial({ color: 0xc8ccd0, roughness: 0.2, metalness: 0.9 });
  const base = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.04, 0.26), wht); base.position.y = 0.02; g.add(base);
  const arm = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.32, 0.07), wht); arm.position.set(0, 0.2, -0.09); arm.rotation.x = 0.12; g.add(arm);
  const stage = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.012, 0.14), blk); stage.position.set(0, 0.14, 0.0); g.add(stage);
  const slide = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.003, 0.025), new THREE.MeshStandardMaterial({ color: 0xf0eee4, roughness: 0.2 })); slide.position.set(0, 0.148, 0.0); g.add(slide);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.1), wht); head.position.set(0, 0.36, -0.04); g.add(head);
  const obj = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.01, 0.07, 14), chrome); obj.position.set(0, 0.3, 0.0); g.add(obj);
  for (const s of [-1, 1]) { const ep = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.013, 0.09, 14), blk); ep.position.set(s * 0.022, 0.42, 0.0); ep.rotation.x = -0.6; g.add(ep); }
  const knob = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.1, 18), blk); knob.rotation.z = Math.PI / 2; knob.position.set(0, 0.13, -0.09); g.add(knob);
  const light = new THREE.Mesh(new THREE.CircleGeometry(0.012, 16), new THREE.MeshBasicMaterial({ color: 0xfff6d0 })); light.rotation.x = -Math.PI / 2; light.position.set(0, 0.041, 0); g.add(light);
  return shadowAll(g);
}
function sLab({ makeStage, start: ST }) {
  const tS = at(4, 'secret') - ST;
  const scene = labStage(makeStage);
  const ms = microscope(); ms.position.set(0.1, 0.945, -0.85); scene.add(ms);
  const man = chemist(); man.root.position.set(0.1, 0, -0.18); man.root.rotation.y = Math.PI; scene.add(man.root);
  const dish = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.012, 24), new THREE.MeshPhysicalMaterial({ color: 0xf2f0e6, roughness: 0.1, transmission: 0.5, transparent: true, opacity: 0.7 })); dish.position.set(-0.35, 0.95, -0.75); scene.add(dish);
  const lump = new THREE.Mesh(new THREE.IcosahedronGeometry(0.035, 2), new THREE.MeshStandardMaterial({ color: 0xd8d2c2, roughness: 1 })); lump.scale.y = 0.6; lump.position.set(-0.35, 0.97, -0.75); scene.add(lump);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const lookUp = easeInOut(range(t, tS - 0.45, tS - 0.05));
      standPose(man, t, { spine: [lerp(0.38, 0.12, lookUp), 0, 0], chest: [lerp(0.2, 0.05, lookUp), 0, 0], neck: [lerp(0.25, 0, lookUp), 0, 0], head: [lerp(0.3, -0.05, lookUp), lerp(0, 0.45, lookUp), 0], lSh: [-0.6, 0, 0.3], lEl: [-1.2, 0, 0], rSh: [-0.6, 0, -0.3], rEl: [-1.2, 0, 0] });
      man.setMood(lookUp > 0.5 ? 'happy' : 'happy'); man.setMouth(lookUp > 0.5 ? 0.5 : 0); man.blink(blinkK(t, [0.7])); man.grip(0.6, 0.6);
      const k = easeInOut(range(t, 0, 3.0));
      const pos = [lerp(1.4, 1.15, k), lerp(1.45, 1.4, k), lerp(0.8, 0.55, k)], look = [lerp(0.05, 0.1, k), lerp(1.15, 1.25, k), -0.55];
      place(c, pos, look);
      return { bloom: 0.35, warm: 0.85, sat: 1.0, dof: dofTo(pos, look, 0.0025, 0.008) };
    },
  };
}
// ============ S4b: a branched starch molecule (amylopectin) grows out of the dark ============
function darkStage(makeStage, col = 0x10141c) {
  const scene = makeStage({ shadowSize: 1, sunDir: [-1, 2, 2], sun: 1.6 });
  const u = scene.userData.sky.material.uniforms; const cc = new THREE.Color(col);
  u.top.value.copy(cc); u.mid.value.copy(cc).multiplyScalar(1.3); u.horizon.value.copy(cc).multiplyScalar(1.6); u.floorC.value.copy(cc);
  scene.children.forEach(o => { if (o.isMesh && o.material && o.material.isShadowMaterial) o.visible = false; });
  return scene;
}
function sStarch({ makeStage, start: ST }) {
  const tA = at(4, 'amylopectin') - ST;
  const scene = darkStage(makeStage);
  const RR = R0(17);
  // glucose units as glowing beads along a branching tree
  const nodes = []; const links = [];
  const grow = (p, dir, depth, d0, n) => {
    let q = p.clone(), dv = dir.clone();
    for (let i = 0; i < n; i++) {
      dv.applyAxisAngle(V(0, 0, 1), (RR() - 0.5) * 0.35).applyAxisAngle(V(1, 0, 0), (RR() - 0.5) * 0.25);
      const nq = q.clone().addScaledVector(dv, 0.085);
      nodes.push({ p: nq, d: d0 + i * 0.035 }); links.push({ a: q.clone(), b: nq.clone(), d: d0 + i * 0.035 });
      if (depth < 3 && i > 1 && i % 4 === 2) { const side = dv.clone().applyAxisAngle(V(0, 0, 1), (RR() > 0.5 ? 1 : -1) * (0.7 + RR() * 0.4)); grow(nq, side, depth + 1, d0 + i * 0.035, Math.max(4, n - 4)); }
      q = nq;
    }
  };
  grow(V(0, -0.95, 0), V(0, 1, 0), 0, 0, 22);
  const nm = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 16, 12), new THREE.MeshStandardMaterial({ color: 0xfff1c8, emissive: 0xffc860, emissiveIntensity: 0.9, roughness: 0.3 }), nodes.length); scene.add(nm);
  const lm = new THREE.InstancedMesh(new THREE.CylinderGeometry(1, 1, 1, 6), new THREE.MeshStandardMaterial({ color: 0xffe8b0, emissive: 0xc89040, emissiveIntensity: 0.6 }), links.length); scene.add(lm);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  const maxD = Math.max(...nodes.map(n => n.d));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const g = lerp(0.25, 1, easeOut(range(t, 0, tA + 0.6))) * maxD + 0.02;
      nodes.forEach((n, i) => { const k = clamp((g - n.d) / 0.06); m4.compose(n.p, q.identity(), V(1, 1, 1).multiplyScalar(0.026 * k + 1e-5)); nm.setMatrixAt(i, m4); });
      links.forEach((l, i) => { const k = clamp((g - l.d) / 0.06); const mid = l.a.clone().lerp(l.b, 0.5); q.setFromUnitVectors(V(0, 1, 0), l.b.clone().sub(l.a).normalize()); m4.compose(mid, q, V(0.008 * k + 1e-5, 0.085 * k + 1e-5, 0.008 * k + 1e-5)); lm.setMatrixAt(i, m4); });
      nm.instanceMatrix.needsUpdate = lm.instanceMatrix.needsUpdate = true;
      const a = t * 0.25;
      place(c, [Math.sin(a) * 3.2, 0.1, Math.cos(a) * 3.2], [0, 0.05, 0]);
      return { bloom: 1.0, warm: 1.0, sat: 1.1 };
    },
  };
}

// ============ S5: tight packed crystals (top) vs loose ones (bottom) ============
function sCrystals({ makeStage, start: ST }) {
  const tT = at(5, 'tightly') - ST, tL = at(5, 'loose') - ST;
  const scene = darkStage(makeStage, 0x0c0e12);
  const tight = crystalField({ tight: true, w: 1.5, h: 1.25, seed: 7 }); tight.position.set(0, 0.72, 0); scene.add(tight);
  const loose = crystalField({ tight: false, w: 1.5, h: 1.25, seed: 9 }); loose.position.set(0, -0.72, 0); scene.add(loose);
  // thin frames around each sample
  const fm = new THREE.MeshStandardMaterial({ color: 0x9aa4ae, metalness: 0.7, roughness: 0.3 });
  for (const y of [0.72, -0.72]) for (const [w, h, x, yy] of [[1.56, 0.03, 0, 0.64], [1.56, 0.03, 0, -0.64], [0.03, 1.31, 0.765, 0], [0.03, 1.31, -0.765, 0]]) { const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.03), fm); b.position.set(x, y + yy, 0.0); scene.add(b); }
  fillLight(scene, [0.2, 0.3, 1], 1.2, 0xe8f4ff);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      tight.grow(easeOut(range(t, tT - 0.9, tT + 0.7)));
      loose.grow(easeOut(range(t, tL - 0.6, tL + 0.6)));
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(0.25, -0.1, k), lerp(0.25, 0.0, k), lerp(4.6, 4.3, k)], [0, lerp(0.15, 0.0, k), 0]);
      return { bloom: 0.45, warm: 0.85, sat: 1.05 };
    },
  };
}

// ============ S6: rain: the rice-mortar wall sheds water, the plain-lime wall soaks it up ============
function sRain({ makeStage, start: ST }) {
  const tW = at(6, 'water') - ST, tS = at(6, 'stronger') - ST;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.3, 0.7, 0.6], fog: 0.012, shadowSize: 1.2, envI: 0.6, cloud: 0.9 });
  chinaLand(scene, { seed: 11, groundC: 0x5e6440, treesN: 18, rT: [12, 50] });
  const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.12, 0.5), archMats().stone); plinth.position.set(0, 0.06, 0); scene.add(shadowAll(plinth));
  const good = brickMat(0.9, 0.9), bad = brickMat(0.9, 0.9);
  const gW = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.3), good); gW.position.set(-0.36, 0.42, 0); scene.add(shadowAll(gW));
  const bW = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.3), bad); bW.position.set(0.36, 0.42, 0); scene.add(shadowAll(bW));
  // water beads on the good wall
  const RR = R0(4), beadM = new THREE.MeshPhysicalMaterial({ color: 0xdfefff, roughness: 0.02, transmission: 0.7, transparent: true, opacity: 0.8, clearcoat: 1 });
  const beads = [...Array(46)].map(() => { const b = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 8), beadM); const top = RR() < 0.35; b.position.set(-0.36 + (RR() - 0.5) * 0.56, top ? 0.722 : 0.15 + RR() * 0.55, top ? (RR() - 0.5) * 0.26 : 0.152); b.userData.s = 0.006 + RR() * 0.008; b.userData.top = top; b.userData.d = RR(); scene.add(b); return b; });
  // dark wet stain that spreads over the bad wall
  const N = 300; const drops = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.0018, 0.0018, 0.07, 4), new THREE.MeshBasicMaterial({ color: 0xd4e4f2, transparent: true, opacity: 0.55 }), N); scene.add(drops);
  const D = [...Array(N)].map((_, i) => [Math.sin(i * 12.9898) * 1.3, Math.cos(i * 78.233) * 0.9 + 0.2, (i * 0.618) % 1]);
  const spl = [0, 1, 2, 3].map(i => { const s = splash2(0.12, 20 + i); scene.add(s); return s; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const soak = easeInOut(range(t, 0.2, tW + 0.3));
      bad.color.setRGB(1, 1, 1).lerp(new THREE.Color(0x5a564e), soak); bad.roughness = lerp(0.92, 0.45, soak);
      beads.forEach(b => { const k = easeOut(range(t, 0.1 + b.userData.d * 1.2, 0.5 + b.userData.d * 1.2)); b.scale.setScalar(b.userData.s * k + 1e-5); if (b.userData.top) b.scale.y *= 0.6; else b.scale.z *= 0.5; });
      const m4 = new THREE.Matrix4();
      D.forEach(([x, z, ph], i) => { const y = 2.2 - ((t * 2.4 + ph) % 1) * 2.4; m4.makeTranslation(x, y, z); drops.setMatrixAt(i, m4); }); drops.instanceMatrix.needsUpdate = true;
      spl.forEach((s, i) => { s.position.set(i < 2 ? -0.5 + i * 0.25 : 0.25 + (i - 2) * 0.22, 0.725, (i % 2) * 0.06 - 0.03); s.update(((t + i * 0.23) % 0.5)); });
      const k = easeInOut(range(t, 0, 3.0));
      const pos = [lerp(0.25, 0.05, k), lerp(0.95, 0.85, k), lerp(2.6, 2.05, k)], look = [0, 0.45, 0];
      place(c, pos, look);
      return { bloom: 0.35, warm: 0.6, sat: 0.95, dof: dofTo(pos, look, 0.003, 0.008) };
    },
  };
}

// ============ S7 montage: city wall / tomb / bridge / Great Wall, cut on the words ============
function sMWall({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.3, 0.74], fog: 0.0025, shadowSize: 16, envI: 0.95, cloud: 0.3 });
  chinaLand(scene, { seed: 3, treesN: 20, rT: [25, 80] });
  const w = cityWall({ len: 90, h: 12, d: 8 }); w.rotation.y = 0.55; scene.add(w);
  const water = new THREE.Mesh(new THREE.PlaneGeometry(200, 14), waterMaterial({ color: 0x2c4a52, opacity: 1, ripple: 1.0 })); water.rotation.x = -Math.PI / 2; water.rotation.z = 0.55; water.position.set(6.5, 0.05, 11); scene.add(water);
  fillLight(scene, [0.4, 0.5, 1], 0.6, 0xffe0bc);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.0));
      place(c, [lerp(26, 22, k), lerp(9, 12, k), lerp(30, 26, k)], [lerp(-2, 2, k), 7, 0]);
      return { bloom: 0.55, flare: 0.9, warm: 1.2 };
    },
  };
}
function tombScene(makeStage, pillars = true) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.5, 0.55, 0.67], fog: 0.004, shadowSize: 9, envI: 0.9, cloud: 0.45 });
  chinaLand(scene, { seed: 13, groundC: 0x7a8048, treesN: 28, rT: [14, 60] });
  const tm = tombMound(); scene.add(tm);
  // spirit-way stone pillars in front
  const st = archMats().stone;
  if (pillars) for (const s of [-1, 1]) for (const z of [9, 13]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.3, 2.4, 12), st); p.position.set(s * 2.6, 1.2, z); scene.add(shadowAll(p)); const cap = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8), st); cap.position.set(s * 2.6, 2.5, z); scene.add(shadowAll(cap)); }
  const path = new THREE.Mesh(new THREE.PlaneGeometry(3, 20), new THREE.MeshStandardMaterial({ color: 0x9a9284, roughness: 1, bumpMap: fabricTexture(5), bumpScale: 3 })); path.rotation.x = -Math.PI / 2; path.position.set(0, 0.01, 15); path.receiveShadow = true; scene.add(path);
  fillLight(scene, [-0.4, 0.5, 1], 0.6);
  return { scene, tm };
}
function sMTomb({ makeStage }) {
  const { scene } = tombScene(makeStage);
  const c = cam(40);
  return { scene, camera: c, update(t) { const k = easeOut(range(t, 0, 1.0)); place(c, [lerp(1.2, 0.6, k), lerp(4.2, 3.8, k), lerp(20, 17.5, k)], [0, 2.4, 3]); return { bloom: 0.5, warm: 1.05 }; } };
}
function sMBridge({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.45, 0.35, 0.82], fog: 0.004, shadowSize: 8, envI: 0.95, cloud: 0.3 });
  chinaLand(scene, { seed: 15, treesN: 26, rT: [24, 70] });
  const riv = new THREE.Mesh(new THREE.PlaneGeometry(9, 200), waterMaterial({ color: 0x2a4a50, opacity: 1, ripple: 1.2 })); riv.rotation.x = -Math.PI / 2; riv.position.y = 0.02; scene.add(riv);
  // cut the river into the bank: two darker bank strips
  const bankM = new THREE.MeshStandardMaterial({ color: 0x5a5236, roughness: 1 });
  for (const s of [-1, 1]) { const bk = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.6, 200), bankM); bk.position.set(s * 4.7, 0.0, 0); scene.add(bk); }
  const br = archBridge({ span: 8, w: 3 }); br.position.set(0, -1.2, 0); scene.add(br);
  fillLight(scene, [-0.4, 0.5, 1], 0.7, 0xffe0bc);
  const c = cam(40);
  return { scene, camera: c, update(t) { const k = easeOut(range(t, 0, 1.0)); place(c, [lerp(-2.5, -2.0, k), lerp(1.7, 1.6, k), lerp(18, 16, k)], [0, 2.4, 0]); return { bloom: 0.6, flare: 0.9, warm: 1.25 }; } };
}
function sMGreat({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.7, 0.25, -0.67], fog: 0.0035, shadowSize: 30, envI: 0.95, cloud: 0.35 });
  chinaLand(scene, { seed: 17, groundC: 0x5e6a3a, treesN: 0 });
  const hillM = new THREE.MeshStandardMaterial({ color: 0x55663a, roughness: 1, bumpMap: fabricTexture(33), bumpScale: 5 });
  const ridge = new THREE.Mesh(new THREE.SphereGeometry(1, 64, 32), hillM); ridge.scale.set(70, 16, 22); ridge.position.y = -4; ridge.receiveShadow = true; scene.add(ridge);
  const pts = []; for (let i = 0; i <= 24; i++) { const x = -56 + i * (112 / 24), z = Math.sin(x * 0.06) * 2.5; const y = -4 + 16 * Math.sqrt(Math.max(0, 1 - (x / 70) ** 2 - (z / 22) ** 2)); pts.push([x, y, z]); }
  const gw = greatWall(pts, { w: 4.0, h: 5 }); scene.add(gw);
  scene.add(trees(ringSpots(60, 25, 70, 31, [0, 0, 0], 0, Math.PI * 2, 0), { seed: 9, scale: 1.6 }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  const c = cam(42);
  return { scene, camera: c, update(t) { const k = easeInOut(range(t, 0, 1.4)); place(c, [lerp(-74, -68, k), lerp(16, 17, k), lerp(16, 14, k)], [lerp(-10, 0, k), 10, 0]); return { bloom: 0.6, flare: 1.0, warm: 1.25 }; } };
}

// ============ S8: a bulldozer strains against the tomb front; the tomb doesn't budge ============
function sDozer({ makeStage, start: ST }) {
  const tB = at(8, 'bulldozer') - ST, tR = at(8, 'reportedly') - ST;
  const { scene, tm } = tombScene(makeStage, false);
  const dz = bulldozer(); dz.rotation.y = Math.PI / 2; scene.add(dz);
  const smoke = puffs(scene, 18, 0x3a3836, 0.55);
  const dust = puffs(scene, 16, 0xb0a48a, 0.4);
  const c = cam(38);
  const zHit = 8.2;
  return {
    scene, camera: c,
    update(t) {
      // rolls in, hits the front, strains (shudders), rocks back a little, pushes again
      const z = kf(t, [[0, 12.5], [1.0, zHit], [tR, zHit], [tR + 0.5, zHit + 0.35], [tR + 1.0, zHit], [tB + 1.5, zHit]], easeInOut);
      const strain = t > 1.0 ? 1 : 0;
      const sh = strain ? shake(t * 3, 1.6, 4) : [0, 0, 0];
      dz.position.set(0 + sh[0] * 0.03, Math.abs(sh[1]) * 0.02, z);
      dz.rotation.z = strain ? Math.sin(t * 40) * 0.006 : 0;
      dz.rotation.x = strain ? -0.02 - 0.015 * Math.sin(t * 9) : 0;
      dz.updateMatrixWorld(true);
      const stack = wpos(dz, V(0.6, 2.75, 0.5));
      smoke.forEach(({ s, i, o }) => { const a = ((t * (strain ? 0.9 : 0.5) + i / 18) % 1); s.position.set(stack.x + a * 0.6 + Math.sin(i) * 0.1, stack.y + a * 1.8, stack.z + a * 0.5); s.scale.setScalar(0.25 + a * 1.1); s.material.opacity = o * (strain ? 1 : 0.5) * Math.sin(Math.PI * a); });
      dust.forEach(({ s, i, o }) => { const a = ((t * 0.8 + i / 16) % 1); const side = i % 2 ? 1 : -1; s.visible = strain; s.position.set(side * 1.1 + Math.sin(i * 3) * 0.3, 0.2 + a * 0.6, z + 1.4 + a * 0.8); s.scale.setScalar(0.3 + a * 0.9); s.material.opacity = o * Math.sin(Math.PI * a); });
      const k = easeInOut(range(t, 0, 3.6));
      const csh = strain ? shake(t * 2, 0.7, 7) : [0, 0, 0];
      const pos = [lerp(12.5, 11.0, k) + csh[0] * 0.04, lerp(2.4, 2.1, k) + csh[1] * 0.04, lerp(9.5, 9.0, k)], look = [0, 1.5, lerp(7.2, 7.0, k)];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.0 };
    },
  };
}

// ============ S9: a restorer re-points a joint with rice mortar; pull back to the gate ============
function trowel() {
  const g = new THREE.Group();
  const steel = new THREE.MeshStandardMaterial({ color: 0xb8bcc0, metalness: 0.8, roughness: 0.3 });
  const blade = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.17, 3), steel); blade.scale.z = 0.08; blade.rotation.x = Math.PI / 2; blade.position.z = 0.1; g.add(blade);
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.016, 0.1, 10), new THREE.MeshStandardMaterial({ color: 0x8a4a1a, roughness: 0.6 })); handle.rotation.x = Math.PI / 2; handle.position.set(0, 0.03, -0.03); g.add(handle);
  return shadowAll(g);
}
function sRestore({ makeStage, start: ST }) {
  const tT = at(9, 'today') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.5, 0.35, 0.79], fog: 0.0025, shadowSize: 12, envI: 0.95, cloud: 0.3 });
  chinaLand(scene, { seed: 2, treesN: 24, rT: [30, 90] });
  const w = cityWall({ len: 70, h: 12, d: 8 }); w.position.set(0, 0, -4); scene.add(w);
  const man = engineer(); man.root.position.set(-5.5, 0, 0.66); man.root.rotation.y = Math.PI; scene.add(man.root);
  const tw = trowel(); scene.add(tw);
  const hawk = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.012, 0.2), new THREE.MeshStandardMaterial({ color: 0x8a8a8a, roughness: 0.5, metalness: 0.4 })); scene.add(hawk);
  const blob = new THREE.Mesh(new THREE.SphereGeometry(0.05, 14, 10), new THREE.MeshStandardMaterial({ color: 0xece6d6, roughness: 0.8 })); blob.scale.y = 0.5; scene.add(blob);
  // fresh joint line on the wall face that fills as he strokes
  const joint = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.03), new THREE.MeshStandardMaterial({ color: 0xf2ecdc, roughness: 0.8, emissive: 0x403a30, emissiveIntensity: 0.3 })); joint.position.set(-5.5, 1.4, 0.005); scene.add(joint);
  fillLight(scene, [-0.4, 0.4, 1], 0.7, 0xffe0bc);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const stroke = Math.sin(t * 4.2);
      standPose(man, t, { rSh: [-1.15, 0, -0.25], rEl: [-0.7, 0, 0], lSh: [-0.7, 0, 0.15], lEl: [-1.3, 0, 0], head: [0.05, 0.1, 0], spine: [0.05, 0, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.9, 2.6])); man.grip(0.9, 0.95);
      man.root.updateMatrixWorld(true);
      const tip = V(-5.5 + stroke * 0.2, 1.4, 0.03);
      tw.position.set(tip.x, tip.y, tip.z + 0.12); tw.rotation.set(0, Math.PI, 0.1 * stroke); tw.updateMatrixWorld(true);
      ikArm(man, 'r', wpos(tw, V(0, 0.03, -0.06)), wpos(man.root, V(-0.5, -0.4, -0.3)), V(0, 1, 0));
      const hp = wpos(man.root, V(0.32, 1.1, 0.35)); hawk.position.copy(hp); blob.position.set(hp.x, hp.y + 0.02, hp.z);
      ikArm(man, 'l', V(hp.x, hp.y - 0.03, hp.z), wpos(man.root, V(0.7, 0.1, 0.3)), V(0, 1, 0));
      joint.scale.x = clamp(0.3 + t * 0.35, 0, 1);
      const k = easeInOut(range(t, 0.4, tT + 0.9));
      const pos = [lerp(-4.0, -1.0, k), lerp(1.7, 5.5, k), lerp(3.0, 42, k)], look = [lerp(-5.5, -1.0, k), lerp(1.3, 10.5, k), lerp(0.2, -3, k)];
      place(c, pos, look);
      return { bloom: 0.55, flare: 0.8, warm: 1.25, dof: k < 0.3 ? dofTo(pos, look, 0.0025, 0.008) : undefined };
    },
  };
}

// ============ timeline ============
const cA = at(4, 'a') - 0.06;
const cT = at(7, 'tombs') - 0.06, cB = at(7, 'bridges') - 0.06, cG = at(7, 'parts') - 0.06;
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sBowl, 'bowl'],
  [ls(2), ls(3), sCook, 'cook'],
  [ls(3), ls(4), sLime, 'lime'],
  [ls(4), cA + 0.12, sLab, 'lab'],
  [cA + 0.12, ls(5), sStarch, 'starch'],
  [ls(5), ls(6), sCrystals, 'crystals'],
  [ls(6), ls(7), sRain, 'rain'],
  [ls(7), cT + 0.12, sMWall, 'mwall'],
  [cT + 0.12, cB + 0.12, sMTomb, 'mtomb'],
  [cB + 0.12, cG + 0.12, sMBridge, 'mbridge'],
  [cG + 0.12, ls(8), sMGreat, 'mgreat'],
  [ls(8), ls(9), sDozer, 'dozer'],
  [ls(9), DURATION + 1, sRestore, 'restore'],
];
// cut slightly before each sentence so the picture leads the voice
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
