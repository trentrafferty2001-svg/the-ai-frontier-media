// Dujiangyan reel: a diorama of the Min River headworks: fish-mouth levee, inner/outer channels, flying-sand spillway,
// bottle-neck gap, canals on the plain; flow streaks whose split follows the season.
import * as THREE from 'three';
import { fabricTexture } from './textures.js';
import { shadowAll, canvasTex, romanBuilder } from './rome.js';
import { mountains, trees, ringSpots, waterMaterial } from './world.js';

const rng = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));

export function landMats() {
  return {
    grass: new THREE.MeshStandardMaterial({ color: 0x6f8a44, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 }),
    stone: new THREE.MeshStandardMaterial({ color: 0x8c8c88, roughness: 0.95, bumpMap: fabricTexture(31), bumpScale: 5 }),
    rock: new THREE.MeshStandardMaterial({ color: 0x6e6a5e, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 6 }),
    field: new THREE.MeshStandardMaterial({ color: 0x8fae4a, roughness: 1, bumpMap: fabricTexture(41), bumpScale: 3 }),
    field2: new THREE.MeshStandardMaterial({ color: 0xb8b45a, roughness: 1, bumpMap: fabricTexture(43), bumpScale: 3 }),
  };
}
function box(mat, x0, x1, z0, z1, h, y0 = -0.6) { const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, h - y0, z1 - z0), mat); m.position.set((x0 + x1) / 2, (h + y0) / 2, (z0 + z1) / 2); m.receiveShadow = m.castShadow = true; return m; }

// forested rocky hill: displaced, flattened sphere, green on top, rock on the steep sides
export function hill(rx, h, rz, seed = 1) {
  const geo = new THREE.IcosahedronGeometry(1, 5), p = geo.attributes.position, col = [];
  const R = rng(seed), ph = [R() * 6, R() * 6, R() * 6];
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const n = 1 + 0.12 * Math.sin(x * 4 + ph[0]) * Math.sin(z * 5 + ph[1]) + 0.06 * Math.sin(y * 9 + ph[2]);
    x *= n; z *= n; y = Math.max(-0.05, y) * n;
    p.setXYZ(i, x * rx, y * h, z * rz);
  }
  geo.computeVertexNormals();
  const nr = geo.attributes.normal; const c = new THREE.Color(), forest = new THREE.Color(0x4a6a34), rockC = new THREE.Color(0x7a7262);
  for (let i = 0; i < p.count; i++) { const steep = 1 - Math.abs(nr.getY(i)); c.copy(forest).lerp(rockC, clamp((steep - 0.45) * 2.5)); col.push(c.r, c.g, c.b); }
  geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 5 }));
  m.castShadow = m.receiveShadow = true;
  return m;
}
// zhulong: a long bamboo basket full of river stones
let ZT = null;
function zhulongTex() {
  if (ZT) return ZT;
  ZT = canvasTex(256, 256, (x) => {
    x.fillStyle = '#5a564e'; x.fillRect(0, 0, 256, 256);
    const R = rng(4); for (let i = 0; i < 90; i++) { const g = 120 + R() * 70 | 0; x.fillStyle = `rgb(${g},${g - 6},${g - 14})`; x.beginPath(); x.ellipse(R() * 256, R() * 256, 8 + R() * 12, 6 + R() * 9, R() * 3, 0, 7); x.fill(); }
    x.strokeStyle = '#c8a860'; x.lineWidth = 7;
    for (let k = -256; k < 512; k += 30) { x.beginPath(); x.moveTo(k, 0); x.lineTo(k + 256, 256); x.stroke(); x.beginPath(); x.moveTo(k + 256, 0); x.lineTo(k, 256); x.stroke(); }
  });
  ZT.wrapS = ZT.wrapT = THREE.RepeatWrapping;
  return ZT;
}
export function zhulong(len = 2.2, r = 0.28) {
  const t = zhulongTex().clone(); t.needsUpdate = true; t.repeat.set(len / 0.8, 2);
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 20, 1), new THREE.MeshStandardMaterial({ map: t, roughness: 0.9, bumpMap: t, bumpScale: 3 }));
  m.rotation.z = Math.PI / 2; m.castShadow = m.receiveShadow = true;
  const g = new THREE.Group(); g.add(m); return g;
}

// fish-mouth levee: pointed nose upstream (z = z0), widening to w, running to z1
function leveeShape(z0, z1, w) {
  const s = new THREE.Shape();
  s.moveTo(0, -z0);
  s.bezierCurveTo(w * 0.35, -z0 - 2, w * 0.5, -z0 - 6, w * 0.5, -z0 - 12);
  s.lineTo(w * 0.5, -z1); s.lineTo(-w * 0.5, -z1); s.lineTo(-w * 0.5, -z0 - 12);
  s.bezierCurveTo(-w * 0.5, -z0 - 6, -w * 0.35, -z0 - 2, 0, -z0);
  return s;
}
export function headworks({ trees: withTrees = true } = {}) {
  const g = new THREE.Group(), M = landMats();
  // water everywhere at y = 0 (land sits on top)
  const water = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), waterMaterial({ color: 0x2f5a5a, opacity: 1, ripple: 1.3 })); water.rotation.x = -Math.PI / 2; water.position.y = 0; g.add(water);
  g.water = water;
  // banks
  g.add(box(M.grass, -200, -11, -200, 30, 1.6));
  g.add(box(M.grass, 11, 200, -200, 200, 1.6));
  // fish-mouth levee (Yuzui), stone faced
  const lev = new THREE.Mesh(new THREE.ExtrudeGeometry(leveeShape(-12, 22, 4.4), { depth: 1.9, bevelEnabled: true, bevelSize: 0.25, bevelThickness: 0.2, bevelSegments: 2, curveSegments: 24 }), M.stone);
  lev.rotation.x = -Math.PI / 2; lev.position.y = -0.6; lev.castShadow = lev.receiveShadow = true; g.add(lev);
  const top = new THREE.Mesh(new THREE.ExtrudeGeometry(leveeShape(-9.5, 21.6, 3.2), { depth: 0.05, bevelEnabled: false, curveSegments: 24 }), M.grass); top.rotation.x = -Math.PI / 2; top.position.y = 1.3; g.add(top);
  // flying-sand spillway: a low weir from z 22 to 30
  const weir = box(M.stone, -2.2, 2.2, 22, 30, 0.25); g.add(weir); g.weir = weir;
  // Lidui rock (cut off from the mountain) and the Yulei mountain; the bottle-neck gap runs between them
  const lidui = hill(3.2, 7, 7.5, 3); lidui.position.set(0.6, 0, 37); g.add(lidui);
  const yulei = hill(9, 12, 11, 5); yulei.position.set(-15, 0, 37); g.add(yulei);
  g.add(box(M.grass, -200, -9, 28, 46, 1.8));
  // the inner channel narrows: walls of the gap
  g.add(box(M.rock, -9, -6.2, 31, 43, 4.0));
  // land between the outer river and the plain below the rock
  g.add(box(M.grass, -2.6, 2.4, 44, 200, 1.2));
  // the plain: fields with canals fanning out from the gap
  const R = rng(9);
  for (let i = 0; i < 9; i++) for (let j = 0; j < 7; j++) {
    const x0 = -6.2 - i * 6.4 - (i > 0 ? 0 : 0), z0 = 47 + j * 6.2;
    if (i === 0 && j === 0) continue;
    const f = box(R() < 0.5 ? M.field : M.field2, x0 - 5.6, x0, z0, z0 + 5.4, 0.9); g.add(f);
  }
  g.add(box(M.grass, -200, -63, 44, 200, 1.0));
  // mountains and trees
  g.add(mountains({ rMin: 120, rMax: 300, height: 60, seed: 6, color: 0x4f6a40, thetaFrom: Math.PI * 0.55, thetaTo: Math.PI * 1.45 }));
  g.add(mountains({ rMin: 140, rMax: 300, height: 30, seed: 8, color: 0x5f7448, thetaFrom: -Math.PI * 0.45, thetaTo: Math.PI * 0.45 }));
  if (withTrees) {
    g.add(trees(ringSpots(40, 0, 60, 3, [-40, 0, -40], 0, Math.PI * 2, 1.6).filter(([x, y, z]) => x < -13), { seed: 4, scale: 1.4 }));
    g.add(trees(ringSpots(40, 0, 60, 5, [40, 0, -10], 0, Math.PI * 2, 1.6).filter(([x]) => x > 13), { seed: 6, scale: 1.4 }));
  }
  g.traverse(o => { if (o.isMesh && o !== water) { o.castShadow = o.castShadow ?? true; } });
  return g;
}

// ---------- flow streaks: white foam dashes moving along the channels ----------
const P_IN = [[-3, -60], [-3.5, -16], [-6.5, -6], [-7.2, 10], [-6.8, 22], [-4.6, 31], [-4.2, 40], [-4.4, 46], [-9, 52], [-20, 58]];
const P_OUT = [[3, -60], [3.5, -16], [6.5, -6], [6.8, 20], [6.5, 45], [6.5, 100]];
const P_SPILL = [[-3, -60], [-3.5, -16], [-6.5, -6], [-7.2, 10], [-5.5, 22], [0, 26], [5.6, 30], [6.5, 45], [6.5, 100]];
function curve(pts) { return new THREE.CatmullRomCurve3(pts.map(([x, z]) => V(x, 0, z))); }
export function flow(n = 520) {
  const C = { in: curve(P_IN), out: curve(P_OUT), spill: curve(P_SPILL) };
  const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.09, 0.02, 0.9), new THREE.MeshBasicMaterial({ color: 0xf2f6f4, transparent: true, opacity: 0.75 }), n);
  const R = rng(13); const D = [...Array(n)].map(() => ({ ph: R(), side: R(), off: (R() - 0.5), r2: R() }));
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), p = V(0, 0, 0), tg = V(0, 0, 0), nrm = V(0, 0, 0);
  // inner: share of streaks taking the inner channel; spill: share of inner ones thrown over the weir; level: water height
  mesh.set = (t, { inner = 0.6, spill = 0, level = 0, speed = 0.05, width = 2.6 } = {}) => {
    D.forEach((d, i) => {
      const goIn = d.side < inner;
      const c = goIn ? (d.r2 < spill ? C.spill : C.in) : C.out;
      const u = (t * speed * (1 + d.r2 * 0.4) + d.ph) % 1;
      c.getPointAt(u, p); c.getTangentAt(u, tg);
      nrm.set(-tg.z, 0, tg.x).normalize();
      const w = width * (goIn && p.z > 30 && p.z < 46 ? 0.45 : 1);
      p.addScaledVector(nrm, d.off * w); p.y = level + 0.03;
      q.setFromUnitVectors(V(0, 0, 1), tg);
      const fade = Math.min(1, u * 12, (1 - u) * 12);
      m4.compose(p, q, V(1, 1, 0.4 + fade * 0.8).multiplyScalar(fade > 0.05 ? 1 : 1e-4)); mesh.setMatrixAt(i, m4);
    });
    mesh.instanceMatrix.needsUpdate = true;
  };
  return mesh;
}

// ---------- people ----------
export function liBing() {
  const h = romanBuilder({ color: 0x2a3a62, skin: 0xd8a878 });
  const cap = new THREE.Group(); cap.position.set(0, 0.12, -0.01); h.j.head.add(cap);
  const blk = new THREE.MeshStandardMaterial({ color: 0x15151a, roughness: 0.6 });
  const c1 = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.15, 0.12, 20), blk); cap.add(c1);
  const c2 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.12, 0.16), blk); c2.position.set(0, 0.08, -0.03); cap.add(c2);
  const beard = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.12, 10), new THREE.MeshStandardMaterial({ color: 0x2a2420, roughness: 0.9 })); beard.rotation.x = Math.PI; beard.position.set(0, -0.12, 0.11); h.j.head.add(beard);
  shadowAll(h.root);
  return h;
}
export function scroll() {
  const g = new THREE.Group();
  const paper = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.26), new THREE.MeshStandardMaterial({ color: 0xe8dcb8, roughness: 0.9, side: THREE.DoubleSide, map: canvasTex(256, 196, (x) => { x.fillStyle = '#e8dcb8'; x.fillRect(0, 0, 256, 196); x.strokeStyle = '#3a5a8a'; x.lineWidth = 6; x.beginPath(); x.moveTo(128, 0); x.lineTo(128, 70); x.lineTo(80, 196); x.moveTo(128, 70); x.lineTo(176, 196); x.stroke(); x.fillStyle = '#6a6458'; x.beginPath(); x.moveTo(128, 70); x.lineTo(118, 110); x.lineTo(138, 110); x.fill(); }) }));
  g.add(paper);
  for (const s of [-1, 1]) { const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.3, 10), new THREE.MeshStandardMaterial({ color: 0x5a3a20 })); rod.rotation.z = Math.PI / 2; rod.position.y = s * 0.135; g.add(rod); }
  return g;
}
