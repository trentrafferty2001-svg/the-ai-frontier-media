// Sticky-rice mortar reel: Ming city wall, cooking pot, bowls, crystals, tomb, bridge, Great Wall, bulldozer.
import * as THREE from 'three';
import { canvasTex } from './rome.js';
import { fabricTexture } from './textures.js';
import { romanBuilder, shadowAll } from './rome.js';
import { glowSprite } from './props.js';

const rng = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;

// ---------- brick textures: colour map + a mortar mask used as the emissive map (glows on cue) ----------
let BT = null;
export function brickTex() {
  if (BT) return BT;
  const R = rng(11), cols = 8, rows = 16, W = 512, H = 512, bw = W / cols, bh = H / rows, gap = 5;
  const draw = (x, mask) => {
    x.fillStyle = mask ? '#000' : '#d8d4c8'; x.fillRect(0, 0, W, H);
    for (let r = 0; r < rows; r++) for (let c = -1; c <= cols; c++) {
      const off = (r % 2) * bw / 2, X = c * bw + off, Y = r * bh;
      if (mask) { x.fillStyle = '#000'; } else { const g = 92 + Math.floor(R() * 34); x.fillStyle = `rgb(${g},${g - 2},${g - 6})`; }
      x.fillRect(X + gap / 2, Y + gap / 2, bw - gap, bh - gap);
      if (!mask) { x.fillStyle = 'rgba(0,0,0,0.08)'; for (let k = 0; k < 6; k++) x.fillRect(X + R() * bw, Y + R() * bh, 3, 2); }
    }
    if (mask) { x.globalCompositeOperation = 'source-over'; }
  };
  // mask: white mortar lines on black
  const color = canvasTex(W, H, (x) => draw(x, false));
  const mask = canvasTex(W, H, (x) => { x.fillStyle = '#fff'; x.fillRect(0, 0, W, H); for (let r = 0; r < rows; r++) for (let c = -1; c <= cols; c++) { const off = (r % 2) * bw / 2; x.fillStyle = '#000'; x.fillRect(c * bw + off + gap / 2, r * bh + gap / 2, bw - gap, bh - gap); } });
  for (const t of [color, mask]) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
  BT = { color, mask };
  return BT;
}
// a brick material with its own texture repeat; setGlow(k) lights the mortar lines
export function brickMat(rx, ry, { tint = 0xffffff } = {}) {
  const T = brickTex();
  const c = T.color.clone(), m = T.mask.clone(); c.needsUpdate = m.needsUpdate = true;
  c.repeat.set(rx, ry); m.repeat.set(rx, ry);
  const mat = new THREE.MeshStandardMaterial({ map: c, color: tint, roughness: 0.92, bumpMap: c, bumpScale: 2, emissive: 0xffc860, emissiveMap: m, emissiveIntensity: 0 });
  mat.setGlow = (k) => { mat.emissiveIntensity = k; };
  return mat;
}

// ---------- Ming city wall (Nanjing-style): battered brick face, crenellations, a gate tower ----------
export function cityWall({ len = 60, h = 12, d = 8, gate = true } = {}) {
  const g = new THREE.Group();
  const face = brickMat(len / 3.2, h / 3.2);
  const body = new THREE.Mesh(new THREE.BoxGeometry(len, h, d), [face, face, new THREE.MeshStandardMaterial({ color: 0x6e6a62, roughness: 1 }), face, face, face]);
  body.position.y = h / 2; g.add(body);
  g.face = face;
  // crenellations (merlons) along the front edge
  const merM = brickMat(0.5, 0.4);
  const n = Math.floor(len / 1.6);
  for (let i = 0; i < n; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.1, 0.6), merM); m.position.set(-len / 2 + 0.8 + i * 1.6, h + 0.55, d / 2 - 0.3); g.add(m); }
  if (gate) {
    // arched gate opening (dark) + a timber gate tower on top
    // arched gate opening: flat dark shape (rectangle + semicircle) just in front of the face
    const sh = new THREE.Shape(); sh.moveTo(-2.4, 0); sh.lineTo(-2.4, 4.0); sh.absarc(0, 4.0, 2.4, Math.PI, 0, true); sh.lineTo(2.4, 0); sh.lineTo(-2.4, 0);
    const door = new THREE.Mesh(new THREE.ShapeGeometry(sh, 32), new THREE.MeshStandardMaterial({ color: 0x14110e, roughness: 1 })); door.position.set(0, 0, d / 2 + 0.03); g.add(door);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(2.55, 0.18, 8, 40, Math.PI), new THREE.MeshStandardMaterial({ color: 0x9a948a, roughness: 0.95 })); rim.position.set(0, 4.0, d / 2 + 0.05); g.add(rim);
    const tower = new THREE.Group(); tower.position.set(0, h, 0); g.add(tower);
    const red = new THREE.MeshStandardMaterial({ color: 0x8e2a1e, roughness: 0.7 }), roof = new THREE.MeshStandardMaterial({ color: 0x5f7074, roughness: 0.6, emissive: 0x2a3234, emissiveIntensity: 1 });
    const hall = new THREE.Mesh(new THREE.BoxGeometry(9, 3.2, 5), red); hall.position.y = 1.6; tower.add(hall);
    for (let i = -4; i <= 4; i += 2) { const col = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 3.2, 10), red); col.position.set(i * 1.05, 1.6, 2.65); tower.add(col); }
    roof.side = THREE.DoubleSide; roof.emissive.set(0x48545a);
    const r1 = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 7.4, 2.6, 4, 1, true), roof); r1.rotation.y = Math.PI / 4; r1.scale.set(1.35, 1, 0.75); r1.position.y = 4.4; tower.add(r1);
  }
  shadowAll(g);
  return g;
}

// ---------- kitchen: big iron pot of sticky-rice soup on a fire, a bowl, grains ----------
export function soupPot({ r = 0.55 } = {}) {
  const g = new THREE.Group();
  const iron = new THREE.MeshStandardMaterial({ color: 0x2a2826, roughness: 0.5, metalness: 0.6 });
  const prof = [[0, -0.02], [r * 0.7, 0], [r, r * 0.4], [r * 1.02, r * 0.8], [r * 1.08, r * 0.82], [r * 1.0, r * 0.82], [r * 0.94, r * 0.4], [r * 0.66, r * 0.06], [0, r * 0.04]].map(([a, b]) => new THREE.Vector2(a, b));
  const pot = new THREE.Mesh(new THREE.LatheGeometry(prof, 40), iron); g.add(pot);
  const soupM = new THREE.MeshStandardMaterial({ color: 0xf2eee2, roughness: 0.35, bumpMap: fabricTexture(41), bumpScale: 2 });
  const soup = new THREE.Mesh(new THREE.CircleGeometry(r * 0.96, 40), soupM); soup.rotation.x = -Math.PI / 2; soup.position.y = r * 0.68; g.add(soup);
  g.soup = soup;
  // stones ring + logs + flames under it
  const R = rng(5), stone = new THREE.MeshStandardMaterial({ color: 0x6a645a, roughness: 1 });
  for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2; const s = new THREE.Mesh(new THREE.IcosahedronGeometry(0.16 + R() * 0.06, 1), stone); s.position.set(Math.cos(a) * r * 1.1, -0.18, Math.sin(a) * r * 1.1); g.add(s); }
  const wood = new THREE.MeshStandardMaterial({ color: 0x4a3020, roughness: 0.9 });
  for (let i = 0; i < 4; i++) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, r * 2, 8), wood); l.rotation.set(Math.PI / 2, i * 0.8, 0); l.position.y = -0.24; g.add(l); }
  const fl = [...Array(7)].map((_, i) => { const s = glowSprite(i % 2 ? 0xff8a2a : 0xffc14a, 0.35); s.position.set((R() - 0.5) * r, -0.12, (R() - 0.5) * r); g.add(s); return s; });
  const light = new THREE.PointLight(0xff8a3a, 2.2, 4, 2); light.position.y = 0; g.add(light);
  const steamTex = glowSprite().material.map;
  const steam = [...Array(14)].map(() => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: steamTex, color: 0xffffff, transparent: true, opacity: 0, depthWrite: false })); g.add(s); return { s, x: (R() - 0.5) * r, z: (R() - 0.5) * r, ph: R(), sp: 0.3 + R() * 0.2 }; });
  g.update = (t) => {
    fl.forEach((s, i) => { s.scale.setScalar(0.28 + 0.12 * Math.sin(t * 9 + i * 1.7)); s.material.opacity = 0.75 + 0.25 * Math.sin(t * 13 + i); });
    light.intensity = 2 + 0.4 * Math.sin(t * 11);
    steam.forEach((o, i) => { const a = (t * o.sp + o.ph) % 1; o.s.position.set(o.x + Math.sin(t + i) * 0.05, r * 0.7 + a * 1.1, o.z); o.s.scale.setScalar(0.25 + a * 0.6); o.s.material.opacity = 0.22 * Math.sin(Math.PI * a); });
  };
  g.update(0);
  shadowAll(g);
  return g;
}
export function bowl({ r = 0.12, grains = true, soup = false } = {}) {
  const g = new THREE.Group();
  const cer = new THREE.MeshStandardMaterial({ color: 0xe8e2d4, roughness: 0.35 }), blue = new THREE.MeshStandardMaterial({ color: 0x2a4a8a, roughness: 0.4 });
  const prof = [[0, 0], [r * 0.45, 0], [r * 0.45, r * 0.08], [r * 0.6, r * 0.12], [r, r * 0.7], [r * 1.02, r * 0.74], [r * 0.95, r * 0.72], [r * 0.56, r * 0.18], [0, r * 0.16]].map(([a, b]) => new THREE.Vector2(a, b));
  g.add(new THREE.Mesh(new THREE.LatheGeometry(prof, 40), cer));
  const band = new THREE.Mesh(new THREE.TorusGeometry(r * 0.99, r * 0.03, 6, 40), blue); band.rotation.x = Math.PI / 2; band.position.y = r * 0.62; g.add(band);
  if (grains) {
    const R = rng(3), gm = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 8, 6), new THREE.MeshStandardMaterial({ color: 0xf6f4ec, roughness: 0.5 }), 260), m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
    for (let i = 0; i < 260; i++) { const a = R() * 6.28, rr = Math.sqrt(R()) * r * 0.85; const y = r * 0.55 + (1 - (rr / (r * 0.85)) ** 2) * r * 0.3 * R(); q.setFromEuler(new THREE.Euler(R() * 3, R() * 3, R() * 3)); m4.compose(new THREE.Vector3(Math.cos(a) * rr, y, Math.sin(a) * rr), q, new THREE.Vector3(r * 0.035, r * 0.035, r * 0.09)); gm.setMatrixAt(i, m4); }
    g.add(gm); g.grains = gm;
  }
  if (soup) { const s = new THREE.Mesh(new THREE.CircleGeometry(r * 0.93, 32), new THREE.MeshStandardMaterial({ color: 0xf0ece0, roughness: 0.3 })); s.rotation.x = -Math.PI / 2; s.position.y = r * 0.62; g.add(s); g.soup = s; }
  shadowAll(g);
  return g;
}

// ---------- mortar crystals under the microscope: loose and gappy vs tight and packed ----------
export function crystalField({ tight = false, w = 1.6, h = 1.6, seed = 7 } = {}) {
  const R = rng(seed), g = new THREE.Group();
  const bg = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({ color: tight ? 0x3a3428 : 0x161412, roughness: 1 })); bg.position.z = -0.05; g.add(bg);
  const n = tight ? 1100 : 55;
  const mat = new THREE.MeshPhysicalMaterial({ color: 0xeef4f6, roughness: 0.2, clearcoat: 0.8, emissive: 0x8ab8d8, emissiveIntensity: 0.12 });
  const geo = new THREE.CylinderGeometry(1, 1, 1, 6);
  const mesh = new THREE.InstancedMesh(geo, mat, n); g.add(mesh);
  const D = [...Array(n)].map(() => {
    const s = tight ? 0.022 + R() * 0.014 : 0.035 + R() * 0.045;
    return { p: new THREE.Vector3((R() - 0.5) * (w - 2.6 * s), (R() - 0.5) * (h - 2.6 * s), 0), q: new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2 + (R() - 0.5) * 0.6, R() * 3, (R() - 0.5) * 0.6)), s, l: tight ? s * 1.2 : s * (1.5 + R() * 2.5), d: R() };
  });
  const m4 = new THREE.Matrix4();
  g.grow = (k) => { D.forEach((o, i) => { const gk = Math.max(0, Math.min(1, (k - o.d * 0.6) / 0.4)); m4.compose(o.p, o.q, new THREE.Vector3(o.s * gk + 1e-5, o.l * gk + 1e-5, o.s * gk + 1e-5)); mesh.setMatrixAt(i, m4); }); mesh.instanceMatrix.needsUpdate = true; };
  g.grow(1);
  if (tight) { // amylopectin "glue": a faint web between the crystals
    const web = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: 0xffe8a8, transparent: true, opacity: 0.0, depthWrite: false })); web.position.z = 0.04; g.add(web); g.web = web;
  }
  return g;
}

// ---------- Ming places: tomb mound with a stone door, arch bridge, Great Wall on a ridge ----------
export function tombMound() {
  const g = new THREE.Group();
  const earth = new THREE.Mesh(new THREE.SphereGeometry(6, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x5e6a3a, roughness: 1, bumpMap: fabricTexture(29), bumpScale: 4 })); earth.scale.y = 0.8; g.add(earth);
  const front = new THREE.Mesh(new THREE.BoxGeometry(6, 2.6, 1.2), brickMat(1.9, 0.9)); front.position.set(0, 1.3, 5.6); g.add(front);
  g.front = front;
  const door = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 2.0), new THREE.MeshStandardMaterial({ color: 0x5a5650, roughness: 0.9 })); door.position.set(0, 1.0, 6.21); g.add(door);
  shadowAll(g);
  return g;
}
export function archBridge({ span = 8, w = 3 } = {}) {
  const g = new THREE.Group();
  const stone = new THREE.MeshStandardMaterial({ color: 0x8a8478, roughness: 0.95, bumpMap: fabricTexture(31), bumpScale: 3 });
  const R = span / 2;
  // arch ring as a half torus-ish extrusion
  const sh = new THREE.Shape(); sh.moveTo(-R - 0.8, 0); sh.lineTo(-R - 0.8, R + 0.9); sh.lineTo(R + 0.8, R + 0.9); sh.lineTo(R + 0.8, 0); sh.lineTo(R, 0); sh.absarc(0, 0, R, 0, Math.PI, false); sh.lineTo(-R - 0.8, 0);
  const geo = new THREE.ExtrudeGeometry(sh, { depth: w, bevelEnabled: false, curveSegments: 32 }); geo.translate(0, 0, -w / 2);
  g.add(new THREE.Mesh(geo, stone));
  for (const s of [-1, 1]) { const rail = new THREE.Mesh(new THREE.BoxGeometry(span + 1.6, 0.5, 0.25), stone); rail.position.set(0, R + 1.15, s * (w / 2 - 0.12)); g.add(rail); }
  shadowAll(g);
  return g;
}
// Great Wall: a wall with merlons following a curve over a hill ridge
export function greatWall(points, { w = 4.5, h = 6 } = {}) {
  const g = new THREE.Group();
  const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
  const L = curve.getLength(), n = Math.ceil(L / 1.4);
  const mat = brickMat(0.6, 1.0, { tint: 0xd8cbb0 }), top = new THREE.MeshStandardMaterial({ color: 0x8a8070, roughness: 1 });
  for (let i = 0; i < n; i++) {
    const u = i / n, p = curve.getPointAt(u), tan = curve.getTangentAt(u);
    const seg = new THREE.Mesh(new THREE.BoxGeometry(L / n + 0.05, h, w), [mat, mat, top, mat, mat, mat]); seg.position.set(p.x, p.y + h / 2 - 1.5, p.z); seg.rotation.y = Math.atan2(-tan.z, tan.x); g.add(seg);
    for (const s of [-1, 1]) if (i % 2 === 0) { const m = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.8, 0.4), mat); m.position.set(0, h / 2 + 0.4, s * (w / 2 - 0.2)); seg.add(m); }
    if (i % 14 === 7) { const tw = new THREE.Mesh(new THREE.BoxGeometry(4.5, 3, w + 1.4), mat); tw.position.set(0, h / 2 + 1.5, 0); seg.add(tw); }
  }
  shadowAll(g);
  return g;
}
export function bulldozer() {
  const g = new THREE.Group();
  const yel = new THREE.MeshStandardMaterial({ color: 0xf2b21a, roughness: 0.5 }), dark = new THREE.MeshStandardMaterial({ color: 0x232323, roughness: 0.8 }), glass = new THREE.MeshStandardMaterial({ color: 0x2a3a48, roughness: 0.1, metalness: 0.4 });
  for (const s of [-1, 1]) { const tr = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.9, 0.7), dark); tr.position.set(0, 0.45, s * 1.0); g.add(tr); for (let k = 0; k < 5; k++) { const wl = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.72, 16), dark); wl.rotation.x = Math.PI / 2; wl.position.set(-1.3 + k * 0.65, 0.42, s * 1.0); g.add(wl); } }
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.1, 1.8), yel); body.position.set(-0.2, 1.4, 0); g.add(body);
  const cab = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.1, 1.4), yel); cab.position.set(-0.6, 2.5, 0); g.add(cab);
  for (const s of [-1, 1]) { const win = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.7), glass); win.position.set(-0.6, 2.6, s * 0.71); win.rotation.y = s > 0 ? 0 : Math.PI; g.add(win); }
  const wf = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.7), glass); wf.position.set(0.01, 2.6, 0); wf.rotation.y = Math.PI / 2; g.add(wf);
  const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.8, 10), dark); stack.position.set(0.6, 2.3, 0.5); g.add(stack);
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.15, 1.1, 2.8), yel); blade.position.set(1.9, 0.6, 0); g.add(blade);
  const edge = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.12, 2.82), dark); edge.position.set(1.9, 0.08, 0); g.add(edge);
  for (const s of [-1, 1]) { const arm = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.18, 0.18), yel); arm.position.set(1.3, 0.85, s * 1.15); arm.rotation.z = -0.2; g.add(arm); }
  shadowAll(g);
  return g;
}

// ---------- people ----------
const strawM = () => new THREE.MeshStandardMaterial({ color: 0xc8a868, roughness: 0.9, bumpMap: fabricTexture(17), bumpScale: 2 });
// Ming worker: plain cotton jacket and a conical straw hat
export function mingWorker(i = 0) {
  const h = romanBuilder({ color: [0x4a5a6a, 0x6a5a40, 0x3a4a3a, 0x5a4a5a][i % 4], skin: [0xd8a878, 0xc89868, 0xe0b080, 0xd0a070][i % 4] });
  const hat = new THREE.Mesh(new THREE.ConeGeometry(0.32, 0.16, 24, 1, true), strawM()); hat.material.side = THREE.DoubleSide; hat.position.set(0, 0.2, -0.01); h.j.head.add(hat);
  shadowAll(h.root);
  return h;
}
// lab chemist: white coat
export function chemist() {
  const h = romanBuilder({ color: 0xf2f2ee, skin: 0xd8a878 });
  const coat = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.3, 0.7, 24, 1, true), new THREE.MeshStandardMaterial({ color: 0xf4f4f0, roughness: 0.8, side: THREE.DoubleSide })); coat.position.y = -0.4; h.j.spine.add(coat);
  shadowAll(h.root);
  return h;
}
