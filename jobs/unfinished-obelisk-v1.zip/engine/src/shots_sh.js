// Shaduf reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { desertGround, palm } from './persia.js';
import { egyptian, pyramid } from './egypt.js';
import { bank, shaduf, seal, LAND, RIVER } from './shaduf.js';
import { VO } from './vo_sh.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['How do you', 3], ['*lift water*', 2], ['out of a *river*', 4], ['*all day long*', 3], ['with nothing but', 3], ['your *arms?*', 2]],
  [['But farmers', 2], ['along the *Nile*', 3], ['had a *trick*', 3], ['let a *weight*', 3], ['do the *lifting*', 3]],
  [["It's called a", 3], ['*shaduf*', 1]],
  [['A long *wooden pole*', 4], ['rests on a *crossbar*', 4], ['between two posts', 3], ['like a *seesaw*', 3]],
  [['On one end', 3], ['hangs a *bucket*', 3], ['On the other', 3], ['a heavy *lump*', 3], ['of *mud* or *stone*', 4]],
  [['The farmer', 2], ['*pulls* the bucket', 3], ['*down* into the river', 4]],
  [['When he *lets go*', 4], ['the *counterweight*', 2], ['swings the full bucket', 4], ['*up* for him', 3]],
  [['He just *turns*', 3], ['and *tips* the water', 4], ['into a *channel*', 3]],
  [['The channel', 2], ['carries it out', 3], ['to the *fields*', 3]],
  [['Working *all day*', 3], ['one shaduf', 2], ['could water', 2], ['about a *tenth*', 3], ['of a *hectare*', 3]],
  [['On *high banks*', 3], ['farmers set up', 3], ['*several in a row*', 4], ['each lifting water', 3], ['to the *next*', 3]],
  [['A machine like it', 4], ['appears on a', 3], ['*Mesopotamian seal*', 2], ['from more than', 3], ['*4,000 years* ago', 4]],
  [['And in parts', 3], ['of *Egypt*', 2], ['and other countries', 3], ['the shaduf', 2], ['is *still used today*', 4]],
  [['A *seesaw*', 2], ['a *bucket*', 2], ['and a *lump of mud*', 5], ['*feeding fields*', 2], ['for *thousands of years*', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

// one lift cycle, u 0..1 -> pole tilt a, yaw, tipB, full, farmer pose
const cycle = (u) => {
  if (u < 0.3) return { a: lerp(-0.25, 0.6, easeInOut(u / 0.3)), yaw: 0, tipB: 0, full: false, pull: 1 };
  if (u < 0.4) return { a: 0.6, yaw: 0, tipB: 0, full: true, pull: 1 };
  if (u < 0.6) return { a: lerp(0.6, -0.25, easeInOut((u - 0.4) / 0.2)), yaw: 0, tipB: 0, full: true, pull: 0 };
  if (u < 0.8) return { a: -0.25, yaw: lerp(0, 2.6, easeInOut((u - 0.6) / 0.2)), tipB: 0, full: true, pull: 0 };
  if (u < 0.9) return { a: lerp(-0.25, 0.1, (u - 0.8) / 0.1), yaw: 2.6, tipB: 1.4 * Math.sin(Math.PI * (u - 0.8) / 0.1), full: true, pull: 0 };
  return { a: lerp(0.1, -0.25, (u - 0.9) / 0.1), yaw: lerp(2.6, 0, (u - 0.9) / 0.1), tipB: 0, full: false, pull: 0 };
};
function site(makeStage, { preset = 'golden', sunDir = [-0.6, 0.45, 0.6], shadowSize = 12 } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog: 0.004, shadowSize, shadowAt: [0, 2, 0], envI: 0.95 });
  const B = bank(scene);
  [[-8, -4, 6], [7, -9, 5.5], [-14, -14, 6.5], [12, -2, 5]].forEach(([x, z, h], i) => { const p = palm(h, i + 13); p.position.set(x, LAND, z); scene.add(p); });
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xffe6c8);
  return { scene, B };
}
function rig(scene, x = 0, i = 0) {
  const S = shaduf(); S.position.x = x; scene.add(S);
  const F = egyptian(i); F.root.position.set(x + 0.4, LAND, 0.9); scene.add(F.root);
  const drops = [...Array(10)].map(() => { const d = glowSprite(0x7ac8ff, 0.12); scene.add(d); return d; });
  return {
    S, F,
    run(u, t, nod = true) {
      const c = cycle(u); S.set(c.a, { full: c.full, tipB: c.tipB, yaw: c.yaw });
      F.root.rotation.y = Math.PI + c.yaw * 0.6;
      standPose(F, t, { spine: [0.3 + c.pull * 0.3, 0, 0], lSh: [-1.5 - c.pull * 0.6, 0, 0.2], rSh: [-1.5 - c.pull * 0.6, 0, -0.2], lEl: [-0.3, 0, 0], rEl: [-0.3, 0, 0] }); F.setMood('happy'); F.setMouth(0); F.grip(0.9, 0.9);
      scene.updateMatrixWorld(true); const bp = S.tipPos();
      drops.forEach((d, k) => { const v = (t * 2 + k / 10) % 1; d.visible = c.tipB > 0.5; d.position.set(bp.x, bp.y - v * 1.2, bp.z); });
      return bp;
    },
  };
}

// ============ S0: a farmer hauling water by hand, bucket after bucket ============
function sHook({ makeStage }) {
  const { scene } = site(makeStage, { sunDir: [0.4, 0.7, 0.5] });
  const F = egyptian(1); scene.add(F.root);
  const jar = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.17, 0.32, 14), new THREE.MeshStandardMaterial({ color: 0x8a5a32 })); scene.add(jar);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const u = (t / 2.4) % 1; const z = lerp(1.2, -3, Math.sin(u * Math.PI)); const y = lerp(RIVER, LAND, Math.min(1, Math.sin(u * Math.PI) * 1.5));
      F.root.position.set(0, y, z); F.root.rotation.y = u < 0.5 ? Math.PI : 0;
      standPose(F, t, { spine: [0.4, 0, 0], lSh: [-0.6, 0, 0.3], rSh: [-0.6, 0, -0.3], lHip: [Math.sin(t * 7) * 0.4, 0, 0.06], rHip: [-Math.sin(t * 7) * 0.4, 0, -0.06] }); F.setMood('happy'); F.setMouth(0.4);
      scene.updateMatrixWorld(true); const hp = F.j.rWr.getWorldPosition(V(0, 0, 0)); jar.position.set(hp.x, hp.y - 0.2, hp.z);
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(6, 4.5, k), lerp(3.5, 3, k), lerp(5, 6, k)], [0, 1.4, -0.5]);
      return { bloom: 0.55, flare: 0.8, warm: 1.35 };
    },
  };
}
// ============ S1: a trick: shadufs along the Nile at sunrise ============
function sRow({ makeStage }) {
  const { scene } = site(makeStage, { sunDir: [0.0, 0.2, 1] });
  const R = [-7.5, -2.5, 2.5, 7.5].map((x, i) => rig(scene, x, i));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.forEach((r, i) => r.run((t / 4 + i * 0.27) % 1, t + i));
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-16, -12, k), lerp(4.0, 4.6, k), lerp(14, 12, k)], [0, 2.6, -1]);
      return { bloom: 0.7, flare: 1.0, warm: 1.35 };
    },
  };
}
// ============ S2..S9: one shaduf, explained step by step (same scene, different cycles + cameras) ============
function oneShot(camFn, cycFn, opts = {}) {
  return ({ makeStage, start: ST }) => {
    const { scene } = site(makeStage, opts);
    const R = rig(scene, 0, 0);
    const c = cam(opts.fov || 36);
    return {
      scene, camera: c,
      update(t) {
        const bp = R.run(cycFn(t, ST), t);
        camFn(c, t, bp);
        return { bloom: 0.55, warm: 1.3 };
      },
    };
  };
}
const sName = oneShot((c, t) => place(c, [lerp(5, 4, easeInOut(range(t, 0, 2))), 3.4, 6.5], [0, 2.8, 0.5]), (t) => (t / 4) % 1);
const sPole = oneShot((c, t) => { const k = easeInOut(range(t, 0, 4.4)); place(c, [lerp(-7.5, -6.5, k), LAND + lerp(2.8, 2.6, k), lerp(2.5, 1.8, k)], [0, LAND + 2.3, 0.2]); }, (t) => 0.02); /* side view: pole on the crossbar between the posts */
const sEnds = oneShot((c, t) => { const k = easeInOut(range(t, 0, 4.8)); place(c, [lerp(14.5, 13.5, k), LAND + lerp(2.8, 2.6, k), lerp(4, 3, k)], [0, LAND + 2.0, 0.7]); }, (t) => 0.02); /* wide three-quarter view: bucket end and weight end both in frame */
const sPull = oneShot((c, t) => place(c, [5.5, LAND + 1.6, 5.0], [0.2, LAND + 1.0, 1.2]), (t) => Math.min(0.38, 0.05 + t / 3.2 * 0.33));
const sUp = oneShot((c, t) => place(c, [6, LAND + 2.0, 6.0], [0.2, LAND + 1.6, 1.2]), (t) => Math.min(0.6, 0.38 + t / 3.4 * 0.22));
const sTip = oneShot((c, t) => place(c, [lerp(-4, -5, easeInOut(range(t, 0, 3))), 4.2, lerp(2, 1, easeInOut(range(t, 0, 3)))], [-1.2, 2.2, -2.2]), (t) => Math.min(0.88, 0.6 + t / 3.0 * 0.28));
const sField = oneShot((c, t) => { const k = easeInOut(range(t, 0, 3)); place(c, [lerp(-3, -1, k), lerp(5, 7, k), lerp(-4, -12, k)], [-1.2, LAND, lerp(-12, -24, k)]); }, (t) => 0.88);
const sDay = oneShot((c, t) => { const a = lerp(0.4, 1.6, easeInOut(range(t, 0, 4.4))); place(c, [Math.sin(a) * 9, 5, Math.cos(a) * 9 - 2], [0, 2.4, -2]); }, (t) => (t / 1.1) % 1, { preset: 'golden', sunDir: [0.7, 0.2, 0.6] });
// ============ S10: stacked shadufs up a high bank ============
function sStack({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.45, 0.6], fog: 0.004, shadowSize: 12, shadowAt: [0, 3, 0], envI: 0.95 });
  bank(scene);
  const steps = [0, 1, 2].map(i => { const s = new THREE.Mesh(new THREE.BoxGeometry(6, 1.4, 3), new THREE.MeshStandardMaterial({ color: 0x8a6a40, roughness: 1 })); s.position.set(0, LAND + 0.7 + i * 1.4 - 1.4, -1.5 - i * 3); scene.add(s); return s; });
  const R = [0, 1, 2].map(i => { const r = rig(scene, 0, i); r.S.position.set(0, -1.4 + i * 1.4, -i * 3); r.F.root.position.set(0.4, LAND - 1.4 + i * 1.4, 0.9 - i * 3); return r; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      R.forEach((r, i) => { r.run((t / 3.2 + i * 0.33) % 0.6, t + i); r.F.root.position.y = LAND - 1.4 + i * 1.4; });
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(10, 8, k), lerp(5, 6, k), lerp(8, 6, k)], [0, 2.8, -3]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S11: a cylinder seal from Mesopotamia ============
function sSeal({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [-1, 3, 2], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a2016); u.mid.value.set(0x3a2a1c); u.horizon.value.set(0x4a3624); u.floorC.value.set(0x20160e);
  const table = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), new THREE.MeshStandardMaterial({ color: 0x4a3020, roughness: 0.8 })); table.rotation.x = -Math.PI / 2; table.receiveShadow = true; scene.add(table);
  const S = seal(); S.position.y = 0.01; scene.add(S);
  const lamp = new THREE.PointLight(0xffb060, 2.5, 4, 2); lamp.position.set(0.6, 1.2, 0.8); scene.add(lamp);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      S.cyl.position.x = lerp(1.6, 0.8, easeInOut(range(t, 0, 2.5))); S.cyl.rotation.x = t * 0.6;
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(0.6, 0.1, k), lerp(3.4, 3.0, k), lerp(2.2, 1.4, k)], [lerp(0.4, 0.1, k), 0, 0.2]);
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S12: still used today ============
const sToday = oneShot((c, t) => { const k = easeInOut(range(t, 0, 4.4)); place(c, [lerp(-6, -4, k), lerp(2.6, 3.2, k), lerp(8, 7, k)], [0, 2.4, 0]); }, (t) => (t / 3.6) % 1, { preset: 'day', sunDir: [-0.5, 0.6, 0.6] });
// ============ S13: sunset, a line of shadufs and green fields ============
function sEnd({ makeStage }) {
  const { scene } = site(makeStage, { sunDir: [0.75, 0.12, 0.6] });
  const R = [-8, 0, 8].map((x, i) => rig(scene, x, i));
  const P = pyramid(); P.scale.setScalar(0.5); P.position.set(30, LAND, -90); scene.add(P);
  const b = birds(4, { from: [-20, 12, 10], to: [20, 14, 0], spread: 4, speed: 0.06, scale: 1.4, seed: 4 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.forEach((r, i) => r.run((t / 4 + i * 0.3) % 1, t + i));
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(3, 10, k), lerp(3, 10, k), lerp(12, 22, k)], [0, 2.5, -4]);
      return { bloom: 0.7, flare: 1.1, warm: 1.4 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sRow], [ls(2), ls(3), sName], [ls(3), ls(4), sPole], [ls(4), ls(5), sEnds],
  [ls(5), ls(6), sPull], [ls(6), ls(7), sUp], [ls(7), ls(8), sTip], [ls(8), ls(9), sField], [ls(9), ls(10), sDay],
  [ls(10), ls(11), sStack], [ls(11), ls(12), sSeal], [ls(12), ls(13), sToday], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
