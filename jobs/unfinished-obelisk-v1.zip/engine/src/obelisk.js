// Unfinished obelisk reel: Aswan granite, the obelisk in its trench, dolerite pounders, copper chisel, pharaoh.
import * as THREE from 'three';
import { fabricTexture } from './textures.js';
import { shadowAll, canvasTex, romanBuilder } from './rome.js';

const rng = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const V = (x, y, z) => new THREE.Vector3(x, y, z);

let GT = null;
export function graniteTex() {
  if (GT) return GT;
  GT = canvasTex(512, 512, (x) => {
    x.fillStyle = '#a87a6c'; x.fillRect(0, 0, 512, 512);
    const R = rng(3);
    for (let i = 0; i < 9000; i++) { const r = R(); x.fillStyle = r < 0.35 ? '#5a3a34' : r < 0.55 ? '#d8b0a0' : r < 0.7 ? '#2a2422' : r < 0.85 ? '#c88a78' : '#ece0d8'; const s = 0.6 + R() * 2.2; x.beginPath(); x.ellipse(R() * 512, R() * 512, s, s * (0.6 + R() * 0.8), R() * 3, 0, 7); x.fill(); }
    // pounding marks: soft dimples
    for (let i = 0; i < 160; i++) { const g = x.createRadialGradient(0, 0, 0, 0, 0, 14); g.addColorStop(0, 'rgba(60,30,20,0.18)'); g.addColorStop(1, 'rgba(60,30,20,0)'); x.save(); x.translate(R() * 512, R() * 512); x.fillStyle = g; x.fillRect(-14, -14, 28, 28); x.restore(); }
  });
  GT.wrapS = GT.wrapT = THREE.RepeatWrapping;
  return GT;
}
export function graniteMat(rep = 1) {
  const t = graniteTex().clone(); t.needsUpdate = true; t.repeat.set(rep, rep);
  return new THREE.MeshStandardMaterial({ map: t, roughness: 0.85, bumpMap: t, bumpScale: 3 });
}

// the obelisk lying on its side (length along x, from x = -L/2 (base) to +L/2 (tip)); its upper face at y = 0
export function obelisk({ L = 42, base = 4.2, top = 2.7, pyr = 3.4 } = {}) {
  const g = new THREE.Group();
  const shaft = L - pyr;
  const geo = new THREE.CylinderGeometry(top / Math.SQRT2, base / Math.SQRT2, shaft, 4, 1);
  geo.rotateY(Math.PI / 4); geo.rotateZ(-Math.PI / 2); geo.translate(-L / 2 + shaft / 2, -base / 2, 0);
  const mat = graniteMat(10);
  const m = new THREE.Mesh(geo, mat); m.castShadow = m.receiveShadow = true; g.add(m);
  const pg = new THREE.ConeGeometry(top / Math.SQRT2, pyr, 4, 1); pg.rotateY(Math.PI / 4); pg.rotateZ(-Math.PI / 2); pg.translate(L / 2 - pyr / 2, -base / 2, 0);
  const p = new THREE.Mesh(pg, mat); p.castShadow = p.receiveShadow = true; g.add(p);
  g.mat = mat; g.L = L; g.base = base;
  return g;
}
// the quarry floor with a trench cut round the obelisk
export function quarryBed({ L = 42, W = 4.2, gap = 0.9, depth = 4.4 } = {}) {
  const g = new THREE.Group(); const mat = graniteMat(24);
  const hx = L / 2 + gap + 0.5, hz = W / 2 + gap;
  const box = (x0, x1, z0, z1, y0, y1) => { const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), mat); m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2); m.receiveShadow = m.castShadow = true; g.add(m); };
  box(-95, 95, hz, 95, -depth - 2, 0); box(-95, 95, -95, -hz, -depth - 2, 0);
  box(-95, -hx, -hz, hz, -depth - 2, 0); box(hx, 95, -hz, hz, -depth - 2, 0);
  box(-hx, hx, -hz, hz, -depth - 2, -depth);
  // rough stepped quarry walls behind
  const R = rng(7);
  for (let i = 0; i < 12; i++) { const w = 6 + R() * 10, h = 2 + R() * 5; const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, 5 + R() * 6), mat); m.position.set(-50 + i * 9 + R() * 3, h / 2, -16 - R() * 8); m.rotation.y = (R() - 0.5) * 0.3; m.castShadow = m.receiveShadow = true; g.add(m); }
  return g;
}
export function doleriteBall(r = 0.15) {
  const geo = new THREE.IcosahedronGeometry(r, 3); const p = geo.attributes.position; const R = rng(5);
  for (let i = 0; i < p.count; i++) { const v = V(p.getX(i), p.getY(i), p.getZ(i)); v.multiplyScalar(1 + (Math.sin(v.x * 40) * Math.sin(v.y * 37) * 0.06)); p.setXYZ(i, v.x, v.y, v.z); }
  geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0x2e3430, roughness: 0.75, bumpMap: fabricTexture(19), bumpScale: 2 })); m.castShadow = true; return m;
}
export function chisel() {
  const g = new THREE.Group();
  const cu = new THREE.MeshStandardMaterial({ color: 0xc87a4a, metalness: 0.8, roughness: 0.35 });
  const shaft = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.2, 0.025), cu); shaft.position.y = 0.1; g.add(shaft);
  const tip = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.04, 0.008), cu); g.add(tip); g.tip = tip;
  return shadowAll(g);
}
export function mallet() {
  const g = new THREE.Group(); const w = new THREE.MeshStandardMaterial({ color: 0x7a5232, roughness: 0.8 });
  const h = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.014, 0.3, 8), w); h.position.y = -0.12; g.add(h);
  const head = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.12, 12), w); head.rotation.z = Math.PI / 2; head.position.y = 0.04; g.add(head);
  return shadowAll(g);
}
// pharaoh in a striped nemes headdress with a false beard
export function pharaoh() {
  const h = romanBuilder({ color: 0xf2ece0, skin: 0xa86a44 });
  const stripes = canvasTex(64, 64, (x) => { for (let i = 0; i < 8; i++) { x.fillStyle = i % 2 ? '#1e3c8a' : '#e0b030'; x.fillRect(0, i * 8, 64, 8); } });
  const nm = new THREE.MeshStandardMaterial({ map: stripes, roughness: 0.5, metalness: 0.2 });
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.165, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.4), nm); cap.position.set(0, 0.05, -0.035); cap.scale.set(1.08, 1, 1.05);
  const back = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.19, 0.3, 20, 1, true, Math.PI * 0.5, Math.PI), nm); back.material = nm.clone(); back.material.side = THREE.DoubleSide; back.position.set(0, -0.08, -0.04); h.j.head.add(back); h.j.head.add(cap);
  for (const s of [-1, 1]) { const lap = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.3, 0.03), nm); lap.position.set(s * 0.16, -0.16, 0.04); lap.rotation.z = s * 0.15; h.j.head.add(lap); }
  const beard = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.03, 0.12, 10), new THREE.MeshStandardMaterial({ color: 0x1e3c8a, roughness: 0.5 })); beard.position.set(0, -0.17, 0.11); h.j.head.add(beard);
  const uraeus = new THREE.Mesh(new THREE.SphereGeometry(0.02, 10, 8), new THREE.MeshStandardMaterial({ color: 0xe0b030, metalness: 0.8, roughness: 0.3 })); uraeus.position.set(0, 0.12, 0.155); h.j.head.add(uraeus);
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.04, 8, 24), nm); collar.rotation.x = Math.PI / 2; collar.scale.set(1.1, 0.8, 1); collar.position.y = 0.17; h.j.chest.add(collar);
  shadowAll(h.root);
  return h;
}
