// Inca quipu reel: the knotted-cord record, a single decimal cord, llama, maize.
import * as THREE from 'three';
import { fabricTexture } from './textures.js';
import { shadowAll } from './rome.js';

const rng = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const V = (x, y, z) => new THREE.Vector3(x, y, z);
export const CORD_COLS = [0xe8dcc0, 0x8a5a34, 0xc8a050, 0x4a3a2a, 0xb83a2a, 0xd8c8a0, 0x6a7a4a, 0x2a4a7a];

function cordMat(col) { const t = fabricTexture(11); return new THREE.MeshStandardMaterial({ color: col, roughness: 0.95, bumpMap: t, bumpScale: 2, emissive: 0xffd060, emissiveIntensity: 0 }); }

// knots along a vertical cord (local: cord runs from y = 0 down to y = -L)
function simpleKnot(r, mat) { const k = new THREE.Mesh(new THREE.TorusGeometry(r * 1.4, r * 0.95, 8, 14), mat); k.rotation.y = Math.PI / 2; k.scale.set(1, 0.75, 1); return k; }
function longKnot(r, turns, mat) {
  const g = new THREE.Group();
  for (let i = 0; i < turns; i++) { const k = new THREE.Mesh(new THREE.TorusGeometry(r * 1.35, r * 0.75, 8, 14), mat); k.rotation.set(Math.PI / 2 + 0.35, 0, 0); k.position.y = -i * r * 1.6; g.add(k); }
  return g;
}
// one pendant cord with a decimal value: hundreds, tens (simple knots), ones (long knot, turns = ones; 1 = simple)
export function cord(value, { L = 0.5, r = 0.006, col = 0xe8dcc0, sway = 0, seed = 1 } = {}) {
  const g = new THREE.Group(); const mat = cordMat(col); g.mat = mat;
  const R = rng(seed);
  const pts = []; for (let i = 0; i <= 12; i++) { const u = i / 12; pts.push(V(Math.sin(u * 2.4 + seed) * 0.006 + sway * u * u, -u * L, Math.cos(u * 3 + seed) * 0.004)); }
  const curve = new THREE.CatmullRomCurve3(pts);
  g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 40, r, 8), mat));
  const tuft = new THREE.Mesh(new THREE.ConeGeometry(r * 2, r * 5, 8), mat); tuft.position.copy(curve.getPoint(1)).add(V(0, -r * 2, 0)); tuft.rotation.x = Math.PI; g.add(tuft);
  const h = Math.floor(value / 100) % 10, t = Math.floor(value / 10) % 10, o = value % 10;
  g.zones = { h: [], t: [], o: [] };
  const place = (u) => curve.getPoint(u);
  for (let i = 0; i < h; i++) { const k = simpleKnot(r, mat.clone()); k.position.copy(place(0.18 + i * 0.035)); g.add(k); g.zones.h.push(k); }
  for (let i = 0; i < t; i++) { const k = simpleKnot(r, mat.clone()); k.position.copy(place(0.48 + i * 0.035)); g.add(k); g.zones.t.push(k); }
  if (o) { const k = o === 1 ? simpleKnot(r, mat.clone()) : longKnot(r, o, mat.clone()); k.position.copy(place(0.78)); g.add(k); g.zones.o.push(k); }
  g.glow = (zone, k) => g.zones[zone].forEach(n => n.traverse(m => { if (m.isMesh) m.material.emissiveIntensity = k; }));
  g.curve = curve;
  return shadowAll(g);
}
// a whole quipu: thick main cord, many pendant cords, a few with subsidiaries
export function quipu({ n = 26, W = 0.7, L = 0.5, seed = 4, hang = true } = {}) {
  const g = new THREE.Group(); const R = rng(seed);
  const main = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([V(-W / 2 - 0.08, 0.02, 0), V(-W / 2, 0, 0), V(W / 2, 0, 0), V(W / 2 + 0.06, -0.06, 0.01)]), 60, 0.011, 10), cordMat(0xd8c8a0)); g.add(main);
  g.cords = [];
  for (let i = 0; i < n; i++) {
    const col = CORD_COLS[Math.floor(R() * CORD_COLS.length)];
    const v = Math.floor(R() * 900) + 10;
    const c = cord(v, { L: L * (0.8 + R() * 0.35), col, sway: (R() - 0.5) * 0.05, seed: i + seed * 31 });
    c.position.set(-W / 2 + (i + 0.5) * W / n, -0.008, (R() - 0.5) * 0.01); c.rotation.z = (R() - 0.5) * 0.06;
    g.add(c); g.cords.push(c);
  }
  return shadowAll(g);
}

// ---------- llama ----------
export function llama(col = 0xe8dcc8) {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: col, roughness: 1, bumpMap: fabricTexture(5), bumpScale: 4 }), dark = new THREE.MeshStandardMaterial({ color: 0x2a2420, roughness: 0.8 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.5, 8, 16), m); body.rotation.z = Math.PI / 2; body.position.y = 0.85; g.add(body);
  const neck = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.5, 6, 12), m); neck.position.set(0.38, 1.2, 0); neck.rotation.z = -0.2; g.add(neck);
  const head = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.14, 6, 12), m); head.rotation.z = Math.PI / 2 - 0.2; head.position.set(0.5, 1.5, 0); g.add(head);
  for (const s of [-1, 1]) { const ear = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.12, 8), m); ear.position.set(0.44, 1.62, s * 0.04); ear.rotation.x = s * 0.2; g.add(ear); const eye = new THREE.Mesh(new THREE.SphereGeometry(0.014, 8, 6), dark); eye.position.set(0.53, 1.53, s * 0.06); g.add(eye); }
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), dark); nose.position.set(0.64, 1.47, 0); g.add(nose);
  g.legs = [];
  for (const [x, z] of [[0.3, 0.12], [0.3, -0.12], [-0.3, 0.12], [-0.3, -0.12]]) { const pv = new THREE.Group(); pv.position.set(x, 0.75, z); const l = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.75, 8), m); l.position.y = -0.37; pv.add(l); const hf = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), dark); hf.position.y = -0.74; pv.add(hf); g.add(pv); g.legs.push(pv); }
  const tail = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), m); tail.position.set(-0.5, 0.92, 0); g.add(tail);
  g.walk = (t) => g.legs.forEach((pv, i) => { pv.rotation.z = Math.sin(t * 6 + (i % 2 ? 0 : Math.PI) + (i > 1 ? Math.PI / 2 : 0)) * 0.3; });
  return shadowAll(g);
}
export function maizeCob() {
  const g = new THREE.Group();
  const cob = new THREE.Mesh(new THREE.CapsuleGeometry(0.035, 0.12, 6, 12), new THREE.MeshStandardMaterial({ color: 0xe8b830, roughness: 0.6, bumpMap: fabricTexture(9), bumpScale: 3 })); g.add(cob);
  for (let i = 0; i < 3; i++) { const h = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6, 0, 2, 0, Math.PI), new THREE.MeshStandardMaterial({ color: 0xc8b878, roughness: 0.9, side: THREE.DoubleSide })); h.scale.set(1, 2.4, 0.4); h.position.y = -0.05; h.rotation.y = i * 2.1; g.add(h); }
  return shadowAll(g);
}
