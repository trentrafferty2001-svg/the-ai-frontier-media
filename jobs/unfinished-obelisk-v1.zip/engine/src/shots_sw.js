// Stepwell reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose } from './shots4.js';
import { birds } from './world.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { thermometer } from './windcatcher.js';
import { stepwell, swVillage, villager, route, lvY, lvW, LEVELS, DEPTH, TOP } from './stepwell.js';
import { VO } from './vo_sw.js';
import { rng } from './textures.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['What if', 2], ['the only *water*', 3], ['near your *village*', 3], ['was *10 stories*', 3], ['*underground?*', 1]],
  [['But in *India*', 3], ['people built', 2], ['a *staircase*', 2], ['*all the way down*', 4], ['to it', 2]],
  [["It's called a", 3], ['*stepwell*', 1]],
  [['In the *dry months*', 4], ['the water *sank*', 3], ['*deep* below', 2], ['the ground', 2]],
  [['So *builders*', 2], ['dug a *huge pit*', 4], ['down to it', 3], ['and *lined it*', 3], ['with *stone*', 2]],
  [['Then they covered', 3], ['the walls', 2], ['with *zigzag steps*', 3]],
  [['When the', 2], ['*monsoon rains* came', 3], ['the water *rose*', 3], ['and *covered*', 2], ['the lower steps', 3]],
  [['As the *dry season*', 4], ['went on', 2], ['people simply', 2], ['*walked further down*', 3]],
  [['The water was', 3], ['*always there*', 2], ['just a *few more steps*', 5], ['away', 1]],
  [['At the *bottom*', 3], ['the air could be', 4], ['*several degrees*', 2], ['*cooler*', 1], ['than up top', 3]],
  [['So stepwells', 2], ['also became', 2], ['*shady places*', 2], ['to *rest*', 2], ['and *meet*', 2]],
  [['*Chand Baori*', 2], ['in *Rajasthan*', 2], ['was built', 2], ['more than', 2], ['*1,100 years* ago', 4]],
  [['It has about', 3], ['*3,500 steps*', 4], ['on *13 levels*', 3], ['going down', 2], ['around *30 meters*', 3]],
  [['A *giant staircase*', 3], ['built just', 2], ['to reach', 2], ['a *drink of water*', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function site(makeStage, { preset = 'golden', sunDir = [-0.5, 0.8, 0.6], cut = false, shadowSize = 30, shadowAt = [0, -10, 0], fog = 0.003, village = true } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt, envI: 0.95 });
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xffe6c8);
  const SW = stepwell(scene, { cut });
  if (village && !cut) swVillage(scene);
  return { scene, SW };
}
const walk = (F, t, sp = 7) => standPose(F, t, { lSh: [-0.2, 0, 0.15], rSh: [-2.9, 0, -0.3], rEl: [-0.3, 0, 0], lHip: [Math.sin(t * sp) * 0.4, 0, 0.06], rHip: [-Math.sin(t * sp) * 0.4, 0, -0.06], lKn: [Math.max(0, -Math.sin(t * sp)) * 0.6, 0, 0], rKn: [Math.max(0, Math.sin(t * sp)) * 0.6, 0, 0] });
const sit = (F, t, talk = 0) => { standPose(F, t, { lHip: [-1.5, 0, 0.1], rHip: [-1.5, 0, -0.1], lKn: [1.5, 0, 0], rKn: [1.5, 0, 0], lSh: [-0.3, 0, 0.2], rSh: [-0.6 - talk * Math.max(0, Math.sin(t * 3)) * 0.6, 0, -0.2], rEl: [-0.8, 0, 0], drop: -0.48 }); F.setMood('happy'); F.setMouth(talk * Math.max(0, Math.sin(t * 9)) * 0.5); };

// ============ S0: a dusty village; a woman walks with an empty pot ============
function sHook({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [0.6, 0.35, 0.7], shadowSize: 12, shadowAt: [-2, 0, 16] });
  const F = villager(0); scene.add(F.root);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const x = lerp(-7, 0, t / 5); F.root.position.set(x, 0, TOP + 3.5); F.root.rotation.y = Math.PI / 2;
      walk(F, t); F.setMood('happy'); F.setMouth(0);
      const k = easeInOut(range(t, 0, 5));
      place(c, [x + 3.5, lerp(1.4, 2.0, k), TOP + 3.5 + lerp(4, 5.2, k)], [x + 0.4, 1.2, TOP + 2.5]);
      return { bloom: 0.6, flare: 1.0, warm: 1.4 };
    },
  };
}
// ============ S1: at the edge, the camera tilts down into the giant stair-pit ============
function sReveal({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [-0.3, 0.9, 0.4] });
  SW.setWater(lvY(11.6));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.8));
      place(c, [0, lerp(3, 5, k), TOP + 2.5], [0, lerp(1, -DEPTH, k), lerp(-10, 0, k)]);
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S2: "a stepwell": high orbit ============
function sName({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [0.5, 0.6, 0.6] });
  SW.setWater(lvY(11.6));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const a = lerp(0.5, 0.9, easeInOut(range(t, 0, 2.2)));
      place(c, [Math.sin(a) * 34, 26, Math.cos(a) * 34], [0, -8, 0]);
      return { bloom: 0.55, flare: 0.8, warm: 1.35 };
    },
  };
}
// cut-away helper camera
const cutCam = (c, t, k0 = 0) => { const k = easeInOut(range(t, 0, 9)); place(c, [lerp(46, 40, k), lerp(-4, -7, k), lerp(26, 20, k)], [0, -13, lerp(-3, -1, k)]); };
// ============ S3: cut-away: in the dry months the water table sinks ============
function sDry({ makeStage }) {
  const { scene, SW } = site(makeStage, { cut: true, sunDir: [-0.9, 0.6, 0.4] });
  SW.setStairs(0); SW.setLining(0); SW.pav.visible = false;
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      SW.setWater(lerp(lvY(3), lvY(11.5), easeInOut(range(t, 0.3, 3.4))));
      cutCam(c, t);
      return { bloom: 0.45, warm: 1.25 };
    },
  };
}
// ============ S4: the pit is dug and lined with stone, top to bottom ============
function sLine({ makeStage, start: ST }) {
  const { scene, SW } = site(makeStage, { cut: true, sunDir: [-0.9, 0.6, 0.4] });
  SW.setStairs(0); SW.pav.visible = false; SW.setWater(lvY(11.5));
  const c = cam(40);
  const tl = at(4, 'lined') - ST;
  return {
    scene, camera: c,
    update(t) {
      SW.setLining(easeInOut(range(t, tl - 0.3, tl + 1.6)));
      cutCam(c, t + 4.5);
      return { bloom: 0.45, warm: 1.25 };
    },
  };
}
// ============ S5: zigzag stairs appear across the walls ============
function sSteps({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [-0.7, 0.7, 0.3] });
  SW.setWater(lvY(11.5)); SW.pav.visible = true;
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      SW.setStairs(easeOut(range(t, 0.1, 2.4)));
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [10, lerp(-3, -4.5, k), lerp(-1.5, 1.5, k)], [-8, -12, 0]); /* across the pit at the far wall's zigzag stairs */
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S6: monsoon rain, the water rises over the lower steps ============
function sMonsoon({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.3, 0.8, 0.4], fog: 0.006, shadowSize: 30, shadowAt: [0, -10, 0], envI: 0.7, cloud: 0.9 });
  fillLight(scene, [0.3, 0.4, 1], 0.4, 0xd8e4ff);
  const SW = stepwell(scene); swVillage(scene);
  const n = 900, geo = new THREE.BufferGeometry(), P = new Float32Array(n * 6), S = [];
  const RR = rng(5); for (let i = 0; i < n; i++) S.push([(RR() - 0.5) * 30, RR() * 30, (RR() - 0.5) * 30, 14 + RR() * 6]);
  geo.setAttribute('position', new THREE.BufferAttribute(P, 3));
  const rain = new THREE.LineSegments(geo, new THREE.LineBasicMaterial({ color: 0xcfe2ff, transparent: true, opacity: 0.5 })); rain.frustumCulled = false; scene.add(rain);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      S.forEach(([x, y, z, v], i) => { const yy = ((y - t * v) % 30 + 30) % 30 - 22; P.set([x, yy, z, x + 0.05, yy + 0.7, z], i * 6); }); geo.attributes.position.needsUpdate = true;
      SW.setWater(lerp(lvY(11.5), lvY(8), easeInOut(range(t, 0.6, 4.0))));
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [9, lerp(-8, -9, k), lerp(-1, 1, k)], [-4, -19, 0]); /* down at the lower steps as the water climbs over them */
      return { bloom: 0.45, warm: 1.05 };
    },
  };
}
// ============ S7: the dry season: the water drops; a woman walks further down ============
function sWalk({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [-0.4, 0.8, 0.5], shadowSize: 14, shadowAt: [3, -14, 6] });
  const F = villager(1); scene.add(F.root);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      SW.setWater(lerp(lvY(8), lvY(11.4), easeInOut(range(t, 0.2, 3.6))));
      const u = range(t, 0, 4.4); const p = route(u, 5, 10); F.root.position.copy(p); F.root.rotation.y = Math.PI + (Math.floor(5 + 5 * u) % 2 ? -0.9 : 0.9);
      walk(F, t, 8); F.setMood('happy'); F.setMouth(0);
      place(c, [p.x - 4.5, p.y + 2.8, p.z - 6], [p.x, p.y - 0.2, p.z - 1]); /* keeps her head in frame */
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S8: at the water's edge she dips the pot ============
function sFill({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [-0.4, 0.8, 0.5], shadowSize: 8, shadowAt: [3, -22, 4] });
  const F = villager(1); scene.add(F.root);
  const yW = lvY(11.4); SW.setWater(yW);
  const p = route(0, 11, 11); p.x = 0.3; F.root.position.copy(p); F.root.rotation.y = Math.PI;
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const d = easeInOut(range(t, 0.6, 1.8)) * (1 - easeInOut(range(t, 3.0, 4.0)));
      standPose(F, t, { spine: [0.6 * d, 0, 0], lSh: [-0.3 - d, 0, 0.2], rSh: [-2.9 + d * 1.6, 0, -0.3], rEl: [-0.3, 0, 0], lKn: [0.5 * d, 0, 0], rKn: [0.5 * d, 0, 0] }); F.setMood('happy'); F.setMouth(0);
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [p.x + lerp(-1.6, -1.2, k), p.y + lerp(2.6, 2.3, k), p.z - lerp(5.8, 5.2, k)], [p.x, p.y + 0.4, p.z - 0.6]);
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S9: thermometers: hot at the top, cooler at the bottom ============
function sCool({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [0.2, 0.9, 0.3], shadowSize: 30 });
  SW.setWater(lvY(11.6));
  const T1 = thermometer(); T1.position.set(-3, 0, TOP + 1.2); T1.scale.setScalar(1.6); scene.add(T1);
  const T2 = thermometer(); T2.position.set(-1.2, lvY(11), lvW(11) - 0.5); T2.scale.setScalar(1.6); scene.add(T2);
  const glow = new THREE.PointLight(0x9ad0ff, 3, 6, 1.5); glow.position.set(-1.2, lvY(11) + 2, lvW(11) - 1.5); scene.add(glow);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      T1.set(0.95); T2.set(lerp(0.95, 0.55, easeInOut(range(t, 1.6, 3.6))));
      const k = easeInOut(range(t, 0.6, 2.6));
      const a = V(-3, 1.4, TOP + 1.2), b = V(-1.2, lvY(11) + 1.4, lvW(11) - 0.5);
      const look = a.clone().lerp(b, k), pos = V(-1, 2.6, TOP - 2.5).lerp(V(0.2, lvY(11) + 1.9, 0.6), k);
      place(c, [pos.x, pos.y, pos.z], [look.x, look.y - 0.1, look.z]);
      return { bloom: 0.5, warm: lerp(1.45, 1.05, k) };
    },
  };
}
// ============ S10: people resting and talking in the shady galleries ============
function sShade({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [0.3, 0.8, 0.6], shadowSize: 14, shadowAt: [0, -7, -9] });
  const people = [0, 1, 2, 3].map(i => { const F = villager(i, { pot: i === 2 }); scene.add(F.root); return F; });
  const yF = -6.4, zF = -lvW(4.2) + 1.6;
  people.forEach((F, i) => { F.root.position.set(-2.7 + i * 1.6, yF, zF + (i % 2) * 0.3); F.root.rotation.y = (i % 2 ? -0.4 : 0.4); });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      people.forEach((F, i) => sit(F, t + i, i % 2));
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(1.5, 0.5, k), lerp(-4.5, -5.2, k), zF + lerp(9, 7.5, k)], [0, yF + 0.2, zF]);
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S11: Chand Baori, Rajasthan: golden aerial ============
function sChand({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [0.8, 0.25, 0.5] });
  SW.setWater(lvY(11.6));
  const b = birds(5, { from: [-30, 18, 10], to: [30, 22, -10], spread: 5, speed: 0.05, scale: 1.6, seed: 3 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const a = lerp(-0.4, 0.1, easeInOut(range(t, 0, 4.8)));
      place(c, [Math.sin(a) * 46, 20, Math.cos(a) * 46], [0, -4, 0]);
      return { bloom: 0.7, flare: 1.1, warm: 1.45 };
    },
  };
}
// ============ S12: dive from the top to the bottom, terraces flashing past ============
function sDive({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [-0.2, 0.9, 0.4] });
  SW.setWater(lvY(11.6));
  const c = cam(46);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.4));
      const wy = lvY(11.6); place(c, [0, lerp(14, wy + 17, k), lerp(5, 3, k)], [0, wy, -1]); /* stops above the water: it used to dive into it and fill the frame with green */
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S13: sunset, the woman walks away with a full pot; crane up ============
function sEnd({ makeStage }) {
  const { scene, SW } = site(makeStage, { sunDir: [0.8, 0.12, 0.6], shadowSize: 14, shadowAt: [4, 0, 16] });
  SW.setWater(lvY(11.6));
  const F = villager(0); scene.add(F.root);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const x = lerp(2, 8, t / 6); F.root.position.set(x, 0, TOP + 2.2); F.root.rotation.y = Math.PI / 2;
      walk(F, t); F.setMood('happy'); F.setMouth(0);
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(x - 3, -6, k), lerp(1.6, 26, k), lerp(TOP + 6, TOP + 28, k)], [lerp(x, 0, k), lerp(1.2, -8, k), lerp(TOP + 2, 0, k)]);
      return { bloom: 0.75, flare: 1.2, warm: 1.5 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sReveal], [ls(2), ls(3), sName], [ls(3), ls(4), sDry], [ls(4), ls(5), sLine],
  [ls(5), ls(6), sSteps], [ls(6), ls(7), sMonsoon], [ls(7), ls(8), sWalk], [ls(8), ls(9), sFill], [ls(9), ls(10), sCool],
  [ls(10), ls(11), sShade], [ls(11), ls(12), sChand], [ls(12), ls(13), sDive], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
