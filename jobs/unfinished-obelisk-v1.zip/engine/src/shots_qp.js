// Inca quipu reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, trees, ringSpots, birds } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll } from './rome.js';
import { terracedHill, incaMats } from './inca.js';
import { quechua } from './andes.js';
import { quipu, cord, llama, maizeCob } from './quipu.js';
import { riceBasket } from './props60.js';
import { VO } from './vo_qp.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(10) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This bundle', 2], ['of *string*', 2], ['ran an *empire*', 3]],
  [["It's a *quipu*", 3], ['the *Inca*', 2], ['record keeper', 2]],
  [['The Inca ruled', 3], ['*millions*', 1], ['of people', 2], ['but *never* used', 3], ['a *written script*', 3]],
  [['Instead', 1], ['trained', 1], ['*knot keepers*', 2], ['tied *numbers*', 2], ['into', 1], ['cotton *cords*', 2]],
  [['Each cord', 2], ['works like', 2], ['our *decimal*', 2], ['numbers', 1]],
  [['Knots near', 2], ['the *top*', 2], ['count', 1], ['*hundreds*', 1], ['the next group', 3], ['counts *tens*', 2]],
  [['Long', 1], ['*looped* knots', 2], ['at the *bottom*', 3], ['count *ones*', 2], ['and a *gap*', 3], ['means *zero*', 2]],
  [['So *three* knots', 3], ['*two* knots', 2], ['and a', 2], ['*seven* loop knot', 3], ['read', 1], ['*327*', 4]],
  [['*Colors*', 1], ['may have', 2], ['marked', 1], ['what was counted', 3], ['like *llamas*', 2], ['or *maize*', 2]],
  [['*Spanish* officials', 2], ['*destroyed* many', 2], ['About', 1], ['*600* survive', 3]],
  [['And some', 2], ['may hold', 2], ['more than', 2], ['*numbers*', 1], ['a *code*', 2], ['nobody has', 2], ['*cracked*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
function skyTint(scene, top, mid, hor, floor) { const u = scene.userData.sky.material.uniforms; u.top.value.set(top); u.mid.value.set(mid); u.horizon.value.set(hor); u.floorC.value.set(floor); }

// ============ shared: Andean terraces, stone walls ============
function andes(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.55, 0.4, 0.73], fog: 0.004, shadowSize: 4, envI: 0.95, cloud: 0.3, ...opts });
  const M = incaMats();
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 64), new THREE.MeshStandardMaterial({ color: 0x8a8a4a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const th = terracedHill({ levels: 10, r0: 34, step: 2.6, rise: 1.6 }); th.position.set(0, 0, -70); scene.add(th);
  scene.add(mountains({ rMin: 110, rMax: 320, height: 80, seed: 9, color: 0x5a6a48 }));
  fillLight(scene, [0.5, 0.5, 1], 0.6, 0xffe0bc);
  const b = birds(3, { from: [-30, 18, -40], to: [30, 22, -50], spread: 5, speed: 0.04, scale: 1.6, seed: 7 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  return scene;
}
// a keeper holding a quipu up by the main cord
function holdQuipu(man, q, t, { y = 1.25, d = 0.45 } = {}) {
  man.root.updateMatrixWorld(true);
  const c = wpos(man.root, V(0, y, d)); q.position.copy(c); q.quaternion.copy(man.root.quaternion); q.updateMatrixWorld(true);
  ikArm(man, 'l', wpos(q, V(0.3, 0.0, 0)), wpos(man.root, V(0.7, 0.3, 0)), V(0, 1, 0));
  ikArm(man, 'r', wpos(q, V(-0.3, 0.0, 0)), wpos(man.root, V(-0.7, 0.3, 0)), V(0, 1, 0));
}

// ============ S0 hook: the quipu held up, pull back to the terraced empire ============
function sHook({ makeStage, start: ST }) {
  const tE = at(0, 'empire') - ST;
  const scene = andes(makeStage);
  const man = quechua(0); man.root.position.set(0, 0, 0); scene.add(man.root);
  const q = quipu({ n: 24, W: 0.62, L: 0.48, seed: 4 }); scene.add(q);
  const others = [[-3, -6, 0.4, 1], [2.5, -9, -0.6, 2], [-5, -13, 0.2, 3]].map(([x, z, ry, i]) => { const p = quechua(i); p.root.position.set(x, 0, z); p.root.rotation.y = ry; scene.add(p.root); return p; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      standPose(man, t, { head: [0.15, 0, 0] }); man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [1.0])); man.grip(0.9, 0.9);
      holdQuipu(man, q, t);
      q.cords.forEach((cd, i) => { cd.rotation.x = Math.sin(t * 1.4 + i * 0.4) * 0.05; });
      others.forEach((p, i) => { standPose(p, t + i, {}); p.setMood('happy'); });
      const k = easeInOut(range(t, 0.2, tE + 0.8));
      const pos = [lerp(0.15, 0.9, k), lerp(1.05, 1.5, k), lerp(1.05, 4.8, k)], look = [lerp(0, -0.6, k), lerp(1.05, 4.5, k), lerp(0.4, -40, k)];
      place(c, pos, look);
      return { bloom: 0.55, flare: 0.9, warm: 1.2, dof: k < 0.4 ? dofTo(pos, look, 0.003, 0.008) : undefined };
    },
  };
}
// ============ macro stage: quipu on a dark cloth, warm light ============
function darkCloth(makeStage, col = 0x2a1a14) {
  const scene = makeStage({ shadowSize: 0.8, sunDir: [-1.2, 2.5, 2], sun: 2.2, hemi: 0.2 });
  skyTint(scene, 0x120c0a, 0x1a120e, 0x221812, 0x120c0a);
  const cloth = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), new THREE.MeshStandardMaterial({ color: col, roughness: 1, bumpMap: fabricTexture(7), bumpScale: 3 })); cloth.position.z = -0.2; cloth.receiveShadow = true; scene.add(cloth);
  fillLight(scene, [0.8, 0.4, 0.6], 0.6, 0xffc890);
  return scene;
}
function sQuipu({ makeStage }) {
  const scene = darkCloth(makeStage);
  const q = quipu({ n: 30, W: 0.8, L: 0.55, seed: 8 }); q.position.y = 0.3; scene.add(q);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      q.cords.forEach((cd, i) => { cd.rotation.x = Math.sin(t * 1.2 + i * 0.5) * 0.04; });
      const k = easeInOut(range(t, 0, 2.7));
      const pos = [lerp(-0.25, 0.2, k), lerp(0.18, 0.12, k), lerp(0.55, 0.6, k)], look = [lerp(-0.12, 0.1, k), 0.08, 0];
      place(c, pos, look, 0.05);
      return { bloom: 0.4, warm: 1.2, dof: dofTo(pos, look, 0.006, 0.008) };
    },
  };
}
// ============ S2: an Inca town on the terraces, people coming and going ============
function sTown({ makeStage, start: ST }) {
  const scene = andes(makeStage, { sunDir: [0.5, 0.45, 0.74] });
  const M = incaMats(), A = archMats();
  const R = (s => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296)(5);
  const houses = [];
  for (let i = 0; i < 14; i++) {
    const x = -14 + (i % 7) * 4.4 + R() * 1.2, z = -6 - Math.floor(i / 7) * 6 - R() * 1.5;
    const h = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.8, 2.2), A.stone); h.position.set(x, 0.9, z); scene.add(shadowAll(h));
    const roof = new THREE.Mesh(new THREE.ConeGeometry(2.2, 1.6, 4), new THREE.MeshStandardMaterial({ color: 0xc8a860, roughness: 1, bumpMap: fabricTexture(17), bumpScale: 3 })); roof.rotation.y = Math.PI / 4; roof.scale.set(1, 1, 0.8); roof.position.set(x, 2.6, z); scene.add(shadowAll(roof));
    houses.push(h);
  }
  const people = [...Array(14)].map((_, i) => { const p = quechua(i); p.root.position.set(-10 + i * 1.5, 0, 2 + (i % 3) * 1.2); p.root.rotation.y = i % 2 ? Math.PI / 2 : -Math.PI / 2; scene.add(p.root); return { p, i }; });
  const ll = [0, 1, 2].map(i => { const l = llama([0xe8dcc8, 0x8a5a34, 0xf4f0e8][i]); l.rotation.y = 0; scene.add(l); return l; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      people.forEach(({ p, i }) => { const dir = i % 2 ? 1 : -1; p.root.position.x = -12 + ((i * 1.7 + t * 0.9 * dir + 40) % 24); const s = Math.sin(t * 6 + i); standPose(p, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07], lSh: [-s * 0.25, 0, 0.16], rSh: [s * 0.25, 0, -0.16] }); p.setMood('happy'); });
      ll.forEach((l, i) => { l.position.set(-8 + ((t * 0.8 + i * 1.6) % 16), 0, 4.5 + i * 0.3); l.walk(t + i); });
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(10, 7, k), lerp(7, 5, k), lerp(16, 13, k)], [lerp(-2, -1, k), 1.5, lerp(-4, -3, k)]);
      return { bloom: 0.55, flare: 0.9, warm: 1.2 };
    },
  };
}
// ============ S3: a knot keeper ties knots into a cord on a frame ============
function sTie({ makeStage, start: ST }) {
  const tT = at(3, 'tied') - ST;
  const scene = andes(makeStage, { sunDir: [-0.4, 0.5, 0.77] });
  const A = archMats();
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.4, 10), A.wood); rod.rotation.z = Math.PI / 2; rod.position.set(0, 1.55, 0); scene.add(shadowAll(rod));
  for (const s of [-1, 1]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 1.6, 10), A.wood); p.position.set(s * 0.68, 0.8, 0); scene.add(shadowAll(p)); }
  const q = quipu({ n: 18, W: 1.1, L: 0.7, seed: 12 }); q.position.set(0, 1.55, 0); scene.add(q);
  const one = q.cords[9];
  const man = quechua(1); man.root.position.set(0.05, 0, 0.55); man.root.rotation.y = Math.PI; scene.add(man.root);
  const knots = [...one.zones.h, ...one.zones.t, ...one.zones.o];
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      knots.forEach((kn, i) => { const a = easeOut(range(t, tT - 1.2 + i * 0.35, tT - 0.9 + i * 0.35)); kn.scale.setScalar(Math.max(1e-3, a)); if (kn.isMesh) kn.scale.y *= 0.75; });
      standPose(man, t, { head: [0.2, 0, 0], spine: [0.1, 0, 0] }); man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.9, 2.4])); man.grip(0.6, 0.6);
      scene.updateMatrixWorld(true);
      const kp = one.localToWorld(one.curve.getPoint(lerp(0.2, 0.8, range(t, tT - 1.2, tT + 1.5))));
      ikArm(man, 'l', kp.clone().add(V(0.04, 0, 0.05)), wpos(man.root, V(0.7, 0.2, 0)), V(0, 1, 0));
      ikArm(man, 'r', kp.clone().add(V(-0.04, -0.02, 0.05)), wpos(man.root, V(-0.7, 0.2, 0)), V(0, 1, 0));
      const k = easeInOut(range(t, 0, 3.2));
      const pos = [lerp(-0.9, -0.6, k), lerp(1.55, 1.4, k), lerp(-1.6, -1.2, k)], look = [lerp(0.0, 0.05, k), lerp(1.3, 1.15, k), 0.2];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.2, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S4-S7: one cord, close up, value 327 (and 305 for the zero) ============
function cordStage(makeStage, extra = false) {
  const scene = darkCloth(makeStage, 0x221410);
  const main = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 3, 12), new THREE.MeshStandardMaterial({ color: 0xd8c8a0, roughness: 0.95, bumpMap: fabricTexture(11), bumpScale: 2 })); main.rotation.z = Math.PI / 2; main.position.y = 0.6; scene.add(main);
  const c327 = cord(327, { L: 1.0, r: 0.013, col: 0xe8dcc0, seed: 3 }); c327.position.set(0, 0.585, 0); scene.add(c327);
  const side = [-0.32, 0.32].map((x, i) => { const cd = cord([145, 62][i], { L: 0.95, r: 0.013, col: [0x8a5a34, 0xb83a2a][i], seed: 7 + i }); cd.position.set(x, 0.585, 0); scene.add(cd); return cd; });
  let c305 = null;
  if (extra) { c305 = cord(305, { L: 1.0, r: 0.013, col: 0x4a3a2a, seed: 5 }); c305.position.set(0.16, 0.585, 0.02); scene.add(c305); side[1].visible = false; }
  const ring = glowSprite(0xffd060, 0.12); ring.material.opacity = 0; scene.add(ring);
  return { scene, c327, c305, side, ring };
}
function sDecimal({ makeStage }) {
  const { scene, c327 } = cordStage(makeStage);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      c327.rotation.x = Math.sin(t * 1.1) * 0.03;
      const k = easeInOut(range(t, 0, 2.6));
      const pos = [lerp(0.5, 0.25, k), lerp(0.7, 0.2, k), lerp(1.6, 1.5, k)], look = [0, lerp(0.35, 0.1, k), 0];
      place(c, pos, look);
      return { bloom: 0.4, warm: 1.15 };
    },
  };
}
function sPlaces({ makeStage, start: ST }) {
  const tH = at(5, 'hundreds') - ST, tT = at(5, 'tens') - ST, tTop = at(5, 'top') - ST;
  const { scene, c327 } = cordStage(makeStage);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      c327.glow('h', 1.4 * easeOut(range(t, tTop - 0.1, tH)) * (1 - 0.7 * range(t, tT - 0.4, tT)));
      c327.glow('t', 1.4 * easeOut(range(t, tT - 0.4, tT)));
      c327.rotation.x = Math.sin(t * 1.1) * 0.03;
      const yk = kf(t, [[0, 0.42], [tH, 0.38], [tT - 0.3, 0.38], [tT + 0.4, 0.1]], easeInOut);
      const pos = [0.22, yk + 0.05, 0.85], look = [0, yk, 0];
      place(c, pos, look);
      return { bloom: 0.6, warm: 1.15, dof: dofTo(pos, look, 0.004, 0.008) };
    },
  };
}
function sOnes({ makeStage, start: ST }) {
  const tO = at(6, 'ones') - ST, tZ = at(6, 'zero') - ST, tG = at(6, 'gap') - ST;
  const { scene, c327, c305, ring } = cordStage(makeStage, true);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      c327.glow('o', 1.4 * easeOut(range(t, 0.2, tO)) * (1 - 0.8 * range(t, tG - 0.4, tG)));
      // the zero: the empty tens spot on the dark cord gets a soft halo
      c305.updateMatrixWorld(true);
      const zp = c305.localToWorld(c305.curve.getPoint(0.52));
      ring.position.copy(zp); ring.position.z += 0.02; ring.material.opacity = 0.8 * easeOut(range(t, tG - 0.2, tZ)); ring.scale.setScalar(0.09 + 0.01 * Math.sin(t * 6));
      c305.glow('h', 0.6 * easeOut(range(t, tG - 0.2, tZ))); c305.glow('o', 0.6 * easeOut(range(t, tG - 0.2, tZ)));
      const yk = kf(t, [[0, -0.15], [tO, -0.2], [tG - 0.4, -0.2], [tZ, 0.05]], easeInOut);
      const xk = kf(t, [[0, 0.0], [tG - 0.4, 0.0], [tZ, 0.1]], easeInOut);
      const pos = [xk + 0.22, yk + 0.05, lerp(0.8, 1.05, range(t, tG - 0.4, tZ))], look = [xk, yk, 0];
      place(c, pos, look);
      return { bloom: 0.6, warm: 1.15, dof: dofTo(pos, look, 0.004, 0.008) };
    },
  };
}
function sRead({ makeStage, start: ST }) {
  const t3 = at(7, 'three') - ST, t2 = at(7, 'two') - ST, t7 = at(7, 'seven') - ST, tR = at(7, 'read') - ST;
  const { scene, c327 } = cordStage(makeStage);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const pulse = (arr, t0, step) => arr.forEach((kn, i) => { const a = Math.sin(Math.PI * range(t, t0 + i * step, t0 + i * step + 0.35)); kn.traverse(m => { if (m.isMesh) m.material.emissiveIntensity = Math.max(m.material.emissiveIntensity * 0.0, 1.6 * a + (t > tR ? 1.0 * easeOut(range(t, tR, tR + 0.4)) : 0)); }); });
      pulse(c327.zones.h, t3 - 0.1, 0.12); pulse(c327.zones.t, t2 - 0.1, 0.12);
      c327.zones.o.forEach(kn => kn.children.forEach((m, i) => { const a = Math.sin(Math.PI * range(t, t7 - 0.1 + i * 0.07, t7 + 0.25 + i * 0.07)); m.material.emissiveIntensity = 1.6 * a + (t > tR ? 1.0 * easeOut(range(t, tR, tR + 0.4)) : 0); }));
      c327.rotation.x = Math.sin(t * 1.1) * 0.03;
      const yk = kf(t, [[0, 0.4], [t3 + 0.3, 0.38], [t2 - 0.2, 0.12], [t7 - 0.2, -0.2], [tR, -0.2], [tR + 0.8, 0.12]], easeInOut);
      const z = kf(t, [[0, 0.75], [tR, 0.75], [tR + 0.8, 1.7]], easeInOut);
      place(c, [0.2, yk + 0.05, z], [0, yk, 0]);
      return { bloom: 0.65, warm: 1.15 };
    },
  };
}
// ============ S8: colours: llamas in the pasture, maize by the keeper ============
function sColors({ makeStage, start: ST }) {
  const tL = at(8, 'llamas') - ST, tM = at(8, 'maize') - ST;
  const scene = andes(makeStage, { sunDir: [-0.5, 0.45, 0.74] });
  const lls = [0, 1, 2, 3].map(i => { const l = llama([0xe8dcc8, 0x8a5a34, 0xf4f0e8, 0x5a4030][i]); scene.add(l); return l; });
  const man = quechua(2); man.root.position.set(0.9, 0, 1.4); man.root.rotation.y = -2.5; scene.add(man.root);
  const q = quipu({ n: 16, W: 0.5, L: 0.42, seed: 21 }); scene.add(q);
  const blanket = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.7), new THREE.MeshStandardMaterial({ color: 0xb83a2a, roughness: 1, bumpMap: fabricTexture(7), bumpScale: 3 })); blanket.rotation.x = -Math.PI / 2; blanket.position.set(-0.3, 0.005, 2.2); blanket.receiveShadow = true; scene.add(blanket);
  const cobs = [...Array(9)].map((_, i) => { const m = maizeCob(); m.position.set(-0.3 + ((i % 3) - 1) * 0.16, 0.04 + Math.floor(i / 3) * 0.035, 2.2 + (Math.floor(i / 3) - 1) * 0.1); m.rotation.set(Math.PI / 2, 0, 0.4 + i * 0.6); scene.add(m); return m; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      lls.forEach((l, i) => { l.position.set(-4 + ((t * 0.6 + i * 1.9) % 9), 0, -1.6 - i * 0.9); l.walk(t + i); });
      standPose(man, t, { head: [0.1, -0.4, 0] }); man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [1.2])); man.grip(0.9, 0.9);
      holdQuipu(man, q, t, { y: 1.15, d: 0.4 });
      // brown and yellow cords light up on the words
      q.cords.forEach((cd, i) => { const col = cd.mat.color.getHex(); const isL = col === 0x8a5a34, isM = col === 0xc8a050; cd.traverse(m => { if (m.isMesh) m.material.emissiveIntensity = (isL ? 0.9 * Math.sin(Math.PI * range(t, tL - 0.2, tL + 1.0)) : 0) + (isM ? 0.9 * Math.sin(Math.PI * range(t, tM - 0.2, tM + 1.0)) : 0); }); });
      const pan = easeInOut(range(t, tL + 0.3, tM));
      const pos = [lerp(-1.6, 1.0, pan), lerp(1.7, 1.3, pan), lerp(4.6, 4.0, pan)], look = [lerp(-1.2, -0.2, pan), lerp(1.1, 0.6, pan), lerp(-1.5, 1.8, pan)];
      place(c, pos, look);
      return { bloom: 0.55, flare: 0.9, warm: 1.2 };
    },
  };
}
// ============ S9a: quipus thrown on a fire; S9b: museum drawer of survivors ============
function sFire({ makeStage, start: ST }) {
  const scene = makeStage({ shadowSize: 1.2, sunDir: [-1, 2, 1], sun: 0.4, hemi: 0.15 });
  skyTint(scene, 0x140c08, 0x1e120c, 0x281810, 0x140c08);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0x3a3028, roughness: 1, bumpMap: fabricTexture(13), bumpScale: 3 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const A = archMats();
  for (let i = 0; i < 6; i++) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.9, 8), A.wood); l.rotation.set(Math.PI / 2, i * 0.55, 0.15); l.position.y = 0.08 + (i % 2) * 0.08; scene.add(shadowAll(l)); }
  const qs = [0, 1, 2].map(i => { const q = quipu({ n: 12, W: 0.4, L: 0.35, seed: 30 + i }); q.rotation.set(-1.2, i * 1.8, 0); q.position.set((i - 1) * 0.15, 0.3, 0.05 * i); scene.add(q); return q; });
  const flames = [...Array(16)].map((_, i) => { const s = glowSprite(i % 2 ? 0xff7a2a : 0xffc04a, 0.4); scene.add(s); return { s, i }; });
  const fl = new THREE.PointLight(0xff8a3a, 5, 6, 2); fl.position.set(0, 0.7, 0.3); scene.add(fl);
  const embers = [...Array(20)].map((_, i) => { const s = glowSprite(0xffa040, 0.02); scene.add(s); return { s, i }; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      flames.forEach(({ s, i }) => { s.position.set(Math.sin(i * 2.3) * 0.3, 0.2 + ((t * 1.3 + i / 16) % 1) * 0.8, Math.cos(i * 1.7) * 0.2); s.scale.setScalar(0.3 + 0.15 * Math.sin(t * 9 + i)); });
      embers.forEach(({ s, i }) => { const a = ((t * 0.5 + i / 20) % 1); s.position.set(Math.sin(i * 3.1) * 0.4 + a * 0.2, 0.4 + a * 1.6, Math.cos(i) * 0.2); s.material.opacity = 1 - a; });
      qs.forEach((q, i) => q.traverse(m => { if (m.isMesh && m.material.color) m.material.color.lerp(new THREE.Color(0x1a120c), 0.02); }));
      fl.intensity = 4.5 + 0.8 * Math.sin(t * 11);
      const k = easeInOut(range(t, 0, 2.0));
      place(c, [lerp(0.8, 0.6, k), lerp(1.0, 0.85, k), lerp(1.8, 1.4, k)], [0, 0.35, 0]);
      return { bloom: 0.8, warm: 1.3 };
    },
  };
}
function sMuseum({ makeStage }) {
  const scene = makeStage({ shadowSize: 1.0, sunDir: [-1.2, 3, 2.2], sun: 0.8, hemi: 0.2 });
  skyTint(scene, 0x0c0d10, 0x14161a, 0x1a1c20, 0x0c0d10);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: 0.4 })); floor.rotation.x = -Math.PI / 2; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(10, 5), new THREE.MeshStandardMaterial({ color: 0x1e2024, roughness: 0.9 })); wall.position.set(0, 2.5, -0.5); scene.add(wall);
  const qs = [0, 1, 2, 3].map(i => { const q = quipu({ n: 14 + i * 3, W: 0.5 + i * 0.05, L: 0.4, seed: 40 + i }); q.position.set((i % 2 ? 0.45 : -0.45), 2.1 - Math.floor(i / 2) * 0.9, -0.45); scene.add(q); return q; });
  for (const [x, y] of [[-0.45, 2.1], [0.45, 2.1], [-0.45, 1.2], [0.45, 1.2]]) { const sp = new THREE.SpotLight(0xfff0d8, 6, 3, 0.4, 0.6, 1.5); sp.position.set(x, y + 0.9, 0.8); sp.target.position.set(x, y - 0.2, -0.45); scene.add(sp, sp.target); }
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeOut(range(t, 0, 2.2));
      place(c, [lerp(0.3, 0.1, k), lerp(1.75, 1.7, k), lerp(2.6, 3.1, k)], [0, 1.6, -0.45]);
      return { bloom: 0.45, warm: 1.0 };
    },
  };
}
// ============ S10: the unread code: slow dolly along knots in the dark ============
function sCode({ makeStage, start: ST }) {
  const tC = at(10, 'cracked') - ST;
  const scene = darkCloth(makeStage, 0x140c0a);
  const q = quipu({ n: 34, W: 1.0, L: 0.6, seed: 50 }); q.position.y = 0.35; scene.add(q);
  const rim = new THREE.SpotLight(0xffd8a0, 8, 4, 0.5, 0.7, 1.5); rim.position.set(1.2, 1.4, -0.6); rim.target.position.set(0, 0.1, 0); scene.add(rim, rim.target);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      q.cords.forEach((cd, i) => { cd.rotation.x = Math.sin(t * 0.9 + i * 0.5) * 0.04; cd.traverse(m => { if (m.isMesh) m.material.emissiveIntensity = 0.5 * Math.max(0, Math.sin(t * 1.6 - i * 0.5)) * (i % 5 === 0 ? 1 : 0); }); });
      const k = easeInOut(range(t, 0, 4.4));
      const pos = [lerp(-0.45, 0.35, k), lerp(0.1, 0.0, k), lerp(0.45, 0.4, k)], look = [lerp(-0.3, 0.25, k), lerp(0.05, -0.02, k), 0];
      place(c, pos, look, 0.04);
      return { bloom: 0.6, warm: 1.2, dof: dofTo(pos, look, 0.008, 0.008), exposure: lerp(1, 0.8, range(t, tC, tC + 1.2)) };
    },
  };
}

// ============ timeline ============
const cA = at(9, 'about') - 0.06;
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sQuipu, 'quipu'],
  [ls(2), ls(3), sTown, 'town'],
  [ls(3), ls(4), sTie, 'tie'],
  [ls(4), ls(5), sDecimal, 'decimal'],
  [ls(5), ls(6), sPlaces, 'places'],
  [ls(6), ls(7), sOnes, 'ones'],
  [ls(7), ls(8), sRead, 'read'],
  [ls(8), ls(9), sColors, 'colors'],
  [ls(9), cA + 0.12, sFire, 'fire'],
  [cA + 0.12, ls(10), sMuseum, 'museum'],
  [ls(10), DURATION + 1, sCode, 'code'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
