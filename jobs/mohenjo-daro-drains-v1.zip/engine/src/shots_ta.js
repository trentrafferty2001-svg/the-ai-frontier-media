// Terracotta Army reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, trees, ringSpots, birds } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll, romanBuilder } from './rome.js';
import { mingWorker } from './rice.js';
import { VO } from './vo_ta.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Farmers', 1], ['digging a well', 3], ['found a', 2], ['*buried army*', 2]],
  [['It was the', 3], ['*Terracotta Army*', 2], ['about', 1], ['*8,000*', 2], ['life-size', 2], ['*clay soldiers*', 2]],
  [['They were made', 3], ["for China's", 2], ['*first emperor*', 2], ['*Qin Shi Huang*', 3], ['over', 1], ['*22 centuries* ago', 4]],
  [['Workers built them', 3], ['in *pieces*', 2], ['*legs*', 1], ['*bodies*', 1], ['*arms* and', 2], ['*heads*', 1], ['then fired them', 3], ['in *kilns*', 2]],
  [['Every face', 2], ['was *finished*', 2], ['*by hand*', 2], ['so no two', 3], ['look quite *alike*', 3]],
  [['They were once', 3], ['painted in', 2], ['*bright colors*', 2], ['but much of', 3], ['the paint', 2], ['*flaked away*', 2], ['after they were', 3], ['*dug up*', 2]],
  [['They carried', 2], ['real *bronze weapons*', 3], ['too', 1], ['*swords*', 1], ['*spears*', 1], ['and *crossbows*', 2]],
  [["And the emperor's", 3], ['*own tomb*', 2], ['nearby', 1], ['has *never*', 2], ['been *opened*', 2]],
  [['The historian', 2], ['*Sima Qian*', 2], ['wrote that', 2], ['it held', 2], ['*rivers of mercury*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;

// ---------- the soldier ----------
const CLAY = 0x9a7458;
function clayMat(tint = 0) { return new THREE.MeshStandardMaterial({ color: new THREE.Color(CLAY).offsetHSL(0, 0, tint), roughness: 1, bumpMap: fabricTexture(19), bumpScale: 2 }); }
// a warrior: the shared figure in clay, with lamellar armour, a topknot and an optional painted look
export function warrior({ seed = 1, painted = false, armour = true } = {}) {
  const R = R0(seed);
  const h = romanBuilder({ color: 0xc8b090, skin: 0xd0a080 });
  const clay = clayMat((R() - 0.5) * 0.06);
  const paint = { tunic: new THREE.MeshStandardMaterial({ color: [0xb83a2a, 0x3a7a4a, 0x6a3a8a][seed % 3], roughness: 0.8 }), skin: new THREE.MeshStandardMaterial({ color: 0xe8c8a8, roughness: 0.7 }), armour: new THREE.MeshStandardMaterial({ color: 0x2a2a30, roughness: 0.6 }) };
  const parts = [];
  h.root.traverse(o => { if (o.isMesh) { parts.push({ o, orig: o.material }); o.material = clay; } });
  const armM = painted ? paint.armour : clay;
  if (armour) {
    const vest = new THREE.Mesh(new THREE.CylinderGeometry(0.215, 0.24, 0.42, 20, 4, true), armM.clone ? armM : armM); vest.material = painted ? paint.armour : clay; vest.scale.set(1.12, 1, 0.72); vest.position.y = 0.04; h.j.chest.add(vest);
    for (let r = 0; r < 4; r++) { const band = new THREE.Mesh(new THREE.TorusGeometry(0.235, 0.012, 6, 24), painted ? new THREE.MeshStandardMaterial({ color: 0xc83a3a }) : clay); band.rotation.x = Math.PI / 2; band.scale.set(1.12, 0.72, 1); band.position.y = -0.14 + r * 0.1; h.j.chest.add(band); }
  }
  const knot = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 10), painted ? new THREE.MeshStandardMaterial({ color: 0x1a1410 }) : clay); knot.position.set(0.05, 0.17, -0.04); h.j.head.add(knot);
  if (R() > 0.4) { const m = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.012, 0.01), painted ? new THREE.MeshStandardMaterial({ color: 0x1a1410 }) : clay); m.position.set(0, -0.05, 0.155); h.j.head.add(m); }
  h.root.scale.setScalar(1.0 + (R() - 0.5) * 0.08);
  h.paintSet = (k) => { const skinC = new THREE.Color(0xd0a080); parts.forEach(({ o, orig }) => { if (!o.userData.pm) { const oc = orig.color ? orig.color : new THREE.Color(0xffffff); const isSkin = Math.abs(oc.r - skinC.r) + Math.abs(oc.g - skinC.g) + Math.abs(oc.b - skinC.b) < 0.12; o.userData.pc = isSkin ? new THREE.Color(0xf0d0b0) : (oc.getHSL({}).l < 0.25 ? oc.clone() : new THREE.Color([0xb83a2a, 0x3a8a4a, 0x7a3a9a][seed % 3])); o.userData.pm = new THREE.MeshStandardMaterial({ color: o.userData.pc.clone(), roughness: 0.8 }); } o.material = o.userData.pm; o.material.color.copy(o.userData.pc).lerp(new THREE.Color(CLAY), 1 - k); }); };
  shadowAll(h.root);
  return h;
}
function standGuard(h, t, i = 0) { standPose(h, 0.3 * i, { rSh: [-0.35, 0, -0.1], rEl: [-1.2, 0, 0], lSh: [0.05, 0, 0.12] }); h.setMood('happy'); h.setMouth(0); h.blink(0); }
function pit(scene, { rows = 5, len = 40 } = {}) {
  const earth = new THREE.MeshStandardMaterial({ color: 0x8a6a4a, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 6 });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: 0x7a5a3e, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  for (let r = 0; r <= rows; r++) { const w = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.6, len), earth); w.position.set(-rows * 2.0 + r * 4.0, 1.3, -len / 2 + 4); w.castShadow = w.receiveShadow = true; scene.add(w); }
  const rim = new THREE.Mesh(new THREE.BoxGeometry(200, 2.6, 30), earth); rim.position.set(0, 1.3, 22); scene.add(rim);
}

// ============ S0 hook: a hoe strikes a clay head in the dry field ============
function sHook({ makeStage, start: ST }) {
  const tA = at(0, 'army') - ST;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.55, 0.67], fog: 0.004, shadowSize: 3, envI: 0.95, cloud: 0.4 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(300, 48), new THREE.MeshStandardMaterial({ color: 0x9a7a52, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 5 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 120, rMax: 300, height: 50, seed: 3, color: 0x7a8a5a }));
  scene.add(trees(ringSpots(30, 25, 80, 4, [0, 0, 0], 0, Math.PI * 2, 0), { seed: 2, scale: 1.6 }));
  const hole = new THREE.Mesh(new THREE.CircleGeometry(0.9, 32), new THREE.MeshStandardMaterial({ color: 0x4a3626, roughness: 1 })); hole.rotation.x = -Math.PI / 2; hole.position.y = 0.01; scene.add(hole);
  const sol = warrior({ seed: 3, armour: false }); sol.root.position.set(0.05, -1.48, 0.05); sol.root.rotation.set(-0.15, 0.4, 0.1); scene.add(sol.root);
  const farmer = mingWorker(1); farmer.root.position.set(-0.4, 0, 1.25); farmer.root.rotation.y = Math.PI - 0.3; scene.add(farmer.root);
  const hoe = new THREE.Group(); const A = archMats(); const hs = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.4, 8), A.wood); hs.position.y = 0.7; hoe.add(hs); const hb = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.02, 0.16), new THREE.MeshStandardMaterial({ color: 0x4a4a4e, metalness: 0.7, roughness: 0.4 })); hb.position.set(0, 0, 0.06); hoe.add(hb); shadowAll(hoe); scene.add(hoe);
  const dust = [...Array(14)].map((_, i) => { const s = glowSprite(0xb89a70, 0.2); s.material.blending = THREE.NormalBlending; scene.add(s); return { s, i }; });
  const c = cam(38);
  const tHit = 1.15;
  return {
    scene, camera: c,
    update(t) {
      standGuard(sol, 0, 0);
      const swing = t < tHit ? Math.sin(Math.PI * t / tHit) : 0;
      standPose(farmer, t, { spine: [0.35 + swing * 0.2, 0, 0], head: [0.3, 0, 0], drop: -0.03 }); farmer.setMood('happy'); farmer.setMouth(t > tHit + 0.2 ? 0.7 : 0); farmer.blink(blinkK(t, [0.5])); farmer.grip(0.95, 0.95);
      farmer.root.updateMatrixWorld(true);
      const tip = V(0.15, 0.32 + swing * 0.6, 0.35); hoe.position.copy(tip); hoe.lookAt(wpos(farmer.root, V(0, 1.2, 0.3))); hoe.rotateX(Math.PI / 2); hoe.updateMatrixWorld(true);
      ikArm(farmer, 'l', wpos(hoe, V(0, 0.9, 0)), wpos(farmer.root, V(0.7, 0.2, 0.2)), V(0, 1, 0)); ikArm(farmer, 'r', wpos(hoe, V(0, 0.6, 0)), wpos(farmer.root, V(-0.7, 0.2, 0.2)), V(0, 1, 0));
      dust.forEach(({ s, i }) => { const a = range(t, tHit, tHit + 0.9); s.visible = a > 0 && a < 1; s.position.set(Math.sin(i * 2.1) * a * 0.6, 0.05 + a * 0.5, Math.cos(i * 1.3) * a * 0.6); s.scale.setScalar(0.1 + a * 0.4); s.material.opacity = 0.5 * (1 - a); });
      const k = easeInOut(range(t, 0, 2.2));
      const sh = t > tHit && t < tHit + 0.25 ? shake(t * 6, 2, 3) : [0, 0, 0];
      const pos = [lerp(0.9, 0.55, k) + sh[0] * 0.01, lerp(1.4, 0.75, k) + sh[1] * 0.01, lerp(1.9, 1.0, k)], look = [0.05, lerp(0.1, -0.05, k), 0.05];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.15, dof: dofTo(pos, look, 0.003, 0.008) };
    },
  };
}
// ============ S1: the pit: rows of soldiers, dolly up and back ============
function army(scene, n = 5, depth = 9, { painted = false } = {}) {
  const base = [0, 1, 2, 3].map(s => warrior({ seed: s + 10, painted }));
  const out = [];
  for (let r = 0; r < n; r++) for (let d = 0; d < depth; d++) { const src = base[(r + d) % 4]; const cl = src.root.clone(true); cl.position.set(-n * 2.0 + 2.0 + r * 4.0 + ((d % 2) - 0.5) * 0.8, 0, 2 - d * 1.6); scene.add(cl); out.push(cl); }
  base.forEach((b, i) => standGuard(b, 0, i));
  base.forEach((b) => b.root.updateMatrixWorld(true));
  return out;
}
function armyScene(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.4, 0.75, 0.52], fog: 0.004, shadowSize: 22, envI: 0.9, cloud: 0.35, ...opts });
  pit(scene, { rows: 5, len: 40 });
  // soldiers: pose the templates first, then clone into rows
  const base = [0, 1, 2, 3].map(s => { const w = warrior({ seed: s + 10 }); standGuard(w, 0, s); w.root.updateMatrixWorld(true); return w; });
  for (let r = 0; r < 5; r++) for (let d = 0; d < 12; d++) { const cl = base[(r * 3 + d) % 4].root.clone(true); cl.position.set(-8 + r * 4.0 + ((d % 2) - 0.5) * 0.8, 0, 2 - d * 1.5); cl.rotation.y = 0; scene.add(cl); }
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe8cc);
  return scene;
}
function sPit({ makeStage }) {
  const scene = armyScene(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(0.6, 3, k), lerp(1.8, 9, k), lerp(5.5, 12, k)], [lerp(0, 0, k), lerp(1.4, 0.5, k), lerp(-2, -8, k)]);
      return { bloom: 0.4, warm: 1.05 };
    },
  };
}
// ============ S2: the first emperor on his throne ============
function sEmperor({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [-1, 2.5, 2], sun: 1.6, hemi: 0.3 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x1a0e0a); u.mid.value.set(0x2a1610); u.horizon.value.set(0x3a1e14); u.floorC.value.set(0x1a0e0a);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), new THREE.MeshStandardMaterial({ color: 0x2a1a14, roughness: 0.4 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const red = new THREE.MeshStandardMaterial({ color: 0x7a1a14, roughness: 0.6 }), gold = new THREE.MeshStandardMaterial({ color: 0xc8a050, metalness: 0.85, roughness: 0.3 });
  for (const x of [-3, 3]) { const col = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 6, 16), red); col.position.set(x, 3, -2); scene.add(shadowAll(col)); }
  const dais = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.5, 2.4), new THREE.MeshStandardMaterial({ color: 0x3a2418 })); dais.position.set(0, 0.25, -1); scene.add(shadowAll(dais));
  const throne = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.6, 0.3), gold); throne.position.set(0, 1.3, -1.9); scene.add(shadowAll(throne));
  const emp = romanBuilder({ color: 0x15151a, skin: 0xd8a878 });
  const crown = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.03, 0.28), new THREE.MeshStandardMaterial({ color: 0x15151a })); crown.position.set(0, 0.23, 0); emp.j.head.add(crown);
  for (let i = 0; i < 6; i++) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.16, 6), gold); b.position.set(-0.12 + i * 0.05, 0.14, 0.14); emp.j.head.add(b); }
  emp.root.position.set(0, 0.5, -1.4); scene.add(emp.root); shadowAll(emp.root);
  const lamps = [-2, 2].map(x => { const l = new THREE.PointLight(0xffa860, 2.4, 6, 2); l.position.set(x, 2.4, 0.5); scene.add(l); const f = glowSprite(0xffc070, 0.2); f.position.copy(l.position); scene.add(f); return l; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standPose(emp, t, { lHip: [-1.4, 0, 0.1], rHip: [-1.4, 0, -0.1], lKn: [1.4, 0, 0], rKn: [1.4, 0, 0], drop: -0.42, lSh: [-0.3, 0, 0.2], rSh: [-0.3, 0, -0.2], lEl: [-1.0, 0, 0], rEl: [-1.0, 0, 0], head: [0, 0, 0] }); emp.setMood('happy'); emp.setMouth(0); emp.blink(blinkK(t, [1.6]));
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(0.3, 0.1, k), lerp(1.4, 1.5, k), lerp(4.2, 2.6, k)], [0, lerp(1.3, 1.45, k), -1.4]);
      return { bloom: 0.6, warm: 1.35 };
    },
  };
}
// ============ S3: a workshop: parts laid out, a kiln glowing ============
function sParts({ makeStage, start: ST }) {
  const tK = at(3, 'kilns') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.45, 0.74], fog: 0.004, shadowSize: 5, envI: 0.95, cloud: 0.3 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(200, 48), new THREE.MeshStandardMaterial({ color: 0x9a7a52, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const clay = clayMat(0);
  const words = ['legs', 'bodies', 'arms', 'heads'].map(w => at(3, w) - ST);
  const groups = [[0, 'legs'], [1, 'bodies'], [2, 'arms'], [3, 'heads']].map(([i]) => { const g = new THREE.Group(); g.position.set(-2.4 + i * 1.6, 0, 0); scene.add(g); return g; });
  for (let k = 0; k < 3; k++) {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.07, 0.8, 12), clay); leg.position.set(-0.25 + k * 0.25, 0.4, 0); groups[0].add(leg);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.26, 0.7, 16), clay); body.position.set(-0.3 + k * 0.3, 0.35, (k % 2) * 0.3); body.scale.z = 0.75; groups[1].add(body);
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.5, 6, 10), clay); arm.rotation.z = Math.PI / 2; arm.position.set(0, 0.08 + k * 0.12, 0); groups[2].add(arm);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 12), clay); head.scale.y = 1.2; head.position.set(-0.3 + k * 0.3, 0.16, 0); groups[3].add(head); const kn = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), clay); kn.position.set(-0.3 + k * 0.3 + 0.03, 0.33, -0.03); groups[3].add(kn);
  }
  groups.forEach(g => shadowAll(g));
  const kiln = new THREE.Mesh(new THREE.SphereGeometry(1.6, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x8a5a3a, roughness: 1, bumpMap: fabricTexture(19), bumpScale: 4 })); kiln.scale.y = 1.2; kiln.position.set(0, 0, -4); scene.add(shadowAll(kiln));
  const mouth = new THREE.Mesh(new THREE.CircleGeometry(0.45, 24), new THREE.MeshBasicMaterial({ color: 0xffa040 })); mouth.position.set(0, 0.5, -2.45); scene.add(mouth);
  const kl = new THREE.PointLight(0xff8a3a, 0, 6, 2); kl.position.set(0, 0.7, -2.0); scene.add(kl);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      groups.forEach((g, i) => { const a = easeOut(range(t, words[i] - 0.25, words[i] + 0.15)); g.scale.setScalar(Math.max(0.001, a)); });
      const on = easeOut(range(t, tK - 0.8, tK)); kl.intensity = 4 * on * (0.85 + 0.15 * Math.sin(t * 11)); mouth.material.color.setRGB(0.3 + on * 0.7, 0.18 + on * 0.45, 0.08 + on * 0.17);
      const x = kf(t, [[0, -2.4], [words[0] + 0.1, -2.4], [words[1] + 0.1, -0.8], [words[2] + 0.1, 0.8], [words[3] + 0.1, 2.4], [tK - 0.6, 1.2], [tK + 0.6, 0]], easeInOut);
      const z = kf(t, [[0, 3.0], [tK - 0.6, 3.0], [tK + 0.6, 2.4]], easeInOut);
      place(c, [x, kf(t, [[0, 1.4], [tK - 0.6, 1.4], [tK + 0.6, 1.8]], easeInOut), z], [x * 0.9, kf(t, [[0, 0.3], [tK - 0.6, 0.3], [tK + 0.6, 0.8]], easeInOut), kf(t, [[0, 0], [tK - 0.6, 0], [tK + 0.6, -3.5]], easeInOut)]);
      return { bloom: 0.5 + on * 0.3, flare: 0.8, warm: 1.25 };
    },
  };
}
// ============ S4: a sculptor finishes a face; a row of heads, each different ============
function sFaces({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.6, 0.62], fog: 0.004, shadowSize: 6, envI: 0.9, cloud: 0.35 });
  const earth = new THREE.MeshStandardMaterial({ color: 0x8a6a4a, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 6 });
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshStandardMaterial({ color: 0x7a5a3e, roughness: 1 })); fl.rotation.x = -Math.PI / 2; fl.receiveShadow = true; scene.add(fl);
  const bw = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.6, 30), earth); bw.position.set(-2.2, 1.3, -6); bw.receiveShadow = true; scene.add(bw);
  const row = [...Array(7)].map((_, i) => { const w = warrior({ seed: 30 + i }); w.root.position.set(0, 0, 3 - i * 1.0); w.root.rotation.y = Math.PI / 2; w.root.updateMatrixWorld(true); standGuard(w, 0, i); w.setMouth(i % 3 === 0 ? 0.15 : 0); scene.add(w.root); return w; });
  row.forEach((w, i) => { w.j.head.scale.set(1 + ((i * 37) % 7 - 3) * 0.02, 1 + ((i * 53) % 5 - 2) * 0.03, 1); w.j.head.rotation.y = ((i * 29) % 5 - 2) * 0.06; });
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const z = lerp(3.3, -2.8, easeInOut(range(t, 0, 3.6)));
      const pos = [1.9, 1.65, z + 0.7], look = [0, 1.55, z - 0.3];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.1, exposure: 1.2, dof: dofTo(pos, [0, 1.6, z], 0.004, 0.008) };
    },
  };
}
// ============ S5: a painted soldier fades to bare clay, flakes drift off ============
function sPaint({ makeStage, start: ST }) {
  const tF = at(5, 'flaked') - ST;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.6, 0.62], fog: 0.004, shadowSize: 3, envI: 0.9, cloud: 0.35 });
  pit(scene, { rows: 2, len: 20 });
  const w = warrior({ seed: 41, painted: true }); w.root.position.set(2, 0, 0); scene.add(w.root);
  const flakes = [...Array(40)].map((_, i) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(0.03, 0.025), new THREE.MeshStandardMaterial({ color: [0xb83a2a, 0x3a7a4a, 0x6a3a8a, 0xe8c8a8][i % 4], side: THREE.DoubleSide })); scene.add(m); return { m, i }; });
  fillLight(scene, [0.4, 0.5, 1], 0.6);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standGuard(w, 0, 1);
      const k = 1 - easeInOut(range(t, tF - 0.6, tF + 1.4));
      w.paintSet(0.25 + 0.75 * k);
      flakes.forEach(({ m, i }) => { const a = range(t, tF - 0.6 + (i % 10) * 0.08, tF + 1.6 + (i % 10) * 0.08); m.visible = a > 0 && a < 1; m.position.set(2 + Math.sin(i * 2.3) * 0.25 + a * 0.2, 1.5 - (i % 7) * 0.12 - a * 1.2, 0.2 + Math.cos(i) * 0.05 + a * 0.15); m.rotation.set(t * 3 + i, t * 2, i); });
      const kc = easeInOut(range(t, 0, 5));
      const pos = [lerp(2.9, 2.6, kc), lerp(1.6, 1.55, kc), lerp(2.6, 2.0, kc)], look = [2, lerp(1.3, 1.35, kc), 0];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.1, dof: dofTo(pos, look, 0.003, 0.008) };
    },
  };
}
// ============ S6: bronze weapons: sword, spear, crossbow in a soldier's hands ============
function sWeapons({ makeStage, start: ST }) {
  const scene = makeStage({ shadowSize: 1.4, sunDir: [-1.2, 2.5, 2], sun: 2.0, hemi: 0.25 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x14100c); u.mid.value.set(0x1c1610); u.horizon.value.set(0x241c14); u.floorC.value.set(0x14100c);
  const bronze = new THREE.MeshStandardMaterial({ color: 0xb8904a, metalness: 0.9, roughness: 0.3 }), wood = archMats().wood;
  const cloth = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), new THREE.MeshStandardMaterial({ color: 0x2a1a14, roughness: 1, bumpMap: fabricTexture(7), bumpScale: 2 })); cloth.rotation.x = -Math.PI / 2; cloth.receiveShadow = true; scene.add(cloth);
  const sword = new THREE.Group(); const blade = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.006, 0.04), bronze); blade.position.x = 0.45; sword.add(blade); const tipS = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.06, 4), bronze); tipS.rotation.z = -Math.PI / 2; tipS.position.x = 0.93; sword.add(tipS); const guard = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 0.1), bronze); sword.add(guard); const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.18, 8), wood); grip.rotation.z = Math.PI / 2; grip.position.x = -0.1; sword.add(grip);
  sword.position.set(-0.5, 0.01, 0.2); sword.rotation.y = 0.2; scene.add(shadowAll(sword));
  const spear = new THREE.Group(); const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1.6, 8), wood); sh.rotation.z = Math.PI / 2; spear.add(sh); const head = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.22, 4), bronze); head.rotation.z = -Math.PI / 2; head.position.x = 0.9; spear.add(head);
  spear.position.set(-0.3, 0.015, -0.1); spear.rotation.y = -0.1; scene.add(shadowAll(spear));
  const xb = new THREE.Group(); const stock = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.05, 0.06), wood); xb.add(stock); const bow = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.014, 6, 24, Math.PI * 0.8), wood); bow.rotation.set(Math.PI / 2, 0, Math.PI * 0.1 - Math.PI / 2); bow.position.set(0.3, 0, 0); xb.add(bow); const trig = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.05, 0.04), bronze); trig.position.set(-0.1, 0.04, 0); xb.add(trig);
  xb.position.set(0.15, 0.03, -0.5); xb.rotation.y = 0.5; scene.add(shadowAll(xb));
  const words = ['swords', 'spears', 'crossbows'].map(w => at(6, w) - ST);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const target = kf(t, [[0, 0], [words[0], 0], [words[1], 1], [words[2], 2], [6, 2]], easeInOut);
      const P = [V(-0.05, 0, 0.25), V(0.1, 0, -0.1), V(0.25, 0, -0.5)];
      const i0 = Math.floor(clamp(target, 0, 1.999)), f = target - i0;
      const L = P[i0].clone().lerp(P[Math.min(2, i0 + 1)], f);
      const pos = [L.x * 0.6 + 0.2, 1.05, L.z * 0.6 + 1.5]; place(c, pos, [L.x * 0.8, 0.0, L.z * 0.8 - 0.1]);
      return { bloom: 0.55, warm: 1.25, exposure: 1.25 };
    },
  };
}
// ============ S7: the emperor's tomb mound at dusk, still unopened ============
function sMound({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.6, 0.12, -0.79], fog: 0.003, shadowSize: 60, envI: 0.95, cloud: 0.35 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 48), new THREE.MeshStandardMaterial({ color: 0x7a7a4a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const mound = new THREE.Mesh(new THREE.CylinderGeometry(18, 60, 40, 4, 1), new THREE.MeshStandardMaterial({ color: 0x5a6a3a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 6 })); mound.rotation.y = Math.PI / 4; mound.position.set(0, 20, -60); scene.add(shadowAll(mound));
  scene.add(trees(ringSpots(160, 0, 70, 6, [0, 0, -60], 0, Math.PI * 2, 0).map(([x, y, z]) => { const r = Math.max(Math.abs(x), Math.abs(z + 60)); const h = Math.max(0, 40 * (1 - r / 60)); return [x, h - 1, z]; }), { seed: 4, scale: 2.2 }));
  scene.add(mountains({ rMin: 200, rMax: 360, height: 60, seed: 9, color: 0x6a7a52 }));
  const b = birds(4, { from: [-50, 50, -70], to: [50, 56, -90], spread: 8, speed: 0.04, scale: 2.4, seed: 7 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  fillLight(scene, [0.4, 0.4, 1], 0.6, 0xffe0bc);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-30, -20, k), lerp(8, 12, k), lerp(60, 50, k)], [0, lerp(18, 22, k), -60]);
      return { bloom: 0.6, flare: 1.1, warm: 1.3 };
    },
  };
}
// ============ S8: inside, as the historian described it: rivers of mercury across a model empire ============
function sMercury({ makeStage, start: ST }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [-1, 2.5, 1.5], sun: 0.8, hemi: 0.15 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x080606); u.mid.value.set(0x0e0a08); u.horizon.value.set(0x140e0a); u.floorC.value.set(0x080606);
  const land = new THREE.Mesh(new THREE.PlaneGeometry(14, 14, 80, 80), new THREE.MeshStandardMaterial({ color: 0x3a2e22, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 6 }));
  const p = land.geometry.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); p.setZ(i, 0.35 * Math.sin(x * 0.8) * Math.cos(y * 0.6) + 0.2 * Math.sin(x * 2.1 + y)); } land.geometry.computeVertexNormals();
  land.rotation.x = -Math.PI / 2; land.receiveShadow = true; scene.add(land);
  const hg = new THREE.MeshStandardMaterial({ color: 0xd8dce0, metalness: 1, roughness: 0.05, emissive: 0x30343a, emissiveIntensity: 0.6 });
  const rivers = [0, 1].map(i => { const pts = []; for (let k = 0; k <= 30; k++) { const v = k / 30; pts.push(V(-7 + v * 14, 0.5, (i ? 2.2 : -1.6) + Math.sin(v * 7 + i) * 1.2)); } const c = new THREE.CatmullRomCurve3(pts); const m = new THREE.Mesh(new THREE.TubeGeometry(c, 200, 0.16, 8), hg); m.scale.y = 0.3; scene.add(m); return m; });
  const palace = new THREE.Group(); const red = new THREE.MeshStandardMaterial({ color: 0x6a1a14 }), roof = new THREE.MeshStandardMaterial({ color: 0x2a2a2a });
  for (let i = 0; i < 5; i++) { const h = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.4, 0.5), red); h.position.set(-1.6 + i * 0.8, 0.7, 0.3); palace.add(h); const r = new THREE.Mesh(new THREE.ConeGeometry(0.6, 0.25, 4), roof); r.rotation.y = Math.PI / 4; r.scale.z = 0.7; r.position.set(-1.6 + i * 0.8, 1.0, 0.3); palace.add(r); }
  scene.add(shadowAll(palace));
  const lamps = [-3, 3].map(x => { const l = new THREE.PointLight(0xffa860, 3, 8, 2); l.position.set(x, 2.5, 2); scene.add(l); return l; });
  const stars = [...Array(40)].map((_, i) => { const s = glowSprite(0xfff0c0, 0.06); s.position.set(Math.sin(i * 7.1) * 6, 5 + Math.cos(i * 3.3) * 1.5, Math.cos(i * 2.7) * 6 - 2); scene.add(s); return s; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      rivers.forEach((m, i) => { m.geometry.setDrawRange(0, Math.floor(200 * clamp(range(t, 0.2 + i * 0.3, 3.2 + i * 0.3)) * 8) * 6); });
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(-5, -2, k), lerp(4.5, 3.2, k), lerp(6, 5, k)], [lerp(-1, 0.5, k), 0.5, 0]);
      return { bloom: 0.75, warm: 1.2 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sPit, 'pit'],
  [ls(2), ls(3), sEmperor, 'emperor'],
  [ls(3), ls(4), sParts, 'parts'],
  [ls(4), ls(5), sFaces, 'faces'],
  [ls(5), ls(6), sPaint, 'paint'],
  [ls(6), ls(7), sWeapons, 'weapons'],
  [ls(7), ls(8), sMound, 'mound'],
  [ls(8), DURATION + 1, sMercury, 'mercury'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
