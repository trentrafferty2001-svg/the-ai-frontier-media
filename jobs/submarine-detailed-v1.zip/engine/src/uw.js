// Underwater world v4: murky green water column, bright rippling surface seen from below,
// sediment particles, god rays, bubbles, pebbly mud, rice tillers with roots.
import * as THREE from 'three';
import { TIME, NOISE } from './world.js';
import { rng } from './textures.js';
import { glowSprite } from './props.js';

let MUD = null;
function mudTexture() {
  if (MUD) return MUD;
  const cv = document.createElement('canvas'); cv.width = cv.height = 1024; const x = cv.getContext('2d'); x.scale(2, 2);
  x.fillStyle = '#4a3a27'; x.fillRect(0, 0, 512, 512);
  const R = rng(19);
  for (let i = 0; i < 2600; i++) { const v = 40 + R() * 60 | 0; x.fillStyle = `rgba(${v + 30},${v + 15},${v - 5},${0.08 + R() * 0.15})`; x.beginPath(); x.arc(R() * 512, R() * 512, 1 + R() * 9, 0, Math.PI * 2); x.fill(); }
  for (let i = 0; i < 160; i++) { const v = 90 + R() * 70 | 0; x.fillStyle = `rgba(${v},${v - 8},${v - 25},0.9)`; x.beginPath(); x.ellipse(R() * 512, R() * 512, 2 + R() * 6, 2 + R() * 5, R() * 3, 0, Math.PI * 2); x.fill(); }
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 3); t.anisotropy = 4;
  MUD = t; return t;
}

let LEAF = null;
function leafTexture() {
  if (LEAF) return LEAF;
  const cv = document.createElement('canvas'); cv.width = cv.height = 512; const x = cv.getContext('2d');
  x.fillStyle = '#000'; x.fillRect(0, 0, 512, 512);
  const R = rng(91);
  for (let k = 0; k < 70; k++) {
    const cx = R() * 512, cy = R() * 512;
    for (let i = 0; i < 9; i++) {
      const a = R() * Math.PI * 2, L = 60 + R() * 120, w = 4 + R() * 5;
      x.strokeStyle = `rgba(255,255,255,${0.55 + R() * 0.4})`; x.lineWidth = w; x.lineCap = 'round';
      x.beginPath(); x.moveTo(cx, cy); x.quadraticCurveTo(cx + Math.cos(a) * L * 0.5 + (R() - 0.5) * 30, cy + Math.sin(a) * L * 0.5 + (R() - 0.5) * 30, cx + Math.cos(a) * L, cy + Math.sin(a) * L); x.stroke();
    }
  }
  const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping;
  LEAF = t; return t;
}
export function underwaterWorld(scene, { surf = 0.4, size = 5, density = 1.5, fogColor = 0x2b6655, center = [0, 0, 0], rays = 7, particles = 700, see = 0.0, leaves = 0.6 } = {}) {
  const u = scene.userData.sky.material.uniforms;
  u.top.value.set(fogColor).lerp(new THREE.Color(0x9ad6bd), 0.35); u.mid.value.set(fogColor); u.horizon.value.set(fogColor); u.floorC.value.set(fogColor);
  scene.fog = new THREE.FogExp2(fogColor, density);
  const [cx, , cz] = center;
  // lighting: soft green-white light from above
  const top = new THREE.DirectionalLight(0xe6fff0, 1.6); top.position.set(cx + 0.3, 3, cz + 0.6); top.target.position.set(cx, 0, cz);
  top.castShadow = true; top.shadow.mapSize.set(1024, 1024); const sc = top.shadow.camera; sc.left = sc.bottom = -1.2; sc.right = sc.top = 1.2; sc.near = 0.5; sc.far = 6;
  scene.add(top, top.target);
  scene.add(new THREE.HemisphereLight(0x8fd6b8, 0x2a2416, 0.6));
  // mud floor
  const mud = new THREE.Mesh(new THREE.PlaneGeometry(size, size, 60, 60), new THREE.MeshStandardMaterial({ map: mudTexture(), roughness: 0.95, bumpMap: mudTexture(), bumpScale: 2.5 }));
  const p = mud.geometry.attributes.position; const R = rng(5);
  for (let i = 0; i < p.count; i++) p.setZ(i, (Math.sin(p.getX(i) * 9 + 1) * Math.sin(p.getY(i) * 7) * 0.008 + (R() - 0.5) * 0.004));
  mud.geometry.computeVertexNormals();
  mud.rotation.x = -Math.PI / 2; mud.position.set(cx, 0, cz); mud.receiveShadow = true; scene.add(mud);
  // pebbles
  const peb = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8 }), 90);
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), c = new THREE.Color();
  for (let i = 0; i < 90; i++) {
    const s = 0.004 + R() * 0.012;
    q.setFromEuler(new THREE.Euler(R() * 3, R() * 3, R() * 3));
    m.compose(new THREE.Vector3(cx + (R() - 0.5) * 2, s * 0.3, cz + (R() - 0.5) * 2), q, new THREE.Vector3(s * 1.3, s * 0.7, s));
    peb.setMatrixAt(i, m); c.setHSL(0.08 + R() * 0.05, 0.15 + R() * 0.15, 0.25 + R() * 0.25); peb.setColorAt(i, c);
  }
  peb.receiveShadow = true; scene.add(peb);
  // surface seen from below: bright Snell's window, darker reflective water outside it
  const sMat = new THREE.ShaderMaterial({
    uniforms: { uTime: TIME, uSee: { value: see }, uLeaf: { value: leafTexture() }, uLeafAmt: { value: leaves }, uFogC: { value: new THREE.Color(fogColor) }, uFogD: { value: density } },
    vertexShader: `varying vec3 vWP; void main(){ vWP = (modelMatrix * vec4(position, 1.0)).xyz; gl_Position = projectionMatrix * viewMatrix * vec4(vWP, 1.0); }`,
    fragmentShader: NOISE + `uniform float uTime, uSee, uLeafAmt, uFogD; uniform vec3 uFogC; uniform sampler2D uLeaf; varying vec3 vWP;
      void main(){
        vec3 V = normalize(vWP - cameraPosition);
        float win = smoothstep(0.5, 0.8, V.y);
        vec2 q = vWP.xz * 7.0 + vec2(uTime * 0.45, uTime * 0.3);
        float r = fbm(q), r2 = fbm(q * 2.3 - uTime * 0.2);
        vec3 inside = mix(vec3(0.7, 0.95, 0.82), vec3(1.5, 1.6, 1.35), smoothstep(0.35, 0.75, r * 0.7 + r2 * 0.5));
        vec3 outside = mix(vec3(0.1, 0.27, 0.22), vec3(0.3, 0.5, 0.42), r);
        float lf = texture2D(uLeaf, vWP.xz * 1.6 + vec2(sin(uTime * 0.6) * 0.01, cos(uTime * 0.5) * 0.01)).r;
        inside *= 1.0 - lf * uLeafAmt * 0.5;
        float dist = length(vWP - cameraPosition);
        float fogF = 1.0 - exp(-pow(uFogD * dist * 0.85, 2.0));
        gl_FragColor = vec4(mix(mix(outside, inside, win), uFogC, fogF), 1.0 - win * uSee);
      }`,
    side: THREE.DoubleSide, transparent: see > 0, depthWrite: see <= 0,
  });
  const surface = new THREE.Mesh(new THREE.PlaneGeometry(size * 2, size * 2), sMat); surface.rotation.x = -Math.PI / 2; surface.position.set(cx, surf, cz); scene.add(surface);
  // sediment particles drifting
  const pg = new THREE.BufferGeometry(); const P = new Float32Array(particles * 3), seeds = [];
  for (let i = 0; i < particles; i++) seeds.push([(R() - 0.5) * 2.2, R() * surf, (R() - 0.5) * 2.2, R() * 6]);
  pg.setAttribute('position', new THREE.BufferAttribute(P, 3));
  const pts = new THREE.Points(pg, new THREE.PointsMaterial({ size: 0.006, color: 0xd9f2e4, transparent: true, opacity: 0.55, depthWrite: false, map: glowSprite().material.map, sizeAttenuation: true }));
  pts.frustumCulled = false; scene.add(pts);
  // god rays
  const rayMat = new THREE.ShaderMaterial({
    uniforms: { uTime: TIME, uOp: { value: 0.16 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `uniform float uTime, uOp; varying vec2 vUv;
      void main(){ float edge = sin(vUv.x * 3.14159); float fall = pow(vUv.y, 1.6) * smoothstep(1.0, 0.8, vUv.y); float fl = 0.75 + 0.25 * sin(uTime * 1.3 + vUv.x * 7.0);
        gl_FragColor = vec4(vec3(0.85, 1.0, 0.85), edge * edge * fall * fl * uOp); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
  });
  const rayList = [];
  for (let i = 0; i < rays; i++) {
    const w = 0.04 + R() * 0.08;
    const r = new THREE.Mesh(new THREE.PlaneGeometry(w, surf * 1.4), rayMat);
    r.position.set(cx - 0.8 + (i / rays) * 1.6 + (R() - 0.5) * 0.1, surf * 0.45, cz - 0.4 + R() * 0.5);
    r.rotation.set(0, (R() - 0.5) * 0.6, 0.28 + (R() - 0.5) * 0.08);
    scene.add(r); rayList.push([r, R() * 6]);
  }
  // bubbles
  const bMat = new THREE.MeshPhysicalMaterial({ color: 0xeaffff, roughness: 0.02, transparent: true, opacity: 0.45, clearcoat: 1, envMapIntensity: 2 });
  const bubbles = [];
  for (let i = 0; i < 10; i++) { const b = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 10), bMat); scene.add(b); bubbles.push([b, (R() - 0.5) * 1.2, (R() - 0.5) * 0.6, R() * 5, 0.002 + R() * 0.004]); }
  scene.userData.updaters.push((t) => {
    for (let i = 0; i < particles; i++) {
      const [x, y, z, ph] = seeds[i];
      P[i * 3] = cx + x + Math.sin(t * 0.3 + ph) * 0.03;
      P[i * 3 + 1] = (y + t * 0.004 + Math.sin(t * 0.5 + ph * 2) * 0.01) % surf;
      P[i * 3 + 2] = cz + z + Math.cos(t * 0.25 + ph) * 0.03;
    }
    pg.attributes.position.needsUpdate = true;
    rayList.forEach(([r, ph]) => { r.rotation.z = 0.28 + Math.sin(t * 0.4 + ph) * 0.03; });
    bubbles.forEach(([b, x, z, ph, s]) => { const k = ((t * 0.12 + ph * 0.2) % 1); b.position.set(cx + x + Math.sin(t * 3 + ph) * 0.01, k * surf, cz + z); b.scale.setScalar(s * (1 + k)); b.visible = k < 0.97; });
  });
  return { surface, mud };
}

// rice tillers seen underwater: pale stems fanning up from the mud, roots spreading
export function tillers(spots, { h = 0.8, seed = 7, stems = 9, roots = 7 } = {}) {
  const R = rng(seed);
  const g = new THREE.Group();
  const stemMat = new THREE.MeshStandardMaterial({ color: 0xffffff, vertexColors: true, roughness: 0.6 });
  const rootMat = new THREE.MeshStandardMaterial({ color: 0xd9cfae, roughness: 0.8 });
  for (const [x, z] of spots) {
    for (let i = 0; i < stems; i++) {
      const r = 0.0035 + R() * 0.003;
      const geo = new THREE.CylinderGeometry(r * 0.75, r, h * (0.8 + R() * 0.3), 6, 6, true); geo.translate(0, geo.parameters.height / 2, 0);
      const col = []; const pp = geo.attributes.position;
      for (let k = 0; k < pp.count; k++) { const v = pp.getY(k) / geo.parameters.height; const c = new THREE.Color(0xc9c78a).lerp(new THREE.Color(0x5e9a3a), Math.min(1, v * 2.2)); col.push(c.r, c.g, c.b); }
      geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      const m = new THREE.Mesh(geo, stemMat);
      const a = R() * Math.PI * 2, tilt = 0.04 + R() * 0.14;
      m.position.set(x + Math.cos(a) * 0.006, 0, z + Math.sin(a) * 0.006);
      m.rotation.set(Math.sin(a) * tilt, 0, -Math.cos(a) * tilt);
      m.castShadow = true; g.add(m);
    }
    for (let i = 0; i < roots; i++) {
      const a = R() * Math.PI * 2, L = 0.04 + R() * 0.06;
      const curve = new THREE.CatmullRomCurve3([new THREE.Vector3(x, 0.004, z), new THREE.Vector3(x + Math.cos(a) * L * 0.5, 0.006, z + Math.sin(a) * L * 0.5), new THREE.Vector3(x + Math.cos(a + 0.3) * L, -0.002, z + Math.sin(a + 0.3) * L)]);
      g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 8, 0.0012, 4), rootMat));
    }
  }
  g.stemMat = stemMat;
  return g;
}
