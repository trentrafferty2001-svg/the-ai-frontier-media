// The Explainer: how a tunnel boring machine eats through rock. Rock cutaway, shield TBM, segment rings, close-up set.
// Units: metres. Tunnel axis along +x (machine faces +x), centre at y = 0. Near half (z > 0) of the rock can be hidden.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TIME } from './world.js';
import { rng } from './textures.js';

const NOISE = `
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vnoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(hash12(i), hash12(i+vec2(1,0)), f.x), mix(hash12(i+vec2(0,1)), hash12(i+vec2(1,1)), f.x), f.y); }
float fbm(vec2 p){ float s = 0.0, a = 0.5; for (int i = 0; i < 5; i++){ s += a * vnoise(p); p *= 2.03; a *= 0.5; } return s; }`;

function rockMaterial({ face = false } = {}) {
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95 });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uFace = { value: face ? 1 : 0 };
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWr;').replace('#include <project_vertex>', '#include <project_vertex>\nvWr = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWr; uniform float uFace;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float y = vWr.y + 0.6 * sin(vWr.x * 0.15) + 0.4 * fbm(vWr.xz * 0.3);
      float band = fract(y * 0.28);
      vec3 c1 = vec3(0.47, 0.40, 0.33), c2 = vec3(0.58, 0.52, 0.44), c3 = vec3(0.36, 0.33, 0.31);
      vec3 col = band < 0.33 ? c1 : band < 0.7 ? c2 : c3;
      col *= 0.8 + 0.4 * fbm(vWr.xy * 1.7 + vWr.z * 0.9);
      float crk = 1.0 - smoothstep(0.0, 0.018, abs(fbm(vWr.xy * 0.9 + vWr.z * 0.4) - 0.5));
      col *= 1.0 - 0.22 * crk;
      float peb = smoothstep(0.72, 0.78, fbm(vWr.xy * 6.0 + vWr.zx * 3.0)); col = mix(col, vec3(0.62, 0.58, 0.52) * (0.8 + 0.4 * fbm(vWr.xy * 20.0)), peb * 0.8);
      float fleck = step(0.985, hash12(floor(vWr.xy * 40.0) + floor(vWr.z * 40.0))); col += vec3(0.25, 0.22, 0.15) * fleck;
      col *= 1.0 - 0.18 * smoothstep(-1.0, -3.2, vWr.y);
      // concentric kerf rings cut by the disc cutters on the face
      float r = length(vWr.yz); float kerf = smoothstep(0.08, 0.0, abs(fract(r / 0.45) - 0.5) - 0.42) * uFace;
      col *= 1.0 - 0.35 * kerf;
      diffuseColor.rgb *= col;`);
  };
  return m;
}

// rock around the bore: half shells (far z<0, near z>0) from x0 to the face, then a solid block beyond the face
export function rockMass(scene, { R = 3.2, H = 40, x0 = -90 } = {}) {
  const half = (sgn) => {
    const s = new THREE.Shape();
    // shape in (u = z, v = y)
    s.moveTo(0, R); s.lineTo(0, H); s.lineTo(sgn * H, H); s.lineTo(sgn * H, -H); s.lineTo(0, -H); s.lineTo(0, -R);
    for (let k = 1; k <= 48; k++) { const a = -Math.PI / 2 + sgn * k / 48 * Math.PI; s.lineTo(Math.cos(a) * R, Math.sin(a) * R); }
    const geo = new THREE.ExtrudeGeometry(s, { depth: 1, bevelEnabled: false, curveSegments: 1 });
    // extrusion is along +z in shape space: remap (u, v, w) -> (x = w, y = v, z = u)
    const p = geo.attributes.position; for (let i = 0; i < p.count; i++) { const u = p.getX(i), v = p.getY(i), w = p.getZ(i); p.setXYZ(i, w, v, u); }
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, rockMaterial()); mesh.receiveShadow = true; mesh.castShadow = false; scene.add(mesh); return mesh;
  };
  const far = half(-1), near = half(1);
  const solid = new THREE.Mesh(new THREE.BoxGeometry(120, 2 * H, 2 * H), rockMaterial({ face: true })); solid.receiveShadow = true; scene.add(solid);
  const solidNear = new THREE.Mesh(new THREE.BoxGeometry(120, 2 * H, H), rockMaterial({ face: true })); scene.add(solidNear);
  const setFace = (xf, cut = true) => {
    far.position.x = near.position.x = x0; far.scale.x = near.scale.x = xf - x0;
    near.visible = !cut;
    // solid block: in cutaway only the far half
    solid.visible = !cut; solid.position.set(xf + 60, 0, 0);
    solidNear.visible = cut; solidNear.position.set(xf + 60, 0, -H / 2);
  };
  setFace(0);
  return { far, near, solid, setFace };
}

// one ring of six curved concrete segments, length len, at x (ring spans x - len .. x)
const segMat = new THREE.MeshStandardMaterial({ color: 0xa9a59c, roughness: 0.85 });
export function segmentGeometry(R, th = 0.3, len = 1.5, arc = Math.PI / 3 - 0.02) {
  const s = new THREE.Shape(); const n = 16;
  for (let k = 0; k <= n; k++) { const a = -arc / 2 + arc * k / n; s.lineTo(Math.cos(a) * R, Math.sin(a) * R); }
  for (let k = n; k >= 0; k--) { const a = -arc / 2 + arc * k / n; s.lineTo(Math.cos(a) * (R - th), Math.sin(a) * (R - th)); }
  const geo = new THREE.ExtrudeGeometry(s, { depth: len - 0.03, bevelEnabled: true, bevelSize: 0.015, bevelThickness: 0.015, bevelSegments: 1, curveSegments: 1 });
  // shape (u, v) in the ring plane -> (y, z); extrusion -> -x
  const p = geo.attributes.position; for (let i = 0; i < p.count; i++) { const u = p.getX(i), v = p.getY(i), w = p.getZ(i); p.setXYZ(i, -w, u, v); }
  geo.computeVertexNormals(); return geo;
}
export function ring(R, { len = 1.5, cut = false } = {}) {
  const g = new THREE.Group(); const geo = segmentGeometry(R, 0.3, len);
  for (let k = 0; k < 6; k++) {
    const a = k / 6 * Math.PI * 2 + Math.PI / 6;
    const m = new THREE.Mesh(geo, segMat); m.rotation.x = a; m.castShadow = m.receiveShadow = true; g.add(m);
  }
  return g;
}

// ---------------- the machine ----------------
export function tbm({ R = 3.2, seed = 1 } = {}) {
  const G = new THREE.Group();
  const yellow = new THREE.MeshStandardMaterial({ color: 0xf2b51b, roughness: 0.45, metalness: 0.35 });
  yellow.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWy;').replace('#include <project_vertex>', '#include <project_vertex>\nvWy = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWy;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float wear = smoothstep(0.74, 0.8, fbm(vWy.xy * 2.2 + vWy.z * 1.7)); float grime = fbm(vWy.yz * 1.3 + vWy.x * 0.7);
      diffuseColor.rgb = mix(diffuseColor.rgb * (0.82 + 0.3 * grime), vec3(0.4, 0.37, 0.33), wear * 0.55);
      float scr = smoothstep(0.985, 1.0, abs(sin(vWy.x * 37.0 + fbm(vWy.yz * 4.0) * 9.0))); diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.55), scr * 0.5);`);
  };
  const steel = new THREE.MeshStandardMaterial({ color: 0x8c949c, roughness: 0.35, metalness: 0.85 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x2b2e33, roughness: 0.6, metalness: 0.4 });
  const red = new THREE.MeshStandardMaterial({ color: 0xc8352b, roughness: 0.5, metalness: 0.3 });
  const SH = 8.5; // shield length
  // shield: open cylinder (we look inside in cutaway), far half only can be toggled
  const shield = new THREE.Mesh(new THREE.CylinderGeometry(R - 0.08, R - 0.08, SH, 64, 1, true, 0, Math.PI * 2), yellow);
  shield.rotation.z = Math.PI / 2; shield.position.x = -SH / 2 - 0.5; shield.material = yellow.clone(); shield.material.side = THREE.DoubleSide; G.add(shield);
  const shieldHalf = new THREE.Mesh(new THREE.CylinderGeometry(R - 0.08, R - 0.08, SH, 64, 1, true, Math.PI / 2, Math.PI), shield.material);
  shieldHalf.rotation.z = Math.PI / 2; shieldHalf.position.x = -SH / 2 - 0.5; G.add(shieldHalf); shieldHalf.visible = false;
  // bulkhead behind the cutterhead
  const bulk = new THREE.Mesh(new THREE.CylinderGeometry(R - 0.12, R - 0.12, 0.25, 64), dark); bulk.rotation.z = Math.PI / 2; bulk.position.x = -1.1; G.add(bulk);
  { const c = document.createElement('canvas'); c.width = 512; c.height = 32; const g = c.getContext('2d'); for (let i = 0; i < 32; i++) { g.fillStyle = i % 2 ? '#111' : '#f2c21b'; g.beginPath(); g.moveTo(i * 16, 32); g.lineTo(i * 16 + 16, 0); g.lineTo(i * 16 + 32, 0); g.lineTo(i * 16 + 16, 32); g.fill(); }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = THREE.RepeatWrapping; t.repeat.set(4, 1);
    const hz = new THREE.Mesh(new THREE.CylinderGeometry(R - 0.1, R - 0.1, 0.18, 96, 1, true), new THREE.MeshStandardMaterial({ map: t, roughness: 0.6, side: THREE.DoubleSide })); hz.rotation.z = Math.PI / 2; hz.position.x = -1.36; G.add(hz); }
  { const boltM = new THREE.MeshStandardMaterial({ color: 0x9aa2aa, roughness: 0.3, metalness: 0.9 }); const bg = new THREE.CylinderGeometry(0.05, 0.05, 0.08, 6); for (let k = 0; k < 48; k++) { const a = k / 48 * Math.PI * 2; const b = new THREE.Mesh(bg, boltM); b.rotation.z = Math.PI / 2; b.position.set(-0.96, Math.cos(a) * (R - 0.35), Math.sin(a) * (R - 0.35)); G.add(b); } }
  { const hoseM = new THREE.MeshStandardMaterial({ color: 0x1a1c1e, roughness: 0.7 }); for (let k = 0; k < 6; k++) { const a = -0.6 + k * 0.24; const pts = []; for (let i = 0; i <= 10; i++) { const u = i / 10; pts.push(new THREE.Vector3(-1.3 - u * 6.5, Math.cos(a) * (R - 0.45) - 0.15 * Math.sin(u * Math.PI), Math.sin(a) * (R - 0.45))); } const h = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, 0.045, 8), hoseM); G.add(h); } }
  { const lm = new THREE.MeshBasicMaterial({ color: 0xfff0c8, toneMapped: false }); const hm = new THREE.MeshStandardMaterial({ color: 0x3a3c40, metalness: 0.6, roughness: 0.4 }); for (let k = 0; k < 5; k++) { const x = -1.5 - k * 4; const box = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.18, 0.22), hm); box.position.set(x, 1.6, -0.5); G.add(box); const lens = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.12), lm); lens.position.set(x, 1.5, -0.5); lens.rotation.x = Math.PI / 2; G.add(lens); } }
  // cutterhead
  const head = new THREE.Group(); head.position.x = 0; G.add(head);
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(R - 0.05, R - 0.1, 0.5, 64), yellow); plate.rotation.z = Math.PI / 2; plate.position.x = -0.3; head.add(plate);
  const hub = new THREE.Mesh(new THREE.SphereGeometry(0.7, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), yellow); hub.rotation.z = -Math.PI / 2; hub.position.x = -0.05; hub.scale.y = 0.6; head.add(hub);
  // spokes (raised arms) and bucket openings
  for (let k = 0; k < 6; k++) {
    const a = k / 6 * Math.PI * 2;
    const sp = new THREE.Mesh(new RoundedBoxGeometry(0.35, R * 0.92, 0.55, 2, 0.06), yellow); sp.position.set(0.02, Math.cos(a) * R * 0.5, Math.sin(a) * R * 0.5); sp.rotation.x = -a; head.add(sp);
    const slot = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.9, 0.45), dark); const b = a + Math.PI / 6; slot.position.set(-0.02, Math.cos(b) * (R - 0.6), Math.sin(b) * (R - 0.6)); slot.rotation.x = -b; head.add(slot);
    const lip = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.08, 0.5), steel); lip.position.set(0.05, Math.cos(b) * (R - 0.15), Math.sin(b) * (R - 0.15)); lip.rotation.x = -b; head.add(lip);
  }
  // disc cutters: steel discs on the spokes at stepped radii, each spins on its own axle as the head turns
  const discs = [];
  const discGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.06, 28); const hubGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.16, 16);
  const R0 = rng(seed);
  for (let k = 0; k < 6; k++) for (let j = 0; j < 5; j++) {
    const a = k / 6 * Math.PI * 2 + (j % 2 ? 0.12 : -0.12); const r = 0.55 + j * (R - 0.85) / 4 + (k % 2) * 0.22;
    if (r > R - 0.25) continue;
    const holder = new THREE.Group(); holder.position.set(0.2, Math.cos(a) * r, Math.sin(a) * r); holder.rotation.x = -a; head.add(holder);
    const d = new THREE.Group(); holder.add(d);
    const disc = new THREE.Mesh(discGeo, steel); disc.castShadow = true; d.add(disc);
    const hb = new THREE.Mesh(hubGeo, dark); d.add(hb);
    const mount = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.08, 0.3), dark); mount.position.x = -0.14; holder.add(mount);
    // disc axle along the holder's local y (radial): plane of the disc contains x and the tangent
    discs.push([d, r]);
  }
  // thrust rams around the tail: body on the shield, rod pushes back on the last ring
  const rams = [];
  const tailX = -SH - 0.5;
  for (let k = 0; k < 10; k++) {
    const a = k / 10 * Math.PI * 2 + 0.3; const r = R - 0.45;
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 1.6, 16), red); body.rotation.z = Math.PI / 2; body.position.set(tailX + 1.6, Math.cos(a) * r, Math.sin(a) * r); G.add(body);
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1, 12), steel); rod.rotation.z = Math.PI / 2; G.add(rod);
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.32, 0.42), dark); shoe.rotation.x = -a; G.add(shoe);
    rams.push({ body, rod, shoe, a, r });
  }
  // erector: rotating ring frame with an arm that carries a segment
  const erector = new THREE.Group(); erector.position.x = tailX + 0.6; G.add(erector);
  const ringFrame = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.12, 12, 40), dark); ringFrame.rotation.y = Math.PI / 2; erector.add(ringFrame);
  const arm = new THREE.Group(); erector.add(arm);
  const beam = new THREE.Mesh(new RoundedBoxGeometry(0.35, 1.6, 0.35, 2, 0.05), red); beam.position.y = 1.5; beam.position.x = -0.65; arm.add(beam);
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.15, 0.7), dark); grip.position.y = 2.3; grip.position.x = -0.65; arm.add(grip);
  const carried = new THREE.Mesh(segmentGeometry(R - 0.12), segMat); carried.castShadow = true; arm.add(carried);
  // segment geometry is already centred on +y at radius R - 0.12
  // backup: conveyor belt and gantry deck running back through the machine
  const belt = new THREE.Group(); G.add(belt);
  const beltLen = 22;
  const deck = new THREE.Mesh(new THREE.BoxGeometry(beltLen, 0.12, 1.0), dark); deck.position.set(-1.5 - beltLen / 2, 0.15, 0); belt.add(deck);
  const rubber = new THREE.Mesh(new THREE.BoxGeometry(beltLen, 0.04, 0.8), new THREE.MeshStandardMaterial({ color: 0x151515, roughness: 0.9 })); rubber.position.set(-1.5 - beltLen / 2, 0.23, 0); belt.add(rubber);
  for (let k = 0; k < 12; k++) { const leg = new THREE.Mesh(new THREE.BoxGeometry(0.1, R - 0.4, 0.1), steel); leg.position.set(-2 - k * 1.8, 0.15 - (R - 0.4) / 2, 0.45); belt.add(leg); const leg2 = leg.clone(); leg2.position.z = -0.45; belt.add(leg2); }
  const hopper = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.3, 0.8, 4, 1, true), new THREE.MeshStandardMaterial({ color: 0x5d636b, metalness: 0.6, roughness: 0.5, side: THREE.DoubleSide })); hopper.position.set(-1.6, 0.8, 0); hopper.rotation.y = Math.PI / 4; G.add(hopper);
  // muck: chips path face -> bottom -> lifted by the wheel -> hopper -> belt
  const N = 160; const chipGeo = new THREE.IcosahedronGeometry(1, 0);
  const chips = new THREE.InstancedMesh(chipGeo, new THREE.MeshStandardMaterial({ color: 0x8a7a68, roughness: 0.9, flatShading: true }), N); chips.frustumCulled = false; chips.castShadow = true; G.add(chips);
  const cs = []; for (let i = 0; i < N; i++) cs.push([R0(), 0.05 + R0() * 0.09, R0() * 6, (R0() - 0.5) * 0.6]);
  const path = new THREE.CatmullRomCurve3([new THREE.Vector3(-0.6, -R + 0.5, 0.6), new THREE.Vector3(-0.7, -R + 0.25, 0), new THREE.Vector3(-0.75, -R * 0.2, -R * 0.8), new THREE.Vector3(-0.8, R * 0.55, -R * 0.55), new THREE.Vector3(-1.4, 1.3, 0), new THREE.Vector3(-1.7, 0.35, 0), new THREE.Vector3(-3.0, 0.32, 0), new THREE.Vector3(-1.5 - beltLen, 0.32, 0)]);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), sc = new THREE.Vector3(), e = new THREE.Euler();
  const st = { spin: 1, ram: 0, erect: 1, erAngle: 0, carry: 1, muck: 1, cut: true, glowRing: 0 };
  function update(t) {
    const ang = t * 0.9 * st.spin;
    head.rotation.x = ang;
    discs.forEach(([d, r]) => { d.rotation.y = ang * r / 0.22; });
    shield.visible = !st.cut; shieldHalf.visible = st.cut;
    // rams: rod from body end to the ring face behind (at tailX - st.ram)
    rams.forEach(({ body, rod, shoe, a, r }) => {
      const x1 = tailX + 0.8, x0 = tailX - 0.05 - st.ram; const L = x1 - x0;
      rod.scale.y = L; rod.position.set((x0 + x1) / 2, Math.cos(a) * r, Math.sin(a) * r);
      shoe.position.set(x0, Math.cos(a) * r, Math.sin(a) * r);
      const vis = !st.cut || Math.sin(a) <= 0.05; body.visible = rod.visible = shoe.visible = vis;
    });
    erector.rotation.x = st.erAngle;
    arm.scale.setScalar(1); beam.scale.y = 1; arm.position.y = 0;
    const ext = st.erect; const gy = (R - 0.55) - (1 - ext) * 1.3; grip.position.y = gy; beam.scale.y = gy / 1.6; beam.position.y = gy / 2; carried.position.y = 0; carried.visible = st.carry > 0.5;
    // place the carried segment so its outer face reaches the ring radius when ext = 1
    carried.position.set(-0.65, -(1 - ext) * 1.3, 0);
    // muck
    chips.visible = st.muck > 0.01;
    for (let i = 0; i < N; i++) {
      const [s0, s, ph, dz] = cs[i]; const u = ((s0 + t * 0.06 * st.spin) % 1 + 1) % 1;
      path.getPointAt(u, v); v.z += dz * (u < 0.5 ? 1 : 0.4);
      e.set(t * 2 + ph, ph, t + ph * 2); q.setFromEuler(e); sc.set(s, s * 0.7, s * 0.85); m4.compose(v, q, sc); chips.setMatrixAt(i, m4);
    }
    chips.instanceMatrix.needsUpdate = true;
  }
  update(0);
  return { group: G, head, st, update, tailX, SH, R, erector, carried, rams };
}

// ---------------- close-up: a disc cutter rolling across a rock slab, chips spalling between the grooves ----------------
export function discSet(scene) {
  const g = new THREE.Group(); scene.add(g);
  const slab = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.8, 2.2, 1, 1, 1), rockMaterial()); slab.position.y = -0.4; slab.receiveShadow = true; g.add(slab);
  // existing grooves (dark lines) along x at z = -0.6, 0 ... and the new groove at z = 0.3
  const grooveM = new THREE.MeshStandardMaterial({ color: 0x2a2420, roughness: 1 });
  [-0.6, -0.15].forEach((z) => { const gr = new THREE.Mesh(new THREE.BoxGeometry(3, 0.02, 0.05), grooveM); gr.position.set(0, 0.002, z); g.add(gr); });
  const newG = new THREE.Mesh(new THREE.BoxGeometry(1, 0.02, 0.05), grooveM); newG.position.set(0, 0.003, 0.3); g.add(newG);
  const steel = new THREE.MeshStandardMaterial({ color: 0xc5ccd3, roughness: 0.2, metalness: 0.7 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x2b2e33, roughness: 0.6, metalness: 0.4 });
  const disc = new THREE.Group(); g.add(disc); const wheel = new THREE.Group(); disc.add(wheel);
  const d = new THREE.Mesh(new THREE.CylinderGeometry(0.43, 0.43, 0.06, 48), steel); d.rotation.x = Math.PI / 2; wheel.add(d);
  const edge = new THREE.Mesh(new THREE.TorusGeometry(0.43, 0.02, 8, 48), steel); wheel.add(edge);
  const hb = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.3, 24), dark); hb.rotation.x = Math.PI / 2; wheel.add(hb);
  const bolt = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.2, 0.32), steel); bolt.position.y = 0.08; wheel.add(bolt);
  const yoke = new THREE.Mesh(new RoundedBoxGeometry(0.9, 0.5, 0.5, 2, 0.06), new THREE.MeshStandardMaterial({ color: 0xf2b51b, roughness: 0.45, metalness: 0.35 })); yoke.position.y = 0.6; disc.add(yoke);
  // force arrow
  const arrowM = new THREE.MeshStandardMaterial({ color: 0xff4a2a, emissive: 0xff2a10, emissiveIntensity: 0.4 });
  const arrow = new THREE.Group(); const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.7, 16), arrowM); shaft.position.y = 0.55; arrow.add(shaft);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.3, 20), arrowM); tip.rotation.z = Math.PI; tip.position.y = 0.05; arrow.add(tip); disc.add(arrow); arrow.position.y = 0.95;
  // spalling chips between the new groove and the last one
  const N = 40, R = rng(5), cs = []; for (let i = 0; i < N; i++) cs.push([(R() - 0.5) * 2.6, 0.0 + R() * 0.25, 0.04 + R() * 0.07, R() * 6, R()]);
  const chips = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 0), new THREE.MeshStandardMaterial({ color: 0x8a7a68, roughness: 0.9, flatShading: true }), N); chips.frustumCulled = false; chips.castShadow = true; g.add(chips);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), s = new THREE.Vector3(), e = new THREE.Euler();
  const st = { x: -1.2, arrow: 0, chips: 0, press: 0 };
  function update(t) {
    disc.position.set(st.x, 0.43 - 0.02 * st.press, 0.3); wheel.rotation.z = -st.x / 0.43;
    arrow.scale.setScalar(st.arrow); arrow.visible = st.arrow > 0.01;
    newG.scale.x = Math.max(0.001, st.x + 1.5); newG.position.x = (-1.5 + st.x) / 2;
    for (let i = 0; i < N; i++) {
      const [x, z, sz, ph, r] = cs[i];
      const born = x < st.x - 0.1 ? Math.min(1, (st.x - 0.1 - x) * 2) * st.chips : 0; // chips pop behind the disc
      const up = born * (0.15 + r * 0.25) * Math.sin(Math.min(1, born) * Math.PI * 0.9);
      v.set(x + born * 0.2 * (r - 0.5), 0.02 + up, z + born * 0.15); e.set(born * 3 + ph, ph, born * 2); q.setFromEuler(e);
      s.set(sz, sz * 0.4, sz * 0.8).multiplyScalar(born > 0 ? 1 : 0.0001); m4.compose(v, q, s); chips.setMatrixAt(i, m4);
    }
    chips.instanceMatrix.needsUpdate = true;
  }
  update(0);
  return { group: g, st, update };
}

// building for scale: n floors, windows
export function building(floors = 5, { w = 10, d = 8, fh = 3.4 } = {}) {
  const g = new THREE.Group(); const h = floors * fh;
  const body = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 2, 0.15), new THREE.MeshStandardMaterial({ color: 0xd9c7a8, roughness: 0.85 })); body.position.y = h / 2; body.castShadow = body.receiveShadow = true; g.add(body);
  const winM = new THREE.MeshStandardMaterial({ color: 0x5b8bb0, roughness: 0.15, metalness: 0.4 });
  for (let f = 0; f < floors; f++) for (let k = 0; k < 4; k++) { const wi = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.6, 0.1), winM); wi.position.set(-w / 2 + 1.5 + k * (w - 3) / 3, f * fh + 1.9, d / 2 + 0.02); g.add(wi); }
  const roof = new THREE.Mesh(new THREE.BoxGeometry(w + 0.4, 0.3, d + 0.4), new THREE.MeshStandardMaterial({ color: 0x8a5a44 })); roof.position.y = h + 0.15; g.add(roof);
  return g;
}
// simple person for scale (1.75 m)
export function person(color = 0xff7a1a) {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color, roughness: 0.6 }); const skin = new THREE.MeshStandardMaterial({ color: 0xe0b08a, roughness: 0.6 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.7, 4, 12), m); body.position.y = 1.05; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.14, 16, 12), skin); head.position.y = 1.62; g.add(head);
  const hat = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xffd21a })); hat.position.y = 1.66; g.add(hat);
  [-0.11, 0.11].forEach((x) => { const l = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.55, 4, 8), new THREE.MeshStandardMaterial({ color: 0x2f3e5a })); l.position.set(x, 0.38, 0); g.add(l); });
  return g;
}
