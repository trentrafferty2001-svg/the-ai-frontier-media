// The Explainer: how a jet engine works. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { turbofan, airflow, airliner, exhaust, coolBlade, X } from './jet.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_je.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Every *jet engine*', 3], ['does just', 2], ['*four things*', 2], ['*Suck*', 1], ['*squeeze*', 1], ['*bang*', 1], ['*blow*', 1]],
  [['First', 1], ['a *giant fan*', 3], ['at the front', 3], ['*sucks in*', 2], ['a *huge* amount', 3], ['of air', 2]],
  [['*Most* of it', 3], ['flows *around*', 2], ["the engine's *core*", 3], ['and gives', 2], ['the plane', 2], ['most of its *push*', 4]],
  [['The rest', 2], ['goes *inside*', 2], ['where rows', 2], ['of *spinning blades*', 3], ['*squeeze* it', 2], ['to about', 2], ['*forty times*', 2], ['its normal', 2], ['*pressure*', 1]],
  [['Then *fuel*', 2], ['is *sprayed in*', 3], ['and *burns*', 2], ['at up to', 3], ['*2,000 degrees*', 3]],
  [['The *hot gas*', 3], ['*blasts out*', 2], ['the back', 2], ['spinning', 1], ['a *turbine*', 2], ['on its way', 3]],
  [['That *turbine*', 2], ['turns the', 2], ['*same shaft*', 2], ['as the *fan*', 3], ['and the', 2], ['*compressor*', 1], ['so the engine', 3], ['keeps *itself*', 2], ['*running*', 1]],
  [['The gas', 2], ['is *hotter*', 2], ['than the', 2], ['turbine blades', 2], ['can *melt* at', 3], ['so *cool air*', 3], ['flows through', 2], ['*tiny holes*', 2], ['inside them', 2]],
  [['Throwing air', 2], ['*backwards*', 1], ['pushes the plane', 3], ['*forwards*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.02; c.far = 900; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.5, warm: 1.05, sat: 1.18, exposure: 1.0 };
const SPIN = (T) => T * 9.3; // rotor angle (aliasing-safe: not a multiple of the blade spacing per frame)

function sky(makeStage) { return makeStage({ outdoor: 'day', sunDir: [0.5, 0.8, 0.6], cloud: 0.4, envI: 1.0, shadowSize: 6 }); }
function lab(makeStage, { air = true } = {}) {
  const scene = sky(makeStage);
  const E = turbofan(); scene.add(E.group);
  const A = air ? airflow() : null; if (A) scene.add(A.mesh);
  return { scene, E, A };
}
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

// ============ S0 hook: rush into a real engine on the wing, then the cutaway lights up suck / squeeze / bang / blow ============
function sHook({ makeStage }) {
  const scene = sky(makeStage);
  const P = airliner(); P.position.set(0, 0, -300); scene.add(P);
  const E = turbofan(); scene.add(E.group); const A = airflow(); scene.add(A.mesh);
  const c = C(42);
  const cutT = at(0, 'suck') - 0.12;
  return {
    scene, camera: c,
    update(t, T) {
      P.userData.pods.forEach(p => { p.userData.fan.rotation.x = SPIN(T) * 1.1; });
      if (t < cutT) {
        const pod = P.userData.pods[1]; const pp = new THREE.Vector3(); pod.getWorldPosition(pp);
        const k = easeIn(range(t, 0, cutT));
        orb(c, [pp.x + 1.6, pp.y, pp.z], lerp(14, 3.2, k), lerp(70, 84, k), lerp(8, 3, k));
        return { ...POST, exposure: 1.05 };
      }
      E.st.spin = SPIN(T); E.st.burn = 1; E.st.hot = 1; A.st.bypass = 1; A.st.core = 1; A.update(T);
      const w = ['suck', 'squeeze', 'bang', 'blow'].map(x => at(0, x)); const keys = ['fan', 'cmp', 'comb', 'tur'];
      keys.forEach((k, i) => { E.st.hi[k] = (t >= w[i] - 0.05 && (i === 3 || T < w[i + 1] - 0.05)) ? 1 - 0.4 * range(T, w[i], w[i] + 0.5) : 0; });
      E.update(T);
      const k = easeInOut(range(t, cutT, cutT + 3));
      orb(c, [0, 0, 0], lerp(15.5, 14.5, k), lerp(44, 36, k), lerp(14, 10, k));
      return POST;
    },
  };
}
// ============ S1: the fan sucks air in (front three-quarter) ============
function sFan({ makeStage }) {
  const { scene, E, A } = lab(makeStage);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      E.st.spin = SPIN(T); E.st.burn = 1; E.st.hot = 1; A.st.half = false; A.st.bypass = 1; A.st.core = 1; A.st.speed = 1; E.update(T); A.update(T);
      const k = easeInOut(range(t, 0, 3.7));
      orb(c, [X.fan, 0, 0], lerp(8.5, 6.8, k), lerp(62, 48, k), lerp(8, 12, k));
      return POST;
    },
  };
}
// ============ S2: most air bypasses the core and gives most of the push ============
function sBypass({ makeStage }) {
  const { scene, E, A } = lab(makeStage);
  const L = tag(scene, 'bypass air', 0.75, '#7fd2ff', [0.4, 2.1, 0.4]);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      E.st.spin = SPIN(T); E.st.burn = 1; E.st.hot = 1; A.st.bypass = 1; A.st.core = 0.25; E.update(T); A.update(T);
      pop(L, easeOut(range(T, at(2, 'around'), at(2, 'around') + 0.3)), 0.75);
      const k = easeInOut(range(t, 0, 4.5));
      orb(c, [0.2, 0.1, 0], lerp(15, 14, k), lerp(30, 38, k), lerp(16, 10, k));
      return POST;
    },
  };
}
// ============ S3: compressor squeezes the core air ~40x ============
function sCompress({ makeStage }) {
  const { scene, E, A } = lab(makeStage);
  const L = tag(scene, '40× pressure', 0.3, '#ffe14a', [0.9, 1.2, 0.2]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      E.st.spin = SPIN(T); E.st.burn = 1; E.st.hot = 1; A.st.bypass = 0.15; A.st.core = 1; E.st.hi.cmp = 0.5 * smooth(range(T, at(3, 'squeeze') - 0.2, at(3, 'squeeze') + 0.3)) * (1 - range(T, at(3, 'forty'), at(3, 'pressure')));
      E.update(T); A.update(T);
      pop(L, easeOut(range(T, at(3, 'forty') - 0.1, at(3, 'forty') + 0.2)), 0.3);
      const k = easeInOut(range(t, 0, 6.1));
      orb(c, [lerp(1.4, 0.8, k), 0, 0], lerp(4.6, 4.0, k), lerp(28, 12, k), lerp(14, 8, k));
      return POST;
    },
  };
}
// ============ S4: fuel sprays in and burns ============
function sBurn({ makeStage }) {
  const { scene, E, A } = lab(makeStage);
  const L = tag(scene, '2,000°C', 0.34, '#ffb347', [-0.3, 0.95, 0.3]);
  // fuel spray: tiny droplets from the nozzles
  const R = rnd(4); const D = []; const dm = new THREE.MeshBasicMaterial({ color: 0xfff1b0, toneMapped: false });
  const drops = new THREE.InstancedMesh(new THREE.SphereGeometry(0.012, 6, 4), dm, 140); scene.add(drops);
  for (let i = 0; i < 140; i++) D.push([Math.PI / 2 + R() * Math.PI, R(), (R() - 0.5) * 0.4]);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      const spray = range(T, at(4, 'sprayed') - 0.2, at(4, 'sprayed'));
      E.st.spin = SPIN(T); E.st.burn = smooth(range(T, at(4, 'burns') - 0.15, at(4, 'burns') + 0.3)); E.st.hot = 1; A.st.bypass = 0.15; A.st.core = 1; E.update(T); A.update(T);
      D.forEach(([a, ph, sp], i) => { const u = ((ph + T * 1.6) % 1); const r = 0.46 + sp * u * 0.5; M.compose(new THREE.Vector3(X.comb0 - u * 0.45, -Math.sin(a) * r, Math.cos(a) * r), q, s.setScalar(spray > 0 ? 1 : 0.0001)); drops.setMatrixAt(i, M); });
      drops.instanceMatrix.needsUpdate = true;
      pop(L, easeOut(range(T, at(4, 'two') - 0.1, at(4, 'two') + 0.2)), 0.34);
      const k = easeInOut(range(t, 0, 3.9));
      orb(c, [-0.3, 0, 0], lerp(4.0, 3.4, k), lerp(20, 34, k), lerp(16, 10, k));
      return { ...POST, bloom: 0.8 };
    },
  };
}
// ============ S5: hot gas blasts out the back, spinning the turbine (rear three-quarter) ============
function sTurbine({ makeStage }) {
  const { scene, E, A } = lab(makeStage);
  const X0 = exhaust(6, 0.55); X0.group.position.x = -2.9; scene.add(X0.group);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      E.st.spin = SPIN(T); E.st.burn = 1; E.st.hot = 1; A.st.bypass = 0.3; A.st.core = 1; A.st.half = true; E.update(T); A.update(T);
      E.st.hi.tur = 0.6 * smooth(range(T, at(5, 'turbine') - 0.2, at(5, 'turbine') + 0.2)) * (1 - range(T, at(5, 'way'), le(5) + 0.3)); E.update(T);
      X0.mat.opacity = 0.1 + 0.04 * Math.sin(T * 20);
      const k = easeInOut(range(t, 0, 3.7));
      orb(c, [-1.6, 0, 0], lerp(6.5, 5.4, k), lerp(-40, -20, k), lerp(14, 10, k));
      return { ...POST, bloom: 0.7 };
    },
  };
}
// ============ S6: one shaft links turbine, compressor and fan ============
function sShaft({ makeStage }) {
  const { scene, E, A } = lab(makeStage);
  const glow = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 4.6, 16), new THREE.MeshBasicMaterial({ color: 0xffd34a, transparent: true, opacity: 0, toneMapped: false, depthWrite: false, blending: THREE.AdditiveBlending }));
  glow.rotation.z = Math.PI / 2; glow.position.x = 0.1; scene.add(glow);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      E.st.spin = SPIN(T); E.st.burn = 1; E.st.hot = 1; A.st.bypass = 0.3; A.st.core = 0.5; E.update(T); A.update(T);
      glow.material.opacity = 0.8 * smooth(range(T, at(6, 'shaft') - 0.2, at(6, 'shaft') + 0.3)) * (0.8 + 0.2 * Math.sin(T * 8));
      const ks = [['turbine', 'tur'], ['fan', 'fan'], ['compressor', 'cmp']];
      ks.forEach(([w, k]) => { const a = at(6, w); E.st.hi[k] = 0.7 * (T > a - 0.05 && T < a + 0.9 ? 1 - range(T, a + 0.4, a + 0.9) : 0); }); E.update(T);
      const k = easeInOut(range(t, 0, 5.8));
      orb(c, [0, 0, 0], lerp(11.5, 10.5, k), lerp(8, 22, k), lerp(24, 14, k));
      return POST;
    },
  };
}
// ============ S7: blade cooling close-up ============
function sCool({ makeStage }) {
  const scene = sky(makeStage);
  const B = coolBlade(); scene.add(B.group);
  const R = rnd(13);
  const hotM = new THREE.MeshBasicMaterial({ color: 0xff6a20, toneMapped: false, transparent: true, opacity: 0.85 });
  const hot = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.02, 0.22, 4, 8), hotM, 90); scene.add(hot);
  const H = []; for (let i = 0; i < 90; i++) H.push([(R() - 0.5) * 2.4, R() * 2.6, -0.5 + R() * 1.0 + (R() < 0.5 ? 0.5 : -0.6), R()]);
  const coolM = new THREE.MeshBasicMaterial({ color: 0x7fd8ff, toneMapped: false });
  const cool = new THREE.InstancedMesh(new THREE.SphereGeometry(0.022, 8, 6), coolM, B.holes.length * 4); scene.add(cool);
  const hotL = tag(scene, 'hot gas', 0.26, '#ff8a3d', [-0.45, 2.4, 0.3]); const coolL = tag(scene, 'cool air', 0.26, '#7fd8ff', [0.45, 2.4, 0.3]);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, Math.PI / 2)), q0 = new THREE.Quaternion(), s = new THREE.Vector3(1, 1, 1);
  const c = C(36);
  return {
    scene, camera: c,
    update(t, T) {
      H.forEach(([x0, y, z, ph], i) => { const x = 1.4 - (((ph + T * 0.9) % 1)) * 2.8; M.compose(new THREE.Vector3(x, y, z), q, s.setScalar(1)); hot.setMatrixAt(i, M); }); hot.instanceMatrix.needsUpdate = true;
      const on = smooth(range(T, at(7, 'cool') - 0.2, at(7, 'cool') + 0.3));
      B.holes.forEach((h, i) => { for (let k = 0; k < 4; k++) { const u = ((k / 4 + T * 1.2 + i * 0.13) % 1); M.compose(new THREE.Vector3(h.x - u * 0.35, h.y + u * 0.03, h.z + 0.02 + u * 0.05), q0, s.setScalar(on > 0.01 ? on : 0.0001)); cool.setMatrixAt(i * 4 + k, M); } });
      cool.instanceMatrix.needsUpdate = true;
      B.mat.emissiveIntensity = 0.45 - 0.25 * on;
      pop(hotL, easeOut(range(T, at(7, 'hotter') - 0.1, at(7, 'hotter') + 0.2)), 0.26); pop(coolL, easeOut(range(T, at(7, 'cool') - 0.1, at(7, 'cool') + 0.2)), 0.26);
      const k = easeInOut(range(t, 0, 6.0));
      orb(c, [0, 1.35, 0], lerp(5.4, 4.6, k), lerp(-14, 12, k), lerp(8, 4, k));
      return { ...POST, bloom: 0.7 };
    },
  };
}
// ============ S8: airliner flies past: air thrown back, plane pushed forward ============
function sEnd({ makeStage }) {
  const scene = sky(makeStage);
  const P = airliner(); scene.add(P);
  const ex = P.userData.pods.map(p => { const e = exhaust(14, 0.85); e.group.position.copy(p.position).add(new THREE.Vector3(-2.1, 0, 0)); P.add(e.group); return e; });
  const arrM = (c) => new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0.6, transparent: true, opacity: 0 });
  const mk = (c, dir) => { const g = new THREE.Group(); const m = arrM(c); const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 6, 16), m); sh.rotation.z = Math.PI / 2; const hd = new THREE.Mesh(new THREE.ConeGeometry(0.9, 1.8, 20), m); hd.rotation.z = -dir * Math.PI / 2; hd.position.x = dir * 3.9; g.add(sh, hd); g.userData.m = m; return g; };
  const back = mk(0x6ec8ff, -1); back.position.set(-10, -2.5, 6); back.scale.setScalar(1.1); scene.add(back);
  const fwd = mk(0xffd34a, 1); fwd.position.set(1, 6.5, 0); fwd.scale.setScalar(1.1); scene.add(fwd);
  const c = C(42);
  return {
    scene, camera: c,
    update(t, T) {
      P.position.x = (T - ls(8)) * 3.0;
      P.userData.pods.forEach(p => { p.userData.fan.rotation.x = SPIN(T) * 1.1; });
      ex.forEach(e => { e.mat.opacity = 0.1 + 0.03 * Math.sin(T * 25); });
      const kb = easeOut(range(T, at(8, 'backwards') - 0.2, at(8, 'backwards') + 0.3)), kf = easeOut(range(T, at(8, 'forwards') - 0.3, at(8, 'forwards') + 0.2));
      back.userData.m.opacity = 0.85 * kb; back.position.x = P.position.x - 12 - kb * 2; back.visible = false; // exhaust shows the air going back
      fwd.userData.m.opacity = 0.85 * kf; fwd.position.x = P.position.x + 0.5 + kf * 2; fwd.visible = kf > 0.01;
      const k = easeInOut(range(t, 0, 4.2));
      orb(c, [P.position.x - 1, 0, 0], lerp(70, 72, k), lerp(58, 64, k), lerp(-6, 6, k));
      return POST;
    },
  };
}

const SH = [sHook, sFan, sBypass, sCompress, sBurn, sTurbine, sShaft, sCool, sEnd];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
