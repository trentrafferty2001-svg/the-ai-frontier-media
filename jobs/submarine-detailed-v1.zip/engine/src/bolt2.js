// The Explainer: how lightning forms. Storm world (dark sky, rain, lone tree, thundercloud), inside-the-cloud particles,
// charge signs and a stepped-leader / streamer / return-stroke bolt. Everything is a pure function of time.
import * as THREE from 'three';
import { groundMat, grass as grassBlades, leafyTrees, bush } from './hummer2.js';
import { NOISE, TIME, trees } from './world.js';
import { label } from './gps.js';

export function rnd(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

// ---------- storm sky with a flash uniform ----------
function stormSky(top = 0x1b2130, hor = 0x4a5466) {
  const m = new THREE.ShaderMaterial({
    uniforms: { uTop: { value: new THREE.Color(top) }, uHor: { value: new THREE.Color(hor) }, uFlash: { value: 0 }, uTime: TIME },
    vertexShader: `varying vec3 vDir; void main(){ vDir = (modelMatrix*vec4(position,1.)).xyz - cameraPosition; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.); gl_Position.z = gl_Position.w; }`,
    fragmentShader: NOISE + `uniform vec3 uTop, uHor; uniform float uFlash, uTime; varying vec3 vDir;
      void main(){ vec3 d = normalize(vDir); float y = d.y;
        vec3 col = mix(uHor, uTop, pow(clamp(y, 0.0, 1.0), 0.5));
        if (y > 0.0) { vec2 uv = d.xz / (y + 0.12) * 1.3 + vec2(uTime * 0.03, 0.0); float n = fbm(uv);
          col = mix(col, col * 0.6, smoothstep(0.35, 0.75, n)); col += vec3(0.75, 0.75, 1.0) * uFlash * (0.35 + 0.65 * n) * smoothstep(-0.05, 0.3, y); }
        if (y < 0.0) col = mix(uHor, vec3(0.08, 0.09, 0.08), smoothstep(0.0, -0.08, y));
        gl_FragColor = vec4(col, 1.0); }`,
    side: THREE.BackSide, depthWrite: false,
  });
  const s = new THREE.Mesh(new THREE.SphereGeometry(400, 48, 24), m); s.frustumCulled = false; s.renderOrder = -10; return s;
}

// ---------- the thundercloud: base at y=20, tower to ~40, anvil ----------
export const BASE = 20, TOP = 40;
function cloud() {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x8c95a6, roughness: 1, transparent: true, opacity: 1, emissive: 0xc8c8ff, emissiveIntensity: 0 });
  const R = rnd(11), geo = new THREE.IcosahedronGeometry(1, 3);
  const puffs = [];
  // flat dark base
  for (let i = 0; i < 26; i++) { const a = R() * Math.PI * 2, r = Math.sqrt(R()) * 13; puffs.push([Math.cos(a) * r, BASE + 1.6 + R() * 1.5, Math.sin(a) * r * 0.7, 3.2 + R() * 2.2]); }
  // tower
  for (let i = 0; i < 40; i++) { const y = BASE + 3 + R() * 15, w = 9 - (y - BASE) * 0.12, a = R() * Math.PI * 2, r = Math.sqrt(R()) * w; puffs.push([Math.cos(a) * r, y, Math.sin(a) * r * 0.7, 3.5 + R() * 2.5]); }
  // anvil
  for (let i = 0; i < 36; i++) { const a = R() * Math.PI * 2, r = Math.sqrt(R()) * 21; puffs.push([Math.cos(a) * r, TOP - 3 + R() * 3, Math.sin(a) * r * 0.6, 2.6 + R() * 2.4]); }
  const im = new THREE.InstancedMesh(geo, mat, puffs.length);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), c = new THREE.Color();
  puffs.forEach(([x, y, z, s], i) => { M.compose(new THREE.Vector3(x, y, z), q, new THREE.Vector3(s, s * (y < BASE + 4 ? 0.55 : 0.85), s)); im.setMatrixAt(i, M); const k = Math.min(1, (y - BASE) / (TOP - BASE)); im.setColorAt(i, c.setRGB(0.55 + 0.4 * k, 0.58 + 0.4 * k, 0.66 + 0.34 * k)); });
  g.add(im);
  { const small = []; puffs.forEach(([x, y, z, s0]) => { for (let k = 0; k < 4; k++) { const a = R() * Math.PI * 2, b = R() * Math.PI - Math.PI / 2; small.push([x + Math.cos(a) * Math.cos(b) * s0 * 0.95, y + Math.sin(b) * s0 * 0.6, z + Math.sin(a) * Math.cos(b) * s0 * 0.7, s0 * (0.35 + R() * 0.3)]); } });
    const im2 = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 3), mat, small.length);
    small.forEach(([x, y, z, sz], i) => { M.compose(new THREE.Vector3(x, y, z), q, new THREE.Vector3(sz, sz * 0.8, sz)); im2.setMatrixAt(i, M); const k = Math.min(1, Math.max(0, (y - BASE) / (TOP - BASE))); im2.setColorAt(i, c.setRGB(0.6 + 0.4 * k, 0.63 + 0.37 * k, 0.7 + 0.3 * k)); }); g.add(im2); }
  return { group: g, mat };
}

// ---------- lone tree at the origin (top ~ y 5) ----------
export const TREE_TOP = new THREE.Vector3(0, 5.2, 0);
function loneTree() {
  const g = new THREE.Group();
  const tr = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.38, 3.2, 10), new THREE.MeshStandardMaterial({ color: 0x4a3626, roughness: 1 })); tr.position.y = 1.6; g.add(tr);
  const lm = new THREE.MeshStandardMaterial({ color: 0x2f5a2a, roughness: 0.95 }); const R = rnd(5);
  for (let i = 0; i < 9; i++) { const s = new THREE.Mesh(new THREE.IcosahedronGeometry(0.9 + R() * 0.5, 2), lm); s.position.set((R() - 0.5) * 1.8, 3.4 + R() * 1.1, (R() - 0.5) * 1.6); s.scale.setScalar(0.75); g.add(s); const b = bush(30 + i, 160, 1.15); b.position.copy(s.position).add(new THREE.Vector3(0, -0.4, 0)); b.scale.setScalar(1.0); g.add(b); }
  return g;
}

// ---------- rain: thin streaks falling through a box around a centre ----------
function rain(center, size, n = 1400, seed = 3) {
  const R = rnd(seed); const P = []; for (let i = 0; i < n; i++) P.push([R(), R(), R(), 0.7 + R() * 0.6]);
  const m = new THREE.MeshBasicMaterial({ color: 0xaab4c8, transparent: true, opacity: 0.35, depthWrite: false });
  const im = new THREE.InstancedMesh(new THREE.BoxGeometry(0.02, 1, 0.02), m, n); im.frustumCulled = false;
  const M = new THREE.Matrix4(), q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, 0.12)), s = new THREE.Vector3();
  function update(T) {
    P.forEach(([x, y, z, v], i) => { const yy = ((y - T * 0.9 * v) % 1 + 1) % 1; s.set(1, size[1] * 0.04, 1); M.compose(new THREE.Vector3(center[0] + (x - 0.5) * size[0], center[1] + (yy - 0.5) * size[1], center[2] + (z - 0.5) * size[2]), q, s); im.setMatrixAt(i, M); });
    im.instanceMatrix.needsUpdate = true;
  }
  update(0);
  return { mesh: im, update, mat: m };
}

// ---------- charge signs ----------
const BADGE = {};
function badge(plus) {
  if (BADGE[plus]) return BADGE[plus];
  const cv = document.createElement('canvas'); cv.width = cv.height = 256; const c = cv.getContext('2d');
  c.beginPath(); c.arc(128, 128, 110, 0, Math.PI * 2); c.fillStyle = plus ? '#ff5a36' : '#2f9bff'; c.fill(); c.lineWidth = 14; c.strokeStyle = 'rgba(0,0,0,0.8)'; c.stroke();
  c.fillStyle = '#ffffff'; c.fillRect(58, 110, 140, 36); if (plus) c.fillRect(110, 58, 36, 140);
  const tx = new THREE.CanvasTexture(cv); tx.colorSpace = THREE.SRGBColorSpace; return (BADGE[plus] = tx);
}
// charge badge: red circle with +, blue circle with -
export function sign(plus, size = 1.2) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: badge(plus), transparent: true, depthTest: false, depthWrite: false, fog: false })); s.renderOrder = 20; s.scale.setScalar(size); return s; }

// ---------- bolt geometry ----------
const UP = new THREE.Vector3(0, 1, 0);
function segMesh(a, b, r, mat) { const d = b.clone().sub(a), L = d.length(); const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, 6, 1, true), mat); m.position.copy(a).addScaledVector(d, 0.5); m.quaternion.setFromUnitVectors(UP, d.normalize()); return m; }
function path(a, b, n, jit, R) { const P = [a.clone()]; for (let i = 1; i < n; i++) { const k = i / n, p = a.clone().lerp(b, k); const f = jit * Math.sin(Math.PI * k) ** 0.5; p.x += (R() - 0.5) * 2 * f; p.z += (R() - 0.5) * 1.2 * f; p.y += (R() - 0.5) * 0.3 * jit; P.push(p); } P.push(b.clone()); return P; }
export const MEET = new THREE.Vector3(0.4, 7.2, 0);
export function bolt(seed = 7) {
  const R = rnd(seed), g = new THREE.Group();
  const coreM = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, transparent: true, depthWrite: false });
  const glowM = new THREE.MeshBasicMaterial({ color: 0x9d8cff, toneMapped: false, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false });
  const start = new THREE.Vector3(-3.5, BASE + 0.5, 0.5);
  const main = path(start, MEET, 16, 1.6, R);
  const steps = []; // leader steps: [core, glow, order]
  for (let i = 0; i < main.length - 1; i++) { const c = segMesh(main[i], main[i + 1], 0.06, coreM), w = segMesh(main[i], main[i + 1], 0.2, glowM); g.add(c, w); steps.push({ ms: [c, w], k: i + 1 }); }
  // branches off the leader
  [3, 6, 9, 12].forEach((at, j) => {
    const dir = j % 2 ? 1 : -1; const p0 = main[at]; const p1 = p0.clone().add(new THREE.Vector3(dir * (2 + R() * 2.5), -(2.5 + R() * 3), (R() - 0.5) * 2));
    const bp = path(p0, p1, 5, 0.7, R);
    for (let i = 0; i < bp.length - 1; i++) { const c = segMesh(bp[i], bp[i + 1], 0.035, coreM), w = segMesh(bp[i], bp[i + 1], 0.13, glowM); g.add(c, w); steps.push({ ms: [c, w], k: at + (i + 1) * 0.9, branch: true }); }
  });
  // upward streamer from the tree top to MEET
  const sp = path(TREE_TOP.clone(), MEET, 4, 0.4, R); const str = [];
  const sCore = new THREE.MeshBasicMaterial({ color: new THREE.Color(2.6, 2.5, 2.2), toneMapped: false }), sGlow = new THREE.MeshBasicMaterial({ color: 0xfff0b0, toneMapped: false, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false });
  for (let i = 0; i < sp.length - 1; i++) { const c = segMesh(sp[i], sp[i + 1], 0.07, sCore), w = segMesh(sp[i], sp[i + 1], 0.3, sGlow); g.add(c, w); str.push({ ms: [c, w], k: (i + 1) / (sp.length - 1) }); }
  const flash = new THREE.PointLight(0xd8d4ff, 0, 140, 1); flash.position.copy(start).lerp(MEET, 0.5); g.add(flash);
  const N = main.length - 1;
  // set(leader 0..1, streamer 0..1, power: 0 = faint leader glow, 1 = full return stroke, branchFade 0..1)
  function set(leader, streamer, power, branchFade = 0) {
    const lk = leader * N;
    steps.forEach(({ ms, k, branch }) => { const on = k <= lk + 0.001; ms.forEach(m => { m.visible = on && !(branch && branchFade >= 0.99); }); });
    str.forEach(({ ms, k }) => ms.forEach(m => { m.visible = streamer >= k - 0.001; }));
    const b = 0.9 + power * 3.5; coreM.color.setRGB(b * 0.9, b * 0.86, b); glowM.opacity = 0.25 + power * 0.45; glowM.color.setRGB(0.6 + power, 0.55 + power * 0.8, 1.0 + power);
    coreM.opacity = 1 - branchFade * 0; flash.intensity = power * 260;
  }
  set(0, 0, 0);
  return { group: g, set, main, start, flash };
}

// ---------- outdoor storm stage ----------
export function stormStage({ rainOn = true, tree = true, cloudOn = true } = {}) {
  const scene = new THREE.Scene(); scene.userData.updaters = [];
  const sky = stormSky(); scene.add(sky); scene.userData.sky = sky;
  scene.fog = new THREE.FogExp2(0x3a4352, 0.006);
  const hemi = new THREE.HemisphereLight(0x8a94b0, 0x2a2a1e, 1.1); scene.add(hemi);
  const key = new THREE.DirectionalLight(0xb8c4e0, 1.0); key.position.set(-30, 60, 40); scene.add(key);
  const gm = groundMat(); gm.color.set(0x8a9a8a); gm.map.repeat.set(160, 160); const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 64), gm); ground.rotation.x = -Math.PI / 2; scene.add(ground);
  { const gb = grassBlades(9000, 0.6, 14, 33); gb.scale.setScalar(2.2); scene.add(gb); }
  const spots = []; const R = rnd(21); for (let k = 0; k < 140; k++) { const a = R() * Math.PI * 2, r = 22 + R() * 140; spots.push([Math.cos(a) * r, 0, Math.sin(a) * r]); }
  scene.add(trees(spots.slice(60), { seed: 4, scale: 2.2 }));
  scene.add(leafyTrees(spots.slice(0, 60).map(([x, y, z]) => { const r = Math.hypot(x, z); const f = Math.min(1, 70 / r); return [x * f, y, z * f]; }), { seed: 8, leaves: 1100, scale: 1.8 }));
  { const wm = new THREE.MeshBasicMaterial({ color: 0xffc870, toneMapped: false }); const R2 = rnd(44); for (let k = 0; k < 9; k++) { const a = -2.4 + k * 0.32 + R2() * 0.1, r = 48 + R2() * 30; const h = new THREE.Group(); h.position.set(Math.sin(a) * r, 0, -Math.cos(a) * r); h.rotation.y = -a;
      const body = new THREE.Mesh(new THREE.BoxGeometry(7, 4.5, 6), new THREE.MeshStandardMaterial({ color: [0xb8a890, 0xc8b8a0, 0xa89880][k % 3], roughness: 0.9 })); body.position.y = 2.25; h.add(body);
      const roof = new THREE.Mesh(new THREE.ConeGeometry(5.6, 3, 4), new THREE.MeshStandardMaterial({ color: 0x6a3a2a, roughness: 0.8 })); roof.rotation.y = Math.PI / 4; roof.position.y = 6; h.add(roof);
      for (let w = 0; w < 2; w++) { const win = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.2), wm); win.position.set(-1.6 + w * 3.2, 2.6, 3.02); h.add(win); } scene.add(h); } }
  // a few low hills
  for (let k = 0; k < 7; k++) { const h = new THREE.Mesh(new THREE.SphereGeometry(40 + k * 6, 32, 16), new THREE.MeshStandardMaterial({ color: 0x34502c, roughness: 1 })); const a = -1.2 + k * 0.4; h.position.set(Math.sin(a) * 210, -32 - k * 2, -Math.cos(a) * 210); h.scale.y = 0.6; scene.add(h); }
  let T = null; if (tree) { T = loneTree(); scene.add(T); }
  const C = cloudOn ? cloud() : null; if (C) scene.add(C.group);
  const Rn = rainOn ? rain([0, 12, 0], [60, 30, 40]) : null; if (Rn) scene.add(Rn.mesh);
  // flash(k): sky, cloud glow and ambient brighten
  function flash(k) { sky.material.uniforms.uFlash.value = k * 0.55; hemi.intensity = 1.1 + k * 0.9; if (C) C.mat.emissiveIntensity = k * 0.35; }
  return { scene, cloud: C, rain: Rn, flash, hemi };
}

// ---------- inside the cloud: grey mist, droplets / ice crystals / hail ----------
export function insideStage() {
  const scene = new THREE.Scene(); scene.userData.updaters = [];
  const sky = stormSky(0x5a6476, 0x7c8698); scene.add(sky); scene.userData.sky = sky;
  scene.fog = new THREE.FogExp2(0x76808f, 0.07);
  scene.add(new THREE.HemisphereLight(0xe6ecff, 0x4a5060, 1.6));
  const d = new THREE.DirectionalLight(0xffffff, 1.4); d.position.set(3, 6, 4); scene.add(d);
  { const cv = document.createElement('canvas'); cv.width = cv.height = 128; const c = cv.getContext('2d'); const gr = c.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(235,240,250,0.55)'); gr.addColorStop(0.5, 'rgba(210,218,232,0.25)'); gr.addColorStop(1, 'rgba(200,210,225,0)'); c.fillStyle = gr; c.fillRect(0, 0, 128, 128);
    const tex = new THREE.CanvasTexture(cv); const R = rnd(77);
    for (let i = 0; i < 22; i++) { const m = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false, opacity: 0.14 + R() * 0.14, color: 0xb8c0d0 }); const sp = new THREE.Sprite(m); const z = -9 - R() * 12; sp.position.set((R() - 0.5) * 24, (R() - 0.5) * 30, z); sp.scale.setScalar(5 + R() * 7); scene.add(sp); } }
  return { scene, sky };
}
// droplet (blue, glossy), crystal (white star-ish), hail (white lumpy)
export const MAT = {
  drop: new THREE.MeshPhysicalMaterial({ color: 0x5aa8ff, roughness: 0.05, transmission: 0.3, clearcoat: 1, emissive: 0x10306a, emissiveIntensity: 0.4 }),
  ice: new THREE.MeshStandardMaterial({ color: 0xeaf6ff, roughness: 0.2, metalness: 0.1, emissive: 0x9cc8ff, emissiveIntensity: 0.35, flatShading: true }),
  hail: new THREE.MeshPhysicalMaterial({ color: 0xf2f4f8, roughness: 0.55, clearcoat: 0.6, sheen: 0.8, sheenColor: new THREE.Color(0xd0e8ff), emissive: 0x404858, emissiveIntensity: 0.3 }),
};
export const GEO = {
  drop: new THREE.SphereGeometry(0.06, 16, 12),
  ice: (() => { const g = new THREE.OctahedronGeometry(0.07, 0); g.scale(1, 1.6, 1); return g; })(),
  hail: (() => { const g = new THREE.IcosahedronGeometry(0.16, 4); const p = g.attributes.position; for (let i = 0; i < p.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(p, i); const n = v.clone().normalize(); v.multiplyScalar(1 + 0.04 * Math.sin(v.x * 70) * Math.sin(v.y * 60) * Math.sin(v.z * 80) + 0.05 * Math.sin(v.x * 23 + v.z * 19)); p.setXYZ(i, v.x, v.y, v.z); g.attributes.normal.setXYZ(i, n.x, n.y, n.z); } return g; })(),
};
export function spark() { const m = new THREE.SpriteMaterial({ color: 0xfff2a0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }); const cv = document.createElement('canvas'); cv.width = cv.height = 128; const c = cv.getContext('2d'); const gr = c.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,240,160,0.8)'); gr.addColorStop(1, 'rgba(255,200,80,0)'); c.fillStyle = gr; c.fillRect(0, 0, 128, 128); m.map = new THREE.CanvasTexture(cv); const s = new THREE.Sprite(m); return s; }
