// The Explainer: how a chameleon changes colour. Chameleon on a branch (head +x), skin cross-section with a crystal
// lattice whose spacing sets the reflected colour, light rays.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.6, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
// colour from crystal spacing k (0 calm -> 1 excited): green (with yellow pigment) -> yellow -> orange -> red
export function skinColour(k, dark = 0) {
  const stops = [[0, 0x3fae3a], [0.45, 0xc8d22a], [0.7, 0xf0a020], [1, 0xe8461e]]; const c = new THREE.Color();
  for (let i = 0; i < stops.length - 1; i++) { const [a, ca] = stops[i], [b, cb] = stops[i + 1]; if (k <= b) { c.set(ca).lerp(new THREE.Color(cb), (k - a) / (b - a)); break; } }
  if (k > 1) c.set(stops[3][1]);
  return c.multiplyScalar(1 - 0.75 * dark);
}
export function chameleon() {
  const G = new THREE.Group(); const skin = std(0x3fae3a, 0.55); const spotM = std(0x2a7a2a, 0.6); const stripeM = std(0x9ae85a, 0.6);
  const body = new THREE.Mesh(new THREE.SphereGeometry(1, 40, 28), skin); body.scale.set(1.3, 0.9, 0.55); G.add(body);
  // dorsal crest
  for (let k = 0; k < 9; k++) { const c = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.22, 6), skin); const a = -0.9 + k * 0.22; c.position.set(Math.sin(a) * 1.2, Math.cos(a) * 0.86, 0); c.rotation.z = -a; G.add(c); }
  // lateral stripe
  const st = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 16), stripeM); st.scale.set(1.12, 0.12, 0.57); st.position.y = -0.15; G.add(st);
  // head with casque
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.55, 32, 20), skin); head.scale.set(1.25, 0.95, 0.8); head.position.set(1.45, 0.2, 0); G.add(head);
  const casque = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.9, 20), skin); casque.position.set(1.15, 0.72, 0); casque.rotation.z = 0.9; casque.scale.z = 0.5; G.add(casque);
  const eyes = [-1, 1].map(s => { const e = new THREE.Group(); const turret = new THREE.Mesh(new THREE.SphereGeometry(0.2, 20, 14), skin); e.add(turret); const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 8), std(0x0a0a0a, 0.2)); pupil.position.set(0.12, 0, s * 0.13); e.add(pupil); e.position.set(1.6, 0.35, s * 0.33); G.add(e); return e; });
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.02, 6, 20, 1.2), std(0x1a3a1a)); mouth.position.set(1.6, 0.05, 0); mouth.rotation.set(Math.PI / 2, 0, -0.4); G.add(mouth);
  // spots
  const R = rnd(4); for (let k = 0; k < 18; k++) { const sp = new THREE.Mesh(new THREE.SphereGeometry(0.07 + R() * 0.06, 10, 8), spotM); const a = R() * Math.PI * 2, b = (R() - 0.5) * 2.2; sp.position.set(Math.cos(a) * 1.25 * 0.9 * (b > 0 ? 1 : 1) * 0 + b * 0.55, 0.3 + R() * 0.45, (R() < 0.5 ? -1 : 1) * 0.5); G.add(sp); }
  // curled tail: tube along a spiral
  const pts = []; for (let i = 0; i <= 40; i++) { const u = i / 40; const ang = u * Math.PI * 2.4; const r = 0.9 * (1 - u * 0.75); pts.push(new THREE.Vector3(-1.2 - 0.6 * u - r * Math.sin(ang) * 0.6, -0.3 - r * (1 - Math.cos(ang)) * 0.6, 0)); }
  const tail = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 60, 0.16, 10), skin); G.add(tail);
  // legs gripping (down to y ~ -1.15)
  [[0.7, 1], [0.7, -1], [-0.7, 1], [-0.7, -1]].forEach(([x, s]) => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.08, 0.7, 10), skin); l.position.set(x, -0.8, s * 0.32); l.rotation.x = s * 0.35; G.add(l); const f = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 8), skin); f.scale.set(1, 0.6, 1.4); f.position.set(x, -1.13, s * 0.2); G.add(f); });
  const st0 = { k: 0, dark: 0 };
  function update(T) { const c = skinColour(st0.k, st0.dark); skin.color.copy(c); spotM.color.copy(c).multiplyScalar(0.7); stripeM.color.copy(skinColour(Math.min(1, st0.k + 0.25), st0.dark)).lerp(new THREE.Color(0xffffff), 0.35); eyes.forEach((e, i) => { e.rotation.z = 0.4 * Math.sin(T * 1.3 + i * 2); e.rotation.y = 0.5 * Math.sin(T * 0.9 + i); }); }
  update(0);
  return { group: G, st: st0, update };
}
export function branch(len = 14) { const g = new THREE.Group(); const m = std(0x6a4a2a, 0.9); const b = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, len, 12), m); b.rotation.z = Math.PI / 2; g.add(b);
  const R = rnd(9); const lm = std(0x4f9a3a, 0.7, 0, { side: THREE.DoubleSide }); for (let k = 0; k < 16; k++) { const l = new THREE.Mesh(new THREE.SphereGeometry(0.4, 12, 8), lm); l.scale.set(1, 0.08, 0.5); l.position.set((R() - 0.5) * len, 0.2 + R() * 0.4, (R() - 0.5) * 1.6); l.rotation.set(R(), R() * 3, R()); g.add(l); } return g; }

// skin cross-section block: yellow pigment layer on top, crystal lattice below. spacing(k) spreads the lattice.
export function skinSection() {
  const G = new THREE.Group();
  const block = new THREE.Mesh(new THREE.BoxGeometry(6, 3, 2.4), std(0xf0c8b0, 0.8, 0, { transparent: true, opacity: 0.25, depthWrite: false })); block.position.y = -1.0; G.add(block);
  const top = new THREE.Mesh(new THREE.BoxGeometry(6, 0.45, 2.4), std(0xf2d22a, 0.5, 0, { transparent: true, opacity: 0.65 })); top.position.y = 0.72; G.add(top);
  const cellM = std(0xbfd8ff, 0.3, 0, { transparent: true, opacity: 0.18, depthWrite: false }); const cell = new THREE.Mesh(new THREE.BoxGeometry(5.6, 1.9, 2.0), cellM); cell.position.y = -0.7; G.add(cell);
  const N = [11, 5, 4]; const cm = new THREE.MeshPhysicalMaterial({ color: 0xeaf4ff, roughness: 0.05, metalness: 0.3, iridescence: 1, iridescenceIOR: 1.8, clearcoat: 1 });
  const im = new THREE.InstancedMesh(new THREE.OctahedronGeometry(0.11, 0), cm, N[0] * N[1] * N[2]); G.add(im);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(1, 1, 1);
  function spacing(k) { let i = 0; const d = 0.36 + 0.16 * k; for (let a = 0; a < N[0]; a++) for (let b = 0; b < N[1]; b++) for (let c = 0; c < N[2]; c++) { M.compose(new THREE.Vector3((a - (N[0] - 1) / 2) * d, -0.7 + (b - (N[1] - 1) / 2) * d * 0.8, (c - (N[2] - 1) / 2) * d), q, s); im.setMatrixAt(i++, M); } im.instanceMatrix.needsUpdate = true; }
  spacing(0);
  return { group: G, spacing, top };
}
// a light ray: thin glowing cylinder from a to b, colour settable
export function ray() { const m = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, transparent: true }); const g = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1, 10), m); const head = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.3, 12), m); const grp = new THREE.Group(); grp.add(g, head);
  return { group: grp, set(a, b, k, color) { const d = b.clone().sub(a); const L = d.length() * k; g.scale.y = Math.max(0.001, L); g.position.copy(a).addScaledVector(d.normalize(), L / 2); g.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d); head.position.copy(a).addScaledVector(d, L); head.quaternion.copy(g.quaternion); grp.visible = k > 0.01; if (color) m.color.copy(color); } }; }
export { std };
