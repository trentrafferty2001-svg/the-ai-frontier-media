// The Explainer: why the sky is blue. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { SPEC, person, hills, prism, molecules, pair, wave, eye, std, glow } from './sky2.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_bl2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['The *sky*', 2], ['should really', 2], ['look *violet*', 2], ['So why', 2], ['do we see', 3], ['*blue*', 1]],
  [['*Sunlight*', 1], ['looks *white*', 2], ["but it's a *mix*", 4], ['of *every colour*', 3], ['from *red*', 2], ['to *violet*', 2]],
  [['On its way down', 4], ['it *hits*', 2], ['countless *tiny*', 2], ['*nitrogen*', 1], ['and *oxygen*', 2], ['*molecules*', 1], ['in the air', 3]],
  [['Those molecules', 2], ['*scatter*', 1], ['*short waves*', 2], ['like *blue*', 2], ['and *violet*', 2], ['*far more*', 2], ['than the *long*', 3], ['*red* ones', 2]],
  [['So *blue light*', 3], ['*bounces*', 1], ['all over the sky', 4], ['and reaches', 2], ['your *eyes*', 2], ['from *every*', 2], ['*direction*', 1]],
  [['*Violet* scatters', 2], ['even more', 2], ['but the sun', 3], ['gives out', 2], ['*less* of it', 3], ['and our *eyes*', 3], ['are much more', 3], ['*sensitive*', 1], ['to *blue*', 2]],
  [['At *sunset*', 2], ['the light', 2], ['has to cross', 3], ['*far more air*', 3], ['to reach you', 3], ['so most of', 3], ['the *blue*', 2], ['is *scattered away*', 3]],
  [['Only the *reds*', 3], ['and *oranges*', 2], ['make it *through*', 3], ['and the whole sky', 4], ['glows *orange*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 38) => { const c = cam(fov); c.near = 0.01; c.far = 800; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 1.0, warm: 0.95, sat: 1.15, exposure: 1.05 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };
const col = (a, b, k) => new THREE.Color(a).lerp(new THREE.Color(b), k);
const VIOLET = [0x4a1ab8, 0x8a5ae0, 0xd0b8f4], BLUE = [0x1a56d0, 0x4a96e8, 0xb4dcf6], DUSK = [0x3a2a6a, 0xe8642a, 0xffb84a];
function setSky(scene, A, B, k, floor = 0x3a6a2a) { const u = scene.userData.sky.material.uniforms; if (!u.top) return; u.top.value.copy(col(A[0], B[0], k)); u.mid.value.copy(col(A[1], B[1], k)); u.horizon.value.copy(col(A[2], B[2], k)); u.floorC.value.set(floor); }
function day(makeStage) {
  const scene = makeStage({ shadowSize: 8, sunDir: [3, 6, -4] });
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(hills()); const P = person(); P.rotation.y = Math.PI; scene.add(P);
  const sunM = glow(0xfff4d0, { transparent: true }); const sun = new THREE.Mesh(new THREE.SphereGeometry(3, 32, 20), sunM); scene.add(sun);
  return { scene, P, sun, sunM };
}
function lab(makeStage, top = 0x0a0e24) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(top); u.mid.value.set(0x121834); u.horizon.value.set(0x1a2244); u.floorC.value.set(0x05080e); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xdfe8ff, 0x101828, 0.9)); const k = new THREE.DirectionalLight(0xffffff, 1.2); k.position.set(3, 5, 6); scene.add(k);
  return scene;
}

// ============ S0 hook: looking up from a hill, the sky starts violet and turns blue ============
function sHook({ makeStage }) {
  const W = day(makeStage); W.sun.position.set(-30, 45, -60);
  const c = C(44); const tb = at(0, 'blue');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      setSky(W.scene, VIOLET, BLUE, smooth(range(T, tb - 0.9, tb + 0.2)));
      const k = easeInOut(range(t, 0, 3.9));
      place(c, [1.4, 1.1, lerp(7.5, 6.8, k)], [lerp(-1, -2, k), lerp(8.5, 11, k), -20]);
      return POST;
    },
  };
}
// ============ S1: white sunlight through a prism fans into every colour ============
function sPrism({ makeStage }) {
  const scene = lab(makeStage); const Pr = prism(); scene.add(Pr.group);
  const Lw = tag(scene, 'white light', 0.95, '#ffffff', [-2.1, 1.25, 0.3]), Lr = tag(scene, 'red', 0.95, '#ff6a6a', [2.6, 0.75, 0.3]), Lv = tag(scene, 'violet', 0.95, '#c08aff', [2.3, -3.1, 0.3]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      Pr.set(easeOut(range(T, at(1, 'mix') - 0.2, at(1, 'colour') + 0.2)));
      pop(Lw, easeOut(range(T, at(1, 'white') - 0.15, at(1, 'white') + 0.15)), 0.95);
      pop(Lr, easeOut(range(T, at(1, 'red') - 0.15, at(1, 'red') + 0.15)), 0.95); pop(Lv, easeOut(range(T, at(1, 'violet') - 0.15, at(1, 'violet') + 0.15)), 0.95);
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0.3, -0.5, 0], lerp(19.5, 18.5, k), lerp(-8, 6, k), 4);
      return POST;
    },
  };
}
// ============ S2: sunlight streams down into a crowd of tiny N2 and O2 molecules ============
function sAir({ makeStage }) {
  const scene = lab(makeStage, 0x1a3a7a); const u = scene.userData.sky.material.uniforms; if (u.top) { u.mid.value.set(0x2a56a8); u.horizon.value.set(0x3a6ab8); u.floorC.value.set(0x2a56a8); }
  const M = molecules(220, [16, 20, 10]); scene.add(M.group);
  const beamM = glow(0xfff8e0, { transparent: true, opacity: 0, depthWrite: false }); const beam = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 30, 32, 1, true), beamM); beam.rotation.z = 0.25; scene.add(beam);
  const hn = pair(false), ho = pair(true); hn.position.set(-1.6, 1.8, 2.5); ho.position.set(1.7, -0.2, 2.5); scene.add(hn, ho);
  const Ln = tag(scene, 'nitrogen', 1.0, '#cfe0ff', [-0.3, 3.1, 2.5]), Lo = tag(scene, 'oxygen', 1.0, '#ffb0a0', [1.1, 1.1, 2.5]);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      M.update(T); hn.rotation.z = Math.sin(T) * 0.5; ho.rotation.z = Math.cos(T * 0.9) * 0.5; hn.position.y = 1.8 + Math.sin(T * 1.4) * 0.1; ho.position.y = -0.2 + Math.cos(T * 1.2) * 0.1;
      beamM.opacity = 0.13 * smooth(range(T, ls(2) - 0.2, at(2, 'down') + 0.3)) * (0.85 + 0.15 * Math.sin(T * 6));
      const sn = easeOut(range(T, at(2, 'nitrogen') - 0.15, at(2, 'nitrogen') + 0.2)), so = easeOut(range(T, at(2, 'oxygen') - 0.15, at(2, 'oxygen') + 0.2));
      hn.scale.setScalar(0.3 + 0.7 * sn); ho.scale.setScalar(0.3 + 0.7 * so); pop(Ln, sn, 1.0); pop(Lo, so, 1.0);
      const k = easeInOut(range(t, 0, 5.3));
      orb(c, [0, 0.6, 0], lerp(16, 13.5, k), lerp(-6, 6, k), 3);
      return POST;
    },
  };
}
// ============ S3: a short blue wave hits a molecule and sprays out in all directions; a long red wave passes straight through ============
function sScatter({ makeStage }) {
  const scene = lab(makeStage); const mol = pair(false); scene.add(mol);
  const blue = wave(0x3a8aff, 0.7, 0.3, -7, -0.6, 0.07); blue.group.position.y = 1.4; scene.add(blue.group);
  const red = wave(0xff3a3a, 2.4, 0.45, -7, 7, 0.08); red.group.position.y = -1.6; scene.add(red.group);
  const R = rnd(8); const spray = []; for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2 + 0.2; const w = wave(i % 3 === 2 ? 0x9a5aff : 0x4a9aff, 0.5, 0.16, 0, 1.6, 0.05); const g = new THREE.Group(); g.add(w.group); g.rotation.z = a; g.position.y = 1.4; scene.add(g); spray.push({ g, w, a }); }
  mol.position.y = 1.4;
  const Ls = tag(scene, 'short waves', 0.9, '#8ac4ff', [-1.0, 3.8, 0.3]), Ll = tag(scene, 'long waves', 0.9, '#ff8a8a', [-0.8, -3.1, 0.3]);
  const c = C(38); const ts = at(3, 'scatter'), tl = at(3, 'long');
  return {
    scene, camera: c,
    update(t, T) {
      blue.set(T, 3); mol.rotation.z = Math.sin(T * 2) * 0.3;
      const sp = smooth(range(T, ts - 0.1, ts + 0.6));
      spray.forEach(({ g, w }) => { w.set(T, 2); g.children[0].position.x = 0.8 + ((T * 1.2) % 1.2) * sp; g.scale.setScalar(Math.max(0.001, sp)); g.visible = sp > 0.01; });
      const rk = smooth(range(T, tl - 0.8, tl - 0.1)); red.set(T, 4); red.group.visible = rk > 0.01; red.group.scale.y = Math.max(0.001, rk);
      pop(Ls, easeOut(range(T, at(3, 'short') - 0.15, at(3, 'short') + 0.15)), 0.9); pop(Ll, easeOut(range(T, tl - 0.15, tl + 0.15)), 0.9);
      const k = easeInOut(range(t, 0, 5.8));
      orb(c, [0, 0.4, 0], lerp(18.5, 17, k), lerp(-6, 6, k), 3);
      return POST;
    },
  };
}
// ============ S4: blue light streams into your eyes from every part of the sky ============
function sEvery({ makeStage }) {
  const W = day(makeStage); setSky(W.scene, BLUE, BLUE, 0); W.sun.position.set(40, 50, -70);
  const R = rnd(12); const H = new THREE.Vector3(0, 1.65, 0); const S = [];
  const sm = glow(0x2a7aff); for (let i = 0; i < 46; i++) { const az = (R() - 0.5) * 2.6, el = 0.15 + R() * 1.1, d = 26 + R() * 8; const P0 = new THREE.Vector3(Math.sin(az) * Math.cos(el) * d, H.y + Math.sin(el) * d, -Math.cos(az) * Math.cos(el) * d); const m = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 2.6, 6), sm); W.scene.add(m); S.push({ m, P0, ph: R() }); }
  const c = C(46); const up = new THREE.Vector3(0, 1, 0), q = new THREE.Quaternion();
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      S.forEach(({ m, P0, ph }) => { const u = (T * 0.45 + ph) % 1; m.position.copy(P0).lerp(H, u); const dir = H.clone().sub(P0).normalize(); q.setFromUnitVectors(up, dir); m.quaternion.copy(q); m.scale.setScalar(u > 0.93 ? (1 - u) / 0.07 : 1); });
      const k = easeInOut(range(t, 0, 5.0));
      place(c, [lerp(0.9, 1.3, k), 1.2, lerp(6.4, 7.6, k)], [lerp(-0.5, -1.2, k), lerp(9, 10.5, k), -20]);
      return POST;
    },
  };
}
// ============ S5: the sun sends less violet than blue, and the eye is most sensitive to blue ============
function sEye({ makeStage }) {
  const scene = lab(makeStage); const E = eye(); E.group.position.set(1.3, -2.3, 0); E.group.lookAt(-3, 3, 7); scene.add(E.group);
  const sunM = glow(0xffd860); const sun = new THREE.Mesh(new THREE.SphereGeometry(0.85, 32, 20), sunM); sun.position.set(-1.6, 4.0, -1); scene.add(sun);
  const rays = []; const mk = (c, r, off) => { const a = sun.position.clone(), b = E.group.position.clone(); const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 1, 8), glow(c, { transparent: true })); const dir = b.clone().sub(a); const n = new THREE.Vector3(-dir.y, dir.x, 0).normalize(); m.position.copy(a.clone().lerp(b, 0.5)).addScaledVector(n, off); m.scale.y = dir.length() * 0.78; m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize()); scene.add(m); rays.push(m); return m; };
  const blues = [-0.45, -0.27, -0.09, 0.09].map(o => mk(0x3a8aff, 0.07, o)); const violets = [0.33].map(o => mk(0x9a4aff, 0.035, o));
  const Ll = tag(scene, 'less violet', 0.9, '#c08aff', [1.2, 2.5, 0.5]), Lb = tag(scene, 'sees blue best', 0.9, '#8ac4ff', [0.6, -4.1, 0.6]);
  const c = C(38); const tl = at(5, 'less'), tsn = at(5, 'sensitive');
  return {
    scene, camera: c,
    update(t, T) {
      const on = smooth(range(T, ls(5) - 0.1, ls(5) + 0.6)); blues.forEach(m => m.material.opacity = on); violets.forEach(m => { m.material.opacity = on * (1 - 0.6 * smooth(range(T, tl - 0.2, tl + 0.4))); });
      E.irisM.emissiveIntensity = 1.6 * smooth(range(T, tsn - 0.3, tsn + 0.4));
      pop(Ll, easeOut(range(T, tl - 0.15, tl + 0.15)) * 1, 0.9); pop(Lb, easeOut(range(T, tsn - 0.15, tsn + 0.15)), 0.9);
      const k = easeInOut(range(t, 0, 6.5));
      orb(c, [0, 0.3, 0], lerp(18, 16.5, k), lerp(-6, 6, k), 3);
      return POST;
    },
  };
}
// ============ S6: diagram: at noon light crosses a thin layer of air; at sunset it skims through far more, losing its blue ============
function sPath({ makeStage }) {
  const scene = lab(makeStage, 0x05070f); const G = new THREE.Group(); scene.add(G);
  const earth = new THREE.Mesh(new THREE.CircleGeometry(4, 64), std(0x2a7a4a, 0.8)); earth.position.y = -4; G.add(earth);
  const air = new THREE.Mesh(new THREE.RingGeometry(4, 5.3, 96), glow(0x6aaaf0, { transparent: true, opacity: 0.28, depthWrite: false })); air.position.set(0, -4, -0.05); G.add(air);
  const you = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 12), glow(0xffffff)); you.position.set(0, 0.05, 0.1); G.add(you);
  { const cm = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55, depthWrite: false }); for (let i = 0; i < 26; i++) { const a = Math.PI / 2 + (i - 13) * 0.11; const c = new THREE.Mesh(new THREE.SphereGeometry(0.14 + (i % 3) * 0.06, 12, 8), cm); c.scale.set(1.8, 0.6, 0.3); c.position.set(Math.cos(a) * 4.55, -4 + Math.sin(a) * 4.55, 0.02); c.rotation.z = a - Math.PI / 2; G.add(c); } }
  const noonSun = new THREE.Mesh(new THREE.SphereGeometry(0.6, 24, 16), glow(0xfff0c0)); noonSun.position.set(0, 4.4, 0); G.add(noonSun);
  const noonRay = new THREE.Mesh(new THREE.BoxGeometry(0.12, 4.3, 0.06), glow(0xfff8e0)); noonRay.position.set(0, 2.25, 0.05); G.add(noonRay);
  const setSun = new THREE.Mesh(new THREE.SphereGeometry(0.6, 24, 16), glow(0xffa040, { transparent: true })); setSun.position.set(5.8, 0.3, 0); G.add(setSun);
  const segs = []; for (let i = 0; i < 24; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.12, 0.06), glow(0xffffff)); m.position.set(5.4 - i * 0.225, 0.3 - (i / 23) * 0.25, 0.05); G.add(m); segs.push(m); }
  const R = rnd(21); const blues = []; for (let i = 0; i < 22; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), glow(0x4a9aff)); G.add(m); blues.push({ m, x: 5.5 - R() * 5.2, a: R() * Math.PI * 2, ph: R() }); }
  const Ln = tag(scene, 'noon', 1.3, '#fff0c0', [-1.3, 4.4, 0.3]), Ls = tag(scene, 'sunset', 1.3, '#ffb060', [5.0, 2.0, 0.3]), Ly = tag(scene, 'you', 1.0, '#ffffff', [-1.0, 0.9, 0.3]);
  const c = C(38); const tss = at(6, 'sunset'), tsc = at(6, 'scattered');
  const cW = new THREE.Color(0xffffff), cO = new THREE.Color(0xff7a2a);
  return {
    scene, camera: c,
    update(t, T) {
      const sk = smooth(range(T, tss - 0.2, tss + 0.6)); setSun.visible = sk > 0.01; setSun.scale.setScalar(Math.max(0.001, sk));
      const draw = range(T, at(6, 'cross') - 0.2, at(6, 'air') + 0.4); const fade = smooth(range(T, at(6, 'blue') - 0.3, tsc + 0.6));
      segs.forEach((m, i) => { const f = i / 23; m.visible = draw * 1.05 > f; m.material.color.copy(cW).lerp(cO, Math.min(1, fade * (0.3 + f))); });
      blues.forEach(({ m, x, a, ph }) => { const u = fade > 0 ? ((T * 0.6 + ph) % 1) : 0; m.visible = fade > 0.02 && draw * 7.0 > 7.0 - x; m.position.set(x + Math.cos(a) * u * 1.6, 0.25 + Math.sin(a) * u * 1.6, 0.1); m.scale.setScalar(fade * (1 - u)); });
      noonRay.material.color.setScalar(1);
      pop(Ln, easeOut(range(T, ls(6) - 0.1, ls(6) + 0.3)), 1.3); pop(Ls, easeOut(range(T, tss - 0.1, tss + 0.3)), 1.3); pop(Ly, easeOut(range(T, ls(6), ls(6) + 0.3)), 1.0);
      const k = easeInOut(range(t, 0, 5.8));
      orb(c, [2.4, 1.0, 0], lerp(26, 24.5, k), lerp(-4, 4, k), 2);
      return POST;
    },
  };
}
// ============ S7: payoff: back on the hill, the sky turns orange at sunset ============
function sSunset({ makeStage }) {
  const W = day(makeStage); const c = C(44); const tr = at(7, 'reds'), to = at(7, 'orange');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const k2 = smooth(range(T, tr - 0.6, to + 0.4)); setSky(W.scene, BLUE, DUSK, k2, k2 > 0.5 ? 0x2a3a1a : 0x3a6a2a);
      W.sun.position.set(-6, lerp(16, 8, k2), -90); W.sunM.color.copy(col(0xfff4d0, 0xff7a2a, k2)); W.sun.scale.setScalar(lerp(1, 1.6, k2));
      const k = easeInOut(range(t, 0, 5.8));
      place(c, [lerp(1.0, 1.4, k), 1.4, lerp(6.0, 7.5, k)], [-1.5, lerp(5, 4, k), -40]);
      return POST;
    },
  };
}

const SH = [sHook, sPrism, sAir, sScatter, sEvery, sEye, sPath, sSunset];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
