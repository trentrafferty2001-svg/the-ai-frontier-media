// The Explainer: how a submarine dives and surfaces. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { submarine, forces, oceanSurface, std } from './sub.js';
import { sea } from './ocean.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_sb.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *submarine* dives', 3], ['by letting', 2], ['the *sea flood*', 3], ['into it', 2], ['on *purpose*', 2]],
  [['Between its', 2], ['*inner* and *outer*', 3], ['hull are', 2], ['huge', 1], ['*ballast tanks*', 2]],
  [['On the *surface*', 3], ["they're full", 2], ['of *air*', 2], ['so the sub', 3], ['weighs *less*', 2], ['than the water', 3], ['it *pushes aside*', 3], ['and it *floats*', 3]],
  [['To *dive*', 2], ['valves on top', 3], ['*open*', 1], ['the *air* rushes', 3], ['*out*', 1], ['and *seawater*', 2], ['*floods in*', 2], ['from below', 2]],
  [['Now the sub', 3], ['is *heavier*', 2], ['than the water', 3], ['it pushes aside', 3], ['so it *sinks*', 3]],
  [['Smaller', 1], ['*trim tanks*', 2], ['*fine tune*', 2], ['the balance', 2], ['so it can', 3], ['*hover*', 1], ['at one depth', 3]],
  [['Fins called', 2], ['*diving planes*', 2], ['*tilt* it', 2], ['*up* or *down*', 3], ['as it moves', 3]],
  [['To *surface*', 2], ['*high pressure*', 2], ['*air* is blasted', 3], ['into the tanks', 3], ['pushing the', 2], ['*water* back out', 3]],
  [['*Lighter*', 1], ['than the water', 3], ['again', 1], ['it *rises*', 2], ['all the way', 3], ['back to the', 3], ['*surface*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.05; c.far = 900; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.45, warm: 1.0, sat: 1.15, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

// surface world: sky + ocean plane at y=0; sub floating with its waterline
function surfaceWorld(makeStage) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.5, 0.7, 0.6], fog: 0.004, shadowSize: 8, envI: 1.0, cloud: 0.4 });
  const O = oceanSurface(); scene.add(O.mesh); const S = submarine(); scene.add(S.group);
  return { scene, O, S };
}
// underwater world: blue fog, sand far below, bright surface overhead at y = 0, sub at depth
function deepWorld(makeStage) {
  const scene = makeStage({ shadowSize: 6, sunDir: [0.6, 6, 1.2] });
  sea(scene, { rocks: false, coral: false, fogColor: 0x0c4a78, density: 0.018 });
  scene.children.filter(o => o.isMesh && o.geometry && o.geometry.type === 'PlaneGeometry').forEach(o => { o.position.y = -22; });
  const top = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshBasicMaterial({ color: 0x9fe6ff, side: THREE.DoubleSide, transparent: true, opacity: 0.85, fog: false })); top.rotation.x = Math.PI / 2; scene.add(top);
  const S = submarine(); scene.add(S.group);
  const R = rnd(3); const motes = new THREE.InstancedMesh(new THREE.SphereGeometry(0.03, 6, 4), new THREE.MeshBasicMaterial({ color: 0xcfefff, transparent: true, opacity: 0.5 }), 500); scene.add(motes);
  const M = new THREE.Matrix4(); for (let i = 0; i < 500; i++) { M.makeTranslation((R() - 0.5) * 40, -20 + R() * 20, (R() - 0.5) * 30); motes.setMatrixAt(i, M); }
  return { scene, S };
}
// global ballast state by time
function ballast(S, T) {
  const s = S.S;
  s.fill = T < at(3, 'open') ? 0 : T < ls(7) ? smooth(range(T, at(3, 'air') - 0.2, at(3, 'below') + 0.6)) : 1 - smooth(range(T, at(7, 'blasted') - 0.2, le(7)));
  s.vent = (T > at(3, 'open') - 0.1 && T < at(3, 'below') + 0.6) ? 1 : 0;
  s.blow = (T > at(7, 'blasted') - 0.2 && T < le(7) + 0.4) ? 1 : 0;
  s.trim = 0.5 + 0.25 * Math.sin(Math.max(0, T - at(5, 'fine')) * 2.2) * smooth(range(T, at(5, 'fine') - 0.2, at(5, 'fine') + 0.3)) * (1 - smooth(range(T, at(5, 'hover'), at(5, 'depth'))));
  s.prop = T * 4;
}

// ============ S0 hook: at the surface, vents roar open and the sub slides under ============
function sHook({ makeStage }) {
  const W = surfaceWorld(makeStage);
  const spray = []; const R = rnd(7); const sm = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 });
  for (let i = 0; i < 80; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.08 + R() * 0.1, 8, 6), sm); W.scene.add(m); spray.push({ m, x: R() < 0.5 ? 2.95 : -2.95, dx: (R() - 0.5) * 0.6, dz: (R() - 0.5) * 0.6, v: 4 + R() * 3, ph: R() }); }
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t) {
      W.O.update(t); const S = W.S;
      const sink = easeIn(range(t, 0.4, 4.4)); S.group.position.set(t * 0.4, lerp(0.15, -2.4, sink), 0); S.body.rotation.z = -0.05 * sink;
      S.S.prop = t * 4; S.update(t);
      spray.forEach(o => { const u = ((o.ph + t * 1.2) % 1); const on = t < 3.4; o.m.visible = on; o.m.position.set(S.group.position.x + o.x + o.dx * u * 2, S.group.position.y + 1.0 + o.v * u - 4 * u * u, o.dz * u * 2); o.m.scale.setScalar(1 - u * 0.5); });
      const k = easeInOut(range(t, 0, 4.3));
      orb(c, [lerp(0.5, 1.5, k), lerp(0.3, -0.4, k), 0], lerp(17, 19, k), lerp(50, 58, k), lerp(10, 6, k));
      return POST;
    },
  };
}
// ============ S1: hull fades to reveal the ballast tanks (underwater, at the surface) ============
function sReveal({ makeStage }) {
  const W = deepWorld(makeStage); W.S.group.position.set(0, -8, 0);
  const L1 = tag(W.scene, 'ballast tanks', 0.6, '#9cf0ff', [0, -5.9, 0]), L2 = L1;
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      ballast(W.S, T); W.S.S.xray = smooth(range(T, at(1, 'inner') - 0.3, at(1, 'outer') + 0.2)); W.S.update(T);
      const lk = easeOut(range(T, at(1, 'ballast') - 0.15, at(1, 'ballast') + 0.2)); pop(L1, lk, 0.6);
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [0, -7.8, 0], lerp(17, 15, k), lerp(56, 46, k), lerp(6, 10, k));
      return POST;
    },
  };
}
// ============ S2: at the surface the tanks hold air: weight = buoyancy, it floats ============
function sFloat({ makeStage }) {
  const W = surfaceWorld(makeStage); W.S.group.position.set(0, 0.15, 0);
  const F = forces(); W.S.group.add(F.group);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.O.update(T); ballast(W.S, T); W.S.S.xray = 1; W.S.update(T);
      W.S.group.position.y = 0.15 + 0.05 * Math.sin(T * 1.3);
      const fk = easeOut(range(T, at(2, 'weighs') - 0.2, at(2, 'weighs') + 0.3)); F.set(1.6 * fk, 1.6 * fk);
      const k = easeInOut(range(t, 0, 5.8));
      orb(c, [0, 0.2, 0], lerp(18, 16, k), lerp(56, 46, k), lerp(12, 8, k));
      return POST;
    },
  };
}
// ============ S3: vents open, air bubbles out, seawater floods in (close on the fore tank) ============
function sFlood({ makeStage }) {
  const W = deepWorld(makeStage); W.S.group.position.set(0, -8, 0);
  const c = C(38);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      ballast(W.S, T); W.S.S.xray = 1; W.S.update(T);
      const k = easeInOut(range(t, 0, 5.2));
      orb(c, [lerp(2.8, 1.6, k), lerp(-7.3, -7.0, k), 0], lerp(7.5, 10, k), lerp(34, 24, k), lerp(8, 12, k));
      return POST;
    },
  };
}
// ============ S4: heavier than the water it displaces: it sinks ============
function sSink({ makeStage }) {
  const W = deepWorld(makeStage); const F = forces(); W.S.group.add(F.group);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      ballast(W.S, T); W.S.S.xray = 1 - smooth(range(T, at(4, 'sinks') + 0.4, le(4) + 0.8)) * 0.6; W.S.update(T);
      const d = easeIn(range(t, 0, 4.2)); W.S.group.position.set(0, lerp(-8, -14, d), 0);
      const fk = easeOut(range(T, at(4, 'heavier') - 0.2, at(4, 'heavier') + 0.3)); F.set(1.6 * fk, 2.6 * fk);
      orb(c, [0, W.S.group.position.y + 0.6, 0], 17, lerp(50, 58, d), lerp(10, 2, d));
      return POST;
    },
  };
}
// ============ S5: trim tank fine-tunes; the sub hovers ============
function sTrim({ makeStage }) {
  const W = deepWorld(makeStage); W.S.group.position.set(0, -9, 0);
  const L = tag(W.scene, 'trim tank', 0.75, '#9cf0ff', [0, -6.8, 1.2]);
  const c = C(38);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      ballast(W.S, T); W.S.S.xray = 1; W.S.update(T);
      W.S.group.position.y = -9 + 0.15 * Math.sin(T * 1.6) * (1 - smooth(range(T, at(5, 'hover') - 0.2, at(5, 'hover') + 0.6)));
      pop(L, easeOut(range(T, at(5, 'trim') - 0.15, at(5, 'trim') + 0.2)), 0.75);
      const k = easeInOut(range(t, 0, 4.0));
      orb(c, [0, -9.4, 0], lerp(15, 14, k), lerp(-40, -30, k), lerp(-4, 0, k));
      return POST;
    },
  };
}
// ============ S6: diving planes tilt it up or down as it moves ============
function sPlanes({ makeStage }) {
  const W = deepWorld(makeStage);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      ballast(W.S, T); W.S.S.xray = 0; const tu = at(6, 'up'), td = at(6, 'down');
      const pl = T < tu - 0.2 ? 0 : T < td - 0.2 ? -0.35 : 0.35; W.S.S.planes = pl * smooth(range(T, tu - 0.3, tu));
      W.S.update(T);
      const pitch = (T < td - 0.1 ? 0.12 * smooth(range(T, tu - 0.1, tu + 0.5)) : lerp(0.12, -0.14, smooth(range(T, td - 0.1, td + 0.7))));
      W.S.body.rotation.z = pitch; W.S.group.position.set(-3 + t * 1.6, -9 + Math.sin(pitch) * t * 0.8, 0);
      const k = easeInOut(range(t, 0, 3.3));
      orb(c, [W.S.group.position.x + 0.5, -8.8, 0], 17, lerp(52, 60, k), lerp(4, 8, k));
      return POST;
    },
  };
}
// ============ S7: blow the tanks: high-pressure air pushes the water out ============
function sBlow({ makeStage }) {
  const W = deepWorld(makeStage); W.S.group.position.set(0, -9, 0);
  const L = tag(W.scene, 'high-pressure air', 0.7, '#9cf0ff', [0, -6.4, 0.5]);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      ballast(W.S, T); W.S.S.xray = 1; W.S.update(T);
      pop(L, easeOut(range(T, at(7, 'high') - 0.15, at(7, 'high') + 0.2)) * (1 - range(T, at(7, 'pushing'), at(7, 'pushing') + 0.4)), 0.7);
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [0, -8.8, 0], lerp(16, 17, k), lerp(-50, -40, k), lerp(6, 10, k));
      return POST;
    },
  };
}
// ============ S8: it rises and breaks the surface ============
function sRise({ makeStage }) {
  const W = surfaceWorld(makeStage);
  const R = rnd(19); const sm = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.75 }); const sp = [];
  for (let i = 0; i < 90; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.1 + R() * 0.12, 8, 6), sm); W.scene.add(m); sp.push({ m, x: (R() - 0.5) * 8, z: (R() < 0.5 ? -1 : 1) * (1.3 + R() * 1.4), v: 2 + R() * 3, ph: R() * 0.4 }); }
  const c = C(40); const tb = at(8, 'rises') + 0.4;
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.O.update(T); W.S.S.xray = 0; W.S.S.prop = T * 4; W.S.update(T);
      const r = easeOut(range(T, ls(8) - 0.2, tb + 1.2)); W.S.group.position.set(0, lerp(-4, 0.6, r), 0); W.S.body.rotation.z = 0.12 * (1 - r);
      sp.forEach(o => { const u = T - tb - o.ph; o.m.visible = u > 0 && u < 1.2; const uu = Math.max(0, u); o.m.position.set(o.x, 0.2 + o.v * uu - 4.9 * uu * uu, o.z); });
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [0, lerp(-0.5, 0.5, k), 0], lerp(18, 21, k), lerp(52, 58, k), lerp(4, 10, k));
      return POST;
    },
  };
}

const SH = [sHook, sReveal, sFloat, sFlood, sSink, sTrim, sPlanes, sBlow, sRise];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
