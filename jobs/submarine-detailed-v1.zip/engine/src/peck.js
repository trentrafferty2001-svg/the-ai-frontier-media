// The Explainer: why woodpeckers don't get concussions. Woodpecker with x-ray head, bark trunk, props.
// Units: metres. Woodpecker ~0.25 m long (great spotted size), clinging to a trunk whose surface faces +x at x = 0.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TIME, NOISE, trees } from './world.js';
import { rng } from './textures.js';

// ---------------- forest and trunk ----------------
export function forest(scene, { seed = 3 } = {}) {
  const g = new THREE.Mesh(new THREE.CircleGeometry(80, 48), new THREE.MeshStandardMaterial({ color: 0x4f6b35, roughness: 1 }));
  g.rotation.x = -Math.PI / 2; g.position.y = -3; g.receiveShadow = true; scene.add(g);
  const R = rng(seed); const spots = [];
  for (let k = 0; k < 140; k++) { const a = R() * Math.PI * 2, r = 6 + R() * 40; const x = Math.cos(a) * r, z = Math.sin(a) * r; if (x > -3 && Math.abs(z) < 4) continue; spots.push([x, -3, z]); }
  scene.add(trees(spots, { seed, scale: 2.2 }));
  // a few tall background trunks
  const bm = barkMaterial(0.8);
  for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + (R() - 0.5) * 2.4, r = 3 + R() * 9; const t = new THREE.Mesh(new THREE.CylinderGeometry(0.25 + R() * 0.2, 0.35 + R() * 0.2, 14, 16), bm); t.position.set(-Math.abs(Math.cos(a) * r) - 1.5, 4, Math.sin(a) * r); t.castShadow = true; scene.add(t); }
}
function barkMaterial(dark = 1) {
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95 });
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWb;').replace('#include <project_vertex>', '#include <project_vertex>\nvWb = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWb;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float a = atan(vWb.z, vWb.x); vec2 q = vec2(a * 6.0, vWb.y * 2.2);
      float ridge = smoothstep(0.35, 0.75, fbm(vec2(q.x * 3.0, q.y * 0.6)));
      vec3 c = mix(vec3(0.24, 0.17, 0.11), vec3(0.47, 0.37, 0.27), ridge) * (0.8 + 0.4 * fbm(q * 4.0));
      diffuseColor.rgb *= c * ${dark.toFixed(2)};`);
  };
  return m;
}
// the hero trunk: vertical cylinder with its surface at x = 0 near the bird, a peck hole that deepens
export function trunk(scene) {
  const g = new THREE.Group(); scene.add(g);
  const r = 0.32;
  const t = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.1, 12, 48), barkMaterial()); t.position.set(-r, 3, 0); t.castShadow = t.receiveShadow = true; g.add(t);
  const hole = new THREE.Mesh(new THREE.CircleGeometry(0.018, 20), new THREE.MeshStandardMaterial({ color: 0x1b120a, roughness: 1 }));
  hole.rotation.y = Math.PI / 2; hole.position.set(0.004, 0.03, 0); g.add(hole);
  const rim = new THREE.Mesh(new THREE.RingGeometry(0.018, 0.03, 20), new THREE.MeshStandardMaterial({ color: 0xc89a62, roughness: 1 })); rim.rotation.y = Math.PI / 2; rim.position.set(0.003, 0.03, 0); g.add(rim);
  return { group: g, hole, rim, setHole: (k) => { hole.scale.setScalar(0.4 + 0.8 * k); rim.scale.setScalar(0.4 + 0.8 * k); } };
}

// wood chips burst at a point; .burst(t, t0) shows chips flying for 0.5 s after t0
export function chips(scene, { n = 24, at = [0.01, 0.03, 0] } = {}) {
  const R = rng(9); const m = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 0.3, 0.6), new THREE.MeshStandardMaterial({ color: 0xd8b07a, roughness: 0.9 }), n); m.frustumCulled = false; scene.add(m);
  const seeds = []; for (let i = 0; i < n; i++) seeds.push([0.3 + R() * 0.6, (R() - 0.3) * 0.8, (R() - 0.5) * 0.9, 0.004 + R() * 0.006, R() * 6]);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), s = new THREE.Vector3(), e = new THREE.Euler();
  const update = (ages) => { // ages: array of times since recent pecks (seconds)
    for (let i = 0; i < n; i++) {
      const age = ages[i % ages.length]; const [vx, vy, vz, sz, ph] = seeds[i];
      if (age < 0 || age > 0.6) { m4.makeScale(0, 0, 0); m.setMatrixAt(i, m4); continue; }
      v.set(at[0] + vx * age, at[1] + vy * age - 2.5 * age * age, at[2] + vz * age); e.set(age * 20 + ph, ph, age * 14); q.setFromEuler(e);
      s.setScalar(sz * (1 - age / 0.6 * 0.3)); m4.compose(v, q, s); m.setMatrixAt(i, m4);
    }
    m.instanceMatrix.needsUpdate = true;
  };
  update([-1]);
  return { mesh: m, update };
}

// ---------------- woodpecker ----------------
// pivot at the neck; .set({ peck 0..1 (1 = beak on the wood), xray 0..1, jelly 0..1, helmet 0..1 })
export function woodpecker() {
  const G = new THREE.Group();
  const black = new THREE.MeshStandardMaterial({ color: 0x1b1c20, roughness: 0.55 });
  const white = new THREE.MeshStandardMaterial({ color: 0xf2f0ea, roughness: 0.7 });
  const red = new THREE.MeshStandardMaterial({ color: 0xd8262b, roughness: 0.5 });
  const xr = { value: 0 };
  const headSkin = new THREE.MeshStandardMaterial({ color: 0xf2f0ea, roughness: 0.6, transparent: true });
  const headBlack = new THREE.MeshStandardMaterial({ color: 0x1b1c20, roughness: 0.55, transparent: true });
  const headRed = new THREE.MeshStandardMaterial({ color: 0xd8262b, roughness: 0.5, transparent: true });
  // body: upright, belly facing +x is NOT the case; the bird clings with its belly toward the trunk (-x), back toward +x
  const body = new THREE.Group(); G.add(body);
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.05, 28, 20), black); torso.scale.set(0.9, 1.7, 1.0); torso.position.set(0.035, -0.07, 0); torso.castShadow = true; body.add(torso);
  const chest = new THREE.Mesh(new THREE.SphereGeometry(0.045, 24, 16), white); chest.scale.set(0.7, 1.5, 0.9); chest.position.set(0.012, -0.065, 0); body.add(chest);
  const vent = new THREE.Mesh(new THREE.SphereGeometry(0.02, 16, 12), red); vent.position.set(0.02, -0.14, 0); body.add(vent);
  // wings folded on the back with white bars
  [-1, 1].forEach((s) => {
    const w = new THREE.Mesh(new THREE.SphereGeometry(0.045, 20, 14), black); w.scale.set(0.5, 1.7, 0.45); w.position.set(0.05, -0.08, s * 0.035); w.rotation.z = -0.15; body.add(w);
    for (let k = 0; k < 4; k++) { const bar = new THREE.Mesh(new THREE.BoxGeometry(0.01, 0.006, 0.02), white); bar.position.set(0.072, -0.04 - k * 0.025, s * 0.04); body.add(bar); }
    const shoulder = new THREE.Mesh(new THREE.SphereGeometry(0.018, 14, 10), white); shoulder.scale.set(0.5, 1.6, 0.6); shoulder.position.set(0.065, -0.03, s * 0.036); body.add(shoulder);
  });
  // stiff tail propped against the trunk
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.11, 4), black); tail.position.set(0.012, -0.2, 0); tail.rotation.z = -0.25; tail.scale.z = 0.4; body.add(tail);
  // feet gripping the bark
  const footM = new THREE.MeshStandardMaterial({ color: 0x5b5e66, roughness: 0.6 });
  [-1, 1].forEach((s) => { for (let k = 0; k < 2; k++) { const toe = new THREE.Mesh(new THREE.CapsuleGeometry(0.004, 0.022, 3, 6), footM); toe.position.set(0.003, -0.11 + k * 0.02 * (k ? 1 : -1), s * 0.02); toe.rotation.z = k ? 0.6 : -0.6; body.add(toe); } });
  // neck pivot and head
  const neck = new THREE.Group(); neck.position.set(0.03, 0.0, 0); G.add(neck);
  const head = new THREE.Group(); head.position.set(0.0, 0.035, 0); neck.add(head);
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.034, 28, 20), headBlack); skull.scale.set(1.1, 1.0, 0.95); head.add(skull);
  const cheek = new THREE.Mesh(new THREE.SphereGeometry(0.028, 24, 16), headSkin); cheek.scale.set(0.95, 0.62, 1.2); cheek.position.set(-0.002, -0.009, 0); head.add(cheek);
  const cap = new THREE.Mesh(new THREE.SphereGeometry(0.03, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2.3), headRed); cap.position.set(0.012, 0.012, 0); cap.rotation.z = 0.5; cap.scale.set(1, 0.7, 0.9); head.add(cap);
  const beakM = new THREE.MeshStandardMaterial({ color: 0x3a3a3e, roughness: 0.35, metalness: 0.2 });
  const beak = new THREE.Mesh(new THREE.ConeGeometry(0.011, 0.055, 4), beakM); beak.rotation.z = Math.PI / 2; beak.position.set(-0.055, -0.002, 0); beak.scale.set(1, 1, 0.8); head.add(beak);
  const eyes = [];
  [-1, 1].forEach((s) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.007, 14, 10), new THREE.MeshStandardMaterial({ color: 0x120a06, roughness: 0.15 })); e.position.set(-0.016, 0.006, s * 0.029); head.add(e); eyes.push(e);
    const glint = new THREE.Mesh(new THREE.SphereGeometry(0.0022, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff })); glint.position.set(-0.003, 0.003, s * 0.006); e.add(glint); });
  // x-ray insides: bone skull shell and a small pink brain
  const boneM = new THREE.MeshStandardMaterial({ color: 0xf3ead6, roughness: 0.5, emissive: 0x403a30, emissiveIntensity: 0.4, transparent: true, opacity: 0.85 });
  const bone = new THREE.Mesh(new THREE.SphereGeometry(0.026, 24, 16), boneM); bone.scale.set(1.1, 0.95, 0.9); head.add(bone);
  const beakBone = new THREE.Mesh(new THREE.ConeGeometry(0.009, 0.05, 6), boneM); beakBone.rotation.z = Math.PI / 2; beakBone.position.set(-0.05, -0.002, 0); head.add(beakBone);
  const brainM = new THREE.MeshStandardMaterial({ color: 0xf08aa0, roughness: 0.5, emissive: 0xff4060, emissiveIntensity: 0.2 });
  const brain = new THREE.Mesh(new THREE.SphereGeometry(0.014, 20, 14), brainM); brain.scale.set(1.2, 0.9, 1); brain.position.set(0.004, 0.004, 0); head.add(brain);
  // cartoon "shock absorber" spring between beak and skull (the old idea)
  const spring = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(Array.from({ length: 60 }, (_, k) => { const a = k / 59 * Math.PI * 12; return new THREE.Vector3(-0.03 + k / 59 * 0.024, Math.cos(a) * 0.011, Math.sin(a) * 0.011); })), 200, 0.0022, 6), new THREE.MeshStandardMaterial({ color: 0xffc23a, metalness: 0.8, roughness: 0.3, emissive: 0x805a10, emissiveIntensity: 0.4 }));
  head.add(spring);
  // helmet for the closer
  const helmet = new THREE.Group(); head.add(helmet);
  const hm = new THREE.Mesh(new THREE.SphereGeometry(0.04, 28, 14, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xffd21a, roughness: 0.35, metalness: 0.1 })); hm.position.y = 0.006; hm.scale.set(1.15, 1.0, 1.05); helmet.add(hm);
  const brim = new THREE.Mesh(new THREE.TorusGeometry(0.044, 0.004, 8, 32), hm.material); brim.rotation.x = Math.PI / 2; brim.position.y = 0.006; helmet.add(brim);
  const strap = new THREE.Mesh(new THREE.TorusGeometry(0.03, 0.002, 6, 24, Math.PI), new THREE.MeshStandardMaterial({ color: 0x222222 })); strap.rotation.set(0, Math.PI / 2, Math.PI); strap.position.y = 0.0; helmet.add(strap);
  const st = { peck: 0, xray: 0, jelly: 0, helmet: 0, spring: 0, squish: 0, seeBrain: 0 };
  function update() {
    // peck: rotate the neck so the beak tip moves toward -x into the bark
    neck.rotation.z = THREE.MathUtils.lerp(-0.25, 0.32, st.peck);
    head.position.x = -0.012 * st.peck;
    const xa = st.xray;
    [headSkin, headBlack, headRed].forEach((m) => { m.opacity = 1 - 0.82 * xa; m.depthWrite = xa < 0.5; });
    bone.visible = beakBone.visible = brain.visible = xa > 0.02; boneM.opacity = (st.spring > 0.01 || st.seeBrain ? 0.32 : 0.85) * xa; brainM.emissiveIntensity = st.seeBrain ? 0.6 : 0.2; brainM.opacity = xa; brainM.transparent = true;
    spring.visible = st.spring > 0.01; spring.scale.setScalar(Math.max(0.001, st.spring)); spring.scale.x = Math.max(0.001, st.spring) * (1 - 0.5 * st.squish);
    // jelly head: squashes along x on impact and wobbles
    skull.scale.set(1.1 * (1 - 0.45 * st.jelly * st.squish), 1.0 * (1 + 0.25 * st.jelly * st.squish), 0.95 * (1 + 0.2 * st.jelly * st.squish));
    cheek.scale.set(0.95 * (1 - 0.45 * st.jelly * st.squish), 0.62 * (1 + 0.25 * st.jelly * st.squish), 1.2);
    helmet.visible = st.helmet > 0.01; helmet.position.y = 0.006 + (1 - st.helmet) * 0.12; helmet.rotation.z = (1 - st.helmet) * 0.6;
  }
  update();
  return { group: G, head, neck, beak, brain, st, update };
}
// peck cycle: returns peck amount 0..1 at time t for a rate (pecks/s) with a sharp strike and slower pull back
export function peckCurve(t, rate) {
  const x = ((t * rate) % 1 + 1) % 1;
  return x < 0.35 ? Math.pow(x / 0.35, 2.2) : x < 0.45 ? 1 : 1 - (x - 0.45) / 0.55;
}
// time since the latest few strikes (for chip bursts)
export function strikeAges(t, rate, n = 4) { const a = []; const k = Math.floor(t * rate - 0.35); for (let i = 0; i < n; i++) a.push(t - (k - i + 0.35) / rate); return a; }

// ---------------- props ----------------
export function brainModel(radius, color = 0xf0a0b0) {
  const m = new THREE.MeshStandardMaterial({ color, roughness: 0.55, emissive: 0x401018, emissiveIntensity: 0.15 });
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vOb;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvOb = position;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vOb;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float n = fbm(vOb.xy * ${(8 / radius).toFixed(2)} + vOb.z * ${(5 / radius).toFixed(2)}); float fold = smoothstep(0.02, 0.0, abs(n - 0.5) - 0.0);
      diffuseColor.rgb *= 1.0 - 0.35 * fold;`);
  };
  const g = new THREE.Group();
  [-1, 1].forEach((s) => { const h = new THREE.Mesh(new THREE.SphereGeometry(radius, 48, 32), m); h.scale.set(1.25, 0.85, 0.55); h.position.z = s * radius * 0.5; h.castShadow = true; g.add(h); });
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.15, radius * 0.1, radius * 0.6, 12), m); stem.position.set(radius * 0.25, -radius * 0.7, 0); g.add(stem);
  return g;
}
export function gauge() {
  const g = new THREE.Group();
  const face = new THREE.Mesh(new THREE.CircleGeometry(0.5, 64), new THREE.MeshStandardMaterial({ color: 0xf6f4ee, roughness: 0.5 })); g.add(face);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.035, 12, 64), new THREE.MeshStandardMaterial({ color: 0x2b2e33, metalness: 0.6, roughness: 0.3 })); g.add(rim);
  const zones = [[0x3fbf5a, 0, 0.55], [0xf2c14e, 0.55, 0.75], [0xe0402f, 0.75, 1.0]];
  const toA = (k) => Math.PI * (1.25 - 1.5 * k);
  zones.forEach(([c, a, b]) => { const r = new THREE.Mesh(new THREE.RingGeometry(0.33, 0.44, 48, 1, toA(b), toA(a) - toA(b)), new THREE.MeshStandardMaterial({ color: c, roughness: 0.5 })); r.position.z = 0.002; g.add(r); });
  const needle = new THREE.Group(); needle.position.z = 0.01; g.add(needle);
  const nd = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.025, 0.01), new THREE.MeshStandardMaterial({ color: 0x1b1b1b })); nd.position.x = 0.21; needle.add(nd);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.03, 24), nd.material); hub.rotation.x = Math.PI / 2; needle.add(hub);
  return { group: g, set: (k) => { needle.rotation.z = toA(k); } };
}
export function crashCar() {
  const g = new THREE.Group();
  const paint = new THREE.MeshStandardMaterial({ color: 0x2f7fd8, roughness: 0.3, metalness: 0.4 });
  const body = new THREE.Mesh(new RoundedBoxGeometry(2.2, 0.55, 1.1, 3, 0.12), paint); body.position.y = 0.55; body.castShadow = true; g.add(body);
  const cab = new THREE.Mesh(new RoundedBoxGeometry(1.1, 0.45, 1.0, 3, 0.12), new THREE.MeshStandardMaterial({ color: 0xbfe0ff, roughness: 0.1, metalness: 0.2 })); cab.position.set(-0.15, 1.0, 0); g.add(cab);
  const wM = new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.8 });
  [[0.7, 0.55], [-0.7, 0.55], [0.7, -0.55], [-0.7, -0.55]].forEach(([x, z]) => { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.27, 0.18, 20), wM); w.rotation.x = Math.PI / 2; w.position.set(x, 0.27, z); g.add(w); });
  // crash dummy in the driver seat
  const dummy = new THREE.Group(); const dm = new THREE.MeshStandardMaterial({ color: 0xf2c94c, roughness: 0.5 });
  const dh = new THREE.Mesh(new THREE.SphereGeometry(0.13, 16, 12), dm); dh.position.set(-0.1, 1.15, 0.2); dummy.add(dh);
  g.add(dummy);
  return { group: g, body, dummyHead: dh };
}
export function hiSpeedCam() {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0x2a2d33, roughness: 0.4, metalness: 0.5 });
  const box = new THREE.Mesh(new RoundedBoxGeometry(0.3, 0.2, 0.2, 2, 0.02), m); g.add(box);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.16, 24), m); lens.rotation.z = Math.PI / 2; lens.position.x = -0.22; g.add(lens);
  const glass = new THREE.Mesh(new THREE.CircleGeometry(0.05, 24), new THREE.MeshStandardMaterial({ color: 0x223355, roughness: 0.05, metalness: 0.9 })); glass.rotation.y = -Math.PI / 2; glass.position.x = -0.301; g.add(glass);
  const rec = new THREE.Mesh(new THREE.SphereGeometry(0.015, 12, 8), new THREE.MeshStandardMaterial({ color: 0xff2020, emissive: 0xff0000, emissiveIntensity: 1.5 })); rec.position.set(0.1, 0.11, 0.05); g.add(rec);
  [0, 2.1, 4.2].forEach((a) => { const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1.4, 8), m); leg.position.set(Math.cos(a) * 0.25, -0.75, Math.sin(a) * 0.25); leg.rotation.set(Math.sin(a) * 0.18, 0, -Math.cos(a) * 0.18); g.add(leg); });
  return { group: g, rec };
}
