// The Explainer: how a hot air balloon flies. Balloon (envelope ~ 16 tall, basket below at y=0), burner flame,
// top vent, see-through mode with inside/outside air particles, molecule box, balance, wind layers.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.6, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
export const ENV_BOTTOM = 4.2, ENV_H = 15, ENV_R = 7.2;
function envProfile(v) { // v 0 (mouth) .. 1 (crown) -> radius
  if (v < 0.12) return 1.0 + (v / 0.12) * 1.4;
  const u = (v - 0.12) / 0.88; return 2.4 + (ENV_R - 2.4) * Math.sin(Math.min(1, u * 1.25) * Math.PI / 2) * (u > 0.8 ? Math.sqrt(Math.max(0, 1 - Math.pow((u - 0.8) / 0.2, 2) * 0.82)) : 1);
}
export function balloon() {
  const G = new THREE.Group();
  const pts = []; for (let i = 0; i <= 40; i++) { const v = i / 40; pts.push(new THREE.Vector2(Math.max(0.01, envProfile(v)), ENV_BOTTOM + v * ENV_H)); }
  pts.push(new THREE.Vector2(0.01, ENV_BOTTOM + ENV_H));
  const geo = new THREE.LatheGeometry(pts, 48); const pa = geo.attributes.position; const col = []; const c = new THREE.Color(); const cols = [0xe8402a, 0xf2c21a, 0x2a7ae0, 0xf2f2f2];
  for (let i = 0; i < pa.count; i++) { const a = Math.atan2(pa.getZ(i), pa.getX(i)); const g = Math.floor(((a + Math.PI) / (Math.PI * 2)) * 16) % 4; c.set(cols[g]); col.push(c.r, c.g, c.b); }
  geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  const envM = new THREE.MeshStandardMaterial({ color: 0xffffff, vertexColors: true, roughness: 0.55, side: THREE.DoubleSide, transparent: true, opacity: 1, emissive: 0xff7a20, emissiveIntensity: 0 });
  const env = new THREE.Mesh(geo, envM); G.add(env);
  const vent = new THREE.Mesh(new THREE.CircleGeometry(1.6, 32), std(0xe8402a, 0.5, 0, { side: THREE.DoubleSide })); vent.rotation.x = -Math.PI / 2; vent.position.y = ENV_BOTTOM + ENV_H - 0.05; G.add(vent);
  // basket, cables, burner
  const basket = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.1, 1.4), std(0x9a6a3a, 0.9)); basket.position.y = 0.55; G.add(basket);
  const rim = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.12, 1.5), std(0x6a4422, 0.8)); rim.position.y = 1.12; G.add(rim);
  [[-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7], [0.7, 0.7]].forEach(([x, z]) => { const a = new THREE.Vector3(x, 1.1, z), b = new THREE.Vector3(x * 1.45, ENV_BOTTOM + 0.1, z * 1.45); const d = b.clone().sub(a); const cb = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, d.length(), 6), std(0x333333)); cb.position.copy(a).addScaledVector(d, 0.5); cb.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); G.add(cb); });
  const burner = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.3, 0.4, 16), std(0xb8c0c8, 0.3, 0.9)); burner.position.y = 2.4; G.add(burner);
  // people
  [[-0.3, 0.2], [0.3, -0.2], [0.25, 0.35]].forEach(([x, z], i) => { const h = new THREE.Mesh(new THREE.SphereGeometry(0.17, 14, 10), std([0xe8c0a0, 0xc89070, 0xf0d0b0][i])); h.position.set(x, 1.45, z); G.add(h); const b = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.2, 0.4, 12), std([0x2a6ae0, 0xe0402a, 0x3aa04a][i])); b.position.set(x, 1.15, z); G.add(b); });
  // flame
  const flameM = new THREE.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0.9, toneMapped: false, blending: THREE.AdditiveBlending, depthWrite: false });
  const flame = new THREE.Mesh(new THREE.ConeGeometry(0.35, 2.2, 16, 1, true), flameM); flame.position.y = 2.6 + 1.1; G.add(flame);
  const core = new THREE.Mesh(new THREE.ConeGeometry(0.15, 1.4, 12, 1, true), new THREE.MeshBasicMaterial({ color: 0xbfe0ff, transparent: true, opacity: 0.9, toneMapped: false, blending: THREE.AdditiveBlending, depthWrite: false })); core.position.y = 2.6 + 0.7; G.add(core);
  const glow = new THREE.PointLight(0xff9a40, 0, 20); glow.position.y = 3.5; G.add(glow);
  const st = { burn: 0, xray: 0, vent: 0, heat: 0 };
  function update(T) {
    const f = st.burn * (0.85 + 0.15 * Math.sin(T * 40)); flame.scale.set(1, Math.max(0.001, f), 1); flame.visible = core.visible = f > 0.02; core.scale.set(1, Math.max(0.001, f), 1); glow.intensity = 60 * f;
    envM.opacity = 1 - 0.72 * st.xray; envM.depthWrite = st.xray < 0.3; envM.emissiveIntensity = 0.25 * st.burn + 0.15 * st.heat;
    vent.position.y = ENV_BOTTOM + ENV_H - 0.05 - 1.2 * st.vent; vent.scale.setScalar(1 - 0.15 * st.vent);
  }
  update(0);
  return { group: G, st, update };
}
// air particles inside (hot, orange, fast, sparse) and around (cold, blue, slow, dense) the envelope
export function airDots(seed = 3) {
  const R = rnd(seed); const nIn = 160, nOut = 420;
  const mk = (n, c) => { const im = new THREE.InstancedMesh(new THREE.SphereGeometry(0.11, 8, 6), new THREE.MeshBasicMaterial({ color: c, toneMapped: false }), n); im.frustumCulled = false; return im; };
  const inside = mk(nIn, 0xff8a3a), outside = mk(nOut, 0x6ab8ff);
  const PI = []; for (let i = 0; i < nIn; i++) PI.push([R(), R(), R(), R() * 6]);
  const PO = []; for (let i = 0; i < nOut; i++) { let x, y, z; do { x = (R() - 0.5) * 22; y = R() * 24; z = (R() - 0.5) * 14; } while (Math.hypot(x, z) < envProfile(Math.min(1, Math.max(0, (y - ENV_BOTTOM) / ENV_H))) + 0.6 && y > ENV_BOTTOM && y < ENV_BOTTOM + ENV_H + 0.5); PO.push([x, y, z, R() * 6]); }
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  function update(T, k, escape = 0) {
    PI.forEach(([a, b, cc, ph], i) => { const v = 0.08 + b * 0.84; const r = envProfile(v) * 0.85 * Math.sqrt(cc); const ang = a * Math.PI * 2 + T * 0.8; let y = ENV_BOTTOM + v * ENV_H + Math.sin(T * 6 + ph) * 0.3; let x = Math.cos(ang) * r, z = Math.sin(ang) * r;
      if (escape > 0 && i % 3 === 0) { const u = ((ph / 6 + T * 0.4) % 1) * escape; y = ENV_BOTTOM + ENV_H * 0.95 + u * 6; x *= 0.2; z *= 0.2; }
      M.compose(new THREE.Vector3(x, y, z), q, s.setScalar(k > 0.01 ? k : 0.0001)); inside.setMatrixAt(i, M); });
    PO.forEach(([x, y, z, ph], i) => { M.compose(new THREE.Vector3(x + Math.sin(T * 1.5 + ph) * 0.12, y + Math.cos(T * 1.3 + ph) * 0.12, z), q, s.setScalar(k > 0.01 ? k : 0.0001)); outside.setMatrixAt(i, M); });
    inside.instanceMatrix.needsUpdate = outside.instanceMatrix.needsUpdate = true;
  }
  update(0, 0);
  return { inside, outside, update };
}
// a glass box of air molecules; heat 0..1 speeds them up and spreads them (some leave through the open top)
export function moleculeBox(n = 70, seed = 9) {
  const G = new THREE.Group();
  const box = new THREE.Mesh(new THREE.BoxGeometry(3, 3, 3), new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transmission: 0.9, transparent: true, opacity: 0.25, side: THREE.DoubleSide, depthWrite: false })); G.add(box);
  const edges = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(3, 3, 3)), new THREE.LineBasicMaterial({ color: 0xcfe6ff })); G.add(edges);
  const plate = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.2, 3.2), std(0x3a3a3a, 0.5, 0.5, { emissive: 0xff3a00, emissiveIntensity: 0 })); plate.position.y = -1.65; G.add(plate);
  const R = rnd(seed); const P = []; for (let i = 0; i < n; i++) P.push([R(), R(), R(), R(), R(), R()]);
  const cold = new THREE.Color(0x6ab8ff), hot = new THREE.Color(0xff7a3a);
  const im = new THREE.InstancedMesh(new THREE.SphereGeometry(0.1, 10, 8), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 }), n); G.add(im);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(1, 1, 1), c = new THREE.Color();
  const tri = (x) => { const f = ((x % 2) + 2) % 2; return f < 1 ? f : 2 - f; };
  function update(T, heat) {
    plate.material.emissiveIntensity = 1.2 * heat; const sp = 0.3 + 1.6 * heat;
    P.forEach(([a, b, cc, va, vb, vc], i) => { const leave = heat > 0.4 && i % 3 === 0; let x = (tri(a * 2 + T * sp * (0.5 + va)) - 0.5) * 2.7, y = (tri(b * 2 + T * sp * (0.5 + vb)) - 0.5) * 2.7, z = (tri(cc * 2 + T * sp * (0.5 + vc)) - 0.5) * 2.7;
      if (leave) { const u = Math.min(1, (heat - 0.4) / 0.6); y = lerp1(y, 1.5 + 2.5 * u + ((a + T * 0.3) % 1), u); }
      M.compose(new THREE.Vector3(x, y, z), q, s); im.setMatrixAt(i, M); im.setColorAt(i, c.copy(cold).lerp(hot, heat)); });
    im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
  }
  const lerp1 = (a, b, t) => a + (b - a) * t;
  update(0, 0);
  return { group: G, update };
}
// a balance with two equal boxes: cold (left) and hot (right); tilt k: hot side rises
export function balance() {
  const G = new THREE.Group();
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.2, 3, 12), std(0x8a8a90, 0.4, 0.8)); post.position.y = 1.5; G.add(post);
  const beam = new THREE.Group(); beam.position.y = 3.05; G.add(beam);
  const bar = new THREE.Mesh(new THREE.BoxGeometry(5, 0.12, 0.2), std(0xc0a040, 0.3, 0.9)); beam.add(bar);
  const mkBox = (c) => { const b = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.4, 1.4), new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.1, transmission: 0.6, transparent: true, opacity: 0.5 })); return b; };
  const L = mkBox(0x6ab8ff), Rr = mkBox(0xff8a3a); G.add(L, Rr);
  const R = rnd(4); const dots = (box, n, c) => { for (let i = 0; i < n; i++) { const d = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), new THREE.MeshBasicMaterial({ color: c })); d.position.set((R() - 0.5) * 1.2, (R() - 0.5) * 1.2, (R() - 0.5) * 1.2); box.add(d); } };
  dots(L, 40, 0x2a7ae0); dots(Rr, 22, 0xe0602a);
  function set(k) { beam.rotation.z = -0.22 * k; [[L, -2.2], [Rr, 2.2]].forEach(([b, x]) => { const p = new THREE.Vector3(x, 0, 0).applyAxisAngle(new THREE.Vector3(0, 0, 1), beam.rotation.z); b.position.set(p.x, 3.05 + p.y - 0.85, 0); }); }
  set(0);
  return { group: G, set };
}
// wind layers: streams of moving streaks at different heights and directions
export function windLayers() {
  const G = new THREE.Group(); const layers = [{ y: 6, dir: -1, c: 0x9ad8ff }, { y: 18, dir: 1, c: 0xffe08a }, { y: 30, dir: -1, c: 0xc8a8ff }]; const R = rnd(13); const all = [];
  layers.forEach(L => { const m = new THREE.MeshBasicMaterial({ color: L.c, transparent: true, opacity: 0, toneMapped: false, depthWrite: false }); for (let i = 0; i < 40; i++) { const s = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.28, 0.28), m); G.add(s); all.push({ s, L, x: R(), dy: (R() - 0.5) * 3, z: (R() - 0.5) * 20, m }); } L.m = m; });
  // arrow heads per layer
  return { group: G, layers, update(T, k) { all.forEach(({ s, L, x, dy, z }) => { const u = ((x + T * 0.12) % 1); s.position.set(L.dir * (u - 0.5) * 70, L.y + dy, z); }); layers.forEach(L => { L.m.opacity = 0.8 * k; }); } };
}
export { std };
