// The Explainer: how a scab forms. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { WD, scabScene } from './scab.js';
import { VO } from './vo_sc.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['The moment', 2], ['you *cut* yourself', 3], ['your blood starts', 3], ['*knitting a net*', 3]],
  [['First', 1], ['blood vessels', 2], ['near the cut', 3], ['*squeeze tight*', 2], ['to slow', 2], ['the *bleeding*', 2]],
  [['Then *platelets*', 2], ['*tiny bits*', 2], ['of cells', 2], ['*rush in*', 2], ['and *stick*', 2], ['to the wound', 3]],
  [['They *grab*', 2], ['onto each other', 3], ['piling up', 2], ['into a', 2], ['*soft plug*', 2]],
  [['They also', 2], ['send out *signals*', 3], ['that turn', 2], ['a *protein*', 2], ['in your blood', 3], ['into long', 2], ['*sticky threads*', 2], ['called *fibrin*', 2]],
  [['The threads', 2], ['weave a *mesh*', 3], ['that *traps*', 2], ['*red blood cells*', 3], ['like fish', 2], ['in a *net*', 3]],
  [["That's a *clot*", 3], ['As it *dries*', 3], ['in the air', 3], ['it *hardens*', 2], ['into a *scab*', 3]],
  [['Underneath', 1], ['*white blood cells*', 3], ['fight *germs*', 2], ['and *new skin*', 3], ['grows in', 2], ['from the *edges*', 3]],
  [['When the', 2], ['*new skin*', 2], ['is ready', 2], ['the scab', 2], ['*falls off*', 2], ['by itself', 2]],
  [['So try not', 3], ['to *pick* it', 3], ["It's a *bandage*", 3], ['your body *built*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.01; c.far = 200; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.45, warm: 1.05, sat: 1.25, exposure: 0.9, ao: 0.6 };
function lab(makeStage) {
  const scene = makeStage({ shadowSize: 8, sunDir: [3, 8, 6] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x3a1a2a); u.mid.value.set(0x2a1220); u.horizon.value.set(0x2a1220); u.floorC.value.set(0x160810); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xffe8f0, 0x401020, 0.45));
  const fill = new THREE.PointLight(0xffd0d8, 9, 30); fill.position.set(-3, 3, 8); scene.add(fill);
  const K = scabScene(scene);
  return { scene, K };
}
// shared state curve over the whole film (global time T), so every shot shows the right stage
function stage(K, T) {
  const s = K.st;
  s.flow = 1;
  s.constrict = smooth(range(T, ls(1) + 0.8, ls(2)));
  s.platelets = smooth(range(T, ls(2) + 0.2, ls(3)));
  s.plug = smooth(range(T, ls(3) + 0.2, ls(4)));
  s.signal = smooth(range(T, ls(4), ls(4) + 1.5)) * (1 - smooth(range(T, ls(5), ls(5) + 1)));
  s.fibrin = smooth(range(T, at(4, 'sticky') - 1.2, ls(5) + 1.5));
  s.trapped = smooth(range(T, at(5, 'traps') - 0.4, at(5, 'net')));
  s.dry = smooth(range(T, at(6, 'dries') - 0.3, at(6, 'scab')));
  s.wbc = smooth(range(T, ls(7), at(7, 'new')));
  s.grow = smooth(range(T, at(7, 'new') - 0.2, ls(8) + 2.2));
  s.fall = easeIn(range(T, at(8, 'falls') - 0.2, at(8, 'falls') + 1.4));
}

// ============ S0 hook: the cut bleeds and a net of threads zips across it in fast forward ============
function sHook({ makeStage }) {
  const { scene, K } = lab(makeStage);
  const c = C(40);
  return {
    scene, camera: c,
    update(t) {
      const s = K.st; s.flow = 1.4; s.constrict = 0; s.platelets = smooth(range(t, 0.0, 1.6)); s.plug = 0; s.signal = 0;
      s.fibrin = smooth(range(t, 0.3, 3.2)); s.trapped = smooth(range(t, 1.6, 3.4)); s.dry = 0; s.wbc = 0; s.grow = 0; s.fall = 0;
      K.update(t);
      const k = easeInOut(range(t, 0, 3.6));
      orb(c, [0, -WD * 0.5, 0], lerp(9, 13, k), lerp(14, 26, k), lerp(22, 14, k));
      return POST;
    },
  };
}
// a generic shot: global stage curves, camera keyframes
function shot(cam0, cam1, extra) {
  return ({ makeStage }) => {
    const { scene, K } = lab(makeStage);
    const c = C(40);
    return {
      scene, camera: c,
      update(t, T) {
        stage(K, T); if (extra) extra(K, t, T); K.update(T);
        const k = easeInOut(range(t, 0, 4));
        orb(c, cam0.tg.map((v, i) => lerp(v, cam1.tg[i], k)), 2.0 * lerp(cam0.d, cam1.d, k), lerp(cam0.az, cam1.az, k), lerp(cam0.el, cam1.el, k));
        return POST;
      },
    };
  };
}
const sVessel = shot({ tg: [0, -WD - 0.3, 2.6], d: 4.5, az: 35, el: 10 }, { tg: [0, -WD - 0.3, 2.6], d: 3.8, az: 25, el: 14 });
const sPlatelets = shot({ tg: [0, -WD * 0.6, 0], d: 6.0, az: 20, el: 10 }, { tg: [0, -WD * 0.5, 0.5], d: 5.0, az: 30, el: 14 });
const sPlug = shot({ tg: [0, -0.5, 0], d: 4.4, az: 15, el: 30 }, { tg: [0, -0.6, 0], d: 3.8, az: 25, el: 34 });
const sFibrin = shot({ tg: [0, -WD * 0.5, 0], d: 5.4, az: 10, el: 6 }, { tg: [0, -WD * 0.5, 0], d: 4.6, az: 32, el: 10 });
const sMesh = shot({ tg: [0, -WD * 0.55, 0.5], d: 3.6, az: 5, el: 4 }, { tg: [0, -WD * 0.55, 0.5], d: 3.0, az: 20, el: 6 });
const sScab = shot({ tg: [0, -0.4, 0], d: 6.5, az: 25, el: 40 }, { tg: [0, -0.3, 0], d: 6.0, az: 15, el: 22 });
const sRepair = shot({ tg: [0, -1.0, 0], d: 5.4, az: 10, el: 6 }, { tg: [0, -0.8, 0], d: 4.8, az: 22, el: 10 });
const sFall = shot({ tg: [0.5, -0.2, 0], d: 6.4, az: 20, el: 16 }, { tg: [1.0, 0.4, 0], d: 7.4, az: 25, el: 20 });
const sEnd = shot({ tg: [1.6, 0.6, 0], d: 9.0, az: 30, el: 26 }, { tg: [0.8, 0.0, 0], d: 11.0, az: 35, el: 30 });

// ============ timeline ============
const SH = [sHook, sVessel, sPlatelets, sPlug, sFibrin, sMesh, sScab, sRepair, sFall, sEnd];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
