// The Explainer: why woodpeckers don't get concussions. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { forest, trunk, chips, woodpecker, peckCurve, strikeAges, brainModel, gauge, crashCar, hiSpeedCam } from './peck.js';
import { VO } from './vo_wp.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *woodpecker*', 2], ['*slams* its head', 3], ['into wood', 2], ['up to', 2], ['*twenty times*', 2], ['a *second*', 2]],
  [['Each blow', 2], ['*stops* its head', 3], ['*faster* than', 2], ['a *car crash*', 3], ['would stop *yours*', 3]],
  [['For years', 2], ['people thought', 2], ['its *skull*', 2], ['worked like', 2], ['a built in', 3], ['*shock absorber*', 2]],
  [['But in', 2], ['*2022*', 3], ['scientists *filmed*', 2], ['woodpeckers', 1], ['in *slow motion*', 3], ['and found', 2], ['the *opposite*', 2]],
  [['The head barely', 3], ['*cushions* anything', 2], ['It hits like', 3], ['a *stiff hammer*', 3]],
  [['A *spongy* head', 3], ['would *waste*', 2], ['the blow', 2], ['and the beak', 3], ["wouldn't *dig in*", 3]],
  [['So why no', 3], ['*concussion?*', 1], ['The answer', 2], ['may be *size*', 3]],
  [["A woodpecker's", 2], ['*brain* is', 2], ['*tiny*', 1], ['and *light*', 2], ['so the forces', 3], ['inside it', 2], ['stay *small*', 2]],
  [['The team', 2], ['*calculated*', 1], ['that even', 2], ['the *hardest* pecks', 3], ['stay *below*', 2], ['the level', 2], ['that would', 2], ['*injure* its brain', 3]],
  [['Being *small*', 2], ['is its *helmet*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.005; c.far = 300; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.4, warm: 1.08, sat: 1.15, exposure: 1.0 };
const BX = 0.068, BY = 0.022; // bird position so the beak tip just reaches the bark (x = 0) at peck = 1
function wood(makeStage, { sun = [-0.4, 0.75, 0.6] } = {}) {
  const scene = makeStage({ outdoor: 'day', sunDir: sun, fog: 0.012, shadowSize: 1.2, shadowAt: [0, 0, 0], envI: 0.9, cloud: 0.25 });
  scene.userData.key.shadow.camera.near = 0.1; scene.userData.key.shadow.camera.far = 60;
  forest(scene); const T = trunk(scene);
  const W = woodpecker(); W.group.position.set(BX, BY, 0); scene.add(W.group);
  const Ch = chips(scene, { at: [0.012, 0.03, 0] });
  return { scene, T, W, Ch };
}
// drive pecking at `rate` per second from local time t
function drum(R, t, rate, amp = 1) { R.W.st.peck = peckCurve(t, rate) * amp; R.W.update(); R.Ch.update(amp > 0.5 ? strikeAges(t, rate) : [-1]); }

// ============ S0 hook: drumming on the trunk, chips flying ============
function sHook({ makeStage }) {
  const R = wood(makeStage);
  const c = C(34);
  return {
    scene: R.scene, camera: c,
    update(t) {
      drum(R, t, 10.5); R.T.setHole(smooth(range(t, 0, 4)));
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0.075, lerp(0.02, -0.03, k), 0], lerp(0.5, 0.8, k), lerp(8, 22, k), lerp(4, 8, k));
      return { ...POST, dof: { focus: 0.55, aperture: 0.0025, maxblur: 0.005 } };
    },
  };
}
// ============ S1: a car crash for comparison ============
function sCrash({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.5, 0.7, 0.6], fog: 0.004, shadowSize: 8, shadowAt: [0, 0, 0], envI: 0.9 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: 0x8c8f93, roughness: 0.9 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const wall = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.6, 3.2), new THREE.MeshStandardMaterial({ color: 0xb8b2a6, roughness: 0.9 })); wall.position.set(1.6, 0.8, 0); wall.castShadow = true; scene.add(wall);
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.2, 3.22), new THREE.MeshStandardMaterial({ color: 0xffd21a })); stripe.position.set(1.6, 1.2, 0); scene.add(stripe);
  const car = crashCar(); scene.add(car.group);
  const c = C(36);
  const TC = at(1, 'crash') - ls(1);
  return {
    scene, camera: c,
    update(t) {
      // drive in, hit the wall at TC, crumple, dummy head jolts
      const hitT = TC; const x = t < hitT ? lerp(-5, 0.0, t / hitT) : 0.0;
      const after = Math.max(0, t - hitT);
      car.group.position.x = x; car.body.scale.x = 1 - 0.12 * smooth(range(after, 0, 0.12));
      car.body.position.x = -0.13 * smooth(range(after, 0, 0.12));
      car.dummyHead.position.x = -0.1 + 0.18 * Math.exp(-after * 6) * Math.sin(Math.min(after * 20, Math.PI)) ;
      const shake = after > 0 ? 0.03 * Math.exp(-after * 8) * Math.sin(after * 80) : 0;
      orb(c, [0.2 + shake, 0.8, 0], lerp(12, 11, smooth(range(t, 0, 4))), 18, 10);
      return POST;
    },
  };
}
// ============ S2: the old idea: a built-in shock absorber (x-ray, spring squashing) ============
function sMyth({ makeStage }) {
  const R = wood(makeStage);
  const c = C(30);
  const TS = at(2, 'shock') - ls(2);
  return {
    scene: R.scene, camera: c,
    update(t) {
      R.W.st.xray = smooth(range(t, 0.2, 1.0)); R.W.st.spring = easeOut(range(t, TS - 0.6, TS));
      const p = peckCurve(t, 1.6); R.W.st.peck = p; R.W.st.squish = p > 0.95 ? 1 : 0;
      R.W.update(); R.Ch.update(strikeAges(t, 1.6, 2));
      orb(c, [0.065, 0.05, 0], 0.4, 10, 6);
      return POST;
    },
  };
}
// ============ S3: 2022: a high-speed camera films the bird ============
function sFilm({ makeStage }) {
  const R = wood(makeStage);
  const cm = hiSpeedCam(); cm.group.position.set(0.4, 0.06, -0.55); cm.group.rotation.y = 1.06; R.scene.add(cm.group);
  const c = C(38);
  const TS = at(3, 'slow') - ls(3);
  return {
    scene: R.scene, camera: c,
    update(t) {
      const slow = smooth(range(t, TS - 0.3, TS + 0.4));
      drum(R, t * lerp(1, 0.12, slow), 6);
      cm.rec.visible = Math.floor(t * 2) % 2 === 0;
      const k = easeInOut(range(t, 0, 6.1));
      orb(c, [lerp(0.2, 0.075, k), lerp(0.0, 0.03, k), lerp(-0.2, 0.0, k)], lerp(1.9, 0.5, k), lerp(25, 12, k), lerp(10, 4, k));
      return POST;
    },
  };
}
// ============ S4: no cushioning: stiff head, like a hammer (x-ray, slow strike) ============
function sHammer({ makeStage }) {
  const R = wood(makeStage);
  const hammer = new THREE.Group(); const hm = new THREE.MeshStandardMaterial({ color: 0x9aa3ad, metalness: 0.9, roughness: 0.3 });
  const hh = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.03, 0.03), hm); hammer.add(hh);
  const hd = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.007, 0.16, 12), new THREE.MeshStandardMaterial({ color: 0xa8743e, roughness: 0.6 })); hd.position.set(0.02, -0.08, 0); hammer.add(hd);
  hammer.position.set(0.06, 0.12, 0.06); R.scene.add(hammer);
  const c = C(30);
  const TH = at(4, 'hammer') - ls(4);
  return {
    scene: R.scene, camera: c,
    update(t) {
      R.W.st.xray = 1; R.W.st.spring = 0;
      const p = peckCurve(t * 0.35, 1.2); R.W.st.peck = p; R.W.update(); R.Ch.update(strikeAges(t * 0.35, 1.2, 2));
      const hk = smooth(range(t, TH - 0.6, TH)); hammer.visible = hk > 0.01; hammer.scale.setScalar(hk); hammer.rotation.z = 0.9 * (1 - peckCurve(t * 0.35 + 0.1, 1.2));
      orb(c, [0.07, 0.07, 0.02], 0.45, 12, 6);
      return POST;
    },
  };
}
// ============ S5: a spongy head would squash and the beak would not bite ============
function sJelly({ makeStage }) {
  const R = wood(makeStage);
  const c = C(30);
  return {
    scene: R.scene, camera: c,
    update(t) {
      R.W.st.jelly = 1; R.W.st.xray = 0;
      const p = peckCurve(t, 1.1); R.W.st.peck = Math.min(p, 0.82); // stops short: the head squashes instead
      R.W.st.squish = p > 0.8 ? Math.sin(Math.min(1, (p - 0.8) / 0.2) * Math.PI / 2) : 0;
      R.W.update(); R.Ch.update([-1]);
      R.W.head.rotation.z = 0.08 * Math.sin(t * 22) * R.W.st.squish;
      orb(c, [0.065, 0.04, 0], 0.42, 10, 6);
      return POST;
    },
  };
}
// ============ S6: why no concussion? zoom into the brain ============
function sWhy({ makeStage }) {
  const R = wood(makeStage);
  const c = C(30);
  return {
    scene: R.scene, camera: c,
    update(t) {
      R.W.st.peck = 0.1; R.W.st.seeBrain = 1; R.W.st.xray = smooth(range(t, 0.6, 1.4)); R.W.update(); R.Ch.update([-1]);
      const b = new THREE.Vector3(); R.W.brain.getWorldPosition(b);
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [b.x, b.y, b.z], lerp(0.5, 0.2, k), 4, 6);
      return { ...POST, bloom: 0.55 };
    },
  };
}
// ============ S7: a human brain next to a woodpecker brain ============
function sBrains({ makeStage }) {
  const scene = makeStage({ shadowSize: 0.6, sunDir: [1, 4, 3] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x24364a); u.mid.value.set(0x1a2838); u.horizon.value.set(0x1a2838); u.floorC.value.set(0x101820); }
  const table = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.02, 64), new THREE.MeshStandardMaterial({ color: 0xe8e4dc, roughness: 0.4 })); table.position.y = -0.01; table.receiveShadow = true; scene.add(table);
  const human = brainModel(0.075); human.position.set(-0.09, 0.065, 0); human.rotation.y = 0.3; scene.add(human);
  const bird = brainModel(0.0085, 0xf08aa0); bird.position.set(0.1, 0.0075, 0.03); scene.add(bird);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.025, 0.0015, 8, 48), new THREE.MeshBasicMaterial({ color: 0xffd21a })); ring.rotation.x = -Math.PI / 2; ring.position.set(0.1, 0.002, 0.03); scene.add(ring);
  const c = C(34);
  const TT = at(7, 'tiny') - ls(7);
  return {
    scene, camera: c,
    update(t) {
      const r = smooth(range(t, TT - 0.2, TT + 0.3)); ring.scale.setScalar(0.6 + 0.6 * r + 0.08 * Math.sin(t * 6)); ring.visible = r > 0.01;
      const k = easeInOut(range(t, 0, 5));
      orb(c, [lerp(-0.03, 0.02, k), 0.05, 0.0], lerp(1.15, 0.95, k), lerp(-10, 10, k), lerp(26, 32, k));
      return { ...POST, ao: 0.5 };
    },
  };
}
// ============ S8: the injury gauge stays in the green while it pecks ============
function sGauge({ makeStage }) {
  const R = wood(makeStage);
  const G = gauge(); G.group.scale.setScalar(0.08); G.group.position.set(0.09, 0.24, 0.03); G.group.rotation.y = 0.2; R.scene.add(G.group);
  const c = C(32);
  const TH = at(8, 'hardest') - ls(8);
  return {
    scene: R.scene, camera: c,
    update(t) {
      const rate = t < TH ? 3 : 6; const p = peckCurve(t, rate); R.W.st.peck = p; R.W.update(); R.Ch.update(strikeAges(t, rate));
      const hit = Math.max(0, strikeAges(t, rate, 1)[0]); const kick = Math.exp(-hit * 8);
      G.set(0.12 + (t < TH ? 0.25 : 0.38) * kick);
      orb(c, [0.08, 0.12, 0], 0.7, 12, 6);
      return POST;
    },
  };
}
// ============ S9: being small is its helmet ============
function sHelmet({ makeStage }) {
  const R = wood(makeStage);
  const c = C(32);
  const TH = at(9, 'helmet') - ls(9);
  return {
    scene: R.scene, camera: c,
    update(t) {
      R.W.st.helmet = easeOut(range(t, TH - 0.4, TH + 0.1));
      const p = t > TH + 0.8 ? peckCurve(t, 6) : 0.05; R.W.st.peck = p; R.W.update(); R.Ch.update(t > TH + 0.8 ? strikeAges(t, 6) : [-1]);
      const k = easeInOut(range(t, 0, 3.5));
      orb(c, [0.075, 0.04, 0], lerp(0.6, 0.45, k), lerp(10, 22, k), 6);
      return POST;
    },
  };
}

// ============ timeline ============
const SH = [sHook, sCrash, sMyth, sFilm, sHammer, sJelly, sWhy, sBrains, sGauge, sHelmet];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
