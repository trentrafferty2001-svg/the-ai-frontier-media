// Persian windcatcher (badgir) reel: mud house with a tall slatted wind tower (cut-away option showing the inner divider),
// airflow particles (cool in, warm out), basement pool + qanat channel, thermometer, Yazd skyline, Dowlat Abad tower,
// modern building with wind towers.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll } from './rome.js';
import { persiaMats } from './persia.js';
import { glowSprite } from './props.js';

// tower: w x w footprint, from y0 to y1, slatted openings near the top on all four sides (or `sides` count)
export function tower({ w = 1.6, y0 = 4, y1 = 12, oct = false } = {}) {
  const P = persiaMats(); const g = new THREE.Group();
  const shaftM = P.mud.clone(); shaftM.transparent = true;
  const h = y1 - y0;
  const shaft = new THREE.Mesh(oct ? new THREE.CylinderGeometry(w * 0.6, w * 0.65, h, 8) : new THREE.BoxGeometry(w, h, w), shaftM); shaft.position.y = y0 + h / 2; g.add(shaft);
  // cut-away version: back + side walls stay solid (the old see-through shaft left only a thin stick visible)
  const inner = new THREE.Group(); inner.visible = false; g.add(inner);
  const wt = 0.14;
  for (const [sx, sz, bx, bz] of [[0, -1, w, wt], [-1, 0, wt, w], [1, 0, wt, w]]) { const m = new THREE.Mesh(new THREE.BoxGeometry(bx, h, bz), P.mud); m.position.set(sx * (w - wt) / 2, y0 + h / 2, sz * (w - wt) / 2); inner.add(m); }
  const back = new THREE.Mesh(new THREE.PlaneGeometry(w - 2 * wt, h), new THREE.MeshStandardMaterial({ color: 0x5a3e26, roughness: 1 })); back.position.set(0, y0 + h / 2, -(w - wt) / 2 + wt / 2 + 0.01); inner.add(back); // shadowed inside face
  const dark = new THREE.MeshStandardMaterial({ color: 0x1a120a, roughness: 1 });
  const slats = new THREE.Group(); g.add(slats);
  const n = oct ? 8 : 4;
  for (let s = 0; s < n; s++) {
    const a = s / n * Math.PI * 2; const r = (oct ? w * 0.6 : w / 2) + 0.01;
    for (let k = 0; k < 3; k++) { const o = new THREE.Mesh(new THREE.PlaneGeometry(w * (oct ? 0.18 : 0.2), h * 0.16), dark); o.position.set(Math.sin(a) * r + Math.cos(a) * (k - 1) * w * (oct ? 0.0 : 0.28), y1 - h * 0.12, Math.cos(a) * r - Math.sin(a) * (k - 1) * w * (oct ? 0.0 : 0.28)); o.rotation.y = a; if (oct && k !== 1) continue; slats.add(o); }
  }
  const cap = new THREE.Mesh(oct ? new THREE.CylinderGeometry(w * 0.65, w * 0.65, 0.25, 8) : new THREE.BoxGeometry(w + 0.2, 0.25, w + 0.2), P.mud); cap.position.y = y1 + 0.12; g.add(cap);
  const div = new THREE.Mesh(new THREE.BoxGeometry(0.1, h, w * 0.95), P.mudCut); div.position.y = y0 + h / 2; div.visible = false; g.add(div);
  g.cut = (k) => { const on = k > 0.5; shaft.visible = !on; inner.visible = on; div.visible = on; slats.visible = !on; };
  return shadowAll(g);
}
// mud house 8 x 4 x 6 with a tower at x=-2.5 and a roof vent at x=+3; cut(k) hides the front wall
export function house({ seed = 1 } = {}) {
  const P = persiaMats(); const g = new THREE.Group();
  const floor = new THREE.Mesh(new THREE.BoxGeometry(8, 0.2, 6), P.mudCut); floor.position.y = -0.1; g.add(floor);
  const back = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 0.4), P.mud); back.position.set(0, 2, -2.8); g.add(back);
  const L = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4, 6), P.mud); L.position.set(-3.8, 2, 0); g.add(L);
  const R = L.clone(); R.position.x = 3.8; g.add(R);
  const frontM = P.mud.clone(); frontM.transparent = true;
  const front = new THREE.Mesh(new THREE.BoxGeometry(8, 4, 0.4), frontM); front.position.set(0, 2, 2.8); g.add(front);
  const door = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 2.2), new THREE.MeshStandardMaterial({ color: 0x5a3a20 })); door.position.set(1.2, 1.1, 3.01); g.add(door);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(8.2, 0.3, 6.2), P.mud); roof.position.y = 4.15; g.add(roof);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(1.4, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), P.mud); dome.position.set(1.0, 4.3, 0); g.add(dome);
  const T = tower(); T.position.set(-2.5, 0, 0); g.add(T);
  const vent = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.4, 1.0, 10), P.mud); vent.position.set(3.0, 4.8, 0); g.add(vent);
  // basement pool + qanat channel
  const pool = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.05, 1.4), new THREE.MeshStandardMaterial({ color: 0x3a8ac8, emissive: 0x0a3a6a, emissiveIntensity: 0.5, roughness: 0.05 })); pool.position.set(-1.0, 0.03, 0.2); g.add(pool);
  for (const [x, z, bx, bz] of [[-1.0, -0.55, 2.3, 0.15], [-1.0, 0.95, 2.3, 0.15], [-2.1, 0.2, 0.15, 1.6], [0.1, 0.2, 0.15, 1.6]]) { const r = new THREE.Mesh(new THREE.BoxGeometry(bx, 0.22, bz), new THREE.MeshStandardMaterial({ color: 0x3a7a9a, roughness: 0.6 })); r.position.set(x, 0.11, z); g.add(r); } // tiled pool rim
  const qan = new THREE.Mesh(new THREE.BoxGeometry(12, 0.4, 0.8), new THREE.MeshStandardMaterial({ color: 0x3a8ac8, emissive: 0x0a3a6a, emissiveIntensity: 0.5, roughness: 0.1 })); qan.position.set(0, -1.2, 0.6); qan.visible = false; g.add(qan);
  const earth = new THREE.Mesh(new THREE.BoxGeometry(14, 2, 0.2), P.mudCut); earth.position.set(0, -1.1, -0.2); earth.visible = false; g.add(earth);
  // air particles: cool (blue) in through the tower, across the room, warm (orange) out through the vent
  const air = [...Array(70)].map(() => { const s = glowSprite(0x9ad8ff, 0.24); g.add(s); s.trail = [1, 2, 3].map(q => { const tr = glowSprite(0x9ad8ff, 0.24 * (1 - q * 0.2)); g.add(tr); return tr; }); return s; }); // each puff trails a short streak
  const path = (u, i, viaQanat) => {
    const j = ((i * 37) % 70) / 70 - 0.5;
    if (u < 0.15) { const v = u / 0.15; return [-8 + v * 5.5, 11.3 + j * 0.6, j * 0.6, 0]; }
    if (u < 0.45) { const v = (u - 0.15) / 0.3; return [-2.85 + j * 0.25, 11.3 - v * (viaQanat ? 12.5 : 10.3), j * 0.6, 0.1]; } // down the windward half of the shaft
    if (u < 0.75) { const v = (u - 0.45) / 0.3; return [-2.5 + v * 5.5, (viaQanat ? -1.0 + v * 2.4 : 1.0) + Math.sin(v * 6 + i) * 0.25, j * 3, v * v * 0.6]; }
    const v = (u - 0.75) / 0.25; return [3.0 + j * 0.2, 1.4 + v * 5.0, j * 0.4, 1];
  };
  g.flow = (k, t, { inOnly = false, viaQanat = false } = {}) => air.forEach((s, i) => {
    const u = (t * 0.1 + i / 70) % 1; const show = !(inOnly && u > 0.45) && k > 0.01;
    [s, ...s.trail].forEach((sp, q) => { const uq = Math.max(0, u - q * 0.006); const p = path(uq, i, viaQanat); sp.position.set(p[0], p[1], p[2]); const warm = p[3]; sp.material.color.setRGB(0.55 + 0.45 * warm, 0.85 - 0.3 * warm, 1 - 0.75 * warm); sp.material.opacity = k * 0.85 * (1 - q * 0.25); sp.visible = show; });
  });
  g.cut = (k) => { frontM.opacity = 1 - 0.9 * k; frontM.depthWrite = k < 0.05; door.visible = k < 0.5; T.cut(k); };
  g.qanat = (on) => { qan.visible = on; earth.visible = on; };
  g.cut(0); g.flow(0, 0);
  g.tower = T; g.pool = pool;
  return shadowAll(g);
}
// thermometer: glass tube with a red column; set(k) 0..1
export function thermometer() {
  const g = new THREE.Group();
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.6, 16), new THREE.MeshPhysicalMaterial({ color: 0xdff0ff, transparent: true, opacity: 0.3, roughness: 0.05 })); tube.position.y = 0.9; g.add(tube);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 12), new THREE.MeshStandardMaterial({ color: 0xe02020, emissive: 0x801010, emissiveIntensity: 0.6 })); bulb.position.y = 0.1; g.add(bulb);
  const col = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1, 10), bulb.material); g.add(col);
  for (let i = 0; i < 8; i++) { const tick = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.012, 0.01), new THREE.MeshStandardMaterial({ color: 0x222222 })); tick.position.set(0.12, 0.3 + i * 0.18, 0.05); g.add(tick); }
  g.set = (k) => { const h = 0.2 + 1.3 * k; col.scale.y = h; col.position.y = 0.2 + h / 2; };
  g.set(1);
  return g;
}
// Yazd-like skyline of mud houses and windcatchers around the origin
export function skyline(scene, { n = 40, r = 60, seed = 4 } = {}) {
  const P = persiaMats(); const R = rng(seed);
  for (let i = 0; i < n; i++) {
    const x = (R() - 0.5) * r * 2, z = -R() * r * 1.5 - 6; const w = 5 + R() * 5, h = 3 + R() * 2;
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w * (0.7 + R() * 0.5)), P.mud); b.position.set(x, h / 2, z); b.castShadow = b.receiveShadow = true; scene.add(b);
    if (R() < 0.75) { const t = tower({ w: 1.2 + R() * 0.6, y0: h, y1: h + 4 + R() * 6 }); t.position.set(x + (R() - 0.5) * w * 0.5, 0, z); scene.add(t); }
    if (R() < 0.3) { const d = new THREE.Mesh(new THREE.SphereGeometry(w * 0.3, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), P.mud); d.position.set(x, h, z); scene.add(d); }
  }
}
// modern glass building with two white wind towers
export function modernBuilding() {
  const g = new THREE.Group();
  const glass = new THREE.MeshPhysicalMaterial({ color: 0x8ab8d8, metalness: 0.3, roughness: 0.1, clearcoat: 1 });
  const b = new THREE.Mesh(new THREE.BoxGeometry(16, 10, 10), glass); b.position.y = 5; g.add(b);
  const white = new THREE.MeshStandardMaterial({ color: 0xf2f2f0, roughness: 0.4 });
  for (const x of [-5, 5]) { const t = new THREE.Mesh(new THREE.BoxGeometry(2.4, 12, 2.4), white); t.position.set(x, 16, 0); g.add(t); for (let k = 0; k < 4; k++) { const sl = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 2.4), new THREE.MeshStandardMaterial({ color: 0x2a3a4a })); sl.position.set(x - 0.75 + k * 0.5, 20.5, 1.21); g.add(sl); } }
  return shadowAll(g);
}
