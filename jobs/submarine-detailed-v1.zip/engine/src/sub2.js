// detail kit for the submarine: tiled hull, hatches, masts, limber holes; underwater reef, god rays, rippled surface
import * as THREE from 'three';
import * as S from './sub.js';
import { reefDetail } from './reef2.js';
import { rnd } from './bolt.js';
export { forces, oceanSurface, std, WATER_C } from './sub.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const tileTex = () => cv(512, 512, (g, w, h) => { g.fillStyle = '#ffffff'; g.fillRect(0, 0, w, h); const R = rnd(4); const s = 32;
  for (let y = 0; y < h; y += s) for (let x = 0; x < w; x += s) { const v = 225 + R() * 30 | 0; g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(x + 1, y + 1, s - 2, s - 2); }
  g.strokeStyle = 'rgba(70,75,85,0.9)'; g.lineWidth = 2; for (let x = 0; x <= w; x += s) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); } for (let y = 0; y <= h; y += s) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  for (let i = 0; i < 40; i++) { g.fillStyle = 'rgba(120,125,135,0.5)'; g.fillRect((R() * 16 | 0) * s + 1, (R() * 16 | 0) * s + 1, s - 2, s - 2); } });
export function submarine() {
  const U = S.submarine(); const tt = tileTex(); tt.repeat.set(5, 7);
  { const hg = U.body.children[0].geometry; const p = hg.attributes.position, uv = hg.attributes.uv; for (let i = 0; i < p.count; i++) { uv.setXY(i, (Math.atan2(p.getZ(i), p.getX(i)) / (Math.PI * 2) + 1) % 1, (p.getY(i) + 4.2) / 8.4); } uv.needsUpdate = true; }
  const seen = new Set(); U.body.traverse(o => { if (!o.isMesh || seen.has(o.material)) return; const c = o.material.color && o.material.color.getHex(); if (c === 0x2f3540 || c === 0x262b33) { seen.add(o.material); o.material.map = tt; o.material.bumpMap = tt; o.material.bumpScale = 0.8; o.material.color.set(c === 0x2f3540 ? 0x3a4250 : 0x30363f); o.material.needsUpdate = true; } });
  const hullM = U.body.children[0].material; const dark = new THREE.MeshStandardMaterial({ color: 0x0c0f14, roughness: 0.6, transparent: true }); const metal = new THREE.MeshStandardMaterial({ color: 0x5a6470, roughness: 0.35, metalness: 0.7, transparent: true });
  const extra = new THREE.Group(); U.body.add(extra);
  // limber holes along both sides near the waterline
  for (let k = 0; k < 22; k++) [-1, 1].forEach(s => { const h = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.05, 0.02), dark); const x = 2.6 - k * 0.24; h.position.set(x, -0.38, s * 0.93); h.rotation.x = s * 0.4; extra.add(h); });
  // hatches on the deck, masts + periscope on the sail, sonar ring at the bow
  [2.9, -1.6, -2.6].forEach(x => { const hh = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.05, 20), metal); hh.position.set(x, 0.99, 0); extra.add(hh); });
  [[1.1, 0.06, 0.9], [1.45, 0.04, 1.2], [1.8, 0.05, 0.7]].forEach(([x, r, l]) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, l, 10), metal); m.position.set(x, 2.25 + l / 2, 0); extra.add(m); });
  const peri = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.1), dark); peri.position.set(1.45, 2.9, 0); extra.add(peri);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.8, 0.03, 8, 40), metal); ring.rotation.y = Math.PI / 2; ring.position.set(3.6, 0, 0); extra.add(ring);
  // windows on the sail
  [-1, 1].forEach(s => { for (let k = 0; k < 3; k++) { const w = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 0.09), new THREE.MeshStandardMaterial({ color: 0x8fd0ff, emissive: 0x2a6080, roughness: 0.1, transparent: true })); w.position.set(1.15 + k * 0.22, 1.85, s * 0.255); w.rotation.y = s > 0 ? 0 : Math.PI; extra.add(w); } });
  const up = U.update; U.update = (T) => { up(T); const op = hullM.opacity; extra.traverse(o => { if (o.isMesh) { o.material.opacity = op; o.material.depthWrite = op > 0.7; } }); };
  return U;
}
// underwater dressing for a world whose sand floor sits at y = floorY and surface at y = 0
export function deepDetail(scene, floorY = -22) {
  scene.userData.updaters = scene.userData.updaters || [];
  [[0, 2, 11], [Math.PI, 1, 23]].forEach(([ry, count, seed]) => { const holder = new THREE.Group(); holder.userData = scene.userData; reefDetail(holder, { count, seed, keepClear: 1.2 }); holder.userData = {}; holder.scale.setScalar(5); holder.position.y = floorY + 0.55; holder.rotation.y = ry; scene.add(holder); });
  // sand floor bigger so no edge shows
  scene.children.filter(o => o.isMesh && o.geometry && o.geometry.type === 'PlaneGeometry' && Math.abs(o.position.y - floorY) < 0.5).forEach(o => o.scale.setScalar(5));
  // surface: rippled caustic pattern, fades into fog with distance
  const rip = cv(512, 512, (g, w, h) => { g.fillStyle = '#7fd8f0'; g.fillRect(0, 0, w, h); const R = rnd(9); g.strokeStyle = 'rgba(235,255,255,0.65)'; for (let i = 0; i < 140; i++) { g.lineWidth = 1 + R() * 3; const x = R() * w, y = R() * h, r = 10 + R() * 40; g.beginPath(); g.ellipse(x, y, r, r * (0.4 + R() * 0.5), R() * 3, 0, Math.PI * (0.6 + R())); g.stroke(); } }); rip.repeat.set(30, 30);
  scene.children.filter(o => o.isMesh && o.material && o.material.isMeshBasicMaterial && o.material.color.getHex() === 0x9fe6ff).forEach(o => { o.material.map = rip; o.material.color.set(0xffffff); o.material.fog = true; o.material.needsUpdate = true; });
  // god rays: tall additive planes angled down from the surface
  const rt = cv(64, 512, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, 'rgba(220,250,255,0.5)'); gr.addColorStop(1, 'rgba(220,250,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); const g2 = g.createLinearGradient(0, 0, w, 0); g2.addColorStop(0, 'rgba(0,0,0,1)'); g2.addColorStop(0.5, 'rgba(0,0,0,0)'); g2.addColorStop(1, 'rgba(0,0,0,1)'); g.globalCompositeOperation = 'destination-out'; g.fillStyle = g2; g.fillRect(0, 0, w, h); });
  const R = rnd(21); const rays = [];
  for (let i = 0; i < 18; i++) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1.5 + R() * 3, 30), new THREE.MeshBasicMaterial({ map: rt, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.18 + R() * 0.2, side: THREE.DoubleSide, fog: false })); m.geometry.translate(0, -15, 0); m.position.set((R() - 0.5) * 50, 0, -6 - R() * 26); m.rotation.z = 0.25 + (R() - 0.5) * 0.1; scene.add(m); rays.push([m, R()]); }
  // small fish schools in the distance
  const fg = new THREE.ConeGeometry(0.08, 0.35, 6); fg.rotateZ(-Math.PI / 2); const fm = new THREE.MeshStandardMaterial({ color: 0xc8d8e0, roughness: 0.3, metalness: 0.6 });
  const fish = new THREE.InstancedMesh(fg, fm, 160); scene.add(fish); const FP = []; for (let i = 0; i < 160; i++) { const sch = i % 4; FP.push([sch, (R() - 0.5) * 3, (R() - 0.5) * 1.5, (R() - 0.5) * 2]); }
  const M = new THREE.Matrix4(), q = new THREE.Quaternion();
  scene.userData.updaters.push((T) => { rays.forEach(([m, ph]) => { m.material.opacity = 0.15 + 0.12 * Math.sin(T * 0.7 + ph * 9); }); FP.forEach(([s, x, y, z], i) => { const cx = -20 + s * 12 + ((T * 1.2 + s * 7) % 40) - 20, cy = -12 + s * 2.2, cz = -18 - s * 4; M.compose(new THREE.Vector3(cx + x + Math.sin(T * 2 + i) * 0.1, cy + y, cz + z), q, new THREE.Vector3(1, 1, 1)); fish.setMatrixAt(i, M); }); fish.instanceMatrix.needsUpdate = true; });
}
