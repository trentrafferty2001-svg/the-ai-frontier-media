// The Explainer: why volcanoes erupt. Cutaway volcano (cross-section face at z=0, camera on +z), magma, bubbles,
// lava flows, ash plume, soda bottle. Units ~ km-ish: cone 6 high, crust down to -12.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.8, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
export const LAVA = () => new THREE.MeshStandardMaterial({ color: 0xff5a10, emissive: 0xff3a00, emissiveIntensity: 1.6, roughness: 0.6, toneMapped: false });
export const CRATER = new THREE.Vector3(0, 6, 0);
export const CHAMBER = new THREE.Vector3(0, -6, 0);
// mountain profile (height at |x|)
export function profile(x, R = 14, H = 6.5, crater = 1.2) { const a = Math.abs(x); if (a > R) return 0; if (a < crater) return H - 0.5 + 0.5 * (a / crater) ** 2; return H * Math.pow(1 - (a - crater) / (R - crater), 1.25); }

export function volcano({ R = 14, H = 6.5, cut = true } = {}) {
  const G = new THREE.Group();
  const rock = std(0x6a5a4a, 0.95), grass = std(0x5a7a3a, 1), ash = std(0x4a4440, 0.95);
  // mountain: lathe (back half when cut)
  const pts = []; for (let i = 0; i <= 40; i++) { const x = (i / 40) * R; pts.push(new THREE.Vector2(Math.max(0.001, x), profile(x, R, H))); }
  const lg = new THREE.LatheGeometry(pts, 96, cut ? Math.PI / 2 : 0, cut ? Math.PI : Math.PI * 2);
  const col = []; const pa = lg.attributes.position; const c = new THREE.Color();
  for (let i = 0; i < pa.count; i++) { const y = pa.getY(i); c.set(y > H * 0.55 ? 0x5a4c42 : y > H * 0.25 ? 0x6e6248 : 0x5d7a3e); col.push(c.r, c.g, c.b); }
  lg.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  const mtn = new THREE.Mesh(lg, std(0xffffff, 0.95, 0, { vertexColors: true, side: THREE.DoubleSide })); G.add(mtn);
  // ground (back half disc when cut)
  const gd = new THREE.Mesh(new THREE.CircleGeometry(160, 64, cut ? 0 : 0, cut ? Math.PI : Math.PI * 2), grass); gd.rotation.x = -Math.PI / 2; gd.position.y = -0.01; if (cut) gd.rotation.z = 0; G.add(gd);
  let face = null, layers = [];
  if (cut) {
    // cross-section face: crust block + mountain silhouette, layered strata
    const sh = new THREE.Shape(); sh.moveTo(-40, -40); sh.lineTo(40, -40); sh.lineTo(40, 0); sh.lineTo(R, 0);
    for (let i = 40; i >= -40; i--) { const x = (i / 40) * R; sh.lineTo(x, profile(x, R, H)); } sh.lineTo(-40, 0); sh.closePath();
    const fg = new THREE.ShapeGeometry(sh, 4);
    const fc = []; const fp = fg.attributes.position; const cc = new THREE.Color();
    for (let i = 0; i < fp.count; i++) { const y = fp.getY(i); const band = Math.floor((y + 14) / 2.3) % 3; cc.set(y > 0 ? 0x7a6650 : [0x7a5a40, 0x6a4c36, 0x8a6a48][band]); cc.offsetHSL(0, 0, -Math.max(0, -y) * 0.012); fc.push(cc.r, cc.g, cc.b); }
    fg.setAttribute('color', new THREE.Float32BufferAttribute(fc, 3));
    face = new THREE.Mesh(fg, std(0xffffff, 0.95, 0, { vertexColors: true, side: THREE.DoubleSide })); G.add(face);
  }
  return { group: G, face, mtn };
}

// magma system drawn on the cut face (flat glowing shapes just in front of it)
export function magmaSystem() {
  const G = new THREE.Group(); const lava = LAVA();
  // deep melt zone at the bottom
  const melt = new THREE.Mesh(new THREE.PlaneGeometry(30, 2.4), new THREE.MeshBasicMaterial({ color: 0xff4a10, transparent: true, opacity: 0, toneMapped: false })); melt.position.set(0, -12.8, 0.03); G.add(melt);
  // chamber: ellipse, scaled by fill
  const ch = new THREE.Mesh(new THREE.CircleGeometry(1, 48), lava); ch.scale.set(4.2, 1.6, 1); ch.position.set(CHAMBER.x, CHAMBER.y, 0.04); G.add(ch);
  // conduit: tall thin quad from chamber to crater, grows with .conduit
  const cd = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 1), lava); cd.geometry.translate(0, 0.5, 0); cd.position.set(0, CHAMBER.y + 1.2, 0.05); G.add(cd);
  // rising blobs (from the melt zone to the chamber)
  const R = rnd(12); const blobs = []; for (let i = 0; i < 10; i++) { const b = new THREE.Mesh(new THREE.CircleGeometry(0.45 + R() * 0.3, 24), lava); b.scale.y = 1.25; G.add(b); blobs.push({ b, x: (R() - 0.5) * 6, ph: R() }); }
  // gas bubbles: bright small discs, spread through the chamber + conduit
  const bm = new THREE.MeshBasicMaterial({ color: 0xfff2c0, transparent: true, toneMapped: false });
  const bub = []; for (let i = 0; i < 70; i++) { const m = new THREE.Mesh(new THREE.CircleGeometry(1, 16), bm); G.add(m); bub.push({ m, x: (R() - 0.5), y: R(), inC: i < 45, ph: R(), s: 0.5 + R() * 0.5 }); }
  // cracks in the rock above the chamber
  const cm = new THREE.MeshBasicMaterial({ color: 0x1a0e08 }); const cracks = [];
  for (let i = 0; i < 6; i++) { const g = new THREE.Group(); let p = new THREE.Vector2((R() - 0.5) * 4, CHAMBER.y + 1.4); const segs = []; for (let k = 0; k < 6; k++) { const q = p.clone().add(new THREE.Vector2((R() - 0.5) * 1.2, 0.9 + R() * 0.5)); const d = q.clone().sub(p); const s = new THREE.Mesh(new THREE.PlaneGeometry(0.08, d.length()), cm); s.position.set((p.x + q.x) / 2, (p.y + q.y) / 2, 0.06); s.rotation.z = -Math.atan2(d.x, d.y); g.add(s); segs.push(s); p = q; } G.add(g); cracks.push(segs); }
  const st = { melt: 0, rise: 0, fill: 0.3, conduit: 0, gas: 0, bubbleSize: 0, crack: 0, glow: 1 };
  function update(T) {
    melt.material.opacity = 0.85 * st.melt;
    ch.scale.set(4.2 * (0.35 + 0.65 * st.fill), 1.6 * (0.35 + 0.65 * st.fill) * (1 + 0.04 * st.bubbleSize * Math.sin(T * 9)), 1);
    lava.emissiveIntensity = 1.4 * st.glow + 0.6 * st.bubbleSize * (0.5 + 0.5 * Math.sin(T * 9));
    cd.scale.set(1, Math.max(0.001, st.conduit * (CRATER.y - CHAMBER.y - 1.2)), 1); cd.visible = st.conduit > 0.01;
    blobs.forEach(({ b, x, ph }) => { const u = ((ph + T * 0.18) % 1); const on = st.rise > 0.01; b.visible = on; b.position.set(x * (1 - u * 0.7), -12 + u * 5.2, 0.05); b.scale.setScalar(st.rise * (1 - u * 0.3)); b.scale.y *= 1.25; });
    bub.forEach((o) => { let x, y; if (o.inC) { const a = o.x * Math.PI * 2; x = CHAMBER.x + Math.cos(a) * 3.2 * o.y * (0.35 + 0.65 * st.fill); y = CHAMBER.y + Math.sin(a) * 1.1 * o.y * (0.35 + 0.65 * st.fill); } else { const u = ((o.ph + T * 0.25) % 1); x = o.x * 0.4; y = CHAMBER.y + 1.4 + u * (CRATER.y - CHAMBER.y - 1.6) * st.conduit; }
      const r = (0.04 + 0.16 * st.bubbleSize * o.s) * (o.inC ? 1 : 0.8 + 0.6 * ((o.ph + T * 0.25) % 1));
      o.m.position.set(x, y, 0.07); o.m.scale.setScalar(Math.max(0.001, r)); o.m.visible = st.gas > 0.01 && (o.inC || st.conduit > 0.05); o.m.material.opacity = Math.min(1, st.gas * 1.5); });
    cracks.forEach((segs, i) => segs.forEach((s, k) => { s.visible = st.crack * 6 > k + (i % 3) * 0.3; }));
  }
  update(0);
  return { group: G, st, update };
}

// lava flows down the flanks: glowing ribbons laid on the surface (full volcano), grow with k
export function lavaFlows(R = 14, H = 6.5, n = 7, seed = 3) {
  const G = new THREE.Group(); const mat = LAVA(); const Rr = rnd(seed); const flows = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + Rr() * 0.5; const pts = [];
    for (let k = 0; k <= 30; k++) { const r = 1.0 + (k / 30) * (R * (0.6 + Rr() * 0.3)); const wob = Math.sin(k * 0.6 + i) * 0.3; const aa = a + wob * 0.05; pts.push(new THREE.Vector3(Math.cos(aa) * r, profile(r, R, H) + 0.12, Math.sin(aa) * r)); }
    const curve = new THREE.CatmullRomCurve3(pts); const tg = new THREE.TubeGeometry(curve, 60, 0.3, 8, false);
    const m = new THREE.Mesh(tg, mat); G.add(m); flows.push(m);
  }
  return { group: G, set(k) { flows.forEach((m, i) => { const kk = Math.max(0, Math.min(1, k * 1.2 - i * 0.03)); m.geometry.setDrawRange(0, Math.floor(m.geometry.index.count * kk / 6) * 6); m.visible = kk > 0.01; }); }, mat };
}
// ash plume: many grey puffs rising and expanding from the crater, plus glowing bombs
export function plume(seed = 4) {
  const G = new THREE.Group(); const R = rnd(seed); const P = []; const am = std(0x5a5654, 1); const geo = new THREE.IcosahedronGeometry(1, 2);
  for (let i = 0; i < 90; i++) { const m = new THREE.Mesh(geo, am); G.add(m); P.push({ m, ph: R(), dx: (R() - 0.5), dz: (R() - 0.5), s: 0.6 + R() * 0.8 }); }
  const bm = LAVA(); const B = []; for (let i = 0; i < 16; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), bm); G.add(m); B.push({ m, vx: (R() - 0.5) * 6, vz: (R() - 0.5) * 6, vy: 6 + R() * 5, ph: R() * 0.6 }); }
  return { group: G, set(k, t) {
    P.forEach(o => { const u = k > 0.01 ? ((o.ph + t * 0.12) % 1) * Math.min(1, k * 1.5) : 0; const y = u * 26 * o.s; o.m.position.set(o.dx * (1 + y * 0.35), CRATER.y + y, o.dz * (1 + y * 0.35)); o.m.scale.setScalar(Math.max(0.001, u > 0 ? (0.6 + y * 0.13) * o.s : 0)); o.m.visible = u > 0.001; o.m.rotation.set(t * 0.2 + o.ph, t * 0.1, 0); });
    B.forEach(o => { const tt = ((t * 0.6 + o.ph) % 1.4); const on = k > 0.05; o.m.visible = on; o.m.position.set(o.vx * tt, CRATER.y + o.vy * tt - 4.9 * tt * tt, o.vz * tt); });
  } };
}
// soda bottle: green glass, cap, foam that sprays out with k
export function soda() {
  const G = new THREE.Group();
  const pts = []; [[0.0, 0.5], [0.05, 0.55], [1.6, 0.55], [2.1, 0.3], [2.6, 0.2], [2.75, 0.21]].forEach(([y, r]) => pts.push(new THREE.Vector2(r, y)));
  const glass = new THREE.Mesh(new THREE.LatheGeometry(pts, 40), new THREE.MeshPhysicalMaterial({ color: 0x3aa860, roughness: 0.05, transmission: 0.7, thickness: 0.2, transparent: true, opacity: 0.85, side: THREE.DoubleSide })); G.add(glass);
  const liquid = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 1.55, 32), new THREE.MeshPhysicalMaterial({ color: 0x8a4a1a, roughness: 0.1, transmission: 0.3 })); liquid.position.y = 0.82; G.add(liquid);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.22, 24), std(0xd02020, 0.4, 0.3)); cap.position.y = 2.82; G.add(cap);
  const R = rnd(2); const fm = std(0xfff8ee, 0.9); const F = []; for (let i = 0; i < 70; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.09 + R() * 0.08, 10, 8), fm); G.add(m); F.push({ m, vx: (R() - 0.5) * 1.6, vy: 3 + R() * 3, vz: (R() - 0.5) * 1.6, ph: R() }); }
  const inB = []; const ib = new THREE.MeshBasicMaterial({ color: 0xfff0d0, transparent: true, opacity: 0.8 }); for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.03 + R() * 0.03, 8, 6), ib); G.add(m); inB.push({ m, x: (R() - 0.5) * 0.7, z: (R() - 0.5) * 0.7, ph: R() }); }
  return { group: G, set(k, t) {
    cap.position.set(k > 0 ? k * 1.2 : 0, 2.82 + k * 3, 0); cap.rotation.z = k * 6;
    F.forEach(o => { const tt = ((t * 0.8 + o.ph) % 1) * k; o.m.visible = k > 0.02; o.m.position.set(o.vx * tt, 2.8 + o.vy * tt - 4 * tt * tt, o.vz * tt); });
    inB.forEach(o => { const u = (o.ph + t * 0.6) % 1; o.m.visible = k > 0.0; o.m.position.set(o.x, 0.1 + u * 1.5, o.z); o.m.scale.setScalar(k > 0 ? 1 + u : 0.001); });
  } };
}
export { std };
