// The Explainer: how penguins survive the cold. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { penguin, huddle, blizzard, featherPatch, bodySection, exchanger, std } from './penguin.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_pg.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*Emperor penguins*', 2], ['survive', 1], ['*minus forty*', 2], ['degrees', 1], ['and the middle', 3], ['of their *huddle*', 3], ['can get *warmer*', 3], ['than a', 2], ['*summer day*', 2]],
  [['Their *stiff*', 2], ['outer *feathers*', 2], ['overlap like', 2], ['*roof tiles*', 2], ['and *fluffy down*', 3], ['underneath', 1], ['*traps* a layer', 3], ['of *warm air*', 3]],
  [['Under the skin', 3], ['a *thick* layer', 3], ['of *fat*', 2], ['keeps the', 2], ['*heat* in', 2]],
  [['Their *feet*', 2], ['stand on *ice*', 3], ['all day', 2], ['but they', 2], ["*don't freeze*", 2]],
  [['*Warm blood*', 2], ['flowing down', 2], ['to the feet', 3], ['passes right', 2], ['next to', 2], ['*cold blood*', 2], ['coming back', 2], ['and *hands over*', 3], ['its *heat*', 2]],
  [['So the feet', 3], ['stay just', 2], ['*above freezing*', 2], ['and very', 2], ['*little heat*', 2], ['is lost', 2]],
  [['They even', 2], ['*rock back*', 2], ['on their *heels*', 3], ['to touch', 2], ['*less ice*', 2]],
  [['And when', 2], ['*blizzards* hit', 2], ['*thousands*', 1], ['crowd together', 2], ['in a *huddle*', 3]],
  [['They slowly', 2], ['*shuffle*', 1], ['so everyone', 2], ['*takes a turn*', 3], ['in the', 2], ['*warm middle*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.02; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.4, warm: 0.92, sat: 1.1, exposure: 1.05 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

// icy world: pale sky, snow plain
function ice(makeStage, storm = 0.6) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.4, 0.35, 0.7], fog: 0.02 + 0.03 * storm, shadowSize: 8, envI: 1.0, cloud: 0.7 });
  const g = new THREE.Mesh(new THREE.CircleGeometry(200, 48), std(0xeef4fa, 0.9)); g.rotation.x = -Math.PI / 2; scene.add(g);
  const B = blizzard(); scene.add(B.mesh);
  return { scene, B };
}
// studio for diagrams
function lab(makeStage, top = 0x2a3a52) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(top); u.mid.value.set(0x2c4058); u.horizon.value.set(0x34485e); u.floorC.value.set(0x182030); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xeef6ff, 0x203040, 0.9));
  return scene;
}

// ============ S0 hook: blizzard, a huddle; swoop toward the middle: -40 outside, warm inside ============
function sHook({ makeStage }) {
  const W = ice(makeStage, 1); const Hd = huddle(); W.scene.add(Hd.group);
  const L1 = tag(W.scene, '−40°C', 1.0, '#9fd8ff', [-2.5, 4.4, 2.0]); const L2 = tag(W.scene, 'over 20°C inside', 0.8, '#ffb347', [0, 2.6, 0]);
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t) {
      W.B.update(t); Hd.layout(1, t, 1);
      pop(L1, easeOut(range(t, at(0, 'minus') - 0.2, at(0, 'minus') + 0.2)) * (1 - range(t, at(0, 'middle'), at(0, 'middle') + 0.3)), 1.0);
      pop(L2, easeOut(range(t, at(0, 'warmer') - 0.2, at(0, 'warmer') + 0.2)), 0.8);
      const k = easeInOut(range(t, 0, 6.2));
      orb(c, [0, lerp(1.2, 0.6, k), 0], lerp(16, 9, k), lerp(30, 70, k), lerp(14, 34, k));
      return POST;
    },
  };
}
// ============ S1: feathers like roof tiles over down; warm air layer ============
function sFeathers({ makeStage }) {
  const scene = lab(makeStage); const F = featherPatch(); scene.add(F.group);
  const R = rnd(4); const wind = []; const wm = new THREE.MeshBasicMaterial({ color: 0xcfe8ff, transparent: true, opacity: 0.7 });
  for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.02, 0.02), wm); scene.add(m); wind.push({ m, z: (R() - 0.5) * 2.2, y: 0.6 + R() * 1.2, ph: R() }); }
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      const lift = smooth(range(T, at(1, 'fluffy') - 0.4, at(1, 'fluffy') + 0.3)) * (1 - smooth(range(T, at(1, 'traps') + 0.6, le(1)))); // lift feathers to show the down
      F.feathers.forEach((f, i) => { f.position.y = 0.24 + Math.floor(i / 9) * 0.012 + lift * 0.45; });
      F.warm.material.opacity = 0.45 * smooth(range(T, at(1, 'warm') - 0.3, at(1, 'air') + 0.2)) * (0.75 + 0.25 * Math.sin(T * 4));
      wind.forEach(o => { const u = (o.ph + T * 0.6) % 1; const x = -3 + u * 6; const y = Math.max(o.y - 0.0, 0.42 + (x > -0.2 ? (x + 0.2) * 0.2 : 0)); o.m.position.set(x, o.y + Math.max(0, 1 - Math.abs(x)) * 0.3, o.z); });
      const k = easeInOut(range(t, 0, 6.2));
      orb(c, [0, 0.1, 0], lerp(6.0, 4.8, k), lerp(30, 10, k), lerp(32, 22, k));
      return { ...POST, warm: 1.0 };
    },
  };
}
// ============ S2: body cross-section: thick fat layer ============
function sFat({ makeStage }) {
  const scene = lab(makeStage); const B = bodySection(); B.group.position.y = 0.2; scene.add(B.group);
  const L = tag(scene, 'fat', 0.9, '#ffe8a8', [0, 3.2, 0.2]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      const f = smooth(range(T, at(2, 'thick') - 0.2, at(2, 'fat') + 0.2)); B.fat.material.emissive = new THREE.Color(0xffd070); B.fat.material.emissiveIntensity = 0.5 * f * (0.7 + 0.3 * Math.sin(T * 5));
      B.core.material.emissiveIntensity = 0.4 + 0.4 * smooth(range(T, at(2, 'heat') - 0.2, at(2, 'heat') + 0.3));
      pop(L, easeOut(range(T, at(2, 'fat') - 0.15, at(2, 'fat') + 0.2)), 0.9);
      const k = easeInOut(range(t, 0, 3.2));
      orb(c, [0, -0.9, 0], lerp(15, 14, k), lerp(-10, 6, k), 4);
      return POST;
    },
  };
}
// ============ S3: feet on the ice ============
function sFeet({ makeStage }) {
  const W = ice(makeStage, 0.3); const P = penguin(); W.scene.add(P.group);
  const c = C(36);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.B.update(T, 0.4);
      const k = easeInOut(range(t, 0, 3.2));
      orb(c, [0, lerp(0.6, 0.2, k), 0.1], lerp(3.6, 2.2, k), lerp(30, 20, k), lerp(14, 10, k));
      return POST;
    },
  };
}
// ============ S4: countercurrent exchange in the leg ============
function sExchange({ makeStage }) {
  const scene = lab(makeStage); const X = exchanger(); scene.add(X.group);
  const La = tag(scene, 'warm blood', 0.45, '#ff8a7a', [-0.45, 2.95, 0.3]), Lv = tag(scene, 'cold blood', 0.45, '#8ac0ff', [0.45, -2.95, 0.3]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      X.update(T, 1, smooth(range(T, at(4, 'hands') - 0.3, at(4, 'heat') + 0.2)));
      pop(La, easeOut(range(T, at(4, 'warm') - 0.1, at(4, 'warm') + 0.2)), 0.45); pop(Lv, easeOut(range(T, at(4, 'cold') - 0.1, at(4, 'cold') + 0.2)), 0.45);
      const k = easeInOut(range(t, 0, 6.0));
      orb(c, [0, 0, 0], lerp(10.5, 9.5, k), lerp(-12, 10, k), 4);
      return { ...POST, bloom: 0.5 };
    },
  };
}
// ============ S5: feet just above freezing ============
function sAbove({ makeStage }) {
  const W = ice(makeStage, 0.3); const P = penguin(); W.scene.add(P.group);
  const L = tag(W.scene, 'feet: about 1°C', 0.11, '#ffd08a', [0, 0.26, 0.4]);
  const c = C(36);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.B.update(T, 0.4);
      P.feet.forEach(f => { f.material = f.material; });
      pop(L, easeOut(range(T, at(5, 'above') - 0.2, at(5, 'above') + 0.2)) * 0, 0.11);
      const k = easeInOut(range(t, 0, 3.8));
      orb(c, [0, -0.12, 0.15], lerp(1.9, 2.2, k), lerp(-14, -26, k), lerp(26, 30, k));
      return POST;
    },
  };
}
// ============ S6: rocks back on its heels ============
function sHeels({ makeStage }) {
  const W = ice(makeStage, 0.3); const P = penguin(); W.scene.add(P.group);
  const c = C(36);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.B.update(T, 0.4);
      const r = smooth(range(T, at(6, 'rock') - 0.2, at(6, 'heels') + 0.2)); P.body.rotation.x = -0.32 * r; P.body.position.z = -0.12 * r;
      P.feet.forEach(f => { f.rotation.x = -0.6 * r; f.position.y = 0.03 + 0.06 * r; });
      const k = easeInOut(range(t, 0, 3.0));
      orb(c, [0, 0.55, 0], lerp(4.2, 3.8, k), lerp(78, 86, k), lerp(4, 6, k));
      return POST;
    },
  };
}
// ============ S7: blizzard hits, thousands pack into a huddle ============
function sHuddle({ makeStage }) {
  const W = ice(makeStage, 1); const Hd = huddle(); W.scene.add(Hd.group);
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.B.update(T, 1); Hd.layout(smooth(range(T, at(7, 'crowd') - 0.6, le(7) + 0.3)), T, 0.3);
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [0, 0.6, 0], lerp(13, 15, k), lerp(20, 34, k), lerp(16, 24, k));
      return POST;
    },
  };
}
// ============ S8: overhead: the huddle shuffles; warm middle glows ============
function sShuffle({ makeStage }) {
  const W = ice(makeStage, 0.8); const Hd = huddle(); W.scene.add(Hd.group);
  const glow = new THREE.Mesh(new THREE.CircleGeometry(2.2, 48), new THREE.MeshBasicMaterial({ color: 0xff9a40, transparent: true, opacity: 0, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending }));
  glow.rotation.x = -Math.PI / 2; glow.position.y = 1.5; glow.renderOrder = 20; W.scene.add(glow);
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.B.update(T, 0.8); Hd.layout(1, T * 3, 1);
      glow.material.opacity = 0.35 * smooth(range(T, at(8, 'warm') - 0.4, at(8, 'middle'))) * (0.8 + 0.2 * Math.sin(T * 3));
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [0, 0.4, 0], lerp(12, 15, k), lerp(10, 40, k), lerp(55, 65, k));
      return POST;
    },
  };
}

const SH = [sHook, sFeathers, sFat, sFeet, sExchange, sAbove, sHeels, sHuddle, sShuffle];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
