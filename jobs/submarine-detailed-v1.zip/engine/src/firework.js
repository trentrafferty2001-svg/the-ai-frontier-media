// The Explainer: how fireworks get their colours. Bursts (sphere/ring/heart) as instanced stars with trails,
// shell cutaway (stars + burst charge + time fuse), mortar tube cutaway with lift charge, atom with electron jump +
// photon, night city skyline. Units ~ metres (bursts in sky units).
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.8, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
export const COL = { red: 0xff2a3a, green: 0x3aff5a, yellow: 0xffc21a, blue: 0x1a40ff, white: 0xffffff, gold: 0xffa84a, pink: 0xff4ac8 };
function dirs(shape, n, R) {
  const D = [];
  if (shape === 'ring') for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; D.push(new THREE.Vector3(Math.cos(a), Math.sin(a), 0)); }
  else if (shape === 'heart') for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; const x = 16 * Math.pow(Math.sin(a), 3), y = 13 * Math.cos(a) - 5 * Math.cos(2 * a) - 2 * Math.cos(3 * a) - Math.cos(4 * a); D.push(new THREE.Vector3(x / 17, (y + 2) / 17, 0)); }
  else { const g = Math.PI * (3 - Math.sqrt(5)); for (let i = 0; i < n; i++) { const y = 1 - (i + 0.5) / n * 2, r = Math.sqrt(1 - y * y), a = i * g + R() * 0.3; D.push(new THREE.Vector3(Math.cos(a) * r, y, Math.sin(a) * r).multiplyScalar(0.85 + R() * 0.15)); } }
  return D;
}
// a burst: set(t) with t = seconds since the burst (t < 0 hides it); whiten 0..1 washes the colour to white
export function burst({ color = COL.red, n = 90, R = 3, shape = 'sphere', seed = 1, life = 2.8, trail = 6, size = 1 } = {}) {
  const G = new THREE.Group(); const r = rnd(seed); const D = dirs(shape, n, r);
  const m = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false });
  const im = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 8, 6), m, n * trail); im.frustumCulled = false; G.add(im);
  const base = new THREE.Color(color), wh = new THREE.Color(0xffffff), c = new THREE.Color();
  const flashM = new THREE.MeshBasicMaterial({ color: 0xfff4e0, transparent: true, toneMapped: false, depthWrite: false });
  const flash = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), flashM); G.add(flash);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3();
  let lastW = -1;
  function paint(w) { for (let i = 0; i < n * trail; i++) { const k = i % trail; c.copy(base).lerp(wh, Math.max(w, k === 0 ? 0.12 : 0)).multiplyScalar(k === 0 ? 1.6 : 1.1 - k / trail * 0.7); im.setColorAt(i, c); } im.instanceColor.needsUpdate = true; lastW = w; }
  paint(0);
  function set(t, whiten = 0, dim = 0) {
    if (Math.abs(whiten - lastW) > 0.01) paint(whiten);
    const vis = t >= 0 && t < life + 0.6; im.visible = vis; flash.visible = vis && t < 0.18;
    if (!vis) return;
    flash.scale.setScalar(Math.max(0.001, R * 0.1 * (1 + t * 5))); flashM.opacity = 0.8 * Math.max(0, 1 - t / 0.18);
    const fade = t < life ? 1 : Math.max(0, 1 - (t - life) / 0.6);
    for (let j = 0; j < n; j++) for (let k = 0; k < trail; k++) {
      const tt = Math.max(0, t - k * 0.045); const ex = 1 - Math.exp(-tt * 3.2);
      p.copy(D[j]).multiplyScalar(R * ex); p.y -= 0.09 * R * tt * tt;
      const flick = 0.75 + 0.25 * Math.sin(t * 40 + j * 7.1);
      const sz = (k === 0 ? 0.075 : 0.05 * (1 - k / trail)) * R * size * fade * (tt > 0 || k === 0 ? 1 : 0) * (k === 0 ? flick : 1) * (1 - dim);
      M.compose(p, q, s.setScalar(Math.max(0.0001, sz))); im.setMatrixAt(j * trail + k, M);
    }
    im.instanceMatrix.needsUpdate = true;
  }
  set(-1);
  return { group: G, set };
}
// rising rocket spark with a short trail (local y from 0 to h)
export function riser(color = COL.gold) {
  const G = new THREE.Group(); const m = new THREE.MeshBasicMaterial({ color, toneMapped: false }); const P = [];
  for (let i = 0; i < 10; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.16 * (1 - i / 12), 6, 4), m); G.add(s); P.push(s); }
  return { group: G, set(u, h) { P.forEach((s, i) => { const uu = Math.max(0, u - i * 0.02); s.position.set(0.05 * Math.sin(uu * 30), h * (1 - Math.pow(1 - uu, 2)) - i * 0.12, 0); s.visible = u > 0 && u < 1; }); } };
}
// night skyline: dark blocks with warm windows, along x, at z
export function skyline(seed = 3, width = 90) {
  const G = new THREE.Group(); const R = rnd(seed);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), std(0x06080e, 1)); ground.rotation.x = -Math.PI / 2; G.add(ground);
  const bm = std(0x0c1018, 0.9); const wm = new THREE.MeshBasicMaterial({ color: 0xffc87a, toneMapped: false });
  for (let x = -width / 2; x < width / 2;) { const w = 2 + R() * 4, h = 3 + R() * 14, d = 3 + R() * 3; const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), bm); b.position.set(x + w / 2, h / 2, -R() * 4); G.add(b);
    for (let i = 0; i < Math.floor(h / 1.6); i++) for (let j = 0; j < Math.floor(w / 1.2); j++) if (R() < 0.35) { const win = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.55), wm); win.position.set(x + 0.7 + j * 1.2, 1 + i * 1.6, b.position.z + d / 2 + 0.02); G.add(win); }
    x += w + 0.3; }
  return G;
}
// cutaway shell (radius 1, cut face toward +z): paper wall, burst charge core, stars on the cut face, time fuse with spark
export function shellCut({ pattern = 'sphere', colors = [COL.red, COL.green, COL.yellow, COL.blue] } = {}) {
  const G = new THREE.Group();
  const paper = std(0xc89a5a, 0.95);
  const back = new THREE.Mesh(new THREE.SphereGeometry(1, 40, 24, Math.PI, Math.PI), std(0xb88a4a, 0.95, 0, { side: THREE.DoubleSide })); G.add(back);
  const rim = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.0, 48), paper); rim.position.z = 0.01; G.add(rim);
  const core = new THREE.Mesh(new THREE.CircleGeometry(0.9, 48), std(0x2a2826, 1)); core.position.z = 0.005; G.add(core);
  const R = rnd(9); const gm = std(0x4a4640, 1); for (let i = 0; i < 160; i++) { const a = R() * Math.PI * 2, rr = Math.sqrt(R()) * 0.62; const g = new THREE.Mesh(new THREE.SphereGeometry(0.025, 5, 4), gm); g.position.set(Math.cos(a) * rr, Math.sin(a) * rr, 0.02); G.add(g); }
  const pts = [];
  if (pattern === 'heart') dirs('heart', 26).forEach(d => pts.push([d.x * 0.62, d.y * 0.62 - 0.05]));
  else if (pattern === 'ring') for (let i = 0; i < 20; i++) { const a = i / 20 * Math.PI * 2; pts.push([Math.cos(a) * 0.55, Math.sin(a) * 0.55]); }
  else for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2; pts.push([Math.cos(a) * 0.76, Math.sin(a) * 0.76]); }
  const stars = pts.map(([x, y], i) => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.1, 14, 10), std(colors[i % colors.length], 0.5, 0, { emissive: colors[i % colors.length], emissiveIntensity: 0.35 })); m.position.set(x, y, 0.06); G.add(m); return m; });
  const fuseM = std(0x6a4a2a, 0.9); const fuse = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.8, 10), fuseM); fuse.position.set(0, 1.0, 0.03); G.add(fuse);
  const burnt = new THREE.Mesh(new THREE.CylinderGeometry(0.052, 0.052, 1, 10), std(0x151210, 1)); G.add(burnt);
  const spark = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffb04a, toneMapped: false })); G.add(spark);
  const glow = new THREE.PointLight(0xffa040, 0, 3, 2); spark.add(glow);
  const top = 1.4, bot = 0.62;
  function set(f, T = 0) { // f: fuse burnt fraction 0..1
    const y = top - (top - bot) * f; spark.position.set(0, y, 0.06); spark.visible = f > 0 && f < 1; spark.scale.setScalar(1 + 0.3 * Math.sin(T * 50)); glow.intensity = spark.visible ? 2 : 0;
    burnt.visible = f > 0.01; burnt.scale.y = Math.max(0.001, top - y); burnt.position.set(0, (top + y) / 2, 0.035);
  }
  set(0);
  return { group: G, set, stars, core };
}
// mortar tube cutaway (back half), lift charge granules at the bottom, flash light
export function mortar() {
  const G = new THREE.Group();
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 4.6, 40, 1, true, Math.PI / 2, Math.PI), std(0x2a4a3a, 0.7, 0, { side: THREE.DoubleSide })); tube.position.y = 2.3; G.add(tube);
  [-1.2, 1.2].forEach(x => { const w = new THREE.Mesh(new THREE.BoxGeometry(0.1, 4.6, 0.1), std(0x1a3a2a, 0.7)); w.position.set(x, 2.3, 0); G.add(w); });
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.5, 0.3, 40), std(0x1a2a22, 0.8)); base.position.y = -0.15; G.add(base);
  const R = rnd(2); const gm = std(0x1a1a1a, 0.9); const gr = [];
  for (let i = 0; i < 220; i++) { const a = Math.PI + R() * Math.PI, rr = Math.sqrt(R()) * 1.1; const g = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 4), gm); g.position.set(Math.cos(a) * rr, 0.06 + R() * 0.3, Math.sin(a) * rr * -1 * -1); g.position.z = -Math.abs(g.position.z) + 0.05; G.add(g); gr.push(g); }
  const fm = new THREE.MeshBasicMaterial({ color: 0xffd08a, transparent: true, toneMapped: false, depthWrite: false });
  const flash = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 14), fm); flash.position.y = 0.4; G.add(flash);
  const light = new THREE.PointLight(0xffb060, 0, 14, 2); light.position.set(0, 1.0, 1.2); G.add(light);
  function set(k, gone = false) { flash.visible = k > 0.01; flash.scale.set(1.1 * (0.5 + k), 0.6 + 2.5 * k, 1.1 * (0.5 + k)); fm.opacity = 0.7 * k; light.intensity = 30 * k; gr.forEach(g => g.visible = !gone); }
  set(0);
  return { group: G, set };
}
// smoke puffs (local), u 0..1 grows/fades
export function smoke(n = 12, seed = 4) { const G = new THREE.Group(); const R = rnd(seed); const m = new THREE.MeshStandardMaterial({ color: 0x8a8a90, roughness: 1, transparent: true, opacity: 0.5, depthWrite: false }); const P = []; for (let i = 0; i < n; i++) { const s = new THREE.Mesh(new THREE.IcosahedronGeometry(1, 1), m); G.add(s); P.push({ s, dx: (R() - 0.5) * 2, dy: R() * 2, dz: (R() - 0.5) }); }
  return { group: G, set(u, k = 1) { P.forEach(o => { o.s.position.set(o.dx * (0.4 + u), o.dy * (0.5 + u * 2), o.dz); o.s.scale.setScalar(Math.max(0.001, k * (0.4 + u * 1.4))); o.s.visible = k > 0.02 && u > 0; }); m.opacity = 0.5 * (1 - u) * k; } }; }
// atom: nucleus, two orbit rings, electron, photon wave
export function atom() {
  const G = new THREE.Group(); const R = rnd(6);
  for (let i = 0; i < 14; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.22, 16, 12), std(i % 2 ? 0xe85a4a : 0x9aa0b0, 0.4)); const v = new THREE.Vector3(R() - 0.5, R() - 0.5, R() - 0.5).normalize().multiplyScalar(0.25 * Math.cbrt(R())); s.position.copy(v); G.add(s); }
  const rings = [1.4, 2.4].map(r => { const m = new THREE.Mesh(new THREE.TorusGeometry(r, 0.025, 8, 96), new THREE.MeshBasicMaterial({ color: 0x8ab0ff, transparent: true, opacity: 0.6, toneMapped: false })); G.add(m); return m; });
  const eM = new THREE.MeshBasicMaterial({ color: 0x9ad8ff, toneMapped: false }); const e = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 12), eM); G.add(e);
  const pts = []; for (let i = 0; i <= 120; i++) { const x = i / 120 * 3; pts.push(new THREE.Vector3(x, 0.35 * Math.sin(x * 7) * Math.sin(Math.PI * i / 120), 0)); }
  const phM = new THREE.MeshBasicMaterial({ color: COL.red, toneMapped: false }); const photon = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 120, 0.09, 8), phM); G.add(photon);
  const heatM = new THREE.MeshBasicMaterial({ color: 0xff7a2a, transparent: true, opacity: 0, toneMapped: false, depthWrite: false, blending: THREE.AdditiveBlending }); const heat = new THREE.Mesh(new THREE.SphereGeometry(0.9, 32, 20), heatM); heat.renderOrder = -1; G.add(heat);
  function set(T, jump, phU, heatK) { // jump 0..1 radius blend; phU photon travel 0..1 (<=0 hidden)
    const a = T * 2.2; const r = 1.4 + 1.0 * jump; e.position.set(Math.cos(a) * r, Math.sin(a) * r, 0); e.scale.setScalar(1 + 0.4 * jump);
    rings[1].material.opacity = 0.35 + 0.5 * jump;
    photon.visible = phU > 0 && phU < 1; const ang = Math.atan2(e.position.y, e.position.x);
    if (photon.visible) { photon.rotation.z = 0.6; photon.position.set(Math.cos(0.6) * (1.0 + phU * 2.6), Math.sin(0.6) * (1.0 + phU * 2.6), 0); }
    heatM.opacity = 0.55 * heatK; heat.scale.setScalar(1 + 0.25 * heatK);
    return ang;
  }
  set(0, 0, 0, 0);
  return { group: G, set, electron: e, photon };
}
export { std };
