// Persian qanat reel: cut-away cross-section (hill rising to +x, aquifer, mother well, gently sloping tunnel, access
// shafts with spoil rings, water strip + flowing particles), windlass, mud village, green fields, garden pool.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex } from './rome.js';
import { persiaMats } from './persia.js';
import { glowSprite } from './props.js';

// ground surface height along x (village at x<-22 flat at 0, hill rising to ~22 at x=30)
export const surf = (x) => x < -22 ? 0 : Math.pow((x + 22) / 52, 1.6) * 22;
export const tunnelY = (x) => 0.0 + (x + 24) * 0.06;        // outlet at x=-24 (y=0), rising gently toward the hills
export const MW = 24;                                         // mother well x
export function section({ depth = 6, shafts = 12 } = {}) {
  const P = persiaMats(); const g = new THREE.Group();
  // cross-section face with soil strata, pebbles and darker deep layers (it used to be one flat orange colour)
  const strata = canvasTex(256, 1024, (x) => {
    const R = rng(21); const cols = ['#c8955e', '#b98450', '#a8743f', '#9a6a3c', '#8c5e36', '#7c5232', '#6e482c', '#5e3e26'];
    let y = 0; let i = 0; while (y < 1024) { const h = 40 + R() * 90; x.fillStyle = cols[Math.min(cols.length - 1, Math.floor(y / 1024 * cols.length))]; x.globalAlpha = 1; x.fillRect(0, y, 256, h + 2); x.fillStyle = i % 2 ? 'rgba(255,230,190,0.08)' : 'rgba(40,20,10,0.08)'; x.fillRect(0, y, 256, h); y += h; i++; }
    for (let k = 0; k < 1400; k++) { const r = 0.6 + R() * 1.6; const v = 70 + R() * 50; x.fillStyle = `rgba(${v},${v * 0.72},${v * 0.48},${0.25 + R() * 0.3})`; x.beginPath(); x.ellipse(R() * 256, R() * 1024, r * 1.4, r, R() * 3, 0, 7); x.fill(); }
  });
  strata.wrapS = strata.wrapT = THREE.RepeatWrapping; strata.repeat.set(1 / 12, 1 / 22); strata.offset.set(0, 14 / 22);
  const earthM = new THREE.MeshStandardMaterial({ map: strata, roughness: 1, bumpMap: fabricTexture(31), bumpScale: 2 });
  const sh = new THREE.Shape(); sh.moveTo(-40, -14);
  for (let x = -40; x <= 34; x += 1) sh.lineTo(x, surf(x)); sh.lineTo(34, -14); sh.lineTo(-40, -14);
  const block = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: false }), earthM); block.position.z = -depth; g.add(block);
  const top = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth, bevelEnabled: false }), P.sand); top.scale.set(1, 1, 1); // not used
  // aquifer: blue band under the hills
  const aq = new THREE.Shape(); aq.moveTo(4, tunnelY(4) - 3); for (let x = 4; x <= 34; x++) aq.lineTo(x, tunnelY(x) + 1.2 + (x - 4) * 0.08); aq.lineTo(34, tunnelY(34) - 4); aq.lineTo(4, tunnelY(4) - 3);
  const aqTex = canvasTex(512, 512, (x) => { const R = rng(33); x.fillStyle = '#2f62a0'; x.fillRect(0, 0, 512, 512); for (let k = 0; k < 2600; k++) { const r = 1 + R() * 4; const v = R(); x.fillStyle = v < 0.5 ? `rgba(150,190,230,${0.25 + R() * 0.3})` : `rgba(20,40,80,${0.2 + R() * 0.3})`; x.beginPath(); x.ellipse(R() * 512, R() * 512, r * 1.3, r, R() * 3, 0, 7); x.fill(); } });
  aqTex.wrapS = aqTex.wrapT = THREE.RepeatWrapping; aqTex.repeat.set(0.12, 0.12);
  const aqM = new THREE.MeshStandardMaterial({ map: aqTex, roughness: 0.35, bumpMap: fabricTexture(13), bumpScale: 3 }); // wet gravel, not a flat blue sheet
  const aquifer = new THREE.Mesh(new THREE.ShapeGeometry(aq), aqM); aquifer.position.z = 0.08; g.add(aquifer); // layers spaced out: 0.01-0.04 apart z-fought into stripes at a distance
  const darkM = new THREE.MeshStandardMaterial({ color: 0x24160c, roughness: 1 });
  // tunnel strip (revealed from the outlet toward the mother well via tunnel.scale.x)
  const tg = new THREE.Group(); tg.position.set(-24, 0, 0.16); g.add(tg);
  const tsh = new THREE.Shape(); tsh.moveTo(0, -0.1); tsh.lineTo(MW + 24, tunnelY(MW) - 0.1); tsh.lineTo(MW + 24, tunnelY(MW) + 1.1); tsh.lineTo(0, 1.0); tsh.lineTo(0, -0.1);
  tg.add(new THREE.Mesh(new THREE.ShapeGeometry(tsh), darkM));
  const wsh = new THREE.Shape(); wsh.moveTo(0, -0.1); wsh.lineTo(MW + 24, tunnelY(MW) - 0.1); wsh.lineTo(MW + 24, tunnelY(MW) + 0.25); wsh.lineTo(0, 0.25); wsh.lineTo(0, -0.1);
  const waterM = new THREE.MeshStandardMaterial({ color: 0x5ab8f0, emissive: 0x1a5a9a, emissiveIntensity: 0.8, roughness: 0.2 });
  const wstrip = new THREE.Mesh(new THREE.ShapeGeometry(wsh), waterM); wstrip.position.z = 0.06; tg.add(wstrip);
  // mother well
  const mwH = surf(MW) - tunnelY(MW);
  const mw = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1), darkM); mw.position.set(MW, 0, 0.3); g.add(mw);
  // shafts
  const sx = [...Array(shafts)].map((_, i) => -18 + i * ((MW - 4 + 18) / shafts));
  const shaftM = sx.map(x => { const m = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 1), darkM); m.position.set(x, 0, 0.3); g.add(m); return m; });
  const rings = sx.map(x => { const r = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.45, 8, 16), P.mud); r.rotation.x = Math.PI / 2; r.scale.z = 0.6; r.position.set(x, surf(x) + 0.1, -depth / 2); g.add(r); return r; });
  // flowing water particles
  const drops = [...Array(40)].map(() => { const d = glowSprite(0x9ad8ff, 0.5); d.position.z = 0.45; g.add(d); return d; });
  g.dig = (k) => { tg.scale.x = Math.max(0.001, k); };      // tunnel reveal 0..1 from the outlet
  g.well = (k) => { const h = mwH * k + 0.01; mw.scale.y = h; mw.position.y = surf(MW) - h / 2; };
  g.shafts = (k) => { shaftM.forEach((m, i) => { const x = sx[i]; const on = k * shafts > i; const h = (surf(x) - tunnelY(x) - 0.5) * (on ? 1 : 0) + 0.001; m.scale.y = h; m.position.y = surf(x) - h / 2; rings[i].visible = on; }); };
  g.water = (k, t = 0) => { wstrip.visible = k > 0.01; wstrip.material.opacity = 1; drops.forEach((d, i) => { const u = ((t * 0.05 + i / 40) % 1); const x = MW - u * (MW + 24); d.position.set(x, tunnelY(x) + 0.15, 0.45); d.visible = k > 0.01 && u < k; }); };
  g.dig(1); g.well(1); g.shafts(1); g.water(1);
  g.sx = sx; g.aquifer = aquifer;
  return shadowAll(g);
}
// windlass over a shaft: two posts, crossbar, rope + bucket
export function windlass() {
  const wood = new THREE.MeshStandardMaterial({ color: 0x7a5232, roughness: 0.85 }); const g = new THREE.Group();
  for (const s of [-1, 1]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 1.4, 8), wood); p.position.set(s * 0.8, 0.7, 0); g.add(p); }
  const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.8, 10), wood); bar.rotation.z = Math.PI / 2; bar.position.y = 1.3; g.add(bar);
  const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1, 6), new THREE.MeshStandardMaterial({ color: 0xc8a868, roughness: 0.9 })); g.add(rope);
  const bucket = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.15, 0.3, 14), new THREE.MeshStandardMaterial({ color: 0x5a3a20, roughness: 0.9 })); g.add(bucket);
  g.set = (y) => { bucket.position.set(0, y, 0); rope.position.set(0, (1.3 + y + 0.15) / 2, 0); rope.scale.y = Math.max(0.01, 1.3 - y - 0.15); bar.rotation.x = y * 4; };
  g.set(0.4);
  return shadowAll(g);
}
// mud-brick village houses + green fields + an outlet stream (around origin)
export function village(scene, { seed = 3 } = {}) {
  const P = persiaMats(); const R = rng(seed);
  for (let i = 0; i < 10; i++) { const w = 2 + R() * 2, h = 1.6 + R() * 1.4; const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w * (0.8 + R() * 0.4)), P.mud); b.position.set(-8 + (i % 5) * 3.6 + R(), h / 2, -10 - Math.floor(i / 5) * 4 + R()); b.castShadow = b.receiveShadow = true; scene.add(b); const d = new THREE.Mesh(new THREE.SphereGeometry(w * 0.35, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), P.mud); d.position.set(b.position.x, h, b.position.z); scene.add(d); }
  const fieldM = new THREE.MeshStandardMaterial({ color: 0x5a8a2a, roughness: 0.9, bumpMap: fabricTexture(11), bumpScale: 3 });
  for (let i = 0; i < 6; i++) { const f = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 4.5), fieldM); f.rotation.x = -Math.PI / 2; f.position.set(-7 + (i % 3) * 6, 0.03, 2 + Math.floor(i / 3) * 5); f.receiveShadow = true; scene.add(f); }
  const stream = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 40), new THREE.MeshStandardMaterial({ color: 0x5ab8f0, emissive: 0x1a4a7a, emissiveIntensity: 0.4, roughness: 0.1 })); stream.rotation.x = -Math.PI / 2; stream.position.set(-1, 0.05, -2); scene.add(stream);
}
// Persian garden pool with fountain jets
export function gardenPool() {
  const P = persiaMats(); const g = new THREE.Group();
  const rim = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.4, 10.4), new THREE.MeshStandardMaterial({ color: 0xd8ccb0, roughness: 0.7 })); rim.position.y = 0.2; g.add(rim);
  const w = new THREE.Mesh(new THREE.BoxGeometry(4.0, 0.05, 10.0), new THREE.MeshStandardMaterial({ color: 0x3a8ac8, emissive: 0x0a3a6a, emissiveIntensity: 0.4, roughness: 0.05 })); w.position.y = 0.38; g.add(w);
  // fountains: arcs of droplets (solid cylinders read as white poles)
  const N = 5 * 60, dropM = new THREE.MeshStandardMaterial({ color: 0xdff4ff, emissive: 0x6aa8d8, emissiveIntensity: 0.5, roughness: 0.1, transparent: true, opacity: 0.6 });
  const fj = new THREE.InstancedMesh(new THREE.SphereGeometry(0.018, 6, 4), dropM, N); g.add(fj); const dm = new THREE.Matrix4();
  const rings = [...Array(5)].map((_, i) => { const r = new THREE.Mesh(new THREE.RingGeometry(0.15, 0.32, 24), new THREE.MeshBasicMaterial({ color: 0xeaf8ff, transparent: true, opacity: 0.5 })); r.rotation.x = -Math.PI / 2; r.position.set(0, 0.42, -4 + i * 2); g.add(r); return r; });
  g.update = (t) => { for (let n = 0; n < N; n++) { const f = Math.floor(n / 60), i = n % 60; const u = (t * 0.9 + i / 60) % 1; const a = i * 2.39996; const rr = u * 0.42; dm.makeTranslation(Math.cos(a) * rr, 0.42 + 1.1 * 4 * u * (1 - u), -4 + f * 2 + Math.sin(a) * rr); fj.setMatrixAt(n, dm); } fj.instanceMatrix.needsUpdate = true; rings.forEach((r, i) => r.scale.setScalar(1 + 0.15 * Math.sin(t * 6 + i))); };
  g.update(0);
  const tm = new THREE.MeshStandardMaterial({ color: 0x2f5a2a, roughness: 0.9 });
  for (let i = 0; i < 8; i++) { const c = new THREE.Mesh(new THREE.ConeGeometry(0.5, 3.4, 10), tm); c.position.set(i % 2 ? 3.2 : -3.2, 1.7, -4.5 + Math.floor(i / 2) * 3); c.castShadow = true; g.add(c); }
  return shadowAll(g);
}
