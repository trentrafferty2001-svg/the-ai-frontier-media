// The Explainer: how the Falkirk Wheel lifts boats. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { LIFT, ARM, HUB, GL, ANG_DOWN, site, wheel, boat, kettle, scaleSet, waterMat } from './wheel.js';
import { label } from './gps.js';
import { VO } from './vo_fw.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This *giant wheel*', 3], ['*lifts* boats', 2], ['*24 metres*', 3], ['using about', 2], ['as much power', 3], ['as boiling', 2], ['*eight kettles*', 2]],
  [["It's the", 2], ['*Falkirk Wheel*', 2], ['in *Scotland*', 2], ['the *only*', 2], ['*rotating* boat lift', 3], ['in the world', 3]],
  [['It joins', 2], ['*two canals*', 2], ['one *high up*', 3], ['one *down below*', 3]],
  [['Each end holds', 3], ['a huge *tank*', 3], ['of *water*', 2], ['called a *gondola*', 3]],
  [['A *boat* floats', 3], ['into the', 2], ['*bottom* one', 2], ['and *gates*', 2], ['*seal* it in', 3]],
  [["Here's the *trick*", 3], ['A floating boat', 3], ['*pushes out*', 2], ['exactly its', 2], ['*own weight*', 2], ['in *water*', 2]],
  [['So both gondolas', 3], ['always weigh', 2], ['*the same*', 2], ['boat or', 2], ['*no boat*', 2]],
  [['That *balance*', 2], ['means the motors', 3], ['*barely work*', 2], ['They just', 2], ['*turn* it', 2]],
  [['As it rotates', 3], ['*gears*', 1], ['keep each gondola', 3], ['*level*', 1], ['so *nothing spills*', 3]],
  [['About', 1], ['*four minutes* later', 3], ['the boat', 2], ['*floats out*', 2], ['*24 metres*', 3], ['*higher*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.05; c.far = 1500; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.4, warm: 1.08, sat: 1.15, exposure: 1.0, flare: 0.4 };
function world(makeStage, sun = [0.55, 0.6, 0.6]) {
  const scene = makeStage({ outdoor: 'day', sunDir: sun, fog: 0.0012, shadowSize: 45, shadowAt: [0, 8, 0], envI: 0.9, cloud: 0.3 });
  scene.userData.key.shadow.camera.far = 400;
  const S = site(scene);
  const Wh = wheel(); scene.add(Wh.group);
  return { scene, S, Wh };
}
// a boat riding inside gondola i (local y so the hull sits in the water at y = 1.5)
function boatIn(Wh, i, z = 0) { const b = boat(); b.position.set(0, 1.5, z); Wh.gondolas[i].group.add(b); return b; }

// ============ S0 hook: the wheel turning with a boat aboard; eight kettles steam in the foreground ============
function sHook({ makeStage }) {
  const { scene, Wh } = world(makeStage);
  boatIn(Wh, 0);
  const ks = []; for (let k = 0; k < 8; k++) { const kt = kettle([0xd94b3d, 0x2f7fd8, 0xf2c14e, 0x3fbf5a][k % 4]); kt.group.scale.setScalar(2.2); scene.add(kt.group); ks.push(kt); }
  const c = C(40);
  const TK = at(0, 'eight') - ls(0);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN + 0.5 + t * 0.12; Wh.st.gates = 1; Wh.update();
      const k = easeInOut(range(t, 0, 6.2));
      const camPos = new THREE.Vector3(lerp(8, 14, k), lerp(6, 9, k), lerp(70, 84, k));
      place(c, camPos.toArray(), [0, lerp(14, 12, k), 0]);
      // kettles in a row just in front of the camera, lower third; they pop up and steam on "eight kettles"
      const fwd = new THREE.Vector3(0, 13, 0).sub(camPos).normalize(), right = new THREE.Vector3().crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();
      ks.forEach((kt, i) => { const pop = easeOut(range(t, TK - 0.4 + i * 0.07, TK + i * 0.07)); const p = camPos.clone().addScaledVector(fwd, 22).addScaledVector(right, (i - 3.5) * 1.55).add(new THREE.Vector3(0, -7.2 + 0.3 * (1 - pop), 0)); kt.group.position.copy(p); kt.group.scale.setScalar(1.4 * pop); kt.group.visible = pop > 0.01; kt.group.lookAt(camPos.x, p.y, camPos.z); kt.setSteam(t, pop); });
      return POST;
    },
  };
}
// ============ S1: aerial over the wheel and both canals ============
function sAerial({ makeStage }) {
  const { scene, Wh } = world(makeStage); boatIn(Wh, 1);
  const c = C(42);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN; Wh.update();
      const k = easeInOut(range(t, 0, 4.6));
      orb(c, [0, 10, -10], lerp(110, 95, k), lerp(130, 160, k), lerp(32, 26, k));
      return POST;
    },
  };
}
// ============ S2: the high canal (aqueduct) and the low basin ============
function sCanals({ makeStage }) {
  const { scene, Wh } = world(makeStage);
  const c = C(40);
  const TH = at(2, 'high') - ls(2), TD = at(2, 'down') - ls(2);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN; Wh.update();
      const k = easeInOut(range(t, TH - 0.4, TD + 0.3));
      place(c, [26, lerp(30, 6, k), lerp(-40, 40, k)], [0, lerp(LIFT, 0.5, k), lerp(-45, 25, k)]);
      return POST;
    },
  };
}
// ============ S3: a gondola close up: a huge tank of water ============
function sGondola({ makeStage }) {
  const { scene, Wh } = world(makeStage);
  const c = C(38);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN; Wh.update();
      const g = Wh.gondolas[1].group.position;
      const k = easeInOut(range(t, 0, 3.3));
      orb(c, [g.x, g.y + 1.0, g.z], lerp(30, 22, k), lerp(40, 25, k), lerp(28, 22, k));
      return POST;
    },
  };
}
// ============ S4: a boat floats into the bottom gondola; the gates close ============
function sEnter({ makeStage }) {
  const { scene, Wh } = world(makeStage);
  const b = boat(); scene.add(b);
  const c = C(40);
  const TG = at(4, 'gates') - ls(4);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN; Wh.st.gates = 1 - smooth(range(t, TG - 0.2, TG + 0.6)); Wh.update();
      b.position.set(0, 0, lerp(32, 0, easeOut(range(t, 0, TG - 0.3)))); b.rotation.y = Math.PI;
      orb(c, [0, 2, lerp(16, 4, smooth(range(t, 0, TG)))], 30, 35, 22);
      return POST;
    },
  };
}
// ============ S5: Archimedes: the boat pushes out its own weight of water; the scale does not change ============
function sArchimedes({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [2, 5, 3] });
  const S = scaleSet(); scene.add(S.group);
  const b = boat(); b.scale.setScalar(0.2); scene.add(b);
  const L = label('500.0 kg', { size: 0.55, color: '#7dff9a' }); L.sprite.position.set(0.6, 3.0, 0); scene.add(L.sprite);
  const c = C(36);
  const TP = at(5, 'pushes') - ls(5), TW = at(5, 'weight') - ls(5);
  return {
    scene, camera: c,
    update(t) {
      const k = smooth(range(t, TP - 1.0, TP + 0.4));
      b.position.set(0, lerp(3.2, 1.75, k), 0); b.rotation.y = Math.PI / 2;
      const pour = smooth(range(t, TP - 0.4, TW + 0.4)); S.set(pour, pour);
      // reading wobbles while the boat lands, then settles back to exactly the same number
      const wob = Math.sin(t * 18) * 3 * Math.exp(-Math.pow((t - TP) / 0.35, 2));
      L.set(`${(500 + wob).toFixed(1)} kg`);
      orb(c, [0.9, 1.3, 0], lerp(8.6, 7.8, smooth(range(t, 0, 4.4))), 12, 14);
      return { ...POST, flare: 0 };
    },
  };
}
// ============ S6: both gondolas weigh the same: a balance beam stays level ============
function sBalance({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [2, 5, 3] });
  const beamM = new THREE.MeshStandardMaterial({ color: 0x9aa3ad, metalness: 0.8, roughness: 0.3 });
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.14, 2.2, 16), beamM); post.position.y = 1.1; scene.add(post);
  const beam = new THREE.Group(); beam.position.y = 2.25; scene.add(beam);
  beam.add(new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.1, 0.12), beamM));
  const trays = [-1.1, 1.1].map((x) => { const tr = new THREE.Group(); tr.position.x = x; beam.add(tr); const ch = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.8, 6), beamM); ch.position.y = -0.4; tr.add(ch);
    const tank = new THREE.Mesh(new RoundedBoxGeometryLike(0.9, 0.45, 0.6), new THREE.MeshStandardMaterial({ color: 0xc9cfd6, metalness: 0.7, roughness: 0.3 })); tank.position.y = -1.0; tr.add(tank);
    const w = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.02, 0.55), waterMat()); w.position.y = -0.76; tr.add(w); return tr; });
  const b = boat(); b.scale.setScalar(0.07); b.rotation.y = Math.PI / 2; b.position.set(0, -0.8, 0); trays[1].add(b);
  const c = C(36);
  const TN = at(6, 'no') - ls(6);
  return {
    scene, camera: c,
    update(t) {
      const tilt = 0.0 + 0.02 * Math.sin(t * 2.2) * Math.exp(-t * 0.8); beam.rotation.z = tilt; trays.forEach((tr) => { tr.rotation.z = -tilt; });
      b.visible = !(t > TN - 0.2 && t < TN + 1.0);
      orb(c, [0, 1.5, 0], 6.2, lerp(-8, 8, smooth(range(t, 0, 3.4))), 8);
      return { ...POST, flare: 0 };
    },
  };
}
function RoundedBoxGeometryLike(w, h, d) { return new THREE.BoxGeometry(w, h, d); }
// ============ S7: small motors turn the giant wheel ============
function sMotor({ makeStage }) {
  const { scene, Wh } = world(makeStage); boatIn(Wh, 0);
  const c = C(36);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN + 0.3 + t * 0.09; Wh.update();
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [0, HUB, 0], lerp(58, 70, k), lerp(25, 15, k), lerp(6, 12, k));
      return POST;
    },
  };
}
// ============ S8: gears keep the gondolas level as the wheel turns ============
function sGears({ makeStage }) {
  const { scene, Wh } = world(makeStage); boatIn(Wh, 0);
  const c = C(38);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN + 0.4 + t * 0.35; Wh.st.gears = 1; Wh.update();
      const k = easeInOut(range(t, 0, 3.8));
      orb(c, [0, HUB, GL / 2 + 3], lerp(44, 52, k), 0, lerp(6, 10, k));
      return POST;
    },
  };
}
// ============ S9: four minutes later: the boat floats out onto the aqueduct, 24 m up ============
function sOut({ makeStage }) {
  const { scene, Wh } = world(makeStage);
  const b = boat(); scene.add(b);
  const c = C(40);
  const TF = at(9, 'floats') - ls(9);
  return {
    scene, camera: c,
    update(t) {
      Wh.st.angle = ANG_DOWN - Math.PI * (1 - smooth(range(t, 0, 1.4))) * 0.08 - Math.PI; Wh.st.gates = smooth(range(t, TF - 0.8, TF - 0.2)) * 0 + (t < TF - 0.6 ? 1 : 0); Wh.update();
      b.position.set(0, LIFT, lerp(0, -30, easeIn(range(t, TF - 0.5, TF + 3.0)))); b.rotation.y = 0;
      const k = easeInOut(range(t, 0, 5.4));
      orb(c, [0, LIFT - 4, lerp(-4, -16, k)], lerp(42, 56, k), lerp(55, 40, k), lerp(14, 18, k));
      return POST;
    },
  };
}

// ============ timeline ============
const SH = [sHook, sAerial, sCanals, sGondola, sEnter, sArchimedes, sBalance, sMotor, sGears, sOut];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
