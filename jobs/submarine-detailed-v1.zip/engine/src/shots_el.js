// The Explainer: why lifts can't free-fall. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { shaft, car, counterweight, governor, cables, demo, TOPY, std } from './lift.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_el.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['In *1854*', 4], ['a man stood', 3], ['on a *lift*', 3], ['and had', 2], ['the *only rope*', 3], ['holding it *cut*', 3], ["It *didn't fall*", 3]],
  [["Today's lifts", 2], ['hang from', 2], ['*several*', 1], ['*steel cables*', 2], ['and usually', 2], ['*each one*', 2], ['could hold', 2], ['the car', 2], ['on its own', 3]],
  [['A heavy', 2], ['*counterweight*', 1], ['*balances* the load', 3], ['so the motor', 3], ['*barely* has', 2], ['to lift', 2]],
  [['But the real', 3], ['*safety trick*', 2], ['is a *second loop*', 4], ['of cable', 2], ['linked to a', 3], ['*spinning*', 1], ['*governor*', 1], ['at the top', 3]],
  [['If the car', 3], ['moves *too fast*', 3], ['*weights* inside', 2], ['the governor', 2], ['*swing outwards*', 2], ['and *lock* it', 3]],
  [['That *yanks*', 2], ['a *lever*', 2], ['on the car', 3], ['which *jams*', 2], ['*steel wedges*', 2], ['against the', 2], ['*guide rails*', 2]],
  [['The car', 2], ['*squeezes*', 1], ['to a *stop*', 3]],
  [['And at the', 3], ['very *bottom*', 2], ['*springs*', 1], ['or *oil buffers*', 3], ['*cushion*', 1], ['any landing', 2]],
  [['So even if', 3], ['*every cable*', 2], ['*snapped*', 1], ['the lift would', 3], ['*brake itself*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.05; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.4, warm: 1.02, sat: 1.12, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

// modern shaft world
function world(makeStage) {
  const scene = makeStage({ shadowSize: 8, sunDir: [3, 30, 12] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x2a3240); u.mid.value.set(0x343c4a); u.horizon.value.set(0x3c4452); u.floorC.value.set(0x1a1e26); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xfff6ea, 0x404048, 1.0));
  for (let k = 0; k < 4; k++) { const l = new THREE.PointLight(0xfff0d8, 25, 14); l.position.set(0, 3 + k * 7, 2.5); scene.add(l); }
  const S = shaft(); scene.add(S.group); const Cr = car(); scene.add(Cr.group); const CW = counterweight(); scene.add(CW.group); CW.group.position.set(-2.14, 0, 0);
  const K = cables(); scene.add(K.group); const Gv = governor(); scene.add(Gv.group, Gv.outer);
  return { scene, S, Cr, CW, K, Gv };
}
// position car (bottom y) and counterweight (bottom y) so cables stay the same total length
function placeCar(W, y) { W.Cr.group.position.y = y; const cw = TOPY - 6 - (y - 6); W.CW.group.position.y = Math.max(-1.2, Math.min(TOPY - 4, cw)); }

// ============ S0 hook: 1854, rope cut, the platform catches itself ============
function sHook({ makeStage }) {
  const scene = makeStage({ shadowSize: 8, sunDir: [3, 10, 6] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x6a5a48); u.mid.value.set(0x8a7458); u.horizon.value.set(0x9a8264); u.floorC.value.set(0x4a3a2a); }
  const D = demo(); scene.add(D.group);
  const L = tag(scene, '1854', 0.7, '#ffe8b0', [0, 10.2, 0]);
  const c = C(40); const tc = at(0, 'cut');
  return {
    scene, camera: c,
    update(t) {
      const drop = t < tc ? 0 : easeIn(range(t, tc, tc + 0.22)) * 0.45; const catchK = smooth(range(t, tc + 0.15, tc + 0.3));
      D.set(5 - drop, t > tc ? range(t, tc, tc + 0.5) : 0, catchK);
      pop(L, easeOut(range(t, 0.1, 0.5)), 0.7);
      const sh = t > tc + 0.2 && t < tc + 0.8 ? 0.08 * Math.sin(t * 60) * (1 - range(t, tc + 0.2, tc + 0.8)) : 0;
      const k = easeInOut(range(t, 0, 6.3));
      orb(c, [sh, lerp(7.5, 6.0, k), 0], lerp(14, 9.5, k), lerp(20, 10, k), lerp(6, 4, k));
      return { ...POST, warm: 1.15, sat: 0.9 };
    },
  };
}
// ============ S1: modern lift, several cables, each strong enough ============
function sCables({ makeStage }) {
  const W = world(makeStage); placeCar(W, 12);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.Cr.update(T); W.Gv.update(T);
      const each = at(1, 'each'); const idx = T > each - 0.1 ? Math.min(5, Math.floor((T - each + 0.1) / 0.35)) : -1; const g = T > at(1, 'several') - 0.1 && T < each - 0.1 ? 99 : idx;
      W.K.set(12, W.CW.group.position.y, g, 1);
      const k = easeInOut(range(t, 0, 5.6));
      orb(c, [0, lerp(15, 16.5, k), 0], lerp(15, 13, k), lerp(-4, 8, k), lerp(-4, 6, k));
      return POST;
    },
  };
}
// ============ S2: counterweight balances the load ============
function sCounter({ makeStage }) {
  const W = world(makeStage);
  const L = tag(W.scene, 'counterweight', 0.8, '#ffe14a', [-0.6, 0, 1.0]);
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const y = lerp(4, 14, smooth(range(t, 0.2, 4.4))); placeCar(W, y); W.Cr.update(T); W.Gv.st.spin = T * 2; W.Gv.update(T); W.K.set(y, W.CW.group.position.y);
      L.position.y = W.CW.group.position.y + 3.2; pop(L, easeOut(range(T, at(2, 'counterweight') - 0.15, at(2, 'counterweight') + 0.2)), 0.8);
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0, lerp(8, 13, k), -0.6], 19, lerp(6, 14, k), lerp(4, 8, k));
      return POST;
    },
  };
}
// ============ S3: the governor and its rope loop at the top ============
function sGovernor({ makeStage }) {
  const W = world(makeStage); placeCar(W, 16);
  const L = tag(W.scene, 'governor', 0.4, '#ffe14a', [1.95, TOPY + 1.2, 0.5]);
  const c = C(38);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.Cr.update(T); W.K.set(16, W.CW.group.position.y); W.Gv.st.spin = T * 2; W.Gv.st.glow = smooth(range(T, at(3, 'second') - 0.2, at(3, 'loop') + 0.3)); W.Gv.update(T);
      pop(L, easeOut(range(T, at(3, 'governor') - 0.15, at(3, 'governor') + 0.2)), 0.4);
      const k = easeInOut(range(t, 0, 5.2));
      orb(c, [1.4, lerp(20, 24.6, k), 0.3], lerp(9, 5.2, k), lerp(10, 26, k), lerp(-4, 0, k));
      return POST;
    },
  };
}
// ============ S4: overspeed: car drops fast, governor flyweights fly out and lock ============
function sOverspeed({ makeStage }) {
  const W = world(makeStage);
  const c = C(38); const t0 = ls(4);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const fall = 0.5 * 2.4 * Math.max(0, t) ** 2; const y = 20 - Math.min(fall, 14); placeCar(W, y); W.Cr.update(T); W.K.set(y, W.CW.group.position.y);
      const sp = 2 * T + 3 * t * t; W.Gv.st.spin = sp; W.Gv.st.out = smooth(range(T, at(4, 'weights') - 0.3, at(4, 'swing') + 0.3)); W.Gv.st.lock = smooth(range(T, at(4, 'lock') - 0.2, at(4, 'lock') + 0.15)); W.Gv.update(T);
      const k = easeInOut(range(t, 0, 2.0));
      orb(c, [1.95, TOPY - 0.2, 0.35], lerp(3.4, 2.6, k), lerp(12, 4, k), 2);
      return POST;
    },
  };
}
// ============ S5/S6: lever yanks, wedges jam the rails, car squeezes to a stop ============
function sWedges({ makeStage }) {
  const W = world(makeStage); const R = rnd(4); const sparks = []; const sm = new THREE.MeshBasicMaterial({ color: 0xffd060, toneMapped: false });
  for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 4), sm); W.scene.add(m); sparks.push({ m, s: R() < 0.5 ? -1 : 1, vx: R(), vy: R(), ph: R() }); }
  const c = C(38); const tj = at(5, 'jams');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const v = 3.2 * (1 - smooth(range(T, tj, at(6, 'stop')))); const y = 9 - (T < tj ? (T - ls(5)) * 3.2 : (tj - ls(5)) * 3.2 + (T - tj) * 1.6 * (1 - 0.5 * range(T, tj, at(6, 'stop'))));
      placeCar(W, y); W.Cr.st.trip = smooth(range(T, at(5, 'yanks') - 0.1, tj + 0.2)); W.Cr.update(T); W.K.set(y, W.CW.group.position.y);
      sparks.forEach(o => { const u = ((o.ph + T * 2) % 1); o.m.visible = T > tj && v > 0.3; o.m.position.set(o.s * (1.38 + o.vx * 0.5 * u), y - 0.3 + o.vy * 0.6 * u - 1.5 * u * u, 0.3); });
      const k = easeInOut(range(t, 0, 6));
      orb(c, [1.0, y + 0.4, 0.2], lerp(4.2, 3.4, k), lerp(28, 18, k), lerp(-8, -2, k));
      return { ...POST, bloom: 0.6 };
    },
  };
}
// ============ S7: pit buffers cushion a landing ============
function sBuffers({ makeStage }) {
  const W = world(makeStage);
  const c = C(40); const tl = at(7, 'cushion');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const land = smooth(range(T, at(7, 'springs') - 0.4, tl)); const squash = smooth(range(T, tl - 0.25, tl + 0.3)); const y = lerp(3.2, 0.0, land) - 0.25 * squash;
      placeCar(W, y); W.Cr.update(T); W.K.set(y, W.CW.group.position.y);
      W.S.buffers.forEach(b => { b.scale.y = 1 - 0.3 * squash; });
      const k = easeInOut(range(t, 0, 3.9));
      orb(c, [0, 0.8, 0.2], lerp(6.5, 5.8, k), lerp(-24, -10, k), lerp(14, 8, k));
      return POST;
    },
  };
}
// ============ S8: every cable snapped, the lift still holds on the rails ============
function sEnd({ makeStage }) {
  const W = world(makeStage); placeCar(W, 10);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const cut = smooth(range(T, at(8, 'snapped') - 0.2, at(8, 'snapped') + 0.6)); const y = 10 - 0.35 * cut;
      W.Cr.group.position.y = y; W.Cr.st.trip = cut; W.Cr.update(T); W.K.set(y, W.CW.group.position.y, -1, 0, cut);
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [0, lerp(11.5, 12.5, k), 0], lerp(11, 17, k), lerp(8, 16, k), lerp(4, 10, k));
      return POST;
    },
  };
}

const SH = [sHook, sCables, sCounter, sGovernor, sOverspeed, sWedges, sWedges, sBuffers, sEnd];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
