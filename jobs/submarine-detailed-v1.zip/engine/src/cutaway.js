// Cut-away paddy diorama v4: soil strata, progressive trench, grassy bunds, see-through water, bamboo inlet.
import * as THREE from 'three';
import { NOISE, TIME, waterMaterial } from './world.js';
import { riceClumps } from './farm2.js';
import { carp } from './farm2.js';
import { rng } from './textures.js';

function soilMaterial(top) {
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.92 });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uTop = { value: top };
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;')
      .replace('#include <project_vertex>', '#include <project_vertex>\nvWP = (modelMatrix * vec4(transformed, 1.0)).xyz; vWN = normalize(mat3(modelMatrix) * objectNormal);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWP; varying vec3 vWN; uniform float uTop;\n${NOISE}`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        float d = uTop - vWP.y + (vnoise(vec2(vWP.x + vWP.z, vWP.y) * 9.0) - 0.5) * 0.035;
        vec3 wet = vec3(0.075, 0.05, 0.032), topsoil = vec3(0.13, 0.085, 0.05), clay = vec3(0.3, 0.16, 0.07), sub = vec3(0.24, 0.19, 0.12);
        vec3 c = mix(wet, topsoil, smoothstep(0.02, 0.05, d));
        c = mix(c, clay, smoothstep(0.17, 0.22, d));
        c = mix(c, sub, smoothstep(0.42, 0.5, d));
        vec2 sq = vec2(vWP.x + vWP.z * 0.7, vWP.y) * 70.0;
        float pb = smoothstep(0.86, 0.95, hash12(floor(sq))) * smoothstep(0.5, 0.2, length(fract(sq) - 0.5));
        c = mix(c, vec3(0.42, 0.38, 0.32), pb * 0.6);
        float roots = smoothstep(0.85, 1.0, sin((vWP.x + vWP.z) * 90.0 + vnoise(vec2(vWP.x + vWP.z, vWP.y) * 25.0) * 9.0)) * (1.0 - smoothstep(0.05, 0.16, d));
        c = mix(c, vec3(0.45, 0.38, 0.24), roots * 0.45);
        c *= 0.85 + 0.3 * vnoise(vec2(vWP.x + vWP.z, vWP.y) * 40.0);
        if (vWN.y > 0.6) c = vec3(0.1, 0.068, 0.042) * (0.75 + 0.5 * vnoise(vWP.xz * 18.0));
        diffuseColor.rgb = c;`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
        if (vWN.y > 0.6) roughnessFactor = mix(0.5, 0.95, vnoise(vWP.xz * 6.0));`);
  };
  return m;
}

export function cutawayField(scene, { W = 1.3, D = 1.6, TOP = 0.4, BOT = -0.32, TR = 0.24, SEG = 14 } = {}) {
  const g = new THREE.Group(); scene.add(g);
  const soil = soilMaterial(TOP);
  const R = rng(13);
  // main block
  const main = new THREE.Mesh(new THREE.BoxGeometry(W - TR, TOP - BOT, D), soil); main.position.set(TR / 2, (TOP + BOT) / 2, 0);
  main.castShadow = main.receiveShadow = true; g.add(main);
  // trench strip: segments that dig down one by one
  const segs = [];
  for (let i = 0; i < SEG; i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(TR, 1, D / SEG), soil);
    m.castShadow = m.receiveShadow = true; g.add(m); segs.push(m);
  }
  const TB = 0.13; // trench bottom
  // bunds with grass
  const grassMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95 });
  grassMat.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWP; varying vec3 vWN;')
      .replace('#include <project_vertex>', '#include <project_vertex>\nvWP = (modelMatrix * vec4(transformed, 1.0)).xyz; vWN = normalize(mat3(modelMatrix) * objectNormal);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWP; varying vec3 vWN;\n${NOISE}`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        float n = fbm(vec2(vWP.x + vWP.z, vWP.y) * 30.0 + vWP.xz * 20.0);
        vec3 mudC = vec3(0.12, 0.085, 0.05) * (0.8 + 0.5 * n);
        vec3 grassC = mix(vec3(0.12, 0.25, 0.05), vec3(0.25, 0.4, 0.1), n);
        float g = vWN.y > 0.6 ? 1.0 : smoothstep(0.45, 0.75, n + (vWP.y - 0.4) * 2.0);
        diffuseColor.rgb = mix(mudC, grassC, g);`);
  };
  const walls = [];
  const mk = (w, d, x, z) => {
    const wall = new THREE.Group(); wall.position.set(x, TOP, z); g.add(wall);
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, 1, d), grassMat); b.position.y = 0.5; b.castShadow = b.receiveShadow = true; wall.add(b);
    const spots = [];
    const n = Math.round(Math.max(w, d) / 0.035);
    for (let i = 0; i < n; i++) { const u = (i + 0.5) / n - 0.5; spots.push([w > d ? u * w : (R() - 0.5) * w * 0.8, 1, w > d ? (R() - 0.5) * d * 0.8 : u * d]); }
    const gr = riceClumps(spots, { h: 0.07, hVar: 0.5, blades: 5, width: 0.006, color: 0x3f7a22, color2: 0x86b84a, spread: 0.8, sway: 0.01, seed: 70 + walls.length, cast: false });
    wall.add(gr);
    walls.push({ wall, b, gr });
  };
  mk(W + 0.08, 0.07, 0, D / 2 + 0.035); mk(W + 0.08, 0.07, 0, -D / 2 - 0.035); mk(0.07, D, -W / 2 - 0.035, 0); mk(0.07, D, W / 2 + 0.035, 0);
  // water body (front cut face visible) and rippled top
  const bodyMat = new THREE.MeshPhysicalMaterial({ color: 0x3d8c7a, roughness: 0.15, transparent: true, opacity: 0.42, depthWrite: false });
  const body = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), bodyMat); body.renderOrder = 3; g.add(body);
  const topW = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), waterMaterial({ color: 0x2a5a4c, opacity: 0.72 })); topW.rotation.x = -Math.PI / 2; topW.renderOrder = 4; g.add(topW);
  // bamboo inlet pipe at the back left
  const bamboo = new THREE.MeshStandardMaterial({ color: 0x9aa64a, roughness: 0.55 });
  const pipe = new THREE.Group(); pipe.position.set(-W / 2 + 0.1, TOP + 0.24, -D / 2 - 0.25); pipe.rotation.set(0.25, 0, 0); g.add(pipe);
  const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 0.6, 16, 1, true), bamboo); tube.rotation.x = Math.PI / 2; pipe.add(tube);
  for (const z of [-0.2, 0.05]) { const n = new THREE.Mesh(new THREE.TorusGeometry(0.029, 0.006, 6, 16), new THREE.MeshStandardMaterial({ color: 0x7d8838, roughness: 0.6 })); n.position.z = z; pipe.add(n); }
  pipe.traverse(o => { if (o.isMesh) o.castShadow = true; });
  const mouth = new THREE.Vector3(0, 0, 0.3);
  const streamMat = new THREE.MeshPhysicalMaterial({ color: 0xd7f0ff, roughness: 0.05, transparent: true, opacity: 0.6, clearcoat: 1, envMapIntensity: 1.8, depthWrite: false });
  let stream = null;
  // shovel and dirt
  const shovel = new THREE.Group();
  const wood = new THREE.MeshStandardMaterial({ color: 0x8a6440, roughness: 0.7 });
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.012, 0.62, 10), wood); handle.position.y = 0.32; shovel.add(handle);
  const grip = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.008, 8, 16), wood); grip.position.y = 0.66; shovel.add(grip);
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.15, 0.008), new THREE.MeshPhysicalMaterial({ color: 0xa9adb2, metalness: 1, roughness: 0.32 })); blade.position.y = -0.06; shovel.add(blade);
  shovel.traverse(o => { if (o.isMesh) o.castShadow = true; });
  scene.add(shovel);
  const clodMat = new THREE.MeshStandardMaterial({ color: 0x3a281a, roughness: 0.95 });
  const clods = [...Array(6)].map(() => { const c = new THREE.Mesh(new THREE.IcosahedronGeometry(1, 0), clodMat); c.castShadow = true; scene.add(c); return c; });
  const fishes = [carp(0.13, { seed: 21 }), carp(0.11, { seed: 22 })];
  fishes.forEach(f => g.add(f));
  const zOf = (i) => -D / 2 + (i + 0.5) * D / SEG;

  const set = ({ dig = 0, wall = 0, level = 0, fishOn = 0, t = 0, shovelOn = false, inflow = 0 }) => {
    // trench: the shovel works from the front (+z) toward the back
    const front = lerp(D / 2 + 0.1, -D / 2 - 0.1, dig);
    segs.forEach((m, i) => {
      const z = zOf(i);
      const k = smooth(clamp((z - front) / 0.18 + 0.5));
      const top = lerp(TOP, TB, k);
      m.scale.y = top - BOT; m.position.set(-W / 2 + TR / 2, (top + BOT) / 2, z);
    });
    // walls
    const wh = 0.015 + 0.14 * wall;
    for (const { b, gr } of walls) { b.scale.y = wh; b.position.y = wh / 2 - 0.005; gr.position.y = wh - 1 - 0.005; gr.visible = wall > 0.02; }
    // water
    const lv = lerp(TB, TOP + 0.11, level);
    const full = lv > TOP;
    body.visible = topW.visible = level > 0.001;
    const xw = full ? W - 0.004 : TR - 0.004, xc = full ? 0 : -W / 2 + TR / 2;
    body.scale.set(xw, Math.max(0.001, lv - TB), D - 0.004); body.position.set(xc, (lv + TB) / 2, 0);
    topW.scale.set(xw, D - 0.004, 1); topW.position.set(xc, lv + 0.001, 0);
    // inlet stream
    if (stream) { g.remove(stream); stream.geometry.dispose(); stream = null; }
    if (inflow > 0.01) {
      pipe.updateMatrixWorld(true);
      const m0 = g.worldToLocal(pipe.localToWorld(mouth.clone()));
      const pts = [];
      for (let i = 0; i <= 12; i++) { const s = i / 12; pts.push(new THREE.Vector3(m0.x, m0.y - (m0.y - lv) * s * s, m0.z + 0.22 * s)); }
      stream = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 16, 0.016 * inflow, 8), streamMat);
      g.add(stream);
    }
    // shovel scoops along the trench
    shovel.visible = shovelOn;
    clods.forEach(c => c.visible = false);
    if (shovelOn) {
      const cyc = (t * 2.2) % 1, lift = Math.max(0, Math.sin(cyc * Math.PI * 2));
      const z = clamp(front, -D / 2 + 0.1, D / 2 - 0.1);
      shovel.position.set(-W / 2 + TR / 2 - 0.02, lerp(TOP, TB, 0.7) + 0.05 + lift * 0.14, z);
      shovel.rotation.set(0.35 + Math.sin(cyc * Math.PI * 2) * 0.35, 0, 0.18);
      clods.forEach((c, i) => {
        const u = (cyc - 0.25 - i * 0.02);
        if (u > 0 && u < 0.55) {
          c.visible = true;
          c.position.set(-W / 2 - 0.05 - u * (0.5 + i * 0.06), TOP + 0.12 + u * 0.9 - u * u * 2.6, z + (i - 2.5) * 0.02);
          c.scale.setScalar(0.012 + (i % 3) * 0.005); c.rotation.set(u * 9, u * 7 + i, 0);
        }
      });
    }
    // fish sheltering in the trench
    fishes.forEach((f, i) => {
      f.visible = fishOn > 0;
      const z = lerp(0.9, (i ? -0.3 : 0.2), easeOut(fishOn)) + Math.sin(t * 1.5 + i) * 0.03;
      f.position.set(-W / 2 + TR / 2 + (i ? 0.03 : -0.03), TB + 0.06 + i * 0.04, z);
      f.face(new THREE.Vector3(0, 0, -1)); f.swim(t + i, 10, 0.4);
    });
  };
  return { set, group: g };
}
const lerp = (a, b, k) => a + (b - a) * k;
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const smooth = (t) => t * t * (3 - 2 * t);
const easeOut = (t) => 1 - (1 - clamp(t)) ** 3;
