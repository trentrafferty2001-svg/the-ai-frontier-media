// The Explainer: how your fridge pushes heat out. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { kitchen, fridge, thermometer, haze, pistonSet, capillarySet, heatStream, heatLines, FW, FH, FD } from './fridge.js';
import { VO } from './vo_fr.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Your fridge', 2], ["*doesn't* make *cold*", 3], ['It pumps', 2], ['*heat out*', 2], ['and dumps it', 3], ['in your *kitchen*', 3]],
  [['Hidden in', 2], ['the walls', 2], ['a special *fluid*', 3], ['runs around', 2], ['a *loop* of pipes', 4]],
  [['First a pump', 3], ['called a', 2], ['*compressor*', 1], ['*squeezes* it', 2], ['and squeezing', 2], ['a gas', 2], ['makes it *hot*', 3]],
  [['*Hotter* than', 2], ['your kitchen', 2], ['so in the *coils*', 4], ['at the back', 3], ['it gives', 2], ['that *heat*', 2], ['to the *room*', 3], ['and turns', 2], ['to *liquid*', 2]],
  [['Then it\'s *forced*', 3], ['through a', 2], ['*tiny tube*', 2]],
  [['Out the', 2], ['other end', 2], ['the *pressure*', 2], ['*drops*', 1], ['and the liquid', 3], ['*boils*', 1], ['well below', 2], ['*freezing*', 1]],
  [['*Boiling*', 1], ['soaks up *heat*', 3], ['so it pulls', 3], ['*warmth* out', 2], ['of *everything*', 2], ['inside', 1]],
  [['Then the gas', 3], ['goes back', 2], ['to the *compressor*', 3], ['and the *loop*', 3], ['starts again', 2]],
  [["That's why", 2], ['the *back*', 2], ['of a fridge', 3], ['feels *warm*', 2], ["It's the *heat*", 3], ['from your *food*', 3]],
  [['So leaving', 2], ['the *door open*', 3], ["*doesn't* cool", 2], ['your kitchen', 2], ['It *warms*', 2], ['it up', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.01; c.far = 60; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.45, warm: 1.05, sat: 1.15, exposure: 0.9 };
function room(makeStage, opts = {}) {
  const scene = makeStage({ shadowSize: 3, sunDir: [1.6, 3.2, 2.4] });
  kitchen(scene, opts);
  const Fr = fridge(); Fr.group.position.z = 0.35; scene.add(Fr.group);
  // heat lines rising off the back coils and over the top into the room
  const heatA = { value: 0 };
  const HL = heatLines({ n: 14, w: 0.7, h: 1.3, seed: 3 }); HL.position.set(0, 0.6, -FD / 2 - 0.12); Fr.group.add(HL);
  const HL2 = heatLines({ n: 8, w: 0.9, h: 0.9, seed: 5, rise: 0.25 }); HL2.position.set(0, FH + 0.05, -FD / 2 + 0.05); Fr.group.add(HL2);
  scene.userData.updaters.push((t) => { HL.userData.amt = HL2.userData.amt = Math.min(1, heatA.value); HL.userData.update(t); HL2.userData.update(t); Fr.st.coil = Math.min(1, heatA.value * 0.8); Fr.update(t); });
  return { scene, Fr, heatA };
}
function shotRange(line) { return [ls(line), le(line)]; }

// ============ S0 hook: fridge in the kitchen, heat pouring off its back ============
function sHook({ makeStage }) {
  const { scene, Fr, heatA } = room(makeStage);
  const th = thermometer(); th.group.position.set(-0.85, 1.45, -0.88); th.group.scale.setScalar(1.6); scene.add(th.group);
  const c = C(40);
  const TH = at(0, 'heat') - ls(0), TK = at(0, 'kitchen') - ls(0);
  return {
    scene, camera: c,
    update(t) {
      Fr.st.xray = 0.55; Fr.st.door = 0; Fr.st.cold = 1; Fr.st.dots = 1; Fr.st.flow = 1.2; Fr.st.frost = 1;
      heatA.value = 0.9 + 0.6 * smooth(range(t, TH - 0.2, TH + 0.4));
      th.set(0.3 + 0.35 * smooth(range(t, TK - 0.3, TK + 0.6)));
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0, lerp(1.25, 1.15, k), 0.15], lerp(3.4, 4.0, k), lerp(-98, -78, k), lerp(4, 8, k));
      return POST;
    },
  };
}
// ============ S1: x-ray: the loop of pipes appears, fluid running ============
function sLoop({ makeStage }) {
  const { scene, Fr, heatA } = room(makeStage);
  const c = C(38);
  const TL = at(1, 'loop') - ls(1);
  return {
    scene, camera: c,
    update(t) {
      Fr.st.xray = smooth(range(t, 0.1, 1.2)); Fr.st.dots = smooth(range(t, 0.8, 1.8)); Fr.st.flow = 1.2; heatA.value = 0.25;
      const k = easeInOut(range(t, 0, 3.8));
      orb(c, [0, 0.98, 0.25], lerp(4.0, 3.6, k), lerp(-35, -60, k), 6);
      return POST;
    },
  };
}
// ============ S2: compressor: the piston squeezes the gas and it heats up ============
function sSqueeze({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [1, 4, 3] });
  kitchen(scene, { warm: 0.6 });
  scene.children.filter(o => o.isMesh && o.position.y > 0.3 && o.position.x > 0.5).forEach(o => { o.visible = false; });
  const P = pistonSet(scene); P.group.position.set(0, 0.25, 0.6);
  const c = C(36);
  const TC = at(2, 'compressor') - ls(2), TS = at(2, 'squeezes') - ls(2), TH = at(2, 'hot') - ls(2);
  return {
    scene, camera: c,
    update(t, T) {
      const k = easeInOut(range(t, TS - 0.3, TS + 0.8)) * (1 - 0.15 * Math.max(0, Math.sin((t - TS - 1.2) * 4)) * smooth(range(t, TS + 1.2, TS + 1.5)));
      P.set(Math.min(1, k + 0.25 * smooth(range(t, TH - 0.6, TH))), T);
      const kc = easeInOut(range(t, 0, 4.8));
      orb(c, [0, 0.62, 0.6], lerp(1.55, 1.35, kc), lerp(18, 8, kc), lerp(14, 8, kc));
      return { ...POST, bloom: 0.7 };
    },
  };
}
// ============ S3: the back coils: hot fluid sheds heat into the room and turns liquid ============
function sCoils({ makeStage }) {
  const { scene, Fr, heatA } = room(makeStage);
  const c = C(38);
  const TB = at(3, 'back') - ls(3), TR = at(3, 'room') - ls(3);
  return {
    scene, camera: c,
    update(t) {
      Fr.st.xray = 0.6; Fr.st.flow = 1.0; Fr.st.dots = 1;
      heatA.value = 0.5 + 0.9 * smooth(range(t, TR - 1.2, TR));
      const k = easeInOut(range(t, 0, 5.6));
      orb(c, [0, lerp(1.2, 0.95, k), 0.35 - FD / 2], lerp(1.8, 2.4, k), lerp(-150, -130, k), lerp(4, 10, k));
      return POST;
    },
  };
}
// ============ S4 + S5: through the tiny tube, pressure drops, it boils, frost grows ============
function sTube(line) {
  return ({ makeStage }) => {
    const scene = makeStage({ shadowSize: 2, sunDir: [1, 4, 3] });
    const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x1b2a3c); u.mid.value.set(0x203246); u.horizon.value.set(0x203246); u.floorC.value.set(0x101820); }
    scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
    scene.add(new THREE.HemisphereLight(0xcfe6ff, 0x203040, 0.8));
    const S = capillarySet(scene); S.group.position.set(0, 0.6, 0);
    scene.userData.updaters.push((t) => S.update(t));
    const cold = new THREE.PointLight(0x5aa0ff, 0, 2); cold.position.set(1.2, 0.8, 0.4); scene.add(cold);
    const c = C(34);
    const t0 = ls(4);
    return {
      scene, camera: c,
      update(t, T) {
        const g = T - t0; // shared clock across both lines
        const TF = at(5, 'freezing') - t0, TB = at(5, 'boils') - t0, TD = at(5, 'drops') - t0;
        S.st.frost = smooth(range(g, TB, TF + 0.6)); S.st.boil = 0.3 + 0.7 * smooth(range(g, TD - 0.3, TB));
        cold.intensity = 2.5 * smooth(range(g, TB - 0.5, TF));
        if (line === 4) place(c, [lerp(-0.45, 0.05, easeInOut(range(g, 0, 2.0))), 0.78, 0.55], [lerp(-0.35, 0.2, easeInOut(range(g, 0, 2.0))), 0.6, 0]);
        else { const k = easeInOut(range(g, 2.0, 6.2)); place(c, [lerp(0.35, 1.05, k), lerp(0.78, 0.76, k), lerp(0.55, 0.62, k)], [lerp(0.45, 1.05, k), 0.6, 0]); }
        return { ...POST, warm: 0.85, bloom: 0.7 };
      },
    };
  };
}
// ============ S6: inside: warmth drifts from the food into the icy pipes ============
function sInside({ makeStage }) {
  const { scene, Fr, heatA } = room(makeStage);
  const amt = { value: 0 };
  const ev = Fr.evCurve.getPoint(0.5);
  [[-0.17, 0.75, 0.04], [0.08, 0.7, 0.0], [0.12, 1.06, 0.02], [-0.12, 1.18, -0.04], [0.1, 0.3, 0.02]].forEach(([x, y, z], i) => {
    const cv = new THREE.CatmullRomCurve3([new THREE.Vector3(x, y, z), new THREE.Vector3(x * 0.6, (y + ev.y) / 2 + 0.05, z - 0.08), new THREE.Vector3(ev.x + (i - 2) * 0.08, ev.y - 0.06, ev.z + 0.04)]);
    Fr.group.add(heatStream(cv, { amt, r: 0.013, speed: 0.45, color: 0xff6a1a }));
  });
  const c = C(36);
  const TW = at(6, 'warmth') - ls(6);
  return {
    scene, camera: c,
    update(t) {
      Fr.st.door = 1; Fr.st.lamp = 0.6; Fr.st.cold = 0.35; Fr.st.xray = 0; Fr.st.frost = 1; Fr.st.dots = 0.0; heatA.value = 0;
      amt.value = smooth(range(t, 0.4, 1.2)) * (0.7 + 0.5 * smooth(range(t, TW - 0.3, TW + 0.3)));
      const k = easeInOut(range(t, 0, 3.8));
      orb(c, [0, 0.95, 0.35], lerp(2.4, 2.0, k), lerp(16, 8, k), lerp(4, 8, k));
      return { ...POST, exposure: 0.8 };
    },
  };
}
// ============ S7: the whole loop again, orbiting ============
function sCycle({ makeStage }) {
  const { scene, Fr, heatA } = room(makeStage);
  const c = C(38);
  return {
    scene, camera: c,
    update(t) {
      Fr.st.xray = 1; Fr.st.dots = 1; Fr.st.flow = 1.6; Fr.st.frost = 1; Fr.st.compGlow = 0.4; heatA.value = 0.35;
      const k = easeInOut(range(t, 0, 3.6));
      orb(c, [0, 0.95, 0.3], 3.6, lerp(-150, -95, k), lerp(14, 8, k));
      return POST;
    },
  };
}
// ============ S8: the back feels warm: heat traced from the food to the coils ============
function sWarm({ makeStage }) {
  const { scene, Fr, heatA } = room(makeStage);
  const amt = { value: 0 };
  const path = new THREE.CatmullRomCurve3([new THREE.Vector3(-0.17, 0.75, 0.04), new THREE.Vector3(-0.1, 1.45, -0.2), new THREE.Vector3(0.1, 1.5, -0.32), new THREE.Vector3(0.14, 0.4, -FD / 2 - 0.06), new THREE.Vector3(0.0, 1.2, -FD / 2 - 0.05), new THREE.Vector3(0.0, 1.8, -FD / 2 - 0.25)]);
  Fr.group.add(heatStream(path, { amt, r: 0.014, speed: 0.35 }));
  const c = C(38);
  const TF = at(8, 'food') - ls(8), TW = at(8, 'warm') - ls(8);
  return {
    scene, camera: c,
    update(t) {
      Fr.st.xray = 0.85; Fr.st.dots = 0.6; Fr.st.flow = 1.0; Fr.st.frost = 1;
      heatA.value = 0.6 + 0.7 * smooth(range(t, TW - 0.4, TW + 0.2));
      amt.value = smooth(range(t, TF - 1.6, TF - 0.6));
      const k = easeInOut(range(t, 0, 3.6));
      orb(c, [0, 1.0, 0.2], lerp(3.3, 3.6, k), lerp(-75, -105, k), 8);
      return POST;
    },
  };
}
// ============ S9: door left open: cold spills out, the back pours out even more heat, the room warms ============
function sOpen({ makeStage }) {
  const { scene, Fr, heatA } = room(makeStage);
  const coldA = { value: 0 };
  const cold = haze({ w: 0.8, h: 1.0, color: 0x6fb8ff, dir: -1, amt: coldA }); cold.position.set(0.0, 0.5, FD / 2 + 0.25); Fr.group.add(cold);
  const th = thermometer(); th.group.position.set(-0.62, 1.45, -0.88); th.group.scale.setScalar(1.6); scene.add(th.group);
  const c = C(40);
  const TO = at(9, 'open') - ls(9), TW = at(9, 'warms') - ls(9);
  return {
    scene, camera: c,
    update(t) {
      Fr.st.door = easeOut(range(t, TO - 0.6, TO + 0.3)); Fr.st.lamp = Fr.st.door; Fr.st.cold = Fr.st.door * 0.6; Fr.st.frost = 1;
      coldA.value = 0.8 * smooth(range(t, TO, TO + 0.8));
      heatA.value = 0.8 + 1.0 * smooth(range(t, TW - 0.8, TW + 0.2));
      Fr.st.compGlow = 0.6 * smooth(range(t, TW - 0.8, TW));
      th.set(0.3 + 0.55 * smooth(range(t, TW - 0.6, TW + 1.0)));
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [-0.4, 1.15, 0.1], lerp(3.9, 4.4, k), lerp(-35, -50, k), 8);
      return { ...POST, exposure: 0.85 };
    },
  };
}

// ============ timeline ============
const SH = [sHook, sLoop, sSqueeze, sCoils, sTube(4), sTube(5), sInside, sCycle, sWarm, sOpen];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
