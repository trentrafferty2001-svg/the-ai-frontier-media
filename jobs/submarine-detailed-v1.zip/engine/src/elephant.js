// al-Jazari elephant clock reel: elephant (see-through body option) with water tank + sinking bowl, platform with
// carpet, scribe with pen over a dial, mahout with mallet + cymbal, tower with dome, ball release and ball path, vase,
// whirling bird on top; palace courtyard.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { glowSprite } from './props.js';
import { birdMesh } from './world.js';

let EM = null;
export function eMats() {
  if (EM) return EM;
  const carpet = canvasTex(256, 256, (x) => { x.fillStyle = '#8a1a1a'; x.fillRect(0, 0, 256, 256); x.strokeStyle = '#e8c060'; x.lineWidth = 8; x.strokeRect(14, 14, 228, 228); x.fillStyle = '#1a3a6a'; x.beginPath(); x.moveTo(128, 50); x.lineTo(206, 128); x.lineTo(128, 206); x.lineTo(50, 128); x.fill(); x.fillStyle = '#e8c060'; for (let i = 0; i < 12; i++) { x.beginPath(); x.arc(40 + (i % 4) * 58, 30 + Math.floor(i / 4) * 98, 6, 0, 7); x.fill(); } });
  EM = {
    skin: new THREE.MeshStandardMaterial({ color: 0x8e8a8c, roughness: 0.85, bumpMap: fabricTexture(53), bumpScale: 6 }), // wrinkled hide
    ghost: new THREE.MeshPhysicalMaterial({ color: 0xb8c4d0, roughness: 0.3, transparent: true, opacity: 0.13, depthWrite: false, side: THREE.DoubleSide }), // faint shell so the tank reads
    gold: new THREE.MeshStandardMaterial({ color: 0xe0b040, metalness: 0.9, roughness: 0.25 }),
    tower: new THREE.MeshStandardMaterial({ color: 0xe8dcc0, roughness: 0.6 }),
    teal: new THREE.MeshStandardMaterial({ color: 0x2a8a8a, roughness: 0.5 }),
    carpet: new THREE.MeshStandardMaterial({ map: carpet, roughness: 0.9 }),
    water: new THREE.MeshStandardMaterial({ color: 0x2a8ae0, emissive: 0x0a4a8a, emissiveIntensity: 0.7, transparent: true, opacity: 0.62, roughness: 0.1, depthWrite: false }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transparent: true, opacity: 0.06, depthWrite: false, side: THREE.DoubleSide }),
    copper: new THREE.MeshStandardMaterial({ color: 0xc87a3a, metalness: 0.85, roughness: 0.3 }),
    string: new THREE.MeshBasicMaterial({ color: 0xffe8a0 }),
    tusk: new THREE.MeshStandardMaterial({ color: 0xf4eedc, roughness: 0.4 }),
  };
  return EM;
}
function seated(color, skin, turbanC) {
  const h = romanBuilder({ color, skin });
  const t = new THREE.Mesh(new THREE.SphereGeometry(0.17, 20, 12, 0, Math.PI * 2, 0, Math.PI * 0.6), new THREE.MeshStandardMaterial({ color: turbanC, roughness: 0.85 })); t.position.set(0, 0.06, -0.01); t.scale.set(1.1, 1.0, 1.15); h.j.head.add(t);
  return shadowAll(h.root), h;
}
// the whole clock. Elephant faces +x. set({bowl 0..1 sink, tip 0..1, ball u, strike k, bird angle, pen angle})
export function elephantClock({ ghost = false } = {}) {
  const M = eMats(); const g = new THREE.Group();
  const bodyM = ghost ? M.ghost : M.skin;
  const parts = [];
  const add = (mesh) => { g.add(mesh); parts.push(mesh); return mesh; };
  // body: an egg shape, higher and rounder at the shoulders, belly a little flatter
  const bg = new THREE.SphereGeometry(1, 48, 32); { const p = bg.attributes.position; for (let i = 0; i < p.count; i++) { let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const sh = 1 + 0.12 * Math.max(0, x); y *= (y > 0 ? 1.0 + 0.1 * Math.max(0, x + 0.3) : 0.85); p.setXYZ(i, x * 1.7, y * 1.15 * sh, z * 1.05 * (1 + 0.06 * Math.max(0, x))); } bg.computeVertexNormals(); }
  const body = add(new THREE.Mesh(bg, bodyM)); body.position.set(0, 2.2, 0);
  // legs: tapered columns with a knee bulge and round feet with toenails
  const legProf = [[0, 0], [0.4, 0], [0.42, 0.06], [0.37, 0.2], [0.34, 0.6], [0.37, 0.85], [0.35, 1.1], [0.4, 1.5], [0.46, 1.75], [0, 1.75]].map(([a, b]) => new THREE.Vector2(a, b));
  for (const [x, z] of [[-1.0, -0.55], [-1.0, 0.55], [1.0, -0.55], [1.0, 0.55]]) {
    const l = add(new THREE.Mesh(new THREE.LatheGeometry(legProf, 24), bodyM)); l.position.set(x, 0, z);
    if (!ghost) for (let k = -1; k <= 1; k++) { const n = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), M.tusk); n.scale.set(1, 0.7, 1); n.position.set(x + 0.36 * Math.cos(k * 0.5), 0.05, z + 0.36 * Math.sin(k * 0.5)); g.add(n); }
  }
  // head with a domed forehead, tapering curled trunk, cupped ears hanging behind the eyes, curved tusks
  const head = add(new THREE.Mesh(new THREE.SphereGeometry(0.75, 32, 24), bodyM)); head.position.set(1.85, 2.75, 0); head.scale.set(1.0, 1.08, 0.95);
  const brow = add(new THREE.Mesh(new THREE.SphereGeometry(0.5, 24, 16), bodyM)); brow.position.set(2.1, 3.15, 0); brow.scale.set(0.9, 0.8, 1.2);
  const tc = new THREE.CatmullRomCurve3([[2.35, 2.75, 0], [2.6, 2.2, 0], [2.7, 1.5, 0], [2.65, 0.9, 0], [2.8, 0.55, 0], [2.98, 0.6, 0]].map(p => new THREE.Vector3(...p)));
  const tg = new THREE.TubeGeometry(tc, 60, 0.28, 16); { const p = tg.attributes.position; const uv = tg.attributes.uv; for (let i = 0; i < p.count; i++) { const u = uv.getX(i), c = tc.getPointAt(Math.min(1, u)); const k = 1 - 0.68 * u; p.setXYZ(i, c.x + (p.getX(i) - c.x) * k, c.y + (p.getY(i) - c.y) * k, c.z + (p.getZ(i) - c.z) * k); } tg.computeVertexNormals(); }
  const trunk = add(new THREE.Mesh(tg, bodyM));
  for (const s of [-1, 1]) {
    const eg = new THREE.CircleGeometry(0.8, 32); { const p = eg.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); p.setXYZ(i, x * 0.75, y * 1.0 - Math.max(0, -y) * 0.15, -0.18 * (1 - (x * x + y * y) / 0.64)); } eg.computeVertexNormals(); }
    const ear = add(new THREE.Mesh(eg, bodyM)); ear.material.side = THREE.DoubleSide; ear.position.set(1.55, 2.8, s * 0.72); ear.rotation.y = s * 0.35 + (s < 0 ? Math.PI : 0);
    const tk = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([[2.35, 2.35, s * 0.3], [2.65, 2.0, s * 0.34], [2.95, 2.05, s * 0.3]].map(p => new THREE.Vector3(...p))), 16, 0.06, 10), M.tusk); g.add(tk);
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 10), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.3 })); eye.position.set(2.32, 3.0, s * 0.47); g.add(eye);
  }
  const tail = add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([[-1.65, 2.5, 0], [-1.8, 2.0, 0], [-1.78, 1.5, 0.05]].map(p => new THREE.Vector3(...p))), 16, 0.04, 8), bodyM));
  // platform + carpet on the back
  const plat = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 1.6), M.gold); plat.position.set(-0.1, 3.35, 0); g.add(plat);
  const carp = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.9, 1.75), M.carpet); carp.position.set(-0.1, 2.95, 0); carp.scale.set(1, 1, 1); g.add(carp);
  // tower with dome + bird
  const tower = new THREE.Group(); tower.position.set(-0.5, 3.41, 0); g.add(tower);
  const tw = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.6, 1.8, 8), M.tower); tw.position.y = 0.9; tower.add(tw);
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; const win = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.3, 0.05), new THREE.MeshStandardMaterial({ color: 0x1a120c })); win.position.set(Math.sin(a) * 0.57, 1.3, Math.cos(a) * 0.57); win.rotation.y = a; tower.add(win); }
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.6, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), M.teal); dome.position.y = 1.8; tower.add(dome);
  const bird = new THREE.Group(); bird.position.y = 2.45; tower.add(bird);
  // a gilded bird on a short spindle (was a cone with two flat plates)
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.2, 8), M.gold); rod.position.y = -0.05; bird.add(rod);
  const bm = birdMesh({ color: 0xd8a838, tip: 0x2a6a8a, beak: 0xc85a2a }); bm.scale.setScalar(0.5); bm.position.set(0.12, 0.1, 0); bird.add(bm); bird.flap = bm.flap;
  const balls = [...Array(4)].map((_, i) => { const b = new THREE.Mesh(new THREE.SphereGeometry(0.07, 14, 10), M.copper); b.position.set(-0.5 + Math.sin(i) * 0.25, 4.7, Math.cos(i) * 0.25); g.add(b); return b; });
  const ball = new THREE.Mesh(new THREE.SphereGeometry(0.08, 14, 10), M.copper); g.add(ball);
  // scribe on the platform (seated, facing +z) with a dial
  const scribe = seated(0xe8e0d0, 0xc89068, 0x2a4a8a); scribe.root.position.set(0.55, 3.0, 0.15); scribe.root.rotation.y = Math.PI / 2; scribe.root.scale.setScalar(0.7); g.add(scribe.root);
  const dial = new THREE.Mesh(new THREE.RingGeometry(0.18, 0.26, 32, 1, 0, Math.PI), M.gold); dial.position.set(0.95, 3.75, 0.15); dial.rotation.y = Math.PI / 2; g.add(dial);
  const pen = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.24, 0.02), new THREE.MeshStandardMaterial({ color: 0x1a1a1a })); const penP = new THREE.Group(); penP.position.copy(dial.position); penP.add(pen); pen.position.y = 0.12; g.add(penP);
  // mahout on the neck with mallet; cymbal; vase
  const mahout = seated(0xd8c8a8, 0xa86a44, 0xc0402a); mahout.root.position.set(1.55, 2.95, 0); mahout.root.rotation.y = Math.PI / 2; mahout.root.scale.setScalar(0.7); g.add(mahout.root);
  const cymbal = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.02, 24), M.gold); cymbal.position.set(1.95, 3.55, 0.55); cymbal.rotation.x = Math.PI / 2; g.add(cymbal);
  const vase = new THREE.Mesh(new THREE.LatheGeometry([[0, 0], [0.1, 0], [0.14, 0.08], [0.1, 0.18], [0.12, 0.26], [0, 0.26]].map(([a, b]) => new THREE.Vector2(a, b)), 16), M.gold); vase.position.set(1.15, 3.41, -0.45); g.add(vase);
  // inside: tank, water, bowl, string
  const tank = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.0, 0.8), M.glass); tank.position.set(0, 2.1, 0); g.add(tank);
  tank.add(new THREE.LineSegments(new THREE.EdgesGeometry(tank.geometry), new THREE.LineBasicMaterial({ color: 0xd8e8f0, transparent: true, opacity: 0.8 }))); // tank edges
  const water = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.8, 0.76), M.water); water.position.set(0, 2.0, 0); g.add(water);
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.3, 20, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), M.copper); bowl.material = M.copper.clone(); bowl.material.side = THREE.DoubleSide; g.add(bowl);
  const bowlW = new THREE.Mesh(new THREE.CircleGeometry(0.28, 20), M.water); bowlW.rotation.x = -Math.PI / 2; g.add(bowlW);
  const jet = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.18, 6), M.water); g.add(jet);
  const str = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 1, 6), M.string); g.add(str);
  const inside = [tank, water, bowl, bowlW, jet, str];
  g.inside = (on) => inside.forEach(m => m.visible = on);
  g.inside(ghost);
  const ballPath = new THREE.CatmullRomCurve3([[-0.5, 4.7, 0.5], [-0.1, 4.2, 0.6], [0.5, 3.9, 0.3], [1.0, 3.75, -0.3], [1.15, 3.6, -0.45]].map(p => new THREE.Vector3(...p)));
  g.set = ({ sink = 0, tip = 0, ballU = -1, strike = 0, birdA = 0, pen: pa = null, flow = true } = {}) => {
    const by = 2.38 - sink * 0.62; bowl.position.set(0, by, 0); bowl.rotation.z = tip * 1.4; bowlW.position.set(0, by - 0.25 + sink * 0.22, 0); bowlW.scale.setScalar(0.5 + sink * 0.5); bowlW.visible = g.inside_on && sink > 0.05 && tip < 0.3;
    jet.position.set(0, by - 0.25, 0); jet.visible = g.inside_on && flow && sink < 0.98 && tip < 0.1;
    const top = 3.3; str.position.set(0.3, (by + top) / 2, 0); str.scale.y = top - by;
    penP.rotation.x = pa != null ? pa : -Math.PI / 2 + sink * Math.PI;
    bird.rotation.y = birdA; bird.flap(birdA * 1.5, Math.min(1, Math.abs(birdA) > 0.01 ? 1 : 0));
    ball.visible = ballU >= 0 && ballU <= 1; if (ball.visible) ball.position.copy(ballPath.getPoint(Math.min(1, ballU)));
    mahout.setPose({ rSh: [-1.0 - strike * 1.4, 0, -0.4], rEl: [-0.6, 0, 0], lSh: [-0.6, 0, 0.3], lHip: [-1.4, 0, 0.3], rHip: [-1.4, 0, -0.3], lKn: [1.4, 0, 0], rKn: [1.4, 0, 0] });
    scribe.setPose({ rSh: [-1.1, 0, -0.2], rEl: [-0.7, 0, 0], lHip: [-1.4, 0, 0.3], rHip: [-1.4, 0, -0.3], lKn: [1.4, 0, 0], rKn: [1.4, 0, 0], head: [0.3, 0, 0] });
    [mahout, scribe].forEach(h => { h.setMood('happy'); h.setMouth(0); });
    cymbal.position.y = 3.55 + Math.max(0, 0.02 * Math.sin(strike * 30)) * (strike > 0.9 ? 1 : 0);
  };
  g.inside_on = ghost; const _inside = g.inside; g.inside = (on) => { g.inside_on = on; _inside(on); };
  g.ghost = (k) => { parts.forEach(p => { p.material = k > 0.5 ? M.ghost : M.skin; }); };
  g.set({});
  g.bird = bird; g.ball = ball; g.cymbal = cymbal; g.scribe = scribe; g.mahout = mahout; g.bowl = bowl; g.tower = tower; g.dial = dial; g.vase = vase;
  return shadowAll(g);
}
// palace courtyard: tiled floor, arcade of pointed arches behind
export function palace(scene) {
  const tile = canvasTex(128, 128, (x) => { x.fillStyle = '#e8dcc0'; x.fillRect(0, 0, 128, 128); x.fillStyle = '#2a7a8a'; x.beginPath(); x.moveTo(64, 10); x.lineTo(118, 64); x.lineTo(64, 118); x.lineTo(10, 64); x.fill(); x.fillStyle = '#e8c060'; x.beginPath(); x.arc(64, 64, 14, 0, 7); x.fill(); }, [20, 20]);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ map: tile, roughness: 0.6 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const wm = new THREE.MeshStandardMaterial({ color: 0xd8c4a0, roughness: 0.8 });
  for (let i = -4; i <= 4; i++) {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 4, 12), wm); p.position.set(i * 2.6, 2, -6); p.castShadow = true; scene.add(p);
    if (i < 4) { const a = new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.22, 8, 20, Math.PI), wm); a.position.set(i * 2.6 + 1.3, 4, -6); scene.add(a); }
  }
  const back = new THREE.Mesh(new THREE.BoxGeometry(26, 7, 0.4), new THREE.MeshStandardMaterial({ color: 0xc8b090, roughness: 0.9 })); back.position.set(0, 3.5, -8); back.receiveShadow = true; scene.add(back);
  const top = new THREE.Mesh(new THREE.BoxGeometry(26, 0.6, 2.6), wm); top.position.set(0, 5.6, -6.8); scene.add(top);
}
