import * as THREE from 'three';
import { fish, rice, grid, paddy, farmer, splash, bug, weed, bucket, underwater, shaft, farmMats, glowSprite } from './farm.js';
import { VO } from './vo.js';
import { TIME, fields, mountains, trees, ringSpots, birds, terraces, mist, waterMaterial } from './world.js';
import { riceClumps, clumpGrid, carp, farmer2, splash2 } from './farm2.js';
import { underwaterWorld, tillers } from './uw.js';
import { cutawayField } from './cutaway.js';
import { kf, lerp, smooth, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';

export const DURATION = 30.3;

// word timings of the voiceover (global seconds), generated from the Kokoro durations
const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const end = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][2];

// caption chunks per line: [text, number of spoken words]
const CHUNKS = [
  [['If you put', 3], ['*fish*', 1], ['in a *rice field*', 4], ["you'd think", 2], ["they'd *eat*", 2], ['the *crop*', 2]],
  [['But farmers', 2], ['in *China*', 2], ['have done this', 3], ['for over', 2], ['*1,200 years*', 3]],
  [['First', 1], ['dig a *trench*', 3], ['along the edge', 3], ['so the fish', 3], ['have *shelter*', 2]],
  [['Then raise', 2], ['the *walls*', 2], ['and *flood*', 2], ['the field', 2]],
  [['A week', 2], ['after planting', 2], ['*release*', 1], ['young *carp*', 2]],
  [['The fish eat', 3], ['*weeds*', 1], ['and *pests*', 2], ['and their *waste*', 3], ['*feeds*', 1], ['the rice', 2]],
  [['The rice', 2], ['*shades* the water', 3], ['keeping the fish', 3], ['*cool*', 1]],
  [['So at *harvest*', 3], ['you get', 2], ['*two crops*', 2], ['from *one field*', 3]],
];
// [start, text, end?]
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    const last = ci === chunks.length - 1;
    CAPTIONS.push(last ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
});
export const FADES = [[3.95, 4.1, 4.2, 4.33]];

function blinkK(t, times) { let k = 0; for (const b of times) k = Math.max(k, 1 - Math.abs(t - b) / 0.07); return k; }
function idle(t, k = 1) { return Math.sin(t * 1.6) * 0.012 * k; }
const STAND = {
  lSh: [0.05, 0, 0.16], rSh: [0.05, 0, -0.16], lEl: [-0.25, 0, 0], rEl: [-0.25, 0, 0],
  lHip: [0, 0, 0.07], rHip: [0, 0, -0.07], lAn: [0, 0, -0.07], rAn: [0, 0, 0.07],
};
function standPose(h, t, extra = {}) {
  const p = { ...STAND, ...extra };
  p.chest = [idle(t) + (extra.chest?.[0] || 0), extra.chest?.[1] || 0, extra.chest?.[2] || 0];
  h.setPose(p);
}
const wpos = (obj, v = V(0, 0, 0)) => obj.localToWorld(v.clone());

// ============ shared outdoor dressing ============
function dressWorld(scene, { y = 0.2, cover = 0.72, golden = false, birdsOn = true, treesOn = true, mtn = true, seed = 1, treeR = [34, 95] } = {}) {
  const f = fields(700, golden ? { cover: Math.max(cover, 0.85), rice: 0xb8902f, rice2: 0xe2c35e, water: 0x2b2a1e } : { cover });
  f.position.y = y; scene.add(f);
  if (mtn) scene.add(mountains({ rMin: 95, rMax: 330, height: 48, seed: 3 + seed }));
  if (treesOn) scene.add(trees(ringSpots(46, treeR[0], treeR[1], 7 + seed, [0, 0, 0], 0, Math.PI * 2, y - 0.1), { seed: 5 + seed, scale: 1.4 }));
  if (birdsOn) { const b = birds(5, { from: [-45, 13, -55], to: [45, 17, -70], spread: 7, speed: 0.045, scale: 2.2, seed: 4 + seed }); scene.add(b); scene.userData.updaters.push((t) => b.update(t)); }
  return f;
}
function fillLight(scene, dir = [0.4, 0.5, 1], i = 0.9, color = 0xfff1e0) {
  const l = new THREE.DirectionalLight(color, i); l.position.set(...dir); scene.add(l); return l;
}

// ============ SHOT 1: farmer in a green paddy drops a carp in ============
function shot1({ makeStage }) {
  const WY = 0.2;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.78, 0.45, 0.3], fog: 0.0032, shadowSize: 4, envI: 0.9 });
  dressWorld(scene, { y: WY, cover: 0.75 });
  fillLight(scene, [0.8, 0.4, 0.6], 0.55);
  const near = new THREE.Mesh(new THREE.PlaneGeometry(7.6, 8.2), waterMaterial({ color: 0x1f2c24, opacity: 1 })); near.rotation.x = -Math.PI / 2; near.position.set(0, WY + 0.004, -1.6); near.receiveShadow = true; scene.add(near);
  scene.add(riceClumps(clumpGrid(-3.6, 3.6, -5.5, 2.2, 0.3, { y: 0.02, seed: 11, skip: (x, z) => (x * x + z * z < 0.28) || ((x + 0.08) ** 2 + (z - 0.8) ** 2 < 0.3) || (z > 0.95 && x > -0.75 && x < 1.1) }), { h: 0.85, blades: 10, seed: 12 }));
  const man = farmer2(); man.root.rotation.y = 0.35; scene.add(man.root);
  const f = carp(0.36, { seed: 3 }); scene.add(f);
  const sp = splash2(1.3); scene.add(sp);
  const c = cam(36);
  const TD = 0.95, G = 5.5;
  return {
    scene, camera: c,
    update(tr) {
      const t = tr < 1.4 ? tr : 1.4 + (tr - 1.4) * 0.5;
      man.setMood('happy');
      const lift = kf(t, [[0, 0], [0.5, 1]]);
      standPose(man, t, { rSh: [lerp(0.05, -1.25, lift), 0, -0.2], rEl: [lerp(-0.25, -0.35, lift), 0, 0], neck: [0.12, 0, 0], head: [0.15 * lift, 0.15, 0] });
      man.setMouth(t < TD ? 0.0 : 0.3); man.blink(blinkK(tr, [0.6, 2.05])); man.grip(0.3, t < TD ? 0.85 : 0.35);
      scene.updateMatrixWorld(true);
      const hand = wpos(man.j.rWr, V(0, -0.12, 0.03));
      if (t < TD) {
        f.position.copy(hand); f.rotation.set(0.2, 0.35 + Math.PI, Math.sin(t * 14) * 0.25); f.swim(t, 14, 0.8);
      } else {
        const h0 = V(-0.08, 1.05, 0.68), dt = t - TD;
        const tImp = Math.sqrt(2 * (h0.y - WY) / G);
        if (dt < tImp) {
          f.position.set(h0.x, h0.y - 0.5 * G * dt * dt, h0.z + dt * 0.1);
          f.rotation.set(0.2, 0.35 + Math.PI, -0.9 * (dt / tImp) + Math.sin(t * 16) * 0.3); f.swim(t, 16, 0.9);
        } else {
          const u = dt - tImp;
          f.position.set(h0.x - u * 0.25, WY - 0.1 - Math.min(0.06, u * 0.2), h0.z + 0.07 + u * 0.15);
          f.rotation.set(0, Math.PI * 0.8, 0); f.swim(t, 10, 0.5);
        }
        sp.position.set(h0.x, WY, h0.z + tImp * 0.1);
        sp.update(dt - tImp);
      }
      const k = easeInOut(range(tr, 0, 1.4));
      const pk = easeInOut(range(tr, 1.35, 2.3));
      const s = shake(tr, 0.5 + 2.5 * Math.exp(-Math.pow((tr - 1.56) / 0.12, 2)));
      const p0 = [lerp(0.75, 0.6, k), lerp(1.05, 1.0, k), lerp(3.5, 3.05, k)], l0 = [lerp(0.05, 0.0, k), lerp(1.2, 1.1, k), 0.0];
      const p1 = [0.25, 0.5, 1.5], l1 = [-0.1, 0.27, 0.7];
      place(c, [lerp(p0[0], p1[0], pk) + s[0], lerp(p0[1], p1[1], pk) + s[1], lerp(p0[2], p1[2], pk)], [lerp(l0[0], l1[0], pk), lerp(l0[1], l1[1], pk), lerp(l0[2], l1[2], pk)]);
      return { bloom: 0.4 + 0.2 * Math.exp(-Math.pow((tr - 1.6) / 0.2, 2)), dof: { focus: lerp(3.3, 0.9, pk), aperture: 0.0012, maxblur: 0.005 } };
    },
  };
}

// ============ SHOT 1b: farmer's face, worried the fish will eat his rice ============
function shotFace({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.78, 0.45, 0.3], fog: 0.0032, shadowSize: 2.5 });
  dressWorld(scene, { y: 0.2, cover: 0.75, birdsOn: false });
  fillLight(scene, [0.8, 0.4, 0.6], 0.6);
  scene.add(riceClumps(clumpGrid(-3, 3, -5, 0.4, 0.3, { y: 0.02, seed: 21, skip: (x, z) => x * x + z * z < 0.3 }), { h: 0.85, blades: 10, seed: 22 }));
  const man = farmer2(); man.root.rotation.y = 0.2; scene.add(man.root);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      man.setMood('surprised');
      standPose(man, t, { neck: [-0.05, 0, 0], head: [-0.12 - 0.1 * easeOut(range(t, 0, 0.3)), 0.35, 0.05], lSh: [-0.5, 0, 0.9], lEl: [-1.9, 0, 0], rSh: [0.05, 0, -0.16] });
      man.setMouth(0.85 * easeOut(range(t, 0.05, 0.3)));
      const k = easeOut(range(t, 0, 1.1));
      const s = shake(t, 0.6);
      place(c, [0.22 + s[0], 1.64 + s[1], lerp(1.3, 1.0, k)], [0.03, 1.62, 0]);
      return { dof: { focus: lerp(1.3, 1.0, k) - 0.08, aperture: 0.006, maxblur: 0.014 }, bloom: 0.4 };
    },
  };
}

// ============ SHOT 2: underwater, the carp goes for a rice stem ============
function stripStudio(scene) { scene.children.forEach(o => { if (o.isLight || (o.isMesh && o.material && o.material.isShadowMaterial)) o.visible = false; }); }
function shot2({ makeStage, start: ST }) {
  const tCrop = at(0, 'crop') - ST;
  const scene = makeStage({ shadowSize: 1 }); stripStudio(scene);
  underwaterWorld(scene, { surf: 0.42, density: 1.9, see: 0.0, leaves: 0.7 });
  scene.add(tillers([[0.07, 0], [0.21, -0.15], [-0.26, -0.24], [0.36, 0.08], [-0.12, -0.42], [0.05, -0.5]], { h: 0.85, seed: 8 }));
  const f = carp(0.15, { seed: 3 }); scene.add(f);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const x = lerp(-0.22, -0.01, easeOut(range(t, 0, tCrop + 0.05)));
      f.position.set(x, 0.17 + Math.sin(t * 2) * 0.006, 0.02);
      f.face(V(1, 0.05, 0)); f.swim(t, 10, 0.45);
      f.mouth(t > tCrop - 0.05 ? 0.5 + 0.5 * Math.sin((t - tCrop) * 11) : 0);
      const k = easeInOut(range(t, 0, 1.4));
      place(c, [lerp(-0.12, -0.02, k), 0.19, lerp(0.56, 0.4, k)], [lerp(-0.07, 0.02, k), 0.19, 0]);
      return { bloom: 0.55, warm: 0.5, sat: 1.15, dof: { focus: lerp(0.56, 0.4, k), aperture: 0.012, maxblur: 0.012 } };
    },
  };
}

// ============ SHOT 3: hillside terraces in morning mist, centuries old ============
function shot3({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.3, 0.17, -0.94], fog: 0.0028, shadowSize: 45, shadowAt: [0, 4, 8], envI: 0.9, cloud: 0.3 });
  const ter = terraces({ center: [0, 0, -8], levels: 16, r0: 46, step: 2.5, rise: 0.6, seed: 9 });
  scene.add(ter);
  const f = fields(700, { cover: 0.4, bundX: 16, bundZ: 11 }); f.position.y = -0.62; scene.add(f);
  scene.add(mountains({ rMin: 90, rMax: 340, height: 55, seed: 6 }));
  scene.add(trees(ringSpots(40, 50, 95, 31, [0, 0, -8], 1.05, 2.6, -0.7), { seed: 32, scale: 1.6 }));
  scene.add(trees(ringSpots(40, 50, 95, 35, [0, 0, -8], -2.6, -1.05, -0.7), { seed: 36, scale: 1.6 }));
  scene.add(trees(ringSpots(14, 2, 8, 33, [0, 9.2, -8], -3.1, 3.1, 9.2), { seed: 34, scale: 1.3 }));
  for (const [y, op] of [[1.6, 0.16], [6.0, 0.1]]) { const m = mist(140, 90, { y, opacity: op, color: 0xffffff, scale: 0.035 }); m.position.z = -8; scene.add(m); }
  // two farmers working on a near terrace
  const workers = [];
  for (const [th, lvl] of [[-0.12, 2], [0.1, 3]]) {
    const w = farmer2();
    const r = ter.rOut(lvl, th) - 1.2;
    w.root.position.set(Math.sin(th) * r, ter.levelY(lvl) - 0.25, -8 + Math.cos(th) * r);
    w.root.rotation.y = th + Math.PI + 0.6;
    scene.add(w.root); workers.push(w);
  }
  const b = birds(6, { from: [-40, 12, 10], to: [40, 16, -20], spread: 8, speed: 0.06, scale: 1.8, seed: 8 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      workers.forEach((w, i) => {
        const bend = 0.5 + 0.12 * Math.sin(t * 2.2 + i * 2);
        w.setPose({ ...STAND, spine: [0.35, 0, 0], chest: [bend, 0, 0], neck: [-0.4, 0, 0], head: [-0.2, 0, 0], lSh: [-0.6 - bend * 0.5, 0, 0.2], rSh: [-0.9 - bend * 0.4, 0, -0.2], lEl: [-0.3, 0, 0], rEl: [-0.4, 0, 0], lHip: [-0.3, 0, 0.12], rHip: [-0.3, 0, -0.12], lKn: [0.4, 0, 0], rKn: [0.4, 0, 0], drop: -0.08 });
      });
      const k = easeInOut(range(t, 0, 4.7));
      place(c, [lerp(-11, 5, k), lerp(15.5, 12.5, k), lerp(52, 43, k)], [lerp(-3, 2, k), lerp(4.5, 5.0, k), lerp(-4, -8, k)]);
      return { bloom: 0.5, flare: 0.6, warm: 1.12 };
    },
  };
}

// ============ SHOTS 4 + 5: a cut-away paddy out in the fields ============
function cutStage(makeStage) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.62, 0.6], fog: 0.0035, shadowSize: 1.6, envI: 0.9 });
  dressWorld(scene, { y: -0.34, cover: 0.6, seed: 4, treeR: [16, 70] });
  scene.add(riceClumps(clumpGrid(-3.2, 3.2, -3.4, 3.0, 0.26, { y: -0.4, seed: 81, skip: (x, z) => (x > -0.8 && x < 0.8 && z > -1.0 && z < 1.0) }), { h: 0.55, blades: 8, seed: 82, cast: false }));
  fillLight(scene, [0.7, 0.4, 0.8], 0.5);
  return scene;
}
function shot4({ makeStage, start: ST }) {
  const tDig = at(2, 'dig') - ST, tEdge = end(2, 'edge') - ST, tSo = at(2, 'so') - ST, tShel = end(2, 'shelter') - ST;
  const scene = cutStage(makeStage);
  const d = cutawayField(scene, {});
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      d.set({ dig: easeInOut(range(t, tDig - 0.1, tEdge)), wall: 0, level: kf(t, [[tSo - 0.15, 0], [tSo + 0.5, 0.35]]), fishOn: range(t, tSo, tShel - 0.2), t, shovelOn: t > tDig - 0.35 && t < tSo - 0.1 });
      const k = easeInOut(range(t, 0, 3.9));
      const pos = [lerp(-1.35, -1.0, k), lerp(1.3, 1.08, k), lerp(2.35, 2.0, k)], look = [-0.25, 0.22, 0.05];
      place(c, pos, look);
      const dist = Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]);
      return { bloom: 0.35, dof: { focus: dist, aperture: 0.0022, maxblur: 0.008 } };
    },
  };
}
function shot5({ makeStage, start: ST }) {
  const tRaise = at(3, 'raise') - ST, tWalls = end(3, 'walls') - ST, tFlood = at(3, 'flood') - ST, tField = end(3, 'field') - ST;
  const scene = cutStage(makeStage);
  const d = cutawayField(scene, {});
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const inflow = smooth(range(t, tFlood - 0.25, tFlood + 0.1)) * (1 - smooth(range(t, tField + 0.3, tField + 0.6)));
      d.set({ dig: 1, wall: easeOut(range(t, tRaise - 0.05, tWalls)), level: lerp(0.35, 1, easeInOut(range(t, tFlood - 0.05, tField + 0.2))), fishOn: 1, t: t + 3.9, inflow });
      const k = easeInOut(range(t, 0, tField + 0.3));
      const pos = [lerp(-0.75, 0.35, k), lerp(1.25, 1.55, k), lerp(2.3, 2.45, k)], look = [lerp(-0.25, 0.0, k), 0.28, 0];
      place(c, pos, look);
      const dist = Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]);
      return { bloom: 0.35, dof: { focus: dist, aperture: 0.0022, maxblur: 0.008 } };
    },
  };
}

// ============ SHOT 6: release young carp among seedlings ============
function shot6({ makeStage, start: ST }) {
  const tRel = at(4, 'release') - ST;
  const WY = 0.12;
  const scene = makeStage({ outdoor: 'day', sunDir: [0.75, 0.42, -0.5], fog: 0.0032, shadowSize: 3.5 });
  dressWorld(scene, { y: WY, cover: 0.12, seed: 2 });
  fillLight(scene, [-0.6, 0.5, 1], 0.9);
  scene.add(riceClumps(clumpGrid(-2.8, 2.0, -4.2, 1.6, 0.27, { y: 0.0, seed: 41, jitter: 0.03, skip: (x, z) => ((x - 0.15) ** 2 + (z - 0.55) ** 2 < 0.25) }), { h: 0.32, blades: 6, seed: 42, spread: 0.55, color: 0x5ea832, color2: 0x9fd25a, sway: 0.03 }));
  const man = farmer2(); man.root.position.set(0.15, -0.05, 0.55); man.root.rotation.y = -0.6; scene.add(man.root);
  const bk = bucket(); scene.add(bk);
  const fry = [], spl = [];
  for (let i = 0; i < 6; i++) { const f = carp(0.08, { seed: 10 + i, style: i % 3 ? 'koi' : 'wild' }); scene.add(f); fry.push(f); const s = splash2(0.4, 11 + i); scene.add(s); spl.push(s); }
  const c = cam(38);
  const TT = tRel + 0.05;
  return {
    scene, camera: c,
    update(t) {
      const tip = easeInOut(range(t, TT - 0.5, TT + 0.3));
      standPose(man, t, { rSh: [-1.0, 0, lerp(-0.2, -0.05, tip)], rEl: [-0.5, 0, 0], lSh: [-0.9, 0, 0.35], lEl: [-0.7, 0, 0], chest: [0.15, 0, 0], neck: [0.25, 0, 0], head: [0.2, 0, 0] });
      man.setMood('happy'); man.setMouth(0.0); man.blink(blinkK(t, [0.9, 2.4])); man.grip(0.5, 0.95);
      scene.updateMatrixWorld(true);
      const hand = wpos(man.j.rWr, V(0, -0.06, 0));
      bk.position.copy(hand).add(V(0, -0.02, 0));
      bk.rotation.set(0, 0, tip * 1.7);
      bk.position.x -= tip * 0.05;
      const lip = V(-0.13, 0.11, 0).applyEuler(bk.rotation).add(bk.position);
      fry.forEach((f, i) => {
        const dt = t - (TT + i * 0.18);
        if (dt < 0) { f.visible = false; spl[i].update(-1); return; }
        f.visible = true;
        const vx = -0.35 - (i % 3) * 0.12, vz = (i - 2.5) * 0.08, G = 4;
        const tImp = Math.sqrt(2 * Math.max(0.001, lip.y - WY) / G);
        if (dt < tImp) {
          f.position.set(lip.x + vx * dt, lip.y - 0.5 * G * dt * dt, lip.z + vz * dt);
          f.rotation.set(dt * 4 + i, 0.6 * i, -1.0); f.swim(t, 18, 0.9);
          spl[i].update(-1);
        } else {
          const ix = lip.x + vx * tImp, iz = lip.z + vz * tImp, u = dt - tImp;
          spl[i].position.set(ix, WY, iz); spl[i].update(u);
          const dir = V(-Math.cos(i), 0, -Math.abs(Math.sin(i)) - 0.3);
          f.position.set(ix + dir.x * u * 0.25, WY - 0.04, iz + dir.z * u * 0.25);
          f.face(dir); f.swim(t + i, 12, 0.5);
        }
      });
      const k = easeInOut(range(t, 0, 3.2));
      const s = shake(t, 0.4);
      place(c, [lerp(-1.55, -1.7, k) + s[0], lerp(1.25, 1.15, k) + s[1], lerp(4.3, 3.95, k)], [lerp(-0.15, -0.25, k), lerp(1.0, 0.92, k), 0.4]);
      return { bloom: 0.5, dof: { focus: 3.0, aperture: 0.0012, maxblur: 0.005 } };
    },
  };
}

// ============ SHOT 7: the mechanism, underwater ============
function shot7({ makeStage, start: ST }) {
  const tW = at(5, 'weeds') - ST, tP = at(5, 'pests') - ST, tWa = at(5, 'waste') - ST, tF = at(5, 'feeds') - ST, tE = end(5, 'rice') - ST + 0.35;
  const scene = makeStage({ shadowSize: 1 }); stripStudio(scene);
  const SURF = 0.36;
  underwaterWorld(scene, { surf: SURF, density: 1.6, see: 0.0, leaves: 0.7 });
  const F = farmMats();
  const stems = tillers([[0.12, -0.02], [0.25, -0.15], [-0.05, -0.23], [0.4, 0.05]], { h: 0.75, seed: 31 });
  const riceMat = stems.stemMat; riceMat.emissive = new THREE.Color(0x46ff7a); riceMat.emissiveIntensity = 0;
  scene.add(stems);
  const wd = weed(0.15); wd.position.set(-0.13, 0, 0.02); scene.add(wd);
  wd.traverse(o => { if (o.isMesh) { o.material = o.material.clone(); o.material.color.set(0x5a8f2c); } });
  const b = bug(0.035); scene.add(b);
  const f = carp(0.14, { seed: 4 }); scene.add(f);
  const pellets = [];
  for (let i = 0; i < 6; i++) { const p = new THREE.Mesh(new THREE.SphereGeometry(0.006, 10, 8), F.pellet); scene.add(p); pellets.push(p); }
  const glows = [0, 1, 2].map(() => { const g = glowSprite(0x6dff8a, 0.08); g.material.fog = false; scene.add(g); return g; });
  const c = cam(46);
  return {
    scene, camera: c,
    update(t) {
      const KEYS = [[0, [-0.42, 0.12, 0.04]], [tW - 0.1, [-0.22, 0.1, 0.04]], [tW + 0.35, [-0.2, 0.11, 0.04]], [tP + 0.3, [-0.02, 0.27, 0.03]], [tWa, [0.0, 0.2, 0.06]], [tE + 0.6, [-0.12, 0.2, 0.08]]];
      const P = kf(t, KEYS), P2 = kf(t + 0.05, KEYS);
      f.position.set(...P);
      let dir = V(P2[0] - P[0], P2[1] - P[1], P2[2] - P[2]);
      if (dir.length() < 1e-4 || t > tWa) dir = t > tWa ? V(-1, 0, 0.1) : V(1, 0, 0);
      if (t > tW - 0.1 && t < tW + 0.35) dir = V(1, -0.6, 0);
      f.face(dir); f.swim(t, 10, 0.45);
      const bite1 = t > tW - 0.05 && t < tW + 0.4 ? Math.abs(Math.sin((t - tW) * 18)) : 0;
      const bite2 = t > tP + 0.2 && t < tP + 0.45 ? 1 : 0;
      f.mouth(Math.max(bite1, bite2));
      const we = easeIn(range(t, tW, tW + 0.45));
      wd.scale.set(1, Math.max(0.02, 1 - we), 1); wd.visible = we < 0.98;
      b.position.set(-0.01, SURF + 0.006 + Math.max(0, tP - 0.1 - t) * 0.4, 0.03);
      b.rotation.set(0, 0.4, Math.sin(t * 20) * 0.05);
      b.visible = t > tW - 0.25 && t < tP + 0.32;
      pellets.forEach((p, i) => {
        const dt = t - (tWa + i * 0.16);
        p.visible = dt > 0;
        p.position.set(-0.06 - dt * 0.04 + i * 0.035, Math.max(0.004, 0.19 - dt * 0.12), 0.05 - i * 0.012);
      });
      const feed = range(t, tF, tE);
      riceMat.emissiveIntensity = 0.35 * smooth(feed) * (0.7 + 0.3 * Math.sin(t * 8));
      glows.forEach((g, i) => {
        const base = [[0.12, -0.02], [0.25, -0.15], [-0.05, -0.23]][i];
        const ph = clamp(feed * 1.4 - i * 0.2);
        g.position.set(base[0], 0.01 + ph * 0.42, base[1]);
        g.material.opacity = feed > 0 ? Math.sin(ph * Math.PI) * 0.9 : 0;
        g.scale.setScalar(0.06 + 0.04 * ph);
      });
      const k = easeInOut(range(t, 0, tE));
      const camY = t < tP ? 0.16 : lerp(0.16, 0.2, range(t, tP, tP + 0.5));
      const pos = [lerp(-0.18, -0.02, k), camY, lerp(0.78, 0.7, k)];
      place(c, pos, [lerp(-0.18, 0.02, k), lerp(0.15, 0.17, k), 0]);
      return { bloom: 0.6, warm: 0.5, sat: 1.15, dof: { focus: Math.hypot(pos[0] - P[0], pos[1] - P[1], pos[2] - P[2]), aperture: 0.008, maxblur: 0.01 } };
    },
  };
}

// ============ SHOT 8: looking up through the water, rice leaves shading it ============
function shot8({ makeStage }) {
  const SURF = 0.42;
  const scene = makeStage({ shadowSize: 1.5 }); stripStudio(scene);
  underwaterWorld(scene, { surf: SURF, density: 1.15, see: 0.0, rays: 9, leaves: 1.0 });
  scene.add(tillers(clumpGrid(-0.8, 0.8, -0.9, 0.2, 0.19, { seed: 41, jitter: 0.06 }).map(p => [p[0], p[2]]), { h: 0.5, seed: 42, stems: 7 }));
  const f1 = carp(0.14, { seed: 6 }), f2 = carp(0.11, { seed: 7, style: 'wild' }); scene.add(f1, f2);
  const c = cam(50);
  return {
    scene, camera: c,
    update(t) {
      f1.position.set(lerp(0.35, -0.05, t / 3.4), 0.2 + Math.sin(t * 1.4) * 0.01, 0.12); f1.face(V(-1, 0, -0.05)); f1.swim(t, 5, 0.35);
      f2.position.set(lerp(-0.4, -0.12, t / 3.4), 0.12, -0.05); f2.face(V(1, 0, 0.1)); f2.swim(t + 1, 5, 0.3);
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [0.0, lerp(0.04, 0.06, k), lerp(0.75, 0.6, k)], [0.0, lerp(0.3, 0.4, k), lerp(-0.1, -0.2, k)]);
      return { bloom: 0.65, warm: 0.5, sat: 1.15 };
    },
  };
}

// ============ SHOT 9: golden-hour harvest, rice in one hand, carp in the other ============
function shot9({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.55, 0.16, -0.82], fog: 0.0038, shadowSize: 4, envI: 1.0, cloud: 0.4 });
  dressWorld(scene, { y: 0.05, golden: true, seed: 3 });
  fillLight(scene, [-0.3, 0.5, 1], 1.0, 0xffe2c0);
  scene.add(riceClumps(clumpGrid(-3.0, 3.0, -4.6, 1.4, 0.25, { y: -0.05, seed: 51, skip: (x, z) => x * x + z * z < 0.35 }), { h: 0.95, blades: 8, seed: 52, golden: true, panicles: true, color: 0x8f8a34, color2: 0xc2ad4c, sway: 0.05, spread: 0.3 }));
  const man = farmer2(); scene.add(man.root);
  const sheaf = riceClumps([[0, 0, 0], [0.02, 0, 0.01], [-0.015, 0, 0.012]], { h: 0.42, blades: 7, seed: 62, golden: true, panicles: true, color: 0xa69a3e, color2: 0xd8bd5a, spread: 0.1, sway: 0.0 });
  scene.add(sheaf);
  const tie = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.008, 6, 20), farmMats().straw); tie.rotation.x = Math.PI / 2; tie.position.y = 0.1; sheaf.add(tie);
  const f = carp(0.32, { seed: 5 }); scene.add(f);
  const sparkle = glowSprite(0xfff2c0, 0.2); scene.add(sparkle);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const up = easeOut(range(t, 0.1, 0.8));
      standPose(man, t, {
        lSh: [lerp(0.05, -2.0, up), 0, lerp(0.16, 0.3, up)], lEl: [lerp(-0.25, -0.35, up), 0, 0],
        rSh: [lerp(0.05, -2.0, up), 0, lerp(-0.16, -0.3, up)], rEl: [lerp(-0.25, -0.35, up), 0, 0],
        head: [-0.05, 0, Math.sin(t * 2) * 0.04],
      });
      man.setMood('happy'); man.setMouth(0.5); man.blink(blinkK(t, [1.3, 3.5])); man.grip(0.95, 0.95);
      scene.updateMatrixWorld(true);
      const lh = wpos(man.j.lWr, V(0, -0.06, 0)), rh = wpos(man.j.rWr, V(0, -0.06, 0));
      sheaf.position.copy(lh).add(V(0, -0.1, 0.04)); sheaf.rotation.set(0, 0, 0.1);
      f.position.copy(rh).add(V(0.0, 0.0, 0.07)); f.rotation.set(0, 0, 1.25 + Math.sin(t * 9) * 0.12); f.swim(t, 12, 0.6);
      sparkle.position.copy(rh).add(V(0.05, 0.08, 0.1)); sparkle.material.opacity = 0.6 * Math.max(0, Math.sin(t * 3));
      const k = easeInOut(range(t, 0, 4.3));
      place(c, [lerp(0.35, 0.15, k), lerp(1.35, 1.45, k), lerp(3.9, 3.3, k)], [0, lerp(1.45, 1.55, k), 0]);
      return { bloom: 0.6, flare: 1.0, warm: 1.3, dof: { focus: lerp(3.9, 3.3, k), aperture: 0.0018, maxblur: 0.007 } };
    },
  };
}

export const SHOTS = [
  { start: 0.0, end: 2.17, build: shot1 },      // "If you put fish in a rice field"
  { start: 2.17, end: 2.75, build: shotFace },  // "you'd think they'd"
  { start: 2.75, end: 4.2, build: shot2 },      // "eat the crop"
  { start: 4.2, end: 8.85, build: shot3 },      // "But farmers in China..."
  { start: 8.85, end: 12.85, build: shot4 },    // "First, dig a trench..."
  { start: 12.85, end: 15.55, build: shot5 },   // "Then raise the walls..."
  { start: 15.55, end: 18.4, build: shot6 },    // "A week after planting..."
  { start: 18.4, end: 22.5, build: shot7 },     // "The fish eat weeds and pests..."
  { start: 22.5, end: 25.75, build: shot8 },    // "The rice shades the water..."
  { start: 25.75, end: DURATION + 1, build: shot9 }, // "So at harvest..."
];

export { dressWorld, fillLight, standPose, STAND, wpos, stripStudio, cutStage, blinkK, shot1, shotFace, shot2, shot3, shot4, shot5, shot6, shot7, shot8, shot9 };
