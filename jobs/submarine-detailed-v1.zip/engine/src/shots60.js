// 60 s edit: v4 segments are reused as rendered; this file defines the full timeline and the new shots.
import * as THREE from 'three';
import { dressWorld, fillLight, standPose, STAND, wpos, stripStudio, cutStage, blinkK, shot1, shotFace, shot2, shot3, shot4, shot5, shot6, shot7, shot8, shot9 } from './shots4.js';
import { riceClumps, clumpGrid, carp, farmer2, splash2 } from './farm2.js';
import { fields, mountains, trees, ringSpots, birds, terraces, mist, waterMaterial } from './world.js';
import { underwaterWorld, tillers } from './uw.js';
import { cutawayField } from './cutaway.js';
import { house, acacia, jerrycan, sack, riceBasket, cap, mudCloud } from './props60.js';
import { bug, glowSprite } from './farm.js';
import { materials } from './materials.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, smooth, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { VO } from './vo60.js';
import { BLOCKS } from './timeline60.js';

export const DURATION = 60.0;
const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const end = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][2];

const CHUNKS = [
  [['If you put', 3], ['*fish*', 1], ['in a *rice field*', 4], ["you'd think", 2], ["they'd *eat*", 2], ['the *crop*', 2]],
  [['But farmers', 2], ['in *China*', 2], ['have done this', 3], ['for over', 2], ['*1,200 years*', 3]],
  [['In *2005*', 4], ['the *UN*', 3], ['named it', 2], ['a *global*', 2], ['*farming heritage* site', 3]],
  [["*Here's how*", 2], ['it works', 2]],
  [['First', 1], ['dig a *trench*', 3], ['along the edge', 3], ['so the fish', 3], ['have *shelter*', 2]],
  [['Then raise', 2], ['the *walls*', 2], ['and *flood*', 2], ['the field', 2]],
  [['A week', 2], ['after planting', 2], ['*release*', 1], ['young *carp*', 2]],
  [['Then the fish', 3], ['get to *work*', 3], ['*swimming*', 1], ['between the rice', 3], ['*all day*', 2]],
  [['The fish eat', 3], ['*weeds*', 1], ['and *pests*', 2], ['and their *waste*', 3], ['*feeds*', 1], ['the rice', 2]],
  [['As they swim', 3], ['they *bump*', 2], ['the *stems*', 2], ['knocking *bugs*', 2], ['into the water', 3]],
  [['They *stir up*', 3], ['the *mud* too', 3], ['adding *oxygen*', 2], ['to the water', 3]],
  [['The rice', 2], ['*shades* the water', 3], ['keeping the fish', 3], ['*cool*', 1]],
  [['The *result?*', 2], ['Just as much *rice*', 4], ['with *68%*', 4], ['less *pesticide*', 2], ['and *a quarter*', 3], ['less *fertilizer*', 2]],
  [['So at *harvest*', 3], ['you get', 2], ['*two crops*', 2], ['from *one field*', 3]],
  [['And now', 2], ['this *1,200-year-old*', 5], ['trick', 1], ['is *spreading*', 2], ['to farms in', 3], ['*Africa*', 1], ['and *Southeast Asia*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
});
export const FADES = [[3.95, 4.1, 4.2, 4.33]];

// ============ shared: the terraces valley (same place as the v4 establishing shot) ============
function terraceWorld(scene, { workers = false } = {}) {
  const ter = terraces({ center: [0, 0, -8], levels: 16, r0: 46, step: 2.5, rise: 0.6, seed: 9 });
  scene.add(ter);
  const f = fields(700, { cover: 0.4, bundX: 16, bundZ: 11 }); f.position.y = -0.62; scene.add(f);
  scene.add(mountains({ rMin: 90, rMax: 340, height: 55, seed: 6 }));
  scene.add(trees(ringSpots(40, 50, 95, 31, [0, 0, -8], 1.05, 2.6, -0.7), { seed: 32, scale: 1.6 }));
  scene.add(trees(ringSpots(40, 50, 95, 35, [0, 0, -8], -2.6, -1.05, -0.7), { seed: 36, scale: 1.6 }));
  scene.add(trees(ringSpots(14, 2, 8, 33, [0, 9.2, -8], -3.1, 3.1, 9.2), { seed: 34, scale: 1.3 }));
  for (const [y, op] of [[1.6, 0.16], [6.0, 0.1]]) { const m = mist(140, 90, { y, opacity: op, color: 0xffffff, scale: 0.035 }); m.position.z = -8; scene.add(m); }
  const b = birds(6, { from: [-40, 12, 30], to: [40, 16, 0], spread: 8, speed: 0.06, scale: 1.8, seed: 8 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  if (workers) for (const [th, lvl] of [[-0.12, 2], [0.1, 3]]) {
    const w = farmer2(); const r = ter.rOut(lvl, th) - 1.2;
    w.root.position.set(Math.sin(th) * r, ter.levelY(lvl) - 0.25, -8 + Math.cos(th) * r); w.root.rotation.y = th + Math.PI + 0.6;
    w.setPose({ ...STAND, spine: [0.35, 0, 0], chest: [0.55, 0, 0], neck: [-0.4, 0, 0], head: [-0.2, 0, 0], lSh: [-0.9, 0, 0.2], rSh: [-1.1, 0, -0.2], lEl: [-0.3, 0, 0], rEl: [-0.4, 0, 0], lHip: [-0.3, 0, 0.12], rHip: [-0.3, 0, -0.12], lKn: [0.4, 0, 0], rKn: [0.4, 0, 0], drop: -0.08 });
    scene.add(w.root);
  }
  return ter;
}

// ============ A: the village under the terraces (UN heritage line) ============
function shotA({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.3, 0.17, -0.94], fog: 0.0028, shadowSize: 22, shadowAt: [0, 0, 46], envI: 0.9, cloud: 0.3 });
  terraceWorld(scene);
  fillLight(scene, [0.1, 0.45, 1], 0.9, 0xffe0bc);
  [[-9, 44, 0.15, 6], [-2.5, 46.5, -0.08, 5.4], [4.5, 44.2, 0.18, 6.4], [10.5, 46.8, -0.22, 5], [-15, 47.5, 0.3, 5.6], [1.2, 51.5, 0.05, 5.8]].forEach(([x, z, ry, w], i) => {
    const h = house({ w, d: 4.2, h: 3.0 + (i % 2) * 0.4, seed: i }); h.position.set(x, -0.62, z); h.rotation.y = ry; scene.add(h);
  });
  scene.add(trees([[-12, -0.62, 50], [7.5, -0.62, 49.5], [14, -0.62, 44], [-5.5, -0.62, 50.5]], { seed: 44, scale: 1.1 }));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.7));
      place(c, [lerp(9, 5, k), lerp(13, 8.5, k), lerp(84, 78, k)], [lerp(0, -1, k), lerp(3.2, 4.0, k), lerp(32, 28, k)]);
      return { bloom: 0.55, flare: 0.7, warm: 1.15 };
    },
  };
}

// ============ H: "Here's how it works" — swoop onto the cut-away ============
function shotH({ makeStage }) {
  const scene = cutStage(makeStage);
  const d = cutawayField(scene, {});
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      d.set({ dig: 0, wall: 0, level: 0, fishOn: 0, t, shovelOn: false });
      const k = easeInOut(range(t, 0, 1.58));
      const pos = [lerp(1.7, -1.35, k), lerp(2.3, 1.3, k), lerp(3.5, 2.35, k)], look = [lerp(0.1, -0.25, k), lerp(0.05, 0.22, k), lerp(0.2, 0.05, k)];
      place(c, pos, look);
      return { bloom: 0.35, dof: { focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: 0.0022, maxblur: 0.008 } };
    },
  };
}

// ============ B: tracking a carp weaving between the rice ============
function shotB({ makeStage }) {
  const scene = makeStage({ shadowSize: 1 }); stripStudio(scene);
  underwaterWorld(scene, { surf: 0.42, density: 1.7, leaves: 0.7, size: 6 });
  const lane = (x) => 0.11 * Math.sin(((x + 0.9) / 0.36) * 2.4) - 0.08;
  const spots = [];
  for (let x = -1.5; x <= 1.0; x += 0.24) for (let z = -0.95; z <= 0.4; z += 0.24) {
    const xx = x + Math.sin(z * 9) * 0.04, zz = z + Math.cos(x * 7) * 0.04;
    if (Math.abs(zz - lane(xx)) < 0.09 || (zz > lane(xx) && zz < lane(xx) + 0.5)) continue;
    spots.push([xx, zz]);
  }
  scene.add(tillers(spots, { h: 0.8, seed: 51, stems: 6, roots: 3 }));
  const f = carp(0.15, { seed: 3 }); scene.add(f);
  const f2 = carp(0.12, { seed: 8 }), f3 = carp(0.11, { seed: 9, style: 'wild' }); scene.add(f2, f3);
  const c = cam(44);
  const path = (t) => { const x = -0.9 + 0.36 * t; return V(x, 0.16 + Math.sin(t * 1.7) * 0.012, lane(x)); };
  return {
    scene, camera: c,
    update(t) {
      const p = path(t), q = path(t + 0.05);
      f.position.copy(p); f.face(q.clone().sub(p)); f.swim(t, 11, 0.5);
      f2.position.set(0.6 - 0.25 * t, 0.2, -0.7); f2.face(V(-1, 0, 0.1)); f2.swim(t + 2, 8, 0.4);
      f3.position.set(-1.0 + 0.2 * t, 0.12, -0.9); f3.face(V(1, 0, -0.05)); f3.swim(t + 4, 8, 0.4);
      const pos = [p.x - 0.1, 0.18, p.z + 0.33], look = [p.x + 0.04, 0.16, p.z - 0.05];
      place(c, pos, look);
      return { bloom: 0.55, warm: 0.5, sat: 1.15, dof: { focus: Math.hypot(pos[0] - p.x, pos[1] - p.y, pos[2] - p.z), aperture: 0.01, maxblur: 0.012 } };
    },
  };
}

// ============ C: the carp bumps the stems, planthoppers fall in, one gets eaten ============
function shotC({ makeStage, start: ST }) {
  const tBump = at(9, 'bump') - ST, tKnock = at(9, 'knocking') - ST, tWater = at(9, 'water') - ST;
  const WY = 0.2;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.6, 0.55, 0.45], fog: 0.0035, shadowSize: 1.4, envI: 0.9 });
  dressWorld(scene, { y: -0.05, cover: 0.8, seed: 6, birdsOn: false });
  fillLight(scene, [0.8, 0.4, 0.6], 0.5);
  const mud = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshStandardMaterial({ color: 0x3a2c1c, roughness: 1 })); mud.rotation.x = -Math.PI / 2; mud.position.y = 0.0; scene.add(mud);
  const water = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), waterMaterial({ color: 0x2a4236, opacity: 0.5 })); water.rotation.x = -Math.PI / 2; water.position.y = WY + 0.003; water.renderOrder = 2; scene.add(water);
  const hero = new THREE.Group(); scene.add(hero);
  hero.add(tillers([[0, 0]], { h: 0.95, seed: 61, stems: 9, roots: 0 }));
  hero.add(riceClumps([[0, 0.62, 0]], { h: 0.55, blades: 8, seed: 62, spread: 0.55, sway: 0.03 }));
  scene.add(riceClumps(clumpGrid(-2.4, 2.4, -3.2, -0.4, 0.3, { y: 0.0, seed: 63 }), { h: 1.05, blades: 10, seed: 64 }));
  scene.add(riceClumps([[-0.55, 0, -0.1], [0.5, 0, -0.2]], { h: 1.0, blades: 10, seed: 65 }));
  const bugs = [[0.012, 0.36, 0.018], [-0.015, 0.44, 0.01], [0.018, 0.52, -0.012], [-0.01, 0.6, 0.016]].map((lp, i) => { const b = bug(0.04); scene.add(b); return { b, lp: V(...lp), t0: tKnock - 0.12 + i * 0.1, land: null, sp: splash2(0.22, 40 + i) }; });
  bugs.forEach(o => scene.add(o.sp));
  const f = carp(0.2, { seed: 9 }); scene.add(f);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      // fish glides in just under the surface, nudges the stems, turns and snaps a fallen bug
      const fx = t < tBump ? lerp(-0.75, -0.11, easeOut(range(t, 0, tBump))) : lerp(-0.11, -0.2, easeOut(range(t, tBump, tBump + 0.5)));
      const snap = easeInOut(range(t, tWater - 0.6, tWater));
      const last = bugs[3];
      f.position.set(lerp(fx, 0.14, snap), WY - lerp(0.045, 0.02, snap), lerp(0.06, 0.12, snap));
      f.face(snap > 0.01 && snap < 0.99 ? V(1, 0.25, 0.4) : V(1, 0, 0)); f.swim(t, t < tBump ? 9 : 6, 0.45);
      f.mouth(t > tWater - 0.15 && t < tWater + 0.25 ? 1 : 0);
      const dt = t - tBump;
      hero.rotation.z = dt > 0 ? 0.13 * Math.exp(-dt * 3) * Math.sin(dt * 15) : 0;
      hero.rotation.x = dt > 0 ? 0.06 * Math.exp(-dt * 3) * Math.sin(dt * 12 + 1) : 0;
      hero.updateMatrixWorld(true);
      bugs.forEach((o, i) => {
        const fall = t - o.t0;
        if (fall < 0) { o.b.position.copy(hero.localToWorld(o.lp.clone())); o.b.rotation.set(0, 0.4 + i, Math.PI / 2 * 0.9); o.b.visible = true; o.sp.update(-1); return; }
        const p0 = hero.localToWorld(o.lp.clone());
        const y = p0.y - 0.5 * 9.8 * fall * fall;
        const tl = Math.sqrt(2 * (p0.y - WY) / 9.8);
        if (fall < tl) { o.b.visible = true; o.b.position.set(p0.x + fall * 0.15 * (i % 2 ? 1 : -1), y, p0.z + fall * 0.1); o.b.rotation.set(fall * 12, i, fall * 9); o.sp.update(-1); }
        else {
          const lx = p0.x + tl * 0.15 * (i % 2 ? 1 : -1), lz = p0.z + tl * 0.1;
          o.sp.position.set(lx, WY, lz); o.sp.update(fall - tl);
          const eaten = i === 3 && t > tWater;
          o.b.visible = !eaten; o.b.position.set(lx + Math.sin(t * 9 + i) * 0.003, WY + 0.004, lz); o.b.rotation.set(0, i + t, Math.sin(t * 20) * 0.2);
        }
      });
      const k = easeInOut(range(t, 0, 4.2));
      const pos = [lerp(0.34, 0.24, k), lerp(0.34, 0.3, k), lerp(0.7, 0.55, k)], look = [lerp(-0.02, 0.04, k), lerp(0.33, 0.28, k), 0];
      place(c, pos, look);
      return { bloom: 0.45, dof: { focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: 0.012, maxblur: 0.012 } };
    },
  };
}

// ============ D: rooting in the mud, oxygen bubbles rising ============
function shotD({ makeStage, start: ST }) {
  const tStir = at(10, 'stir') - ST, tOx = at(10, 'oxygen') - ST;
  const scene = makeStage({ shadowSize: 1 }); stripStudio(scene);
  underwaterWorld(scene, { surf: 0.42, density: 1.6, leaves: 0.6, particles: 900 });
  scene.add(tillers([[0.32, -0.28], [-0.38, -0.32], [0.05, -0.6], [0.55, 0.08], [-0.6, 0.0]], { h: 0.8, seed: 71 }));
  const f = carp(0.16, { seed: 12 }); scene.add(f);
  const cloud = mudCloud(40, { seed: 5, color: 0x6a4e30 }); cloud.scale.setScalar(1.6); scene.add(cloud);
  const cloud2 = mudCloud(26, { seed: 9, color: 0x7a5e3e, rate: 0.8 }); cloud2.scale.setScalar(1.4); scene.add(cloud2);
  const bm = new THREE.MeshPhysicalMaterial({ color: 0xeefcff, roughness: 0.02, transparent: true, opacity: 0.55, clearcoat: 1, envMapIntensity: 2.5 });
  const bubbles = [...Array(28)].map((_, i) => { const b = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 10), bm); scene.add(b); return { b, t0: tOx - 0.35 + i * 0.07, x: (Math.sin(i * 7.3) * 0.5) * 0.12, z: Math.cos(i * 3.1) * 0.06, s: 0.003 + (i % 4) * 0.0015, ph: i }; });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const dive = easeInOut(range(t, 0, Math.max(0.3, tStir - 0.1)));
      const bob = Math.sin(t * 7) * 0.006 * dive;
      f.position.set(lerp(-0.25, -0.03, dive), lerp(0.16, 0.07, dive) + bob, 0.0);
      f.face(V(1, lerp(0.0, -0.75, dive), 0)); f.swim(t, 13, 0.55);
      f.mouth(dive > 0.8 ? 0.5 + 0.5 * Math.sin(t * 16) : 0);
      const snout = f.position.clone().add(V(0.06, -0.055, 0).multiplyScalar(dive));
      cloud.position.set(snout.x + 0.01, 0.012, snout.z); cloud.update(t - (tStir - 0.15), t > tStir - 0.15);
      cloud2.position.set(snout.x - 0.05, 0.01, snout.z + 0.02); cloud2.update(t - (tStir + 0.2), t > tStir + 0.2);
      bubbles.forEach((o) => {
        const a = t - o.t0;
        o.b.visible = a > 0 && a < 3;
        if (!o.b.visible) return;
        o.b.position.set(snout.x + o.x + Math.sin(a * 6 + o.ph) * 0.006, 0.02 + a * 0.13, snout.z + o.z);
        o.b.scale.setScalar(o.s * (1 + a * 0.4));
      });
      const k = easeInOut(range(t, 0, 3.5));
      const lift = easeInOut(range(t, tOx - 0.2, tOx + 1.2));
      const pos = [lerp(0.12, 0.05, k), lerp(0.09, 0.12, lift), lerp(0.55, 0.42, k)], look = [lerp(0.0, 0.02, k), lerp(0.06, 0.16, lift), 0];
      place(c, pos, look);
      return { bloom: 0.6, warm: 0.5, sat: 1.15, dof: { focus: Math.hypot(pos[0] - snout.x, pos[1] - snout.y, pos[2] - snout.z), aperture: 0.009, maxblur: 0.011 } };
    },
  };
}

// ============ E: the result — rice basket, 7 of 10 pesticide cans pop, 1 of 4 sacks pops ============
function popScale(dt) { if (dt < 0) return 1; if (dt < 0.08) return 1 + 0.25 * dt / 0.08; return Math.max(0.001, 1.25 * (1 - (dt - 0.08) / 0.12)); }
function puffs(n, seed) {
  const g = new THREE.Group(); const tex = glowSprite().material.map;
  const list = [...Array(n)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color: 0xf2f2ee, transparent: true, opacity: 0, depthWrite: false })); g.add(s); return { s, d: V(Math.cos(i * 2.4 + seed), 0.6 + (i % 3) * 0.2, Math.sin(i * 2.4 + seed)).normalize() }; });
  g.update = (dt) => list.forEach(({ s, d }) => { const on = dt > 0.05 && dt < 0.6; s.visible = on; if (!on) return; const a = dt - 0.05; s.position.copy(d).multiplyScalar(0.03 + a * 0.18); s.scale.setScalar(0.05 + a * 0.12); s.material.opacity = 0.7 * (1 - a / 0.55); });
  g.update(-1);
  return g;
}
function shotE({ makeStage, start: ST }) {
  const tRes = at(12, 'result') - ST, tRice = at(12, 'rice') - ST, t68 = at(12, 'sixty') - ST, tPest = at(12, 'pesticide') - ST, tQ = at(12, 'quarter') - ST, tFert = at(12, 'fertilizer') - ST;
  const WY = 0.2;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.7, 0.5, 0.5], fog: 0.0032, shadowSize: 2.5, envI: 0.9 });
  dressWorld(scene, { y: WY, cover: 0.78, seed: 1 });
  fillLight(scene, [0.8, 0.4, 0.6], 0.55);
  const near = new THREE.Mesh(new THREE.PlaneGeometry(9, 5), waterMaterial({ color: 0x1f2c24, opacity: 1 })); near.rotation.x = -Math.PI / 2; near.position.set(0, WY + 0.004, -1.6); scene.add(near);
  scene.add(riceClumps(clumpGrid(-4, 4, -4, -0.6, 0.3, { y: 0.02, seed: 91 }), { h: 0.85, blades: 10, seed: 92 }));
  // grassy bund across the frame
  const bundMat = new THREE.MeshStandardMaterial({ color: 0x55712c, roughness: 0.95, bumpMap: fabricTexture(41), bumpScale: 3 });
  const bund = new THREE.Mesh(new THREE.BoxGeometry(9, 0.34, 0.8), bundMat); bund.position.set(0, 0.17, 0.35); bund.receiveShadow = true; scene.add(bund);
  const verge = new THREE.Mesh(new THREE.BoxGeometry(9, 0.3, 3.0), bundMat); verge.position.set(0, 0.15, 2.2); verge.receiveShadow = true; scene.add(verge);
  const grassSpots = []; for (let x = -4.4; x <= 4.4; x += 0.06) grassSpots.push([x + Math.sin(x * 13) * 0.02, 0.34, 0.35 + Math.sin(x * 7.7) * 0.32]);
  scene.add(riceClumps(grassSpots, { h: 0.08, hVar: 0.6, blades: 5, width: 0.006, color: 0x3f7a22, color2: 0x86b84a, spread: 0.8, sway: 0.01, seed: 93, cast: false }));
  const TOP = 0.34;
  const basket = riceBasket(); basket.position.set(-1.05, TOP, 0.42); scene.add(basket);
  const cans = [];
  for (let i = 0; i < 10; i++) { const j = jerrycan(); j.position.set(-0.42 + (i % 5) * 0.2, TOP, 0.28 + Math.floor(i / 5) * 0.2); j.rotation.y = 0.15 * Math.sin(i * 3); scene.add(j); const p = puffs(8, i); p.position.set(j.position.x, TOP + 0.12, j.position.z); scene.add(p); cans.push({ j, p, t0: i < 7 ? tPest - 0.15 + [0, 5, 2, 8, 1, 6, 3][i] * 0.05 : 1e9 }); }
  const order = [3, 1, 6, 0, 8, 4, 5]; // which cans vanish (mixed rows)
  cans.forEach((c, i) => { c.t0 = 1e9; }); order.forEach((ci, k) => { cans[ci].t0 = tPest - 0.18 + k * 0.06; });
  const sacks = [];
  [[0.95, 0, 0.42, 0], [1.6, 0, 0.42, 0.05], [1.27, 0.19, 0.42, -0.08], [1.3, 0.37, 0.44, 0.1]].forEach(([x, y, z, ry], i) => { const s = sack(i + 1); s.position.set(x, TOP + y, z); s.rotation.y = ry; scene.add(s); const p = puffs(10, i + 20); p.position.set(x, TOP + y + 0.1, z); scene.add(p); sacks.push({ s, p, t0: i === 3 ? tFert - 0.05 : 1e9 }); });
  const man = farmer2(); man.root.position.set(-0.45, 0.0, -2.9); man.root.rotation.y = 0.15; scene.add(man.root);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standPose(man, t, { head: [-0.05, 0.1 * Math.sin(t * 1.3), 0] }); man.setMood('happy'); man.setMouth(0.0); man.blink(blinkK(t, [1.0, 3.3, 5.6]));
      cans.forEach(({ j, p, t0 }) => { j.scale.setScalar(popScale(t - t0)); j.visible = t - t0 < 0.2; p.update(t - t0); });
      sacks.forEach(({ s, p, t0 }) => { s.scale.setScalar(popScale(t - t0)); s.visible = t - t0 < 0.2; p.update(t - t0); });
      const x = kf(t, [[0, -1.05], [Math.max(0.2, tRice + 0.2), -1.0], [t68 + 0.1, 0.0], [tPest + 0.4, 0.0], [tQ + 0.1, 1.25], [tFert + 1.2, 1.3]], easeInOut);
      const z = kf(t, [[0, 1.55], [tRice + 0.2, 1.45], [t68 + 0.1, 1.75], [tPest + 0.4, 1.7], [tQ + 0.1, 1.6], [tFert + 1.2, 1.75]], easeInOut);
      const pos = [x + 0.2, 0.92, z + 0.7], look = [x, TOP + 0.24, 0.1];
      place(c, pos, look);
      return { bloom: 0.4, dof: { focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: 0.0035, maxblur: 0.01 } };
    },
  };
}

// ============ F1: sunset over the terraces ("And now, this 1,200-year-old trick") ============
function shotF1({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.55, 0.1, -0.83], fog: 0.003, shadowSize: 40, shadowAt: [0, 4, 8], envI: 0.9, cloud: 0.32 });
  terraceWorld(scene, { workers: true });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(14, 8, k), lerp(8.5, 9.5, k), lerp(48, 44, k)], [lerp(-4, -6, k), lerp(4.6, 4.8, k), lerp(-6, -8, k)]);
      return { bloom: 0.6, flare: 0.9, warm: 1.25 };
    },
  };
}

// ============ F2: a paddy farm under acacias at sunset ("spreading to farms in Africa and Southeast Asia") ============
function shotF2({ makeStage }) {
  const WY = 0.18;
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.55, 0.11, -0.83], fog: 0.0036, shadowSize: 4, envI: 0.95, cloud: 0.25 });
  const f = fields(700, { cover: 0.45, rice: 0x5e9a30, rice2: 0x9cc84c, water: 0x2b2a22, bundX: 12, bundZ: 9 }); f.position.y = WY; scene.add(f);
  scene.add(mountains({ rMin: 110, rMax: 330, height: 26, seed: 14, color: 0x7a5a3c }));
  const ac = [[-9, -14, 1.2], [12, -22, 1.4], [-22, -35, 1.6], [26, -40, 1.5], [3, -48, 1.8], [-36, -20, 1.3], [40, -18, 1.2], [-6, -70, 2.0], [18, -65, 1.8]];
  ac.forEach(([x, z, s], i) => { const a = acacia(s, i + 3); a.position.set(x, WY - 0.05, z); a.rotation.y = i; scene.add(a); });
  const b = birds(5, { from: [-40, 10, -40], to: [40, 14, -55], spread: 7, speed: 0.05, scale: 2.0, seed: 12 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const near = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), waterMaterial({ color: 0x24261f, opacity: 1 })); near.rotation.x = -Math.PI / 2; near.position.set(0, WY + 0.004, -1.6); scene.add(near);
  scene.add(riceClumps(clumpGrid(-3.6, 3.6, -5.5, 1.8, 0.3, { y: 0.0, seed: 101, skip: (x, z) => x * x + z * z < 0.35 }), { h: 0.7, blades: 9, seed: 102 }));
  // a different farmer: own skin tone, cap and shirt
  const man = farmer2();
  const M = materials();
  const skin = M.skin.clone(); skin.color.set(0x7a4a2e); skin.sheenColor = new THREE.Color(0xc08060);
  const shirt = new THREE.MeshStandardMaterial({ color: 0xd9822b, roughness: 0.95 });
  man.root.traverse(o => { if (o.isMesh) { if (o.material === M.skin) o.material = skin; else if (o.material.color && o.material.color.getHex() === 0x4d6f99) o.material = shirt; } });
  man.hat.visible = false;
  const hatC = cap(0x2b3a55); hatC.position.set(0, 0.17, -0.005); man.j.head.add(hatC);
  man.root.rotation.y = -0.25; scene.add(man.root);
  const fish = carp(0.3, { seed: 15 }); scene.add(fish);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const up = easeOut(range(t, 0.0, 0.6));
      standPose(man, t, { rSh: [lerp(0.05, -2.2, up), 0, lerp(-0.16, -0.25, up)], rEl: [lerp(-0.25, -0.3, up), 0, 0], lSh: [0.05, 0, 0.25], head: [-0.08, 0.12, 0] });
      man.setMood('happy'); man.setMouth(0.4); man.blink(blinkK(t, [1.6, 3.9])); man.grip(0.3, 0.95);
      scene.updateMatrixWorld(true);
      const rh = wpos(man.j.rWr, V(0, -0.06, 0));
      fish.position.copy(rh).add(V(0, 0.0, 0.07)); fish.rotation.set(0, 0, 1.3 + Math.sin(t * 9) * 0.12); fish.swim(t, 12, 0.6);
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(-0.4, -1.4, k), lerp(1.45, 2.4, k), lerp(2.6, 5.6, k)], [lerp(0.05, 0.0, k), lerp(1.4, 1.2, k), lerp(0, -3, k)]);
      return { bloom: 0.6, flare: 0.9, warm: 1.3 };
    },
  };
}

// ============ timeline: reused v4 segments are placeholders here (never rendered) ============
function placeholder({ makeStage }) {
  const scene = makeStage({}); const c = cam(40); place(c, [0, 1, 3], [0, 1, 0]);
  return { scene, camera: c, update() { return {}; } };
}
const BUILD = { A: shotA, H: shotH, B: shotB, C: shotC, D: shotD, E: shotE };
export const SHOTS = [];
for (const b of BLOCKS) {
  const s = b.f0 / 24, e = b.f1 / 24;
  if (b.id === 's1') SHOTS.push({ start: 0, end: 2.17, build: shot1, id: 's1a' }, { start: 2.17, end: 2.75, build: shotFace, id: 's1b' }, { start: 2.75, end: e, build: (a) => shot2({ ...a, start: 2.75 }), id: 's1c' });
  else if (b.id === 's2') SHOTS.push({ start: s, end: e, build: shot3, id: 's2' });
  else if (b.id === 's3') SHOTS.push({ start: s, end: e, build: (a) => shot4({ ...a, start: 212 / 24 }), id: 's3' });
  else if (b.id === 's4') SHOTS.push({ start: s, end: e, build: (a) => shot5({ ...a, start: 308 / 24 }), id: 's4' });
  else if (b.id === 's5') SHOTS.push({ start: s, end: e, build: (a) => shot6({ ...a, start: 373 / 24 }), id: 's5' });
  else if (b.id === 's6') SHOTS.push({ start: s, end: e, build: (a) => shot7({ ...a, start: 442 / 24 }), id: 's6' });
  else if (b.id === 's7') SHOTS.push({ start: s, end: e, build: shot8, id: 's7' });
  else if (b.id === 's8') SHOTS.push({ start: s, end: e, build: (a) => shot9({ ...a, start: 25.75 }), id: 's8' });
  else if (b.kind === 'seg') SHOTS.push({ start: s, end: e, build: placeholder, id: b.id });
  else if (b.id === 'F') {
    const cut = at(14, 'is') - 0.06;
    SHOTS.push({ start: s, end: cut, build: shotF1, id: 'F1' }, { start: cut, end: e + 1, build: shotF2, id: 'F2' });
  } else SHOTS.push({ start: s, end: e, build: BUILD[b.id], id: b.id });
}
