// The Explainer: why an octopus has three hearts (and blue blood). Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { sea, octopus, textSprite, bloodDrop } from './ocean.js';
import { VO } from './vo_oc.js';
import { rng } from './textures.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This animal', 2], ['has *three hearts*', 3], ['and its blood', 3], ['is *blue*', 2]],
  [['Two *small hearts*', 3], ['sit at the base', 4], ['of its *gills*', 3]],
  [['Each one', 2], ['*pumps blood*', 2], ['through a *gill*', 3], ['to pick up', 3], ['*oxygen*', 1]],
  [['Then the *big*', 3], ['*third heart*', 2], ['pushes it around', 3], ['the *whole body*', 3]],
  [['Like two', 2], ['*booster pumps*', 2], ['feeding one', 2], ['*main pump*', 2]],
  [['But when', 2], ['the octopus *swims*', 3], ['that *main heart*', 3], ['*stops beating*', 2]],
  [['That may be why', 4], ['octopuses would', 2], ['rather *crawl*', 2]],
  [['And the *blue?*', 3], ['Their blood', 2], ['carries *oxygen*', 2], ['with *copper*', 2], ['not *iron*', 2], ['like ours', 2]],
  [['That *copper*', 2], ['turns *blue*', 2], ['when it grabs', 3], ['*oxygen*', 1]],
  [['It may work', 3], ['better in', 2], ['*cold water*', 2], ['with *little oxygen*', 3]],
  [['But it', 2], ['carries *less*', 2], ['so *three hearts*', 3], ['keep it *moving*', 3]],
  [['*Three hearts*', 2], ['*blue blood*', 2], ['and not a', 3], ['*single bone*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.01; c.far = 200; return c; };
const FLOOR = -0.12;
// orbit camera: target, distance, azimuth (deg, 0 = from +z), elevation (deg)
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const wp = (o) => { const v = new THREE.Vector3(); o.updateWorldMatrix(true, false); o.getWorldPosition(v); return [v.x, v.y, v.z]; };
// octopus standing on the sand: G at the height where the crown sits just above the floor
function reef(makeStage, opts = {}) {
  const scene = makeStage({ shadowSize: 3, sunDir: [0.6, 6, 1.2] });
  const S = sea(scene, opts);
  const O = octopus({ seed: opts.seed || 1 }); scene.add(O.group);
  O.st.floorY = FLOOR;
  O.group.position.set(0, FLOOR + 0.16, 0);
  scene.userData.updaters.push((t) => O.update(t));
  return { scene, S, O };
}
const POST = { bloom: 0.55, warm: 0.95, sat: 1.15, exposure: 1.05 };

// ============ S0 hook: x-ray octopus on the reef, three hearts beating, blue blood running ============
function sHook({ makeStage }) {
  const { scene, O } = reef(makeStage);
  O.group.rotation.y = 0.35;
  const c = C(34);
  const T3 = at(0, 'three') - ls(0), TB = at(0, 'blue') - ls(0);
  return {
    scene, camera: c,
    update(t) {
      O.st.xray = 1; O.st.rate = 1.3;
      O.st.glowMain = O.st.glowGill = 0.6 * Math.exp(-Math.pow((t - T3 - 0.3) / 0.35, 2));
      O.st.flow = 1 + 0.8 * smooth(range(t, TB - 0.3, TB + 0.3));
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [0, lerp(0.16, 0.2, k), -0.04], lerp(1.45, 1.1, k), lerp(28, 18, k), lerp(14, 10, k));
      return POST;
    },
  };
}
// ============ S1: inside the mantle: the two small hearts at the base of the gills ============
function sGills({ makeStage }) {
  const { scene, O } = reef(makeStage);
  O.group.rotation.y = -0.5;
  const c = C(30);
  const TH = at(1, 'hearts') - ls(1), TG = at(1, 'gills') - ls(1);
  return {
    scene, camera: c,
    update(t) {
      O.st.xray = 1; O.st.rate = 1.2;
      O.st.glowGill = 0.9 * smooth(range(t, TH - 0.2, TH + 0.2)) * (1 - smooth(range(t, TG - 0.2, TG + 0.4)) * 0.6);
      O.st.gillGlow = smooth(range(t, TG - 0.3, TG + 0.2));
      O.st.glowMain = 0;
      const k = easeInOut(range(t, 0, 2.6));
      orb(c, [0, 0.24, -0.12], lerp(0.95, 0.8, k), lerp(205, 190, k), 14);
      return { ...POST, ao: 0.6 };
    },
  };
}
// ============ S2: one gill close: pale blood goes in, blue blood comes out ============
function sOxy({ makeStage }) {
  const { scene, O } = reef(makeStage);
  O.group.rotation.y = -1.1;
  const c = C(26);
  return {
    scene, camera: c,
    update(t) {
      O.st.xray = 1; O.st.rate = 1.2; O.st.flow = 0.8; O.st.gillGlow = 0.6 + 0.4 * smooth(range(t, 1.2, 2.2)); O.st.glowGill = 0.4;
      const k = easeInOut(range(t, 0, 3.4));
      const g = wp(O.gills[0]); orb(c, [g[0], g[1] + 0.05, g[2]], lerp(0.85, 0.7, k), lerp(-150, -135, k), 26);
      return { ...POST, ao: 0.5 };
    },
  };
}
// ============ S3: the big heart pumps blue blood out to the arms ============
function sMain({ makeStage }) {
  const { scene, O } = reef(makeStage);
  O.group.rotation.y = 0.2;
  const c = C(36);
  const TB = at(3, 'big') - ls(3);
  return {
    scene, camera: c,
    update(t) {
      O.st.xray = 1; O.st.rate = 1.2; O.st.flow = 1.4;
      O.st.glowMain = 0.9 * smooth(range(t, TB - 0.1, TB + 0.3));
      const k = easeInOut(range(t, 0, 3.0));
      orb(c, [0, lerp(0.22, 0.12, k), lerp(-0.1, 0, k)], lerp(0.8, 2.1, k), lerp(195, 210, k), lerp(14, 22, k));
      return POST;
    },
  };
}
// ============ S4: two booster pumps feeding one main pump (highlight order) ============
function sPumps({ makeStage }) {
  const { scene, O } = reef(makeStage);
  O.group.rotation.y = Math.PI + 0.25;
  const c = C(30);
  const TBo = at(4, 'booster') - ls(4), TM = at(4, 'main') - ls(4);
  return {
    scene, camera: c,
    update(t) {
      O.st.xray = 1; O.st.rate = 1.2; O.st.flow = 1.2;
      O.st.glowGill = 1.0 * smooth(range(t, TBo - 0.2, TBo + 0.2)) * (1 - 0.7 * smooth(range(t, TM - 0.3, TM)));
      O.st.glowMain = 1.0 * smooth(range(t, TM - 0.2, TM + 0.2));
      const k = easeInOut(range(t, 0, 2.7));
      orb(c, [0, 0.24, -0.12], lerp(0.85, 0.75, k), lerp(160, 172, k), 18);
      return { ...POST, ao: 0.6 };
    },
  };
}
// ============ S5: the octopus jets off; its main heart stops ============
function sSwim({ makeStage }) {
  const { scene, O } = reef(makeStage, { seed: 2 });
  O.st.floorY = null;
  const c = C(38);
  const TS = at(5, 'swims') - ls(5), TStop = at(5, 'stops') - ls(5);
  return {
    scene, camera: c,
    update(t) {
      const go = smooth(range(t, TS - 0.6, TS + 0.2));
      O.st.xray = 1; O.st.swim = go; O.st.rate = 1.3; O.st.floorY = go < 0.3 ? FLOOR : null;
      O.st.beatMain = 1 - smooth(range(t, TStop - 0.5, TStop + 0.1));
      // lift off and glide to +x, mantle first
      const x = go * (t - (TS - 0.6)) * 0.28;
      O.group.position.set(x, FLOOR + 0.16 + go * 0.25, 0);
      O.group.rotation.set(0, 0, -go * 1.3);
      const m = wp(O.mantle); orb(c, [m[0] + 0.02, m[1] - 0.06, 0], 2.1, 12, 6);
      return POST;
    },
  };
}
// ============ S6: crawling on the sand ============
function sCrawl({ makeStage }) {
  const { scene, O } = reef(makeStage, { seed: 4 });
  O.st.xray = 0; O.st.crawl = 1;
  O.group.rotation.y = Math.PI / 2;
  const c = C(36);
  return {
    scene, camera: c,
    update(t) {
      const x = -0.3 + t * 0.12;
      O.group.position.set(x, FLOOR + 0.15 + 0.012 * Math.sin(t * 5.2), 0);
      orb(c, [x + 0.05, 0.08, 0], 1.6, 20, 7);
      return POST;
    },
  };
}
// ============ S7: copper vs iron: a blue drop and a red drop ============
function sMetals({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [1, 5, 3] });
  sea(scene, { rocks: false, coral: false, fogColor: 0x12324a, density: 0.08 });
  const blueD = bloodDrop(0x2a5cff, 0xc87533); blueD.group.position.set(-0.34, 0.2, 0); scene.add(blueD.group);
  const redD = bloodDrop(0xd8202a, 0x8a8f96); redD.group.position.set(0.34, 0.2, 0); scene.add(redD.group);
  const cu = textSprite('Cu', { size: 0.2, color: '#ffb37a' }); cu.position.set(-0.34, 1.05, 0.1); scene.add(cu);
  const fe = textSprite('Fe', { size: 0.2, color: '#e6e6e6' }); fe.position.set(0.34, 1.05, 0.1); scene.add(fe);
  const pl = new THREE.PointLight(0xffffff, 2, 4); pl.position.set(0, 1.2, 1.2); scene.add(pl);
  const O = octopus({ seed: 5 }); O.group.scale.setScalar(0.7); O.group.position.set(-0.5, FLOOR + 0.11, 0.3); O.group.rotation.y = 0.5; scene.add(O.group); O.st.floorY = FLOOR;
  scene.userData.updaters.push((t) => O.update(t));
  const c = C(36);
  const TC = at(7, 'copper') - ls(7), TI = at(7, 'iron') - ls(7);
  return {
    scene, camera: c,
    update(t) {
      const kb = easeOut(range(t, 0, 0.6)), kc = smooth(range(t, TC - 0.3, TC + 0.2)), ki = smooth(range(t, TI - 0.3, TI + 0.2));
      blueD.group.scale.setScalar(0.32 + 0.3 * kb); redD.group.scale.setScalar(0.62 * ki);
      blueD.atom.rotation.y = t; redD.atom.rotation.y = -t;
      blueD.atom.scale.setScalar(0.4 + 0.6 * kc + 0.15 * Math.exp(-Math.pow((t - TC - 0.2) / 0.2, 2)));
      cu.material.opacity = kc; fe.material.opacity = ki;
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0, 0.5, 0], lerp(3.0, 3.3, k), lerp(-6, 0, k), 4);
      return { ...POST, bloom: 0.7 };
    },
  };
}
// ============ S8: two copper atoms grab an oxygen molecule; the protein turns blue ============
function sMolecule({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [1, 5, 3] });
  sea(scene, { rocks: false, coral: false, fogColor: 0x0d2236, density: 0.05 });
  scene.children.filter(o => o.isMesh && o.geometry && o.geometry.type === 'PlaneGeometry' && o.geometry.parameters.width > 20).forEach(o => { o.visible = false; });
  const R = rng(9);
  // protein: lumpy translucent blob of spheres
  const prot = new THREE.Group(); scene.add(prot);
  const pm = new THREE.MeshPhysicalMaterial({ color: 0xbfc4cc, roughness: 0.35, clearcoat: 0.8, transparent: true, opacity: 0.38, depthWrite: false, emissive: new THREE.Color(0x1f5cff), emissiveIntensity: 0 });
  for (let i = 0; i < 46; i++) { const a = R() * Math.PI * 2, b = Math.acos(2 * R() - 1), r = 0.3 + R() * 0.08; const s = new THREE.Mesh(new THREE.SphereGeometry(0.07 + R() * 0.05, 16, 12), pm); s.position.set(Math.sin(b) * Math.cos(a) * r * 1.2, Math.cos(b) * r * 0.9, Math.sin(b) * Math.sin(a) * r * 0.7 - 0.12); prot.add(s); }
  const cuM = new THREE.MeshStandardMaterial({ color: 0xd07a3a, metalness: 1, roughness: 0.22 });
  const cuA = new THREE.Mesh(new THREE.SphereGeometry(0.075, 32, 20), cuM); cuA.position.set(-0.1, 0, 0.12); prot.add(cuA);
  const cuB = cuA.clone(); cuB.position.x = 0.1; prot.add(cuB);
  const oM = new THREE.MeshStandardMaterial({ color: 0xe8333a, roughness: 0.3 });
  const O2 = new THREE.Group(); const o1 = new THREE.Mesh(new THREE.SphereGeometry(0.055, 24, 16), oM), o2 = o1.clone(); o1.position.x = -0.04; o2.position.x = 0.04; O2.add(o1, o2); scene.add(O2);
  const glow = new THREE.PointLight(0x3a6bff, 0, 2); glow.position.set(0, 0, 0.3); scene.add(glow);
  const lab = textSprite('O₂', { size: 0.12, color: '#ffffff' }); scene.add(lab);
  const cl = textSprite('Cu', { size: 0.09, color: '#ffb37a' }); cl.position.set(-0.1, -0.17, 0.25); scene.add(cl);
  const cr = textSprite('Cu', { size: 0.09, color: '#ffb37a' }); cr.position.set(0.1, -0.17, 0.25); scene.add(cr);
  const fill = new THREE.PointLight(0xffffff, 1.5, 3); fill.position.set(0.4, 0.6, 1); scene.add(fill);
  const c = C(34);
  const TG = at(8, 'grabs') - ls(8);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0.2, TG + 0.1));
      O2.position.set(lerp(0.55, 0, k), lerp(0.55, 0.0, k), lerp(0.4, 0.14, k)); O2.rotation.z = (1 - k) * 2.5 + Math.sin(t * 2) * 0.1 * (1 - k);
      lab.position.set(O2.position.x, O2.position.y + 0.11, O2.position.z + 0.05); lab.material.opacity = 1 - smooth(range(t, TG, TG + 0.4));
      const b = smooth(range(t, TG - 0.1, TG + 0.6));
      pm.color.set(0xbfc4cc).lerp(new THREE.Color(0x3c6dff), b); pm.emissiveIntensity = 0.6 * b; pm.opacity = 0.38 + 0.25 * b; glow.intensity = 3 * b;
      prot.rotation.y = Math.sin(t * 0.5) * 0.15;
      orb(c, [0, 0.08, 0], lerp(2.3, 2.0, t / 3), lerp(10, 2, t / 3), 6);
      return { ...POST, bloom: 0.8, ao: 0 };
    },
  };
}
// ============ S9: cold, dim water under the ice: the octopus at home ============
function sCold({ makeStage }) {
  const { scene, O } = reef(makeStage, { cold: true, fogColor: 0x0f2c44, density: 0.16, sand: 0x6c6a66, seed: 6 });
  // sea ice overhead
  const ice = new THREE.Mesh(new THREE.PlaneGeometry(40, 40, 60, 60), new THREE.MeshStandardMaterial({ color: 0xdfefff, roughness: 0.3, emissive: 0x9fc8ff, emissiveIntensity: 0.35, side: THREE.DoubleSide }));
  const p = ice.geometry.attributes.position; for (let i = 0; i < p.count; i++) p.setZ(i, Math.sin(p.getX(i) * 1.3) * Math.cos(p.getY(i) * 1.1) * 0.25);
  ice.geometry.computeVertexNormals(); ice.rotation.x = Math.PI / 2; ice.position.y = 1.7; scene.add(ice);
  O.group.rotation.y = 0.6; O.st.rate = 0.7;
  const c = C(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.2));
      orb(c, [0, lerp(0.6, 0.4, k), 0], lerp(2.0, 1.85, k), lerp(-25, -15, k), lerp(-16, -11, k));
      return { bloom: 0.4, warm: 0.75, sat: 0.9, exposure: 1.0 };
    },
  };
}
// ============ S10: three hearts working hard ============
function sHard({ makeStage }) {
  const { scene, O } = reef(makeStage, { seed: 7 });
  O.group.rotation.y = 0.9;
  const c = C(30);
  const TT = at(10, 'three') - ls(10);
  return {
    scene, camera: c,
    update(t) {
      O.st.xray = 1; O.st.rate = 1.2 + 0.8 * smooth(range(t, 0.5, 2.0)); O.st.flow = 1.2 + smooth(range(t, 0.5, 2.0));
      const g = smooth(range(t, TT - 0.2, TT + 0.3)); O.st.glowMain = O.st.glowGill = 0.7 * g;
      const k = easeInOut(range(t, 0, 3.0));
      orb(c, [0, 0.2, -0.06], lerp(1.2, 0.95, k), lerp(40, 25, k), 12);
      return POST;
    },
  };
}
// ============ S11: no bones: it pours itself into a small hole in a rock ============
function sBone({ makeStage }) {
  const { scene, O } = reef(makeStage, { seed: 8 });
  const HY = FLOOR + 0.14, HR = 0.075;
  // rock slab across the view (faces +x) with a small round hole
  const shape = new THREE.Shape(); shape.moveTo(-0.9, -0.2); shape.lineTo(0.9, -0.2); shape.bezierCurveTo(0.9, 0.5, 0.4, 0.75, 0, 0.78); shape.bezierCurveTo(-0.5, 0.75, -0.9, 0.5, -0.9, -0.2);
  const hole = new THREE.Path(); hole.absarc(0, HY - FLOOR, HR, 0, Math.PI * 2, true); shape.holes.push(hole);
  const slab = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: 0.22, bevelEnabled: true, bevelSize: 0.04, bevelThickness: 0.04, bevelSegments: 3, curveSegments: 40 }), new THREE.MeshStandardMaterial({ color: 0x7d7264, roughness: 0.92 }));
  slab.rotation.y = Math.PI / 2; slab.position.set(-0.22, FLOOR, 0); slab.castShadow = slab.receiveShadow = true; scene.add(slab);
  const dark = new THREE.Mesh(new THREE.CircleGeometry(HR * 0.98, 32), new THREE.MeshBasicMaterial({ color: 0x050a0c })); dark.rotation.y = Math.PI / 2; dark.position.set(-0.3, HY, 0); scene.add(dark);
  const c = C(36);
  const TN = at(11, 'not') - ls(11);
  return {
    scene, camera: c,
    update(t) {
      // sits facing the camera, x-ray on; then turns, arms into the hole, body squeezes in after them
      const k = easeInOut(range(t, TN - 0.05, TN + 1.5));
      const x = lerp(0.42, -0.62, k);
      O.st.xray = 1 - smooth(range(t, TN - 0.25, TN + 0.15));
      O.st.floorY = k > 0.02 ? null : FLOOR;
      O.st.swim = smooth(range(t, TN - 0.25, TN + 0.3)); O.st.reach = 0.0; O.st.tight = smooth(range(t, TN, TN + 0.5));
      O.st.squash = Math.exp(-Math.pow((x + 0.1) / 0.22, 2)) * (x < 0.2 ? 1 : 0) + (x < -0.1 ? 1 : 0) * 0.9;
      O.st.squash = Math.min(1, O.st.squash);
      O.group.rotation.set(0, 0, -Math.PI / 2 * O.st.swim);
      O.group.position.set(x, lerp(FLOOR + 0.16, HY, O.st.swim), 0);
      O.group.visible = x > -0.6;
      orb(c, [lerp(0.3, 0.0, smooth(range(t, TN - 0.2, TN + 1.4))), HY + 0.08, 0], 2.7, 64, 7);
      return POST;
    },
  };
}

// ============ timeline ============
const SH = [sHook, sGills, sOxy, sMain, sPumps, sSwim, sCrawl, sMetals, sMolecule, sCold, sHard, sBone];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
