// The Explainer: the Falkirk Wheel. Rotating boat lift, gondolas kept level by gears, canals, boat, props.
// Units: metres. Hub at (0, HUB, 0); axle along z; gondolas long along z; lower basin water at y = 0, aqueduct water at y = LIFT.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TIME, NOISE, trees } from './world.js';
import { rng } from './textures.js';

export const LIFT = 24, ARM = 12, HUB = 10.5, GL = 22;  // gondola centres at HUB +- ARM

const steelM = () => new THREE.MeshStandardMaterial({ color: 0xc9cfd6, metalness: 0.75, roughness: 0.3 });
export function waterMat(color = 0x2f6f8a, op = 0.92) {
  const m = new THREE.MeshPhysicalMaterial({ color, roughness: 0.08, metalness: 0.0, transparent: true, opacity: op, clearcoat: 1 });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = TIME;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWw;').replace('#include <project_vertex>', '#include <project_vertex>\nvWw = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWw; uniform float uTime;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float r = fbm(vWw.xz * 0.6 + vec2(uTime * 0.15, uTime * 0.1)); diffuseColor.rgb *= 0.85 + 0.35 * r;`);
  };
  return m;
}

// ---------------- landscape: lower basin, hills, the aqueduct leading off at the top ----------------
export function site(scene, { seed = 4 } = {}) {
  const R = rng(seed);
  const grass = new THREE.MeshStandardMaterial({ color: 0x5c8f3c, roughness: 1 });
  const g = new THREE.Mesh(new THREE.PlaneGeometry(600, 600, 300, 300), grass);
  const p = g.geometry.attributes.position;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); const d = Math.hypot(x, y + 20);
    // plane y = -world z. Pit for the basin and the wheel (world z -16..80, |x| < 20) below the water line
    const inPit = Math.abs(x) < 20 && -y > -16 && -y < 80;
    p.setZ(i, inPit ? -7 : Math.max(0, (d - 45)) * 0.12 * (0.6 + 0.4 * Math.sin(x * 0.02)) + 0.6 + (y > 60 ? (y - 60) * 0.35 : 0)); }
  g.geometry.computeVertexNormals(); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; scene.add(g);
  // basin (lower canal) water and its quay
  const basin = new THREE.Mesh(new THREE.PlaneGeometry(40, 96), waterMat()); basin.rotation.x = -Math.PI / 2; basin.position.set(0, 0.0, 32); scene.add(basin);
  const quayM = new THREE.MeshStandardMaterial({ color: 0xb7b0a3, roughness: 0.9 });
  [-1, 1].forEach((s) => { const q = new THREE.Mesh(new THREE.BoxGeometry(4, 8.6, 96), quayM); q.position.set(s * 22, -3.2, 32); q.receiveShadow = true; scene.add(q); });
  const back = new THREE.Mesh(new THREE.BoxGeometry(48, 8.6, 4), quayM); back.position.set(0, -3.2, -18); scene.add(back);
  // aqueduct: concrete channel on round arches, running from the top gondola towards -z, water at LIFT
  const aq = new THREE.Group(); scene.add(aq);
  const cm = new THREE.MeshStandardMaterial({ color: 0xd8d3c8, roughness: 0.85 });
  const len = 90, z0 = -GL / 2 - 2;
  const floor = new THREE.Mesh(new THREE.BoxGeometry(7, 1.2, len), cm); floor.position.set(0, LIFT - 2.1, z0 - len / 2); floor.castShadow = floor.receiveShadow = true; aq.add(floor);
  [-1, 1].forEach((s) => { const w = new THREE.Mesh(new THREE.BoxGeometry(0.8, 3.2, len), cm); w.position.set(s * 3.9, LIFT - 0.9, z0 - len / 2); w.castShadow = true; aq.add(w); });
  const aw = new THREE.Mesh(new THREE.PlaneGeometry(7, len), waterMat()); aw.rotation.x = -Math.PI / 2; aw.position.set(0, LIFT, z0 - len / 2); aq.add(aw);
  for (let k = 0; k < 8; k++) { const zz = z0 - 6 - k * 11; const h = LIFT - 2.7 - Math.max(0, (k - 3)) * 2.5; const pier = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.5, h + 1, 16), cm); pier.position.set(0, h / 2 - 0.5, zz); pier.castShadow = true; aq.add(pier); }
  // a few trees and the visitor centre block
  const spots = []; for (let k = 0; k < 120; k++) { const a = R() * Math.PI * 2, r = 50 + R() * 200; const x = Math.cos(a) * r, z = Math.sin(a) * r; if (Math.abs(x) < 15 && z < -10) continue; if (Math.abs(x) < 45 && z > -20 && z < 130) continue; spots.push([x, 0.5 + Math.max(0, r - 45) * 0.08, z]); }
  scene.add(trees(spots, { seed, scale: 3.2 }));
  const vc = new THREE.Mesh(new RoundedBoxGeometry(30, 6, 14, 2, 1), new THREE.MeshStandardMaterial({ color: 0xece6da, roughness: 0.6 })); vc.position.set(-45, 3, 40); vc.castShadow = true; scene.add(vc);
  return { basin, aqueduct: aq };
}

// ---------------- the wheel ----------------
function gondola() {
  const g = new THREE.Group();
  const shell = steelM();
  // trough: open box with rounded bottom (half cylinder) and end gates
  const prof = new THREE.Shape(); prof.moveTo(-3.2, 2.2); prof.lineTo(-3.2, 0); prof.absarc(0, 0, 3.2, Math.PI, 2 * Math.PI, false); prof.lineTo(3.2, 2.2); prof.lineTo(2.8, 2.2); prof.lineTo(2.8, 0); prof.absarc(0, 0, 2.8, 2 * Math.PI, Math.PI, true); prof.lineTo(-2.8, 2.2); prof.closePath();
  const body = new THREE.Mesh(new THREE.ExtrudeGeometry(prof, { depth: GL, bevelEnabled: false, curveSegments: 24 }), shell); body.position.z = -GL / 2; body.castShadow = true; g.add(body);
  const water = new THREE.Mesh(new THREE.BoxGeometry(5.5, 0.05, GL - 0.4), waterMat()); water.position.y = 1.5; g.add(water);
  const gates = [-1, 1].map((s) => { const gt = new THREE.Mesh(new THREE.BoxGeometry(6.4, 5.2, 0.4), shell); gt.position.set(0, -0.4, s * GL / 2); g.add(gt); return gt; });
  return { group: g, gates, water };
}
function gear(radius, teeth, width, color = 0x3b3f46) {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color, metalness: 0.7, roughness: 0.35 });
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, width, 48), m); disc.rotation.x = Math.PI / 2; g.add(disc);
  for (let k = 0; k < teeth; k++) { const a = k / teeth * Math.PI * 2; const t = new THREE.Mesh(new THREE.BoxGeometry(radius * 0.16, radius * 0.18, width), m); t.position.set(Math.cos(a) * radius * 1.06, Math.sin(a) * radius * 1.06, 0); t.rotation.z = a; g.add(t); }
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.25, radius * 0.25, width * 1.3, 24), new THREE.MeshStandardMaterial({ color: 0xffc23a, metalness: 0.6, roughness: 0.3 })); hub.rotation.x = Math.PI / 2; g.add(hub);
  return g;
}
export function wheel() {
  const W = new THREE.Group();
  const armM = new THREE.MeshStandardMaterial({ color: 0xdfe3e8, metalness: 0.6, roughness: 0.32 });
  // central spine on a pivot
  const spine = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, GL + 6, 32), armM); spine.rotation.x = Math.PI / 2; spine.position.y = HUB; W.add(spine);
  const pivot = new THREE.Mesh(new RoundedBoxGeometry(6, HUB, 5, 2, 0.6), new THREE.MeshStandardMaterial({ color: 0xbdb6aa, roughness: 0.85 })); pivot.position.set(0, HUB / 2 - 1, -GL / 2 - 4.5); pivot.castShadow = true; W.add(pivot);
  const rot = new THREE.Group(); rot.position.y = HUB; W.add(rot);
  // two arms (front and back): double-headed axe shape, curved blades
  const sh = new THREE.Shape();
  const r0 = ARM + 4.2;
  sh.moveTo(-r0, 1.0); sh.bezierCurveTo(-r0 * 0.6, 3.4, -4, 2.2, 0, 2.6); sh.bezierCurveTo(4, 3.0, r0 * 0.55, 6.5, r0, 4.5); sh.bezierCurveTo(r0 + 2.2, 2.0, r0 + 1.5, -1.2, r0, -1.0);
  sh.bezierCurveTo(r0 * 0.6, -3.4, 4, -2.2, 0, -2.6); sh.bezierCurveTo(-4, -3.0, -r0 * 0.55, -6.5, -r0, -4.5); sh.bezierCurveTo(-r0 - 2.2, -2.0, -r0 - 1.5, 1.2, -r0, 1.0);
  [-ARM, ARM].forEach((x) => { const h = new THREE.Path(); h.absarc(x, 0, 3.7, 0, Math.PI * 2, true); sh.holes.push(h); });
  const armGeo = new THREE.ExtrudeGeometry(sh, { depth: 1.2, bevelEnabled: true, bevelSize: 0.25, bevelThickness: 0.25, bevelSegments: 2, curveSegments: 32 });
  [-1, 1].forEach((s) => { const a = new THREE.Mesh(armGeo, armM); a.position.z = s * (GL / 2 + 1.2) - 0.6; a.castShadow = true; rot.add(a); });
  // gears on the back arm: fixed sun gear at the hub, two idlers, one gear per gondola (keeps them level)
  const gearSet = new THREE.Group(); gearSet.position.z = GL / 2 + 2.6; rot.add(gearSet);
  const sun = gear(2.2, 18, 0.8); gearSet.add(sun); // counter-rotated so it stays fixed in the world
  const idlers = [], ends = [];
  [-1, 1].forEach((s) => { const id = gear(1.6, 14, 0.8, 0x5a5f66); id.position.x = s * 4.2; gearSet.add(id); idlers.push(id); const e = gear(2.2, 18, 0.8); e.position.x = s * ARM * 0.62; gearSet.add(e); ends.push(e); });
  // gondolas: positioned by angle, never rotated
  const G = [gondola(), gondola()]; G.forEach((g) => { g.group.position.y = HUB; W.add(g.group); });
  const st = { angle: 0, gates: 1, gears: 0 };
  function update() {
    rot.rotation.z = st.angle; gearSet.visible = st.gears > 0;
    sun.rotation.z = -st.angle; idlers.forEach((g) => { g.rotation.z = st.angle * 1.375; }); ends.forEach((g) => { g.rotation.z = -st.angle; });
    G.forEach((g, i) => { const a = st.angle + (i ? 0 : Math.PI); g.group.position.set(Math.cos(a) * ARM, HUB + Math.sin(a) * ARM, 0); g.gates.forEach((gt) => { gt.position.y = -0.4 - (1 - st.gates) * 5.4; }); });
  }
  update();
  return { group: W, rot, gondolas: G, st, update, gearSet };
}
// angle so that gondola 0 is at the bottom (docked in the basin) and gondola 1 at the top (docked at the aqueduct)
export const ANG_DOWN = Math.PI / 2;  // gondola 0 at angle+PI = 3PI/2 -> bottom

// ---------------- narrowboat ----------------
export function boat(color = 0x2e6b3f) {
  const g = new THREE.Group();
  const hullM = new THREE.MeshStandardMaterial({ color: 0x1f2328, roughness: 0.5 });
  const sh = new THREE.Shape(); sh.moveTo(-0.95, 0); sh.lineTo(0.95, 0); sh.lineTo(0.95, 8.5); sh.quadraticCurveTo(0.95, 10, 0, 10.6); sh.quadraticCurveTo(-0.95, 10, -0.95, 8.5); sh.closePath();
  const hull = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: 1.1, bevelEnabled: false }), hullM); hull.rotation.x = -Math.PI / 2; hull.position.set(0, -0.6, 5.3); hull.castShadow = true; g.add(hull);
  hull.rotation.set(Math.PI / 2, 0, 0); hull.position.set(0, 0.5, -5.3);
  const cabin = new THREE.Mesh(new RoundedBoxGeometry(1.7, 1.2, 6.5, 2, 0.15), new THREE.MeshStandardMaterial({ color, roughness: 0.5 })); cabin.position.set(0, 1.1, -0.6); cabin.castShadow = true; g.add(cabin);
  const roof = new THREE.Mesh(new RoundedBoxGeometry(1.8, 0.15, 6.7, 2, 0.06), new THREE.MeshStandardMaterial({ color: 0xc8352b, roughness: 0.5 })); roof.position.set(0, 1.75, -0.6); g.add(roof);
  for (let k = 0; k < 5; k++) [-1, 1].forEach((s) => { const w = new THREE.Mesh(new THREE.CircleGeometry(0.18, 16), new THREE.MeshStandardMaterial({ color: 0xf2d27a, emissive: 0x6a5420, emissiveIntensity: 0.3 })); w.position.set(s * 0.86, 1.2, -3.2 + k * 1.3); w.rotation.y = s * Math.PI / 2; g.add(w); });
  const tiller = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.2, 8), new THREE.MeshStandardMaterial({ color: 0xc89a3a })); tiller.position.set(0, 1.0, 4.6); tiller.rotation.x = 1.0; g.add(tiller);
  return g;
}

// ---------------- props ----------------
export function kettle(color = 0xd94b3d) {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color, roughness: 0.3, metalness: 0.3 });
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.5, 24, 16), m); b.scale.set(1, 0.85, 1); b.position.y = 0.45; g.add(b);
  const sp = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.12, 0.5, 12), m); sp.position.set(0.5, 0.6, 0); sp.rotation.z = -0.9; g.add(sp);
  const h = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.05, 8, 16, Math.PI), new THREE.MeshStandardMaterial({ color: 0x222222 })); h.position.y = 0.85; g.add(h);
  const steam = []; for (let k = 0; k < 4; k++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false })); g.add(s); steam.push([s, k * 0.25]); }
  return { group: g, setSteam(t, on) { steam.forEach(([s, ph]) => { const k = ((t * 0.8 + ph) % 1); s.position.set(0.75 + k * 0.3, 0.85 + k * 1.0, 0); s.scale.setScalar(1 + k * 2); s.material.opacity = on * 0.7 * (1 - k); }); } };
}
export function scaleSet() {
  const g = new THREE.Group();
  const base = new THREE.Mesh(new RoundedBoxGeometry(3.2, 0.35, 2.2, 3, 0.1), new THREE.MeshStandardMaterial({ color: 0xf0f0f0, roughness: 0.4 })); base.position.y = 0.18; g.add(base);
  const disp = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.25, 0.05), new THREE.MeshStandardMaterial({ color: 0x111111 })); disp.position.set(0, 0.2, 1.11); g.add(disp);
  const glass = new THREE.MeshPhysicalMaterial({ color: 0xdff2ff, roughness: 0.05, transparent: true, opacity: 0.25, depthWrite: false, side: THREE.DoubleSide });
  const tank = new THREE.Mesh(new THREE.BoxGeometry(2.8, 1.6, 1.8), glass); tank.position.y = 1.15; g.add(tank);
  const water = new THREE.Mesh(new THREE.BoxGeometry(2.74, 1.4, 1.74), waterMat(0x3a8fd0, 0.6)); water.position.y = 1.05; g.add(water);
  const jug = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.4, 1.0, 24, 1, true), glass); jug.position.set(2.3, 0.5, 0.3); g.add(jug);
  const jw = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.38, 1, 24), waterMat(0x3a8fd0, 0.7)); jw.position.set(2.3, 0.05, 0.3); jw.scale.y = 0.01; g.add(jw);
  const spill = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 1.0, 8), waterMat(0x3a8fd0, 0.7)); spill.position.set(1.75, 1.3, 0.3); spill.rotation.z = 0.8; spill.visible = false; g.add(spill);
  return { group: g, water, jw, spill, set(k, pour) { jw.scale.y = Math.max(0.01, k * 0.7); jw.position.y = 0.02 + k * 0.35; spill.visible = pour > 0.05 && pour < 0.95; } };
}
