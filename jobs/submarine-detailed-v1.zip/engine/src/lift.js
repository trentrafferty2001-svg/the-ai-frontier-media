// The Explainer: why lifts can't free-fall. 1854 demo platform; modern shaft cutaway (front open, camera +z):
// car on guide rails, hoist cables over a sheave to a counterweight, overspeed governor + rope loop, safety wedges, pit buffers.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.6, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
const steel = std(0x9aa4ae, 0.35, 0.8), dark = std(0x3a3f46, 0.6, 0.4), wood = std(0x8a5a32, 0.8);
export const TOPY = 26, PITY = 0;
function seg(a, b, r, mat) { const d = b.clone().sub(a), L = d.length(); const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 1, 8), mat); m.scale.y = L; m.position.copy(a).addScaledVector(d, 0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); return m; }
function setSeg(m, a, b) { const d = b.clone().sub(a), L = d.length(); m.scale.y = Math.max(0.001, L); m.position.copy(a).addScaledVector(d, 0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); }

export function shaft() {
  const G = new THREE.Group();
  const wallM = std(0xb8b2a8, 0.9);
  const back = new THREE.Mesh(new THREE.BoxGeometry(6, TOPY + 3, 0.3), wallM); back.position.set(0, (TOPY + 3) / 2 - 1.5, -2.6); G.add(back);
  [-1, 1].forEach(s => { const w = new THREE.Mesh(new THREE.BoxGeometry(0.3, TOPY + 3, 5.4), wallM); w.position.set(s * 3, (TOPY + 3) / 2 - 1.5, -0.1); G.add(w); });
  const pit = new THREE.Mesh(new THREE.BoxGeometry(6, 0.3, 5.4), std(0x6a6660, 0.9)); pit.position.set(0, -1.5, -0.1); G.add(pit);
  // floor landings (door frames on the back wall would be hidden; use bands on side walls)
  for (let k = 1; k < 8; k++) [-1, 1].forEach(s => { const b = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.12, 5.4), std(0x8a847a)); b.position.set(s * 2.84, k * 3.2, -0.1); G.add(b); });
  // guide rails (car) at x = +/-1.35; counterweight rails at back
  [-1, 1].forEach(s => { const r = new THREE.Mesh(new THREE.BoxGeometry(0.12, TOPY + 1.5, 0.22), steel); r.position.set(s * 1.38, (TOPY + 1.5) / 2 - 1.5, 0); G.add(r); const r2 = new THREE.Mesh(new THREE.BoxGeometry(0.08, TOPY + 1.5, 0.1), steel); r2.position.set(-2.15, (TOPY + 1.5) / 2 - 1.5, s * 0.75); G.add(r2); });
  // machine room beam + sheave at the top
  const beam = new THREE.Mesh(new THREE.BoxGeometry(6, 0.5, 5.4), dark); beam.position.set(0, TOPY + 1.0, -0.1); G.add(beam);
  const sheave = new THREE.Mesh(new THREE.CylinderGeometry(1.08, 1.08, 0.5, 40), steel); sheave.rotation.x = Math.PI / 2; sheave.position.set(-1.07, TOPY - 1.08, 0); G.add(sheave);
  // buffers in the pit (springs)
  const buffers = [-0.6, 0.6].map(x => { const g = new THREE.Group(); const coil = new THREE.Mesh(new THREE.TorusKnotGeometry(0.22, 0.04, 80, 8, 1, 6), std(0xd8b020, 0.4, 0.6)); coil.scale.set(1, 1, 2.6); coil.rotation.x = Math.PI / 2; coil.position.y = 0.55; g.add(coil); const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.08, 20), dark); cap.position.y = 1.15; g.add(cap); g.position.set(x, -1.35, 0); G.add(g); return g; });
  return { group: G, sheave, buffers };
}
// the car: cab + sling frame; safety gear (wedges) at the bottom of the sling next to each rail; lever on top
export function car() {
  const G = new THREE.Group();
  const cab = new THREE.Mesh(new THREE.BoxGeometry(2.3, 2.6, 2.2), std(0xd9dde2, 0.4, 0.3)); cab.position.y = 1.3; G.add(cab);
  const doors = new THREE.Mesh(new THREE.BoxGeometry(1.2, 2.2, 0.04), std(0xaab2bc, 0.25, 0.8)); doors.position.set(0, 1.2, 1.12); G.add(doors);
  const win = new THREE.Mesh(new THREE.BoxGeometry(0.02, 2.0, 0.02), std(0x333a42)); win.position.set(0, 1.2, 1.15); G.add(win);
  // sling: uprights along the rails + crosshead + plank
  [-1, 1].forEach(s => { const u = new THREE.Mesh(new THREE.BoxGeometry(0.12, 3.2, 0.3), std(0x2a6aa8, 0.5, 0.4)); u.position.set(s * 1.24, 1.4, 0); G.add(u); });
  const cross = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.22, 0.32), std(0x2a6aa8, 0.5, 0.4)); cross.position.y = 3.05; G.add(cross);
  const plank = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.22, 0.32), std(0x2a6aa8, 0.5, 0.4)); plank.position.y = -0.15; G.add(plank);
  // safety gear: a housing on each side with a wedge that slides up into the gap beside the rail
  const wedgeM = std(0xe0a020, 0.35, 0.7, { emissive: 0xff6a00, emissiveIntensity: 0 });
  const wedges = [-1, 1].map(s => { const h = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.5, 0.5), dark); h.position.set(s * 1.38, -0.1, 0); G.add(h); const w = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.4, 0.3), wedgeM); w.position.set(s * 1.38 - s * 0.13, -0.3, 0.3); G.add(w); return w; });
  // lever on top (connected to the governor rope at x = 1.0)
  const lever = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.08, 0.08), std(0xc83a2a, 0.5, 0.3)); lever.geometry.translate(0.45, 0, 0); lever.position.set(0.55, 3.25, 0.35); G.add(lever);
  // man inside (simple silhouette) visible through open front? keep cab closed.
  const st = { trip: 0 };
  function update(T) { wedges.forEach((w, i) => { w.position.y = -0.3 + 0.32 * st.trip; }); wedgeM.emissiveIntensity = 0.8 * st.trip; lever.rotation.z = 0.5 * st.trip; }
  return { group: G, st, update };
}
export function counterweight() { const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.BoxGeometry(0.5, 2.6, 1.2), std(0xe0a020, 0.5, 0.3)); b.position.y = 1.3; g.add(b); for (let k = 0; k < 8; k++) { const s = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.03, 1.22), std(0x8a5a10)); s.position.y = 0.3 + k * 0.3; g.add(s); } return { group: g }; }
// governor: wheel with two flyweights; tension pulley in the pit; rope loop (one side clamps to the car lever)
export function governor() {
  const G = new THREE.Group(); G.position.set(1.95, TOPY - 0.2, 0.35);
  const wheel = new THREE.Group(); G.add(wheel);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.06, 10, 40), std(0xe0b030, 0.4, 0.6)); wheel.add(rim);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.2, 16), dark); hub.rotation.x = Math.PI / 2; wheel.add(hub);
  const fly = [-1, 1].map(s => { const arm = new THREE.Group(); const w = new THREE.Mesh(new THREE.SphereGeometry(0.12, 14, 10), std(0xc83a2a, 0.4, 0.4)); w.position.set(0, s * 0.25, 0.12); arm.add(w); wheel.add(arm); return { arm, w, s }; });
  const pawl = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.08, 0.1), std(0xc83a2a)); pawl.position.set(0.55, 0.55, 0.12); G.add(pawl);
  const frame = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.1, 0.5), dark); frame.position.set(0, -0.7, 0); G.add(frame);
  const pulley = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.05, 10, 30), std(0xe0b030, 0.4, 0.6)); pulley.position.set(1.95, -0.7, 0.35);
  const ropeM = std(0xe8e0c8, 0.6), hl = new THREE.MeshBasicMaterial({ color: 0xffe14a, transparent: true, opacity: 0, toneMapped: false, depthWrite: false });
  const ropes = [seg(new THREE.Vector3(1.45, TOPY - 0.2, 0.35), new THREE.Vector3(1.45, -0.7, 0.35), 0.025, ropeM), seg(new THREE.Vector3(2.45, TOPY - 0.2, 0.35), new THREE.Vector3(2.45, -0.7, 0.35), 0.025, ropeM)];
  const glows = [seg(new THREE.Vector3(1.45, TOPY - 0.2, 0.35), new THREE.Vector3(1.45, -0.7, 0.35), 0.07, hl), seg(new THREE.Vector3(2.45, TOPY - 0.2, 0.35), new THREE.Vector3(2.45, -0.7, 0.35), 0.07, hl)];
  const outer = new THREE.Group(); outer.add(pulley, ...ropes, ...glows);
  const st = { spin: 0, out: 0, lock: 0, glow: 0 };
  function update(T) { wheel.rotation.z = -st.spin; fly.forEach(({ w, s }) => { w.position.y = s * (0.25 + 0.17 * st.out); }); pawl.rotation.z = -0.6 * st.lock; hl.opacity = 0.6 * st.glow * (0.7 + 0.3 * Math.sin(T * 6)); }
  update(0);
  return { group: G, outer, st, update };
}
// hoist cables: from car top to the sheave (front side) and from the sheave (back side) down to the counterweight
export function cables(n = 6) {
  const m = std(0x3a3f46, 0.5, 0.6); const hlM = new THREE.MeshBasicMaterial({ color: 0xffe14a, transparent: true, opacity: 0, toneMapped: false, depthWrite: false });
  const g = new THREE.Group(); const front = [], back = [], hl = [];
  for (let i = 0; i < n; i++) { const z = -0.8 + i * 0.05 - (n - 1) * 0.025; const f = seg(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 1, 0), 0.03, m), b = seg(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 1, 0), 0.03, m), h = seg(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 1, 0), 0.06, hlM.clone()); g.add(f, b, h); front.push({ m: f, dx: -0.2 + i * 0.08 }); back.push({ m: b, dx: -0.2 + i * 0.08 }); hl.push(h); }
  return { group: g, set(carY, cwY, glowIdx = -1, glowK = 0, cut = 0) {
    front.forEach(({ m, dx }, i) => { const top = new THREE.Vector3(dx * 0.4, TOPY - 1.08, dx), bot = new THREE.Vector3(dx * 0.4, carY + 3.2, dx); if (cut > 0) bot.y = Math.max(bot.y, TOPY - 1 - cut * 4 - i * 0.6); setSeg(m, top, bot); setSeg(hl[i], top, bot); hl[i].material.opacity = (glowIdx === i || glowIdx === 99) ? 0.8 * glowK : 0; });
    back.forEach(({ m, dx }) => { setSeg(m, new THREE.Vector3(-2.14, TOPY - 1.08, dx), new THREE.Vector3(-2.14, cwY + 2.6, dx)); });
  } };
}
// 1854 demo: wooden tower with a hoist platform, a man in a top hat, a rope above, pawls and toothed rails
export function demo() {
  const G = new THREE.Group();
  [-1, 1].forEach(s => { const p = new THREE.Mesh(new THREE.BoxGeometry(0.3, 9, 0.3), wood); p.position.set(s * 1.6, 4.5, 0); G.add(p); for (let k = 0; k < 40; k++) { const t = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.18, 4), dark); t.position.set(s * 1.42, 0.5 + k * 0.2, 0); t.rotation.z = s * Math.PI / 2; G.add(t); } });
  const top = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.3, 0.4), wood); top.position.y = 9.1; G.add(top);
  const plat = new THREE.Group(); G.add(plat);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.15, 2.0), wood); plat.add(deck);
  const pawls = [-1, 1].map(s => { const p = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.06, 0.1), std(0x9a9aa0, 0.4, 0.8)); p.position.set(s * 1.2, 0.2, 0); plat.add(p); return { p, s }; });
  const man = new THREE.Group(); const coat = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.32, 1.1, 16), std(0x1a1a22)); coat.position.y = 0.65; man.add(coat); const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 12), std(0xe8c0a0)); head.position.y = 1.35; man.add(head); const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 0.36, 16), std(0x101014)); hat.position.y = 1.62; man.add(hat); const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.03, 16), std(0x101014)); brim.position.y = 1.45; man.add(brim);
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.6, 8), std(0x1a1a22)); arm.position.set(0.32, 1.2, 0); arm.rotation.z = -2.3; man.add(arm); man.position.set(-0.3, 0.07, 0.2); plat.add(man);
  const ropeM = std(0xc8b088, 0.8); const ropeTop = seg(new THREE.Vector3(0, 9, 0), new THREE.Vector3(0, 8, 0), 0.05, ropeM), ropeLow = seg(new THREE.Vector3(0, 8, 0), new THREE.Vector3(0, 7, 0), 0.05, ropeM); G.add(ropeTop, ropeLow);
  return { group: G, set(platY, cut, catchK) {
    plat.position.y = platY; const mid = 7.0 + (platY - 5) * 0.2;
    setSeg(ropeTop, new THREE.Vector3(0, 9, 0), new THREE.Vector3(0, mid + 0.15, 0));
    const lowTop = new THREE.Vector3(0, mid - 0.15 - cut * 0.6, 0); setSeg(ropeLow, lowTop, new THREE.Vector3(0, platY + 0.1, 0)); ropeLow.visible = true;
    pawls.forEach(({ p, s }) => { p.position.x = s * (1.05 + 0.3 * catchK); });
  } };
}
export { std };
