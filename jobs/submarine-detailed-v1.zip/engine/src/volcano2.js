// detail kit for volcano: rock strata texture, magma texture, gas bubbles, crusted lava flows, textured slopes, trees, shaded ash
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as V from './volcano.js';
import { groundMat, leafyTrees } from './hummer2.js';
export { CRATER, CHAMBER, std, soda, profile, LAVA } from './volcano.js';
function cv(w, h, f, rep = true) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; if (rep) t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
// strata: 1 texture unit = 1 world unit / 40 ; drawn top (y=+40) to bottom (y=-40)
const strataTex = () => { const t = cv(1024, 1024, (g, w, h) => { const R = rnd(31); const bands = ['#8a6c4c', '#74583e', '#9a7a56', '#6a4e36', '#80664a', '#5e4430', '#8e7052', '#6c5038'];
  let y = 0; let k = 0; while (y < h) { const bh = 30 + R() * 60; g.fillStyle = bands[k++ % bands.length]; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= w; x += 32) g.lineTo(x, y + Math.sin(x * 0.01 + k) * 6); g.lineTo(w, y + bh + 8); for (let x = w; x >= 0; x -= 32) g.lineTo(x, y + bh + Math.sin(x * 0.01 + k + 1) * 6); g.closePath(); g.fill(); y += bh; }
  const dark = g.createLinearGradient(0, h * 0.5, 0, h); dark.addColorStop(0, 'rgba(40,20,10,0)'); dark.addColorStop(1, 'rgba(60,20,8,0.55)'); g.fillStyle = dark; g.fillRect(0, h * 0.5, w, h * 0.5);
  for (let i = 0; i < 5000; i++) { const v = R(); g.fillStyle = v < 0.5 ? 'rgba(40,28,18,0.4)' : 'rgba(190,160,120,0.3)'; g.beginPath(); g.ellipse(R() * w, R() * h, 0.6 + R() * 2.4, 0.6 + R() * 1.8, R() * 3, 0, 7); g.fill(); }
  g.strokeStyle = 'rgba(30,18,10,0.35)'; g.lineWidth = 1.2; for (let i = 0; i < 18; i++) { let x = R() * w, yy = R() * h; g.beginPath(); g.moveTo(x, yy); for (let s = 0; s < 6; s++) { x += (R() - 0.5) * 30; yy += R() * 18; g.lineTo(x, yy); } g.stroke(); } }, false); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; };
const rockTex = () => cv(512, 512, (g, w, h) => { g.fillStyle = '#7a6a58'; g.fillRect(0, 0, w, h); const R = rnd(8); for (let i = 0; i < 9000; i++) { const v = R(); g.fillStyle = v < 0.4 ? 'rgba(60,50,42,0.5)' : v < 0.8 ? 'rgba(140,124,104,0.4)' : 'rgba(40,34,30,0.6)'; g.fillRect(R() * w, R() * h, 1 + R() * 4, 1 + R() * 3); }
  g.strokeStyle = 'rgba(40,32,26,0.4)'; for (let i = 0; i < 90; i++) { g.lineWidth = 1 + R() * 2; let x = R() * w, y = R() * h; g.beginPath(); g.moveTo(x, y); for (let s = 0; s < 5; s++) { x += (R() - 0.5) * 40; y += (R() - 0.5) * 40; g.lineTo(x, y); } g.stroke(); } });
const magmaTex = () => cv(512, 512, (g, w, h) => { const gr = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2); gr.addColorStop(0, '#fff2a0'); gr.addColorStop(0.45, '#ffb030'); gr.addColorStop(0.8, '#ff5a10'); gr.addColorStop(1, '#a01a00'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  const R = rnd(4); for (let i = 0; i < 260; i++) { const x = R() * w, y = R() * h; const r = 4 + R() * 26; const sg = g.createRadialGradient(x, y, 0, x, y, r); const hot = R() < 0.5; sg.addColorStop(0, hot ? 'rgba(255,250,200,0.55)' : 'rgba(150,30,0,0.4)'); sg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = sg; g.fillRect(x - r, y - r, 2 * r, 2 * r); }
  g.strokeStyle = 'rgba(120,20,0,0.5)'; g.lineWidth = 2; for (let i = 0; i < 40; i++) { let x = R() * w, y = R() * h; g.beginPath(); g.moveTo(x, y); for (let s = 0; s < 4; s++) { x += (R() - 0.5) * 50; y += (R() - 0.5) * 50; g.lineTo(x, y); } g.stroke(); } }, false);
const crustTex = () => cv(512, 128, (g, w, h) => { g.fillStyle = '#ffb030'; g.fillRect(0, 0, w, h); const R = rnd(6);
  for (let i = 0; i < 70; i++) { const x = R() * w, y = R() * h, rw = 14 + R() * 40, rh = 10 + R() * 26; g.fillStyle = `rgb(${30 + R() * 30 | 0},${18 + R() * 14 | 0},${12 + R() * 10 | 0})`; g.beginPath(); g.ellipse(x, y, rw, rh, R() * 3, 0, 7); g.fill(); }
  g.globalCompositeOperation = 'lighter'; for (let i = 0; i < 120; i++) { g.fillStyle = 'rgba(255,120,20,0.25)'; g.fillRect(R() * w, R() * h, 2 + R() * 8, 1 + R() * 3); } });
const bubbleTex = () => cv(128, 128, (g, w, h) => { g.clearRect(0, 0, w, h); const gr = g.createRadialGradient(64, 64, 30, 64, 64, 64); gr.addColorStop(0, 'rgba(255,240,190,0.15)'); gr.addColorStop(0.8, 'rgba(255,245,210,0.85)'); gr.addColorStop(1, 'rgba(255,245,210,0)'); g.fillStyle = gr; g.beginPath(); g.arc(64, 64, 64, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,0.95)'; g.beginPath(); g.ellipse(46, 44, 14, 9, -0.6, 0, 7); g.fill(); }, false);

export function volcano(o = {}) {
  const out = V.volcano(o); const { R = 14, H = 6.5, cut = true } = o;
  // slopes: rock texture over the vertex colours
  const rt = tx('rock', rockTex); const rtm = rt.clone(); rtm.needsUpdate = true; rtm.repeat.set(8, 3);
  out.mtn.material = new THREE.MeshStandardMaterial({ map: rtm, bumpMap: rtm, bumpScale: 2, vertexColors: true, roughness: 0.95, side: THREE.DoubleSide });
  out.mtn.material.color.setScalar(1.35);
  // ground: textured grass, trees ring, boulders
  out.group.children.forEach(c => { if (c.geometry && c.geometry.type === 'CircleGeometry') { const gm = groundMat(); gm.map = gm.map.clone(); gm.map.repeat.set(160, 160); gm.map.needsUpdate = true; c.material = gm; } });
  const Rr = rnd(R * 7 | 0); const spots = []; const Rt = Rr; for (let i = 0; i < 320; i++) { const a = cut ? Rr() * Math.PI + Math.PI : Rr() * Math.PI * 2, r = R + 1 + Rr() * 30; spots.push([Math.cos(a) * r, 0, Math.sin(a) * r * (cut ? 1 : 1)]); }
  out.group.add(leafyTrees(cut ? spots.map(([x, y, z]) => [x, y, -Math.abs(z)]) : spots, { seed: 5, leaves: 260, scale: 0.4 }));
  const bm = new THREE.MeshStandardMaterial({ map: rt, color: 0x9a8c7c, roughness: 0.95 }); const bg = new THREE.IcosahedronGeometry(1, 2);
  for (let i = 0; i < 60; i++) { const a = Rr() * Math.PI * 2, r = 2 + Rr() * (R - 2); const z = Math.sin(a) * r; if (cut && z > -0.4) continue; const b = new THREE.Mesh(bg, bm); const s = 0.12 + Rr() * 0.3; b.scale.set(s, s * 0.7, s); b.position.set(Math.cos(a) * r, V.profile(r, R, H) + s * 0.3, z); b.rotation.set(Rr() * 3, Rr() * 3, 0); out.group.add(b); }
  if (out.face) { const st = tx('strata', strataTex); out.face.material = new THREE.MeshStandardMaterial({ map: st, bumpMap: st, bumpScale: 1.5, roughness: 0.95, side: THREE.DoubleSide });
    const uv = out.face.geometry.attributes.uv, p = out.face.geometry.attributes.position; for (let i = 0; i < p.count; i++) uv.setXY(i, (p.getX(i) + 40) / 30, (p.getY(i) + 40) / 30); uv.needsUpdate = true;
    // a thin soil + grass rim along the cut top
    const rim = []; for (let i = -40; i <= 40; i++) { const x = i; rim.push(new THREE.Vector3(x, Math.abs(x) < R ? V.profile(x, R, H) : 0, 0.02)); }
  }
  return out;
}
export function magmaSystem() {
  const M = V.magmaSystem(); const mt = tx('magma', magmaTex), bt = tx('bubble', bubbleTex);
  const seen = new Set(); M.group.traverse(o => { if (!o.isMesh || seen.has(o.material)) return; seen.add(o.material);
    if (o.material.isMeshStandardMaterial && o.material.emissiveIntensity > 0.5) { o.material.map = mt; o.material.emissiveMap = mt; o.material.color.set(0xffffff); o.material.emissive.set(0x9a9a9a); o.material.needsUpdate = true; }
    else if (o.material.isMeshBasicMaterial && o.material.color.getHex() === 0xfff2c0) { o.material.map = bt; o.material.color.set(0xffffff); o.material.transparent = true; o.material.depthWrite = false; o.material.needsUpdate = true; } });
  M.group.children.forEach(o => { if (o.isMesh && o.geometry.type === 'PlaneGeometry' && o.material.isMeshBasicMaterial && o.material.color.getHex() === 0xff4a10) { const m2 = mt.clone(); m2.wrapS = m2.wrapT = THREE.RepeatWrapping; m2.repeat.set(6, 0.5); m2.needsUpdate = true; o.material.map = m2; o.material.color.set(0xffffff); o.material.needsUpdate = true; } });
  // soft glow halo behind the chamber
  const halo = cv(256, 256, (g, w, h) => { const gr = g.createRadialGradient(128, 128, 0, 128, 128, 128); gr.addColorStop(0, 'rgba(255,140,40,0.55)'); gr.addColorStop(1, 'rgba(255,80,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); }, false);
  const hm = new THREE.Mesh(new THREE.PlaneGeometry(12, 6), new THREE.MeshBasicMaterial({ map: halo, transparent: true, depthWrite: false, toneMapped: false, blending: THREE.AdditiveBlending }));
  hm.position.set(V.CHAMBER.x, V.CHAMBER.y, 0.02); M.group.add(hm);
  const up = M.update; M.update = (T) => { up(T); const f = 0.35 + 0.65 * M.st.fill; hm.scale.set(f, f, 1); hm.material.opacity = 0.6 + 0.4 * M.st.glow; mt.offset.set(Math.sin(T * 0.3) * 0.02, T * 0.01); };
  return M;
}
export function lavaFlows(R = 14, H = 6.5, n = 7, seed = 3) {
  const L = V.lavaFlows(R, H, n, seed); const ct = tx('crust', crustTex);
  L.mat.map = ct; L.mat.emissiveMap = ct; L.mat.color.set(0xffffff); L.mat.emissive.set(0xffffff); L.mat.emissiveIntensity = 1.1; L.mat.needsUpdate = true;
  ct.repeat.set(6, 1);
  // flatten each tube into a wide ribbon lying on the slope
  L.group.children.forEach(m => { const g = m.geometry; const p = g.attributes.position; const path = g.parameters.path; const segs = g.parameters.tubularSegments, rad = g.parameters.radialSegments;
    const up = new THREE.Vector3(0, 1, 0), off = new THREE.Vector3(), q = new THREE.Vector3();
    for (let i = 0; i <= segs; i++) { const c = path.getPointAt(i / segs), T = path.getTangentAt(i / segs); const side = new THREE.Vector3().crossVectors(T, up).normalize(); const nrm = new THREE.Vector3().crossVectors(side, T).normalize(); const w = 1 + 0.6 * (i / segs);
      for (let j = 0; j <= rad; j++) { const k = i * (rad + 1) + j; off.set(p.getX(k) - c.x, p.getY(k) - c.y, p.getZ(k) - c.z); const a = off.dot(side), b = off.dot(nrm); q.copy(c).addScaledVector(side, a * 1.9 * w).addScaledVector(nrm, b * 0.35 - 0.04); p.setXYZ(k, q.x, q.y, q.z); } }
    p.needsUpdate = true; g.computeVertexNormals(); });
  return L;
}
export function plume(seed = 4) {
  const P = V.plume(seed); const geo = new THREE.IcosahedronGeometry(1, 4); { const p = geo.attributes.position, nm = geo.attributes.normal, v = new THREE.Vector3(); for (let i = 0; i < p.count; i++) { v.fromBufferAttribute(p, i); const d = v.clone().normalize(); const n = 1 + 0.12 * Math.sin(d.x * 5.1 + d.y * 3.3) * Math.sin(d.z * 4.7 - d.y * 2.1) + 0.06 * Math.sin(d.x * 13 + d.z * 11); v.copy(d).multiplyScalar(n); p.setXYZ(i, v.x, v.y, v.z); nm.setXYZ(i, d.x, d.y, d.z); } }
  const geoN = geo;
  const mats = [0x5a5654, 0x6a6460, 0x4a4644, 0x7a726c].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 1 }));
  let i = 0; P.group.children.forEach(m => { if (m.geometry.type === 'IcosahedronGeometry') { m.geometry = geoN; m.material = mats[i++ % 4]; } });
  const glow = new THREE.PointLight(0xff6a20, 60, 30, 1.6); glow.position.copy(V.CRATER).add(new THREE.Vector3(0, 2, 0)); P.group.add(glow);
  return P;
}
