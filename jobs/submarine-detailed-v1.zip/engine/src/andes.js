// Inca rope bridge reel: Andean gorge + river, grass rope bridge (buildable), twisted cords/ropes/cables,
// ichu grass bundles, Quechua weavers (poncho + montera hat), Spanish rider on a horse, stone anchors.
import * as THREE from 'three';
import { SKY_PRESETS, waterMaterial, mountains } from './world.js';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { riceClumps } from './farm2.js';

SKY_PRESETS.andes = { zenith: 0x2c66c8, horizon: 0xc8d8ea, ground: 0x6a6a4a, sunColor: 0xfff1dc, cloud: 0.42, haze: 0xb6c8da, sunI: 4.0 };

let AM = null;
export function andesMats() {
  if (AM) return AM;
  const rope = canvasTex(64, 256, (x) => {
    x.fillStyle = '#c9a45a'; x.fillRect(0, 0, 64, 256);
    for (let i = -8; i < 40; i++) { x.strokeStyle = i % 2 ? 'rgba(120,85,35,0.55)' : 'rgba(235,205,130,0.5)'; x.lineWidth = 4; x.beginPath(); x.moveTo(0, i * 8); x.lineTo(64, i * 8 + 28); x.stroke(); }
    const R = rng(4); for (let i = 0; i < 300; i++) { x.fillStyle = `rgba(90,60,20,${R() * 0.25})`; x.fillRect(R() * 64, R() * 256, 1, 3 + R() * 6); }
  }, [1, 1]);
  rope.wrapS = rope.wrapT = THREE.RepeatWrapping;
  const rock = canvasTex(256, 256, (x) => {
    x.fillStyle = '#7a6c5c'; x.fillRect(0, 0, 256, 256); const R = rng(7);
    for (let i = 0; i < 260; i++) { x.fillStyle = `rgba(${60 + R() * 70},${55 + R() * 60},${45 + R() * 50},${0.2 + R() * 0.3})`; x.beginPath(); x.moveTo(R() * 256, R() * 256); for (let k = 0; k < 4; k++) x.lineTo(R() * 256, R() * 256); x.fill(); }
    x.strokeStyle = 'rgba(30,25,20,0.4)'; for (let i = 0; i < 30; i++) { x.beginPath(); const y = R() * 256; x.moveTo(0, y); x.lineTo(256, y + (R() - 0.5) * 30); x.stroke(); }
  }, [6, 6]);
  AM = {
    rope: (rep = 20) => { const t = rope.clone(); t.needsUpdate = true; t.repeat.set(1, rep); return new THREE.MeshStandardMaterial({ map: t, roughness: 0.9, bumpMap: t, bumpScale: 2 }); },
    ropeOld: new THREE.MeshStandardMaterial({ color: 0x8a7a60, roughness: 1, bumpMap: fabricTexture(13), bumpScale: 3 }),
    rock: new THREE.MeshStandardMaterial({ color: 0x86765f, roughness: 0.95, bumpMap: fabricTexture(37), bumpScale: 6, flatShading: true, side: THREE.DoubleSide }),
    stone: new THREE.MeshStandardMaterial({ color: 0x8c8478, roughness: 0.9, bumpMap: fabricTexture(19), bumpScale: 3 }),
    grass: new THREE.MeshStandardMaterial({ color: 0x8f8a4c, roughness: 1, bumpMap: fabricTexture(29), bumpScale: 3 }),
    stick: new THREE.MeshStandardMaterial({ color: 0x7a5a36, roughness: 0.9 }),
  };
  return AM;
}

// ---------- the gorge: two rocky cliff walls, grassy tops, a river far below, Andes behind ----------
export function gorge(scene, { span = 28, depth = 26, len = 160, riverW = 6, seed = 3, far = true } = {}) {
  const M = andesMats(); const g = new THREE.Group(); const R = rng(seed);
  const halfGap = span / 2;
  for (const s of [-1, 1]) {
    // cliff face: a displaced plane facing the gorge, wider at the top
    const geo = new THREE.PlaneGeometry(len, depth + 4, 80, 30); const p = geo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const u = p.getX(i), v = p.getY(i); const yy = Math.min(0, v + (depth + 4) / 2 - depth - 2);
      const k = (yy + depth) / depth; // 0 bottom .. 1 top
      const inset = (1 - k) * (halfGap - riverW / 2 - 2) * 0.9;
      const n = Math.sin(u * 0.35 + seed) * 1.4 + Math.sin(u * 1.3 + v * 0.7) * 0.6 + Math.sin(v * 1.9 + u * 0.2) * 0.5 + (R() - 0.5) * 0.4;
      p.setXYZ(i, u, yy, -(halfGap - inset) + n * 0.8);
    }
    geo.computeVertexNormals();
    const face = new THREE.Mesh(geo, M.rock); face.rotation.y = s > 0 ? -Math.PI / 2 : Math.PI / 2;
    face.receiveShadow = face.castShadow = true; g.add(face);
    // grassy plateau on top
    const top = new THREE.Mesh(new THREE.PlaneGeometry(220, len), M.grass); top.rotation.x = -Math.PI / 2; top.position.set(s * (halfGap + 110 - 0.5), 0.0, 0); top.receiveShadow = true; g.add(top);
  }
  const river = new THREE.Mesh(new THREE.PlaneGeometry(riverW + 8, len), waterMaterial({ color: 0x3a6a5a, opacity: 1, ripple: 2.0 })); river.rotation.x = -Math.PI / 2; river.position.y = -depth + 0.5; g.add(river);
  const bed = new THREE.Mesh(new THREE.PlaneGeometry(riverW + 14, len), M.stone); bed.rotation.x = -Math.PI / 2; bed.position.y = -depth - 0.2; g.add(bed);
  if (far) scene.add(mountains({ rMin: 180, rMax: 380, height: 55, seed: 9 + seed, color: 0x6a7058 }));
  scene.add(g);
  return { g, river, depth };
}
// tufts of ichu grass on the plateaus
export function ichuTufts(spots, { h = 0.5 } = {}) { return riceClumps(spots, { h, hVar: 0.4, blades: 14, width: 0.008, color: 0xa99a52, color2: 0xd8c47a, spread: 0.9, sway: 0.04, seed: 77 }); }

// stone anchor platform at a cliff edge
export function anchor(s = 1) {
  const M = andesMats(); const g = new THREE.Group(); const R = rng(21 + s);
  for (let i = 0; i < 28; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.5 + R() * 0.4, 0.3 + R() * 0.2, 0.4 + R() * 0.3), M.stone); b.position.set((R() - 0.5) * 1.6, 0.15 + Math.floor(i / 9) * 0.35, (R() - 0.5) * 2.6); b.rotation.y = R() * 0.4; g.add(b); }
  return shadowAll(g);
}

// ---------- the bridge ----------
// parabola sag from x=-L/2..L/2, anchors at y=0
export function ropeBridge({ L = 28, sag = 2.6, W = 1.2, old = false } = {}) {
  const M = andesMats(); const g = new THREE.Group();
  const mat = old ? M.ropeOld : M.rope(60);
  const y = (x, s = sag) => -s * (1 - (2 * x / L) ** 2);
  const curve = (z, dy = 0, s = sag) => new THREE.CatmullRomCurve3([...Array(25)].map((_, i) => { const x = -L / 2 - 1.5 + (L + 3) * i / 24; const xx = Math.max(-L / 2, Math.min(L / 2, x)); return new THREE.Vector3(x, (Math.abs(x) > L / 2 ? 0.1 : y(xx, s)) + dy, z); }));
  const cables = [-0.45, -0.15, 0.15, 0.45].map(z => { const m = new THREE.Mesh(new THREE.TubeGeometry(curve(z * W / 1.2), 120, 0.07, 8), mat); g.add(m); return m; });
  const rails = [-1, 1].map(s => { const m = new THREE.Mesh(new THREE.TubeGeometry(curve(s * 0.7 * W / 1.2, 1.0, sag * 0.92), 120, 0.05, 8), mat); g.add(m); return m; });
  // floor sticks (instanced), side cords (instanced)
  const nF = Math.floor(L / 0.22), nS = Math.floor(L / 0.35) * 2;
  const floor = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.025, 0.025, W * 0.95, 6), old ? M.ropeOld : M.stick, nF);
  const side = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.012, 0.012, 1, 4), mat, nS);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0));
  const fx = [...Array(nF)].map((_, i) => -L / 2 + (i + 0.5) * L / nF);
  const sx = [...Array(nS / 2)].map((_, i) => -L / 2 + (i + 0.5) * L / (nS / 2));
  g.add(floor, side);
  const setFloor = (k) => { fx.forEach((x, i) => { const on = (x + L / 2) / L <= k; m4.compose(new THREE.Vector3(x, y(x) + 0.08, 0), q, new THREE.Vector3(1, on ? 1 : 1e-4, on ? 1 : 1e-4)); floor.setMatrixAt(i, m4); }); floor.instanceMatrix.needsUpdate = true; };
  const setSides = (k) => { let j = 0; sx.forEach((x) => { for (const s of [-1, 1]) { const on = (x + L / 2) / L <= k; const y0 = y(x), y1 = y(x, sag * 0.92) + 1.0; m4.compose(new THREE.Vector3(x, (y0 + y1) / 2, s * 0.6 * W / 1.2), new THREE.Quaternion(), new THREE.Vector3(on ? 1 : 1e-4, on ? (y1 - y0) : 1e-4, on ? 1 : 1e-4)); side.setMatrixAt(j++, m4); } }); side.instanceMatrix.needsUpdate = true; };
  const reveal = (m, k) => { const idx = m.geometry.index.count; m.geometry.setDrawRange(0, Math.floor(Math.max(0, Math.min(1, k)) * idx / 48) * 48); };
  g.set = ({ cables: kc = 1, rails: kr = 1, floor: kf = 1, sides: ks = 1 } = {}) => { cables.forEach(m => reveal(m, kc)); rails.forEach(m => reveal(m, kr)); setFloor(kf); setSides(ks); };
  g.set({});
  g.yAt = (x) => y(x);
  return shadowAll(g);
}

// ---------- twisted strands (cord -> rope -> cable) along +x, grown by k ----------
export function twisted({ strands = 3, R = 0.02, r = 0.012, len = 1, turns = 6, mat = null, seed = 1 } = {}) {
  const g = new THREE.Group(); const M = andesMats(); const m = mat || M.rope(8);
  const parts = [...Array(strands)].map((_, s) => {
    const pts = [...Array(81)].map((_, i) => { const u = i / 80, a = u * turns * Math.PI * 2 + s * Math.PI * 2 / strands; return new THREE.Vector3(u * len, Math.cos(a) * R, Math.sin(a) * R); });
    const mesh = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 160, r, 8), m); g.add(mesh); return mesh;
  });
  g.grow = (k) => parts.forEach(p => p.geometry.setDrawRange(0, Math.floor(Math.max(0, Math.min(1, k)) * p.geometry.index.count / 48) * 48));
  return shadowAll(g);
}
// bundle of ichu grass (loose blades lying along +x)
export function grassBundle(n = 200, { len = 0.6, seed = 2 } = {}) {
  const R = rng(seed); const g = new THREE.Group();
  const mesh = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.0015, 0.002, 1, 3), new THREE.MeshStandardMaterial({ color: 0xd2bb6a, roughness: 0.8 }), n);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  for (let i = 0; i < n; i++) { const a = R() * Math.PI * 2, rr = Math.sqrt(R()) * 0.04; q.setFromEuler(new THREE.Euler(0, (R() - 0.5) * 0.1, Math.PI / 2 + (R() - 0.5) * 0.15)); m4.compose(new THREE.Vector3((R() - 0.5) * 0.05, Math.cos(a) * rr + 0.04, Math.sin(a) * rr), q, new THREE.Vector3(1, len * (0.8 + R() * 0.3), 1)); mesh.setMatrixAt(i, m4); }
  g.add(mesh); mesh.castShadow = true;
  return g;
}

// ---------- people ----------
const PONCHO = [0xb8342a, 0xd8602a, 0x7a2a5a, 0x2a6a8a, 0xc89a2a];
export function quechua(i = 0, { kid = false } = {}) {
  const h = romanBuilder({ color: PONCHO[i % PONCHO.length], skin: 0x9a6a48 });
  // stripes on the poncho: thin bands on the chest
  const band = new THREE.MeshStandardMaterial({ color: [0xf2d24a, 0x2a2a5a, 0xf2efe6][i % 3], roughness: 0.9 });
  for (const y of [0.05, 0.13]) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.02, 32, 1, true), band); b.scale.set(1.14, 1, 0.68); b.position.y = y; h.j.chest.add(b); }
  // montera hat: flat wide brim + low crown
  const hm = new THREE.MeshStandardMaterial({ color: [0x2a1a14, 0xb8342a, 0x3a2a5a][i % 3], roughness: 0.8 });
  const hat = new THREE.Group(); hat.position.y = 0.15; h.j.head.add(hat);
  const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.02, 32), hm); hat.add(brim);
  const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.07, 24), hm); crown.position.y = 0.04; hat.add(crown);
  const trim = new THREE.Mesh(new THREE.TorusGeometry(0.235, 0.01, 6, 32), new THREE.MeshStandardMaterial({ color: 0xf2d24a })); trim.rotation.x = Math.PI / 2; hat.add(trim);
  if (kid) h.root.scale.setScalar(0.72);
  return shadowAll(h.root), h;
}
// Spanish rider: steel morion helmet + breastplate, on a simple horse
export function horseAndRider() {
  const g = new THREE.Group();
  const hide = new THREE.MeshStandardMaterial({ color: 0x5a3a24, roughness: 0.7 }), dark = new THREE.MeshStandardMaterial({ color: 0x241810, roughness: 0.8 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.3, 0.9, 8, 16), hide); body.rotation.z = Math.PI / 2; body.position.y = 1.15; g.add(body);
  const neck = new THREE.Mesh(new THREE.CapsuleGeometry(0.16, 0.55, 6, 12), hide); neck.position.set(0.68, 1.5, 0); neck.rotation.z = -0.7; g.add(neck);
  const head = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.38, 6, 12), hide); head.position.set(0.98, 1.72, 0); head.rotation.z = -1.9; g.add(head);
  const mane = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.08, 0.05), dark); mane.position.set(0.62, 1.68, 0); mane.rotation.z = -0.7; g.add(mane);
  const tail = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.5, 4, 8), dark); tail.position.set(-0.78, 1.0, 0); tail.rotation.z = -0.35; g.add(tail);
  const legs = [[0.42, 0.18], [0.42, -0.18], [-0.42, 0.18], [-0.42, -0.18]].map(([x, z]) => { const L = new THREE.Group(); L.position.set(x, 1.0, z); g.add(L); const m = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.05, 1.0, 10), hide); m.position.y = -0.5; L.add(m); const hoof = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.08, 10), dark); hoof.position.y = -1.0; L.add(hoof); return L; });
  const saddle = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.08, 0.62), new THREE.MeshStandardMaterial({ color: 0x8a2a1a, roughness: 0.6 })); saddle.position.set(0, 1.45, 0); g.add(saddle);
  const rider = romanBuilder({ color: 0x3a3a5a, skin: 0xd99b7a });
  const steel = new THREE.MeshStandardMaterial({ color: 0xc8ccd2, metalness: 0.9, roughness: 0.3 });
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.19, 0.36, 28, 1, true), steel); plate.scale.set(1.15, 1, 0.72); plate.position.y = 0.1; rider.j.chest.add(plate);
  const helm = new THREE.Group(); helm.position.y = 0.1; rider.j.head.add(helm);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.16, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), steel); dome.scale.set(1, 1.1, 1.15); helm.add(dome);
  const crest = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.02, 6, 24, Math.PI), steel); crest.rotation.y = Math.PI / 2; crest.position.y = 0.08; helm.add(crest);
  const brim = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 6, 32), steel); brim.rotation.x = Math.PI / 2; brim.scale.y = 1.25; helm.add(brim);
  rider.root.position.set(-0.05, 0.62, 0); rider.root.rotation.y = Math.PI / 2; g.add(rider.root);
  g.rider = rider;
  g.walk = (t) => { legs.forEach((L, i) => { L.rotation.z = 0.35 * Math.sin(t * 5 + (i % 2 ? Math.PI : 0) + (i > 1 ? Math.PI / 2 : 0)); }); g.children[0].position.y = 1.15 + Math.abs(Math.sin(t * 5)) * 0.03; };
  shadowAll(g);
  return g;
}
