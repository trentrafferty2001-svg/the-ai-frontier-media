// The Explainer: octopus (three hearts, blue blood). Reef set, octopus with x-ray body, blood flow, molecule set.
// Units: metres. Octopus local frame: head/eyes near the origin, mantle above and behind (+y, -z), arms below (-y).
import * as THREE from 'three';
import { TIME } from './world.js';
import { rng } from './textures.js';

const NOISE = `
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vnoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(hash12(i), hash12(i+vec2(1,0)), f.x), mix(hash12(i+vec2(0,1)), hash12(i+vec2(1,1)), f.x), f.y); }
float fbm(vec2 p){ float s = 0.0, a = 0.5; for (int i = 0; i < 5; i++){ s += a * vnoise(p); p *= 2.03; a *= 0.5; } return s; }
`;
export { NOISE };

// ---------------- water set ----------------
// studio stage turned into open water: blue fog, sand with moving caustics, rocks, coral, weed, god rays, marine snow
export function sea(scene, { fogColor = 0x125a7c, density = 0.13, sand = 0xb39a74, size = 60, rocks = true, coral = true, cold = false, seed = 3 } = {}) {
  const u = scene.userData.sky.material.uniforms;
  const fc = new THREE.Color(fogColor);
  if (u.top) { u.top.value.copy(fc).lerp(new THREE.Color(cold ? 0x6d93b0 : 0x8fe0f0), 0.55); u.mid.value.copy(fc); u.horizon.value.copy(fc); u.floorC.value.copy(fc).multiplyScalar(0.6); }
  scene.fog = new THREE.FogExp2(fc, density);
  // remove the studio's shadow-catcher ground
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  const R = rng(seed);
  const key = scene.userData.key; key.color.set(cold ? 0xcfe6ff : 0xeafcff); key.intensity = cold ? 1.2 : 1.8;
  key.position.set(0.6, 6, 1.2); key.target.position.set(0, 0, 0);
  const sc = key.shadow.camera; sc.left = sc.bottom = -3; sc.right = sc.top = 3; sc.near = 0.5; sc.far = 14; sc.updateProjectionMatrix();
  scene.add(new THREE.HemisphereLight(cold ? 0x7fa6c8 : 0x8fe6ff, cold ? 0x101820 : 0x5a4a30, cold ? 0.5 : 0.8));
  // sand floor with caustics
  const g = new THREE.PlaneGeometry(size, size, 160, 160);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); p.setZ(i, Math.sin(x * 2.1 + Math.sin(y * 0.7)) * 0.012 + Math.sin(x * 0.4 + y * 0.6) * 0.08 + Math.sin(y * 0.33 - x * 0.2) * 0.12 - 0.12); }
  g.computeVertexNormals();
  const sm = new THREE.MeshStandardMaterial({ color: sand, roughness: 0.95 });
  sm.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = TIME; sh.uniforms.uCaus = { value: cold ? 0.15 : 1.0 };
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWq;').replace('#include <project_vertex>', '#include <project_vertex>\nvWq = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWq; uniform float uTime, uCaus;\n${NOISE}`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        diffuseColor.rgb *= 0.86 + 0.24 * fbm(vWq.xz * 3.0) - 0.08 * smoothstep(0.55, 0.8, fbm(vWq.xz * 0.6));`)
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        vec2 cq = vWq.xz * 2.4; float c1 = abs(sin(cq.x * 3.1 + fbm(cq + uTime * 0.35) * 6.0) * sin(cq.y * 2.7 + fbm(cq * 1.3 - uTime * 0.3) * 6.0));
        float caus = pow(1.0 - c1, 6.0); totalEmissiveRadiance += vec3(0.55, 0.75, 0.7) * caus * 0.35 * uCaus;`);
  };
  const floor = new THREE.Mesh(g, sm); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  // rocks
  const rockMat = new THREE.MeshStandardMaterial({ color: cold ? 0x4c5560 : 0x7a6f62, roughness: 0.92 });
  const rockList = [];
  const rock = (x, z, s, sy = 0.7) => {
    const geo = new THREE.IcosahedronGeometry(1, 2); const q = geo.attributes.position; const RR = rng(Math.floor(x * 13 + z * 7 + 100));
    const ph = RR() * 10; for (let i = 0; i < q.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(q, i); const n = Math.sin(v.x * 3.1 + ph) * Math.sin(v.y * 2.7 + ph * 0.7) * Math.sin(v.z * 3.3 + ph * 1.3); v.multiplyScalar(0.88 + 0.18 * n + 0.06 * Math.sin(v.x * 7 + v.z * 6 + ph)); q.setXYZ(i, v.x, v.y, v.z); }
    geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, rockMat); m.scale.set(s, s * sy, s * (0.8 + R() * 0.4)); m.position.set(x, -0.12 + s * sy * 0.25, z); m.rotation.y = R() * 6;
    m.castShadow = m.receiveShadow = true; scene.add(m); rockList.push(m); return m;
  };
  if (rocks) [[-1.6, -1.8, 0.7], [1.9, -2.4, 0.9], [-3.2, -4.5, 1.4], [3.6, -5, 1.6], [0.4, -6.5, 1.8], [-5, -2, 1.1], [5, -1.4, 1.0], [-2.4, 1.4, 0.35], [2.6, 0.9, 0.45]].forEach(([x, z, s]) => rock(x, z, s));
  // coral: branchy fingers + fans + brain-coral domes
  const sway = [];
  if (coral) {
    const cols = cold ? [0x8a9aa8, 0x6f7f8e] : [0xf07a5a, 0xf2c14e, 0xb06ad8, 0x58c7a8, 0xf09ab8];
    for (let k = 0; k < 26; k++) {
      const a = R() * Math.PI * 2, r = 1.4 + R() * 5.5; const x = Math.cos(a) * r, z = -Math.abs(Math.sin(a) * r) - 0.6 + (R() < 0.25 ? 2.5 : 0);
      if (Math.abs(x) < 1.8 && z > -3.2) continue;
      const col = cols[k % cols.length]; const mat = new THREE.MeshStandardMaterial({ color: col, roughness: 0.7 });
      const grp = new THREE.Group(); grp.position.set(x, -0.1, z); scene.add(grp);
      const type = k % 3;
      if (type === 0) { // branching fingers
        for (let b = 0; b < 7; b++) { const h = 0.18 + R() * 0.3; const c = new THREE.Mesh(new THREE.CapsuleGeometry(0.025, h, 4, 8), mat); c.position.set((R() - 0.5) * 0.18, h / 2, (R() - 0.5) * 0.18); c.rotation.set((R() - 0.5) * 0.7, 0, (R() - 0.5) * 0.7); c.castShadow = true; grp.add(c); }
      } else if (type === 1) { // fan
        const f = new THREE.Mesh(new THREE.CircleGeometry(0.3 + R() * 0.2, 24, 0, Math.PI), new THREE.MeshStandardMaterial({ color: col, roughness: 0.8, side: THREE.DoubleSide }));
        f.rotation.y = R() * 3; grp.add(f); sway.push([f, R() * 6]);
      } else { // dome
        const d = new THREE.Mesh(new THREE.SphereGeometry(0.22 + R() * 0.15, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), mat); d.scale.y = 0.7; d.castShadow = true; grp.add(d);
      }
    }
    // sea grass ribbons
    const weed = new THREE.MeshStandardMaterial({ color: cold ? 0x3d5a4c : 0x3f8f4a, roughness: 0.8, side: THREE.DoubleSide });
    for (let k = 0; k < 40; k++) {
      const x = (R() - 0.5) * 12, z = -1.5 - R() * 7; if (Math.abs(x) < 1.2 && z > -2.5) continue;
      const h = 0.4 + R() * 0.6; const geo = new THREE.PlaneGeometry(0.035, h, 1, 8); geo.translate(0, h / 2, 0);
      const m = new THREE.Mesh(geo, weed); m.position.set(x, -0.1, z); m.rotation.y = R() * 3; scene.add(m); sway.push([m, R() * 6, true]);
    }
  }
  // marine snow
  const N = 900, pg = new THREE.BufferGeometry(), P = new Float32Array(N * 3), sd = [];
  for (let i = 0; i < N; i++) sd.push([(R() - 0.5) * 8, R() * 4, -R() * 8 + 2, R() * 6]);
  pg.setAttribute('position', new THREE.BufferAttribute(P, 3));
  const pts = new THREE.Points(pg, new THREE.PointsMaterial({ size: 0.012, color: 0xe6fbff, transparent: true, opacity: 0.6, depthWrite: false }));
  pts.frustumCulled = false; scene.add(pts);
  // god rays
  const rayMat = new THREE.ShaderMaterial({
    uniforms: { uTime: TIME, uOp: { value: cold ? 0.05 : 0.11 } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `uniform float uTime, uOp; varying vec2 vUv;
      void main(){ float edge = sin(vUv.x * 3.14159); float fall = pow(vUv.y, 1.3); float fl = 0.75 + 0.25 * sin(uTime * 1.1 + vUv.x * 5.0);
        gl_FragColor = vec4(vec3(0.85, 1.0, 1.0), edge * edge * fall * fl * uOp); }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, fog: false,
  });
  const rays = [];
  for (let i = 0; i < 9; i++) { const r = new THREE.Mesh(new THREE.PlaneGeometry(0.4 + R() * 0.6, 9), rayMat); r.position.set(-4 + i, 3.8, -3 - R() * 3); r.rotation.set(0, (R() - 0.5) * 0.5, 0.3); scene.add(r); rays.push([r, R() * 6]); }
  scene.userData.updaters.push((t) => {
    for (let i = 0; i < N; i++) { const [x, y, z, ph] = sd[i]; P[i * 3] = x + Math.sin(t * 0.3 + ph) * 0.05; P[i * 3 + 1] = ((y - t * 0.03) % 4 + 4) % 4 - 0.1; P[i * 3 + 2] = z + Math.cos(t * 0.2 + ph) * 0.05; }
    pg.attributes.position.needsUpdate = true;
    sway.forEach(([m, ph, w]) => { if (w) { m.rotation.z = Math.sin(t * 1.2 + ph) * 0.18; } else m.rotation.x = Math.sin(t * 0.9 + ph) * 0.08; });
    rays.forEach(([r, ph]) => { r.rotation.z = 0.3 + Math.sin(t * 0.3 + ph) * 0.04; });
  });
  return { floor, rockList, rock, floorY: -0.12 };
}

// ---------------- octopus ----------------
const tmpV = new THREE.Vector3(), tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3();
// one tapered arm whose centre line is recomputed every frame; parallel-transport frames, suckers on the underside
function armMesh(mat, suckMat, { seg = 56, rad = 10, r0 = 0.032, len = 0.85 } = {}) {
  const pos = new Float32Array((seg + 1) * rad * 3), idx = [];
  for (let i = 0; i < seg; i++) for (let j = 0; j < rad; j++) { const a = i * rad + j, b = i * rad + (j + 1) % rad, c = a + rad, d = b + rad; idx.push(a, c, b, b, c, d); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setIndex(idx);
  const uv = new Float32Array((seg + 1) * rad * 2); for (let i = 0; i <= seg; i++) for (let j = 0; j < rad; j++) { uv[(i * rad + j) * 2] = j / rad; uv[(i * rad + j) * 2 + 1] = i / seg; }
  geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  const mesh = new THREE.Mesh(geo, mat); mesh.castShadow = true; mesh.frustumCulled = false;
  const NS = 22; const suck = new THREE.InstancedMesh(new THREE.CylinderGeometry(1, 0.8, 0.5, 10), suckMat, NS); suck.frustumCulled = false; suck.castShadow = false;
  const pts = Array.from({ length: seg + 1 }, () => new THREE.Vector3()), T = pts.map(() => new THREE.Vector3()), Nn = pts.map(() => new THREE.Vector3()), B = pts.map(() => new THREE.Vector3());
  const radius = (s) => r0 * Math.pow(1 - s, 0.85) + 0.0025;
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), up = new THREE.Vector3(0, 1, 0);
  // f(s) -> fills the point; underside hint vector u (points toward the sucker side)
  function update(fill, under) {
    fill(pts, seg, radius);
    for (let i = 0; i <= seg; i++) { T[i].subVectors(pts[Math.min(seg, i + 1)], pts[Math.max(0, i - 1)]).normalize(); }
    // initial normal toward the underside hint
    Nn[0].copy(under).addScaledVector(T[0], -under.dot(T[0])).normalize();
    for (let i = 1; i <= seg; i++) { Nn[i].copy(Nn[i - 1]).addScaledVector(T[i], -Nn[i - 1].dot(T[i])).normalize(); }
    for (let i = 0; i <= seg; i++) B[i].crossVectors(T[i], Nn[i]);
    for (let i = 0; i <= seg; i++) {
      const r = radius(i / seg);
      for (let j = 0; j < rad; j++) {
        const a = j / rad * Math.PI * 2; const ca = Math.cos(a), sa = Math.sin(a);
        const k = (i * rad + j) * 3;
        // slightly flattened underside
        const fl = ca > 0 ? 0.82 : 1.0;
        pos[k] = pts[i].x + (Nn[i].x * ca * fl + B[i].x * sa) * r; pos[k + 1] = pts[i].y + (Nn[i].y * ca * fl + B[i].y * sa) * r; pos[k + 2] = pts[i].z + (Nn[i].z * ca * fl + B[i].z * sa) * r;
      }
    }
    geo.attributes.position.needsUpdate = true; geo.computeVertexNormals();
    for (let k = 0; k < NS; k++) {
      const s = 0.06 + k / NS * 0.86; const i = Math.round(s * seg); const r = radius(s);
      tmpV.copy(pts[i]).addScaledVector(Nn[i], r * 0.78);
      q.setFromUnitVectors(up, Nn[i]);
      const sr = r * 0.42; m4.compose(tmpV, q, tmpA.set(sr, sr * 0.35, sr)); suck.setMatrixAt(k, m4);
    }
    suck.instanceMatrix.needsUpdate = true;
  }
  return { mesh, suck, update, len, pts };
}

function skinMaterial(color, { xray }) {
  const m = new THREE.MeshPhysicalMaterial({ color, roughness: 0.42, clearcoat: 0.6, clearcoatRoughness: 0.4, sheen: 0.4, sheenColor: new THREE.Color(0xffc0a0) });
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uX = xray;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vOp; varying vec3 vNw; varying vec3 vVw;').replace('#include <project_vertex>', '#include <project_vertex>\nvOp = position; vNw = normalize(mat3(modelMatrix) * objectNormal); vVw = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vOp; varying vec3 vNw; varying vec3 vVw; uniform float uX;\n${NOISE}`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        float mot = fbm(vOp.xy * 38.0 + vOp.z * 21.0); float spot = smoothstep(0.62, 0.7, fbm(vOp.yz * 55.0 + vOp.x * 30.0));
        diffuseColor.rgb *= 0.78 + 0.42 * mot; diffuseColor.rgb = mix(diffuseColor.rgb, vec3(1.0, 0.86, 0.7), spot * 0.45);`)
      .replace('#include <opaque_fragment>', `#include <opaque_fragment>
        float fr = pow(1.0 - abs(dot(normalize(vNw), normalize(cameraPosition - vVw))), 2.0);
        gl_FragColor.rgb = mix(gl_FragColor.rgb, gl_FragColor.rgb * 0.85 + vec3(0.35, 0.75, 1.0) * fr * 0.7, uX);
        gl_FragColor.a = mix(1.0, 0.22 + 0.55 * fr, uX);`);
  };
  m.transparent = true; m.depthWrite = true;
  return m;
}

export function octopus({ color = 0xc9572f, seed = 1 } = {}) {
  const G = new THREE.Group();
  const xray = { value: 0 };
  const skin = skinMaterial(color, { xray });
  const suckMat = new THREE.MeshStandardMaterial({ color: 0xf2d2b8, roughness: 0.6, transparent: true });
  const body = new THREE.Group(); G.add(body); // mantle + head (can squash)
  // mantle: lathe bulb, axis tilted back
  const prof = []; for (let i = 0; i <= 24; i++) { const s = i / 24; const y = s * 0.36; const r = Math.sin(Math.PI * Math.pow(s, 0.8)) * 0.15 * (1 - 0.15 * s) + (s < 0.05 ? 0.07 * (1 - s / 0.05) : 0); prof.push(new THREE.Vector2(Math.max(0.001, r), y)); }
  const mantleGeo = new THREE.LatheGeometry(prof, 40);
  const mantle = new THREE.Mesh(mantleGeo, skin); mantle.position.set(0, 0.05, -0.02); mantle.rotation.x = -0.55; mantle.castShadow = true; body.add(mantle);
  // head (eye region) and arm crown
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.1, 32, 20), skin); head.scale.set(1.05, 0.75, 0.95); head.position.set(0, 0.0, 0.03); head.castShadow = true; body.add(head);
  const web = new THREE.Mesh(new THREE.SphereGeometry(0.105, 32, 16, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.55), skin); web.position.set(0, -0.03, 0.02); web.scale.set(1.15, 0.6, 1.15); body.add(web);
  // eyes: bulging, gold iris, horizontal bar pupil
  const eyeW = new THREE.MeshPhysicalMaterial({ color: 0xd9b24a, roughness: 0.15, clearcoat: 1 });
  const pupM = new THREE.MeshBasicMaterial({ color: 0x080808 });
  const eyes = [];
  [-1, 1].forEach((sx) => {
    const lid = new THREE.Mesh(new THREE.SphereGeometry(0.034, 20, 14), skin); lid.position.set(sx * 0.072, 0.04, 0.05); body.add(lid);
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.024, 20, 14), eyeW); e.position.set(sx * 0.086, 0.045, 0.062); body.add(e);
    const pu = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.008, 0.026), pupM); pu.position.set(sx * 0.0225, 0, 0.004); e.add(pu); eyes.push(e);
  });
  // siphon
  const siph = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.022, 0.06, 12, 1, true), skin); siph.position.set(0.07, -0.02, -0.05); siph.rotation.set(0.4, 0, -1.2); body.add(siph);

  // ---- internal organs (shown by the x-ray) ----
  const inner = new THREE.Group(); mantle.add(inner); // in mantle space (axis +y along the bulb)
  const heartMat = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.4, emissive: new THREE.Color(c), emissiveIntensity: 0.4 });
  const hMain = new THREE.Mesh(new THREE.SphereGeometry(0.03, 24, 16), heartMat(0xe0303c)); hMain.scale.set(1.25, 1, 1.0); hMain.position.set(0, 0.12, 0.02); inner.add(hMain);
  const hL = new THREE.Mesh(new THREE.SphereGeometry(0.017, 20, 14), heartMat(0xe84a55)); hL.position.set(-0.075, 0.07, 0.03); inner.add(hL);
  const hR = hL.clone(); hR.material = heartMat(0xe84a55); hR.position.x = 0.075; inner.add(hR);
  const gillMat = new THREE.MeshStandardMaterial({ color: 0xf0c4cc, roughness: 0.6, emissive: new THREE.Color(0x3a7bd5), emissiveIntensity: 0 });
  const gills = [];
  [-1, 1].forEach((sx) => {
    const g = new THREE.Group(); g.position.set(sx * 0.085, 0.085, 0.035); g.rotation.set(0.15, 0, sx * -0.25); inner.add(g);
    for (let k = 0; k < 16; k++) for (const sd of [-1, 1]) { const lam = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 6), gillMat); const w = 0.016 * (1 - k / 22); lam.scale.set(w, 0.0022, w * 0.45); lam.position.set(sd * w * 0.9, 0.012 + k * 0.0068, 0); lam.rotation.z = sd * 0.35; g.add(lam); }
    const spine = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.004, 0.11, 6), gillMat); spine.position.y = 0.06; g.add(spine);
    gills.push(g);
  });
  // vessels: tubes on fixed curves, flowing particles
  const curvesM = {
    gillL: new THREE.CatmullRomCurve3([new THREE.Vector3(-0.02, 0.03, 0.03), new THREE.Vector3(-0.06, 0.05, 0.035), hL.position.clone(), new THREE.Vector3(-0.09, 0.1, 0.04), new THREE.Vector3(-0.088, 0.16, 0.035), new THREE.Vector3(-0.05, 0.15, 0.03), new THREE.Vector3(-0.02, 0.125, 0.022)]),
    gillR: new THREE.CatmullRomCurve3([new THREE.Vector3(0.02, 0.03, 0.03), new THREE.Vector3(0.06, 0.05, 0.035), hR.position.clone(), new THREE.Vector3(0.09, 0.1, 0.04), new THREE.Vector3(0.088, 0.16, 0.035), new THREE.Vector3(0.05, 0.15, 0.03), new THREE.Vector3(0.02, 0.125, 0.022)]),
    aorta: new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0.12, 0.02), new THREE.Vector3(0, 0.08, 0.06), new THREE.Vector3(0, 0.02, 0.07), new THREE.Vector3(0, -0.04, 0.06), new THREE.Vector3(0, -0.09, 0.04)]),
  };
  const vesMat = new THREE.MeshStandardMaterial({ color: 0x3f7fe0, roughness: 0.4, emissive: new THREE.Color(0x2a66d8), emissiveIntensity: 0.35, transparent: true, opacity: 0.9 });
  Object.values(curvesM).forEach((c) => { const tb = new THREE.Mesh(new THREE.TubeGeometry(c, 40, 0.0045, 8), vesMat); inner.add(tb); });
  // blood dots: progress along curves; colour from pale (no oxygen) to blue (oxygen) after the gill
  const dotGeo = new THREE.SphereGeometry(0.0055, 8, 6);
  const dotMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x1a55ff, emissiveIntensity: 0.6, roughness: 0.3 });
  const NB = 60; const dots = new THREE.InstancedMesh(dotGeo, dotMat, NB); dots.frustumCulled = false; inner.add(dots);
  const pale = new THREE.Color(0xd8dde8), blue = new THREE.Color(0x1f5cff); const dc = new THREE.Color();
  const routes = [['gillL', 0.45], ['gillR', 0.45], ['aorta', -1]];
  const m4 = new THREE.Matrix4(), qI = new THREE.Quaternion(), one = new THREE.Vector3(1, 1, 1);

  // arms: 8 around the crown
  const arms = [];
  for (let i = 0; i < 8; i++) { const a = armMesh(skin, suckMat, { len: 0.8 + (i % 2) * 0.06 }); G.add(a.mesh, a.suck); arms.push({ ...a, ang: (i + 0.5) / 8 * Math.PI * 2 + 0.1 * Math.sin(i * 3.1 + seed), ph: i * 1.7 + seed }); }

  // state set by shots each frame
  const st = { mode: 'spread', swim: 0, crawl: 0, floorY: null, xray: 0, beatMain: 1, beatGill: 1, rate: 1.1, flow: 1, oxy: 1, glowMain: 0, glowGill: 0, gillGlow: 0, squash: 0, bundleDir: null, reach: 0, tight: 0 };
  const shAx = new THREE.Vector3(), base = new THREE.Vector3(), out = new THREE.Vector3(), side = new THREE.Vector3();
  const inv = new THREE.Matrix4();
  function update(t) {
    xray.value = st.xray;
    suckMat.opacity = 1 - st.xray * 0.8;
    // hearts: lub-dub pulse; main heart can stop (beatMain -> 0)
    const beat = (ph) => { const x = ((t * st.rate + ph) % 1 + 1) % 1; return Math.exp(-Math.pow((x - 0.1) / 0.06, 2)) + 0.5 * Math.exp(-Math.pow((x - 0.3) / 0.06, 2)); };
    const bm = beat(0) * st.beatMain, bg = beat(0.5) * st.beatGill;
    hMain.scale.set(1.25 * (1 + 0.22 * bm), 1 + 0.22 * bm, 1 + 0.22 * bm);
    hL.scale.setScalar(1 + 0.28 * bg); hR.scale.setScalar(1 + 0.28 * bg);
    hMain.material.emissiveIntensity = 0.35 + 0.9 * bm + st.glowMain * 1.6;
    hMain.material.color.set(0xe0303c).lerp(new THREE.Color(0x777788), 1 - st.beatMain);
    hMain.material.emissive.set(0xe0303c).lerp(new THREE.Color(0x222233), 1 - st.beatMain);
    [hL, hR].forEach(h => { h.material.emissiveIntensity = 0.35 + 0.9 * bg + st.glowGill * 1.6; });
    gillMat.emissiveIntensity = st.gillGlow * 0.9;
    // blood
    let k = 0;
    for (let r = 0; r < routes.length; r++) {
      const [name, oxyAt] = routes[r]; const c = curvesM[name]; const n = 20;
      for (let j = 0; j < n; j++) {
        const u = ((j / n + t * 0.22 * st.flow * (name === 'aorta' ? (0.4 + 0.6 * st.beatMain) : 1)) % 1 + 1) % 1;
        c.getPointAt(u, tmpV);
        m4.compose(tmpV, qI, one); dots.setMatrixAt(k, m4);
        const ox = oxyAt < 0 ? 1 : THREE.MathUtils.smoothstep(u, oxyAt, oxyAt + 0.25);
        dc.copy(pale).lerp(blue, ox * st.oxy); dots.setColorAt(k, dc); k++;
      }
    }
    dots.instanceMatrix.needsUpdate = true; if (dots.instanceColor) dots.instanceColor.needsUpdate = true;
    inner.visible = st.xray > 0.02;
    dots.visible = vesMat.visible = st.xray > 0.02;
    // body breathing / jet pulse / squash
    const jet = st.swim > 0 ? Math.max(0, Math.sin(t * 5.5)) * st.swim : 0;
    mantle.rotation.x = -0.55 * (1 - 0.85 * st.swim);
    mantle.scale.set(1 - 0.12 * jet - 0.68 * st.squash + 0.02 * Math.sin(t * 2.2), 1 + 0.08 * jet + 0.35 * st.squash, 1 - 0.12 * jet - 0.68 * st.squash + 0.02 * Math.sin(t * 2.2));
    head.scale.set(1.05 * (1 - 0.55 * st.squash), 0.75, 0.95 * (1 - 0.55 * st.squash));
    web.scale.set(1.15 * (1 - 0.55 * st.squash), 0.6, 1.15 * (1 - 0.55 * st.squash));
    eyes.forEach((e) => { e.visible = st.squash < 0.6; });
    eyes.forEach((e, i) => { e.rotation.y = Math.sin(t * 0.5 + i) * 0.15; });
    // arms in G-local space
    G.updateMatrixWorld(true); inv.copy(G.matrixWorld).invert();
    const floorLocal = st.floorY == null ? null : st.floorY; // world y
    arms.forEach((A) => {
      const ca = Math.cos(A.ang), sa = Math.sin(A.ang);
      out.set(sa, 0, ca); side.set(ca, 0, -sa);
      base.set(sa * 0.07 * (1 - 0.5 * st.squash), -0.05, 0.02 + ca * 0.07);
      const L = A.len, ph = A.ph, spread = 1 - st.swim;
      const dirAt = (s, d) => {
        // spread: leaves outward and down, flattens, tip curls up; swim: trails straight down (-y) in a bundle, rippling
        const crawlW = st.crawl * Math.sin(t * 2.6 - s * 5 + ph) * 0.55;
        const pitchS = -0.75 + s * 0.9 + Math.pow(s, 4) * 2.6 + crawlW + 0.2 * Math.sin(t * 0.8 + ph + s * 3) * s;
        const latS = 0.3 * Math.sin(t * 0.6 + ph) * s + 0.5 * Math.sin(ph * 2.3) * s * s + st.crawl * 0.35 * Math.cos(t * 2.6 - s * 4 + ph) * s;
        tmpA.copy(out).multiplyScalar(Math.cos(pitchS) * Math.cos(latS)).addScaledVector(side, Math.cos(pitchS) * Math.sin(latS)); tmpA.y = Math.sin(pitchS);
        const wob = 0.18 * Math.sin(t * 6 - s * 9 + ph) * s;
        d.copy(out).multiplyScalar((0.16 - 0.1 * s) * (1 - 1.5 * st.tight) + st.reach * 0.3).addScaledVector(side, wob * (1 - st.tight)); d.y = -1;
        d.normalize().lerp(tmpA, spread).normalize();
      };
      A.update((pts, seg, radius) => {
        pts[0].copy(base);
        const dl = L / seg;
        for (let i = 1; i <= seg; i++) {
          dirAt((i - 0.5) / seg, tmpV); pts[i].copy(pts[i - 1]).addScaledVector(tmpV, dl);
        }
        if (floorLocal != null) for (let i = 1; i <= seg; i++) {
          tmpB.copy(pts[i]).applyMatrix4(G.matrixWorld); const r = radius(i / seg) * 0.9;
          if (tmpB.y < floorLocal + r) { tmpB.y = floorLocal + r; pts[i].copy(tmpB.applyMatrix4(inv)); }
        }
      }, tmpB.set(0, -1, 0).multiplyScalar(spread).addScaledVector(out, -(1 - spread)).normalize().clone());
    });
  }
  return { group: G, body, mantle, head, inner, st, update, hearts: { main: hMain, left: hL, right: hR }, gills, xray };
}

// ---------------- text sprite (big Cu / Fe labels) ----------------
export function textSprite(text, { size = 0.3, color = '#ffffff', font = '800 220px Poppins, sans-serif', stroke = 18 } = {}) {
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 300; const g = cv.getContext('2d');
  g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
  g.lineWidth = stroke; g.strokeStyle = 'rgba(0,0,0,0.9)'; g.strokeText(text, 256, 160); g.fillStyle = color; g.fillText(text, 256, 160);
  const tx = new THREE.CanvasTexture(cv); tx.colorSpace = THREE.SRGBColorSpace; tx.anisotropy = 4;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx, transparent: true, depthWrite: false, fog: false }));
  sp.scale.set(size * 512 / 300, size, 1); return sp;
}

// a glossy blood droplet with a metal atom inside
export function bloodDrop(color, atomColor, { metal = 1 } = {}) {
  const g = new THREE.Group();
  const prof = []; for (let i = 0; i <= 40; i++) { const s = i / 40; const y = -Math.cos(s * Math.PI) * 0.5 + 0.5; const r = Math.sin(s * Math.PI) * (0.5 - 0.42 * Math.pow(s, 3)) * (s > 0.85 ? 1 - (s - 0.85) * 2 : 1); prof.push(new THREE.Vector2(Math.max(0.0005, r), y * 1.25)); }
  const d = new THREE.Mesh(new THREE.LatheGeometry(prof, 48), new THREE.MeshPhysicalMaterial({ color, roughness: 0.05, transmission: 0.0, transparent: true, opacity: 0.55, clearcoat: 1, emissive: new THREE.Color(color), emissiveIntensity: 0.25, depthWrite: false }));
  g.add(d);
  const atom = new THREE.Mesh(new THREE.SphereGeometry(0.16, 32, 20), new THREE.MeshStandardMaterial({ color: atomColor, metalness: metal, roughness: 0.25 }));
  atom.position.y = 0.45; g.add(atom);
  return { group: g, drop: d, atom };
}
