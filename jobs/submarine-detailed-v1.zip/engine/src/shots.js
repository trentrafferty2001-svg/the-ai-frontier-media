import * as THREE from 'three';
import { fish, rice, grid, paddy, farmer, splash, bug, weed, bucket, underwater, shaft, farmMats, glowSprite } from './farm.js';
import { VO } from './vo.js';
import { kf, lerp, smooth, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';

export const DURATION = 30.3;

// word timings of the voiceover (global seconds), generated from the Kokoro durations
const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const end = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][2];

// caption chunks per line: [text, number of spoken words]
const CHUNKS = [
  [['If you put', 3], ['fish', 1], ['in a rice field', 4], ["you'd think", 2], ["they'd eat", 2], ['the crop', 2]],
  [['But farmers', 2], ['in China', 2], ['have done this', 3], ['for over', 2], ['1,200 years', 3]],
  [['First', 1], ['dig a trench', 3], ['along the edge', 3], ['so the fish', 3], ['have shelter', 2]],
  [['Then raise', 2], ['the walls', 2], ['and flood', 2], ['the field', 2]],
  [['A week', 2], ['after planting', 2], ['release', 1], ['young carp', 2]],
  [['The fish eat', 3], ['weeds', 1], ['and pests', 2], ['and their waste', 3], ['feeds', 1], ['the rice', 2]],
  [['The rice', 2], ['shades the water', 3], ['keeping the fish', 3], ['cool', 1]],
  [['So at harvest', 3], ['you get', 2], ['two crops', 2], ['from one field', 3]],
];
// [start, text, end?]
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    const last = ci === chunks.length - 1;
    CAPTIONS.push(last ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
});
export const FADES = [[3.95, 4.1, 4.2, 4.33]];

function idle(t, k = 1) { return Math.sin(t * 1.6) * 0.012 * k; }
const STAND = {
  lSh: [0.05, 0, 0.16], rSh: [0.05, 0, -0.16], lEl: [-0.25, 0, 0], rEl: [-0.25, 0, 0],
  lHip: [0, 0, 0.07], rHip: [0, 0, -0.07], lAn: [0, 0, -0.07], rAn: [0, 0, 0.07],
};
function standPose(h, t, extra = {}) {
  const p = { ...STAND, ...extra };
  p.chest = [idle(t) + (extra.chest?.[0] || 0), extra.chest?.[1] || 0, extra.chest?.[2] || 0];
  h.setPose(p);
}
const wpos = (obj, v = V(0, 0, 0)) => obj.localToWorld(v.clone());

// ============ SHOT 1: farmer in a green paddy drops a fish in ============
function shot1({ makeStage }) {
  const scene = makeStage({ shadowSize: 3 });
  const p = paddy(12, 12, { water: 0.22 }); scene.add(p);
  scene.add(rice(grid(-3, 3, -4, -0.6, 0.32, 0.06, 1), { h: 0.75, r: 0.008, seed: 3 }));
  scene.add(rice(grid(0.9, 3, -0.5, 1.6, 0.32, 0.06, 2), { h: 0.75, r: 0.008, seed: 5 }));
  const man = farmer(); man.root.rotation.y = 0.35; scene.add(man.root);
  const f = fish(0.32); scene.add(f);
  const sp = splash(1.2); scene.add(sp);
  const c = cam(36);
  const TD = 1.05, G = 5.5;
  let hand0 = null, splashAt = null;
  return {
    scene, camera: c,
    update(tr) {
      // slow motion from just before the splash
      const t = tr < 1.45 ? tr : 1.45 + (tr - 1.45) * 0.4;
      man.setMood('happy');
      const lift = kf(t, [[0, 0], [0.5, 1]]);
      standPose(man, t, {
        rSh: [lerp(0.05, -1.25, lift), 0, -0.2], rEl: [lerp(-0.25, -0.35, lift), 0, 0],
        neck: [0.12, 0, 0], head: [0.15 * lift, 0.15, 0],
      });
      man.setMouth(t > 0.4 && t < 1.6 ? 0.35 + 0.25 * Math.sin(t * 12) : 0.1);
      scene.updateMatrixWorld(true);
      const hand = wpos(man.j.rWr, V(0, -0.12, 0.03));
      if (!hand0 || t <= TD) hand0 = t <= TD ? hand : hand0;
      if (t < TD) {
        f.position.copy(hand); f.rotation.set(0.2, 0.35 + Math.PI, Math.sin(t * 14) * 0.25); f.swim(t, 14, 0.7);
      } else {
        // fixed drop point so the fall does not depend on render order
        const h0 = V(-0.08, 1.05, 0.68);
        const dt = t - TD;
        const yImp = 0.22, tImp = Math.sqrt(2 * (h0.y - yImp) / G);
        if (dt < tImp) {
          f.position.set(h0.x, h0.y - 0.5 * G * dt * dt, h0.z + dt * 0.1);
          f.rotation.set(0.2, 0.35 + Math.PI, -0.9 * (dt / tImp) + Math.sin(t * 16) * 0.3); f.swim(t, 16, 0.8);
        } else {
          const u = dt - tImp;
          f.position.set(h0.x - u * 0.25, yImp - 0.08 - Math.min(0.06, u * 0.2), h0.z + 0.07 + u * 0.15);
          f.rotation.set(0, Math.PI * 0.8, 0); f.swim(t, 10, 0.5);
        }
        sp.position.set(h0.x, yImp, h0.z + tImp * 0.1);
        sp.update(dt - tImp);
      }
      const k = easeInOut(range(tr, 0, 1.4));
      const pk = easeInOut(range(tr, 1.35, 2.3));
      const s = shake(tr, 0.5 + 2.5 * Math.exp(-Math.pow((tr - 1.62) / 0.12, 2)));
      const p0 = [lerp(0.7, 0.55, k), lerp(1.4, 1.3, k), lerp(3.5, 3.0, k)], l0 = [lerp(0.05, 0.0, k), lerp(1.1, 0.95, k), 0.3];
      const p1 = [0.25, 0.55, 1.75], l1 = [-0.08, 0.3, 0.7];
      place(c, [lerp(p0[0], p1[0], pk) + s[0], lerp(p0[1], p1[1], pk) + s[1], lerp(p0[2], p1[2], pk)], [lerp(l0[0], l1[0], pk), lerp(l0[1], l1[1], pk), lerp(l0[2], l1[2], pk)]);
      return { bloom: 0.4 + 0.4 * Math.exp(-Math.pow((tr - 1.65) / 0.2, 2)) };
    },
  };
}

// ============ SHOT 1b: farmer's face, worried the fish will eat his rice ============
function shotFace({ makeStage }) {
  const scene = makeStage({ shadowSize: 2 });
  scene.add(paddy(10, 10, { water: 0.22 }));
  scene.add(rice(grid(-2.5, 2.5, -3, -0.5, 0.3, 0.06, 7), { h: 0.8, r: 0.008, seed: 9 }));
  const man = farmer(); man.root.rotation.y = 0.2; scene.add(man.root);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      man.setMood('surprised');
      standPose(man, t, { neck: [-0.05, 0, 0], head: [-0.12 - 0.1 * easeOut(range(t, 0, 0.3)), 0.35, 0.05], lSh: [-0.5, 0, 0.9], lEl: [-1.9, 0, 0], rSh: [0.05, 0, -0.16] });
      man.setMouth(0.85 * easeOut(range(t, 0.05, 0.3)));
      const k = easeOut(range(t, 0, 1.1));
      const s = shake(t, 0.6);
      place(c, [0.2 + s[0], 1.66 + s[1], lerp(1.35, 1.0, k)], [0.03, 1.62, 0]);
      return { dof: { focus: lerp(1.35, 1.0, k) - 0.1, aperture: 0.003, maxblur: 0.008 }, bloom: 0.35 };
    },
  };
}

// ============ SHOT 2: underwater, fish eyes a rice stem ============
function shot2({ makeStage, start: ST }) {
  const tCrop = at(0, 'crop') - ST;
  const scene = makeStage({ shadowSize: 1 });
  underwater(scene, 0x3d7a68, 2.2);
  const F = farmMats();
  const mud = new THREE.Mesh(new THREE.BoxGeometry(4, 0.2, 4), F.mud); mud.position.y = -0.1; mud.receiveShadow = true; scene.add(mud);
  const surf = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), F.waterUnder); surf.rotation.x = -Math.PI / 2; surf.position.y = 0.42; scene.add(surf);
  scene.add(rice([[0.06, 0], [0.18, -0.12], [-0.25, -0.2], [0.3, 0.1]], { h: 0.8, r: 0.007, blades: 6, seed: 8 }));
  const f = fish(0.13); scene.add(f);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const x = lerp(-0.2, 0.0, easeOut(range(t, 0, tCrop + 0.05)));
      f.position.set(x, 0.17 + Math.sin(t * 2) * 0.006, 0.02);
      f.face(V(1, 0.05, 0)); f.swim(t, 10, 0.45);
      f.mouth(t > tCrop - 0.05 ? 0.5 + 0.5 * Math.sin((t - tCrop) * 11) : 0);
      const k = easeInOut(range(t, 0, 1.4));
      place(c, [lerp(-0.1, 0.0, k), 0.2, lerp(0.55, 0.38, k)], [lerp(-0.06, 0.03, k), 0.19, 0]);
      return { bloom: 0.5 };
    },
  };
}

// ============ SHOT 3: terraced paddies, centuries old ============
function shot3({ makeStage }) {
  const scene = makeStage({ shadowSize: 8, sunDir: [-4, 7, 2] });
  const F = farmMats();
  for (let i = 0; i < 7; i++) {
    const top = 0.2 + i * 0.42, z = -i * 1.3, w = 9;
    const curve = (i % 2 ? 0.25 : -0.2);
    const blk = new THREE.Mesh(new THREE.BoxGeometry(w, top + 1, 1.3), F.mud);
    blk.position.set(curve, (top - 1) / 2, z); blk.receiveShadow = true; blk.castShadow = true; scene.add(blk);
    const lip = new THREE.Mesh(new THREE.BoxGeometry(w, 0.08, 0.1), F.grass); lip.position.set(curve, top + 0.02, z + 0.62); scene.add(lip);
    const wt = new THREE.Mesh(new THREE.PlaneGeometry(w, 1.2), F.water); wt.rotation.x = -Math.PI / 2; wt.position.set(curve, top + 0.03, z); scene.add(wt);
    scene.add(rice(grid(curve - 4.2, curve + 4.2, z - 0.5, z + 0.45, 0.26, 0.04, 10 + i), { h: 0.32, r: 0.007, blades: 5, seed: 20 + i, y: top }));
  }
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(-0.5, 0.4, k), lerp(1.3, 1.9, k), lerp(2.8, 2.2, k)], [lerp(-0.2, 0.2, k), lerp(1.6, 2.0, k), -5]);
      return { bloom: 0.35 };
    },
  };
}

// ============ diorama for shots 4 + 5: a cut-away field ============
function diorama(scene) {
  const F = farmMats();
  const W = 1.3, D = 1.6, TOP = 0.4, TR = 0.24; // trench width along the left edge
  const g = new THREE.Group(); scene.add(g);
  const main = new THREE.Mesh(new THREE.BoxGeometry(W - TR, TOP, D), F.soil); main.position.set(TR / 2, TOP / 2, 0); g.add(main);
  const mainTop = new THREE.Mesh(new THREE.BoxGeometry(W - TR, 0.03, D), F.mud); mainTop.position.set(TR / 2, TOP - 0.015, 0); g.add(mainTop);
  // trench block: its top lowers as it is dug
  const tr = new THREE.Mesh(new THREE.BoxGeometry(TR, 1, D), F.soil); g.add(tr);
  const trTop = new THREE.Mesh(new THREE.BoxGeometry(TR, 0.03, D), F.mud); g.add(trTop);
  // walls (bunds) around the field
  const walls = [];
  const mk = (w, d, x, z) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, 1, d), F.grass); m.position.set(x, 0, z); g.add(m); walls.push(m); };
  mk(W + 0.08, 0.06, 0, D / 2 + 0.03); mk(W + 0.08, 0.06, 0, -D / 2 - 0.03); mk(0.06, D, -W / 2 - 0.03, 0); mk(0.06, D, W / 2 + 0.03, 0);
  // water volume (clipped by soil visually)
  const wm = new THREE.MeshPhysicalMaterial({ color: 0x6fb2a0, roughness: 0.05, transparent: true, opacity: 0.6, clearcoat: 1, depthWrite: false });
  const water = new THREE.Mesh(new THREE.BoxGeometry(W, 1, D), wm); water.renderOrder = 3; g.add(water);
  const fishes = [fish(0.15, 0xf08a2c), fish(0.13, 0xe0a040)];
  fishes.forEach(f => g.add(f));
  g.traverse(o => { if (o.isMesh && o !== water) { o.castShadow = true; o.receiveShadow = true; } });
  const set = ({ dig = 0, wall = 0, level = 0, fishOn = 0, t = 0 }) => {
    const trH = lerp(TOP, 0.12, dig);
    tr.scale.y = trH; tr.position.set(-W / 2 + TR / 2, trH / 2, 0);
    trTop.position.set(-W / 2 + TR / 2, trH - 0.015, 0);
    const wh = 0.02 + 0.16 * wall;
    for (const m of walls) { m.scale.y = wh; m.position.y = TOP - 0.005 + wh / 2; }
    const top = lerp(0.12, TOP + 0.13, level);
    water.visible = level > 0.001;
    water.scale.y = Math.max(0.001, top - 0.12); water.position.y = 0.12 + water.scale.y / 2;
    const full = top > TOP - 0.005;
    water.scale.set(full ? 0.996 : (TR - 0.004) / W, water.scale.y, 0.996); water.position.x = full ? 0 : -W / 2 + TR / 2;
    fishes.forEach((f, i) => {
      f.visible = fishOn > 0;
      const z = lerp(0.9, (i ? -0.25 : 0.2), easeOut(fishOn)) + Math.sin(t * 1.5 + i) * 0.03;
      f.position.set(-W / 2 + TR / 2 + (i ? 0.03 : -0.03), 0.2 + i * 0.05, z);
      f.face(V(0, 0, -1)); f.swim(t + i, 10, 0.4);
    });
  };
  return { set };
}

// ============ SHOT 4: dig a trench along the edge ============
function shot4({ makeStage, start: ST }) {
  const tDig = at(2, 'dig') - ST, tEdge = end(2, 'edge') - ST, tSo = at(2, 'so') - ST, tShel = end(2, 'shelter') - ST;
  const scene = makeStage({ shadowSize: 2, sunDir: [-3, 6, 4] });
  const d = diorama(scene);
  const shovel = new THREE.Group();
  const M = farmMats();
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.6, 12), new THREE.MeshStandardMaterial({ color: 0x8a6a48, roughness: 0.7 })); handle.position.y = 0.3; shovel.add(handle);
  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.14, 0.01), new THREE.MeshPhysicalMaterial({ color: 0xb0b4b8, metalness: 1, roughness: 0.35 })); blade.position.y = -0.06; shovel.add(blade);
  shovel.traverse(o => { if (o.isMesh) o.castShadow = true; });
  scene.add(shovel);
  const dirt = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), M.mud); scene.add(dirt);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const dig = easeInOut(range(t, tDig - 0.1, tEdge));
      d.set({ dig, wall: 0, level: kf(t, [[tSo - 0.15, 0], [tSo + 0.5, 0.35]]), fishOn: range(t, tSo, tShel - 0.2), t });
      // shovel scoops along the trench
      const cyc = (t * 2.2) % 1;
      const zz = lerp(0.6, -0.6, range(t, tDig - 0.1, tEdge));
      shovel.visible = t < tSo - 0.1;
      shovel.position.set(-0.53, lerp(0.4, 0.15, dig) + Math.max(0, Math.sin(cyc * Math.PI * 2)) * 0.12, zz);
      shovel.rotation.set(0.35 + Math.sin(cyc * Math.PI * 2) * 0.3, 0, 0.15);
      dirt.visible = t < tSo - 0.1 && t > tDig - 0.2;
      const dc = cyc;
      dirt.position.set(-0.53 - dc * 0.35, 0.5 + Math.sin(dc * Math.PI) * 0.25, zz);
      dirt.scale.setScalar(0.03 * (1 - dc * 0.3));
      const k = easeInOut(range(t, 0, 3.9));
      place(c, [lerp(-0.9, -0.6, k), lerp(1.3, 1.1, k), lerp(2.6, 2.3, k)], [-0.25, 0.25, 0]);
      return { bloom: 0.3 };
    },
  };
}

// ============ SHOT 5: raise the walls, flood the field ============
function shot5({ makeStage, start: ST }) {
  const tRaise = at(3, 'raise') - ST, tWalls = end(3, 'walls') - ST, tFlood = at(3, 'flood') - ST, tField = end(3, 'field') - ST;
  const scene = makeStage({ shadowSize: 2, sunDir: [-3, 6, 4] });
  const d = diorama(scene);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      d.set({ dig: 1, wall: easeOut(range(t, tRaise - 0.05, tWalls)), level: lerp(0.35, 1, easeInOut(range(t, tFlood - 0.05, tField + 0.2))), fishOn: 1, t: t + 3.9 });
      const k = easeInOut(range(t, 0, tField + 0.3));
      place(c, [lerp(-0.6, 0.2, k), lerp(1.2, 1.6, k), lerp(2.3, 2.6, k)], [lerp(-0.25, 0.0, k), 0.3, 0]);
      return { bloom: 0.3 };
    },
  };
}

// ============ SHOT 6: release young carp among seedlings ============
function shot6({ makeStage, start: ST }) {
  const tRel = at(4, 'release') - ST;
  const scene = makeStage({ shadowSize: 2.5 });
  scene.add(paddy(10, 10, { water: 0.12 }));
  scene.add(rice(grid(-1.6, 1.6, -2.6, 0.9, 0.3, 0.03, 4), { h: 0.3, r: 0.006, blades: 5, seed: 12 }));
  const man = farmer(); man.root.position.set(0.15, 0, 0.55); man.root.rotation.y = -0.6; scene.add(man.root);
  const bk = bucket(); scene.add(bk);
  const fry = [], spl = [];
  for (let i = 0; i < 6; i++) { const f = fish(0.07, i % 2 ? 0xf08a2c : 0xd9a24a); scene.add(f); fry.push(f); const s = splash(0.45, 11 + i); scene.add(s); spl.push(s); }
  const c = cam(38);
  const TT = tRel + 0.05; // tip time
  return {
    scene, camera: c,
    update(t) {
      const tip = easeInOut(range(t, TT - 0.5, TT + 0.3));
      standPose(man, t, {
        rSh: [-1.0, 0, lerp(-0.2, -0.05, tip)], rEl: [-0.5, 0, 0], lSh: [-0.9, 0, 0.35], lEl: [-0.7, 0, 0],
        chest: [0.15, 0, 0], neck: [0.25, 0, 0], head: [0.2, 0, 0],
      });
      man.setMood('happy'); man.setMouth(0.1);
      scene.updateMatrixWorld(true);
      const hand = wpos(man.j.rWr, V(0, -0.06, 0));
      bk.position.copy(hand).add(V(0, -0.02, 0));
      bk.rotation.set(0, 0, 0);
      bk.rotation.z = tip * 1.7; // pour toward -x
      bk.position.x -= tip * 0.05;
      const lip = V(-0.13, 0.11, 0).applyEuler(bk.rotation).add(bk.position);
      fry.forEach((f, i) => {
        const t0 = TT + i * 0.18;
        const dt = t - t0;
        if (dt < 0) { f.visible = false; spl[i].update(-1); return; }
        f.visible = true;
        const vx = -0.35 - (i % 3) * 0.12, vz = (i - 2.5) * 0.08;
        const G = 4;
        const y = lip.y - 0.5 * G * dt * dt;
        const tImp = Math.sqrt(2 * Math.max(0.001, lip.y - 0.12) / G);
        if (dt < tImp) {
          f.position.set(lip.x + vx * dt, y, lip.z + vz * dt);
          f.rotation.set(dt * 4 + i, 0.6 * i, -1.0); f.swim(t, 18, 0.8);
          spl[i].update(-1);
        } else {
          const ix = lip.x + vx * tImp, iz = lip.z + vz * tImp, u = dt - tImp;
          spl[i].position.set(ix, 0.12, iz); spl[i].update(u);
          const dir = V(-Math.cos(i), 0, -Math.abs(Math.sin(i)) - 0.3);
          f.position.set(ix + dir.x * u * 0.25, 0.07, iz + dir.z * u * 0.25);
          f.face(dir); f.swim(t + i, 12, 0.5);
        }
      });
      const k = easeInOut(range(t, 0, 3.2));
      const s = shake(t, 0.4);
      place(c, [lerp(-1.2, -1.35, k) + s[0], lerp(1.2, 1.1, k) + s[1], lerp(3.9, 3.6, k)], [lerp(-0.15, -0.3, k), 0.95, 0.4]);
      return { bloom: 0.45 };
    },
  };
}

// ============ SHOT 7: the mechanism, underwater ============
function shot7({ makeStage, start: ST }) {
  const tW = at(5, 'weeds') - ST, tP = at(5, 'pests') - ST, tWa = at(5, 'waste') - ST, tF = at(5, 'feeds') - ST, tE = end(5, 'rice') - ST + 0.35;
  const scene = makeStage({ shadowSize: 1 });
  underwater(scene, 0x3d7a68, 1.6);
  const F = farmMats();
  const mud = new THREE.Mesh(new THREE.BoxGeometry(4, 0.2, 4), F.mud); mud.position.y = -0.1; mud.receiveShadow = true; scene.add(mud);
  const SURF = 0.36;
  const surf = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), F.waterUnder); surf.rotation.x = -Math.PI / 2; surf.position.y = SURF; scene.add(surf);
  const riceMat = F.rice.clone(); riceMat.emissive = new THREE.Color(0x3cff6a); riceMat.emissiveIntensity = 0;
  const stems = rice([[0.12, -0.02], [0.24, -0.14], [-0.05, -0.22]], { h: 0.75, r: 0.007, blades: 6, seed: 31 });
  stems.blades.material = riceMat; scene.add(stems);
  const wd = weed(0.14); wd.position.set(-0.13, 0, 0.02); scene.add(wd);
  const b = bug(0.035); scene.add(b);
  const f = fish(0.13); scene.add(f);
  const pellets = [];
  for (let i = 0; i < 6; i++) { const p = new THREE.Mesh(new THREE.SphereGeometry(0.006, 10, 8), F.pellet); scene.add(p); pellets.push(p); }
  const glows = [0, 1, 2].map(() => { const g = glowSprite(0x6dff8a, 0.08); g.material.fog = false; scene.add(g); return g; });
  const c = cam(46);
  // local times: weed bite 0.8-1.4, bug snap 1.4-2.4, waste 2.4-5.1
  return {
    scene, camera: c,
    update(t) {
      // fish path: weed (on "weeds"), dart up to the bug (on "pests"), drift back (on "waste")
      const KEYS = [[0, [-0.42, 0.12, 0.04]], [tW - 0.1, [-0.22, 0.1, 0.04]], [tW + 0.35, [-0.2, 0.11, 0.04]], [tP + 0.3, [-0.02, 0.29, 0.03]], [tWa, [0.0, 0.2, 0.06]], [tE + 0.6, [-0.12, 0.2, 0.08]]];
      const P = kf(t, KEYS), P2 = kf(t + 0.05, KEYS);
      f.position.set(...P);
      let dir = V(P2[0] - P[0], P2[1] - P[1], P2[2] - P[2]);
      if (dir.length() < 1e-4 || t > tWa) dir = t > tWa ? V(-1, 0, 0.1) : V(1, 0, 0);
      if (t > tW - 0.1 && t < tW + 0.35) dir = V(1, -0.6, 0);
      f.face(dir); f.swim(t, 10, 0.45);
      const bite1 = t > tW - 0.05 && t < tW + 0.4 ? Math.abs(Math.sin((t - tW) * 18)) : 0;
      const bite2 = t > tP + 0.2 && t < tP + 0.45 ? 1 : 0;
      f.mouth(Math.max(bite1, bite2));
      // weed gets eaten
      const we = easeIn(range(t, tW, tW + 0.45));
      wd.scale.set(1, Math.max(0.02, 1 - we), 1);
      wd.visible = we < 0.98;
      // bug lands on the surface, gets snapped
      b.position.set(-0.01, SURF + 0.006 + Math.max(0, tP - 0.1 - t) * 0.4, 0.03);
      b.rotation.set(0, 0.4, Math.sin(t * 20) * 0.05);
      b.visible = t > tW - 0.25 && t < tP + 0.32;
      // waste pellets fall to the roots
      pellets.forEach((p, i) => {
        const t0 = tWa + i * 0.16, dt = t - t0;
        p.visible = dt > 0;
        const tail = V(-0.06 - dt * 0.04, 0.2, 0.06);
        p.position.set(tail.x + i * 0.035, Math.max(0.004, 0.19 - dt * 0.12), 0.05 - i * 0.012);
      });
      // rice gets fed: glow travels up the stems (on "feeds the rice")
      const feed = range(t, tF, tE);
      riceMat.emissiveIntensity = 0.25 * smooth(feed) * (0.7 + 0.3 * Math.sin(t * 8));
      glows.forEach((g, i) => {
        const base = [[0.12, -0.02], [0.24, -0.14], [-0.05, -0.22]][i];
        const ph = clamp(feed * 1.4 - i * 0.2);
        g.position.set(base[0], 0.01 + ph * 0.45, base[1]);
        g.material.opacity = feed > 0 ? Math.sin(ph * Math.PI) * 0.9 : 0;
        g.scale.setScalar(0.06 + 0.04 * ph);
      });
      const k = easeInOut(range(t, 0, tE));
      const camY = t < tP ? 0.16 : lerp(0.16, 0.2, range(t, tP, tP + 0.5));
      place(c, [lerp(-0.18, -0.02, k), camY, lerp(0.78, 0.7, k)], [lerp(-0.18, 0.02, k), lerp(0.15, 0.17, k), 0]);
      return { bloom: 0.6 };
    },
  };
}

// ============ SHOT 8: looking up, rice shades the water ============
function shot8({ makeStage }) {
  const scene = makeStage({ shadowSize: 1.5 });
  underwater(scene, 0x3d7a68, 1.1);
  const F = farmMats();
  const mud = new THREE.Mesh(new THREE.BoxGeometry(5, 0.2, 5), F.mud); mud.position.y = -0.1; scene.add(mud);
  const surf = new THREE.Mesh(new THREE.PlaneGeometry(5, 5), F.waterUnder); surf.rotation.x = -Math.PI / 2; surf.position.y = 0.42; scene.add(surf);
  scene.add(rice(grid(-0.8, 0.8, -0.9, 0.2, 0.17, 0.05, 41), { h: 0.9, r: 0.008, blades: 6, seed: 42 }));
  const shafts = [];
  for (let i = 0; i < 5; i++) { const s = shaft(0.6, 0.03 + i * 0.006); s.position.set(-0.5 + i * 0.27, 0.15, -0.35 + (i % 2) * 0.15); s.rotation.z = 0.25; scene.add(s); shafts.push(s); }
  const f1 = fish(0.14), f2 = fish(0.11, 0xe0a040); scene.add(f1, f2);
  const c = cam(50);
  return {
    scene, camera: c,
    update(t) {
      f1.position.set(lerp(0.35, -0.05, t / 3.4), 0.2 + Math.sin(t * 1.4) * 0.01, 0.12); f1.face(V(-1, 0, -0.05)); f1.swim(t, 5, 0.35);
      f2.position.set(lerp(-0.4, -0.12, t / 3.4), 0.12, -0.05); f2.face(V(1, 0, 0.1)); f2.swim(t + 1, 5, 0.3);
      shafts.forEach((s, i) => { s.material.opacity = 0.09 + 0.05 * Math.sin(t * 1.3 + i * 1.7); });
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [0.0, lerp(0.04, 0.06, k), lerp(0.75, 0.6, k)], [0.0, lerp(0.3, 0.4, k), lerp(-0.1, -0.2, k)]);
      return { bloom: 0.6 };
    },
  };
}

// ============ SHOT 9: harvest, rice in one hand, fish in the other ============
function shot9({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sun: 2.6, sunDir: [-2, 5, 5] });
  scene.add(paddy(12, 12, { water: 0.05 }));
  scene.add(rice(grid(-3.2, 3.2, -4, -0.7, 0.3, 0.06, 51), { h: 0.85, r: 0.008, golden: true, blades: 6, seed: 52 }));
  const man = farmer(); scene.add(man.root);
  const F = farmMats();
  const sheaf = rice(grid(-0.03, 0.03, -0.03, 0.03, 0.03, 0.01, 61), { h: 0.38, r: 0.005, golden: true, blades: 7, seed: 62 });
  scene.add(sheaf);
  const tie = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.008, 6, 20), farmMats().straw); tie.rotation.x = Math.PI / 2; sheaf.add(tie); tie.position.y = 0.12;
  const f = fish(0.3); scene.add(f);
  const sparkle = glowSprite(0xfff2c0, 0.2); scene.add(sparkle);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const up = easeOut(range(t, 0.1, 0.8));
      standPose(man, t, {
        lSh: [lerp(0.05, -2.0, up), 0, lerp(0.16, 0.3, up)], lEl: [lerp(-0.25, -0.35, up), 0, 0],
        rSh: [lerp(0.05, -2.0, up), 0, lerp(-0.16, -0.3, up)], rEl: [lerp(-0.25, -0.35, up), 0, 0],
        head: [-0.05, 0, Math.sin(t * 2) * 0.04],
      });
      man.setMood('happy'); man.setMouth(0.55 + 0.15 * Math.sin(t * 6));
      scene.updateMatrixWorld(true);
      const lh = wpos(man.j.lWr, V(0, -0.06, 0)), rh = wpos(man.j.rWr, V(0, -0.06, 0));
      sheaf.position.copy(lh).add(V(0, -0.12, 0.04)); sheaf.rotation.set(0, 0, 0.1);
      f.position.copy(rh).add(V(0.0, 0.0, 0.07)); f.rotation.set(0, 0, 1.25 + Math.sin(t * 9) * 0.12); f.swim(t, 12, 0.6);
      sparkle.position.copy(rh).add(V(0.05, 0.08, 0.1)); sparkle.material.opacity = 0.6 * Math.max(0, Math.sin(t * 3));
      const k = easeInOut(range(t, 0, 4.3));
      place(c, [lerp(0.25, 0.1, k), lerp(1.55, 1.6, k), lerp(3.9, 3.3, k)], [0, lerp(1.4, 1.55, k), 0]);
      return { bloom: 0.45 };
    },
  };
}

export const SHOTS = [
  { start: 0.0, end: 2.17, build: shot1 },      // "If you put fish in a rice field"
  { start: 2.17, end: 2.75, build: shotFace },  // "you'd think they'd"
  { start: 2.75, end: 4.2, build: shot2 },      // "eat the crop"
  { start: 4.2, end: 8.85, build: shot3 },      // "But farmers in China..."
  { start: 8.85, end: 12.85, build: shot4 },    // "First, dig a trench..."
  { start: 12.85, end: 15.55, build: shot5 },   // "Then raise the walls..."
  { start: 15.55, end: 18.4, build: shot6 },    // "A week after planting..."
  { start: 18.4, end: 22.5, build: shot7 },     // "The fish eat weeds and pests..."
  { start: 22.5, end: 25.75, build: shot8 },    // "The rice shades the water..."
  { start: 25.75, end: DURATION + 1, build: shot9 }, // "So at harvest..."
];
