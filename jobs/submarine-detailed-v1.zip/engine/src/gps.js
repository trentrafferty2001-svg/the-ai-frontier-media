// The Explainer: how GPS knows where you are. Earth, satellites, signal pulses, distance spheres, phone with a map, clocks.
// Units: 1 = 1000 km in the space sets. Earth radius 6.371, satellite orbit radius 26.56 (20,200 km up).
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TIME, NOISE } from './world.js';
import { rng } from './textures.js';

export const RE = 6.371, RS = 26.56;

export function space(scene) {
  const u = scene.userData.sky.material.uniforms;
  if (u.top) { u.top.value.set(0x02040a); u.mid.value.set(0x040814); u.horizon.value.set(0x060c1c); u.floorC.value.set(0x02040a); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  const R = rng(4), N = 2500, P = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) { const a = R() * Math.PI * 2, b = Math.acos(2 * R() - 1), r = 300; P[i * 3] = Math.sin(b) * Math.cos(a) * r; P[i * 3 + 1] = Math.cos(b) * r; P[i * 3 + 2] = Math.sin(b) * Math.sin(a) * r; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(P, 3));
  const stars = new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 0.9, sizeAttenuation: true, fog: false })); stars.frustumCulled = false; scene.add(stars);
  const key = scene.userData.key; key.position.set(60, 20, 40); key.target.position.set(0, 0, 0); key.intensity = 2.2; key.castShadow = false;
  scene.add(new THREE.AmbientLight(0x6080ff, 0.25));
  scene.userData.updaters.push((t) => { stars.position.copy(scene.userData.camPos || new THREE.Vector3()); });
}

export function earth() {
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.75 });
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vOe;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvOe = normalize(position);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vOe;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      vec3 p = vOe; float lat = asin(p.y); float lon = atan(p.z, p.x);
      float n = fbm(vec2(lon * 1.6, lat * 2.2) + 3.0) + 0.35 * fbm(vec2(lon * 5.0, lat * 6.0));
      float land = smoothstep(0.7, 0.73, n);
      vec3 ocean = mix(vec3(0.03, 0.14, 0.38), vec3(0.06, 0.3, 0.55), fbm(vec2(lon, lat) * 8.0));
      vec3 ground = mix(vec3(0.12, 0.38, 0.12), vec3(0.5, 0.4, 0.22), smoothstep(0.78, 0.9, n));
      float ice = smoothstep(1.2, 1.35, abs(lat));
      diffuseColor.rgb = mix(mix(ocean, ground, land), vec3(0.95), ice);`);
  };
  const g = new THREE.Group();
  const e = new THREE.Mesh(new THREE.SphereGeometry(RE, 96, 64), m); g.add(e);
  const cl = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.0, depthWrite: false });
  cl.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = TIME;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vOc;').replace('#include <begin_vertex>', '#include <begin_vertex>\nvOc = normalize(position);');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vOc; uniform float uTime;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float lat = asin(vOc.y); float lon = atan(vOc.z, vOc.x) + uTime * 0.01;
      diffuseColor.a = smoothstep(0.62, 0.8, fbm(vec2(lon * 3.0, lat * 5.0) + 11.0)) * 0.7;`);
  };
  const clouds = new THREE.Mesh(new THREE.SphereGeometry(RE * 1.01, 96, 64), cl); g.add(clouds);
  const atm = new THREE.Mesh(new THREE.SphereGeometry(RE * 1.05, 64, 48), new THREE.ShaderMaterial({
    vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position,1.0); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - max(dot(vN, vV), 0.0), 3.0); gl_FragColor = vec4(vec3(0.35, 0.6, 1.0) * f * 1.6, f); }`,
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.FrontSide,
  })); g.add(atm);
  return { group: g, globe: e };
}

export function satellite({ scale = 1 } = {}) {
  const g = new THREE.Group();
  const gold = new THREE.MeshStandardMaterial({ color: 0xd8a33a, metalness: 0.9, roughness: 0.3 });
  const body = new THREE.Mesh(new RoundedBoxGeometry(1, 1.2, 1, 2, 0.06), gold); g.add(body);
  const panelM = new THREE.MeshStandardMaterial({ color: 0x1d3a8a, metalness: 0.6, roughness: 0.25, emissive: 0x0a1840, emissiveIntensity: 0.3 });
  [-1, 1].forEach((s) => {
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.8, 8), new THREE.MeshStandardMaterial({ color: 0xbbbbbb, metalness: 0.8 })); arm.rotation.z = Math.PI / 2; arm.position.x = s * 0.9; g.add(arm);
    const p = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.03, 1.0), panelM); p.position.x = s * 2.4; g.add(p);
    for (let k = 1; k < 6; k++) { const ln = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.035, 1.0), new THREE.MeshStandardMaterial({ color: 0x8899cc })); ln.position.x = s * (1.2 + k * 0.4); g.add(ln); }
  });
  // antenna array pointing down (toward Earth = local -y)
  const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.5, 0.25, 16), new THREE.MeshStandardMaterial({ color: 0xeeeeee, metalness: 0.4, roughness: 0.4 })); ant.position.y = -0.72; g.add(ant);
  const glow = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 12), new THREE.MeshBasicMaterial({ color: 0x7fd8ff })); glow.position.set(0, 0.2, 0.51); g.add(glow);
  g.scale.setScalar(scale);
  return { group: g, glow };
}
// orbit positions: 6 planes x 5 sats, inclination 55 deg
export function constellation(n = 30) {
  const list = [];
  for (let i = 0; i < n; i++) { const plane = i % 6, k = Math.floor(i / 6); list.push({ raan: plane / 6 * Math.PI * 2, ph: k / 5 * Math.PI * 2 + plane * 0.5 }); }
  const inc = 55 * Math.PI / 180;
  const pos = (s, t, out) => {
    const a = s.ph + t * 0.05; const x = Math.cos(a) * RS, y0 = Math.sin(a) * RS;
    const y = y0 * Math.sin(inc), z = y0 * Math.cos(inc);
    out.set(x * Math.cos(s.raan) - z * Math.sin(s.raan), y, x * Math.sin(s.raan) + z * Math.cos(s.raan)); return out;
  };
  return { list, pos };
}
export function orbitRing(raan, color = 0x5f8fff) {
  const inc = 55 * Math.PI / 180; const pts = [];
  for (let k = 0; k <= 128; k++) { const a = k / 128 * Math.PI * 2; const x = Math.cos(a) * RS, y0 = Math.sin(a) * RS; const y = y0 * Math.sin(inc), z = y0 * Math.cos(inc); pts.push(new THREE.Vector3(x * Math.cos(raan) - z * Math.sin(raan), y, x * Math.sin(raan) + z * Math.cos(raan))); }
  return new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.35 }));
}
// distance sphere with a glowing rim (fresnel), colour per satellite
export function distSphere(color) {
  const m = new THREE.ShaderMaterial({
    uniforms: { uC: { value: new THREE.Color(color) }, uA: { value: 1 } },
    vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vN = normalize(normalMatrix * normal); vec4 mv = modelViewMatrix * vec4(position,1.0); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform vec3 uC; uniform float uA; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - abs(dot(vN, vV)), 2.5); gl_FragColor = vec4(uC, (0.05 + 0.6 * f) * uA); }`,
    transparent: true, depthWrite: false, side: THREE.DoubleSide,
  });
  return new THREE.Mesh(new THREE.SphereGeometry(1, 96, 64), m);
}
// signal pulse: a glowing bead travelling from a to b; .set(k 0..1)
export function pulse(color = 0x9fe6ff) {
  const g = new THREE.Group();
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.35, 16, 12), new THREE.MeshBasicMaterial({ color })); g.add(head);
  const line = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1, 8, 1, true), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.5 })); g.add(line);
  const a = new THREE.Vector3(), b = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
  return { group: g, set(from, to, k, trail = true) {
    a.copy(from); b.copy(to); head.position.lerpVectors(a, b, k);
    const mid = new THREE.Vector3().lerpVectors(a, head.position, 0.5); line.position.copy(mid); line.scale.y = Math.max(0.001, a.distanceTo(head.position));
    line.quaternion.setFromUnitVectors(up, new THREE.Vector3().subVectors(b, a).normalize()); line.visible = trail;
  } };
}
// phone with a canvas map screen; .dot(x, y) moves the blue location dot in map space (0..1)
export function phone() {
  const g = new THREE.Group();
  const body = new THREE.Mesh(new RoundedBoxGeometry(0.75, 1.55, 0.08, 4, 0.08), new THREE.MeshStandardMaterial({ color: 0x1b1d22, roughness: 0.3, metalness: 0.5 })); body.castShadow = true; g.add(body);
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 1024; const c = cv.getContext('2d');
  c.fillStyle = '#e9e5dc'; c.fillRect(0, 0, 512, 1024);
  c.fillStyle = '#bfe3a6'; c.fillRect(300, 120, 170, 260); c.fillRect(40, 640, 200, 180);
  c.fillStyle = '#a8d4f0'; c.beginPath(); c.moveTo(0, 470); c.bezierCurveTo(150, 430, 300, 560, 512, 500); c.lineTo(512, 560); c.bezierCurveTo(300, 620, 150, 490, 0, 530); c.fill();
  c.strokeStyle = '#ffffff'; c.lineWidth = 18; [[0, 260, 512, 300], [0, 800, 512, 760], [140, 0, 180, 1024], [380, 0, 340, 1024]].forEach(([a, b, d, e]) => { c.beginPath(); c.moveTo(a, b); c.lineTo(d, e); c.stroke(); });
  c.lineWidth = 8; c.strokeStyle = '#f7f5f0'; for (let k = 0; k < 8; k++) { c.beginPath(); c.moveTo(0, 60 + k * 130); c.lineTo(512, 80 + k * 130); c.stroke(); }
  const tx = new THREE.CanvasTexture(cv); tx.colorSpace = THREE.SRGBColorSpace;
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.68, 1.42), new THREE.MeshBasicMaterial({ map: tx })); screen.position.z = 0.041; g.add(screen);
  const dotM = new THREE.MeshBasicMaterial({ color: 0x2a7bff }); const dot = new THREE.Mesh(new THREE.CircleGeometry(0.035, 24), dotM); dot.position.z = 0.044; g.add(dot);
  const halo = new THREE.Mesh(new THREE.CircleGeometry(0.08, 32), new THREE.MeshBasicMaterial({ color: 0x2a7bff, transparent: true, opacity: 0.25 })); halo.position.z = 0.043; g.add(halo);
  const ghost = new THREE.Mesh(new THREE.CircleGeometry(0.035, 24), new THREE.MeshBasicMaterial({ color: 0xe0402f })); ghost.position.z = 0.045; ghost.visible = false; g.add(ghost);
  const toS = (x, y) => [(x - 0.5) * 0.68, (0.5 - y) * 1.42];
  return { group: g, setDot(x, y, pulseK = 0) { const [a, b] = toS(x, y); dot.position.x = halo.position.x = a; dot.position.y = halo.position.y = b; halo.scale.setScalar(1 + pulseK); halo.material.opacity = 0.3 * (1 - pulseK * 0.7); },
    setGhost(x, y, vis) { const [a, b] = toS(x, y); ghost.position.x = a; ghost.position.y = b; ghost.visible = vis; } };
}
// analog clock face; .set(seconds)
export function clockFace(color = 0xffffff) {
  const g = new THREE.Group();
  g.add(new THREE.Mesh(new THREE.CircleGeometry(1, 64), new THREE.MeshStandardMaterial({ color, roughness: 0.4 })));
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1, 0.06, 12, 64), new THREE.MeshStandardMaterial({ color: 0x9aa3ad, metalness: 0.8, roughness: 0.3 })); g.add(rim);
  for (let k = 0; k < 12; k++) { const tk = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.01), new THREE.MeshBasicMaterial({ color: 0x222222 })); const a = k / 12 * Math.PI * 2; tk.position.set(Math.sin(a) * 0.85, Math.cos(a) * 0.85, 0.01); tk.rotation.z = -a; g.add(tk); }
  const hand = (len, w, c) => { const h = new THREE.Group(); const m = new THREE.Mesh(new THREE.BoxGeometry(w, len, 0.02), new THREE.MeshBasicMaterial({ color: c })); m.position.y = len / 2; h.add(m); h.position.z = 0.03; g.add(h); return h; };
  const mn = hand(0.75, 0.06, 0x222222), sc = hand(0.85, 0.025, 0xe0402f);
  return { group: g, set(s) { sc.rotation.z = -s / 60 * Math.PI * 2; mn.rotation.z = -s / 3600 * Math.PI * 2; } };
}
export function label(text, { size = 0.3, color = '#ffffff' } = {}) {
  const cv = document.createElement('canvas'); cv.width = 1024; cv.height = 256; const c = cv.getContext('2d');
  const draw = (s) => { c.clearRect(0, 0, 1024, 256); c.font = '700 110px Poppins, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round'; c.lineWidth = 16; c.strokeStyle = 'rgba(0,0,0,0.85)'; c.strokeText(s, 512, 136); c.fillStyle = color; c.fillText(s, 512, 136); tx.needsUpdate = true; };
  const tx = new THREE.CanvasTexture(cv); tx.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx, transparent: true, depthWrite: false, fog: false })); sp.scale.set(size * 4, size, 1);
  draw(text); return { sprite: sp, set: draw };
}
