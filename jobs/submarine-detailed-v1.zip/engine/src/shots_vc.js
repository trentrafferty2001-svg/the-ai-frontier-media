// The Explainer: why volcanoes erupt. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { volcano, magmaSystem, lavaFlows, plume, soda, CRATER, CHAMBER, std } from './volcano.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_vc.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *volcano* erupts', 3], ['for the same', 3], ['*reason*', 1], ['a *shaken bottle*', 3], ['of *soda* does', 3]],
  [['*Deep* underground', 2], ['rock gets', 2], ['*hot enough*', 2], ['to *melt*', 2], ['into *magma*', 2]],
  [['Magma is *lighter*', 3], ['than the rock', 3], ['around it', 2], ['so it *rises*', 3], ['and *pools*', 2], ['in a *chamber*', 3], ['a few', 2], ['*kilometres* down', 2]],
  [["It's full of", 3], ['*dissolved gas*', 2], ['mostly', 1], ['*water vapour*', 2], ['and *carbon*', 2], ['*dioxide*', 1]],
  [['As the magma', 3], ['*rises*', 1], ['the *pressure*', 2], ['*drops*', 1], ['and that gas', 3], ['forms *bubbles*', 2], ['just like', 2], ['*opening a soda*', 3]],
  [['The *bubbles*', 2], ['*swell*', 1], ['and the *pressure*', 3], ['*builds*', 1], ['until the rock', 3], ['above', 1], ["*can't hold it*", 3]],
  [['*Runny* magma', 2], ['lets the gas', 3], ['escape *gently*', 2], ['so *lava*', 2], ['*pours out*', 2], ['like in *Hawaii*', 3]],
  [['*Sticky* magma', 2], ['*traps* the gas', 3], ['so it *blasts*', 3], ['out in a', 3], ['*huge explosion*', 2]],
  [['The *lava*', 2], ['that comes out', 3], ['can be over', 3], ['*a thousand*', 2], ['*degrees*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.05; c.far = 900; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.6, warm: 1.08, sat: 1.18, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };
const sky = (makeStage, dusk = false) => makeStage({ outdoor: dusk ? 'golden' : 'day', sunDir: [0.5, 0.6, 0.7], fog: 0.004, shadowSize: 20, envI: 0.9, cloud: 0.35 });

// cutaway world: shared magma state by global time
function cutaway(makeStage) {
  const scene = sky(makeStage); const V = volcano({ cut: true }); scene.add(V.group); const M = magmaSystem(); scene.add(M.group);
  const fill = new THREE.PointLight(0xff8a40, 0, 30); fill.position.set(0, -5, 6); scene.add(fill);
  return { scene, V, M, fill };
}
function magmaState(M, T) {
  const s = M.st;
  s.melt = smooth(range(T, at(1, 'hot') - 0.3, at(1, 'melt') + 0.3));
  s.rise = smooth(range(T, at(1, 'magma'), at(2, 'rises')));
  s.fill = lerp(0.25, 1, smooth(range(T, at(2, 'rises'), at(2, 'chamber') + 0.5)));
  s.gas = smooth(range(T, at(3, 'dissolved') - 0.2, at(3, 'gas') + 0.4));
  s.conduit = smooth(range(T, at(4, 'rises') - 0.3, at(4, 'bubbles') + 0.4));
  s.bubbleSize = lerp(0.05, 0.4, smooth(range(T, at(4, 'bubbles') - 0.3, at(4, 'bubbles') + 0.3))) + 0.6 * smooth(range(T, at(5, 'swell') - 0.3, at(5, 'builds')));
  s.crack = smooth(range(T, at(5, 'rock'), le(5) + 0.2));
}

// ============ S0 hook: an eruption slams up, then a soda bottle pops the same way ============
function sHook({ makeStage }) {
  const scene = sky(makeStage);
  const V = volcano({ cut: false }); scene.add(V.group); const P = plume(); scene.add(P.group);
  const S = soda(); S.group.position.set(200, 0, 0); scene.add(S.group);
  const table = new THREE.Mesh(new THREE.BoxGeometry(8, 0.3, 6), std(0x8a5a32, 0.6)); table.position.set(200, -0.15, 0); scene.add(table);
  const c = C(40); const cut = at(0, 'shaken') - 0.1;
  return {
    scene, camera: c,
    update(t) {
      if (t < cut) {
        P.set(easeOut(range(t, 0.0, 2.2)), t);
        const sh = 0.25 * Math.exp(-t * 2); const k = easeOut(range(t, 0, cut));
        orb(c, [Math.sin(t * 50) * sh, lerp(12, 16, k), 0], lerp(62, 70, k), lerp(25, 30, k), lerp(4, 8, k));
        return { ...POST, exposure: 1.05 };
      }
      S.set(easeOut(range(t, at(0, 'soda') - 0.15, at(0, 'soda') + 0.5)), t);
      const k = easeInOut(range(t, cut, cut + 2.4));
      orb(c, [200, lerp(1.6, 2.6, k), 0], lerp(5.2, 6.4, k), lerp(20, 30, k), lerp(10, 14, k));
      return POST;
    },
  };
}
function cutShot(cam0, cam1, extra) {
  return ({ makeStage }) => {
    const W = cutaway(makeStage); const c = C(40); const ex = extra ? extra(W) : null;
    return {
      scene: W.scene, camera: c,
      update(t, T) {
        magmaState(W.M, T); if (ex) ex(t, T); W.M.update(T); W.fill.intensity = 30 * W.M.st.fill;
        const k = easeInOut(range(t, 0, 4.5));
        orb(c, cam0.tg.map((v, i) => lerp(v, cam1.tg[i], k)), lerp(cam0.d, cam1.d, k), lerp(cam0.az, cam1.az, k), lerp(cam0.el, cam1.el, k));
        return POST;
      },
    };
  };
}
const sMelt = cutShot({ tg: [0, -7, 0], d: 34, az: 8, el: 4 }, { tg: [0, -9, 0], d: 28, az: -4, el: 2 });
const sRise = cutShot({ tg: [0, -8, 0], d: 30, az: -6, el: 2 }, { tg: [0, -5, 0], d: 24, az: 6, el: 4 }, (W) => {
  const L = tag(W.scene, 'a few km down', 0.9, '#ffe14a', [6.5, -3.6, 0.3]);
  return (t, T) => pop(L, easeOut(range(T, at(2, 'kilometres') - 0.2, at(2, 'kilometres') + 0.2)), 0.9);
});
const sGas = cutShot({ tg: [0, -6, 0], d: 14, az: 4, el: 2 }, { tg: [0, -6, 0], d: 11, az: -6, el: 2 }, (W) => {
  const L1 = tag(W.scene, 'H₂O', 0.6, '#bfe6ff', [-2.6, -3.9, 0.3]), L2 = tag(W.scene, 'CO₂', 0.6, '#ffffff', [2.6, -3.9, 0.3]);
  return (t, T) => { pop(L1, easeOut(range(T, at(3, 'water') - 0.1, at(3, 'water') + 0.2)), 0.6); pop(L2, easeOut(range(T, at(3, 'carbon') - 0.1, at(3, 'carbon') + 0.2)), 0.6); };
});
const sBubbles = cutShot({ tg: [0, -2, 0], d: 28, az: -4, el: 3 }, { tg: [0, 0, 0], d: 25, az: 6, el: 4 });
const sPressure = cutShot({ tg: [0, 0, 0], d: 25, az: 4, el: 4 }, { tg: [0, 0.5, 0], d: 23, az: -4, el: 6 }, (W) => (t, T) => {
  const sh = 0.12 * W.M.st.crack; W.scene.position.set(Math.sin(T * 47) * sh, Math.cos(T * 39) * sh, 0);
});
// ============ S6: runny magma: gentle lava flows down a broad shield volcano (Hawaii) ============
function sHawaii({ makeStage }) {
  const scene = sky(makeStage, true);
  const V = volcano({ cut: false, R: 22, H: 4.5 }); scene.add(V.group); const F = lavaFlows(22, 4.5, 8); scene.add(F.group);
  const fountain = []; const lm = new THREE.MeshStandardMaterial({ color: 0xff6a10, emissive: 0xff4a00, emissiveIntensity: 2, toneMapped: false }); const R = rnd(5);
  for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), lm); scene.add(m); fountain.push({ m, vx: (R() - 0.5) * 1.6, vz: (R() - 0.5) * 1.6, vy: 3 + R() * 2, ph: R() }); }
  const glow = new THREE.PointLight(0xff7a30, 60, 40); glow.position.set(0, 6, 0); scene.add(glow);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      F.set(easeOut(range(T, at(6, 'lava') - 0.6, le(6) + 0.6)));
      fountain.forEach(o => { const tt = ((T * 0.9 + o.ph) % 1) * 1.2; o.m.position.set(o.vx * tt, 4.1 + o.vy * tt - 4.9 * tt * tt, o.vz * tt); o.m.visible = T > at(6, 'gently') - 0.5; });
      const k = easeInOut(range(t, 0, 4.8));
      orb(c, [0, lerp(3, 2, k), 0], lerp(40, 34, k), lerp(20, 34, k), lerp(16, 12, k));
      return POST;
    },
  };
}
// ============ S7: sticky magma: explosive eruption, giant ash plume ============
function sExplode({ makeStage }) {
  const scene = sky(makeStage);
  const V = volcano({ cut: false }); scene.add(V.group); const P = plume(9); scene.add(P.group);
  const flash = new THREE.PointLight(0xff8a40, 0, 80); flash.position.set(0, 8, 0); scene.add(flash);
  const c = C(42); const tb = at(7, 'blasts');
  return {
    scene, camera: c,
    update(t, T) {
      const k = easeOut(range(T, tb - 0.2, le(7) + 1.0)); P.set(k, T);
      flash.intensity = 200 * Math.exp(-Math.max(0, T - tb) * 2) * (T > tb ? 1 : 0);
      const sh = 0.5 * Math.exp(-Math.max(0, T - tb) * 1.8) * (T > tb ? 1 : 0);
      const kk = easeInOut(range(t, 0, 4.2));
      orb(c, [Math.sin(T * 53) * sh, lerp(8, 18, kk) + Math.cos(T * 41) * sh, 0], lerp(46, 64, kk), lerp(-20, -8, kk), lerp(3, 6, kk));
      return POST;
    },
  };
}
// ============ S8: close on a lava flow: over 1,000 C ============
function sLava({ makeStage }) {
  const scene = sky(makeStage, true);
  const V = volcano({ cut: false, R: 22, H: 4.5 }); scene.add(V.group); const F = lavaFlows(22, 4.5, 8); F.set(1); scene.add(F.group);
  const glow = new THREE.PointLight(0xff7a30, 40, 30); glow.position.set(9, 4, 2); scene.add(glow);
  const L = tag(scene, 'over 1,000°C', 1.6, '#ffb347', [8, 9.5, 0]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      F.mat.emissiveIntensity = 1.6 + 0.3 * Math.sin(T * 3);
      pop(L, easeOut(range(T, at(8, 'thousand') - 0.2, at(8, 'thousand') + 0.2)), 1.6);
      const k = easeInOut(range(t, 0, 4.5));
      orb(c, [lerp(9, 6, k), 2.5, 0], lerp(24, 32, k), lerp(60, 70, k), lerp(16, 22, k));
      return POST;
    },
  };
}

const SH = [sHook, sMelt, sRise, sGas, sBubbles, sPressure, sHawaii, sExplode, sLava];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
