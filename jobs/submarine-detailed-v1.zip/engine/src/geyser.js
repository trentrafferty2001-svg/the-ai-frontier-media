// The Explainer: why geysers erupt. Surface: sinter mound, pool, eruption column, boardwalk + people.
// Cutaway: cross-section face (z=0) with strata, a twisting pipe filled with water (colour = temperature), rain
// seeping down, magma glow, steam bubbles. Units ~ metres; column up to ~50.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.8, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
// ---------- surface ----------
export function mound() {
  const g = new THREE.Group();
  const pts = []; for (let i = 0; i <= 20; i++) { const r = i / 20 * 14; pts.push(new THREE.Vector2(Math.max(0.01, r), 2.2 * Math.pow(1 - i / 20, 1.6) + 0.05 * Math.sin(i * 3))); }
  const m = new THREE.Mesh(new THREE.LatheGeometry(pts.reverse(), 64), std(0xd8d0c0, 0.95, 0, { side: THREE.DoubleSide })); g.add(m);
  const vent = new THREE.Mesh(new THREE.CircleGeometry(0.9, 24), std(0x2a6a8a, 0.1, 0, { emissive: 0x0a3a5a, emissiveIntensity: 0.4 })); vent.rotation.x = -Math.PI / 2; vent.position.y = 2.22; g.add(vent);
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.9, 1.8, 32), std(0xc89a4a, 0.9)); ring.rotation.x = -Math.PI / 2; ring.position.y = 2.21; g.add(ring);
  return g;
}
// eruption column: water/steam puffs up to height h*50; plus droplets
export function column(seed = 2) {
  const G = new THREE.Group(); const R = rnd(seed); const P = [];
  const sm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, transparent: true, opacity: 0.85 }); const geo = new THREE.IcosahedronGeometry(1, 2);
  for (let i = 0; i < 110; i++) { const m = new THREE.Mesh(geo, sm); G.add(m); P.push({ m, ph: R(), dx: (R() - 0.5), dz: (R() - 0.5), s: 0.6 + R() * 0.8 }); }
  const dm = new THREE.MeshBasicMaterial({ color: 0xcfeeff }); const D = []; for (let i = 0; i < 80; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 4), dm); G.add(m); D.push({ m, ph: R(), vx: (R() - 0.5) * 6, vz: (R() - 0.5) * 6, vy: 18 + R() * 12 }); }
  function set(h, T) { P.forEach(o => { const u = ((o.ph + T * 0.5) % 1); const y = 2.2 + u * 50 * h; const spread = 0.6 + (y / 50) * 4.5; o.m.position.set(o.dx * spread, y, o.dz * spread); o.m.scale.setScalar(h > 0.02 ? (0.7 + y * 0.09) * o.s * (1 - u * 0.3) : 0.0001); o.m.visible = h > 0.02; }); sm.opacity = 0.85;
    D.forEach(o => { const tt = ((T * 0.6 + o.ph) % 1) * 2.4 * Math.sqrt(h); o.m.visible = h > 0.2; o.m.position.set(o.vx * tt, 2.2 + o.vy * tt * h - 4.9 * tt * tt, o.vz * tt); }); }
  set(0, 0);
  return { group: G, set };
}
export function steam(n = 30, seed = 5) { const G = new THREE.Group(); const R = rnd(seed); const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, transparent: true, opacity: 0.45, depthWrite: false }); const P = []; for (let i = 0; i < n; i++) { const s = new THREE.Mesh(new THREE.IcosahedronGeometry(1, 1), m); G.add(s); P.push({ s, ph: R(), dx: (R() - 0.5) * 2 }); } return { group: G, update(T, k = 1) { P.forEach(o => { const u = (o.ph + T * 0.15) % 1; o.s.position.set(o.dx + u * 2, 2.4 + u * 9, (o.ph - 0.5)); o.s.scale.setScalar(k * (0.6 + u * 2.2)); o.s.visible = k > 0.02; }); } }; }
export function people(n = 14, seed = 7) { const G = new THREE.Group(); const R = rnd(seed); const walk = new THREE.Mesh(new THREE.BoxGeometry(34, 0.3, 2.2), std(0x8a6a4a, 0.9)); walk.position.set(0, 0.6, 18); G.add(walk);
  for (let i = 0; i < n; i++) { const p = new THREE.Group(); const b = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.3, 1.1, 10), std([0xe04a3a, 0x3a7ae0, 0xf0c02a, 0x4aa04a][i % 4])); b.position.y = 0.55; p.add(b); const h = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), std(0xe8c0a0)); h.position.y = 1.3; p.add(h); p.position.set(-15 + i * 2.2 + R() * 0.6, 0.75, 18 + (R() - 0.5) * 1.2); G.add(p); } return G; }

// ---------- cutaway ----------
export const PIPE = new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, 0.3), new THREE.Vector3(0.6, -4, 0.3), new THREE.Vector3(-1.4, -8, 0.3), new THREE.Vector3(0.8, -12, 0.3), new THREE.Vector3(-0.6, -16, 0.3), new THREE.Vector3(1.2, -20, 0.3), new THREE.Vector3(0.2, -24, 0.3)]);
export function cutaway() {
  const G = new THREE.Group();
  const sh = new THREE.Shape(); sh.moveTo(-30, -40); sh.lineTo(30, -40); sh.lineTo(30, 0); sh.lineTo(-30, 0); sh.closePath();
  const fg = new THREE.ShapeGeometry(sh, 4); const fp = fg.attributes.position; const fc = []; const c = new THREE.Color();
  for (let i = 0; i < fp.count; i++) { const y = fp.getY(i); const band = Math.floor((-y) / 3.2) % 3; c.set([0x8a7a62, 0x7a6a52, 0x9a8a70][band]); if (y < -26) c.lerp(new THREE.Color(0xc0402a), Math.min(1, (-26 - y) / 8)); fc.push(c.r, c.g, c.b); }
  fg.setAttribute('color', new THREE.Float32BufferAttribute(fc, 3));
  const face = new THREE.Mesh(fg, std(0xffffff, 0.95, 0, { vertexColors: true, side: THREE.DoubleSide })); G.add(face);
  const magma = new THREE.Mesh(new THREE.PlaneGeometry(60, 6), new THREE.MeshBasicMaterial({ color: 0xff5a1a, transparent: true, opacity: 0.85, toneMapped: false })); magma.position.set(0, -37, 0.05); G.add(magma);
  // pipe wall + water (vertex colours by depth: cool blue at top -> red-hot at depth), drawn as a fill from the bottom
  const wall = new THREE.Mesh(new THREE.TubeGeometry(PIPE, 120, 0.75, 12), std(0x3a3028, 0.9, 0, { side: THREE.BackSide })); G.add(wall);
  const wg = new THREE.TubeGeometry(PIPE, 120, 0.55, 12); const wpos = wg.attributes.position; const wc = []; for (let i = 0; i < wpos.count; i++) wc.push(0, 0, 0); wg.setAttribute('color', new THREE.Float32BufferAttribute(wc, 3));
  const water = new THREE.Mesh(wg, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.2, emissive: 0x000000 })); G.add(water);
  const chambers = [[-1.4, -8], [1.2, -20]].map(([x, y]) => { const m = new THREE.Mesh(new THREE.SphereGeometry(1.4, 20, 14), std(0x2a6aa8, 0.2)); m.scale.z = 0.3; m.position.set(x, y, 0.3); G.add(m); return m; });
  const R = rnd(4); const bubbles = []; const bm = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false });
  for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), bm); G.add(m); bubbles.push({ m, ph: R() }); }
  const rain = []; const rm = new THREE.MeshBasicMaterial({ color: 0x6ab8ff, toneMapped: false }); for (let i = 0; i < 70; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), rm); G.add(m); rain.push({ m, x: (R() - 0.5) * 36, ph: R() }); }
  const cBlue = new THREE.Color(0x2a8ae8), cHot = new THREE.Color(0xe8402a), cSteam = new THREE.Color(0xffffff);
  const st = { fill: 1, heat: 0, steam: 0, bubbles: 0, rain: 0, overflow: 0 };
  function update(T) {
    // colour + fill: u = 0 at the top of the pipe, 1 at the bottom
    const n = wpos.count; const segs = 121; const per = n / segs; const ca = wg.attributes.color;
    for (let i = 0; i < n; i++) { const u = Math.floor(i / per) / 120; c.copy(cBlue).lerp(cHot, Math.max(0, Math.min(1, st.heat * (u * 1.3 - 0.1)))).lerp(cSteam, st.steam * Math.max(0, 1.2 - u)); ca.setXYZ(i, c.r, c.g, c.b); }
    ca.needsUpdate = true;
    const keep = Math.max(0, Math.min(1, st.fill)); const startSeg = Math.floor((1 - keep) * 120); wg.setDrawRange(startSeg * 12 * 6, (120 - startSeg) * 12 * 6);
    chambers.forEach(m => { m.material.color.copy(cBlue).lerp(cHot, st.heat * 0.9).lerp(cSteam, st.steam); });
    bubbles.forEach(b => { const u = ((b.ph + T * 0.35) % 1); const p = PIPE.getPoint(1 - u * (0.6 + 0.4 * st.overflow)); b.m.position.set(p.x + Math.sin(T * 5 + b.ph * 9) * 0.2, p.y, 0.6); b.m.scale.setScalar(Math.max(0.001, st.bubbles * (0.5 + u))); b.m.visible = st.bubbles > 0.02; });
    rain.forEach(r => { const u = ((r.ph + T * 0.2) % 1); r.m.position.set(r.x * (1 - u * 0.7), -u * 22, 0.5); r.m.visible = st.rain > 0.02; r.m.scale.setScalar(st.rain); });
  }
  update(0);
  return { group: G, st, update };
}
export { std };
