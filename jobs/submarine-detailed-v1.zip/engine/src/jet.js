// The Explainer: how a jet engine works. Cutaway turbofan (axis along x, air flows toward -x), airliner, airflow particles.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const metal = (c, r = 0.35, m = 0.85) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
// half lathe about the x axis: keeps the far (z<0) half so the camera on +z sees inside
function lathe(pts, mat, half = true) {
  const g = new THREE.LatheGeometry(pts.map(([x, r]) => new THREE.Vector2(r, x)), 64, half ? Math.PI / 2 : 0, half ? Math.PI : Math.PI * 2);
  g.rotateZ(-Math.PI / 2); // lathe y-axis -> x-axis
  const m = new THREE.Mesh(g, mat); return m;
}
// a bladed rotor: n blades between r0 and r1, chord c, twist; spins about x
function rotor(n, r0, r1, chord, mat, twist = 0.6, thick = 0.012) {
  const g = new THREE.Group();
  const bg = new THREE.BoxGeometry(thick, r1 - r0, chord); bg.translate(0, (r0 + r1) / 2, 0);
  for (let i = 0; i < n; i++) { const b = new THREE.Mesh(bg, mat); const p = new THREE.Group(); p.rotation.x = (i / n) * Math.PI * 2; b.rotation.y = twist; p.add(b); g.add(p); }
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(r0, r0, chord * 0.9, 32), mat); hub.rotation.z = Math.PI / 2; g.add(hub);
  return g;
}
export const X = { fan: 2.3, cmpA: 1.55, cmpB: 0.25, comb0: 0.1, comb1: -0.75, turA: -0.95, turB: -1.85, nozzle: -2.9 };
export function turbofan() {
  const G = new THREE.Group();
  const white = new THREE.MeshStandardMaterial({ color: 0xe9edf2, roughness: 0.45, metalness: 0.2, side: THREE.DoubleSide });
  const inner = new THREE.MeshStandardMaterial({ color: 0x6f7c8c, roughness: 0.5, metalness: 0.6, side: THREE.DoubleSide });
  const core = new THREE.MeshStandardMaterial({ color: 0x9aa6b4, roughness: 0.4, metalness: 0.7, side: THREE.DoubleSide });
  // nacelle (outer shell) and its inner wall
  const nac = lathe([[2.9, 1.42], [2.6, 1.5], [1.6, 1.5], [0.2, 1.42], [-0.9, 1.28], [-1.1, 1.24]], white);
  const nacIn = lathe([[2.9, 1.36], [2.6, 1.38], [1.6, 1.38], [0.2, 1.32], [-0.9, 1.2], [-1.1, 1.18]], inner);
  G.add(nac, nacIn);
  // core casing
  const cc = lathe([[1.7, 0.86], [0.4, 0.84], [-0.9, 0.82], [-2.1, 0.74], [-2.8, 0.58]], core);
  G.add(cc);
  // spinner + exhaust plug + shaft
  const spin = new THREE.Mesh(new THREE.ConeGeometry(0.42, 0.75, 32), metal(0x2a2e34, 0.3, 0.6)); spin.rotation.z = -Math.PI / 2; spin.position.x = X.fan + 0.42; G.add(spin);
  const plug = new THREE.Mesh(new THREE.ConeGeometry(0.34, 1.2, 32), metal(0x4a4038, 0.4, 0.7)); plug.rotation.z = Math.PI / 2; plug.position.x = -2.55; G.add(plug);
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 4.6, 16), metal(0xc9a24a, 0.25, 0.9)); shaft.rotation.z = Math.PI / 2; shaft.position.x = 0.1; G.add(shaft);
  // fan
  const fanM = metal(0x3b4250, 0.35, 0.8);
  const fan = rotor(22, 0.3, 1.34, 0.32, fanM, 0.75, 0.02); fan.position.x = X.fan; G.add(fan);
  // compressor stages: radius shrinks as the air is squeezed
  const cmpM = metal(0xb8c2cf, 0.3, 0.9); const comps = [];
  for (let k = 0; k < 9; k++) { const f = k / 8; const r1 = 0.8 - 0.3 * f; const R = rotor(28, 0.22, r1, 0.08, cmpM, 0.5); R.position.x = X.cmpA - f * (X.cmpA - X.cmpB); G.add(R); comps.push(R); }
  // combustor: glowing ring + flame tongues (emissive, driven by .burn)
  const flameM = new THREE.MeshStandardMaterial({ color: 0xff7a1a, emissive: 0xff5a00, emissiveIntensity: 0, transparent: true, opacity: 0.9, side: THREE.DoubleSide, toneMapped: false });
  const comb = lathe([[X.comb0, 0.62], [X.comb1, 0.62]], new THREE.MeshStandardMaterial({ color: 0x6a5446, roughness: 0.6, metalness: 0.5, side: THREE.DoubleSide }));
  const combIn = lathe([[X.comb0, 0.3], [X.comb1, 0.3]], new THREE.MeshStandardMaterial({ color: 0x6a5446, roughness: 0.6, metalness: 0.5, side: THREE.DoubleSide }));
  G.add(comb, combIn);
  const flames = []; const R = rnd(9);
  for (let i = 0; i < 14; i++) { const a = Math.PI / 2 + (i + 0.5) / 14 * Math.PI; const f = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.6, 10), flameM); f.rotation.z = Math.PI / 2; f.position.set(X.comb0 - 0.38, Math.sin(a) * 0.46 * -1, Math.cos(a) * 0.46); f.userData.s = R(); G.add(f); flames.push(f); }
  // fuel nozzles (small cylinders at combustor front)
  const nz = []; for (let i = 0; i < 14; i++) { const a = Math.PI / 2 + (i + 0.5) / 14 * Math.PI; const n = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.12, 8), metal(0xd0b070)); n.rotation.z = Math.PI / 2; n.position.set(X.comb0 + 0.02, -Math.sin(a) * 0.46, Math.cos(a) * 0.46); G.add(n); nz.push(n); }
  // turbine stages (hot metal)
  const turM = new THREE.MeshStandardMaterial({ color: 0xb07a50, roughness: 0.35, metalness: 0.85, emissive: 0xff3a00, emissiveIntensity: 0 });
  const turs = []; for (let k = 0; k < 4; k++) { const f = k / 3; const T = rotor(34, 0.25, 0.62 + 0.1 * f, 0.1, turM, -0.5); T.position.x = X.turA - f * (X.turA - X.turB); G.add(T); turs.push(T); }
  // highlight shells (one per section) for the hook
  const hiM = new THREE.MeshBasicMaterial({ color: 0xffd21a, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, toneMapped: false });
  const hi = {
    fan: lathe([[X.fan + 0.25, 1.33], [X.fan - 0.25, 1.33]], hiM.clone()),
    cmp: lathe([[X.cmpA + 0.1, 0.83], [X.cmpB - 0.1, 0.83]], hiM.clone()),
    comb: lathe([[X.comb0, 0.66], [X.comb1, 0.66]], hiM.clone()),
    tur: lathe([[X.turA + 0.1, 0.78], [-2.85, 0.6]], hiM.clone()),
  };
  Object.values(hi).forEach(m => G.add(m));
  const st = { spin: 0, burn: 0, hot: 0, hi: { fan: 0, cmp: 0, comb: 0, tur: 0 } };
  function update(T) {
    fan.rotation.x = st.spin * 1.0; comps.forEach((c, k) => { c.rotation.x = st.spin * (2.2 + k * 0.05) * (k % 2 ? 1 : -1) * 0.5 + st.spin; }); turs.forEach((t, k) => { t.rotation.x = st.spin * 1.6 * (k % 2 ? -1 : 1); });
    flameM.emissiveIntensity = 3.5 * st.burn; flameM.opacity = 0.9 * Math.min(1, st.burn * 2);
    flames.forEach((f) => { f.visible = st.burn > 0.02; f.scale.set(1, 0.6 + 0.4 * st.burn + 0.15 * Math.sin(T * 30 + f.userData.s * 20), 1); });
    turM.emissiveIntensity = 0.6 * st.hot;
    Object.entries(hi).forEach(([k, m]) => { m.material.opacity = 0.55 * st.hi[k]; m.renderOrder = 25; m.visible = st.hi[k] > 0.01; });
  }
  update(0);
  return { group: G, st, update, fan, flames };
}

// air particles: bypass (outer ring) and core streams. pos along x from +3.6 to -4.2; core radius narrows through the compressor.
export function airflow({ n = 420, seed = 5 } = {}) {
  const R = rnd(seed); const P = [];
  for (let i = 0; i < n; i++) P.push({ core: i % 4 === 0, ph: R(), a: Math.PI / 2 + R() * Math.PI, rj: R(), v: 0.8 + R() * 0.4 });
  const geo = new THREE.SphereGeometry(0.035, 8, 6);
  const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, transparent: true });
  const im = new THREE.InstancedMesh(geo, mat, n); im.frustumCulled = false;
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3(), c = new THREE.Color();
  const st = { bypass: 0, core: 0, speed: 1, half: true };
  const cold = new THREE.Color(0x6ec8ff), warm = new THREE.Color(0xffe08a), hot = new THREE.Color(0xff4a1a);
  function coreR(x) { if (x > 1.6) return 0.62; if (x > 0.25) return 0.62 - (1.6 - x) / 1.35 * 0.2; if (x > -0.8) return 0.46; if (x > -1.9) return 0.46 + (-0.8 - x) / 1.1 * 0.06; return 0.52 - Math.min(0.2, (-1.9 - x) * 0.15); }
  function update(T) {
    P.forEach((o, i) => {
      const on = o.core ? st.core : st.bypass;
      const span = 7.8; const x = 3.6 - (((o.ph + T * 0.22 * o.v * st.speed) % 1 + 1) % 1) * span;
      let r, col, sc = 1;
      if (o.core) {
        r = coreR(x) * (0.55 + 0.45 * o.rj) + 0.05;
        const heat = x < X.comb0 ? Math.min(1, (X.comb0 - x) / 0.5) : 0; const sq = x < 1.6 ? Math.min(1, (1.6 - x) / 1.35) : 0;
        col = c.copy(cold).lerp(warm, sq * 0.5).lerp(hot, heat); sc = 1 + sq * 0.2 + heat * 0.5;
      } else { r = 0.98 + 0.32 * o.rj; col = c.copy(cold); if (x < -1.1) r += (-1.1 - x) * 0.05; }
      if (x > 2.9) r = r * 1.05 + (x - 2.9) * 0.4 * (o.core ? 0.2 : 0.3);
      p.set(x, -Math.sin(o.a) * r, Math.cos(o.a) * r);
      const vis = on > 0.01 && (!st.half || p.z <= 0.02);
      s.setScalar(vis ? sc * Math.min(1, on * 1.5) : 0.0001);
      M.compose(p, q, s); im.setMatrixAt(i, M); im.setColorAt(i, col);
    });
    im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true;
  }
  update(0);
  return { mesh: im, st, update };
}

// simple airliner: fuselage along x (nose +x), low wings with two engines
export function airliner() {
  const g = new THREE.Group();
  const body = new THREE.MeshStandardMaterial({ color: 0xf2f4f7, roughness: 0.35, metalness: 0.2 });
  const blue = new THREE.MeshStandardMaterial({ color: 0x1f4fa8, roughness: 0.4, metalness: 0.2 });
  const fus = new THREE.Mesh(new THREE.CapsuleGeometry(1.9, 26, 12, 32), body); fus.rotation.z = Math.PI / 2; g.add(fus);
  const belly = new THREE.Mesh(new THREE.CapsuleGeometry(1.92, 25.8, 12, 32, ), blue); belly.rotation.z = Math.PI / 2; belly.scale.set(1, 1, 1); belly.position.y = -0.02; belly.visible = false; g.add(belly);
  const stripe = new THREE.Mesh(new THREE.CylinderGeometry(1.93, 1.93, 24, 32, 1, true, 0, Math.PI * 2), blue); stripe.rotation.z = Math.PI / 2; stripe.scale.set(1, 1, 1); stripe.position.y = 0; g.add(stripe); stripe.scale.z = 1; stripe.visible = false;
  // windows
  const winM = new THREE.MeshStandardMaterial({ color: 0x1a2430, roughness: 0.2 });
  for (let k = 0; k < 30; k++) [-1, 1].forEach(s => { const w = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.36, 0.05), winM); w.position.set(10 - k * 0.7, 0.55, s * 1.88); g.add(w); });
  const cock = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.35, 2.2), winM); cock.position.set(14.2, 0.9, 0); cock.rotation.z = -0.4; g.add(cock);
  // wings (swept boxes)
  [-1, 1].forEach(s => {
    const w = new THREE.Mesh(new THREE.BoxGeometry(5, 0.35, 17), body); w.position.set(-0.5 - 2.5, -1.1, s * 9.5); w.rotation.y = s * 0.45; g.add(w);
    const t = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.2, 6), body); t.position.set(-13.5, 0.6, s * 3.5); t.rotation.y = s * 0.5; g.add(t);
    // engine pod under each wing
    const pod = new THREE.Group(); const sh = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 0.9, 4.2, 32, 1, true), body); sh.rotation.z = Math.PI / 2; pod.add(sh);
    const shIn = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 0.85, 4.2, 32, 1, true), new THREE.MeshStandardMaterial({ color: 0x2a2e34, side: THREE.BackSide })); shIn.rotation.z = Math.PI / 2; pod.add(shIn);
    const fan = rotor(20, 0.25, 1.02, 0.2, metal(0x3b4250), 0.75, 0.03); fan.position.x = 1.6; pod.add(fan); pod.userData.fan = fan;
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.6, 24), metal(0x2a2e34)); cone.rotation.z = -Math.PI / 2; cone.position.x = 1.85; pod.add(cone);
    const pyl = new THREE.Mesh(new THREE.BoxGeometry(2.5, 1.2, 0.3), body); pyl.position.set(-0.2, 1.1, 0); pod.add(pyl);
    pod.position.set(1.6, -2.6, s * 6.2); g.add(pod); (g.userData.pods ||= []).push(pod);
  });
  const fin = new THREE.Mesh(new THREE.BoxGeometry(4, 6, 0.3), blue); fin.position.set(-13.2, 4, 0); fin.rotation.z = 0.5; g.add(fin);
  return g;
}

// heat shimmer / exhaust jet: a translucent cone behind a pod
export function exhaust(len = 8, r = 0.9) {
  const m = new THREE.MeshBasicMaterial({ color: 0xffc89a, transparent: true, opacity: 0.12, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  const c = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 1.8, len, 32, 1, true), m); c.rotation.z = Math.PI / 2; c.position.x = -len / 2; const g = new THREE.Group(); g.add(c); return { group: g, mat: m };
}

// one turbine blade, big, with cooling holes: cool air dots stream out of the holes
export function coolBlade() {
  const g = new THREE.Group();
  const sh = new THREE.Shape(); sh.moveTo(-0.5, 0); sh.bezierCurveTo(-0.3, 0.28, 0.3, 0.25, 0.5, 0.02); sh.bezierCurveTo(0.2, 0.12, -0.2, 0.12, -0.5, 0);
  const geo = new THREE.ExtrudeGeometry(sh, { depth: 2.2, bevelEnabled: true, bevelSize: 0.02, bevelThickness: 0.02, curveSegments: 24 }); geo.rotateX(-Math.PI / 2); geo.translate(0, 0, 0);
  const mat = new THREE.MeshStandardMaterial({ color: 0xc89060, roughness: 0.35, metalness: 0.8, emissive: 0xff3a00, emissiveIntensity: 0.25 });
  const b = new THREE.Mesh(geo, mat); g.add(b);
  const root = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.35, 0.6), metal(0x9a8a7a)); root.position.y = -0.15; g.add(root);
  // holes: dark dots on the front face in rows
  const holes = []; const hm = new THREE.MeshBasicMaterial({ color: 0x140a06 });
  for (let r = 0; r < 7; r++) for (let k = 0; k < 4; k++) { const h = new THREE.Mesh(new THREE.CircleGeometry(0.03, 12), hm); const x = -0.3 + k * 0.18; h.position.set(x, 0.3 + r * 0.26, -0.09 * (1 - (2 * x) ** 2) + 0.012); g.add(h); holes.push(h.position.clone()); }
  return { group: g, holes, mat };
}
