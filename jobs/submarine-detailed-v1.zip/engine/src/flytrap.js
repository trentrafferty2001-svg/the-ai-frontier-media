// The Explainer: how a Venus flytrap snaps shut. Trap of two hinged lobes (hinge along x at the origin, lobes rise
// in +y and open toward +z / -z). Lobe curvature c: + bulges outward (open, under tension), - curves inward (closed).
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.6, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
const NU = 24, NV = 14;
function lobeShape(u, v, c) { // u -1..1 across, v 0..1 from hinge to rim
  const w = Math.sqrt(Math.max(0, 1 - Math.pow(v * 0.92, 2)));
  return new THREE.Vector3(u * 1.0 * (0.25 + 0.75 * w), v * 1.05, c * (1 - u * u) * Math.sin(Math.PI * v * 0.9) * 0.45);
}
function lobe(side, seed) {
  const G = new THREE.Group();
  const geo = new THREE.PlaneGeometry(1, 1, NU, NV); const pos = geo.attributes.position;
  const inner = new THREE.MeshStandardMaterial({ color: 0xc8303a, roughness: 0.45, side: THREE.BackSide, emissive: 0x3a8aff, emissiveIntensity: 0 });
  const outer = new THREE.MeshStandardMaterial({ color: 0x5ea83a, roughness: 0.6, side: THREE.FrontSide });
  const mi = new THREE.Mesh(geo, inner), mo = new THREE.Mesh(geo, outer); G.add(mi, mo);
  // teeth along the rim + trigger hairs on the inner face
  const tm = std(0x8ad04a, 0.5); const teeth = []; for (let k = 0; k < 15; k++) { const t = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.42, 6), tm); G.add(t); teeth.push({ t, u: -0.92 + k / 14 * 1.84 }); }
  const hm = std(0xffe0a0, 0.4, 0, { emissive: 0xffc040, emissiveIntensity: 0 }); const hairs = [[-0.32, 0.45], [0.3, 0.42], [0.0, 0.66]].map(([u, v]) => { const h = new THREE.Mesh(new THREE.ConeGeometry(0.018, 0.2, 6), hm); h.geometry.translate(0, 0.1, 0); G.add(h); return { h, u, v }; });
  function shape(c) {
    for (let j = 0; j <= NV; j++) for (let i = 0; i <= NU; i++) { const u = -1 + 2 * i / NU, v = j / NV; const p = lobeShape(u, v, c); pos.setXYZ(j * (NU + 1) + i, p.x, p.y, p.z * side); }
    pos.needsUpdate = true; geo.computeVertexNormals();
    teeth.forEach(({ t, u }) => { const v = Math.sqrt(Math.max(0, 1 - u * u)) * 0.98; const p = lobeShape(u, Math.min(1, v), c); const vv = Math.min(1, v); const yy = vv * 1.05; const dir = new THREE.Vector3(p.x, yy - 0.25, 0).normalize(); t.position.set(p.x, yy, p.z * side).addScaledVector(dir, 0.18); t.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir); });
    hairs.forEach(({ h, u, v }) => { const p = lobeShape(u, v, c); h.position.set(p.x, p.y, p.z * side); h.rotation.set(-side * 1.3, 0, 0); });
  }
  shape(0.6);
  return { group: G, shape, inner, hairs, hm };
}
// trap: two lobes. set(open 0..1 (1 = wide open), curve -1..1, glow, hairGlow)
export function trap(seed = 1) {
  const G = new THREE.Group(); const A = lobe(1, seed), B = lobe(-1, seed + 1); G.add(A.group, B.group);
  const rib = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.9, 10), std(0x4f9a3a, 0.6)); rib.rotation.z = Math.PI / 2; G.add(rib);
  function set(open, curve, glow = 0, hairGlow = 0) {
    const a = 0.08 + open * 0.62; A.group.rotation.x = a; B.group.rotation.x = -a; A.shape(curve); B.shape(curve);
    [A, B].forEach(L => { L.inner.emissiveIntensity = 1.2 * glow; L.hm.emissiveIntensity = 1.5 * hairGlow; });
  }
  set(1, 0.6);
  return { group: G, set, A, B };
}
// plant: pot, soil, moss, several traps on petioles; returns the hero trap (index 0)
export function plant() {
  const G = new THREE.Group();
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.2, 1.4, 32), std(0xb0603a, 0.7)); pot.position.y = -0.7; G.add(pot);
  const soil = new THREE.Mesh(new THREE.CylinderGeometry(1.55, 1.55, 0.06, 32), std(0x3a2a1a, 1)); G.add(soil);
  const R = rnd(3); for (let k = 0; k < 40; k++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.12 + R() * 0.08, 8, 6), std(0x5a8a2a, 1)); const a = R() * 6.28, r = R() * 1.4; m.position.set(Math.cos(a) * r, 0.03, Math.sin(a) * r); m.scale.y = 0.4; G.add(m); }
  const traps = [];
  for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2 + 0.3; const T = trap(10 + k); const s = k === 0 ? 0.55 : 0.22 + R() * 0.06; T.group.scale.setScalar(s); const r = k === 0 ? 0.0 : 1.3; T.group.position.set(Math.cos(a) * r, k === 0 ? 0.9 : 0.25 + R() * 0.15, Math.sin(a) * r - (k === 0 ? 0 : 0.4)); T.group.rotation.y = k === 0 ? 0 : -a + Math.PI / 2; T.set(1, 0.6); G.add(T.group); traps.push(T);
    const pet = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.05, 1, 8), std(0x5ea83a, 0.6)); const top = T.group.position.clone(); pet.scale.y = top.length(); pet.position.copy(top).multiplyScalar(0.5); pet.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), top.clone().normalize()); G.add(pet); }
  return { group: G, traps };
}
// fly
export function fly() { const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.SphereGeometry(0.06, 14, 10), std(0x202428, 0.4, 0.3)); b.scale.set(1.5, 0.8, 0.8); g.add(b); const h = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 8), std(0x202428, 0.4)); h.position.x = 0.09; g.add(h); [-1, 1].forEach(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.025, 10, 8), std(0x8a1a1a, 0.3)); e.position.set(0.11, 0.015, s * 0.025); g.add(e); const w = new THREE.Mesh(new THREE.CircleGeometry(0.07, 12), new THREE.MeshPhysicalMaterial({ color: 0xdfefff, transparent: true, opacity: 0.5, side: THREE.DoubleSide })); w.scale.set(1.2, 0.5, 1); w.rotation.x = -Math.PI / 2; w.position.set(-0.03, 0.05, s * 0.06); w.userData.s = s; g.add(w); }); return g; }
// popper toy: a rubber dome that flips inside out
export function popper() { const g = new THREE.Group(); const geo = new THREE.SphereGeometry(0.5, 32, 12, 0, Math.PI * 2, 0, Math.PI / 2.6); const m = new THREE.Mesh(geo, std(0xff6a2a, 0.4, 0, { side: THREE.DoubleSide })); g.add(m); return { group: g, set(f) { m.scale.y = 1 - 2 * f; m.position.y = f * 0.5 * 0.45; } }; }
export { std };
