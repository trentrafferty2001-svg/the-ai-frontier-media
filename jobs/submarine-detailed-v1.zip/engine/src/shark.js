// The Explainer: how sharks sense electricity. Shark (head +x, ~3 long), hammerhead variant, flatfish in sand,
// electric field rings, snout pores, ampulla cutaway, magnetic field lines.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.5, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
function tri(a, b, c, mat) { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute([...a, ...b, ...c, ...a, ...c, ...b], 3)); g.computeVertexNormals(); return new THREE.Mesh(g, mat); }
export function shark({ hammer = false } = {}) {
  const G = new THREE.Group(); const body = new THREE.Group(); G.add(body);
  const top = std(0x6f7c8a, 0.5), belly = std(0xe6e8ea, 0.6);
  // body: lathe along x (nose +x)
  const prof = []; for (let i = 0; i <= 30; i++) { const u = i / 30; const r = 0.42 * Math.pow(Math.sin(Math.PI * Math.min(1, u * 1.05)), 0.8) * (u < 0.15 ? Math.pow(u / 0.15, 0.6) : 1) * (1 - 0.65 * Math.max(0, u - 0.6) / 0.4); prof.push(new THREE.Vector2(Math.max(0.005, r), -1.5 + u * 3)); }
  const bg = new THREE.LatheGeometry(prof, 40); bg.rotateZ(Math.PI / 2); bg.scale(1, 0.85, 1);
  // colour: countershading via vertex colours
  const col = []; const pa = bg.attributes.position; const c = new THREE.Color(); for (let i = 0; i < pa.count; i++) { c.copy(top.color).lerp(belly.color, THREE.MathUtils.smoothstep(-pa.getY(i), -0.05, 0.12)); col.push(c.r, c.g, c.b); }
  bg.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  const bodyMesh = new THREE.Mesh(bg, std(0xffffff, 0.5, 0, { vertexColors: true })); body.add(bodyMesh); // nose at +x
  const finM = std(0x66727f, 0.5, 0, { side: THREE.DoubleSide });
  body.add(tri([0.2, 0.3, 0], [-0.3, 0.3, 0], [-0.15, 0.95, 0], finM)); // dorsal
  [-1, 1].forEach(s => body.add(tri([0.55, -0.2, s * 0.25], [0.15, -0.22, s * 0.3], [0.0, -0.45, s * 0.95], finM))); // pectorals
  const tail = new THREE.Group(); tail.position.x = -1.45; body.add(tail);
  tail.add(tri([0.05, 0.02, 0], [-0.25, 0.05, 0], [-0.65, 0.75, 0], finM)); tail.add(tri([0.05, -0.02, 0], [-0.25, -0.02, 0], [-0.45, -0.45, 0], finM));
  // eyes, gills
  [-1, 1].forEach(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 8), std(0x080808, 0.1)); e.position.set(1.12, 0.1, s * 0.2); body.add(e); for (let k = 0; k < 5; k++) { const g = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.16, 0.01), std(0x3a4450)); g.position.set(0.72 - k * 0.07, 0.0, s * 0.355); g.rotation.z = 0.2; body.add(g); } });
  // pores (ampullae openings) on the snout
  const poreM = new THREE.MeshBasicMaterial({ color: 0x14181c }); const pores = []; const R = rnd(5);
  const rAt = (x) => { const u = (1.5 - x) / 3; return 0.42 * Math.pow(Math.sin(Math.PI * Math.min(1, u * 1.05)), 0.8) * (u < 0.15 ? Math.pow(u / 0.15, 0.6) : 1); };
  for (let i = 0; i < 120; i++) { const u = R(), a = R() * Math.PI * 2; const x = 1.02 + u * 0.4; const rr = rAt(x) * 1.01; const p = new THREE.Mesh(new THREE.CircleGeometry(0.011, 6), poreM); p.position.set(x, Math.sin(a) * rr * 0.85, Math.cos(a) * rr); p.lookAt(new THREE.Vector3(x + 0.15, Math.sin(a) * rr * 0.85 * 3, Math.cos(a) * rr * 3)); body.add(p); pores.push(p); }
  // hammerhead: a wide flat head blade with eyes at the tips and pores along it
  let blade = null; if (hammer) { blade = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.08, 1.4), std(0x6f7c8a, 0.5)); blade.geometry.translate(0, 0, 0); blade.position.set(1.32, 0.02, 0); body.add(blade); [-1, 1].forEach(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.045, 10, 8), std(0x080808, 0.1)); e.position.set(1.32, 0.04, s * 0.72); body.add(e); }); for (let i = 0; i < 60; i++) { const p = new THREE.Mesh(new THREE.CircleGeometry(0.011, 6), poreM); p.position.set(1.32 + (R() - 0.5) * 0.3, -0.042, (R() - 0.5) * 1.35); p.rotation.x = Math.PI / 2; body.add(p); pores.push(p); } }
  const glowM = new THREE.MeshBasicMaterial({ color: 0x7ff0ff, transparent: true, opacity: 0, toneMapped: false, blending: THREE.AdditiveBlending, depthWrite: false });
  const glow = new THREE.Mesh(new THREE.SphereGeometry(0.3, 24, 16), glowM); glow.scale.set(hammer ? 0.8 : 1.1, 0.75, hammer ? 2.6 : 0.95); glow.position.x = hammer ? 1.32 : 1.28; body.add(glow);
  const st = { swim: 0, sense: 0 };
  function update(T) { tail.rotation.y = 0.35 * Math.sin(st.swim * 6); body.rotation.y = 0.06 * Math.sin(st.swim * 6 - 1); glowM.opacity = 0.35 * st.sense * (0.6 + 0.4 * Math.sin(T * 9)); }
  update(0);
  return { group: G, body, st, update };
}
// flatfish lying in sand (mostly buried): oval body + eyes; heart glow
export function flatfish() {
  const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.SphereGeometry(0.35, 24, 12), std(0xcdb48c, 0.95)); b.scale.set(1, 0.12, 0.7); b.position.y = -0.02; g.add(b);
  [-1, 1].forEach(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), std(0x101010, 0.2)); e.position.set(0.15, 0.06, s * 0.05); g.add(e); });
  const heart = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 8), new THREE.MeshBasicMaterial({ color: 0xff4a3a, toneMapped: false, transparent: true, opacity: 0 })); heart.position.set(0.05, 0.08, 0); g.add(heart);
  return { group: g, heart };
}
// electric field: concentric rings expanding from a point (flat on the ground or upright)
export function fieldRings(n = 5, max = 2.2) {
  const g = new THREE.Group(); const rings = [];
  for (let i = 0; i < n; i++) { const m = new THREE.Mesh(new THREE.TorusGeometry(1, 0.012, 6, 64), new THREE.MeshBasicMaterial({ color: 0xffe14a, transparent: true, opacity: 0, toneMapped: false, depthWrite: false })); m.rotation.x = Math.PI / 2; g.add(m); rings.push(m); }
  return { group: g, set(T, k) { rings.forEach((m, i) => { const u = ((T * 0.6 + i / n) % 1); const r = 0.15 + u * max; m.scale.set(r, r, 1); m.material.opacity = k * 0.8 * (1 - u); m.visible = k > 0.01; }); } };
}
// ampulla cutaway: skin slab with a pore, jelly-filled canal running down to a bulb with sensor cells, and a nerve
export function ampulla() {
  const G = new THREE.Group();
  const skin = new THREE.Mesh(new THREE.BoxGeometry(5, 0.35, 2), std(0x6f7c8a, 0.6)); skin.position.y = 2.0; G.add(skin);
  const flesh = new THREE.Mesh(new THREE.BoxGeometry(5, 3.6, 2), std(0xd8a8a0, 0.8, 0, { transparent: true, opacity: 0.3, depthWrite: false })); flesh.position.y = 0.0; G.add(flesh);
  const pts = [new THREE.Vector3(0, 2.2, 0.6), new THREE.Vector3(0.2, 1.2, 0.6), new THREE.Vector3(-0.4, 0.2, 0.6), new THREE.Vector3(-0.1, -0.9, 0.6)];
  const curve = new THREE.CatmullRomCurve3(pts);
  const canal = new THREE.Mesh(new THREE.TubeGeometry(curve, 60, 0.16, 16), new THREE.MeshPhysicalMaterial({ color: 0xbfe8ff, roughness: 0.1, transmission: 0.6, transparent: true, opacity: 0.6 })); G.add(canal);
  const jellyM = new THREE.MeshStandardMaterial({ color: 0x9ae6ff, emissive: 0x2aa8ff, emissiveIntensity: 0, transparent: true, opacity: 0.85 });
  const jelly = new THREE.Mesh(new THREE.TubeGeometry(curve, 60, 0.11, 12), jellyM); G.add(jelly);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.42, 24, 16), std(0xf0c8a8, 0.5, 0, { emissive: 0xff8a40, emissiveIntensity: 0 })); bulb.position.set(-0.1, -1.2, 0.6); G.add(bulb);
  const cells = []; for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2; const cc = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), std(0xffe14a, 0.4, 0, { emissive: 0xffc020, emissiveIntensity: 0 })); cc.position.set(-0.1 + Math.cos(a) * 0.36, -1.2 + Math.sin(a) * 0.36, 0.72); G.add(cc); cells.push(cc); }
  const nerve = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(-0.1, -1.6, 0.6), new THREE.Vector3(0.6, -2.0, 0.6), new THREE.Vector3(2.4, -2.2, 0.6)]), 40, 0.06, 8), std(0xf2e8c8, 0.5)); G.add(nerve);
  const pulse = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 8), new THREE.MeshBasicMaterial({ color: 0xfff2a0, toneMapped: false })); G.add(pulse);
  const pore = new THREE.Mesh(new THREE.CircleGeometry(0.16, 20), new THREE.MeshBasicMaterial({ color: 0x0a0c10 })); pore.rotation.x = -Math.PI / 2; pore.position.set(0, 2.18, 0.6); G.add(pore);
  const nervePath = new THREE.CatmullRomCurve3([new THREE.Vector3(-0.1, -1.6, 0.6), new THREE.Vector3(0.6, -2.0, 0.6), new THREE.Vector3(2.4, -2.2, 0.6)]);
  return { group: G, set(T, jel, sig) { jellyM.emissiveIntensity = 1.2 * jel; bulb.material.emissiveIntensity = 0.6 * sig; cells.forEach((c, i) => { c.material.emissiveIntensity = sig * (0.6 + 0.4 * Math.sin(T * 10 + i)); }); const u = (T * 1.2) % 1; pulse.position.copy(nervePath.getPoint(u)); pulse.visible = sig > 0.05; } };
}
// Earth's magnetic field: big curved glowing lines
export function magLines() {
  const g = new THREE.Group(); const m = new THREE.MeshBasicMaterial({ color: 0x8adfff, transparent: true, opacity: 0, toneMapped: false, depthWrite: false });
  for (let k = 0; k < 6; k++) { const pts = []; for (let i = 0; i <= 40; i++) { const u = i / 40; pts.push(new THREE.Vector3(-20 + u * 40, 2 + k * 1.2 + Math.sin(u * Math.PI) * (2 + k * 0.6), -6 - k * 1.5)); } const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 80, 0.03, 6), m); g.add(tube); }
  return { group: g, mat: m };
}
export { std };
