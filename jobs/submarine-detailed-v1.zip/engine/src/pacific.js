// Polynesian wayfinding reel: double-hulled voyaging canoe with crab-claw sails, Polynesian navigators, star sky +
// 32-point star compass ring, tropical islands (volcanic, green hills, Rapa Nui with moai), cumulus clouds, beach crowd.
import * as THREE from 'three';
import { SKY_PRESETS, mountains } from './world.js';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { palm } from './persia.js';
import { glowSprite } from './props.js';

SKY_PRESETS.tropic = { zenith: 0x1e6ad8, horizon: 0xbfe2f2, ground: 0x4a7a6a, sunColor: 0xfff4e0, cloud: 0.4, haze: 0xb4d8ea, sunI: 4.2 };
SKY_PRESETS.pnight = { zenith: 0x040818, horizon: 0x1a2a52, ground: 0x0c1018, sunColor: 0xa8bcff, cloud: 0.05, haze: 0x101a36, sunI: 0.8 };

export function canoe() {
  const g = new THREE.Group();
  const wood = new THREE.MeshStandardMaterial({ color: 0x6a3e22, roughness: 0.75, bumpMap: fabricTexture(5), bumpScale: 2 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x2a1a10, roughness: 0.8 });
  const hulls = [];
  for (const s of [-1, 1]) {
    // hull: lathe-like spindle, tips curve up
    const pts = []; for (let i = 0; i <= 24; i++) { const u = i / 24, x = (u - 0.5) * 18; pts.push(new THREE.Vector3(x, 0.15 + 0.9 * Math.pow(Math.abs(2 * u - 1), 4), 0)); }
    const curve = new THREE.CatmullRomCurve3(pts);
    const geo = new THREE.TubeGeometry(curve, 60, 0.55, 14);
    const p = geo.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i); const k = Math.max(0.25, 1 - Math.pow(Math.abs(x) / 9.4, 2.2)); p.setZ(i, s * 1.8 + (p.getZ(i) - s * 0) * k * 0.9); p.setY(i, 0.15 + (p.getY(i) - 0.15) * k); }
    geo.computeVertexNormals();
    const h = new THREE.Mesh(geo, wood); h.position.z = 0; g.add(h); hulls.push(h);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(14, 0.08, 0.06), dark); stripe.position.set(0, 0.5, s * 2.22); g.add(stripe);
  }
  // deck platform + cross beams + small hut
  for (let i = 0; i < 7; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.18, 4.6), wood); b.position.set(-6 + i * 2, 0.75, 0); g.add(b); }
  const deck = new THREE.Mesh(new THREE.BoxGeometry(9, 0.12, 4.4), new THREE.MeshStandardMaterial({ color: 0x8a6a42, roughness: 0.9, bumpMap: fabricTexture(9), bumpScale: 2 })); deck.position.y = 0.89; g.add(deck);
  const hut = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 1.1, 1.0, 4), new THREE.MeshStandardMaterial({ color: 0xb89a5a, roughness: 1 })); hut.rotation.y = Math.PI / 4; hut.scale.set(1.4, 1, 1); hut.position.set(-1.5, 1.4, 0); g.add(hut);
  // two crab-claw sails (curved triangles) on masts
  const sailMat = new THREE.MeshStandardMaterial({ color: 0xe8d8b0, roughness: 0.9, side: THREE.DoubleSide, bumpMap: fabricTexture(17), bumpScale: 1.5 });
  const sails = [];
  for (const [x, z] of [[2.2, -1.2], [-3.4, 1.2]]) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 6, 8), wood); m.position.set(x, 3.8, z); m.rotation.z = 0.1; g.add(m);
    const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.quadraticCurveTo(-1.2, 3.2, -0.6, 6.4); sh.quadraticCurveTo(1.0, 4.8, 3.2, 5.6); sh.quadraticCurveTo(1.4, 2.4, 0, 0);
    const sg = new THREE.ShapeGeometry(sh, 16); const sp = sg.attributes.position; for (let i = 0; i < sp.count; i++) { const x0 = sp.getX(i), y0 = sp.getY(i); sp.setZ(i, 0.5 * Math.sin(Math.PI * Math.min(1, y0 / 6.4)) * (0.5 + x0 / 6)); } sg.computeVertexNormals();
    const s = new THREE.Mesh(sg, sailMat); s.position.set(x, 1.0, z); s.rotation.y = Math.PI / 2 + 0.2; g.add(s); sails.push(s);
  }
  g.sails = sails;
  return shadowAll(g);
}
// Polynesian navigator: wrap (pareu) in a bold colour, darker skin, hair bun, shell necklace
export function polynesian(i = 0, { kid = false } = {}) {
  const cols = [0xb8342a, 0x2a6a8a, 0xd89a2a, 0x3a7a4a, 0x7a2a5a];
  const h = romanBuilder({ color: cols[i % cols.length], skin: [0x8a5a3a, 0x9a643e, 0x7a4e32][i % 3] });
  const bun = new THREE.Mesh(new THREE.SphereGeometry(0.07, 14, 10), new THREE.MeshStandardMaterial({ color: 0x1a1210, roughness: 0.8 })); bun.position.set(0, 0.12, -0.12); h.j.head.add(bun);
  const lei = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.025, 8, 24), new THREE.MeshStandardMaterial({ color: [0xf2efe6, 0xf2d24a, 0xe86a6a][i % 3], roughness: 0.6 })); lei.rotation.x = Math.PI / 2 - 0.3; lei.position.set(0, 0.33, 0.02); h.j.chest.add(lei);
  if (kid) h.root.scale.setScalar(0.75);
  return shadowAll(h.root), h;
}
// starry sky: points on a dome + a few bright named-style stars, rotating slowly
export function starSky(n = 1400, seed = 3) {
  const R = rng(seed); const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { const a = R() * Math.PI * 2, e = Math.asin(R()) * 0.98; pos.set([Math.cos(a) * Math.cos(e) * 240, Math.sin(e) * 240 + 2, Math.sin(a) * Math.cos(e) * 240], i * 3); const w = 0.7 + R() * 0.3; col.set([w, w, 1], i * 3); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ size: 3.2, sizeAttenuation: false, vertexColors: true, fog: false, transparent: true, depthWrite: false }));
  const g = new THREE.Group(); g.add(pts);
  const bright = [...Array(12)].map((_, i) => { const s = glowSprite(0xffffff, 1); s.material.fog = false; s.material.blending = THREE.AdditiveBlending; const a = i / 12 * Math.PI * 2 + 0.2; s.position.set(Math.cos(a) * 235, 6 + (i % 3) * 18, Math.sin(a) * 235); s.scale.setScalar(6 + (i % 3) * 2); g.add(s); return s; });
  g.bright = bright;
  return g;
}
// 32-point star compass ring around the canoe (glowing marks + spokes toward rising points)
export function starCompass(r = 14) {
  const g = new THREE.Group();
  const m = new THREE.MeshBasicMaterial({ color: 0xffd43b, transparent: true, opacity: 0, depthWrite: false, fog: false });
  const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.08, 6, 128), m); ring.rotation.x = Math.PI / 2; g.add(ring);
  const ticks = [];
  for (let i = 0; i < 32; i++) { const a = i / 32 * Math.PI * 2; const t = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, i % 8 === 0 ? 2.4 : i % 2 ? 0.8 : 1.4), m); t.position.set(Math.sin(a) * r, 0, Math.cos(a) * r); t.rotation.y = a; g.add(t); ticks.push(t); }
  const spokes = [];
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2 + 0.2; const s = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, r), m.clone()); s.position.set(Math.sin(a) * r / 2, 0, Math.cos(a) * r / 2); s.rotation.y = a; g.add(s); spokes.push(s); }
  g.set = (k) => { m.opacity = 0.9 * k; spokes.forEach((s, i) => s.material.opacity = 0.5 * Math.max(0, Math.min(1, k * 1.5 - i * 0.08))); };
  g.set(0);
  return g;
}
// islands
export function island({ kind = 'volcanic', s = 1, seed = 2 } = {}) {
  const g = new THREE.Group(); const R = rng(seed);
  const green = new THREE.MeshStandardMaterial({ color: kind === 'rapanui' ? 0x6a8a44 : 0x3f7a34, roughness: 1, flatShading: true });
  const rock = new THREE.MeshStandardMaterial({ color: 0x4a4440, roughness: 1, flatShading: true });
  const sand = new THREE.MeshStandardMaterial({ color: 0xf0e2b8, roughness: 1 });
  const lagoon = new THREE.Mesh(new THREE.CircleGeometry(22, 48), new THREE.MeshStandardMaterial({ color: 0x5fd0c8, roughness: 0.2, transparent: true, opacity: 0.8 })); lagoon.rotation.x = -Math.PI / 2; lagoon.position.y = 0.42; lagoon.material.depthWrite = false; lagoon.renderOrder = 1; g.add(lagoon);
  const beach = new THREE.Mesh(new THREE.CylinderGeometry(15, 17, 1.0, 48), sand); beach.position.y = 0.0; g.add(beach);
  if (kind === 'volcanic') {
    // smooth volcano from a lathe profile, with gentle ridges; green slopes, bare rock and a crater at the top
    const prof = []; for (let i = 0; i <= 20; i++) { const u = i / 20; const r = 13 * Math.pow(1 - u, 1.25) + (u > 0.92 ? 1.6 * (u - 0.92) / 0.08 : 0) + 1.6 * u; prof.push(new THREE.Vector2(Math.max(0.01, r), u * 15 - (u > 0.94 ? (u - 0.94) * 30 : 0))); }
    const geo = new THREE.LatheGeometry(prof, 96); const p = geo.attributes.position; const col = [];
    const cG = new THREE.Color(0x3f7a34), cD = new THREE.Color(0x2c5a26), cR = new THREE.Color(0x6a6058);
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i), a = Math.atan2(z, x), u = y / 15;
      const k = 1 + (0.06 * Math.sin(a * 9 + seed) + 0.035 * Math.sin(a * 21 + seed * 2)) * (1 - u * 0.6);
      p.setX(i, x * k); p.setZ(i, z * k);
      const c = cG.clone().lerp(cD, 0.5 + 0.5 * Math.sin(a * 9 + seed)).lerp(cR, Math.min(1, Math.max(0, (u - 0.62) / 0.3))); col.push(c.r, c.g, c.b);
    }
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); geo.computeVertexNormals();
    const v = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, side: THREE.DoubleSide })); v.position.y = 0.2; g.add(v);
  }
  else { for (let i = 0; i < 4; i++) { const h = new THREE.Mesh(new THREE.SphereGeometry(6 + R() * 3, 12, 8), green); h.scale.y = 0.45; h.position.set((R() - 0.5) * 12, 0.5, (R() - 0.5) * 10); g.add(h); } }
  for (let i = 0; i < 10; i++) { const a = R() * Math.PI * 2, r = 12 + R() * 3; const p = palm(3 + R() * 2, seed * 10 + i); p.position.set(Math.cos(a) * r, 0.4, Math.sin(a) * r); g.add(p); }
  if (kind === 'rapanui') { const st = new THREE.MeshStandardMaterial({ color: 0x5a524a, roughness: 1 }); for (let i = 0; i < 5; i++) { const mo = new THREE.Group(); const body = new THREE.Mesh(new THREE.BoxGeometry(1.0, 2.4, 0.7), st); body.position.y = 1.6; mo.add(body); const head = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.4, 0.8), st); head.position.set(0, 3.4, 0.05); mo.add(head); const brow = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.2, 0.3), st); brow.position.set(0, 3.7, 0.45); mo.add(brow); mo.position.set(-4 + i * 2, 0.4, 13); g.add(mo); } }
  g.scale.setScalar(s);
  return shadowAll(g);
}
// cumulus clouds piled over a spot
export function cumulus(n = 22, seed = 4) {
  const g = new THREE.Group(); const R = rng(seed); const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, emissive: 0x8a96a4, emissiveIntensity: 0.25 });
  for (let i = 0; i < n; i++) { const s = 5 + R() * 7; const b = new THREE.Mesh(new THREE.SphereGeometry(s, 16, 12), m); b.position.set((R() - 0.5) * 30, 6 + R() * 14 + (i / n) * 12, (R() - 0.5) * 14); g.add(b); }
  return g;
}
