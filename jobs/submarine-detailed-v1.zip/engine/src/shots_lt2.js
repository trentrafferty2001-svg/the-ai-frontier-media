// The Explainer: how lightning forms. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { stormStage, insideStage, bolt, sign, spark, rnd, MAT, GEO, BASE, TOP, TREE_TOP, MEET } from './bolt2.js';
import { label } from './gps.js';
import { VO } from './vo_lt2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *lightning bolt*', 3], ['is *five times*', 3], ['*hotter*', 1], ['than the surface', 3], ['of the *sun*', 3], ['and it starts', 3], ['with *ice*', 2]],
  [['Inside a', 2], ['*storm cloud*', 2], ['strong *winds*', 2], ['carry water', 2], ['*droplets*', 1], ['up high', 2], ['where they *freeze*', 3]],
  [['*Ice crystals*', 2], ['and *soft hail*', 3], ['*smash* into', 2], ['each other', 2], ['*millions*', 1], ['of times', 2]],
  [['Every *bump*', 2], ['knocks loose', 2], ['a little', 2], ['*electric charge*', 2]],
  [['Light crystals', 2], ['turn *positive*', 2], ['and *rise*', 2], ['to the *top*', 3], ['Heavy hail', 2], ['turns *negative*', 2], ['and *sinks*', 2]],
  [['The *ground* below', 3], ['turns *positive*', 2], ['and the *pull*', 3], ['keeps *growing*', 2]],
  [['Then the air', 3], ['*gives way*', 2], ['A *path* of charge', 4], ['*zigzags* down', 2], ['in *short steps*', 3]],
  [['As it nears', 3], ['the ground', 2], ['a *spark*', 2], ['reaches *up*', 2], ['to meet it', 3]],
  [['They *connect*', 2], ['and a *huge*', 3], ['*current*', 1], ['flashes *up*', 2], ['heating the air', 3], ['to *30,000*', 3], ['*degrees*', 1]],
  [['The air', 2], ['*bursts* outward', 2], ['with a *boom*', 3], ["That's *thunder*", 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.01; c.far = 900; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.9, warm: 0.92, sat: 1.15, exposure: 1.15, ao: 0 };
const pulse = (T, t0, w = 0.09) => (T >= t0 ? Math.exp(-(T - t0) / w) : 0);

// ---------- global storm state (exterior shots) ----------
const CONNECT = at(8, 'connect');
function strokePower(T) {
  if (T < CONNECT) return 0;
  const p = Math.max(pulse(T, CONNECT, 0.12), 0.85 * pulse(T, CONNECT + 0.22, 0.1), 0.7 * pulse(T, CONNECT + 0.5, 0.12));
  const hold = 0.3 * (1 - smooth(range(T, at(9, 'boom'), le(9) + 0.6)));
  return Math.max(p, hold);
}
function boltState(B, T) {
  const lead = T < at(7, 'nears') - 0.2 ? 0.88 * range(T, at(6, 'path') - 0.1, le(6) + 0.1) : lerp(0.88, 1, range(T, at(7, 'nears') - 0.2, at(7, 'ground')));
  const qlead = Math.floor(lead * 16 * 1.0) / 16; // jumps in steps
  const str = T < CONNECT ? 0.8 * smooth(range(T, at(7, 'spark') - 0.1, at(7, 'meet'))) : 1;
  const strFull = T >= CONNECT - 0.15 ? Math.max(str, range(T, CONNECT - 0.15, CONNECT)) : str;
  const P = strokePower(T);
  B.set(T >= CONNECT ? 1 : qlead, strFull, P, smooth(range(T, CONNECT + 1.0, CONNECT + 3.0)));
  return P;
}
// cloud charges: + signs rise to the anvil, - signs sink to the base; ground + signs
function charges(scene, { cloudSize = 2.6, groundSize = 1.6, lines: showLines = true } = {}) {
  const R = rnd(31); const P = [], M = [], G = [];
  for (let i = 0; i < 18; i++) { const s = sign(true, cloudSize); scene.add(s); P.push({ s, a: new THREE.Vector3((R() - 0.5) * 14, BASE + 6 + R() * 8, (R() - 0.5) * 6), b: new THREE.Vector3((R() - 0.5) * 30, TOP - 2 + R() * 2.5, 6 + R() * 4), d: R() * 0.5 }); }
  for (let i = 0; i < 18; i++) { const s = sign(false, cloudSize); scene.add(s); M.push({ s, a: new THREE.Vector3((R() - 0.5) * 14, BASE + 6 + R() * 8, (R() - 0.5) * 6), b: new THREE.Vector3((R() - 0.5) * 22, BASE + 1 + R() * 2, 9 + R() * 3), d: R() * 0.5 }); }
  for (let i = 0; i < 16; i++) { const s = sign(true, groundSize); scene.add(s); const a = R() * Math.PI * 2, r = 3 + R() * 14; G.push({ s, p: new THREE.Vector3(Math.cos(a) * r, 1.2, Math.sin(a) * r * 0.5 + 3), d: i * 0.05 }); }
  const lines = []; const lm = new THREE.MeshBasicMaterial({ color: 0xffe08a, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
  for (let i = 0; i < 7; i++) { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, BASE - 1.5, 6, 1, true), lm.clone()); m.position.set(-12 + i * 4, (BASE - 1.5) / 2 + 1.2, 3); scene.add(m); lines.push(m); }
  const sz = (s, k, size) => { s.scale.setScalar(size * k); s.visible = k > 0.01; };
  return function update(T, fade = 1) {
    const appear = range(T, at(4, 'light') - 0.1, at(4, 'light') + 0.3);
    const up = smooth(range(T, at(4, 'positive'), at(4, 'top') + 0.4)), down = smooth(range(T, at(4, 'negative') - 0.2, le(4) + 0.4));
    const gone = 1 - smooth(range(T, CONNECT, CONNECT + 0.6));
    P.forEach(({ s, a, b, d }) => { s.position.copy(a).lerp(b, smooth(range(up, d * 0.5, 0.5 + d))); sz(s, easeOut(range(appear, d, 1)) * fade * gone, cloudSize); });
    M.forEach(({ s, a, b, d }) => { s.position.copy(a).lerp(b, smooth(range(down, d * 0.5, 0.5 + d))); sz(s, easeOut(range(appear, d, 1)) * fade * gone, cloudSize); });
    G.forEach(({ s, p, d }) => { s.position.copy(p); sz(s, easeOut(range(T, at(5, 'positive') - 0.2 + d, at(5, 'positive') + d)) * fade * gone, groundSize); });
    const pull = smooth(range(T, at(5, 'pull') - 0.1, le(5) + 0.6)) * gone;
    lines.forEach((m, i) => { m.material.opacity = (showLines ? 1 : 0) * pull * (0.18 + 0.22 * pull) * (0.6 + 0.4 * Math.sin(T * 9 + i * 1.7)) * fade; });
  };
}
function exterior(makeStage, opts = {}) {
  const S = stormStage(opts); const B = bolt(); S.scene.add(B.group);
  const ch = opts.charges ? charges(S.scene, opts.charges) : null;
  return {
    ...S, B,
    step(T, fadeCharges = 1) {
      if (S.rain) S.rain.update(T);
      const P = boltState(B, T);
      const gives = 0.5 * pulse(T, at(6, 'gives'), 0.08) + 0.35 * pulse(T, at(6, 'way'), 0.08);
      S.flash(Math.min(1.6, P * 1.3 + gives));
      if (ch) ch(T, fadeCharges);
      return P;
    },
  };
}

// ============ S0 hook: a bolt slams into the lone tree, re-strikes, camera eases back ============
function sHook({ makeStage }) {
  const S = stormStage(); const B = bolt(); S.scene.add(B.group);
  const c = C(48);
  return {
    scene: S.scene, camera: c,
    update(t) {
      S.rain.update(t);
      const lead = range(t, 0.0, 0.22);
      const P = t < 0.22 ? 0 : Math.max(pulse(t, 0.22, 0.14), 0.9 * pulse(t, 0.55, 0.1), 0.8 * pulse(t, 1.05, 0.12), 0.75 * pulse(t, 2.7, 0.12), 0.35 * (1 - range(t, 0.22, 3.6)));
      B.set(lead, t >= 0.18 ? 1 : 0, P, range(t, 3.2, 4.2));
      S.flash(Math.min(1.6, P * 1.3));
      const k = easeInOut(range(t, 0, 5.2));
      const sh = P * 0.25;
      orb(c, [0.2 + Math.sin(t * 40) * sh * 0.3, lerp(11, 16, k), 0], lerp(27, 44, k), lerp(-12, 6, k), lerp(-2, 4, k));
      return { ...POST, exposure: 1.15 + P * 0.05 };
    },
  };
}
// ============ S1: inside the cloud: updraft carries droplets up; above 0 C they freeze ============
function sUpdraft() {
  const { scene } = insideStage();
  const N = 140, R = rnd(41); const D = []; for (let i = 0; i < N; i++) D.push([(R() - 0.5) * 5, R(), (R() - 0.5) * 3, 0.8 + R() * 0.5, R() * 6]);
  const drops = new THREE.InstancedMesh(GEO.drop, MAT.drop, N), ice = new THREE.InstancedMesh(GEO.ice, MAT.ice, N); drops.frustumCulled = ice.frustumCulled = false; scene.add(drops, ice);
  const streaks = []; const sm = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.22, depthWrite: false });
  for (let i = 0; i < 26; i++) { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 1.4, 4), sm); scene.add(m); streaks.push([m, (R() - 0.5) * 5, R(), (R() - 0.5) * 2.5]); }
  const fl = label('0°C freezing', { size: 0.42, color: '#bfe6ff' }); fl.sprite.position.set(0, 0.62, 0.6); fl.sprite.material.depthTest = false; scene.add(fl.sprite);
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(9, 5), new THREE.MeshBasicMaterial({ color: 0xbfe6ff, transparent: true, opacity: 0.08, side: THREE.DoubleSide, depthWrite: false })); plane.rotation.x = -Math.PI / 2; plane.position.y = 0.4; scene.add(plane);
  const Mx = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), one = new THREE.Vector3(1, 1, 1), zero = new THREE.Vector3(0, 0, 0);
  const c = C(40);
  return {
    scene, camera: c,
    update(t) {
      D.forEach(([x, y0, z, v, sp], i) => {
        const y = -3.2 + (((y0 + t * 0.32 * v) % 1)) * 6.4; const p = new THREE.Vector3(x + Math.sin(t * 1.3 + sp) * 0.08, y, z);
        const frozen = y > 0.4;
        e.set(t * sp * 0.4, t * 0.9 + sp, 0); q.setFromEuler(e);
        Mx.compose(p, q, frozen ? zero : one); drops.setMatrixAt(i, Mx);
        Mx.compose(p, q, frozen ? one : zero); ice.setMatrixAt(i, Mx);
      });
      drops.instanceMatrix.needsUpdate = ice.instanceMatrix.needsUpdate = true;
      streaks.forEach(([m, x, y0, z]) => { m.position.set(x, -3.5 + ((y0 + t * 0.9) % 1) * 7, z); });
      const k = easeInOut(range(t, 0, 5.2));
      orb(c, [0, lerp(-0.6, 0.6, k), 0], lerp(6.2, 5.4, k), lerp(-10, 12, k), lerp(-6, 4, k));
      return { ...POST, bloom: 0.5, exposure: 1.05 };
    },
  };
}
// ============ S2: crystals rising, hail falling, collisions spark ============
function sCollide() {
  const { scene } = insideStage();
  const R = rnd(53); const pairs = [];
  for (let j = 0; j < 12; j++) {
    const p = new THREE.Vector3((R() - 0.5) * 3.2, (R() - 0.5) * 3.6, (R() - 0.5) * 1.6);
    const cm = new THREE.Mesh(GEO.ice, MAT.ice), hm = new THREE.Mesh(GEO.hail, MAT.hail), sp = spark(); sp.scale.setScalar(0); scene.add(cm, hm, sp);
    pairs.push({ p, cm, hm, sp, tc: 0.25 + j * 0.33, side: R() < 0.5 ? -1 : 1 });
  }
  const amb = []; for (let i = 0; i < 40; i++) { const isH = i % 4 === 0; const m = new THREE.Mesh(isH ? GEO.hail : GEO.ice, isH ? MAT.hail : MAT.ice); scene.add(m); amb.push([m, (R() - 0.5) * 6, R(), -1 - R() * 2.5, isH ? -0.25 : 0.4, R() * 6]); }
  const c = C(40);
  return {
    scene, camera: c,
    update(t) {
      pairs.forEach(({ p, cm, hm, sp, tc, side }) => {
        const dt = t - tc;
        hm.position.set(p.x + 0.17, p.y - dt * 0.35, p.z); hm.rotation.set(t * 0.7, t * 0.4, 0);
        if (dt < 0) cm.position.set(p.x - 0.02 * dt, p.y + dt * 1.1, p.z); else cm.position.set(p.x + side * dt * 0.9, p.y + dt * 0.7, p.z + dt * 0.3);
        cm.rotation.set(t * 2, t * 3, 0);
        const f = dt >= 0 ? Math.exp(-dt / 0.12) : 0; sp.position.set(p.x + 0.08, p.y, p.z + 0.05); sp.scale.setScalar(0.9 * f); sp.visible = f > 0.02;
      });
      amb.forEach(([m, x, y0, z, v, s]) => { m.position.set(x + Math.sin(t + s) * 0.1, -3 + (((y0 + t * v * 0.25) % 1 + 1) % 1) * 6, z); m.rotation.set(t * s * 0.3, t, 0); });
      const k = easeInOut(range(t, 0, 4.3));
      orb(c, [0, 0, 0], lerp(5.6, 4.6, k), lerp(8, -10, k), 4);
      return { ...POST, bloom: 0.8, exposure: 1.05 };
    },
  };
}
// ============ S3: close-up: a crystal bumps the hailstone and a minus charge jumps across ============
function sBump() {
  const { scene } = insideStage();
  const hail = new THREE.Mesh(GEO.hail, MAT.hail); hail.scale.setScalar(3); scene.add(hail);
  const cr = [0, 1].map(() => { const m = new THREE.Mesh(GEO.ice, MAT.ice); m.scale.setScalar(3); scene.add(m); return m; });
  const minus = [0, 1].map(() => { const s = sign(false, 0.3); scene.add(s); return s; });
  const plus = [0, 1].map(() => { const s = sign(true, 0.3); scene.add(s); return s; });
  const sp = [0, 1].map(() => { const s = spark(); scene.add(s); return s; });
  const hits = [at(3, 'bump') + 0.05, at(3, 'electric')];
  const dirs = [new THREE.Vector3(-1, -0.7, 0.3).normalize(), new THREE.Vector3(1, -0.8, 0.2).normalize()];
  const c = C(38);
  const sz = (s, k, size = 0.3) => { s.scale.setScalar(size * k); s.visible = k > 0.01; };
  return {
    scene, camera: c,
    update(t, T) {
      hail.rotation.set(T * 0.3, T * 0.2, 0); hail.position.set(0, -0.06 * t, 0); const H = hail.position;
      hits.forEach((th, i) => {
        const dt = T - th, d = dirs[i];
        const touch = H.clone().addScaledVector(d, 0.62);
        if (dt < 0) cr[i].position.copy(touch).addScaledVector(d, -dt * 1.6 + 0); else cr[i].position.copy(touch).add(new THREE.Vector3(d.x * dt * 0.35, dt * 0.45, 0.2 * dt));
        const gone = 1 - smooth(range(dt, 0.6, 1.0)); cr[i].scale.setScalar(3 * Math.max(0.001, gone)); cr[i].rotation.set(T * 2 + i, T * 1.5, 0); cr[i].visible = dt > -1.2 && gone > 0.01;
        const f = dt >= 0 ? Math.exp(-dt / 0.15) : 0; sp[i].position.copy(touch); sp[i].scale.setScalar(0.8 * f); sp[i].visible = f > 0.02;
        // minus hops onto the hail, plus stays on the crystal
        const hop = smooth(range(dt, 0.02, 0.4));
        minus[i].position.copy(touch).lerp(H.clone().addScaledVector(d, 0.42).add(new THREE.Vector3(0, 0.1, 0.45)), hop); sz(minus[i], dt > 0 ? easeOut(range(dt, 0, 0.12)) : 0);
        plus[i].position.copy(cr[i].position).add(new THREE.Vector3(0, 0.25, 0.3)); sz(plus[i], dt > 0.1 ? easeOut(range(dt, 0.1, 0.25)) * gone : 0);
      });
      const k = easeInOut(range(t, 0, 2.8));
      orb(c, [0, -0.45, 0], lerp(6.0, 5.6, k), lerp(-8, 8, k), 3);
      return { ...POST, bloom: 0.8, exposure: 1.05 };
    },
  };
}
// ============ S4: whole cloud: + rise to the top, - sink to the base ============
function sSeparate({ makeStage }) {
  const E = exterior(makeStage, { charges: {} }); E.cloud.mat.opacity = 0.8;
  const c = C(40);
  return {
    scene: E.scene, camera: c,
    update(t, T) {
      E.step(T);
      const k = easeInOut(range(t, 0, 5.4));
      orb(c, [0, lerp(22, 21, k), 0], lerp(86, 80, k), lerp(-6, 6, k), lerp(3, 5, k));
      return POST;
    },
  };
}
// ============ S5: ground turns positive, the pull grows ============
function sGround({ makeStage }) {
  const E = exterior(makeStage, { charges: {} }); E.cloud.mat.opacity = 0.8;
  const c = C(42);
  return {
    scene: E.scene, camera: c,
    update(t, T) {
      E.step(T);
      const k = easeInOut(range(t, 0, 3.6));
      orb(c, [0, lerp(15, 13, k), 0], lerp(66, 58, k), lerp(14, 22, k), lerp(4, 2, k));
      return POST;
    },
  };
}
// ============ S6: the air gives way; the stepped leader zigzags down ============
function sLeader({ makeStage }) {
  const E = exterior(makeStage, { charges: { cloudSize: 1.6, groundSize: 0.9, lines: false } });
  const c = C(44);
  return {
    scene: E.scene, camera: c,
    update(t, T) {
      E.step(T, 0.6);
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [-1, lerp(13, 12, k), 0], lerp(38, 34, k), lerp(-14, -4, k), lerp(-3, 0, k));
      return { ...POST, exposure: 1.2 };
    },
  };
}
// ============ S7: near the ground: a spark climbs from the tree to meet it ============
function sStreamer({ makeStage }) {
  const E = exterior(makeStage, { charges: { cloudSize: 1.2, groundSize: 0.7, lines: false } });
  const c = C(42);
  return {
    scene: E.scene, camera: c,
    update(t, T) {
      E.step(T, 0.8);
      const k = easeInOut(range(t, 0, 3.2));
      orb(c, [0.2, lerp(10, 9, k), 0], lerp(32, 28, k), lerp(20, 30, k), lerp(-2, 1, k));
      return { ...POST, exposure: 1.25 };
    },
  };
}
// ============ S8: connection: the return stroke, blinding flash, 30,000 C ============
function sStroke({ makeStage }) {
  const E = exterior(makeStage, {});
  const L1 = label('30,000°C', { size: 3.2, color: '#ffb347' }); L1.sprite.material.depthTest = false; L1.sprite.renderOrder = 30; E.scene.add(L1.sprite);
  const L2 = label('5× the Sun', { size: 2.4, color: '#ffe08a' }); L2.sprite.material.depthTest = false; L2.sprite.renderOrder = 30; E.scene.add(L2.sprite);
  const c = C(46);
  return {
    scene: E.scene, camera: c,
    update(t, T) {
      const P = E.step(T);
      const k = easeInOut(range(t, 0, 5.0));
      const sh = Math.max(0, P - 0.4) * 0.6;
      const tg = [0 + Math.sin(T * 47) * sh, lerp(12, 13, k) + Math.cos(T * 39) * sh, 0];
      orb(c, tg, lerp(30, 36, k), lerp(8, 16, k), lerp(-6, -2, k));
      // labels sit in the top third, left of the channel
      const lk = easeOut(range(T, at(8, 'thirty') - 0.1, at(8, 'thirty') + 0.2)), lk2 = easeOut(range(T, at(8, 'degrees'), at(8, 'degrees') + 0.25));
      L1.sprite.position.set(0, 24.5, 4); L1.sprite.scale.set(3.2 * 4 * lk, 3.2 * lk, 1); L1.sprite.visible = lk > 0.01;
      L2.sprite.position.set(0, 21.6, 4); L2.sprite.scale.set(2.4 * 4 * lk2, 2.4 * lk2, 1); L2.sprite.visible = lk2 > 0.01;
      return { ...POST, exposure: 1.15 + P * 0.05 };
    },
  };
}
// ============ S9: the air bursts outward: shock wave = thunder; pull back to the storm ============
function sThunder({ makeStage }) {
  const E = exterior(makeStage, {});
  const shell = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, BASE, 48, 1, true), new THREE.MeshBasicMaterial({ color: 0xcfd8ff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
  shell.position.set(-1.5, BASE / 2, 0); E.scene.add(shell);
  const rings = [0, 1, 2].map(() => { const m = new THREE.Mesh(new THREE.TorusGeometry(1, 0.08, 8, 96), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false })); m.rotation.x = Math.PI / 2; E.scene.add(m); return m; });
  const c = C(44);
  const t0 = at(9, 'bursts') - 0.15, tb = at(9, 'boom');
  return {
    scene: E.scene, camera: c,
    update(t, T) {
      const P = E.step(T);
      const g = range(T, t0, t0 + 2.8);
      shell.scale.set(0.5 + 26 * easeOut(g), 1, 0.5 + 26 * easeOut(g)); shell.material.opacity = 0.22 * (1 - g) * (g > 0 ? 1 : 0);
      rings.forEach((m, i) => { const gi = range(T, t0 + i * 0.12, t0 + 2.4 + i * 0.12); const r = 0.5 + 28 * easeOut(gi); m.scale.set(r, r, 1 + gi * 6); m.position.set(-1.5, 3 + i * 7, 0); m.material.opacity = 0.7 * (1 - gi) * (gi > 0 ? 1 : 0); });
      const boom = pulse(T, tb, 0.25) * 0.5;
      const k = easeInOut(range(t, 0, 4.6));
      orb(c, [Math.sin(T * 50) * boom, lerp(13, 22, k) + Math.cos(T * 43) * boom, 0], lerp(40, 86, k), lerp(16, 4, k), lerp(-2, 3, k));
      return { ...POST, exposure: 1.15 + P * 0.05 };
    },
  };
}

// ============ timeline ============
const SH = [sHook, sUpdraft, sCollide, sBump, sSeparate, sGround, sLeader, sStreamer, sStroke, sThunder];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
