// Roman hypocaust reel: bath room cut-away (basement, pilae stacks, raised mosaic floor, walls with tubuli box flues,
// roof vents), outside furnace (praefurnium) with fire, hot-air particles along the path, warm-floor glow, steaming pool,
// snowy villa exterior.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex } from './rome.js';
import { glowSprite } from './props.js';
import { fire } from './heron.js';

let HM = null;
export function hMats() {
  if (HM) return HM;
  const mosaic = canvasTex(256, 256, (x) => { x.fillStyle = '#e8dcc0'; x.fillRect(0, 0, 256, 256); const R = rng(5); for (let i = 0; i < 32; i++) for (let j = 0; j < 32; j++) { const d = Math.hypot(i - 15.5, j - 15.5); x.fillStyle = d < 6 ? (((i + j) % 2) ? '#2a5a8a' : '#e8dcc0') : d < 9 ? '#a83a2a' : d > 14 ? '#3a3a3a' : `rgba(${200 + R() * 30},${185 + R() * 30},${150 + R() * 30},1)`; x.fillRect(i * 8 + 0.5, j * 8 + 0.5, 7, 7); } }, [2, 2]);
  HM = {
    brick: new THREE.MeshStandardMaterial({ color: 0xa8603a, roughness: 0.9, bumpMap: fabricTexture(41), bumpScale: 3 }),
    floor: new THREE.MeshStandardMaterial({ map: mosaic, roughness: 0.5, emissive: 0xff5010, emissiveIntensity: 0 }),
    slab: new THREE.MeshStandardMaterial({ color: 0xb8a888, roughness: 0.9 }),
    wall: new THREE.MeshStandardMaterial({ color: 0xd8c8a8, roughness: 0.8 }),
    plaster: new THREE.MeshStandardMaterial({ color: 0xe0c8a0, roughness: 0.8 }),
    tile: new THREE.MeshStandardMaterial({ color: 0xb85a34, roughness: 0.8 }),
    base: new THREE.MeshStandardMaterial({ color: 0x5a4a3a, roughness: 1 }),
    water: new THREE.MeshStandardMaterial({ color: 0x3a8ac8, emissive: 0x0a3a6a, emissiveIntensity: 0.4, roughness: 0.05, transparent: true, opacity: 0.85 }),
    snow: new THREE.MeshStandardMaterial({ color: 0xf2f6fa, roughness: 0.9 }),
  };
  return HM;
}
// room: 6 x 5, basement y=0, pilae 0.8, floor top y=1.0, walls to y=4.4; front (+z) open; right wall (+x) cut to show flues
export function bathRoom({ cutFloor = false } = {}) {
  const M = hMats(); const g = new THREE.Group();
  const base = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.2, 5.4), M.base); base.position.y = -0.1; g.add(base);
  const pilae = new THREE.Group(); g.add(pilae);
  for (let i = 0; i < 9; i++) for (let j = 0; j < 7; j++) { for (let k = 0; k < 6; k++) { const t = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.12, 0.26), M.brick); t.position.set(-2.6 + i * 0.65, 0.07 + k * 0.13, -2.1 + j * 0.7); pilae.add(t); } }
  // floor in two halves: the back half always stays; the front half fades away for the cut-away
  // (a see-through whole floor ghosted every pila behind it)
  const slab = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.18, 2.5), M.slab.clone()); slab.position.set(0, 0.9, -1.25); g.add(slab);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(6.0, 2.5), M.floor.clone()); floor.rotation.x = -Math.PI / 2; floor.position.set(0, 1.0, -1.25); g.add(floor);
  const slabF = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.18, 2.5), M.slab.clone()); slabF.position.set(0, 0.9, 1.25); g.add(slabF);
  const floorF = new THREE.Mesh(new THREE.PlaneGeometry(6.0, 2.5), M.floor.clone()); floorF.rotation.x = -Math.PI / 2; floorF.position.set(0, 1.0, 1.25); g.add(floorF);
  const cutEdge = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.2, 0.02), new THREE.MeshStandardMaterial({ color: 0x8a6a4a, roughness: 1 })); cutEdge.position.set(0, 0.91, 0.0); g.add(cutEdge);
  // walls: back and left solid, right wall as a cut-away showing the box flues
  const back = new THREE.Mesh(new THREE.BoxGeometry(6.4, 4.4, 0.3), M.plaster); back.position.set(0, 2.2, -2.65); g.add(back);
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.3, 4.4, 5.6), M.plaster); left.position.set(-3.15, 2.2, 0); g.add(left);
  const arch = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.7, 1.0), new THREE.MeshStandardMaterial({ color: 0x140a04 })); arch.position.set(-3.15, 0.4, 0); g.add(arch);
  const right = new THREE.Mesh(new THREE.BoxGeometry(0.12, 4.4, 5.6), M.plaster); right.position.set(3.33, 2.2, 0); right.visible = false; g.add(right);
  const flues = new THREE.Group(); g.add(flues);
  for (let j = 0; j < 7; j++) for (let k = 0; k < 9; k++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.36, 0.5), M.brick); b.position.set(3.18, 1.2 + k * 0.38, -2.2 + j * 0.72); flues.add(b); }
  const roof = new THREE.Mesh(new THREE.BoxGeometry(6.8, 0.3, 5.8), M.tile); roof.position.set(0, 4.55, -0.1); g.add(roof);
  const vents = [-1.8, 0, 1.8].map(z => { const v = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.5, 10), M.tile); v.position.set(3.18, 4.9, z); g.add(v); return v; });
  // steaming pool in the corner
  const pool = new THREE.Group(); pool.position.set(1.2, 1.0, -1.2); g.add(pool);
  const rim = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.5, 1.8), M.wall); rim.position.y = 0.25; pool.add(rim);
  const w = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.05, 1.5), M.water); w.position.y = 0.48; pool.add(w);
  const steam = [...Array(10)].map(() => { const s = glowSprite(0xffffff, 0.6); s.material.blending = THREE.NormalBlending; pool.add(s); return s; });
  // hot air particles along furnace -> under floor -> flues -> vents
  const air = [...Array(60)].map(() => { const s = glowSprite(0xff7a2a, 0.35); g.add(s); return s; });
  const path = (u, i) => {
    const z = -2.0 + ((i * 37) % 60) / 60 * 4.0;
    if (u < 0.12) return [-4.4 + u / 0.12 * 1.4, 0.4, z * 0.2];
    if (u < 0.6) { const v = (u - 0.12) / 0.48; return [-3.0 + v * 6.0, 0.45 + Math.sin(v * 9 + i) * 0.1, z * (0.2 + v * 0.8)]; }
    if (u < 0.95) { const v = (u - 0.6) / 0.35; return [3.18, 1.0 + v * 3.6, z]; }
    const v = (u - 0.95) / 0.05; return [3.18, 4.6 + v * 0.8, Math.round(z / 1.8) * 1.8];
  };
  g.flow = (k, t) => { air.forEach((s, i) => { const u = (t * 0.12 + i / 60) % 1; const p = path(u, i); s.position.set(...p); s.material.opacity = k * (u > 0.6 ? 0.55 : 0.9); s.visible = k > 0.01; s.material.color.setHSL(0.06 - u * 0.04, 1, 0.55 - u * 0.15); }); };
  g.warm = (k) => { floor.material.emissiveIntensity = floorF.material.emissiveIntensity = 0.18 * k; };
  g.steam = (k, t) => steam.forEach((s, i) => { const u = (t * 0.25 + i / 10) % 1; s.position.set(Math.sin(i * 3) * 0.8, 0.5 + u * 1.6, Math.cos(i * 2) * 0.5); s.scale.setScalar(0.4 + u * 1.2); s.material.opacity = k * 0.35 * (1 - u); });
  g.cutFloor = (k) => { for (const m of [floorF, slabF]) { m.material.transparent = k > 0; m.material.opacity = 1 - k; m.material.depthWrite = k < 0.05; m.visible = k < 0.99; m.position.y = (m === floorF ? 1.0 : 0.9) + k * 0.3; } cutEdge.visible = k > 0.5; };
  g.cutFloor(cutFloor ? 1 : 0); g.flow(0, 0); g.warm(0); g.steam(0, 0);
  g.vents = vents; g.pool = pool;
  return shadowAll(g);
}
// praefurnium: brick furnace box against the left wall with arched mouth and fire
export function furnace() {
  const M = hMats(); const g = new THREE.Group();
  const box = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.2, 1.6), M.brick); box.position.set(-4.2, 0.6, 0); g.add(box);
  const mouth = new THREE.Mesh(new THREE.CircleGeometry(0.4, 20, 0, Math.PI), new THREE.MeshStandardMaterial({ color: 0x1a0a04 })); mouth.position.set(-4.2, 0.2, 0.81); g.add(mouth);
  const F = fire(0.7); F.position.set(-4.2, 0.12, 0.86); g.add(F); // in the mouth, not hidden inside the box
  const fl = new THREE.PointLight(0xff7a2a, 4, 4, 1.8); fl.position.set(-4.2, 0.4, 1.3); g.add(fl);
  const yard = new THREE.Mesh(new THREE.PlaneGeometry(14, 10), new THREE.MeshStandardMaterial({ color: 0x6a5a48, roughness: 1, bumpMap: fabricTexture(19), bumpScale: 3 })); yard.rotation.x = -Math.PI / 2; yard.position.set(-5, -0.21, 1); yard.receiveShadow = true; g.add(yard);
  const logs = [...Array(5)].map((_, i) => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.7, 8), new THREE.MeshStandardMaterial({ color: 0x6a4424, roughness: 0.9 })); l.rotation.z = Math.PI / 2; l.position.set(-5.4, 0.08 + (i % 2) * 0.12, 1.4 + i * 0.13); g.add(l); return l; });
  g.fire = F;
  return shadowAll(g);
}
// snowy villa exterior: walls + tiled roof + glowing windows, snow ground
export function villa(scene) {
  const M = hMats();
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), M.snow); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const body = new THREE.Mesh(new THREE.BoxGeometry(12, 4, 8), M.wall); body.position.set(0, 2, -4); body.castShadow = true; scene.add(body);
  const roof = new THREE.Mesh(new THREE.CylinderGeometry(4.6, 4.6, 12.6, 4, 1), M.tile); roof.rotation.set(0, 0, Math.PI / 2); roof.scale.set(0.5, 1, 1); roof.position.set(0, 4.6, -4); scene.add(roof);
  const snowCap = new THREE.Mesh(new THREE.CylinderGeometry(4.72, 4.72, 12.9, 4, 1, false, 0, Math.PI), new THREE.MeshStandardMaterial({ color: 0xf4f6fa, roughness: 0.9 })); snowCap.rotation.set(0, 0, Math.PI / 2); snowCap.scale.set(0.5, 1, 1); snowCap.position.set(0, 4.66, -4); scene.add(snowCap); // snow on the roof
  const pineM = new THREE.MeshStandardMaterial({ color: 0x2e5a3e, roughness: 0.9 }), snowM = new THREE.MeshStandardMaterial({ color: 0xf2f4f8, roughness: 0.9 });
  [[-10, -1, 5.5], [-12.5, -6, 7], [-8.5, -9, 6], [9, -8, 6.5]].forEach(([x, z, h]) => { for (let k = 0; k < 3; k++) { const c = new THREE.Mesh(new THREE.ConeGeometry(h * (0.32 - k * 0.07), h * 0.45, 10), pineM); c.position.set(x, h * (0.3 + k * 0.2), z); c.castShadow = true; scene.add(c); const sc = new THREE.Mesh(new THREE.ConeGeometry(h * (0.2 - k * 0.04), h * 0.2, 10), snowM); sc.position.set(x, h * (0.42 + k * 0.2), z); scene.add(sc); } });
  const door = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 2.4), new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.8 })); door.position.set(4.6, 1.2, 0.01); scene.add(door);
  for (const x of [-3, 0, 3]) { const w = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.4), new THREE.MeshStandardMaterial({ color: 0xffc070, emissive: 0xff9a40, emissiveIntensity: 1.2 })); w.position.set(x, 2.2, 0.01); scene.add(w); }
  const smoke = [...Array(10)].map(() => { const s = glowSprite(0x9a9a9a, 1); s.material.blending = THREE.NormalBlending; scene.add(s); return s; });
  return (t) => smoke.forEach((s, i) => { const u = (t * 0.2 + i / 10) % 1; s.position.set(5 + Math.sin(u * 4) * 0.4, 6 + u * 5, -4); s.scale.setScalar(0.6 + u * 2.5); s.material.opacity = 0.4 * (1 - u); });
}
export function snowfall(scene, n = 300, area = 30) {
  const R = rng(7); const geo = new THREE.BufferGeometry(); const P = new Float32Array(n * 3); const S = [];
  for (let i = 0; i < n; i++) { S.push([(R() - 0.5) * area, R() * 15, (R() - 0.5) * area, 0.4 + R() * 0.6]); }
  geo.setAttribute('position', new THREE.BufferAttribute(P, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.08 })); pts.frustumCulled = false; scene.add(pts);
  return (t) => { S.forEach(([x, y, z, v], i) => { P[i * 3] = x + Math.sin(t + i) * 0.3; P[i * 3 + 1] = ((y - t * v) % 15 + 15) % 15; P[i * 3 + 2] = z; }); geo.attributes.position.needsUpdate = true; };
}
