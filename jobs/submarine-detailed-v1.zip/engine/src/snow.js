// The Explainer: how snowflakes get six arms. Procedural six-fold snowflake that grows (plate -> arms -> branches),
// water-molecule hexagon lattice, vapour particles, cloud fog.
import * as THREE from 'three';
import { rnd } from './bolt.js';

export const ICE = () => new THREE.MeshPhysicalMaterial({ color: 0xdff4ff, roughness: 0.08, metalness: 0.05, transmission: 0.35, thickness: 0.05, clearcoat: 1, iridescence: 0.5, emissive: 0x6ab8ff, emissiveIntensity: 0.25, side: THREE.DoubleSide });
// flake in the xy plane (faces +z). grow(g): 0..0.3 plate, 0.25.. arms, 0.5.. branches. seed changes branch layout.
export function flake(seed = 1, { K = 5, armMax = 1.6 } = {}) {
  const G = new THREE.Group(); const mat = ICE(); const R = rnd(seed);
  const core = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 0.03, 6), mat); core.rotation.x = Math.PI / 2; G.add(core);
  const ridge = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 0.032, 6, 1, true), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6, side: THREE.DoubleSide })); ridge.rotation.x = Math.PI / 2; G.add(ridge);
  const box = new THREE.BoxGeometry(1, 1, 0.025); box.translate(0.5, 0, 0);
  const P = []; for (let k = 0; k < K; k++) P.push({ p: 0.15 + (k / K) * 0.75 + (R() - 0.5) * 0.06, len: 0.5 + R() * 0.5, w: 0.05 + R() * 0.03 });
  const arms = []; for (let a = 0; a < 6; a++) { const ang = a * Math.PI / 3 + Math.PI / 6; const arm = new THREE.Group(); arm.rotation.z = ang; G.add(arm); const shaft = new THREE.Mesh(box, mat); arm.add(shaft); const br = P.map(() => [-1, 1].map(s => { const b = new THREE.Mesh(box, mat); b.rotation.z = s * Math.PI / 3; arm.add(b); return b; })); arms.push({ arm, shaft, br }); }
  function grow(g) {
    const rc = 0.08 + 0.32 * Math.min(1, g / 0.3); core.scale.set(rc, 1, rc); ridge.scale.set(rc * 1.01, 1, rc * 1.01); core.rotation.y = 0; core.rotation.z = 0;
    const L = Math.max(0, (g - 0.22) / 0.78) * armMax; const w = 0.09 * (0.6 + 0.4 * Math.min(1, g * 2));
    arms.forEach(({ shaft, br }) => {
      shaft.position.x = rc * 0.866; shaft.scale.set(Math.max(0.0001, L), w, 1); shaft.visible = L > 0.01;
      br.forEach((pair, k) => { const pos = P[k].p * armMax; const bl = Math.max(0, (L - pos) * 0.45 * P[k].len) * Math.min(1, Math.max(0, (g - 0.45) / 0.2)); pair.forEach(b => { b.position.x = rc * 0.866 + pos; b.scale.set(Math.max(0.0001, bl), P[k].w, 1); b.visible = bl > 0.01; }); });
    });
  }
  grow(0.05);
  return { group: G, grow, mat };
}
// water molecule: red O + two white H at 104.5 degrees
export function water() { const g = new THREE.Group(); const o = new THREE.Mesh(new THREE.SphereGeometry(0.18, 20, 14), new THREE.MeshStandardMaterial({ color: 0xe8443a, roughness: 0.35 })); g.add(o); const hm = new THREE.MeshStandardMaterial({ color: 0xf4f4f4, roughness: 0.35 }); [-1, 1].forEach(s => { const h = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 10), hm); const a = s * 0.912; h.position.set(Math.sin(a) * 0.24, -Math.cos(a) * 0.24, 0); g.add(h); }); return g; }
// hexagonal (honeycomb) lattice of molecules: k=0 scattered, 1 locked; bonds glow in
export function lattice(rings = 2, seed = 4) {
  const G = new THREE.Group(); const R = rnd(seed); const pts = []; const s = 0.9;
  for (let q = -rings; q <= rings; q++) for (let r = -rings; r <= rings; r++) { if (Math.abs(q + r) > rings) continue; const cx = s * 1.732 * (q + r / 2), cy = s * 1.5 * r; for (let k = 0; k < 6; k++) { const a = Math.PI / 6 + k * Math.PI / 3; const p = new THREE.Vector2(cx + Math.cos(a) * s, cy + Math.sin(a) * s); if (!pts.some(o => o.distanceTo(p) < 0.1)) pts.push(p); } }
  const mols = pts.map(p => { const m = water(); G.add(m); return { m, home: p, from: new THREE.Vector3((R() - 0.5) * 9, (R() - 0.5) * 9, (R() - 0.5) * 4), spin: R() * 6 }; });
  const bm = new THREE.MeshBasicMaterial({ color: 0x9ae6ff, transparent: true, opacity: 0, toneMapped: false });
  const bonds = []; for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) { if (Math.abs(pts[i].distanceTo(pts[j]) - s) < 0.05) { const d = pts[j].clone().sub(pts[i]); const b = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, d.length() - 0.4, 6), bm); b.position.set((pts[i].x + pts[j].x) / 2, (pts[i].y + pts[j].y) / 2, 0); b.rotation.z = Math.atan2(d.y, d.x) - Math.PI / 2; G.add(b); bonds.push(b); } }
  return { group: G, set(k, T) { mols.forEach(({ m, home, from, spin }) => { const h = new THREE.Vector3(home.x, home.y, 0); m.position.copy(from).lerp(h, k); m.rotation.z = (1 - k) * (spin + T) + k * Math.atan2(home.y, home.x); }); bm.opacity = 0.8 * Math.max(0, (k - 0.7) / 0.3); } };
}
// vapour: small glowing dots that drift in and stick to targets
export function vapour(n = 200, seed = 7) {
  const R = rnd(seed); const P = []; for (let i = 0; i < n; i++) P.push({ a: R() * Math.PI * 2, r: 1.5 + R() * 3, ph: R(), z: (R() - 0.5) * 1.5, tip: Math.floor(R() * 6) });
  const im = new THREE.InstancedMesh(new THREE.SphereGeometry(0.03, 6, 4), new THREE.MeshBasicMaterial({ color: 0xcfeeff, transparent: true, opacity: 0.85, toneMapped: false }), n); im.frustumCulled = false;
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  return { mesh: im, update(T, k, tipR = 0.4, toTips = 0) { P.forEach((o, i) => { const u = ((o.ph + T * 0.35) % 1); const ta = o.tip * Math.PI / 3 + Math.PI / 6; const tx = toTips ? Math.cos(ta) * tipR : Math.cos(o.a) * 0.2, ty = toTips ? Math.sin(ta) * tipR : Math.sin(o.a) * 0.2; const x = Math.cos(o.a) * o.r * (1 - u) + tx * u, y = Math.sin(o.a) * o.r * (1 - u) + ty * u; M.compose(new THREE.Vector3(x, y, o.z * (1 - u)), q, s.setScalar(k > 0.01 ? k * (1 - u * 0.6) : 0.0001)); im.setMatrixAt(i, M); }); im.instanceMatrix.needsUpdate = true; } };
}
