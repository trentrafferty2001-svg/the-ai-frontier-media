// Chinampa reel: lake (water + bed), chinampa raised bed with posts, woven reed wall, mud fill, crops and willow
// trees (build stages), canoe, Aztec farmer, Tenochtitlan twin-temple pyramid, island houses, colourful trajinera.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { waterMaterial, mountains } from './world.js';
import * as BufferGeometryUtils from 'three/addons/utils/BufferGeometryUtils.js';

let CM = null;
export function chMats2() {
  if (CM) return CM;
  const weave = canvasTex(128, 128, (x) => { x.fillStyle = '#9a7a42'; x.fillRect(0, 0, 128, 128); x.strokeStyle = 'rgba(60,40,15,0.6)'; x.lineWidth = 3; for (let i = 0; i < 16; i++) { x.beginPath(); x.moveTo(0, i * 8 + 4); for (let k = 0; k <= 16; k++) x.lineTo(k * 8, i * 8 + 4 + ((k + i) % 2 ? 2 : -2)); x.stroke(); } }, [6, 1]);
  CM = {
    post: new THREE.MeshStandardMaterial({ color: 0x6a4a2a, roughness: 0.9 }),
    weave: new THREE.MeshStandardMaterial({ map: weave, roughness: 0.95, side: THREE.DoubleSide }),
    mud: new THREE.MeshStandardMaterial({ map: canvasTex(256, 256, (x) => { const R = rng(41); x.fillStyle = '#4a3420'; x.fillRect(0, 0, 256, 256); for (let k = 0; k < 700; k++) { const v = R(); x.fillStyle = v < 0.4 ? `rgba(110,130,50,${0.55 + R() * 0.4})` : v < 0.7 ? `rgba(150,115,55,${0.5 + R() * 0.4})` : `rgba(25,16,8,${0.4 + R() * 0.3})`; x.save(); x.translate(R() * 256, R() * 256); x.rotate(R() * 3.14); x.beginPath(); x.ellipse(0, 0, 2 + R() * 3, 6 + R() * 14, 0, 0, 7); x.fill(); x.restore(); } }, [1.5, 4]), roughness: 1, bumpMap: fabricTexture(31), bumpScale: 4 }), // lake mud with rotting leaves and stalks
    soil: new THREE.MeshStandardMaterial({ color: 0x5a4028, roughness: 1, bumpMap: fabricTexture(9), bumpScale: 3 }),
    crop: new THREE.MeshStandardMaterial({ color: 0x5aa02e, roughness: 0.8, side: THREE.DoubleSide }),
    corn: new THREE.MeshStandardMaterial({ color: 0x7ab83a, roughness: 0.8 }),
    willow: new THREE.MeshStandardMaterial({ color: 0x3f7a34, roughness: 0.85 }),
    bark: new THREE.MeshStandardMaterial({ color: 0x6a5a4a, roughness: 0.9 }),
    bed: new THREE.MeshStandardMaterial({ color: 0x3a3426, roughness: 1 }),
    white: new THREE.MeshStandardMaterial({ color: 0xece4d4, roughness: 0.8 }),
  };
  CM.soil.map = CM.mud.map; CM.soil.color.set(0xd8c8b8); // top layer shows the mud + rotting plants
  return CM;
}
// lake: water surface at y=0, lake bed at y=-depth
export function lake(scene, { size = 600, depth = 1.2, color = 0x2a5a52, mtn = true } = {}) {
  const w = new THREE.Mesh(new THREE.PlaneGeometry(size, size), waterMaterial({ color, opacity: 0.85 })); w.rotation.x = -Math.PI / 2; w.receiveShadow = true; scene.add(w);
  const b = new THREE.Mesh(new THREE.PlaneGeometry(size, size), chMats2().bed); b.rotation.x = -Math.PI / 2; b.position.y = -depth; scene.add(b);
  if (mtn) scene.add(mountains({ rMin: 160, rMax: 340, height: 60, seed: 6, color: 0x5a6a5a }));
  return w;
}
// columnar ahuejote willow
export function willow(h = 6, seed = 1) {
  const M = chMats2(); const g = new THREE.Group(); const R = rng(seed);
  const tr = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.18, h * 0.5, 8), M.bark); tr.position.y = h * 0.25; g.add(tr);
  const c = new THREE.Mesh(new THREE.SphereGeometry(0.9, 14, 12), M.willow); c.scale.set(0.9, h * 0.42, 0.9); c.position.y = h * 0.58; g.add(c);
  for (let i = 0; i < 3; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.5, 10, 8), M.willow); s.scale.set(1, h * 0.25, 1); s.position.set((R() - 0.5) * 0.8, h * (0.45 + R() * 0.3), (R() - 0.5) * 0.8); g.add(s); }
  return shadowAll(g);
}
const UP = new THREE.Vector3(0, 1, 0);
let MAIZE = null;
// a young maize plant (stalk, arching leaves, tassel), base at y=0, ~0.9 tall: reads as a crop, not a green cone
function maizeGeo() {
  if (MAIZE) return MAIZE;
  const parts = [];
  const st = new THREE.CylinderGeometry(0.012, 0.02, 0.8, 6); st.translate(0, 0.4, 0); parts.push(st);
  for (let k = 0; k < 6; k++) {
    const pos = [], idx = [], N = 6, y0 = 0.12 + k * 0.11, a = k * 2.2, L = 0.42 - k * 0.03;
    for (let i = 0; i <= N; i++) { const u = i / N, wdt = 0.035 * Math.sin(Math.PI * Math.min(1, u * 1.1 + 0.05)); const r = u * L, h = y0 + u * L * 0.55 - u * u * L * 0.6;
      const cx = Math.cos(a) * r, cz = Math.sin(a) * r, nx = -Math.sin(a) * wdt, nz = Math.cos(a) * wdt; pos.push(cx - nx, h, cz - nz, cx + nx, h, cz + nz); }
    for (let i = 0; i < N; i++) { const b = i * 2; idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); parts.push(g);
  }
  const ts = new THREE.ConeGeometry(0.03, 0.14, 5); ts.translate(0, 0.86, 0); parts.push(ts);
  MAIZE = BufferGeometryUtils.mergeGeometries(parts.map(p => { const n = p.index ? p.toNonIndexed() : p; const o = new THREE.BufferGeometry(); o.setAttribute('position', n.getAttribute('position')); return o; }));
  MAIZE.computeVertexNormals();
  return MAIZE;
}
// one chinampa w x l, top at y=top; build(stage 0..4): 0 posts, 1 woven wall, 2 mud fill, 3 willows, 4 crops
export function chinampa(w = 4, l = 12, { top = 0.35, depth = 1.2, seed = 1, crops = true } = {}) {
  const M = chMats2(); const g = new THREE.Group(); const R = rng(seed);
  const posts = [];
  const per = []; for (let x = -w / 2; x <= w / 2 + 0.01; x += w / 4) { per.push([x, -l / 2], [x, l / 2]); } for (let z = -l / 2 + l / 8; z < l / 2 - 0.01; z += l / 8) { per.push([-w / 2, z], [w / 2, z]); }
  per.forEach(([x, z]) => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, depth + top + 0.3, 6), M.post); p.position.set(x, (top + 0.3 - depth) / 2, z); g.add(p); posts.push(p); });
  const wall = new THREE.Group(); g.add(wall);
  const H = depth + top;
  [[w, 0, l / 2, 0], [w, 0, -l / 2, 0], [l, w / 2, 0, Math.PI / 2], [l, -w / 2, 0, Math.PI / 2]].forEach(([len, x, z, ry]) => { const p = new THREE.Mesh(new THREE.PlaneGeometry(len, H), M.weave); p.position.set(x, (top - depth) / 2, z); p.rotation.y = ry; wall.add(p); });
  const fill = new THREE.Mesh(new THREE.BoxGeometry(w - 0.05, H, l - 0.05), M.mud); g.add(fill);
  const soil = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.1, l - 0.1), M.soil); soil.rotation.x = -Math.PI / 2; soil.position.y = top + 0.01; g.add(soil);
  const trees = [[-w / 2, -l / 2], [w / 2, -l / 2], [-w / 2, l / 2], [w / 2, l / 2]].map(([x, z], i) => { const t = willow(5 + R() * 2, seed * 7 + i); t.position.set(x, top, z); g.add(t); return t; });
  const plants = new THREE.InstancedMesh(maizeGeo(), M.crop, 120); g.add(plants);
  const P = []; for (let i = 0; i < 120; i++) P.push([(i % 6 - 2.5) * (w - 0.8) / 5, -l / 2 + 0.5 + Math.floor(i / 6) * (l - 1) / 19]);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  g.grow = (k) => { const s = Math.max(0.001, k); P.forEach(([x, z], i) => { q.setFromAxisAngle(UP, (i * 2.399) % 6.28); m4.compose(new THREE.Vector3(x, top, z), q, new THREE.Vector3(s, s, s)); plants.setMatrixAt(i, m4); }); plants.instanceMatrix.needsUpdate = true; plants.visible = k > 0.01; };
  g.build = (st) => { // st continuous 0..4
    const c = (a) => Math.min(1, Math.max(0, st - a));
    posts.forEach((p, i) => { const k = Math.min(1, Math.max(0, st * 1.5 - i / posts.length * 0.5)); p.scale.y = Math.max(0.001, k); p.position.y = (top + 0.3 - depth) / 2 + (1 - k) * 1.5; });
    wall.visible = st > 1; wall.children.forEach(p => { p.scale.y = Math.max(0.001, c(1)); });
    fill.visible = st > 2; const f = c(2); fill.scale.y = Math.max(0.001, f); fill.position.y = -depth + H * f / 2; soil.visible = f > 0.98;
    trees.forEach(t => { t.visible = st > 3; t.scale.setScalar(Math.max(0.001, c(3))); });
    g.grow(crops ? c(3.5) * 2 : 0);
  };
  g.build(4); g.top = top; g.trees = trees; g.fill = fill;
  return shadowAll(g);
}
// field of chinampas separated by canals, around the origin
export function chinampaField(scene, { nx = 5, nz = 3, w = 4, l = 14, gap = 2.4, seed = 2 } = {}) {
  const list = [];
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) { const c = chinampa(w, l, { seed: seed + i * 7 + j }); c.position.set((i - (nx - 1) / 2) * (w + gap), 0, (j - (nz - 1) / 2) * (l + gap)); scene.add(c); list.push(c); }
  return list;
}
// dugout canoe with optional paddler
export function canoe({ paddler = true, color = 0x7a4a2a } = {}) {
  const g = new THREE.Group();
  // hollowed log, open on top, tapered pointed ends (the old half-cylinder was upside down and read as a solid log)
  const hm = new THREE.MeshStandardMaterial({ color, roughness: 0.8, side: THREE.DoubleSide, bumpMap: fabricTexture(17), bumpScale: 2 });
  const shell = (r0, depthK) => { const pos = [], idx = [], NU = 28, NV = 12;
    for (let i = 0; i <= NU; i++) { const u = i / NU, z = (u - 0.5) * 4.2, k = Math.pow(Math.max(0, 1 - Math.pow(Math.abs(z) / 2.1, 2.5)), 0.5);
      for (let j = 0; j <= NV; j++) { const th = Math.PI + Math.PI * j / NV; pos.push(Math.cos(th) * r0 * k, Math.sin(th) * r0 * depthK * Math.max(k, 0.25) + (1 - k) * 0.12, z); } }
    for (let i = 0; i < NU; i++) for (let j = 0; j < NV; j++) { const a = i * (NV + 1) + j, b = a + NV + 1; idx.push(a, b, a + 1, a + 1, b, b + 1); }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setIndex(idx); geo.computeVertexNormals(); return geo; };
  const hull = new THREE.Group(); hull.position.y = 0.3; g.add(hull);
  hull.add(new THREE.Mesh(shell(0.45, 0.6), hm), new THREE.Mesh(shell(0.39, 0.52), new THREE.MeshStandardMaterial({ color: 0x5a3418, roughness: 0.9, side: THREE.DoubleSide })));
  for (const sd of [-1, 1]) { const rim = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, 3.4), hm); rim.position.set(sd * 0.42, 0, 0); hull.add(rim); }
  let man = null;
  if (paddler) { man = aztec(); man.root.position.set(0, 0.1, -1.0); man.root.scale.setScalar(0.95); g.add(man.root); const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 3, 6), chMats2().post); pole.position.set(0.4, 1.0, -0.8); pole.rotation.x = 0.4; g.add(pole); g.pole = pole; }
  g.man = man;
  return shadowAll(g);
}
export function aztec(i = 0) {
  const h = romanBuilder({ color: [0xf2ece0, 0xe8d8b8, 0xf0e4d0][i % 3], skin: [0xa86a44, 0x9a6040, 0xb87850][i % 3] });
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.025, 8, 24), new THREE.MeshStandardMaterial({ color: [0xc0402a, 0x2a7a6a, 0xd8a83a][i % 3], roughness: 0.8 })); band.rotation.x = Math.PI / 2; band.position.y = 0.07; h.j.head.add(band);
  shadowAll(h.root);
  return h;
}
// Tenochtitlan's twin-temple pyramid
export function templeMayor(s = 1) {
  const M = chMats2(); const g = new THREE.Group();
  for (let i = 0; i < 5; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry((20 - i * 3.2) * s, 3 * s, (20 - i * 3.2) * s), M.white); b.position.y = (1.5 + i * 3) * s; g.add(b); }
  const stair = new THREE.Mesh(new THREE.BoxGeometry(6 * s, 16 * s, 3 * s), new THREE.MeshStandardMaterial({ color: 0xd8ccb8, roughness: 0.8 })); stair.position.set(0, 7 * s, 9 * s); stair.rotation.x = -0.75; g.add(stair);
  [[-2.5, 0x3a6ac8], [2.5, 0xc83a2a]].forEach(([x, col]) => { const sh = new THREE.Mesh(new THREE.BoxGeometry(3.6 * s, 3.6 * s, 3.6 * s), new THREE.MeshStandardMaterial({ color: col, roughness: 0.7 })); sh.position.set(x * s, 16.8 * s, 0); g.add(sh); const rf = new THREE.Mesh(new THREE.ConeGeometry(2.6 * s, 2.2 * s, 4), M.white); rf.rotation.y = Math.PI / 4; rf.position.set(x * s, 19.7 * s, 0); g.add(rf); });
  return shadowAll(g);
}
export function islandCity(scene, { at = [0, 0, -120], r = 40, seed = 3 } = {}) {
  const M = chMats2(); const R = rng(seed);
  const isl = new THREE.Mesh(new THREE.CylinderGeometry(r, r + 2, 1.2, 48), new THREE.MeshStandardMaterial({ color: 0xc8b898, roughness: 1 })); isl.position.set(at[0], 0.0, at[2]); scene.add(isl);
  const T = templeMayor(0.9); T.position.set(at[0], 0.6, at[2]); scene.add(T);
  for (let i = 0; i < 90; i++) { const a = R() * Math.PI * 2, d = 14 + R() * (r - 16); const w = 2 + R() * 3; const b = new THREE.Mesh(new THREE.BoxGeometry(w, 1.5 + R() * 2, w), M.white); b.position.set(at[0] + Math.cos(a) * d, 1.2, at[2] + Math.sin(a) * d); b.castShadow = true; scene.add(b); }
}
// colourful Xochimilco trajinera (flat boat with a painted arch)
export function trajinera(seed = 1) {
  const g = new THREE.Group(); const cols = [0xe83a5a, 0xf0c030, 0x3ab0e8, 0x5ac83a, 0xe87a2a];
  const hull = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, 7), new THREE.MeshStandardMaterial({ color: 0x3a6a3a, roughness: 0.7 })); hull.position.y = 0.2; g.add(hull);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.12, 5.4), new THREE.MeshStandardMaterial({ color: cols[seed % 5], roughness: 0.6 })); roof.position.y = 2.3; g.add(roof);
  for (const z of [-2.5, 2.5]) for (const x of [-1.1, 1.1]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.9, 8), new THREE.MeshStandardMaterial({ color: 0xf2ece0 })); p.position.set(x, 1.35, z); g.add(p); }
  const arch = new THREE.Mesh(new THREE.TorusGeometry(1.2, 0.18, 8, 24, Math.PI), new THREE.MeshStandardMaterial({ color: cols[(seed + 2) % 5], roughness: 0.6 })); arch.position.set(0, 2.3, 3.3); g.add(arch);
  return shadowAll(g);
}
