// The Explainer: how GPS knows where you are. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { RE, RS, space, earth, satellite, constellation, orbitRing, distSphere, pulse, phone, clockFace, label } from './gps.js';
import { VO } from './vo_gp.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Your phone', 2], ['*never talks*', 2], ['to *GPS*', 4], ['satellites', 1], ['It only *listens*', 3]],
  [['About *thirty*', 2], ['of them', 2], ['circle the Earth', 3], ['*20,000 km*', 3], ['up', 1]],
  [['Each one has', 3], ['*atomic clocks*', 2], ['and keeps', 2], ['broadcasting', 1], ['the *exact time*', 3], ['and *where* it is', 4]],
  [['The signal flies', 3], ['at the', 2], ['*speed of light*', 3], ['but still takes', 3], ['a *split second*', 3], ['to arrive', 2]],
  [['Your phone', 2], ['*times* that *delay*', 3], ['and works out', 3], ['*how far* away', 3], ['each satellite is', 3]],
  [['*One* distance', 2], ['puts you', 2], ['somewhere on', 2], ['a giant *sphere*', 3]],
  [['*Three* spheres', 2], ['*meet*', 1], ['at a single *point*', 4], ['on the ground', 3], ["That's *you*", 2]],
  [['A *fourth*', 2], ['satellite *corrects*', 2], ["your phone's", 2], ['cheap *clock*', 2]],
  [['Be off by', 3], ['a *millionth*', 2], ['of a second', 3], ["and you'd be", 3], ['*300 metres*', 3], ['out', 1]],
  [['Even *Einstein*', 2], ['matters', 1], ['Up there', 2], ['clocks run *fast*', 3], ["so they're *tuned*", 3], ['to make up', 3], ['for it', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.01; c.far = 900; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.6, warm: 1.0, sat: 1.15, exposure: 1.0, ao: 0 };
// a user location on the globe (lat, lon in degrees) -> vector
const geo = (lat, lon, r = RE) => { const a = lat * Math.PI / 180, b = lon * Math.PI / 180; return new THREE.Vector3(Math.cos(a) * Math.cos(b) * r, Math.sin(a) * r, Math.cos(a) * Math.sin(b) * r); };
const ME = geo(25, 20);
function orbitSet(makeStage, { sats = 30, rings = true } = {}) {
  const scene = makeStage({ shadowSize: 3, sunDir: [6, 2, 4] });
  space(scene);
  const E = earth(); scene.add(E.group);
  const K = constellation(sats); const S = K.list.map(() => { const s = satellite({ scale: 0.5 }); scene.add(s.group); return s; });
  if (rings) for (let p = 0; p < 6; p++) scene.add(orbitRing(p / 6 * Math.PI * 2));
  const v = new THREE.Vector3();
  const place2 = (t) => K.list.forEach((s, i) => { K.pos(s, t, v); S[i].group.position.copy(v); S[i].group.lookAt(0, 0, 0); S[i].group.rotateX(-Math.PI / 2); });
  return { scene, E, K, S, place2 };
}
// three fixed satellites above the user for the trilateration shots
const SAT3 = [geo(55, -10, RS), geo(10, 55, RS), geo(40, 70, RS), geo(-5, 5, RS)];

// ============ S0 hook: a phone on a map, signals raining down from the sky, nothing going up ============
function sHook({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [2, 5, 3] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x0b1a3a); u.mid.value.set(0x203a6a); u.horizon.value.set(0x3a5a8a); u.floorC.value.set(0x0b1a3a); }
  const P = phone(); P.group.rotation.x = -0.35; scene.add(P.group);
  const waves = [];
  for (let k = 0; k < 6; k++) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.012, 8, 64), new THREE.MeshBasicMaterial({ color: 0x8fe0ff, transparent: true, opacity: 0.8 })); r.rotation.x = Math.PI / 2; scene.add(r); waves.push(r); }
  const sats = [-0.9, 0.2, 1.1].map((x, i) => { const s = satellite({ scale: 0.06 }); s.group.position.set(x, 2.6 + (i % 2) * 0.3, -1.2); s.group.rotation.x = 0.3; scene.add(s.group); return s; });
  const c = C(40);
  return {
    scene, camera: c,
    update(t) {
      P.setDot(0.48, 0.52, (t * 1.2) % 1);
      waves.forEach((w, k) => { const f = ((t * 0.7 + k / 6) % 1); const src = sats[k % 3].group.position; w.position.set(lerp(src.x, 0, f), lerp(src.y, 0.15, f), lerp(src.z, 0, f)); w.scale.setScalar(lerp(0.15, 1.1, f)); w.material.opacity = 0.9 * Math.sin(Math.PI * f); });
      const k = easeInOut(range(t, 0, 4.2));
      orb(c, [0, lerp(0.3, 0.9, k), -0.2], lerp(2.6, 4.2, k), lerp(-8, 8, k), lerp(32, 18, k));
      return POST;
    },
  };
}
// ============ S1: the constellation around the Earth ============
function sOrbits({ makeStage }) {
  const O = orbitSet(makeStage);
  const c = C(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      O.place2(T * 3); O.E.group.rotation.y = T * 0.03;
      const k = easeInOut(range(t, 0, 3.7));
      orb(c, [0, 0, 0], lerp(70, 88, k), lerp(20, 40, k), lerp(18, 24, k));
      return POST;
    },
  };
}
// ============ S2: one satellite, its atomic clock time ticking out ============
function sClock({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [6, 2, 4] }); space(scene);
  const E = earth(); E.group.position.set(0, -14, -6); E.group.scale.setScalar(1.5); scene.add(E.group);
  const S = satellite({ scale: 1 }); scene.add(S.group);
  const L = label('12:00:00.000000', { size: 0.55, color: '#9fe6ff' }); L.sprite.position.set(0, 2.2, 0); scene.add(L.sprite);
  const rings = []; for (let k = 0; k < 4; k++) { const r = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 24), new THREE.MeshBasicMaterial({ color: 0x7fd8ff, transparent: true, opacity: 0.2, depthWrite: false, side: THREE.BackSide })); scene.add(r); rings.push(r); }
  const c = C(38);
  const TT = at(2, 'exact') - ls(2);
  return {
    scene, camera: c,
    update(t) {
      const us = Math.floor(t * 1e6 / 37) * 37; const sec = Math.floor(t);
      L.set(`12:00:0${Math.min(9, sec)}.${String(us % 1000000).padStart(6, '0')}`);
      S.glow.material.color.setHSL(0.55, 1, 0.6 + 0.3 * Math.sin(t * 12));
      rings.forEach((r, k) => { const f = (t * 0.6 + k / 4) % 1; r.scale.setScalar(1 + f * 9); r.material.opacity = 0.18 * (1 - f) * smooth(range(t, 0.5, 1.2)); });
      L.sprite.material.opacity = smooth(range(t, TT - 0.8, TT - 0.2)) * 0 + 1;
      const k = easeInOut(range(t, 0, 4.9));
      orb(c, [0, 0.4, 0], lerp(9, 7.5, k), lerp(-30, 10, k), lerp(8, 2, k));
      return POST;
    },
  };
}
// ============ S3: the pulse races down at light speed; a stopwatch shows the split second ============
function sTravel({ makeStage }) {
  const O = orbitSet(makeStage, { sats: 0, rings: false });
  const S = satellite({ scale: 0.9 }); S.group.position.copy(SAT3[0]); S.group.lookAt(0, 0, 0); S.group.rotateX(-Math.PI / 2); O.scene.add(S.group);
  const pin = new THREE.Mesh(new THREE.SphereGeometry(0.25, 16, 12), new THREE.MeshBasicMaterial({ color: 0x2a7bff })); pin.position.copy(ME); O.scene.add(pin);
  const Pl = pulse(); O.scene.add(Pl.group);
  const L = label('0.000 s', { size: 2.0, color: '#ffd21a' }); O.scene.add(L.sprite);
  const c = C(42);
  const TS = at(3, 'split') - ls(3);
  return {
    scene: O.scene, camera: c,
    update(t) {
      const k = smooth(range(t, 0.6, TS + 0.4)); Pl.set(SAT3[0], ME, k);
      L.set(`${(0.0700 * k).toFixed(3)} s`);
      const mid = new THREE.Vector3().lerpVectors(SAT3[0], ME, 0.5); L.sprite.position.copy(mid).add(new THREE.Vector3(0, 6, 0)); L.sprite.material.opacity = smooth(range(t, 0.4, 1.0));
      orb(c, [mid.x, mid.y, mid.z], 52, 75, 10);
      return POST;
    },
  };
}
// ============ S4: delay -> distance: a measuring line with ticks, each satellite gets its own line ============
function sDelay({ makeStage }) {
  const O = orbitSet(makeStage, { sats: 0, rings: false });
  const sats = SAT3.slice(0, 3).map((p) => { const s = satellite({ scale: 0.9 }); s.group.position.copy(p); s.group.lookAt(0, 0, 0); s.group.rotateX(-Math.PI / 2); O.scene.add(s.group); return s; });
  const pin = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12), new THREE.MeshBasicMaterial({ color: 0x2a7bff })); pin.position.copy(ME); O.scene.add(pin);
  const cols = [0xff6a5a, 0x5affa0, 0x5ab4ff];
  const lines = SAT3.slice(0, 3).map((p, i) => { const pl = pulse(cols[i]); O.scene.add(pl.group); return pl; });
  const c = C(42);
  const TE = at(4, 'each') - ls(4);
  return {
    scene: O.scene, camera: c,
    update(t) {
      lines.forEach((l, i) => { const k = smooth(range(t, i === 0 ? 0.2 : TE - 1.0 + i * 0.25, (i === 0 ? 1.6 : TE + i * 0.25))); l.set(SAT3[i], ME, k); l.group.visible = k > 0.001; });
      const k = easeInOut(range(t, 0, 4.3));
      orb(c, [ME.x * 1.8, ME.y * 1.8 + 4, ME.z * 1.8], lerp(55, 62, k), lerp(55, 75, k), lerp(12, 18, k));
      return POST;
    },
  };
}
// ============ S5 + S6: one sphere, then three spheres meeting at your point ============
function sSpheres(line) {
  return ({ makeStage }) => {
    const O = orbitSet(makeStage, { sats: 0, rings: false });
    const cols = [0xff6a5a, 0x5affa0, 0x5ab4ff];
    const sats = SAT3.slice(0, 3).map((p) => { const s = satellite({ scale: 0.9 }); s.group.position.copy(p); s.group.lookAt(0, 0, 0); s.group.rotateX(-Math.PI / 2); O.scene.add(s.group); return s; });
    const sph = SAT3.slice(0, 3).map((p, i) => { const m = distSphere(cols[i]); m.position.copy(p); m.scale.setScalar(p.distanceTo(ME)); O.scene.add(m); return m; });
    const pin = new THREE.Group(); const pinH = new THREE.Mesh(new THREE.SphereGeometry(0.45, 20, 14), new THREE.MeshBasicMaterial({ color: 0xffffff })); pin.add(pinH);
    const halo = new THREE.Mesh(new THREE.RingGeometry(0.6, 0.9, 40), new THREE.MeshBasicMaterial({ color: 0xffd21a, side: THREE.DoubleSide, transparent: true })); pin.add(halo);
    pin.position.copy(ME).multiplyScalar(1.01); pin.lookAt(ME.clone().multiplyScalar(2)); O.scene.add(pin);
    const c = C(42);
    const t0 = ls(5);
    return {
      scene: O.scene, camera: c,
      update(t, T) {
        const g = T - t0;
        const g1 = ls(6) - t0, TY = at(6, 'you') - t0;
        const a0 = smooth(range(g, 0.5, 1.5)), a1 = smooth(range(g, g1 + 0.1, g1 + 0.7)), a2 = smooth(range(g, g1 + 0.6, g1 + 1.2));
        sph[0].material.uniforms.uA.value = a0; sph[1].material.uniforms.uA.value = a1; sph[2].material.uniforms.uA.value = a2;
        sph[0].visible = a0 > 0.01; sph[1].visible = a1 > 0.01; sph[2].visible = a2 > 0.01;
        const pk = smooth(range(g, TY - 0.5, TY)); pin.visible = pk > 0.01; pin.scale.setScalar(pk * (1 + 0.15 * Math.sin(g * 8))); halo.material.opacity = 0.8;
        if (line === 5) orb(c, [0, 4, 0], lerp(110, 100, smooth(range(g, 0, 2.6))), 60, 25);
        else { const k = easeInOut(range(g, g1, g1 + 3.3)); orb(c, [lerp(0, ME.x, k), lerp(4, ME.y, k), lerp(0, ME.z, k)], lerp(100, 24, k), lerp(60, 68, k), lerp(25, 30, k)); }
        return POST;
      },
    };
  };
}
// ============ S7: a fourth satellite corrects the phone's clock ============
function sFourth({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [2, 5, 3] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x0b1a3a); u.mid.value.set(0x182c52); u.horizon.value.set(0x203a6a); u.floorC.value.set(0x0b1a3a); }
  const P = phone(); P.group.position.set(-0.55, 0, 0); scene.add(P.group);
  const CL = clockFace(); CL.group.scale.setScalar(0.42); CL.group.position.set(0.45, 0.25, 0.1); scene.add(CL.group);
  const S = satellite({ scale: 0.12 }); S.group.position.set(0.5, 2.1, -0.6); S.group.rotation.x = 0.4; scene.add(S.group);
  const Pl = pulse(0xffd21a); scene.add(Pl.group);
  const c = C(38);
  const TC = at(7, 'corrects') - ls(7);
  return {
    scene, camera: c,
    update(t) {
      const fix = smooth(range(t, TC, TC + 0.5));
      // cheap clock wobbles off, then snaps to the right time
      const off = (1 - fix) * (0.8 * Math.sin(t * 3.1) + 0.5); CL.set(20 + t + off * 6);
      CL.group.rotation.z = (1 - fix) * 0.06 * Math.sin(t * 9);
      const pk = smooth(range(t, TC - 0.9, TC)); Pl.set(S.group.position, CL.group.position, pk); Pl.group.visible = pk > 0.01 && fix < 0.99;
      orb(c, [0, 0.55, 0], 4.6, lerp(-6, 6, smooth(range(t, 0, 2.6))), 12);
      return POST;
    },
  };
}
// ============ S8: one microsecond off = 300 m: the dot jumps across the map ============
function sOff({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [2, 5, 3] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x0b1a3a); u.mid.value.set(0x182c52); u.horizon.value.set(0x203a6a); u.floorC.value.set(0x0b1a3a); }
  const P = phone(); scene.add(P.group);
  const L = label('+0.000001 s', { size: 0.17, color: '#ffd21a' }); L.sprite.position.set(0, 0.88, 0.12); scene.add(L.sprite);
  const c = C(36);
  const TM = at(8, 'millionth') - ls(8), TH = at(8, 'three') - ls(8);
  return {
    scene, camera: c,
    update(t) {
      const j = easeInOut(range(t, TH - 0.3, TH + 0.4));
      P.setDot(lerp(0.48, 0.78, j), lerp(0.52, 0.2, j), (t * 1.2) % 1); P.setGhost(0.48, 0.52, j > 0.05);
      L.sprite.material.opacity = smooth(range(t, TM - 0.2, TM + 0.2));
      orb(c, [0, 0.25, 0], lerp(3.0, 2.7, smooth(range(t, 0, 4))), 0, 4);
      return POST;
    },
  };
}
// ============ S9: a ground clock and a satellite clock; the sky one runs fast until it is tuned ============
function sEinstein({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [6, 2, 4] }); space(scene);
  const E = earth(); E.group.position.set(0, -9.5, -4); scene.add(E.group);
  const S = satellite({ scale: 0.35 }); S.group.position.set(0.4, 3.5, 0); scene.add(S.group);
  const up = clockFace(0xdff4ff); up.group.scale.setScalar(0.75); up.group.position.set(0.4, 1.9, 0.5); scene.add(up.group);
  const dn = clockFace(); dn.group.scale.setScalar(0.75); dn.group.position.set(-0.4, -1.5, 0.5); scene.add(dn.group);
  const knob = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 24), new THREE.MeshStandardMaterial({ color: 0xffd21a, metalness: 0.6, roughness: 0.3 })); knob.rotation.x = Math.PI / 2; knob.position.set(1.05, 1.25, 0.5); scene.add(knob);
  const c = C(40);
  const TF = at(9, 'fast') - ls(9), TT = at(9, 'tuned') - ls(9);
  return {
    scene, camera: c,
    update(t) {
      const tune = smooth(range(t, TT - 0.2, TT + 0.6));
      const fastK = smooth(range(t, TF - 1.2, TF)) * (1 - tune);
      dn.set(t * 10); up.set(t * 10 + fastK * t * 6);
      knob.rotation.y = tune * Math.PI * 1.5; knob.scale.setScalar(1 + 0.3 * Math.sin(Math.PI * tune));
      const k = easeInOut(range(t, 0, 5));
      orb(c, [0, 0.9, 0], lerp(10, 9, k), lerp(-8, 8, k), 6);
      return POST;
    },
  };
}

// ============ timeline ============
const SH = [sHook, sOrbits, sClock, sTravel, sDelay, sSpheres(5), sSpheres(6), sFourth, sOff, sEinstein];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
