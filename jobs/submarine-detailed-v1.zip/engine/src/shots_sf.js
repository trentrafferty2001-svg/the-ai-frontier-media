// The Explainer: how snowflakes get six arms. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { flake, lattice, vapour, water, ICE } from './snow.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_sf.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Every *snowflake*', 2], ['has *six arms*', 3], ['and it all', 3], ['comes down to', 3], ['how *water*', 2], ['*molecules*', 1], ['fit together', 2]],
  [['High in a *cloud*', 4], ['*water vapour*', 2], ['*freezes* onto', 2], ['a tiny', 2], ['*speck of dust*', 3]],
  [['Water molecules', 2], ['*lock together*', 2], ['in a *hexagon*', 3], ['pattern', 1], ['so the first', 3], ['crystal is a', 3], ['tiny *six sided*', 3], ['*plate*', 1]],
  [['As it *falls*', 3], ['more *vapour*', 2], ['*freezes*', 1], ['straight onto it', 3]],
  [['The *six corners*', 3], ['poke *furthest*', 2], ['into the', 2], ['*moist air*', 2], ['so they grab', 3], ['vapour *fastest*', 2], ['and *grow*', 2], ['into *arms*', 2]],
  [['Then the arms', 3], ['sprout *branches*', 2], ['of their own', 3]],
  [['Around', 1], ['*minus fifteen*', 2], ['degrees', 1], ['in *moist air*', 3], ['you get the', 3], ['classic', 1], ['*feathery star*', 2]],
  [['All *six arms*', 3], ['feel the *same*', 3], ['conditions', 1], ['at the same time', 4], ['so they grow', 3], ['almost', 1], ['*identically*', 1]],
  [['But *every flake*', 3], ['takes a', 2], ['*different path*', 2], ['down', 1], ['so almost', 2], ['*no two*', 2], ['are *alike*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 38) => { const c = cam(fov); c.near = 0.02; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.7, warm: 0.88, sat: 1.1, exposure: 1.05 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

// cold dark-blue "sky" with drifting snow motes
function sky(makeStage, top = 0x0e2a4a) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(top); u.mid.value.set(0x163a5e); u.horizon.value.set(0x1e4a70); u.floorC.value.set(0x0a1a2e); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xeaf6ff, 0x203a5a, 1.1));
  const key = new THREE.DirectionalLight(0xffffff, 1.6); key.position.set(2, 3, 5); scene.add(key);
  const R = rnd(3); const n = 300; const motes = new THREE.InstancedMesh(new THREE.SphereGeometry(0.02, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 }), n); scene.add(motes);
  const P = []; for (let i = 0; i < n; i++) P.push([(R() - 0.5) * 12, R(), -2 - R() * 6, 0.5 + R()]);
  const M = new THREE.Matrix4();
  scene.userData.updaters.push((T) => { P.forEach(([x, y, z, v], i) => { M.makeTranslation(x + Math.sin(T + i) * 0.1, 6 - ((y + T * 0.05 * v) % 1) * 12, z); motes.setMatrixAt(i, M); }); motes.instanceMatrix.needsUpdate = true; });
  return scene;
}
// global growth curve
function growAt(T) { return T < ls(1) ? 0 : T < ls(3) ? 0.18 * smooth(range(T, at(2, 'plate') - 1.5, at(2, 'plate'))) + 0.05 : T < ls(4) ? 0.18 + 0.05 * range(T, ls(3), ls(4)) : T < ls(5) ? lerp(0.23, 0.5, smooth(range(T, at(4, 'grow') - 1.2, le(4)))) : T < ls(6) ? lerp(0.5, 0.75, smooth(range(T, ls(5), le(5)))) : lerp(0.75, 1, smooth(range(T, ls(6), at(6, 'star')))); }

// ============ S0 hook: a snowflake grows from nothing to a full six-armed star, spinning ============
function sHook({ makeStage }) {
  const scene = sky(makeStage); const F = flake(3); scene.add(F.group);
  const c = C(36);
  return {
    scene, camera: c,
    update(t) {
      F.grow(easeOut(range(t, 0.1, 4.0))); F.group.rotation.set(0.35 * Math.sin(t * 0.6), 0.5 * Math.sin(t * 0.4), t * 0.25);
      const k = easeInOut(range(t, 0, 5.5));
      orb(c, [0, 0.3, 0], lerp(4.6, 10.5, k), 0, 4);
      return POST;
    },
  };
}
// ============ S1: a dust speck in a cloud; vapour freezes onto it ============
function sSeed({ makeStage }) {
  const scene = sky(makeStage, 0x5a7090); scene.fog = new THREE.FogExp2(0x8aa4c0, 0.12);
  const dust = new THREE.Mesh(new THREE.IcosahedronGeometry(0.06, 0), new THREE.MeshStandardMaterial({ color: 0x8a6a4a, roughness: 0.9 })); scene.add(dust);
  const F = flake(3); F.group.scale.setScalar(0.35); scene.add(F.group); const V = vapour(); scene.add(V.mesh);
  const L = tag(scene, 'dust', 0.12, '#ffe8c0', [0, -0.25, 0.2]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      V.update(T, smooth(range(T, at(1, 'vapour') - 0.3, at(1, 'vapour') + 0.3))); V.mesh.scale.setScalar(0.4);
      F.grow(0.03 + 0.12 * smooth(range(T, at(1, 'freezes') - 0.2, le(1) + 0.4))); F.group.rotation.z = T * 0.2;
      pop(L, easeOut(range(T, at(1, 'dust') - 0.2, at(1, 'dust') + 0.1)), 0.12);
      const k = easeInOut(range(t, 0, 4.1));
      orb(c, [0, 0, 0], lerp(4.0, 1.6, k), lerp(-10, 6, k), 4);
      return POST;
    },
  };
}
// ============ S2: molecules lock into a hexagon pattern; zoom out to a six-sided plate ============
function sLattice({ makeStage }) {
  const scene = sky(makeStage); const L = lattice(); scene.add(L.group);
  const F = flake(3); F.group.scale.setScalar(4); F.group.position.z = -0.5; scene.add(F.group); F.mat.transparent = true;
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      L.set(smooth(range(T, at(2, 'lock') - 0.4, at(2, 'hexagon') + 0.4)), T);
      const out = smooth(range(T, at(2, 'crystal') - 0.3, at(2, 'plate') + 0.2));
      F.grow(0.18); F.mat.opacity = out; L.group.scale.setScalar(1 - 0.85 * out); L.group.visible = out < 0.98;
      const k = easeInOut(range(t, 0, 6.3));
      orb(c, [0, 0, 0], lerp(7.5, 8.5, k) + out * 2, 0, 0);
      return POST;
    },
  };
}
// ============ S3: falling plate collects vapour ============
function sFall({ makeStage }) {
  const scene = sky(makeStage); const F = flake(3); scene.add(F.group); const V = vapour(220, 9); scene.add(V.mesh);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      F.grow(growAt(T)); F.group.rotation.set(0.5, 0.3 * Math.sin(T), T * 0.3); V.update(T, 1, 0.35);
      const k = easeInOut(range(t, 0, 2.8));
      orb(c, [0, 0, 0], lerp(3.2, 2.6, k), lerp(10, -6, k), lerp(20, 10, k));
      return POST;
    },
  };
}
// ============ S4: corners reach into moist air, grab vapour fastest, grow arms ============
function sArms({ makeStage }) {
  const scene = sky(makeStage); const F = flake(3); scene.add(F.group); const V = vapour(260, 11); scene.add(V.mesh);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      const g = growAt(T); F.grow(g); F.group.rotation.z = T * 0.05;
      const rc = 0.08 + 0.32 * Math.min(1, g / 0.3); const L = Math.max(0, (g - 0.22) / 0.78) * 1.6; V.update(T, 1, rc + L, 1);
      const k = easeInOut(range(t, 0, 5.7));
      orb(c, [0, 0, 0], lerp(3.4, 6.5, k), 0, lerp(0, 4, k));
      return POST;
    },
  };
}
// ============ S5: branches sprout ============
function sBranch({ makeStage }) {
  const scene = sky(makeStage); const F = flake(3); scene.add(F.group);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      F.grow(growAt(T)); F.group.rotation.z = T * 0.05;
      const k = easeInOut(range(t, 0, 2.3));
      orb(c, [0.6, 0.35, 0], lerp(2.4, 2.0, k), lerp(20, 8, k), lerp(14, 6, k));
      return POST;
    },
  };
}
// ============ S6: -15 C, moist: the classic feathery star ============
function sStar({ makeStage }) {
  const scene = sky(makeStage); const F = flake(3); scene.add(F.group);
  const L = tag(scene, '−15°C', 0.9, '#9fd8ff', [0, 3.1, 0]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      F.grow(growAt(T)); F.group.rotation.set(0.2 * Math.sin(T * 0.5), 0.25 * Math.sin(T * 0.4), T * 0.08);
      pop(L, easeOut(range(T, at(6, 'minus') - 0.15, at(6, 'minus') + 0.2)), 0.9);
      const k = easeInOut(range(t, 0, 4.5));
      orb(c, [0, 0.3, 0], lerp(10.5, 11.5, k), 0, 4);
      return POST;
    },
  };
}
// ============ S7: all six arms see the same conditions: highlight sweep around the arms ============
function sSame({ makeStage }) {
  const scene = sky(makeStage); const F = flake(3); scene.add(F.group); F.grow(1);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.03, 8, 96), new THREE.MeshBasicMaterial({ color: 0x9ae6ff, transparent: true, opacity: 0, toneMapped: false })); scene.add(ring);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      F.group.rotation.set(0, 0, T * 0.1); ring.scale.setScalar(0.5 + ((T * 0.4) % 1) * 1.2); ring.material.opacity = 0.6 * (1 - ((T * 0.4) % 1)) * smooth(range(T, at(7, 'same') - 0.3, at(7, 'same')));
      const k = easeInOut(range(t, 0, 5.5));
      orb(c, [0, 0.3, 0], lerp(11.5, 10.5, k), lerp(-6, 6, k), 2);
      return POST;
    },
  };
}
// ============ S8: different paths -> different flakes, falling together ============
function sMany({ makeStage }) {
  const scene = sky(makeStage); const R = rnd(21); const Fs = [];
  for (let i = 0; i < 7; i++) { const f = flake(10 + i * 7, { K: 3 + (i % 4), armMax: 1.2 + R() * 0.6 }); f.grow(0.8 + R() * 0.2); f.group.scale.setScalar(0.38 + R() * 0.14); scene.add(f.group); Fs.push({ f, x: (i % 2 ? 0.9 : -0.9) + (R() - 0.5) * 0.4, y: 3.2 - i * 1.15, z: -R() * 1.5, s: R() }); }
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      Fs.forEach(({ f, x, y, z, s }) => { f.group.position.set(x + 0.3 * Math.sin(t * 0.8 + s * 6), y - t * 0.25, z); f.group.rotation.set(0.4 * Math.sin(t + s * 4), 0.4 * Math.cos(t * 0.7 + s), t * 0.3 * (s - 0.5)); });
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [0, lerp(0, -0.8, k), -0.8], lerp(9, 10, k), 0, 2);
      return { ...POST, bloom: 0.4 };
    },
  };
}

const SH = [sHook, sSeed, sLattice, sFall, sArms, sBranch, sStar, sSame, sMany];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
