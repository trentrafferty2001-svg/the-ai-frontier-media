// The Explainer: how a fridge pushes heat out. Kitchen set, x-ray fridge with the refrigerant loop, close-up sets.
// Units: metres. Fridge 0.7 x 1.8 x 0.68, standing on the floor at the origin, door facing +z.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TIME } from './world.js';
import { rng } from './textures.js';

export const FW = 0.7, FH = 1.8, FD = 0.68;
const HOT = new THREE.Color(0xff3b1f), WARM = new THREE.Color(0xffa040), NEU = new THREE.Color(0xe8e8f0), COLD = new THREE.Color(0x2a6bff), ICE = new THREE.Color(0x9fd8ff);
const NOISE = `
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vnoise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(hash12(i), hash12(i+vec2(1,0)), f.x), mix(hash12(i+vec2(0,1)), hash12(i+vec2(1,1)), f.x), f.y); }
float fbm(vec2 p){ float s = 0.0, a = 0.5; for (int i = 0; i < 4; i++){ s += a * vnoise(p); p *= 2.03; a *= 0.5; } return s; }`;

// ---------------- kitchen ----------------
export function kitchen(scene, { warm = 1 } = {}) {
  const u = scene.userData.sky.material.uniforms;
  if (u.top) { u.top.value.set(0xf3e6d2); u.mid.value.set(0xf3e6d2); u.horizon.value.set(0xf3e6d2); u.floorC.value.set(0xd8c8b0); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  const key = scene.userData.key; key.position.set(1.6, 3.2, 2.4); key.target.position.set(0, 0.8, 0); key.intensity = 1.7; key.color.set(0xfff0dc);
  const sc = key.shadow.camera; sc.left = sc.bottom = -2.5; sc.right = sc.top = 2.5; sc.near = 0.5; sc.far = 10; sc.updateProjectionMatrix();
  // floor tiles
  const fm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.55 });
  fm.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWk;').replace('#include <project_vertex>', '#include <project_vertex>\nvWk = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vWk;').replace('#include <color_fragment>', `#include <color_fragment>
      vec2 q = vWk.xz / 0.4; vec2 f = fract(q); float ch = mod(floor(q.x) + floor(q.y), 2.0);
      float grout = step(0.97, max(f.x, f.y)) + step(max(f.x, f.y), 0.03);
      diffuseColor.rgb *= mix(mix(vec3(0.93, 0.9, 0.85), vec3(0.62, 0.68, 0.74), ch), vec3(0.55), clamp(grout, 0.0, 1.0) * 0.6);`);
  };
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), fm); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  // back wall with a tiled backsplash
  const wm = new THREE.MeshStandardMaterial({ color: 0xd9c19a, roughness: 0.9 });
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(14, 5), wm); wall.position.set(0, 2.5, -0.9); wall.receiveShadow = true; scene.add(wall);
  const side = new THREE.Mesh(new THREE.PlaneGeometry(8, 5), wm); side.rotation.y = Math.PI / 2; side.position.set(-4.5, 2.5, 2); side.receiveShadow = true; scene.add(side);
  // counter with cupboards to the right of the fridge, upper cupboards
  const cab = new THREE.MeshStandardMaterial({ color: 0x5f8f7a, roughness: 0.6 }), top = new THREE.MeshStandardMaterial({ color: 0xe9e4dc, roughness: 0.35 });
  const knob = new THREE.MeshStandardMaterial({ color: 0xc9a46a, metalness: 0.8, roughness: 0.3 });
  for (let k = 0; k < 3; k++) {
    const x = 0.85 + k * 0.62;
    const c = new THREE.Mesh(new RoundedBoxGeometry(0.6, 0.86, 0.6, 2, 0.015), cab); c.position.set(x, 0.43, -0.55); c.castShadow = c.receiveShadow = true; scene.add(c);
    const k1 = new THREE.Mesh(new THREE.SphereGeometry(0.018, 12, 8), knob); k1.position.set(x + 0.2, 0.7, -0.24); scene.add(k1);
    const uc = new THREE.Mesh(new RoundedBoxGeometry(0.6, 0.7, 0.34, 2, 0.015), cab); uc.position.set(x, 1.95, -0.71); uc.castShadow = true; scene.add(uc);
  }
  const ct = new THREE.Mesh(new RoundedBoxGeometry(1.9, 0.05, 0.64, 2, 0.01), top); ct.position.set(1.47, 0.885, -0.55); ct.castShadow = ct.receiveShadow = true; scene.add(ct);
  // a pot plant and a kettle on the counter
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.055, 0.12, 20), new THREE.MeshStandardMaterial({ color: 0xc8643c, roughness: 0.8 })); pot.position.set(2.1, 0.97, -0.6); scene.add(pot);
  const leafM = new THREE.MeshStandardMaterial({ color: 0x3f8f45, roughness: 0.7 });
  for (let k = 0; k < 7; k++) { const l = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), leafM); l.scale.set(0.5, 1.5, 0.3); const a = k / 7 * Math.PI * 2; l.position.set(2.1 + Math.cos(a) * 0.04, 1.1, -0.6 + Math.sin(a) * 0.04); l.rotation.set(Math.sin(a) * 0.5, 0, Math.cos(a) * 0.5); scene.add(l); }
  const ket = new THREE.Mesh(new THREE.SphereGeometry(0.1, 24, 16), new THREE.MeshStandardMaterial({ color: 0xd94b3d, roughness: 0.3, metalness: 0.2 })); ket.scale.set(1, 0.9, 1); ket.position.set(1.2, 1.0, -0.55); ket.castShadow = true; scene.add(ket);
  const wl = new THREE.PointLight(0xffd9a8, 1.4 * warm, 6); wl.position.set(0.5, 2.3, 1.2); scene.add(wl);
  scene.add(new THREE.HemisphereLight(0xfff2e0, 0x8a7a66, 0.4));
  return { floor };
}

// wall thermometer: red bar height set by .set(k 0..1)
export function thermometer() {
  const g = new THREE.Group();
  const board = new THREE.Mesh(new RoundedBoxGeometry(0.1, 0.42, 0.02, 2, 0.01), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 })); g.add(board);
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.32, 12), new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transparent: true, opacity: 0.4 })); glass.position.set(0, 0.03, 0.02); g.add(glass);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.02, 16, 12), new THREE.MeshStandardMaterial({ color: 0xe0202a, emissive: 0x801010, emissiveIntensity: 0.4 })); bulb.position.set(0, -0.15, 0.02); g.add(bulb);
  const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 1, 10), bulb.material); bar.position.set(0, 0, 0.02); g.add(bar);
  const tickM = new THREE.MeshBasicMaterial({ color: 0x333333 });
  for (let k = 0; k < 8; k++) { const tk = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.003, 0.002), tickM); tk.position.set(0.03, -0.11 + k * 0.035, 0.012); g.add(tk); }
  const set = (k) => { const h = 0.04 + 0.26 * k; bar.scale.y = h; bar.position.y = -0.14 + h / 2; };
  set(0.3);
  return { group: g, set };
}

// heat shimmer: additive rising orange (or sinking blue) wisps on a camera-facing-ish quad
export function haze({ w = 0.6, h = 1.6, color = 0xff7a2a, dir = 1, amt = { value: 1 } } = {}) {
  const m = new THREE.ShaderMaterial({
    uniforms: { uTime: TIME, uC: { value: new THREE.Color(color) }, uA: amt, uDir: { value: dir } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: NOISE + `uniform float uTime, uA, uDir; uniform vec3 uC; varying vec2 vUv;
      void main(){ vec2 q = vec2(vUv.x * 3.0, vUv.y * 2.0 - uDir * uTime * 0.6);
        float n = fbm(q + vec2(fbm(q * 1.7 + uTime * 0.2) * 1.5, 0.0));
        float wisps = smoothstep(0.45, 0.8, n) * sin(vUv.x * 3.14159) * (uDir > 0.0 ? smoothstep(0.0, 0.15, vUv.y) * (1.0 - vUv.y) : smoothstep(1.0, 0.85, vUv.y) * vUv.y);
        gl_FragColor = vec4(uC, clamp(wisps * uA * 0.6, 0.0, 0.85)); }`,
    transparent: true, depthWrite: false, blending: THREE.NormalBlending, side: THREE.DoubleSide,
  });
  const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m); p.renderOrder = 5; return p;
}

// ---------------- fridge with the loop ----------------
function serp(pts, x0, x1, y0, y1, rows, z) { // serpentine path between y0 and y1 (rows runs), adds to pts
  for (let r = 0; r <= rows; r++) { const y = y0 + (y1 - y0) * r / rows; const a = r % 2 ? x1 : x0, b = r % 2 ? x0 : x1; pts.push(new THREE.Vector3(a, y, z), new THREE.Vector3(b, y, z)); }
}
export function fridge({ seed = 1 } = {}) {
  const G = new THREE.Group();
  const xr = { value: 0 };
  const shell = new THREE.MeshPhysicalMaterial({ color: 0xe6ebf0, roughness: 0.25, clearcoat: 0.8, clearcoatRoughness: 0.2, transparent: true });
  shell.onBeforeCompile = (sh) => {
    sh.uniforms.uX = xr;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vNf; varying vec3 vPf;').replace('#include <project_vertex>', '#include <project_vertex>\nvNf = normalize(mat3(modelMatrix) * objectNormal); vPf = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec3 vNf; varying vec3 vPf; uniform float uX;')
      .replace('#include <opaque_fragment>', `#include <opaque_fragment>
        float fr = pow(1.0 - abs(dot(normalize(vNf), normalize(cameraPosition - vPf))), 2.0);
        gl_FragColor.rgb = mix(gl_FragColor.rgb, gl_FragColor.rgb * 0.7 + vec3(0.5, 0.8, 1.0) * fr * 0.6, uX);
        gl_FragColor.a = mix(1.0, 0.1 + 0.5 * fr, uX);`);
  };
  const body = new THREE.Group(); G.add(body);
  // cabinet as five walls so the inside can be seen when the door opens
  const T = 0.05;
  const wall = (w, h, d, x, y, z) => { const m = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 2, 0.012), shell); m.position.set(x, y, z); m.castShadow = true; body.add(m); return m; };
  wall(T, FH, FD, -FW / 2 + T / 2, FH / 2 + 0.04, 0); wall(T, FH, FD, FW / 2 - T / 2, FH / 2 + 0.04, 0);
  wall(FW, T, FD, 0, FH + 0.04 - T / 2, 0); wall(FW, 0.16, FD, 0, 0.12, 0); wall(FW, FH, T, 0, FH / 2 + 0.04, -FD / 2 + T / 2);
  const divider = wall(FW - 2 * T, 0.05, FD - T, 0, 1.28, T / 2);
  // feet
  const footM = new THREE.MeshStandardMaterial({ color: 0x333333, roughness: 0.6 });
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => { const f = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.04, 10), footM); f.position.set(a * 0.29, 0.02, b * 0.28); G.add(f); });
  // inside liner (light grey), shelves, light
  const liner = new THREE.MeshStandardMaterial({ color: 0xcdd8e0, roughness: 0.5, side: THREE.BackSide });
  const inner = new THREE.Mesh(new THREE.BoxGeometry(FW - 2 * T - 0.004, FH - 0.21 - T, FD - T - 0.004), liner); inner.position.set(0, 0.2 + (FH - 0.21 - T) / 2, T / 2); body.add(inner);
  const glassM = new THREE.MeshPhysicalMaterial({ color: 0xdff4ff, roughness: 0.05, transparent: true, opacity: 0.35, depthWrite: false });
  [0.62, 0.98].forEach((y) => { const s = new THREE.Mesh(new THREE.BoxGeometry(FW - 2 * T - 0.01, 0.01, FD - T - 0.06), glassM); s.position.set(0, y, 0.0); body.add(s); });
  const lamp = new THREE.PointLight(0xe8f4ff, 0, 1.2); lamp.position.set(0, 1.18, 0.05); body.add(lamp);
  // food
  const food = new THREE.Group(); body.add(food);
  const R = rng(seed);
  const milk = new THREE.Group(); const mk = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.18, 0.08), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 })); mk.position.y = 0.09; milk.add(mk);
  const roof = new THREE.Mesh(new THREE.CylinderGeometry(0.0566, 0.0566, 0.08, 4, 1), new THREE.MeshStandardMaterial({ color: 0x2f6fd8, roughness: 0.6 })); roof.rotation.set(0, Math.PI / 4, Math.PI / 2); roof.scale.set(1, 1, 0.5); roof.position.y = 0.2; milk.add(roof);
  const band = new THREE.Mesh(new THREE.BoxGeometry(0.082, 0.05, 0.082), roof.material); band.position.y = 0.1; milk.add(band);
  milk.position.set(-0.17, 0.63, 0.02); food.add(milk);
  const appM = new THREE.MeshStandardMaterial({ color: 0xd32f2f, roughness: 0.35 });
  for (let k = 0; k < 4; k++) { const a = new THREE.Mesh(new THREE.SphereGeometry(0.04, 18, 14), appM); a.scale.y = 0.9; a.position.set(0.04 + (k % 2) * 0.08, 0.665 + (k > 1 ? 0.0 : 0), -0.06 + Math.floor(k / 2) * 0.09); food.add(a); }
  const botM = new THREE.MeshPhysicalMaterial({ color: 0x3a9a5a, roughness: 0.1, transparent: true, opacity: 0.8 });
  for (let k = 0; k < 2; k++) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.22, 16), botM); b.position.set(-0.16 + k * 0.08, 1.1, -0.06); food.add(b); const n = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.03, 0.06, 12), botM); n.position.set(-0.16 + k * 0.08, 1.24, -0.06); food.add(n); }
  const cheese = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.06, 3, 1, false, 0, 1.2), new THREE.MeshStandardMaterial({ color: 0xf2c94c, roughness: 0.5 })); cheese.position.set(0.12, 1.02, 0.0); food.add(cheese);
  const cake = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.07, 24), new THREE.MeshStandardMaterial({ color: 0xf5d0dc, roughness: 0.6 })); cake.position.set(0.1, 0.24, 0.0); food.add(cake);
  const cherry = new THREE.Mesh(new THREE.SphereGeometry(0.015, 10, 8), appM); cherry.position.set(0.1, 0.29, 0); food.add(cherry);
  // door (hinged on the left edge), handle
  const door = new THREE.Group(); door.position.set(FW / 2, 0, FD / 2); G.add(door);
  const dPanel = new THREE.Mesh(new RoundedBoxGeometry(FW, FH - 0.08, 0.06, 3, 0.02), shell); dPanel.position.set(-FW / 2, FH / 2 + 0.08, 0.03); dPanel.castShadow = true; door.add(dPanel);
  const hM = new THREE.MeshStandardMaterial({ color: 0xb9c2cc, metalness: 0.9, roughness: 0.25 });
  const handle = new THREE.Mesh(new THREE.CapsuleGeometry(0.012, 0.42, 4, 10), hM); handle.position.set(-FW + 0.06, 1.0, 0.09); door.add(handle);
  const hl1 = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 0.04, 8), hM); hl1.rotation.x = Math.PI / 2; hl1.position.set(-FW + 0.06, 1.18, 0.07); door.add(hl1);
  const hl2 = hl1.clone(); hl2.position.y = 0.82; door.add(hl2);
  const seam = new THREE.Mesh(new THREE.BoxGeometry(FW - 0.02, 0.006, 0.004), new THREE.MeshStandardMaterial({ color: 0xbfc5cc })); seam.position.set(-FW / 2, 1.3, 0.062); door.add(seam);

  // ---- refrigerant loop (G space) ----
  const zC = -FD / 2 - 0.035, zE = -FD / 2 + T + 0.02;
  const P = [];
  const cmp = new THREE.Vector3(0.14, 0.12, -FD / 2 - 0.09);
  P.push(cmp.clone().add(new THREE.Vector3(0.0, 0.08, 0)));               // compressor outlet
  P.push(new THREE.Vector3(0.27, 0.3, zC), new THREE.Vector3(0.27, 1.66, zC)); // riser to the top of the condenser
  const s0 = P.length; serp(P, 0.27, -0.27, 1.66, 0.36, 10, zC); const s1 = P.length; // condenser: top to bottom
  P.push(new THREE.Vector3(-0.3, 0.3, zC + 0.01), new THREE.Vector3(-0.31, 0.6, zC + 0.02), new THREE.Vector3(-0.31, 1.6, zC + 0.02)); // capillary up the side
  P.push(new THREE.Vector3(-0.31, 1.7, zC + 0.04), new THREE.Vector3(-0.24, 1.72, zE));                  // through the back wall
  const e0 = P.length; serp(P, -0.24, 0.24, 1.72, 1.36, 6, zE); const e1 = P.length;   // evaporator (freezer back)
  P.push(new THREE.Vector3(0.27, 1.34, zE - 0.03), new THREE.Vector3(0.3, 1.3, zC + 0.03), new THREE.Vector3(0.05, 0.5, zC + 0.02), cmp.clone().add(new THREE.Vector3(-0.06, 0.07, 0))); // suction line home
  const curve = new THREE.CatmullRomCurve3(P, false, 'centripetal', 0.2);
  // arc-length fractions of the sections
  const lens = curve.getLengths(1200); const Ltot = lens[lens.length - 1];
  const frac = (i) => { const pts = curve.getSpacedPoints(1200); let best = 0, bd = 1e9; for (let k = 0; k < pts.length; k++) { const d = pts[k].distanceToSquared(P[i]); if (d < bd) { bd = d; best = k; } } return best / 1200; };
  const F = { cond0: frac(s0), cond1: frac(s1 - 1), cap1: frac(e0), evap1: frac(e1 - 1) };
  const tubeM = new THREE.MeshPhysicalMaterial({ color: 0x9aa3ad, roughness: 0.3, metalness: 0.4, transparent: true, opacity: 1 });
  const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 900, 0.013, 8), tubeM); tube.castShadow = true; G.add(tube);
  const condCurve = new THREE.CatmullRomCurve3(P.slice(s0 - 1, s1), false, 'centripetal', 0.2);
  const hotM = new THREE.MeshStandardMaterial({ color: 0xff6a2a, emissive: 0xff4a10, emissiveIntensity: 0, roughness: 0.4, transparent: true, opacity: 0 });
  const hotTube = new THREE.Mesh(new THREE.TubeGeometry(condCurve, 600, 0.015, 8), hotM); G.add(hotTube);
  const coldL = new THREE.PointLight(0x4f9bff, 0, 1.6); coldL.position.set(0, 1.0, 0.05); G.add(coldL);
  // condenser wire grid (black) behind the coil
  const wireM = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.6 });
  for (let k = 0; k < 9; k++) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.002, 0.002, 1.36, 4), wireM); w.position.set(-0.24 + k * 0.06, 1.01, zC + 0.013); G.add(w); }
  // frost on the evaporator (grows with .frost)
  const frostM = new THREE.MeshStandardMaterial({ color: 0xf4fbff, roughness: 0.9, transparent: true, opacity: 0, emissive: 0x9fd8ff, emissiveIntensity: 0.2 });
  const evCurve = new THREE.CatmullRomCurve3(P.slice(e0, e1), false, 'centripetal', 0.2);
  const frost = new THREE.Mesh(new THREE.TubeGeometry(evCurve, 300, 0.016, 8), frostM); G.add(frost);
  // compressor: black dome canister with a copper stub
  const cM = new THREE.MeshStandardMaterial({ color: 0x1d1f22, roughness: 0.45, metalness: 0.3, emissive: new THREE.Color(0xff3010), emissiveIntensity: 0 });
  const comp = new THREE.Group(); comp.position.copy(cmp); G.add(comp);
  const can = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.06, 6, 20), cM); can.scale.set(1.15, 1, 0.9); comp.add(can); can.castShadow = true;
  const baseP = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.012, 0.16), new THREE.MeshStandardMaterial({ color: 0x555a60 })); baseP.position.y = -0.105; comp.add(baseP);
  // refrigerant dots
  const NB = 200;
  const dots = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 8, 6), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.55, roughness: 0.4 }), NB);
  dots.frustumCulled = false; G.add(dots);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), sc = new THREE.Vector3(), col = new THREE.Color();
  const tempAt = (u) => { // colour along the loop
    if (u < F.cond0) return col.copy(HOT);
    if (u < F.cond1) { const k = (u - F.cond0) / (F.cond1 - F.cond0); return k < 0.6 ? col.copy(HOT).lerp(WARM, k / 0.6) : col.copy(WARM).lerp(NEU, (k - 0.6) / 0.4); }
    if (u < F.cap1) { const k = (u - F.cond1) / (F.cap1 - F.cond1); return col.copy(NEU).lerp(COLD, THREE.MathUtils.smoothstep(k, 0.7, 1.0)); }
    if (u < F.evap1) { const k = (u - F.cap1) / (F.evap1 - F.cap1); return col.copy(COLD).lerp(ICE, k); }
    const k = (u - F.evap1) / (1 - F.evap1); return col.copy(ICE).lerp(NEU, k).lerp(HOT, THREE.MathUtils.smoothstep(k, 0.85, 1.0));
  };
  const liquid = (u) => u > F.cond0 + (F.cond1 - F.cond0) * 0.55 && u < F.cap1 + 0.01;
  const st = { coil: 0, cold: 0, xray: 0, door: 0, flow: 1, run: 1, frost: 0, compGlow: 0, lamp: 0, dots: 1, highlight: null };
  let phase = 0, lastT = null;
  function update(t) {
    xr.value = st.xray;
    hotM.opacity = st.coil; hotM.emissiveIntensity = 1.4 * st.coil; hotTube.visible = st.coil > 0.01;
    coldL.intensity = 2.0 * st.cold;
    tubeM.opacity = 1 - 0.55 * st.xray;
    door.rotation.y = st.door * 1.9;
    lamp.intensity = st.lamp * 0.45;
    frostM.opacity = st.frost * 0.85; frost.scale.setScalar(1);
    cM.emissiveIntensity = st.compGlow * 0.8;
    const s = 1 + 0.004 * Math.sin(t * 60) * st.run; can.scale.set(1.15 * s, s, 0.9 * s);
    // phase integrates speed so changing flow never jumps backwards
    phase = t * 0.05 * st.flow; // pure function of t (farm renders frames in separate chunks)
    dots.visible = st.dots > 0.01;
    for (let i = 0; i < NB; i++) {
      const u = ((i / NB + phase) % 1 + 1) % 1;
      curve.getPointAt(u, v);
      const r = (liquid(u) ? 0.0125 : 0.009) * st.dots;
      sc.set(r, r, r); m4.compose(v, q, sc); dots.setMatrixAt(i, m4);
      dots.setColorAt(i, tempAt(u));
    }
    dots.instanceMatrix.needsUpdate = true; if (dots.instanceColor) dots.instanceColor.needsUpdate = true;
  }
  update(0);
  return { group: G, door, food, st, update, curve, F, comp, cmp, zC, zE, evCurve, lamp, parts: { milk, cake, cheese } };
}

// ---------------- close-up sets ----------------
// piston in a glass cylinder squeezing gas dots; .set(k) 0 = open, 1 = squeezed (dots hot)
export function pistonSet(scene) {
  const g = new THREE.Group(); scene.add(g);
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.62, 48, 1, true), new THREE.MeshPhysicalMaterial({ color: 0xdfefff, roughness: 0.05, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false }));
  glass.position.y = 0.31; g.add(glass);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.012, 10, 48), new THREE.MeshStandardMaterial({ color: 0x8a939c, metalness: 0.8, roughness: 0.3 })); rim.rotation.x = Math.PI / 2; g.add(rim);
  const rim2 = rim.clone(); rim2.position.y = 0.62; g.add(rim2);
  const capM = new THREE.MeshStandardMaterial({ color: 0x5a6068, metalness: 0.7, roughness: 0.35 });
  const head = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.21, 0.04, 48), capM); head.position.y = 0.64; g.add(head);
  const piston = new THREE.Group(); g.add(piston);
  const pm = new THREE.Mesh(new THREE.CylinderGeometry(0.195, 0.195, 0.08, 48), new THREE.MeshStandardMaterial({ color: 0xb5bcc4, metalness: 0.85, roughness: 0.25 })); piston.add(pm);
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.5, 16), capM); rod.position.y = -0.29; piston.add(rod);
  const N = 70, R = rng(4), seeds = []; for (let i = 0; i < N; i++) seeds.push([R() * Math.PI * 2, Math.sqrt(R()) * 0.16, R(), R() * 6]);
  const dm = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.5, roughness: 0.4 });
  const dots = new THREE.InstancedMesh(new THREE.SphereGeometry(0.016, 10, 8), dm, N); dots.frustumCulled = false; g.add(dots);
  const glow = new THREE.PointLight(0xff4a20, 0, 1.5); glow.position.set(0, 0.55, 0.3); g.add(glow);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), s = new THREE.Vector3(1, 1, 1), c = new THREE.Color();
  function set(k, t) {
    const py = THREE.MathUtils.lerp(0.06, 0.46, k); piston.position.y = py;
    const lo = py + 0.05, hi = 0.6;
    for (let i = 0; i < N; i++) {
      const [a, r, h, ph] = seeds[i];
      const jig = (0.006 + 0.014 * k);
      v.set(Math.cos(a + t * 0.8) * r + Math.sin(t * 9 + ph) * jig, lo + (hi - lo) * h + Math.cos(t * 11 + ph) * jig, Math.sin(a + t * 0.8) * r);
      m4.compose(v, q, s); dots.setMatrixAt(i, m4);
      dots.setColorAt(i, c.copy(NEU).lerp(HOT, THREE.MathUtils.smoothstep(k, 0.25, 0.9)));
    }
    dots.instanceMatrix.needsUpdate = true; dots.instanceColor.needsUpdate = true;
    glow.intensity = 2.5 * THREE.MathUtils.smoothstep(k, 0.4, 1.0);
  }
  set(0, 0);
  return { group: g, set };
}

// wide pipe -> tiny tube -> wide evaporator pipe, along +x; liquid squeezes through and boils on exit; frost grows outside
export function capillarySet(scene) {
  const g = new THREE.Group(); scene.add(g);
  const rad = (x) => x < -0.15 ? 0.06 : x < 0 ? THREE.MathUtils.lerp(0.06, 0.012, (x + 0.15) / 0.15) : x < 0.7 ? 0.012 : x < 0.8 ? THREE.MathUtils.lerp(0.012, 0.07, (x - 0.7) / 0.1) : 0.07;
  const prof = []; for (let k = 0; k <= 200; k++) { const x = -0.9 + k / 200 * 2.6; prof.push(new THREE.Vector2(rad(x) + 0.004, x)); }
  const glassM = new THREE.MeshPhysicalMaterial({ color: 0xd9ecff, roughness: 0.05, transparent: true, opacity: 0.24, side: THREE.DoubleSide, depthWrite: false });
  const pipe = new THREE.Mesh(new THREE.LatheGeometry(prof, 40), glassM); pipe.rotation.z = -Math.PI / 2; g.add(pipe);
  const copper = new THREE.MeshStandardMaterial({ color: 0xc8743a, metalness: 0.85, roughness: 0.3 });
  [-0.9, 1.7].forEach((x) => { const r = new THREE.Mesh(new THREE.TorusGeometry(rad(x) + 0.006, 0.008, 8, 32), copper); r.rotation.y = Math.PI / 2; r.position.x = x; g.add(r); });
  // frost crust on the evaporator part
  const frM = new THREE.MeshStandardMaterial({ color: 0xf6fbff, roughness: 0.95, transparent: true, opacity: 0, emissive: 0xa8dcff, emissiveIntensity: 0.25 });
  const fg = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 0), frM, 900); const R = rng(12); const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), sc = new THREE.Vector3();
  for (let i = 0; i < 900; i++) { const x = 0.85 + R() * 0.85, a = R() * Math.PI * 2, s = 0.0025 + R() * 0.004; v.set(x, Math.cos(a) * 0.077, Math.sin(a) * 0.077); q.setFromEuler(new THREE.Euler(R() * 3, R() * 3, R() * 3)); m4.compose(v, q, sc.set(s, s * 1.6, s)); fg.setMatrixAt(i, m4); }
  g.add(fg);
  const N = 320, seeds = []; for (let i = 0; i < N; i++) seeds.push([R(), R() * Math.PI * 2, Math.sqrt(R()), R() * 6]);
  const dm = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.45, roughness: 0.3, transparent: true });
  const dots = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 10, 8), dm, N); dots.frustumCulled = false; g.add(dots);
  const c = new THREE.Color();
  // map a "flow coordinate" s in [0,1) to x so that dots speed up in the narrow tube
  const xs = []; { let acc = 0; const n = 400; const w = []; for (let k = 0; k < n; k++) { const x = -0.9 + (k + 0.5) / n * 2.6; const sp = 1 / Math.max(0.3, rad(x) / 0.06) ** 0.8; w.push(1 / sp); acc += 1 / sp; } let cum = 0; xs.push(-0.9); for (let k = 0; k < n; k++) { cum += w[k] / acc; xs.push(-0.9 + (k + 1) / n * 2.6); w[k] = cum; } xs.cum = [0, ...w]; }
  const xOf = (s) => { const C = xs.cum; let lo = 0, hi = C.length - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (C[m] < s) lo = m; else hi = m; } const f = (s - C[lo]) / Math.max(1e-6, C[hi] - C[lo]); return xs[lo] + (xs[hi] - xs[lo]) * f; };
  const st = { frost: 0, boil: 1 };
  function update(t) {
    frM.opacity = st.frost * 0.8; fg.visible = st.frost > 0.01;
    for (let i = 0; i < N; i++) {
      const [s0, a, r, ph] = seeds[i]; const s = (s0 + t * 0.07) % 1; const x = xOf(s);
      const rr = rad(x) * 0.8 * r; const after = x > 0.75;
      const boilK = after ? THREE.MathUtils.smoothstep(x, 0.75, 1.1) * st.boil : 0;
      v.set(x, Math.cos(a + (after ? t * 2 + ph : 0)) * rr, Math.sin(a + (after ? t * 2 + ph : 0)) * rr);
      const size = (x < 0.7 ? 0.009 : 0.0075) * (1 + 1.6 * boilK * (0.6 + 0.4 * Math.sin(ph * 5)));
      m4.compose(v, q.identity(), sc.set(size, size, size)); dots.setMatrixAt(i, m4);
      dots.setColorAt(i, x < 0.6 ? c.copy(NEU) : c.copy(NEU).lerp(COLD, THREE.MathUtils.smoothstep(x, 0.6, 0.95)));
    }
    dots.instanceMatrix.needsUpdate = true; dots.instanceColor.needsUpdate = true;
  }
  update(0);
  return { group: g, st, update };
}

// wisps of heat (orange dashes) flowing along a curve, e.g. food -> evaporator, or condenser -> room
export function heatStream(curve, { color = 0xff8a3a, r = 0.012, amt = { value: 1 }, speed = 0.5 } = {}) {
  const m = new THREE.ShaderMaterial({
    uniforms: { uTime: TIME, uC: { value: new THREE.Color(color) }, uA: amt, uS: { value: speed } },
    vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
    fragmentShader: `uniform float uTime, uA, uS; uniform vec3 uC; varying vec2 vUv;
      void main(){ float d = fract(vUv.x * 6.0 - uTime * uS * 3.0); float dash = smoothstep(0.0, 0.2, d) * smoothstep(0.75, 0.45, d);
        float ends = smoothstep(0.0, 0.08, vUv.x) * smoothstep(1.0, 0.85, vUv.x);
        gl_FragColor = vec4(uC, dash * ends * uA * 0.95); }`,
    transparent: true, depthWrite: false, blending: THREE.NormalBlending,
  });
  const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, 80, r, 8), m); mesh.renderOrder = 6; return mesh;
}

// cartoon heat lines: wavy orange strokes that rise, wiggle and fade; group.userData.amt (0..1)
export function heatLines({ n = 9, w = 0.6, h = 1.2, color = 0xff7a2a, rise = 0.35, seed = 3, len = 0.32 } = {}) {
  const g = new THREE.Group(); const R = rng(seed); const items = [];
  const pts = []; for (let k = 0; k <= 30; k++) { const y = k / 30 * len; pts.push(new THREE.Vector3(Math.sin(y / len * Math.PI * 3) * 0.035, y, 0)); }
  const geo = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 60, 0.009, 6);
  for (let i = 0; i < n; i++) {
    const m = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0, depthWrite: false, fog: false });
    const mesh = new THREE.Mesh(geo, m); mesh.renderOrder = 7; g.add(mesh);
    items.push([mesh, (R() - 0.5) * w, (R() - 0.5) * 0.25, R(), 0.8 + R() * 0.5]);
  }
  g.userData.amt = 0;
  g.userData.update = (t) => {
    const A = g.userData.amt;
    items.forEach(([m, x, z, ph, sp]) => {
      const k = ((t * rise * sp / h + ph) % 1 + 1) % 1;
      m.position.set(x + Math.sin(t * 2 + ph * 9) * 0.02, k * h, z);
      m.rotation.y = Math.sin(ph * 7) * 0.6;
      m.material.opacity = A * Math.sin(Math.PI * k) * 0.95; m.visible = A > 0.01;
    });
  };
  return g;
}
