// The Explainer: how a tunnel boring machine eats through rock. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { rockMass, ring, tbm, discSet, building, person } from './tbm2.js';
import { leafyTrees, groundMat } from './hummer2.js';
import { VO } from './vo_tb2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This machine', 2], ['*eats* through', 2], ['*solid rock*', 2], ['and *builds*', 2], ['the *tunnel*', 2], ['behind it', 2], ['as it goes', 3]],
  [['At the front', 3], ['a *giant wheel*', 3], ['turns slowly', 2], ['against the *rock*', 3]],
  [["It's studded", 2], ['with *steel discs*', 3], ['each pushed', 2], ['with around', 2], ['*twenty tonnes*', 2], ['of force', 2]],
  [['As they *roll*', 3], ['the rock *cracks*', 3], ['and *chips*', 2], ['break off', 2]],
  [['*Scoops* catch', 2], ['the broken rock', 3], ['and a *conveyor belt*', 4], ['carries it *out*', 3]],
  [['But how does it', 4], ['*move forward?*', 2]],
  [['Behind the wheel', 3], ['a *robot arm*', 3], ['sets curved', 2], ['*concrete blocks*', 2], ['into a *ring*', 3]],
  [['Then giant *pistons*', 3], ['push against', 2], ['that *new ring*', 3], ['and *shove*', 2], ['the whole machine', 3], ['*ahead*', 1]],
  [['So the *tunnel wall*', 4], ['it just built', 3], ['becomes its', 2], ['*launch pad*', 2]],
  [['The *biggest* ones', 3], ['are over', 2], ['*seventeen metres*', 2], ['wide', 1], ['as tall as a', 4], ['*five storey*', 2], ['building', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 40) => { const c = cam(fov); c.near = 0.05; c.far = 400; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.45, warm: 1.05, sat: 1.12, exposure: 1.0 };
const R = 3.2, RL = 1.5;
// tunnel set: rock cutaway, machine with its face at xf, rings behind the tail
function tunnel(makeStage, { cut = true, rings = 12 } = {}) {
  const scene = makeStage({ shadowSize: 14, sunDir: [3, 8, 10] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x2a2622); u.mid.value.set(0x2a2622); u.horizon.value.set(0x2a2622); u.floorC.value.set(0x1a1816); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  const key = scene.userData.key; key.position.set(4, 10, 14); key.target.position.set(-4, 0, 0); key.intensity = 2.4;
  const sc = key.shadow.camera; sc.left = sc.bottom = -16; sc.right = sc.top = 16; sc.near = 1; sc.far = 40; sc.updateProjectionMatrix();
  scene.add(new THREE.HemisphereLight(0xfff0dc, 0x40362c, 0.6));
  const rock = rockMass(scene, { R });
  const M = tbm({ R }); scene.add(M.group); M.st.cut = cut;
  const lamps = []; for (let k = 0; k < 5; k++) { const l = new THREE.PointLight(0xffd9a0, 6, 9); l.position.set(-1.5 - k * 4, 1.6, -0.5); M.group.add(l); lamps.push(l); }
  const ringG = new THREE.Group(); scene.add(ringG);
  const ringsList = []; for (let i = 0; i < rings; i++) { const r = ring(R); ringG.add(r); ringsList.push(r); }
  // per-frame placement: machine face at xf, rings fixed in the world ending at ring0front
  const set = (xf, ring0front, nVisible = rings) => {
    M.group.position.x = xf; rock.setFace(xf, cut);
    ringsList.forEach((r, i) => { r.position.x = ring0front - i * RL; r.visible = i < nVisible; });
  };
  return { scene, rock, M, set, ringsList, ringG };
}
// in cutaway, hide ring segments on the near side so we can see in
function cutRings(list) { list.forEach((r) => r.children.forEach((m) => { const a = m.rotation.x; m.visible = Math.sin(a) < 0.3; })); }

// ============ S0 hook: the machine grinding in the cutaway, pull back along the new tunnel ============
function sHook({ makeStage }) {
  const T = tunnel(makeStage); cutRings(T.ringsList);
  const c = C(42);
  return {
    scene: T.scene, camera: c,
    update(t) {
      const xf = 0;
      T.set(xf, xf + T.M.tailX - 0.05);
      T.M.st.ram = 0; T.M.st.erect = 0.2;
      T.M.update(t);
      const k = easeInOut(range(t, 0, 4.6));
      orb(c, [lerp(-1, -7, k), lerp(0, -0.5, k), -1.2], lerp(15, 27, k), lerp(60, -48, k), lerp(8, 16, k));
      return POST;
    },
  };
}
// ============ S1: the wheel turning against the rock face ============
function sWheel({ makeStage }) {
  const T = tunnel(makeStage); cutRings(T.ringsList);
  const c = C(38);
  return {
    scene: T.scene, camera: c,
    update(t) {
      T.set(0, T.M.tailX - 0.05); T.M.update(t + 4);
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [-1.0, 0, -1.2], lerp(15, 13, k), lerp(75, 80, k), lerp(8, 12, k));
      return POST;
    },
  };
}
// ============ S2 + S3: one disc cutter, the force, the rock cracking ============
function sDisc(line) {
  return ({ makeStage }) => {
    const scene = makeStage({ shadowSize: 3, sunDir: [2, 5, 3] });
    const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x2e2a26); u.mid.value.set(0x2e2a26); u.horizon.value.set(0x2e2a26); u.floorC.value.set(0x1a1816); }
    scene.add(new THREE.HemisphereLight(0xfff0dc, 0x40362c, 0.7));
    const D = discSet(scene);
    { const wall = new THREE.Mesh(new THREE.BoxGeometry(8, 6, 0.6), D.group.children[0].material); wall.position.set(0, 2.2, -1.6); wall.receiveShadow = true; scene.add(wall); const fl = new THREE.Mesh(new THREE.BoxGeometry(8, 0.8, 4), D.group.children[0].material); fl.position.set(0, -0.41, -0.2); scene.add(fl);
      const N = 260, pg = new THREE.BufferGeometry(), P = new Float32Array(N * 3), sd = []; for (let i = 0; i < N; i++) sd.push([(Math.sin(i * 12.9) * 0.5) * 4, Math.abs(Math.sin(i * 7.3)) * 2.2, Math.sin(i * 3.1) * 1.2, i]); pg.setAttribute('position', new THREE.BufferAttribute(P, 3));
      const dust = new THREE.Points(pg, new THREE.PointsMaterial({ size: 0.02, color: 0xe8dcc8, transparent: true, opacity: 0.55, depthWrite: false })); dust.frustumCulled = false; scene.add(dust);
      const lamp = new THREE.SpotLight(0xffe0b0, 30, 9, 0.7, 0.6); lamp.position.set(1.8, 2.6, 1.6); lamp.target.position.set(-0.4, 0, 0.2); scene.add(lamp, lamp.target);
      scene.userData.updaters.push((tt) => { for (let i = 0; i < N; i++) { const [x, y, z, ph] = sd[i]; P[i * 3] = x + Math.sin(tt * 0.4 + ph) * 0.1; P[i * 3 + 1] = ((y + tt * 0.05) % 2.4); P[i * 3 + 2] = z + Math.cos(tt * 0.3 + ph) * 0.1; } pg.attributes.position.needsUpdate = true; }); }
    const c = C(36);
    const t0 = ls(2);
    return {
      scene, camera: c,
      update(t, Tg) {
        const g = Tg - t0;
        const TT = at(2, 'twenty') - t0, TR = at(3, 'roll') - t0, TC = at(3, 'cracks') - t0;
        D.st.arrow = line === 2 ? easeOut(range(g, TT - 0.6, TT)) : 1 - smooth(range(g, TR - 0.4, TR));
        D.st.press = line === 2 ? smooth(range(g, TT - 0.4, TT + 0.2)) : 1;
        D.st.x = line === 2 ? -1.2 + 0.1 * smooth(range(g, 0.5, 3.5)) : lerp(-1.1, 1.0, smooth(range(g, TR - 0.3, TR + 2.4)));
        D.st.chips = line === 2 ? 0 : smooth(range(g, TC - 0.4, TC + 0.1));
        D.update(g);
        if (line === 2) orb(c, [-1.0, 0.7, 0.3], lerp(4.2, 3.8, smooth(range(g, 0, 4))), 22, 10);
        else orb(c, [lerp(-0.6, 0.4, smooth(range(g, TR - 0.3, TR + 2.4))), 0.25, 0.2], 3.6, 28, 26);
        return { ...POST, exposure: 1.05 };
      },
    };
  };
}
// ============ S4: scoops lift the broken rock onto the conveyor ============
function sMuck({ makeStage }) {
  const T = tunnel(makeStage); cutRings(T.ringsList);
  const c = C(40);
  return {
    scene: T.scene, camera: c,
    update(t) {
      T.set(0, T.M.tailX - 0.05); T.M.update(t + 9);
      const k = easeInOut(range(t, 0, 3.7));
      orb(c, [lerp(-1.2, -4, k), lerp(-1.0, 0.0, k), -1.0], lerp(9, 11, k), lerp(-30, -45, k), lerp(14, 18, k));
      return POST;
    },
  };
}
// ============ S5: but how does it move forward? (wide, drifting to the tail) ============
function sHow({ makeStage }) {
  const T = tunnel(makeStage); cutRings(T.ringsList);
  const c = C(42);
  return {
    scene: T.scene, camera: c,
    update(t) {
      T.set(0, T.M.tailX - 0.05); T.M.update(t + 14);
      const k = easeInOut(range(t, 0, 1.9));
      orb(c, [lerp(-5, -9, k), 0, -1.2], 26, lerp(55, 48, k), 12);
      return POST;
    },
  };
}
// ============ S6: the erector swings a curved concrete block into the ring ============
function sErect({ makeStage }) {
  const T = tunnel(makeStage); cutRings(T.ringsList);
  const c = C(38);
  const TR = at(6, 'ring') - ls(6);
  const part = ring(R); T.scene.add(part); part.children.forEach((m) => { const a = m.rotation.x; if (Math.sin(a) > 0.3 || Math.abs(a - 3 * Math.PI / 2) < 0.1) m.visible = false; });
  return {
    scene: T.scene, camera: c,
    update(t) {
      T.set(0, T.M.tailX - 0.05 - RL, 12); // the ring being built sits in the tail
      // newest ring (index -1) is being built: show 5 segments, carry the 6th
      const k = easeInOut(range(t, 0.3, TR));
      T.M.st.erAngle = lerp(Math.PI, 3 * Math.PI / 2, k); part.position.x = T.M.tailX - 0.05; T.M.st.erect = smooth(range(t, TR - 1.0, TR)); T.M.st.carry = 1;
      T.M.update(t + 18);
      orb(c, [T.M.tailX - 0.5, 0.0, -1.2], lerp(12, 10.5, smooth(range(t, 0, 4))), lerp(-50, -35, smooth(range(t, 0, 4))), 10);
      return POST;
    },
  };
}
// ============ S7: pistons push on the new ring, the machine slides ahead ============
function sPush({ makeStage }) {
  const T = tunnel(makeStage); cutRings(T.ringsList);
  const c = C(40);
  const TS = at(7, 'shove') - ls(7);
  return {
    scene: T.scene, camera: c,
    update(t) {
      const d = RL * easeInOut(range(t, TS - 1.0, TS + 1.4));
      const ring0 = T.M.tailX - 0.05;
      T.set(d, ring0); T.M.st.ram = d; T.M.st.erect = 0; T.M.st.carry = 0; T.M.st.erAngle = 0;
      T.M.update(t + 22);
      orb(c, [T.M.tailX + d + 1.0, 0, -1.2], 15, -48, 10);
      return POST;
    },
  };
}
// ============ S8: ring after ring: time-lapse of the cycle ============
function sLaunch({ makeStage }) {
  const T = tunnel(makeStage, { rings: 16 }); cutRings(T.ringsList);
  const glow = new THREE.MeshStandardMaterial({ color: 0xa9a59c, emissive: 0xffa040, emissiveIntensity: 0.0, roughness: 0.85 });
  const c = C(42);
  return {
    scene: T.scene, camera: c,
    update(t) {
      const cyc = t / 0.95; const n = Math.floor(cyc), f = cyc - n;
      const push = easeInOut(range(f, 0.45, 1.0));
      const d = (n + push) * RL;
      const ring0 = T.M.tailX - 0.05 + (n + 1) * RL; // newest ring placed at the start of each cycle
      T.set(d, ring0, 16);
      T.ringsList.forEach((r, i) => { const nv = i === 0 ? f < 0.4 ? f / 0.4 : 1 : 1; r.scale.x = 1; r.visible = i > 0 || f > 0.1; });
      // highlight the newest ring while the pistons push on it
      T.ringsList[0].children.forEach((m) => { m.material = push > 0 && push < 1 ? glow : m.material; });
      glow.emissiveIntensity = 0.6 * Math.sin(Math.PI * push);
      T.M.st.ram = push * RL; T.M.st.erect = 0; T.M.st.carry = 0; T.M.st.erAngle = 0;
      T.M.update(t + 26);
      orb(c, [d - 8, 0, -1.2], 28, -55, 14);
      return POST;
    },
  };
}
// ============ S9: the biggest: a 17.5 m cutterhead beside a five storey building ============
function sBig({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.5, 0.7, 0.6], fog: 0.0015, shadowSize: 40, shadowAt: [0, 0, 0], envI: 0.9 });
  scene.userData.key.shadow.camera.far = 200;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), groundMat()); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  { const c = document.createElement('canvas'); c.width = 256; c.height = 256; const g = c.getContext('2d'); g.fillStyle = '#4a4c50'; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 6000; i++) { g.fillStyle = `rgba(${Math.random() < 0.5 ? 30 : 110},${Math.random() < 0.5 ? 30 : 110},${Math.random() < 0.5 ? 34 : 116},0.35)`; g.fillRect(Math.random() * 256, Math.random() * 256, 2, 2); } g.fillStyle = '#e8e0c0'; g.fillRect(124, 0, 8, 110); g.fillRect(124, 146, 8, 110);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(1, 30);
    const road = new THREE.Mesh(new THREE.PlaneGeometry(9, 300), new THREE.MeshStandardMaterial({ map: t, roughness: 0.85 })); road.rotation.x = -Math.PI / 2; road.rotation.z = Math.PI / 2; road.position.set(0, 0.02, -16); road.receiveShadow = true; scene.add(road);
    const walk = new THREE.Mesh(new THREE.BoxGeometry(3, 0.15, 300), new THREE.MeshStandardMaterial({ color: 0xb8b2a6, roughness: 0.8 })); walk.rotation.y = Math.PI / 2; walk.position.set(0, 0.075, -21.5); scene.add(walk);
    const bc = [0xd9c7a8, 0xc9a48a, 0xa8b8c8, 0xe0d8c8, 0xb89a7a];
    for (let i = 0; i < 8; i++) { const B = building(4 + (i * 3) % 6, { w: 10 + (i % 3) * 2, d: 9, fh: 3.5 }); B.position.set(-48 + i * 13, 0, -30 - (i % 2) * 3); B.children[0].material = B.children[0].material.clone(); B.children[0].material.color.set(bc[i % 5]); scene.add(B); }
    const carC = [0xc8352b, 0x2a6ad8, 0xf2f2f2, 0x2a2c30]; for (let i = 0; i < 6; i++) { const car = new THREE.Group(); const b = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.7, 4.2), new THREE.MeshStandardMaterial({ color: carC[i % 4], roughness: 0.3, metalness: 0.5 })); b.position.y = 0.6; car.add(b); const cab = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.6, 2.2), new THREE.MeshStandardMaterial({ color: 0x202428, roughness: 0.1, metalness: 0.6 })); cab.position.set(0, 1.2, -0.2); car.add(cab); car.rotation.y = Math.PI / 2; car.position.set(-30 + i * 11, 0, -14 - (i % 2) * 4); scene.add(car); }
    const ts = []; for (let i = 0; i < 12; i++) ts.push([-44 + i * 8, 0, -22.5]); scene.add(leafyTrees(ts, { seed: 4, leaves: 1400 })); }
  const M = tbm({ R: 8.75, seed: 3 }); M.st.cut = false; M.st.muck = 0; scene.add(M.group);
  M.group.rotation.y = -Math.PI / 2; M.group.position.set(-6, 8.95, 0); // face toward +z
  const cradle = new THREE.Mesh(new THREE.BoxGeometry(14, 1.2, 16), new THREE.MeshStandardMaterial({ color: 0x55595e, roughness: 0.7 })); cradle.position.set(-6, 0.6, -6); scene.add(cradle);
  const B = building(5, { w: 11, d: 9, fh: 3.5 }); B.position.set(11, 0, -2); scene.add(B);
  const people = [person(), person(0x2a7fd8), person(0xffffff)]; people.forEach((p, i) => { p.position.set(-1 + i * 1.2, 0, 7 + (i % 2)); p.rotation.y = 0.3 * i; scene.add(p); });
  const c = C(44);
  return {
    scene, camera: c,
    update(t) {
      M.update(t * 0.4);
      const k = easeInOut(range(t, 0, 5.5));
      place(c, [lerp(0, 2, k), lerp(2.0, 4.5, k), lerp(30, 44, k)], [lerp(-1, 1.5, k), lerp(7.5, 9, k), 0]);
      return { bloom: 0.4, warm: 1.08, sat: 1.1, exposure: 1.0, flare: 0.3 };
    },
  };
}

// ============ timeline ============
const SH = [sHook, sWheel, sDisc(2), sDisc(3), sMuck, sHow, sErect, sPush, sLaunch, sBig];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
