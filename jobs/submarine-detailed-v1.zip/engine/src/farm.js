// Props for the rice-fish short: fish, rice, water, mud, farmer, splash, bug, terraces.
import * as THREE from 'three';
import { materials } from './materials.js';
import { makeHuman } from './human.js';
import { rng, fabricTexture } from './textures.js';
import { sparks, glowSprite } from './props.js';

const shadow = o => { o.traverse(c => { if (c.isMesh) { c.castShadow = true; c.receiveShadow = true; } }); return o; };

let FM = null;
export function farmMats() {
  if (FM) return FM;
  const fab = fabricTexture(17);
  FM = {
    mud: new THREE.MeshStandardMaterial({ color: 0x6e4b31, roughness: 0.95, bumpMap: fab, bumpScale: 2 }),
    soil: new THREE.MeshStandardMaterial({ color: 0x4f3523, roughness: 1, bumpMap: fab, bumpScale: 3 }),
    grass: new THREE.MeshStandardMaterial({ color: 0x6aa84a, roughness: 0.9, bumpMap: fab, bumpScale: 1 }),
    water: new THREE.MeshPhysicalMaterial({ color: 0x7fb6a0, roughness: 0.06, transparent: true, opacity: 0.55, clearcoat: 1, side: THREE.DoubleSide, depthWrite: false }),
    waterUnder: new THREE.MeshBasicMaterial({ color: 0xcfeee0, transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false }),
    rice: new THREE.MeshStandardMaterial({ color: 0x5fae3a, roughness: 0.6 }),
    riceGold: new THREE.MeshStandardMaterial({ color: 0xd8b24a, roughness: 0.55 }),
    grain: new THREE.MeshStandardMaterial({ color: 0xe9c25a, roughness: 0.5 }),
    straw: new THREE.MeshStandardMaterial({ color: 0xd9b86a, roughness: 0.8, bumpMap: fab, bumpScale: 2 }),
    farmerCloth: new THREE.MeshStandardMaterial({ color: 0x2f5d8c, roughness: 0.9, bumpMap: fab, bumpScale: 1.2 }),
    bucket: new THREE.MeshStandardMaterial({ color: 0x8a6a48, roughness: 0.7 }),
    weed: new THREE.MeshStandardMaterial({ color: 0x3f7a2a, roughness: 0.7, side: THREE.DoubleSide }),
    pellet: new THREE.MeshStandardMaterial({ color: 0x4a3220, roughness: 0.9 }),
  };
  return FM;
}

// ---------- fish: forward is +x, length len ----------
export function fish(len = 0.3, color = 0xf08a2c) {
  const M = materials();
  const g = new THREE.Group();
  const body = new THREE.Group(); g.add(body);
  const skin = new THREE.MeshPhysicalMaterial({ color, roughness: 0.35, clearcoat: 0.8, clearcoatRoughness: 0.2, sheen: 0.4, sheenColor: new THREE.Color(0xffe0a0), emissive: new THREE.Color(color), emissiveIntensity: 0.22 });
  const belly = new THREE.MeshPhysicalMaterial({ color: 0xf6e2b8, roughness: 0.4, clearcoat: 0.6 });
  const b = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 20), skin); b.scale.set(len * 0.5, len * 0.19, len * 0.11); body.add(b);
  const bb = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), belly); bb.scale.set(len * 0.42, len * 0.13, len * 0.1); bb.position.y = -len * 0.06; body.add(bb);
  // tail
  const tailPivot = new THREE.Group(); tailPivot.position.x = -len * 0.46; body.add(tailPivot);
  const ts = new THREE.Shape(); ts.moveTo(0, 0); ts.lineTo(-len * 0.3, len * 0.2); ts.quadraticCurveTo(-len * 0.22, 0, -len * 0.3, -len * 0.2); ts.lineTo(0, 0);
  const finMat = new THREE.MeshPhysicalMaterial({ color, roughness: 0.4, transparent: true, opacity: 0.92, side: THREE.DoubleSide });
  tailPivot.add(new THREE.Mesh(new THREE.ShapeGeometry(ts), finMat));
  // dorsal + side fins
  const ds = new THREE.Shape(); ds.moveTo(len * 0.15, 0); ds.lineTo(-len * 0.05, len * 0.13); ds.lineTo(-len * 0.25, 0);
  const dorsal = new THREE.Mesh(new THREE.ShapeGeometry(ds), finMat); dorsal.position.y = len * 0.16; body.add(dorsal);
  const fins = [];
  for (const s of [1, -1]) {
    const f = new THREE.Mesh(new THREE.ShapeGeometry(ds), finMat); f.scale.setScalar(0.45);
    f.position.set(len * 0.12, -len * 0.08, s * len * 0.1); f.rotation.set(s * 1.2, 0, Math.PI); body.add(f); fins.push(f);
  }
  // big cartoon eyes
  for (const s of [1, -1]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(len * 0.055, 20, 14), M.eyeWhite); e.position.set(len * 0.3, len * 0.05, s * len * 0.075); body.add(e);
    const p = new THREE.Mesh(new THREE.SphereGeometry(len * 0.03, 16, 10), M.iris.clone()); p.material.color.set(0x111111);
    p.position.set(len * 0.33, len * 0.055, s * len * 0.105); body.add(p);
  }
  // mouth (opens via scale)
  const mouth = new THREE.Mesh(new THREE.SphereGeometry(len * 0.035, 16, 10), M.mouth); mouth.position.set(len * 0.48, -len * 0.01, 0); body.add(mouth);
  shadow(g);
  g.swim = (t, rate = 9, amp = 0.45) => {
    tailPivot.rotation.y = Math.sin(t * rate) * amp;
    body.rotation.y = -Math.sin(t * rate - 0.8) * amp * 0.12;
    for (const f of fins) f.rotation.y = Math.sin(t * rate * 0.6) * 0.3;
  };
  g.mouth = (k) => { mouth.scale.set(1, 0.4 + k * 1.6, 0.6 + k); };
  g.face = (dir) => { const d = dir.clone().normalize(); g.rotation.set(0, -Math.atan2(d.z, d.x), Math.asin(Math.max(-1, Math.min(1, d.y))), 'YZX'); };
  g.mouth(0);
  return g;
}

// ---------- rice: instanced blades; plants = [[x,z], ...] ----------
export function rice(plants, { h = 0.5, r = 0.006, golden = false, blades = 7, seed = 4, y = 0, heads = golden } = {}) {
  const F = farmMats();
  const R = rng(seed);
  const geo = new THREE.CylinderGeometry(r * 0.15, r, h, 5, 1); geo.translate(0, h / 2, 0);
  const n = plants.length * blades;
  const mesh = new THREE.InstancedMesh(geo, golden ? F.riceGold : F.rice, n);
  const headGeo = new THREE.CapsuleGeometry(r * 1.3, h * 0.12, 3, 6);
  const hm = heads ? new THREE.InstancedMesh(headGeo, F.grain, n) : null;
  const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), p = new THREE.Vector3();
  let i = 0;
  const tips = [];
  for (const [x, z] of plants) {
    for (let b = 0; b < blades; b++) {
      const yaw = R() * Math.PI * 2, tilt = 0.05 + R() * (golden ? 0.18 : 0.35), k = 0.75 + R() * 0.35;
      e.set(Math.cos(yaw) * tilt, 0, Math.sin(yaw) * tilt);
      q.setFromEuler(e); s.set(1, k, 1); p.set(x + (R() - 0.5) * r * 3, y, z + (R() - 0.5) * r * 3);
      m.compose(p, q, s); mesh.setMatrixAt(i, m);
      if (hm && b % 2 === 0) {
        const tip = new THREE.Vector3(0, h * k, 0).applyQuaternion(q).add(p);
        e.set(Math.cos(yaw) * (tilt + 0.55), 0, Math.sin(yaw) * (tilt + 0.55)); q.setFromEuler(e);
        const off = new THREE.Vector3(0, h * 0.08, 0).applyQuaternion(q);
        m.compose(tip.add(off), q, new THREE.Vector3(1, 1, 1)); hm.setMatrixAt(i, m);
      }
      i++;
    }
  }
  const g = new THREE.Group(); g.add(mesh); if (hm) g.add(hm);
  mesh.castShadow = true; mesh.receiveShadow = true; if (hm) hm.castShadow = true;
  g.blades = mesh;
  return g;
}
export function grid(x0, x1, z0, z1, step, jitter = 0, seed = 2) {
  const R = rng(seed), out = [];
  for (let x = x0; x <= x1 + 1e-6; x += step) for (let z = z0; z <= z1 + 1e-6; z += step) out.push([x + (R() - 0.5) * jitter, z + (R() - 0.5) * jitter]);
  return out;
}

// ---------- paddy: mud slab + water sheet ----------
export function paddy(w, d, { water = 0.25, mud = 0 } = {}) {
  const F = farmMats();
  const g = new THREE.Group();
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.4, d), F.mud); m.position.y = mud - 0.2; m.receiveShadow = true; g.add(m);
  const wt = new THREE.Mesh(new THREE.PlaneGeometry(w, d), F.water); wt.rotation.x = -Math.PI / 2; wt.position.y = water; wt.renderOrder = 2; g.add(wt);
  g.water = wt;
  return g;
}

// ---------- farmer: blue clothes, straw hat ----------
export function farmer() {
  const M = materials(), F = farmMats();
  const h = makeHuman('farmer');
  h.root.traverse(c => { if (c.isMesh && c.material === M.cloth) c.material = F.farmerCloth; });
  const hat = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.16, 40), F.straw);
  hat.position.y = 0.27; hat.castShadow = true; h.j.head.add(hat);
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.012, 8, 32), M.leather); band.rotation.x = Math.PI / 2; band.position.y = 0.215; h.j.head.add(band);
  return h;
}

// ---------- splash: droplets + ring; update(dt since impact) ----------
export function splash(scale = 1, seed = 5) {
  const g = new THREE.Group();
  const sp = sparks(160, { speed: 1.4 * scale, spread: 0.6, gravity: -4 * scale, life: 0.8, size: 0.016 * scale, dir: new THREE.Vector3(0, 1, 0), seed, color: [0.75, 0.9, 1] });
  g.add(sp);
  // crown of droplets: small white spheres thrown up in a ring
  const dropMat = new THREE.MeshPhysicalMaterial({ color: 0xcfe9ff, roughness: 0.05, transparent: true, opacity: 0.7, clearcoat: 1 });
  const drops = [];
  for (let i = 0; i < 18; i++) { const d = new THREE.Mesh(new THREE.SphereGeometry(0.007 * scale, 10, 8), dropMat); g.add(d); drops.push([d, (i / 18) * Math.PI * 2, 0.7 + ((i * 37) % 10) / 20]); }
  const foam = glowSprite(0xffffff, 0.2 * scale); foam.material.opacity = 0; g.add(foam);
  const ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
  const rings = [0, 0.18].map(() => { const r = new THREE.Mesh(new THREE.RingGeometry(0.9, 1, 48), ringMat.clone()); r.rotation.x = -Math.PI / 2; r.position.y = 0.002; g.add(r); return r; });
  g.update = (t) => {
    sp.update(t);
    for (const [d, a, v] of drops) {
      const on = t > 0 && t < 0.9;
      d.visible = on;
      if (on) { const r = 0.05 * scale + t * 0.35 * v * scale; d.position.set(Math.cos(a) * r, Math.max(0, (1.5 * v * t - 2.2 * t * t)) * scale, Math.sin(a) * r); }
    }
    foam.position.y = 0.01; foam.scale.setScalar((0.1 + Math.max(0, t) * 0.4) * scale);
    foam.material.opacity = t > 0 ? Math.max(0, 0.7 - t * 1.0) : 0;
    rings.forEach((r, i) => {
      const tt = t - i * 0.18;
      const on = tt > 0;
      r.scale.setScalar(on ? (0.03 + tt * 0.35) * scale : 0.001);
      r.material.opacity = on ? Math.max(0, 0.7 - tt * 0.6) : 0;
    });
  };
  g.update(-1);
  return g;
}

// ---------- planthopper bug ----------
export function bug(s = 0.03) {
  const M = materials();
  const g = new THREE.Group();
  const shell = new THREE.MeshPhysicalMaterial({ color: 0x6b8a2a, roughness: 0.3, clearcoat: 1 });
  const b = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 14), shell); b.scale.set(s * 0.5, s * 0.25, s * 0.22); g.add(b);
  const wingM = new THREE.MeshPhysicalMaterial({ color: 0xddeeff, transparent: true, opacity: 0.6, roughness: 0.1, side: THREE.DoubleSide });
  for (const z of [1, -1]) { const w = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 8), wingM); w.scale.set(s * 0.45, s * 0.04, s * 0.18); w.position.set(-s * 0.1, s * 0.15, z * s * 0.12); w.rotation.x = z * 0.3; g.add(w); }
  for (const z of [1, -1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(s * 0.08, 10, 8), M.eyeWhite); e.position.set(s * 0.42, s * 0.1, z * s * 0.1); g.add(e); }
  return shadow(g);
}

// ---------- weed with broad leaves ----------
export function weed(s = 0.12) {
  const F = farmMats();
  const g = new THREE.Group();
  for (let i = 0; i < 6; i++) {
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 8), F.weed);
    leaf.scale.set(s * 0.12, s * 0.5, s * 0.03);
    const a = i / 6 * Math.PI * 2;
    leaf.position.set(Math.cos(a) * s * 0.15, s * 0.4, Math.sin(a) * s * 0.15);
    leaf.rotation.set(Math.sin(a) * 0.6, -a, -Math.cos(a) * 0.6);
    g.add(leaf);
  }
  return shadow(g);
}

// ---------- bucket ----------
export function bucket(r = 0.13, h = 0.22) {
  const F = farmMats(), M = materials();
  const g = new THREE.Group();
  const side = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.85, h, 32, 1, true), F.bucket); side.material = F.bucket.clone(); side.material.side = THREE.DoubleSide; g.add(side);
  const bot = new THREE.Mesh(new THREE.CircleGeometry(r * 0.85, 32), F.bucket); bot.rotation.x = -Math.PI / 2; bot.position.y = -h / 2; g.add(bot);
  const w = new THREE.Mesh(new THREE.CircleGeometry(r * 0.97, 32), farmMats().water); w.rotation.x = -Math.PI / 2; w.position.y = h * 0.3; g.add(w);
  for (const y of [-h * 0.3, h * 0.35]) { const band = new THREE.Mesh(new THREE.TorusGeometry(r * (y > 0 ? 0.98 : 0.9), 0.006, 6, 32), M.steelDark); band.rotation.x = Math.PI / 2; band.position.y = y; g.add(band); }
  g.water = w;
  return shadow(g);
}

// ---------- underwater look: murky green sky + fog ----------
export function underwater(scene, color = 0x3d7a68, density = 1.4) {
  const u = scene.userData.sky.material.uniforms;
  u.top.value.set(0xbfe8d4); u.mid.value.set(0x6fae96); u.horizon.value.set(0x3d7a68); u.floorC.value.set(0x24453a);
  scene.fog = new THREE.FogExp2(color, density);
  // animated caustics on the mud (uTime driven by main.js)
  const cm = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uScale: { value: 26 } },
    vertexShader: `varying vec2 vW; void main(){ vec4 w = modelMatrix*vec4(position,1.); vW = w.xz; gl_Position = projectionMatrix*viewMatrix*w; }`,
    fragmentShader: `uniform float uTime, uScale; varying vec2 vW;
      float c(vec2 p){ vec2 i = p; float acc = 0.;
        for(int n=0;n<4;n++){ float t = uTime*0.55*(1.0-0.25*float(n));
          i = p + vec2(cos(t - i.x) + sin(t + i.y), sin(t - i.y) + cos(t + i.x));
          acc += 1.0/length(vec2(p.x/(sin(i.x+t)/0.008), p.y/(cos(i.y+t)/0.008))); }
        acc /= 4.0; acc = 1.17 - pow(clamp(acc, 0.0, 2.0), 1.4); return clamp(pow(clamp(acc, 0.0, 1.2), 8.0), 0.0, 1.5); }
      void main(){ float k = c(vW*uScale*0.25); if (!(k >= 0.0)) k = 0.0; float fade = exp(-dot(vW,vW)*1.2);
        gl_FragColor = vec4(vec3(0.75,1.0,0.8)*k*0.9*fade, 1.0); }`,
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false,
  });
  const cp = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), cm); cp.rotation.x = -Math.PI / 2; cp.position.y = 0.002; cp.renderOrder = 1;
  scene.add(cp);
  scene.userData.caustic = cm;
}

// light shaft through water
export function shaft(len = 1, w = 0.05) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(w * 0.6, w, len, 16, 1, true),
    new THREE.MeshBasicMaterial({ color: 0xeaffd8, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
  return m;
}
export { glowSprite };
