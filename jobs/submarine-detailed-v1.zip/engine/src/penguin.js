// The Explainer: how penguins survive the cold. Emperor penguin, huddle, feather patch, body section,
// countercurrent heat exchange diagram, blizzard snow. Penguin ~1.2 tall, faces +z.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.6, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
const M = { black: std(0x15181f, 0.5), white: std(0xf4f4f0, 0.7), gold: std(0xffb52a, 0.5), beak: std(0x2a2a2a, 0.4), bill: std(0xff8a3a, 0.5), foot: std(0x5a5a62, 0.7) };
const GEO = { body: new THREE.SphereGeometry(0.36, 24, 18), belly: new THREE.SphereGeometry(0.33, 24, 18), head: new THREE.SphereGeometry(0.17, 20, 14), patch: new THREE.SphereGeometry(0.07, 12, 8), beak: new THREE.ConeGeometry(0.035, 0.22, 10), flip: new THREE.SphereGeometry(0.2, 12, 8), foot: new THREE.SphereGeometry(0.08, 10, 8) };
export function penguin() {
  const G = new THREE.Group(); const body = new THREE.Group(); G.add(body);
  const b = new THREE.Mesh(GEO.body, M.black); b.scale.set(1, 1.55, 0.95); b.position.y = 0.55; body.add(b);
  const w = new THREE.Mesh(GEO.belly, M.white); w.scale.set(0.95, 1.45, 0.9); w.position.set(0, 0.52, 0.07); body.add(w);
  const h = new THREE.Mesh(GEO.head, M.black); h.position.set(0, 1.1, 0.02); body.add(h);
  [-1, 1].forEach(s => { const p = new THREE.Mesh(GEO.patch, M.gold); p.scale.set(0.6, 1.4, 1); p.position.set(s * 0.13, 1.02, 0.06); body.add(p); const f = new THREE.Mesh(GEO.flip, M.black); f.scale.set(0.25, 1.1, 0.5); f.position.set(s * 0.36, 0.6, -0.02); f.rotation.z = s * 0.15; body.add(f); });
  const bk = new THREE.Mesh(GEO.beak, M.beak); bk.rotation.x = Math.PI / 2 + 0.25; bk.position.set(0, 1.07, 0.24); body.add(bk);
  const bl = new THREE.Mesh(GEO.patch, M.bill); bl.scale.set(0.4, 0.3, 1.2); bl.position.set(0, 1.04, 0.2); body.add(bl);
  const feet = [-1, 1].map(s => { const f = new THREE.Mesh(GEO.foot, M.foot); f.scale.set(0.9, 0.35, 1.5); f.position.set(s * 0.1, 0.03, 0.12); G.add(f); return f; });
  const tail = new THREE.Mesh(GEO.foot, M.black); tail.scale.set(0.8, 0.4, 1.3); tail.position.set(0, 0.06, -0.3); body.add(tail);
  return { group: G, body, feet };
}
// a huddle: n penguins in a rough disc; layout(k, t) packs them tighter and slowly rotates/shuffles
export function huddle(n = 160, seed = 3) {
  const G = new THREE.Group(); const R = rnd(seed); const P = [];
  for (let i = 0; i < n; i++) { const p = penguin(); const r = Math.sqrt((i + 0.5) / n); const a = i * 2.39996; p.group.rotation.y = R() * 0.6 - 0.3; p.group.scale.setScalar(0.92 + R() * 0.16); G.add(p.group); P.push({ p, r, a, j: R() }); }
  function layout(pack, t, spin = 0) { const Rout = 4.6 - 1.4 * pack; P.forEach(({ p, r, a, j }) => { const aa = a + spin * t * 0.06; const rr = (r * Rout) * (1 + 0.6 * (1 - pack)) + 0.12 * Math.sin(t * 0.7 + j * 9) * 0.3; p.group.position.set(Math.cos(aa) * rr, 0, Math.sin(aa) * rr); p.body.rotation.z = 0.04 * Math.sin(t * 2 + j * 6); }); }
  layout(1, 0);
  return { group: G, P, layout };
}
// snow / blizzard streaks blowing along +x
export function blizzard(center = [0, 3, 0], size = [30, 8, 20], n = 1500, seed = 6) {
  const R = rnd(seed); const P = []; for (let i = 0; i < n; i++) P.push([R(), R(), R(), 0.7 + R() * 0.6]);
  const im = new THREE.InstancedMesh(new THREE.BoxGeometry(0.25, 0.025, 0.025), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.75 }), n); im.frustumCulled = false;
  const Mx = new THREE.Matrix4(), q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0, -0.25)), s = new THREE.Vector3(1, 1, 1);
  return { mesh: im, update(T, k = 1) { P.forEach(([x, y, z, v], i) => { const xx = ((x + T * 0.5 * v) % 1); const yy = ((y - T * 0.12 * v) % 1 + 1) % 1; Mx.compose(new THREE.Vector3(center[0] + (xx - 0.5) * size[0], center[1] + (yy - 0.5) * size[1], center[2] + (z - 0.5) * size[2]), q, s.setScalar(k > 0.01 ? k : 0.0001)); im.setMatrixAt(i, Mx); }); im.instanceMatrix.needsUpdate = true; } };
}
// feather patch: rows of overlapping scale-like feathers over fluffy down on a skin slab; warm air glow
export function featherPatch() {
  const G = new THREE.Group();
  const skin = new THREE.Mesh(new THREE.BoxGeometry(4, 0.3, 2.4), std(0xe8b8a0, 0.8)); skin.position.y = -0.3; G.add(skin);
  const R = rnd(11); const downM = std(0xf2f2ee, 1); const down = [];
  for (let i = 0; i < 120; i++) { const d = new THREE.Mesh(new THREE.IcosahedronGeometry(0.12 + R() * 0.06, 1), downM); d.position.set((R() - 0.5) * 3.8, -0.05 + R() * 0.12, (R() - 0.5) * 2.2); G.add(d); down.push(d); }
  const warm = new THREE.Mesh(new THREE.BoxGeometry(3.9, 0.28, 2.3), new THREE.MeshBasicMaterial({ color: 0xff9a40, transparent: true, opacity: 0, depthWrite: false })); warm.position.y = 0.02; G.add(warm);
  const fm = std(0x1a1d24, 0.35, 0.1); const fg = new THREE.SphereGeometry(0.32, 16, 10); const feathers = [];
  for (let r = 0; r < 7; r++) for (let c = 0; c < 9; c++) { const f = new THREE.Mesh(fg, fm); f.scale.set(1, 0.12, 0.62); f.position.set(-1.8 + c * 0.45 + (r % 2) * 0.22, 0.24 + r * 0.012, -1.05 + r * 0.33); f.rotation.x = -0.28; G.add(f); feathers.push(f); }
  return { group: G, warm, feathers, down };
}
// body section disc: feathers (black ring), fat (cream ring), warm core (red)
export function bodySection() {
  const G = new THREE.Group();
  const ring = (r0, r1, c, z) => { const m = new THREE.Mesh(new THREE.RingGeometry(r0, r1, 64), std(c, 0.7, 0, { side: THREE.DoubleSide })); m.position.z = z; G.add(m); return m; };
  const core = new THREE.Mesh(new THREE.CircleGeometry(1.45, 64), std(0xc8443a, 0.6, 0, { emissive: 0xaa2010, emissiveIntensity: 0.4 })); G.add(core);
  const fat = ring(1.45, 1.9, 0xf2e2b0, 0.002); const skin = ring(1.9, 1.98, 0xe0a890, 0.003); const feath = ring(1.98, 2.3, 0x1a1d24, 0.004);
  return { group: G, core, fat, feath };
}
// countercurrent exchange: artery (warm, down) beside vein (cold, up), blood dots, heat arrows between
export function exchanger() {
  const G = new THREE.Group(); const H = 5;
  const tube = (x, c) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, H, 24, 1, true), new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.2, transmission: 0.5, transparent: true, opacity: 0.45, side: THREE.DoubleSide })); m.position.x = x; G.add(m); return m; };
  tube(-0.45, 0xff6a5a); tube(0.45, 0x6ab0ff);
  const R = rnd(21); const dots = []; const gm = new THREE.SphereGeometry(0.09, 10, 8);
  for (let i = 0; i < 60; i++) { const art = i < 30; const m = new THREE.Mesh(gm, new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x000000, roughness: 0.4 })); G.add(m); dots.push({ m, art, ph: R(), dx: (R() - 0.5) * 0.3, dz: (R() - 0.5) * 0.3 }); }
  const arrows = []; const am = new THREE.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0, toneMapped: false });
  for (let k = 0; k < 5; k++) { const a = new THREE.Group(); const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.35, 8), am); sh.rotation.z = Math.PI / 2; const hd = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.18, 10), am); hd.rotation.z = -Math.PI / 2; hd.position.x = 0.25; a.add(sh, hd); a.position.set(-0.05, H / 2 - 0.7 - k * 0.95, 0); G.add(a); arrows.push(a); }
  const warm = new THREE.Color(0xff3a2a), cool = new THREE.Color(0x8a5adf), cold = new THREE.Color(0x3a7aff);
  function update(T, flow = 1, heat = 0) {
    dots.forEach(o => { const u = ((o.ph + T * 0.25 * flow) % 1); const y = o.art ? H / 2 - u * H : -H / 2 + u * H; const pos = (H / 2 - y) / H; // 0 top .. 1 bottom
      o.m.position.set((o.art ? -0.45 : 0.45) + o.dx, y, o.dz);
      const c = o.art ? warm.clone().lerp(cool, pos * heat) : cool.clone().lerp(cold, pos).lerp(warm, (1 - pos) * heat * 0.6); if (!heat) c.copy(o.art ? warm : cold);
      o.m.material.color.copy(c); o.m.material.emissive.copy(c).multiplyScalar(0.4); });
    am.opacity = 0.9 * heat; arrows.forEach((a, k) => { a.position.x = -0.12 + 0.08 * Math.sin(T * 4 + k); });
  }
  update(0);
  return { group: G, update, H };
}
export { std };
