// The Explainer: how a Venus flytrap snaps shut. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { trap, plant, fly, popper, std } from './flytrap.js';
import { rnd } from './bolt.js';
import { trees } from './world.js';
import { label } from './gps.js';
import { VO } from './vo_vf.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *Venus flytrap*', 3], ['can *count*', 2], ['and it *snaps* shut', 4], ['in about', 2], ['*a tenth*', 2], ['of a *second*', 3]],
  [['Each half', 2], ['of the trap', 3], ['has tiny', 2], ['*trigger hairs*', 2], ['on the inside', 3]],
  [['*One touch*', 2], ['sends an', 2], ['*electrical signal*', 2], ['but *nothing*', 2], ['happens', 1], ['It could just be', 4], ['a *raindrop*', 2]],
  [['A *second touch*', 3], ['within about', 2], ['*half a minute*', 3], ['and it *snaps*', 3]],
  [["But plants don't", 3], ['have *muscles*', 2], ['so how does it', 4], ['move *that fast*', 3]],
  [['Each *lobe*', 2], ['is *curved outwards*', 3], ['like a bent', 3], ['*popper toy*', 2], ["and it's", 2], ['under *tension*', 2]],
  [['The signal', 2], ['makes *water*', 2], ['*shift*', 1], ['in its cells', 3], ['so the lobe', 3], ['*flips its curve*', 3], ['and *snaps closed*', 3]],
  [['The *spiky edges*', 3], ['*lock together*', 2], ['like the *bars*', 3], ['of a *cage*', 3]],
  [['*Struggling*', 1], ['only touches', 2], ['more hairs', 2], ['telling it to', 3], ['*seal shut*', 2], ['and start', 2], ['*digesting*', 1], ['About a week', 3], ['later', 1], ['it *opens again*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 38) => { const c = cam(fov); c.near = 0.01; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.45, warm: 1.05, sat: 1.25, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

// bog garden: grass, distant trees, the potted plant; hero trap world position
function bog(makeStage) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.5, 0.7, 0.6], fog: 0.03, shadowSize: 3, envI: 1.0, cloud: 0.35 });
  const g = new THREE.Mesh(new THREE.CircleGeometry(80, 48), std(0x5a8a3a, 1)); g.position.y = -1.4; g.rotation.x = -Math.PI / 2; scene.add(g);
  const spots = []; for (let k = 0; k < 40; k++) { const a = -0.5 - (k / 40) * 2.2, r = 14 + (k % 6) * 3; spots.push([Math.cos(a) * r, -1.4, Math.sin(a) * r]); } scene.add(trees(spots, { seed: 6, scale: 1.5 }));
  const P = plant(); scene.add(P.group);
  return { scene, P, H: P.traps[0] };
}
// snap curve: open 1 -> 0 and curve +0.6 -> -0.5 in ~0.12 s at time ts
function snap(T, ts) { const k = T < ts ? 0 : Math.min(1, (T - ts) / 0.12); const e = easeIn(k); return { open: 1 - e, curve: lerp(0.6, -0.5, e) }; }
const HERO = new THREE.Vector3(0, 0.9, 0);

// ============ S0 hook: a fly lands, brushes two hairs, SNAP ============
function sHook({ makeStage }) {
  const W = bog(makeStage); const F = fly(); W.scene.add(F); F.scale.setScalar(0.8);
  const c = C(36); const t1 = 1.4, t2 = 2.3;
  return {
    scene: W.scene, camera: c,
    update(t) {
      const land = easeOut(range(t, 0, 1.2)); F.position.set(lerp(1.4, 0, land), lerp(1.9, HERO.y + 0.28, land), lerp(0.8, 0.0, land) + 0.06 * Math.sin(t * 3) * (t > 1.2 ? 1 : 0)); F.rotation.y = lerp(-2.2, 0.4 + 0.3 * Math.sin(t), land);
      const s = snap(t, t2 + 0.05); W.H.set(s.open, s.curve, 0.6 * Math.max(Math.exp(-Math.max(0, t - t1) * 5) * (t > t1 ? 1 : 0), Math.exp(-Math.max(0, t - t2) * 5) * (t > t2 ? 1 : 0)), (t > t1 - 0.05 && t < t1 + 0.4) || (t > t2 - 0.05 && t < t2 + 0.4) ? 1 : 0);
      F.visible = t < t2 + 0.15;
      const sh = t > t2 && t < t2 + 0.5 ? 0.02 * Math.sin(t * 70) : 0;
      const k = easeInOut(range(t, 0, 4.6));
      orb(c, [sh, HERO.y + 0.25, 0], lerp(2.6, 2.3, k), lerp(62, 74, k), lerp(26, 18, k));
      return POST;
    },
  };
}
// ============ S1: inside the open trap: trigger hairs ============
function sHairs({ makeStage }) {
  const W = bog(makeStage);
  const L = tag(W.scene, 'trigger hairs', 0.11, '#ffe8a0', [0, HERO.y + 0.62, 0]);
  const c = C(36);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.H.set(1, 0.6, 0, smooth(range(T, at(1, 'trigger') - 0.2, at(1, 'hairs') + 0.2)) * (0.7 + 0.3 * Math.sin(T * 6)));
      pop(L, easeOut(range(T, at(1, 'trigger') - 0.1, at(1, 'trigger') + 0.2)), 0.11);
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [0, HERO.y + 0.25, 0], lerp(1.4, 1.1, k), lerp(70, 85, k), lerp(50, 60, k));
      return POST;
    },
  };
}
// ============ S2: one touch: a signal flashes, nothing happens; a raindrop ============
function sOne({ makeStage }) {
  const W = bog(makeStage); const drop = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 12), new THREE.MeshPhysicalMaterial({ color: 0xcfeeff, roughness: 0.02, transmission: 0.8, thickness: 0.1 })); drop.scale.y = 1.3; W.scene.add(drop);
  const F = fly(); F.scale.setScalar(0.8); W.scene.add(F);
  const c = C(36); const tt = at(2, 'touch'), tr = at(2, 'raindrop');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      F.position.set(0.12, HERO.y + 0.22, 0.05); F.rotation.y = 0.6 + 0.3 * Math.sin(T * 2); F.visible = T < tr - 0.6;
      const g1 = T > tt ? Math.exp(-(T - tt) * 3) : 0; const g2 = T > tr + 0.3 ? Math.exp(-(T - tr - 0.3) * 3) : 0;
      W.H.set(1, 0.6, 0.7 * Math.max(g1, g2), Math.max(g1, g2));
      const fall = range(T, tr - 0.5, tr + 0.3); drop.position.set(-0.05, HERO.y + 1.4 - fall * 1.15, 0.0); drop.visible = T > tr - 0.5 && T < tr + 0.35;
      const k = easeInOut(range(t, 0, 5.3));
      orb(c, [0, HERO.y + 0.3, 0], lerp(2.3, 2.6, k), lerp(64, 76, k), lerp(28, 22, k));
      return POST;
    },
  };
}
// ============ S3: second touch within half a minute: snap ============
function sTwo({ makeStage }) {
  const W = bog(makeStage); const F = fly(); F.scale.setScalar(0.8); W.scene.add(F);
  const L = tag(W.scene, '< 30 s', 0.14, '#ffe14a', [0, HERO.y + 0.95, 0]);
  const c = C(36); const ts = at(3, 'snaps');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      F.position.set(-0.1 + 0.15 * smooth(range(T, ls(3), at(3, 'second'))), HERO.y + 0.22, 0.03); F.rotation.y = 1.0; F.visible = T < ts + 0.12;
      const s = snap(T, ts); const g = T > at(3, 'touch') ? Math.exp(-(T - at(3, 'touch')) * 3) : 0; W.H.set(s.open, s.curve, 0.7 * g, g);
      pop(L, easeOut(range(T, at(3, 'half') - 0.15, at(3, 'half') + 0.2)) * (1 - range(T, ts - 0.2, ts)), 0.14);
      const k = easeInOut(range(t, 0, 3.2));
      orb(c, [0, HERO.y + 0.25, 0], lerp(2.6, 2.3, k), lerp(-62, -76, k), lerp(24, 18, k));
      return POST;
    },
  };
}
// ============ S4: no muscles: the whole plant, open traps waiting ============
function sNoMuscles({ makeStage }) {
  const W = bog(makeStage);
  const c = C(38);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.P.traps.forEach((tp, i) => tp.set(1, 0.6));
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [0, 0.4, 0], lerp(4.6, 3.8, k), lerp(20, 50, k), lerp(26, 18, k));
      return POST;
    },
  };
}
// ============ S5: lobe curved outward, under tension, like a popper toy ============
function sTension({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x2a4a2a); u.mid.value.set(0x34563a); u.horizon.value.set(0x3e6046); u.floorC.value.set(0x182a1a); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xf2fff0, 0x203020, 1.0));
  const T0 = trap(1); T0.group.position.set(0, -0.3, 0); scene.add(T0.group); const Pp = popper(); Pp.group.position.set(1.0, -1.15, 0); Pp.group.scale.setScalar(0.5); scene.add(Pp.group);
  const arrows = []; const am = new THREE.MeshBasicMaterial({ color: 0xffe14a, toneMapped: false, transparent: true, opacity: 0 });
  [-1, 1].forEach(s => { const a = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.02, 6, 24, Math.PI * 0.8), am); a.position.set(0, 0.25, s * 0.55); a.rotation.y = Math.PI / 2; scene.add(a); arrows.push(a); });
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      T0.set(1, 0.6 + 0.08 * Math.sin(T * 5) * smooth(range(T, at(5, 'tension') - 0.3, at(5, 'tension'))));
      Pp.set(smooth(range(T, at(5, 'toy') + 0.2, at(5, 'toy') + 0.35)));
      am.opacity = 0.9 * smooth(range(T, at(5, 'curved') - 0.2, at(5, 'outwards') + 0.2));
      const k = easeInOut(range(t, 0, 4.6));
      orb(c, [0, -0.2, 0], lerp(4.2, 3.6, k), lerp(80, 88, k), lerp(8, 6, k));
      return POST;
    },
  };
}
// ============ S6: water shifts, the lobes flip their curve and snap (slow motion) ============
function sFlip({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x2a4a2a); u.mid.value.set(0x34563a); u.horizon.value.set(0x3e6046); u.floorC.value.set(0x182a1a); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xf2fff0, 0x203020, 1.0));
  const T0 = trap(1); T0.group.position.set(0, -0.3, 0); scene.add(T0.group);
  const R = rnd(5); const wm = new THREE.MeshBasicMaterial({ color: 0x5ab8ff, toneMapped: false }); const W = []; for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.02, 6, 4), wm); scene.add(m); W.push({ m, u: R() * 2 - 1, v: 0.2 + R() * 0.6, s: R() < 0.5 ? -1 : 1, ph: R() }); }
  const c = C(38); const tw = at(6, 'water'), tf = at(6, 'flips');
  return {
    scene, camera: c,
    update(t, T) {
      const k = smooth(range(T, tf - 0.1, tf + 0.9)); T0.set(1 - k, lerp(0.6, -0.5, k), 0.4 * smooth(range(T, ls(6), ls(6) + 0.4)) * (1 - k));
      W.forEach(o => { const on = T > tw - 0.2 && T < tf + 0.3; o.m.visible = on; const ang = (0.08 + (1 - k) * 0.62) * o.s; const y = o.v * 1.05; const dz = 0.05 + 0.06 * Math.sin(T * 6 + o.ph * 6); const p = new THREE.Vector3(o.u * 0.6, y, dz * o.s); p.applyAxisAngle(new THREE.Vector3(1, 0, 0), ang); o.m.position.copy(p).add(new THREE.Vector3(0, -0.3, 0)); });
      const kk = easeInOut(range(t, 0, 5.0));
      orb(c, [0, 0.1, 0], lerp(3.6, 3.2, kk), lerp(84, 70, kk), lerp(10, 16, kk));
      return { ...POST, bloom: 0.55 };
    },
  };
}
// ============ S7: closed: spiky edges interlock like the bars of a cage ============
function sCage({ makeStage }) {
  const W = bog(makeStage); const F = fly(); F.scale.setScalar(0.8); W.scene.add(F);
  const c = C(36);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.H.set(0.05, -0.5); F.position.set(0, HERO.y + 0.25 + 0.02 * Math.sin(T * 9), 0.0); F.rotation.y = T * 2;
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [0, HERO.y + 0.45, 0], lerp(1.5, 1.2, k), lerp(10, 25, k), lerp(70, 62, k));
      return POST;
    },
  };
}
// ============ S8: seals shut, digests; a week later it opens again (time-lapse) ============
function sDigest({ makeStage }) {
  const W = bog(makeStage);
  const L = tag(W.scene, '1 week later', 0.16, '#ffffff', [0, HERO.y + 1.1, 0]);
  const c = C(36); const tw = at(8, 'week');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const seal = smooth(range(T, at(8, 'seal') - 0.2, at(8, 'shut') + 0.3)); const reopen = smooth(range(T, at(8, 'opens') - 0.4, le(8) + 0.4));
      W.H.set(reopen * 1 + (1 - reopen) * (0.05 - 0.05 * seal), lerp(-0.5 - 0.15 * seal, 0.6, reopen), 0.25 * seal * (1 - reopen) * (0.7 + 0.3 * Math.sin(T * 4)));
      pop(L, easeOut(range(T, tw - 0.1, tw + 0.2)) * (1 - range(T, le(8), le(8) + 0.4)), 0.16);
      const k = easeInOut(range(t, 0, 7.0));
      orb(c, [0, HERO.y + 0.25, 0], lerp(2.4, 3.0, k), lerp(60, 80, k), lerp(26, 22, k));
      return POST;
    },
  };
}

const SH = [sHook, sHairs, sOne, sTwo, sNoMuscles, sTension, sFlip, sCage, sDigest];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
