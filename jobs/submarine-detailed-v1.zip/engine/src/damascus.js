// Damascus steel reel: watered-steel pattern texture, curved shamshir blade (plain + patterned layer), clay crucible,
// crucible furnace, wootz cake, anvil + hammer, smiths (Indian / Persian), forge room, carbide-grain micro view,
// ore lump with vanadium specks, carbon nanotube, village huts.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { glowSprite } from './props.js';
import { cap } from './props60.js';

// ---------- watered pattern: wavy light/dark bands from summed sines + warp ----------
const PAT = {};
export function waterPattern(seed = 1, { w = 1024, h = 256, freq = 70, dark = [78, 80, 88], light = [196, 200, 208] } = {}) {
  const key = seed + ':' + freq; if (PAT[key]) return PAT[key];
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const x = cv.getContext('2d');
  const img = x.createImageData(w, h); const R = rng(seed);
  const waves = [...Array(7)].map(() => [1 + R() * 6, 1 + R() * 4, R() * 6.28, 0.3 + R() * 0.7]);
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
    const u = i / w, v = j / h; let warp = 0;
    for (const [a, b, p, k] of waves) warp += Math.sin(u * a * 6.28 + Math.sin(v * b * 6.28 + p) * 1.6 + p) * k;
    const s = Math.sin((v + warp * 0.07) * freq + Math.sin(u * 9 + v * 3) * 1.2);
    const t = Math.pow(0.5 + 0.5 * s, 2.2);
    const o = (j * w + i) * 4;
    for (let c = 0; c < 3; c++) img.data[o + c] = dark[c] + (light[c] - dark[c]) * t;
    img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return (PAT[key] = t);
}

// ---------- curved blade (shamshir). Blade lies in the xy plane, spine on top, tip at +x; origin at the guard ----------
export function blade({ L = 1.0, W = 0.075, curve = 0.11, pattern = 1, plain = false } = {}) {
  const g = new THREE.Group();
  const sh = new THREE.Shape(); const N = 40;
  const spine = [], edge = [];
  for (let i = 0; i <= N; i++) {
    const u = i / N, x = u * L, bow = -curve * u * u;
    const wid = W * (u < 0.82 ? 1 - u * 0.15 : (1 - u) / 0.18 * 0.88);
    spine.push([x, bow]); edge.push([x, bow - wid]);
  }
  sh.moveTo(...spine[0]); spine.forEach(p => sh.lineTo(...p)); edge.reverse().forEach(p => sh.lineTo(...p)); sh.lineTo(...spine[0]);
  const geo = new THREE.ExtrudeGeometry(sh, { depth: 0.008, bevelEnabled: true, bevelThickness: 0.004, bevelSize: 0.006, bevelSegments: 2, curveSegments: 4 });
  geo.translate(0, 0, -0.004);
  // UVs from position so the pattern runs along the blade on both faces
  const p = geo.attributes.position, uv = geo.attributes.uv;
  for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / L, (p.getY(i) + curve * (p.getX(i) / L) ** 2 + W) / (W * 4));
  geo.computeVertexNormals();
  const steel = new THREE.MeshStandardMaterial({ color: 0xc8ccd2, metalness: 0.95, roughness: 0.22 });
  const base = new THREE.Mesh(geo, steel); g.add(base);
  const pm = new THREE.MeshStandardMaterial({ map: waterPattern(pattern), metalness: 0.85, roughness: 0.28, transparent: true, opacity: plain ? 0 : 1, polygonOffset: true, polygonOffsetFactor: -1 });
  const pat = new THREE.Mesh(geo, pm); g.add(pat);
  g.reveal = (k) => { pm.opacity = k; pat.visible = k > 0.01; };
  g.reveal(plain ? 0 : 1);
  // hilt: guard, grip, pommel cap
  const gold = new THREE.MeshStandardMaterial({ color: 0xc89a3a, metalness: 0.9, roughness: 0.3 });
  const guard = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.2, 0.04), gold); guard.position.set(-0.012, -W / 2, 0); g.add(guard);
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.017, 0.019, 0.2, 14), new THREE.MeshStandardMaterial({ color: 0x3a2014, roughness: 0.6 }));
  grip.rotation.z = Math.PI / 2; grip.position.set(-0.13, -W / 2 + 0.005, 0); grip.rotation.y = 0; g.add(grip);
  const pom = new THREE.Mesh(new THREE.SphereGeometry(0.026, 16, 12), gold); pom.scale.set(1.2, 0.8, 0.8); pom.position.set(-0.24, -W / 2 + 0.012, 0); g.add(pom);
  g.L = L; g.W = W;
  return shadowAll(g);
}

// ---------- clay crucible (lathe), optional seal lid ----------
const clayM = () => new THREE.MeshStandardMaterial({ color: 0xa8643a, roughness: 0.95, bumpMap: fabricTexture(23), bumpScale: 3 });
export function crucible(s = 1, { lid = true, mat = null } = {}) {
  const g = new THREE.Group(); const m = mat || clayM();
  const pts = [[0, 0], [0.07, 0], [0.09, 0.03], [0.1, 0.12], [0.085, 0.2], [0.07, 0.23], [0.06, 0.23], [0.075, 0.2], [0.088, 0.12], [0.078, 0.03], [0, 0.018]].map(([a, b]) => new THREE.Vector2(a * s, b * s));
  const body = new THREE.Mesh(new THREE.LatheGeometry(pts, 24), m); body.material.side = THREE.DoubleSide; g.add(body);
  if (lid) { const l = new THREE.Mesh(new THREE.SphereGeometry(0.075 * s, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), m); l.scale.y = 0.6; l.position.y = 0.225 * s; g.add(l); g.lid = l; }
  return shadowAll(g);
}
// ---------- wootz cake: small domed disc ----------
export function cake(s = 1) {
  const pts = [[0, 0], [0.07, 0], [0.085, 0.012], [0.08, 0.026], [0.05, 0.036], [0, 0.04]].map(([a, b]) => new THREE.Vector2(a * s, b * s));
  const m = new THREE.MeshStandardMaterial({ color: 0x55504c, metalness: 0.6, roughness: 0.5, emissive: 0xff5010, emissiveIntensity: 0 });
  const c = new THREE.Mesh(new THREE.LatheGeometry(pts, 28), m); c.castShadow = c.receiveShadow = true;
  c.heat = (k, hot = 0) => { m.emissiveIntensity = k * 1.4; m.emissive.setHSL(0.03 + hot * 0.09, 1, 0.5 + hot * 0.1); };
  return c;
}
// ---------- glowing coal bed ----------
export function coals(w = 1, d = 0.6, { seed = 4, n = 90 } = {}) {
  const R = rng(seed); const g = new THREE.Group();
  const hot = new THREE.MeshStandardMaterial({ color: 0x2a1a12, emissive: 0xff5a14, emissiveIntensity: 1.6, roughness: 0.9 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x1a1612, roughness: 1 });
  const geo = new THREE.DodecahedronGeometry(0.035, 0);
  for (let i = 0; i < n; i++) { const c = new THREE.Mesh(geo, R() < 0.55 ? hot : dark); c.position.set((R() - 0.5) * w, R() * 0.05, (R() - 0.5) * d); c.rotation.set(R() * 3, R() * 3, R() * 3); c.scale.setScalar(0.7 + R() * 0.8); g.add(c); }
  g.hot = hot;
  return g;
}
// ---------- crucible furnace: clay pit-furnace, open on the camera side, crucibles in the coals ----------
export function furnace({ n = 6 } = {}) {
  const g = new THREE.Group(); const m = clayM(); m.color.set(0x8a5232); m.side = THREE.DoubleSide;
  const wall = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.9, 0.7, 32, 1, true, 0.7, Math.PI * 2 - 1.4), m); wall.position.y = 0.35; g.add(wall);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.76, 0.06, 8, 32, Math.PI * 2 - 1.4), m); rim.rotation.set(Math.PI / 2, 0, 0.7 + Math.PI / 2); rim.position.y = 0.7; g.add(rim);
  const bed = coals(1.3, 1.3, { n: 160 }); bed.position.y = 0.05; g.add(bed); g.bed = bed;
  g.pots = [];
  for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2, r = i === 0 ? 0 : 0.42; const p = crucible(1.4); p.position.set(Math.cos(a) * r * (i ? 1 : 0), 0.06, Math.sin(a) * r * (i ? 1 : 0)); g.add(p); g.pots.push(p); }
  const fire = new THREE.PointLight(0xff7a2a, 3, 3.5, 2); fire.position.set(0, 0.6, 0); g.add(fire); g.fire = fire;
  const gl = glowSprite(0xff8030, 1.6); gl.position.set(0, 0.4, 0); g.add(gl); g.glow = gl;
  return shadowAll(g);
}
// ---------- anvil + hammer ----------
export function anvil() {
  const g = new THREE.Group(); const iron = new THREE.MeshStandardMaterial({ color: 0x3a3c40, metalness: 0.8, roughness: 0.45 });
  const top = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.18), iron); top.position.y = 0.55; g.add(top);
  const horn = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.22, 16), iron); horn.rotation.z = Math.PI / 2; horn.position.set(0.35, 0.56, 0); g.add(horn);
  const waist = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.3, 0.14), iron); waist.position.y = 0.36; g.add(waist);
  const foot = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.08, 0.24), iron); foot.position.y = 0.2; g.add(foot);
  const stump = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.27, 0.16, 18), new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.9 })); stump.position.y = 0.08; g.add(stump);
  g.topY = 0.6;
  return shadowAll(g);
}
export function hammer() {
  const g = new THREE.Group();
  const h = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.014, 0.36, 8), new THREE.MeshStandardMaterial({ color: 0x7a5232, roughness: 0.8 })); h.position.y = 0.12; g.add(h);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.05, 0.05), new THREE.MeshStandardMaterial({ color: 0x404247, metalness: 0.8, roughness: 0.4 })); head.position.y = 0.3; g.add(head);
  return shadowAll(g);
}
// ---------- smiths ----------
export function smith(i = 0) {
  const h = romanBuilder({ color: [0xe8dcc0, 0xcfa070, 0xd8d0c0][i % 3], skin: [0x8a5a3a, 0x9a6844, 0x7a4e32][i % 3] });
  const t = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.05, 10, 24), new THREE.MeshStandardMaterial({ color: [0xf0ece0, 0xc0402a, 0x2a5a8a][i % 3], roughness: 0.9 }));
  t.rotation.x = Math.PI / 2 - 0.15; t.position.set(0, 0.09, -0.01); t.scale.set(1.15, 1.25, 1); h.j.head.add(t);
  const top = new THREE.Mesh(new THREE.SphereGeometry(0.13, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), t.material); top.position.set(0, 0.1, -0.01); top.scale.set(1.05, 0.7, 1.15); h.j.head.add(top);
  shadowAll(h.root);
  return h;
}
// ---------- dark forge room: back wall, floor, hearth with coals ----------
export function forgeRoom(scene, { fire = 1 } = {}) {
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x120c08); u.mid.value.set(0x1e140c); u.horizon.value.set(0x2a1c10); u.floorC.value.set(0x140e08);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), new THREE.MeshStandardMaterial({ color: 0x3a2c20, roughness: 1, bumpMap: fabricTexture(31), bumpScale: 3 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const wm = new THREE.MeshStandardMaterial({ color: 0x5a4434, roughness: 1, bumpMap: fabricTexture(17), bumpScale: 5 });
  const back = new THREE.Mesh(new THREE.PlaneGeometry(12, 5), wm); back.position.set(0, 2.5, -2.2); back.receiveShadow = true; scene.add(back);
  const side = new THREE.Mesh(new THREE.PlaneGeometry(8, 5), wm); side.rotation.y = Math.PI / 2; side.position.set(-3, 2.5, 1); scene.add(side);
  const hearth = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.7, 0.9), new THREE.MeshStandardMaterial({ color: 0x6a4a34, roughness: 1 })); hearth.position.set(-1.6, 0.35, -1.5); hearth.castShadow = hearth.receiveShadow = true; scene.add(hearth);
  const bed = coals(1.1, 0.6, { seed: 8 }); bed.position.set(-1.6, 0.71, -1.5); scene.add(bed);
  const hood = new THREE.Mesh(new THREE.ConeGeometry(0.9, 1.2, 4, 1, true), wm); hood.rotation.y = Math.PI / 4; hood.position.set(-1.6, 2.1, -1.6); scene.add(hood);
  const light = new THREE.PointLight(0xff7028, 4 * fire, 6, 1.6); light.position.set(-1.5, 1.1, -1.0); light.castShadow = true; light.shadow.mapSize.set(1024, 1024); scene.add(light);
  const gl = glowSprite(0xff7020, 1.4); gl.position.set(-1.6, 0.85, -1.4); scene.add(gl);
  scene.userData.fire = (k, t = 0) => { const f = k * (1 + 0.08 * Math.sin(t * 13) + 0.05 * Math.sin(t * 29)); light.intensity = 4 * f; gl.material.opacity = Math.min(1, f); bed.hot.emissiveIntensity = 1.6 * k; };
  scene.userData.fire(fire);
  return { floor, back, hearth, bed, light };
}
// ---------- micro view: carbide grains scattered -> lined up in wavy bands ----------
export function grains(n = 900, { w = 3, h = 5, bands = 9, seed = 5 } = {}) {
  const R = rng(seed);
  const geo = new THREE.SphereGeometry(0.035, 8, 6);
  const m = new THREE.MeshStandardMaterial({ color: 0xe8ecf2, metalness: 0.4, roughness: 0.3, emissive: 0x7ab0ff, emissiveIntensity: 0.25 });
  const inst = new THREE.InstancedMesh(geo, m, n);
  const A = [], B = [];
  for (let i = 0; i < n; i++) {
    A.push([(R() - 0.5) * w, (R() - 0.5) * h, (R() - 0.5) * 0.3]);
    const b = Math.floor(R() * bands), x = (R() - 0.5) * w;
    const y = -h / 2 + (b + 0.5) * h / bands + Math.sin(x * 2.2 + b * 0.9) * 0.22 + (R() - 0.5) * 0.06;
    B.push([x, y, (R() - 0.5) * 0.1]);
  }
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  inst.set = (k, wob = 0) => {
    for (let i = 0; i < n; i++) {
      const a = A[i], b = B[i], kk = Math.min(1, Math.max(0, k * 1.3 - (i % 7) * 0.04));
      s.setScalar(0.7 + (i % 5) * 0.12);
      m4.compose(new THREE.Vector3(a[0] + (b[0] - a[0]) * kk + Math.sin(i + wob) * 0.01, a[1] + (b[1] - a[1]) * kk, a[2] + (b[2] - a[2]) * kk), q, s);
      inst.setMatrixAt(i, m4);
    }
    inst.instanceMatrix.needsUpdate = true;
  };
  inst.set(0); inst.frustumCulled = false;
  return inst;
}
// ---------- ore lump with glowing vanadium specks ----------
export function oreLump(seed = 3) {
  const g = new THREE.Group(); const R = rng(seed);
  const geo = new THREE.IcosahedronGeometry(0.5, 3); const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(p, i); const k = 1 + 0.18 * Math.sin(v.x * 7 + 1) * Math.sin(v.y * 5 + 2) + 0.08 * Math.sin(v.z * 13); v.multiplyScalar(k); p.setXYZ(i, v.x, v.y * 0.8, v.z); }
  geo.computeVertexNormals();
  g.add(new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0x6a4a3a, roughness: 0.85, metalness: 0.3, bumpMap: fabricTexture(13), bumpScale: 6 })));
  const sm = new THREE.MeshStandardMaterial({ color: 0x9ad8ff, emissive: 0x3ab0ff, emissiveIntensity: 0, roughness: 0.3 });
  g.specks = [];
  for (let i = 0; i < 26; i++) { const d = new THREE.Vector3(R() - 0.5, R() - 0.5, R() - 0.5).normalize(); const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.025 + R() * 0.02), sm); s.position.copy(d.multiplyScalar(0.5 * (1 + 0.1 * R()))); s.position.y *= 0.8; g.add(s); g.specks.push(s); }
  g.glow = (k) => { sm.emissiveIntensity = 3 * k; };
  return shadowAll(g);
}
// ---------- carbon nanotube: hexagon-lattice tube ----------
export function nanotube(L = 4, r = 0.5) {
  const tex = canvasTex(256, 256, (x) => {
    x.fillStyle = '#000'; x.fillRect(0, 0, 256, 256); x.strokeStyle = '#7fd8ff'; x.lineWidth = 5;
    const s = 32, hh = s * Math.sqrt(3) / 2;
    for (let row = -1; row < 6; row++) for (let col = -1; col < 6; col++) {
      const cx = col * s * 1.5, cy = row * hh * 2 + (col % 2 ? hh : 0);
      x.beginPath(); for (let k = 0; k <= 6; k++) { const a = k * Math.PI / 3; x.lineTo(cx + Math.cos(a) * s * 0.5 * 1.0, cy + Math.sin(a) * s * 0.5 * 1.0); } x.stroke();
    }
  }, [3, 6]);
  const m = new THREE.MeshBasicMaterial({ map: tex, alphaMap: tex, transparent: true, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
  const t = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, 48, 1, true), m);
  return t;
}
// ---------- village hut (mud walls, thatch cone) ----------
export function hut(seed = 1) {
  const g = new THREE.Group(); const R = rng(seed);
  const wall = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.5, 1.8, 20), new THREE.MeshStandardMaterial({ color: 0xb07a50, roughness: 1, bumpMap: fabricTexture(51), bumpScale: 4 })); wall.position.y = 0.9; g.add(wall);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(2.0, 1.6, 20), new THREE.MeshStandardMaterial({ color: 0xc8a860, roughness: 1, bumpMap: fabricTexture(7), bumpScale: 6 })); roof.position.y = 2.6; roof.rotation.y = R(); g.add(roof);
  const door = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 1.1), new THREE.MeshStandardMaterial({ color: 0x1a120c })); door.position.set(0, 0.55, 1.51); g.add(door);
  return shadowAll(g);
}
