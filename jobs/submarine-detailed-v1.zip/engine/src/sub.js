// The Explainer: how a submarine dives and surfaces. Submarine (nose +x, ~8 long) with cutaway ballast tanks,
// trim tank, vents, diving planes, bubbles; ocean surface; buoyancy arrows.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.5, m = 0.3, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
export const WATER_C = 0x2f8fd8;

function tank(len, h, d) {
  const g = new THREE.Group();
  const wall = new THREE.Mesh(new THREE.BoxGeometry(len, h, d), new THREE.MeshPhysicalMaterial({ color: 0xdfe8f0, roughness: 0.15, transmission: 0.6, transparent: true, opacity: 0.35, depthWrite: false }));
  g.add(wall);
  const edges = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(len, h, d)), new THREE.LineBasicMaterial({ color: 0x9fb6c8 })); g.add(edges);
  const air = new THREE.Mesh(new THREE.BoxGeometry(len * 0.96, h * 0.96, d * 0.96), new THREE.MeshBasicMaterial({ color: 0xfff2c8, transparent: true, opacity: 0.55, depthWrite: false })); g.add(air);
  const water = new THREE.Mesh(new THREE.BoxGeometry(len * 0.96, h * 0.96, d * 0.96), std(0x2aa8ff, 0.1, 0, { transparent: true, opacity: 0.95, emissive: 0x1a6aff, emissiveIntensity: 0.6 }));
  water.geometry.translate(0, h * 0.48, 0); water.position.y = -h * 0.48; g.add(water);
  return { group: g, set(f) { water.scale.y = Math.max(0.001, f); water.visible = f > 0.005; air.scale.y = Math.max(0.001, 1 - f); air.position.y = (h * 0.48) * f; } };
}

export function submarine() {
  const G = new THREE.Group(); const body = new THREE.Group(); G.add(body);
  const hullM = std(0x2f3540, 0.55, 0.4, { transparent: true, opacity: 1 });
  const hull = new THREE.Mesh(new THREE.CapsuleGeometry(1, 6.4, 16, 40), hullM); hull.rotation.z = Math.PI / 2; body.add(hull);
  const sail = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.3, 0.5), hullM); sail.position.set(1.4, 1.35, 0); body.add(sail);
  const sailCap = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 1.4, 16), hullM); sailCap.rotation.z = Math.PI / 2; sailCap.position.set(1.4, 2.0, 0); sailCap.scale.z = 1; body.add(sailCap);
  // diving planes: on the sail and at the stern
  const planeM = std(0x262b33, 0.5, 0.4, { transparent: true, opacity: 1 });
  const sp = new THREE.Group(); sp.position.set(1.5, 1.4, 0); const spm = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.06, 2.2), planeM); sp.add(spm); body.add(sp);
  const st = new THREE.Group(); st.position.set(-4.0, 0, 0); const stm = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.06, 2.6), planeM); st.add(stm); body.add(st);
  const rud = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.8, 0.06), planeM); rud.position.set(-4.0, 0, 0); body.add(rud);
  const prop = new THREE.Group(); prop.position.set(-4.75, 0, 0); for (let k = 0; k < 7; k++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.55, 0.16), std(0xb08a3a, 0.3, 0.9)); b.position.y = 0.3; const p = new THREE.Group(); p.rotation.x = k / 7 * Math.PI * 2; b.rotation.y = 0.5; p.add(b); prop.add(p); } body.add(prop);
  // inside (visible when the hull is see-through): pressure hull, ballast tanks fore/aft, trim tank, air bottles
  const inside = new THREE.Group(); body.add(inside);
  const ph = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.62, 4.4, 32), std(0x8c96a2, 0.4, 0.6)); ph.rotation.z = Math.PI / 2; inside.add(ph);
  const fore = tank(1.3, 1.5, 1.4), aft = tank(1.3, 1.5, 1.4); fore.group.position.set(2.95, 0, 0); aft.group.position.set(-2.95, 0, 0); inside.add(fore.group, aft.group);
  const trim = tank(1.0, 0.45, 0.6); trim.group.position.set(0, -0.75, 0); inside.add(trim.group);
  const bottles = []; for (let k = 0; k < 3; k++) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.9, 12), std(0x3a9a5a, 0.4, 0.4)); b.rotation.z = Math.PI / 2; b.position.set(-0.8 + k * 0.8, 0.82, 0.2); inside.add(b); bottles.push(b); }
  // vents (top of each tank) and flood holes (bottom)
  const vents = [2.95, -2.95].map(x => { const v = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.12, 12), std(0x6a7480, 0.4, 0.6)); v.position.set(x, 0.98, 0); body.add(v); return v; });
  // bubbles: from vents (venting) and from the bottom (blowing)
  const R = rnd(14); const bm = new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transmission: 0.6, transparent: true, opacity: 0.8 });
  const B = []; for (let i = 0; i < 90; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.05 + R() * 0.07, 10, 8), bm); G.add(m); B.push({ m, top: i < 60, x: R() < 0.5 ? 2.95 : -2.95, dx: (R() - 0.5) * 0.5, dz: (R() - 0.5) * 0.5, ph: R() }); }
  // air-flow highlight lines from bottles to tanks
  const pipeM = new THREE.MeshBasicMaterial({ color: 0x9cf0ff, transparent: true, opacity: 0, toneMapped: false });
  const pipe = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.06, 0.06), pipeM); pipe.position.set(0, 0.82, 0.2); inside.add(pipe);
  const S = { xray: 0, fill: 0, trim: 0.5, vent: 0, blow: 0, planes: 0, prop: 0 };
  function update(T) {
    body.updateMatrix();
    hullM.opacity = 1 - 0.6 * S.xray; hullM.depthWrite = S.xray < 0.3; planeM.opacity = 1 - 0.5 * S.xray; inside.visible = S.xray > 0.02;
    fore.set(S.fill); aft.set(S.fill); trim.set(S.trim);
    sp.rotation.z = S.planes; st.rotation.z = S.planes; prop.rotation.x = S.prop;
    pipeM.opacity = 0.9 * S.blow * (0.6 + 0.4 * Math.sin(T * 12));
    const wp = new THREE.Vector3();
    B.forEach(o => { const on = o.top ? S.vent : S.blow; const u = (o.ph + T * 0.9) % 1; o.m.visible = on > 0.02;
      if (o.top) wp.set(o.x + o.dx * u, 1.0 + u * 3.5, o.dz * u * 2); else wp.set(o.x + o.dx * u * 2, -0.85 - u * 0.6 + u * u * 3, o.dz * u * 2);
      o.m.position.copy(wp).applyMatrix4(body.matrix); o.m.scale.setScalar(Math.max(0.001, on * (0.6 + u))); });
  }
  update(0);
  return { group: G, body, S, update, fore, aft, trim };
}

// big arrows: up (buoyancy, blue) and down (weight, red); set(lenUp, lenDown)
export function forces() {
  const g = new THREE.Group();
  const mk = (c) => { const a = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0.5 }); const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 1, 12), m); sh.geometry.translate(0, 0.5, 0); const hd = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.5, 16), m); a.add(sh, hd); a.userData = { sh, hd }; g.add(a); return a; };
  const up = mk(0x3fb8ff), dn = mk(0xff5a4a);
  function set(lu, ld) {
    up.position.set(0.6, 1.2, 1.4); up.userData.sh.scale.y = Math.max(0.001, lu); up.userData.hd.position.y = lu + 0.2; up.visible = lu > 0.02;
    dn.position.set(-0.6, -1.2, 1.4); dn.rotation.z = Math.PI; dn.userData.sh.scale.y = Math.max(0.001, ld); dn.userData.hd.position.y = ld + 0.2; dn.visible = ld > 0.02;
  }
  set(0, 0); return { group: g, set };
}

// ocean surface (seen from above or below)
export function oceanSurface(size = 400) {
  const m = new THREE.MeshPhysicalMaterial({ color: 0x1f6fa8, roughness: 0.15, metalness: 0.1, transparent: true, opacity: 0.72, side: THREE.DoubleSide, clearcoat: 0.6 });
  const g = new THREE.PlaneGeometry(size, size, 120, 120); const p = g.attributes.position; const base = p.array.slice();
  const mesh = new THREE.Mesh(g, m); mesh.rotation.x = -Math.PI / 2;
  return { mesh, update(T) { for (let i = 0; i < p.count; i++) { const x = base[i * 3], y = base[i * 3 + 1]; p.setZ(i, Math.sin(x * 0.35 + T * 1.3) * 0.08 + Math.sin(y * 0.5 - T * 1.1) * 0.06); } p.needsUpdate = true; } };
}
export { std };
