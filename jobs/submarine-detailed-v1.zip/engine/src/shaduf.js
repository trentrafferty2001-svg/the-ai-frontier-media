// Shaduf reel: river bank (land at y=1.6 for z<0, river at y=0.2 for z>0), shaduf (posts, crossbar, pivoting pole with
// bucket + mud counterweight), irrigation channel + fields, terrace of stacked shadufs, Mesopotamian cylinder seal.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex } from './rome.js';
import { waterMaterial } from './world.js';
import { persiaMats } from './persia.js';

export const LAND = 1.6, RIVER = 0.2;
export function bank(scene, { len = 400 } = {}) {
  const P = persiaMats();
  const land = new THREE.Mesh(new THREE.BoxGeometry(len, LAND, 200), new THREE.MeshStandardMaterial({ color: 0x9a7a4a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); land.position.set(0, LAND / 2, -100); land.receiveShadow = true; scene.add(land);
  const slope = new THREE.Mesh(new THREE.PlaneGeometry(len, 2.2), new THREE.MeshStandardMaterial({ color: 0x6a5232, roughness: 1 })); slope.rotation.x = -Math.PI / 2 + 0.62; slope.position.set(0, (LAND + RIVER) / 2 - 0.1, 0.85); slope.receiveShadow = true; scene.add(slope);
  const bed = new THREE.Mesh(new THREE.PlaneGeometry(len, 200), new THREE.MeshStandardMaterial({ color: 0x5a4a30 })); bed.rotation.x = -Math.PI / 2; bed.position.set(0, -0.5, 100); scene.add(bed);
  const water = new THREE.Mesh(new THREE.PlaneGeometry(len, 120), waterMaterial({ color: 0x2f5a5a, opacity: 0.95, ripple: 1.2 })); water.rotation.x = -Math.PI / 2; water.position.set(0, RIVER, 61.5); scene.add(water);
  const far = new THREE.Mesh(new THREE.PlaneGeometry(len, 40), new THREE.MeshStandardMaterial({ color: 0x5a7a34, roughness: 1 })); far.rotation.x = -Math.PI / 2; far.position.set(0, RIVER + 0.05, 140); scene.add(far);
  // irrigation channel + green fields behind
  const ch = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 30), new THREE.MeshStandardMaterial({ color: 0x3a8ab8, emissive: 0x0a3a5a, emissiveIntensity: 0.4, roughness: 0.1 })); ch.rotation.x = -Math.PI / 2; ch.position.set(-1.2, LAND + 0.02, -16); scene.add(ch);
  const fm = new THREE.MeshStandardMaterial({ color: 0x5a9a2a, roughness: 0.9, bumpMap: fabricTexture(11), bumpScale: 3 });
  for (let i = 0; i < 6; i++) { const f = new THREE.Mesh(new THREE.PlaneGeometry(9, 7), fm); f.rotation.x = -Math.PI / 2; f.position.set(i % 2 ? 4.2 : -6.6, LAND + 0.015, -6 - Math.floor(i / 2) * 8); f.receiveShadow = true; scene.add(f); }
  return { channel: ch };
}
// shaduf standing at the bank edge; pivot on the crossbar; set(a) a = pole tilt (0 level, + bucket end down)
export function shaduf() {
  const wood = new THREE.MeshStandardMaterial({ color: 0x7a5a36, roughness: 0.9 }); const mud = persiaMats().mud;
  const g = new THREE.Group();
  for (const s of [-1, 1]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 2.6, 8), mud); p.position.set(s * 0.5, LAND + 1.3, -0.4); g.add(p); }
  const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.3, 8), wood); bar.rotation.z = Math.PI / 2; bar.position.set(0, LAND + 2.55, -0.4); g.add(bar);
  const piv = new THREE.Group(); piv.position.set(0, LAND + 2.6, -0.4); g.add(piv);
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 5.2, 8), wood); pole.rotation.x = Math.PI / 2; pole.position.z = 1.1; piv.add(pole);
  const cw = new THREE.Mesh(new THREE.SphereGeometry(0.4, 12, 10), mud); cw.scale.set(1, 0.85, 1.1); cw.position.z = -1.4; piv.add(cw);
  const tip = new THREE.Object3D(); tip.position.z = 3.6; piv.add(tip);
  const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 1, 6), new THREE.MeshStandardMaterial({ color: 0xc8a868 })); g.add(rope);
  const bucket = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.17, 0.32, 14), new THREE.MeshStandardMaterial({ color: 0x8a5a32, roughness: 0.9 })); g.add(bucket);
  const fillW = new THREE.Mesh(new THREE.CircleGeometry(0.2, 14), new THREE.MeshStandardMaterial({ color: 0x3a8ab8, emissive: 0x0a3a5a, emissiveIntensity: 0.4 })); fillW.rotation.x = -Math.PI / 2; g.add(fillW);
  const R = 2.0; // rope length
  g.set = (a, { full = false, tipB = 0, yaw = 0 } = {}) => {
    piv.rotation.set(a, yaw, 0); g.updateMatrixWorld(true);
    const tp = tip.getWorldPosition(new THREE.Vector3()); g.worldToLocal(tp);
    const by = tp.y - R; bucket.position.set(tp.x, by, tp.z); bucket.rotation.z = tipB;
    rope.position.set(tp.x, tp.y - R / 2 + 0.1, tp.z); rope.scale.y = R - 0.2;
    fillW.visible = full && tipB < 0.4; fillW.position.set(tp.x, by + 0.14, tp.z);
  };
  g.tipPos = () => bucket.getWorldPosition(new THREE.Vector3());
  g.set(0);
  return shadowAll(g);
}
// cylinder seal + its rolled impression showing a figure at a shaduf
export function seal() {
  const tex = canvasTex(512, 256, (x) => {
    x.fillStyle = '#b8946a'; x.fillRect(0, 0, 512, 256);
    x.strokeStyle = 'rgba(70,45,20,0.9)'; x.lineWidth = 7; x.lineCap = 'round';
    const fig = (cx) => { x.beginPath(); x.arc(cx, 70, 14, 0, 7); x.stroke(); x.beginPath(); x.moveTo(cx, 84); x.lineTo(cx, 160); x.moveTo(cx, 160); x.lineTo(cx - 20, 220); x.moveTo(cx, 160); x.lineTo(cx + 20, 220); x.moveTo(cx, 105); x.lineTo(cx + 40, 80); x.stroke(); };
    fig(120); x.beginPath(); x.moveTo(230, 230); x.lineTo(230, 120); x.moveTo(250, 230); x.lineTo(250, 120); x.moveTo(140, 70); x.lineTo(360, 140); x.stroke();
    x.beginPath(); x.arc(150, 70, 12, 0, 7); x.stroke(); x.beginPath(); x.moveTo(360, 140); x.lineTo(360, 200); x.stroke(); x.strokeRect(345, 200, 30, 26);
    fig(430);
    for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(20 + i * 6, 20); x.lineTo(20 + i * 6, 40); x.stroke(); }
  });
  const g = new THREE.Group();
  const clay = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.2), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9, bumpMap: tex, bumpScale: 6 })); clay.rotation.x = -Math.PI / 2; g.add(clay);
  const cyl = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.9, 32), new THREE.MeshStandardMaterial({ color: 0x5a5048, roughness: 0.5 })); cyl.rotation.z = Math.PI / 2; cyl.position.set(0.8, 0.22, 0.9); g.add(cyl);
  g.cyl = cyl;
  return shadowAll(g);
}
