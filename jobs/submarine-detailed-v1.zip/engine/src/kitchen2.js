// Detailed kitchen kit (Explainer detailed December): subway-tile backsplash, plaster wall, panelled cabinet doors,
// a window with daylight, wall shelf with jars and plants, fruit bowl, toaster, microwave, picture, pendant lamp, rug;
// extra fridge food. kitchenDetail(scene) after kitchen(); fridgeFood(F) after fridge().
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { rng } from './textures.js';
function canvasTex(w, h, draw, rep) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; if (rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...rep); } return t; }
const subway = () => canvasTex(256, 256, (g, w, h) => { g.fillStyle = '#9a9690'; g.fillRect(0, 0, w, h); const tw = 64, th = 32; for (let r = 0; r < h / th; r++) for (let c = -1; c < w / tw + 1; c++) { const x = c * tw + (r % 2 ? tw / 2 : 0), y = r * th; const gr = g.createLinearGradient(0, y, 0, y + th); gr.addColorStop(0, '#fbfaf6'); gr.addColorStop(1, '#e4e2dc'); g.fillStyle = gr; g.fillRect(x + 2, y + 2, tw - 4, th - 4); } }, [6, 3]);
const plaster = () => canvasTex(256, 256, (g, w, h) => { g.fillStyle = '#e6d2ae'; g.fillRect(0, 0, w, h); const R = rng(4); for (let i = 0; i < 4000; i++) { g.fillStyle = `rgba(${R() < 0.5 ? 255 : 180},${R() < 0.5 ? 240 : 160},${200},0.08)`; g.fillRect(R() * w, R() * h, 2 + R() * 4, 2 + R() * 4); } }, [6, 3]);
const wood = () => canvasTex(256, 512, (g, w, h) => { g.fillStyle = '#5f8f7a'; g.fillRect(0, 0, w, h); g.strokeStyle = 'rgba(30,60,48,0.55)'; g.lineWidth = 10; g.strokeRect(22, 22, w - 44, h - 44); g.strokeStyle = 'rgba(200,230,215,0.35)'; g.lineWidth = 4; g.strokeRect(34, 34, w - 68, h - 68); const R = rng(6); g.strokeStyle = 'rgba(40,70,58,0.15)'; for (let i = 0; i < 40; i++) { g.lineWidth = 1 + R() * 2; g.beginPath(); const x = R() * w; g.moveTo(x, 0); g.bezierCurveTo(x + 10, h / 3, x - 10, h * 2 / 3, x + 5, h); g.stroke(); } });
const rugTex = () => canvasTex(512, 256, (g, w, h) => { g.fillStyle = '#8a3a2e'; g.fillRect(0, 0, w, h); g.strokeStyle = '#e8c87a'; g.lineWidth = 8; g.strokeRect(14, 14, w - 28, h - 28); g.lineWidth = 4; g.strokeStyle = '#2e4a6a'; g.strokeRect(34, 34, w - 68, h - 68); for (let i = 0; i < 6; i++) { g.fillStyle = i % 2 ? '#e8c87a' : '#2e4a6a'; g.beginPath(); g.moveTo(80 + i * 70, h / 2); g.lineTo(110 + i * 70, h / 2 - 40); g.lineTo(140 + i * 70, h / 2); g.lineTo(110 + i * 70, h / 2 + 40); g.fill(); } });
const picTex = () => canvasTex(256, 192, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#f8c27a'); gr.addColorStop(0.6, '#e8806a'); gr.addColorStop(1, '#3a5a7a'); g.fillStyle = gr; g.fillRect(0, 0, w, h); g.fillStyle = '#fff2c0'; g.beginPath(); g.arc(w * 0.65, h * 0.55, 26, 0, 6.3); g.fill(); g.fillStyle = '#2a3a4a'; g.beginPath(); g.moveTo(0, h); g.lineTo(w * 0.3, h * 0.55); g.lineTo(w * 0.55, h); g.fill(); g.beginPath(); g.moveTo(w * 0.4, h); g.lineTo(w * 0.8, h * 0.6); g.lineTo(w, h); g.fill(); });
const S = (c, r = 0.5, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
export function kitchenDetail(scene) {
  const R = rng(9); const G = new THREE.Group(); scene.add(G);
  // retexture existing wall + cabinets
  scene.traverse(o => { if (!o.isMesh || !o.material || !o.material.color) return; const hex = o.material.color.getHex();
    if (hex === 0xd9c19a) { o.material = new THREE.MeshStandardMaterial({ map: plaster(), roughness: 0.9 }); }
    else if (hex === 0x5f8f7a) { o.material = new THREE.MeshStandardMaterial({ map: wood(), roughness: 0.55, color: 0xffffff }); } });
  // backsplash band between counter and upper cupboards (behind the counter, right of the fridge)
  const bs = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.65), new THREE.MeshStandardMaterial({ map: subway(), roughness: 0.25 })); bs.position.set(1.47, 1.24, -0.885); bs.receiveShadow = true; G.add(bs);
  // window above the counter area to the left of the fridge, with daylight
  const win = new THREE.Group(); win.position.set(-4.47, 1.55, 2.5); win.rotation.y = Math.PI / 2; G.add(win);
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.8), new THREE.MeshBasicMaterial({ map: canvasTex(128, 128, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#7ab8f0'); gr.addColorStop(1, '#d8eefc'); g.fillStyle = gr; g.fillRect(0, 0, w, h); g.fillStyle = '#5a9a5a'; g.beginPath(); g.arc(30, h + 20, 50, 0, 6.3); g.arc(100, h + 30, 55, 0, 6.3); g.fill(); }), toneMapped: false })); sky.position.z = 0.002; win.add(sky);
  const fr = S(0xf4f2ee, 0.5); [[0, 0.42, 0.98, 0.06], [0, -0.42, 0.98, 0.06], [-0.47, 0, 0.06, 0.9], [0.47, 0, 0.06, 0.9], [0, 0, 0.03, 0.84], [0, 0, 0.92, 0.03]].forEach(([x, y, w, h]) => { const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.05), fr); b.position.set(x, y, 0.025); win.add(b); });
  const sill = new THREE.Mesh(new THREE.BoxGeometry(1.06, 0.03, 0.14), fr); sill.position.set(0, -0.46, 0.06); win.add(sill);
  const curtM = new THREE.MeshStandardMaterial({ color: 0xe8b850, roughness: 0.9, side: THREE.DoubleSide }); [-1, 1].forEach(s => { const g = new THREE.PlaneGeometry(0.3, 1.0, 12, 1); const p = g.attributes.position; for (let i = 0; i < p.count; i++) p.setZ(i, Math.sin(p.getX(i) * 60) * 0.015); g.computeVertexNormals(); const c = new THREE.Mesh(g, curtM); c.position.set(s * 0.6, 0.0, 0.07); win.add(c); });
  const dl = new THREE.SpotLight(0xfff2d8, 6, 7, 0.6, 0.6); dl.position.set(-4.2, 1.6, 2.5); dl.target.position.set(-0.4, 0.2, 0.8); G.add(dl, dl.target);
  // wall shelf with jars and a plant (above the counter, under the uppers is taken -> on the plaster to the far right)
  const shelf = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.03, 0.16), S(0x8a5a3a, 0.7)); shelf.position.set(2.85, 1.45, -0.8); G.add(shelf);
  const jarCols = [0xe0a040, 0xc04030, 0x6a9a4a, 0xf0e0c0];
  for (let i = 0; i < 4; i++) { const j = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.12 + (i % 2) * 0.04, 20), new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transparent: true, opacity: 0.35 })); j.position.set(2.6 + i * 0.13, 1.53 + (i % 2) * 0.02, -0.8); G.add(j); const f = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.08, 20), S(jarCols[i], 0.8)); f.position.set(2.6 + i * 0.13, 1.5, -0.8); G.add(f); const lid = new THREE.Mesh(new THREE.CylinderGeometry(0.047, 0.047, 0.02, 20), S(0x3a3a3a, 0.4, 0.6)); lid.position.set(2.6 + i * 0.13, 1.6 + (i % 2) * 0.04, -0.8); G.add(lid); }
  // fruit bowl with fruit on the counter
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.13, 28, 14, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xdfe8f0, roughness: 0.3, side: THREE.DoubleSide })); bowl.scale.y = 0.5; bowl.position.set(1.6, 0.98, -0.5); G.add(bowl);
  const fc = [0xd8322a, 0xf2c64a, 0xf08a2a, 0x7ab03a, 0xd8322a]; for (let i = 0; i < 6; i++) { const f = new THREE.Mesh(new THREE.SphereGeometry(0.04, 16, 12), S(fc[i % 5], 0.45)); f.position.set(1.6 + Math.cos(i) * 0.06, 0.96 + (i > 3 ? 0.05 : 0), -0.5 + Math.sin(i) * 0.06); G.add(f); }
  const ban = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.018, 8, 20, 2.2), S(0xf2d24a, 0.5)); ban.rotation.set(1.3, 0, 0.4); ban.position.set(1.62, 1.03, -0.48); G.add(ban);
  // toaster + microwave
  const toast = new THREE.Mesh(new RoundedBoxGeometry(0.26, 0.17, 0.14, 3, 0.03), S(0xc8ccd2, 0.25, 0.8)); toast.position.set(0.95, 0.995, -0.6); toast.castShadow = true; G.add(toast);
  [-1, 1].forEach(s => { const sl = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.01, 0.025), S(0x111111)); sl.position.set(0.95, 1.08, -0.6 + s * 0.03); G.add(sl); });
  const mw = new THREE.Mesh(new RoundedBoxGeometry(0.46, 0.27, 0.34, 2, 0.02), S(0x2a2c30, 0.4, 0.3)); mw.position.set(2.2, 1.045, -0.62); mw.castShadow = true; G.add(mw);
  const mwg = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.2), new THREE.MeshPhysicalMaterial({ color: 0x101418, roughness: 0.05, clearcoat: 1 })); mwg.position.set(2.15, 1.045, -0.448); G.add(mwg);
  const mwp = new THREE.Mesh(new THREE.PlaneGeometry(0.08, 0.04), new THREE.MeshBasicMaterial({ color: 0x40ff80, toneMapped: false })); mwp.position.set(2.38, 1.11, -0.448); G.add(mwp);
  // picture on the side wall
  const pic = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.45), new THREE.MeshStandardMaterial({ map: picTex(), roughness: 0.6 })); pic.rotation.y = Math.PI / 2; pic.position.set(-4.48, 1.6, 0.8); G.add(pic);
  const pf = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.51, 0.66), S(0x3a2a1a)); pf.position.set(-4.49, 1.6, 0.8); G.add(pf);
  // pendant lamp
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.8), S(0x111111)); cord.position.set(0.9, 2.8, 0.7); G.add(cord);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.18, 32, 1, true), new THREE.MeshStandardMaterial({ color: 0x2a4a3a, roughness: 0.5, side: THREE.DoubleSide })); shade.position.set(0.9, 2.33, 0.7); G.add(shade);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.045, 16, 12), new THREE.MeshBasicMaterial({ color: 0xfff0c8, toneMapped: false })); bulb.position.set(0.9, 2.26, 0.7); G.add(bulb);
  const pl = new THREE.PointLight(0xffe0b0, 1.2, 4); pl.position.set(0.9, 2.2, 0.7); G.add(pl);
  // rug
  const rug = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.8), new THREE.MeshStandardMaterial({ map: rugTex(), roughness: 1 })); rug.rotation.x = -Math.PI / 2; rug.position.set(0.6, 0.004, 1.3); rug.receiveShadow = true; G.add(rug);
  return G;
}
// extra food inside the fridge (in fridge-body space; shelves at y 0.62 and 0.98, floor ~0.2)
export function fridgeFood(F) {
  const food = F.food; const R = rng(3);
  const eggM = new THREE.MeshStandardMaterial({ color: 0xf4e8d4, roughness: 0.6 }); const tray = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.02, 0.1), S(0xa8b0b8, 0.6)); tray.position.set(0.15, 0.995, 0.12); food.add(tray);
  for (let i = 0; i < 6; i++) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.018, 14, 10), eggM); e.scale.y = 1.3; e.position.set(0.1 + (i % 3) * 0.05, 1.02, 0.1 + Math.floor(i / 3) * 0.045); food.add(e); }
  const jcols = [0xd84a3a, 0xf2c64a, 0x8a4a2a]; for (let i = 0; i < 3; i++) { const j = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.08, 18), S(jcols[i], 0.3)); j.position.set(-0.05 + i * 0.07, 1.035, 0.13); food.add(j); const l = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.015, 18), S(0xd8d8d8, 0.3, 0.7)); l.position.set(-0.05 + i * 0.07, 1.082, 0.13); food.add(l); }
  const veg = [0x5aa03a, 0xf08a2a, 0x7ac03a]; for (let i = 0; i < 5; i++) { const v = new THREE.Mesh(i % 2 ? new THREE.CapsuleGeometry(0.015, 0.1, 4, 8) : new THREE.SphereGeometry(0.035, 14, 10), S(veg[i % 3], 0.6)); v.position.set(-0.15 + i * 0.07, 0.25, 0.12); v.rotation.z = i % 2 ? 1.5 : 0; food.add(v); }
  const yog = [0xf0f0f0, 0xf8d0e0]; for (let i = 0; i < 4; i++) { const y = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.025, 0.05, 18), S(yog[i % 2], 0.5)); y.position.set(-0.17 + i * 0.065, 0.655, 0.14); food.add(y); }
}
