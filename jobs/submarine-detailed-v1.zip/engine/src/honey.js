// The Explainer: how bees make honey. Bee, flower with nectar, honeycomb with fill/caps, sugar molecules, jar, spoon.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.5, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
export const HONEY = () => new THREE.MeshPhysicalMaterial({ color: 0xe8a018, roughness: 0.08, transmission: 0.35, thickness: 0.5, clearcoat: 1, emissive: 0x6a3a00, emissiveIntensity: 0.25 });

// bee (body ~1.6 long along +x = head). st: flap (phase), prob (proboscis out 0..1), crop (honey stomach fill 0..1), xray (0..1)
export function bee() {
  const G = new THREE.Group(); const body = new THREE.Group(); G.add(body);
  const yel = std(0xf2b51c, 0.55), blk = std(0x1c1610, 0.6), fuzz = std(0xd9a441, 0.9);
  const thorax = new THREE.Mesh(new THREE.SphereGeometry(0.32, 24, 16), fuzz); body.add(thorax);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 24, 16), blk); head.position.set(0.48, 0.02, 0); body.add(head);
  [-1, 1].forEach(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 12), std(0x0a0a0a, 0.15)); e.scale.set(0.7, 1.2, 0.6); e.position.set(0.55, 0.08, s * 0.16); body.add(e);
    const an = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.4, 6), blk); an.position.set(0.66, 0.3, s * 0.08); an.rotation.z = -0.6; an.rotation.x = s * 0.3; body.add(an); });
  // abdomen: striped (stacked rings), with an x-ray shell option
  const abd = new THREE.Group(); abd.position.set(-0.55, -0.05, 0); body.add(abd);
  const ringMats = []; for (let k = 0; k < 6; k++) { const m = (k % 2 ? blk : yel).clone(); m.transparent = true; ringMats.push(m); const r = 0.36 * Math.sin(Math.PI * (k + 0.8) / 6.6); const ring = new THREE.Mesh(new THREE.SphereGeometry(Math.max(0.1, r), 24, 12), m); ring.scale.set(0.42, 1, 1); ring.position.x = 0.25 - k * 0.14; abd.add(ring); }
  const crop = new THREE.Mesh(new THREE.SphereGeometry(0.16, 20, 14), HONEY()); crop.position.set(0.12, 0, 0); abd.add(crop);
  // proboscis
  const prob = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.012, 0.5, 8), std(0x3a2a18, 0.4)); prob.geometry.translate(0, -0.25, 0); prob.position.set(0.62, -0.12, 0); prob.rotation.z = 0.5; body.add(prob);
  // wings
  const wm = new THREE.MeshPhysicalMaterial({ color: 0xdfefff, roughness: 0.1, transmission: 0.6, transparent: true, opacity: 0.55, side: THREE.DoubleSide });
  const wings = [-1, 1].map(s => { const p = new THREE.Group(); p.position.set(0.05, 0.25, s * 0.12); const w = new THREE.Mesh(new THREE.CircleGeometry(0.42, 24), wm); w.scale.set(0.55, 1, 1); w.rotation.x = -Math.PI / 2; w.position.set(-0.15, 0, s * 0.4); p.add(w); body.add(p); return { p, s }; });
  // legs
  for (let k = 0; k < 3; k++) [-1, 1].forEach(s => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.012, 0.45, 6), blk); l.position.set(0.15 - k * 0.15, -0.32, s * 0.2); l.rotation.x = s * 0.5; l.rotation.z = 0.2 * (k - 1); body.add(l); });
  const st = { flap: 0, prob: 0, crop: 0, xray: 0, wingAmp: 1 };
  function update() {
    wings.forEach(({ p, s }) => { p.rotation.x = s * (0.15 + 0.6 * st.wingAmp * (0.5 + 0.5 * Math.sin(st.flap * Math.PI * 2))); });
    prob.scale.set(1, 0.15 + 0.85 * st.prob, 1);
    crop.scale.setScalar(Math.max(0.001, st.crop)); crop.visible = st.crop > 0.01;
    ringMats.forEach(m => { m.opacity = 1 - 0.65 * st.xray; m.depthWrite = st.xray < 0.5; });
  }
  update();
  return { group: G, st, update, head, prob };
}

// flower with an open cup and a nectar droplet at its centre (top at y ~ 0)
export function flowerCup(color = 0xff7aa8) {
  const g = new THREE.Group(); const pm = std(color, 0.6, 0, { side: THREE.DoubleSide });
  for (let k = 0; k < 8; k++) { const p = new THREE.Mesh(new THREE.SphereGeometry(0.5, 16, 10), pm); p.scale.set(1, 0.12, 0.45); const a = k / 8 * Math.PI * 2; p.position.set(Math.cos(a) * 0.48, -0.02 + 0.08, Math.sin(a) * 0.48); p.rotation.y = -a; p.rotation.z = 0.35; g.add(p); }
  const ctr = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 12), std(0xffc21a, 0.8)); ctr.scale.y = 0.5; g.add(ctr);
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 3, 8), std(0x3f8f3a, 0.7)); stem.position.y = -1.5; g.add(stem);
  const drop = new THREE.Mesh(new THREE.SphereGeometry(0.12, 20, 14), new THREE.MeshPhysicalMaterial({ color: 0xd8f0ff, roughness: 0.02, transmission: 0.8, thickness: 0.3, clearcoat: 1 })); drop.position.y = 0.12; drop.scale.y = 0.75; g.add(drop);
  g.userData.drop = drop; return g;
}

// honeycomb: hex cells on a wall (xy plane, facing +z). fill/cap per cell 0..1
export function comb(nx = 9, ny = 11, r = 0.3) {
  const g = new THREE.Group(); const wax = std(0xf0c25a, 0.55); const capM = std(0xf6dc8a, 0.7);
  const back = new THREE.Mesh(new THREE.PlaneGeometry(nx * r * 1.8, ny * r * 1.6), std(0xc89a3a, 0.8)); back.position.z = -0.4; g.add(back);
  const wall = new THREE.CylinderGeometry(r, r, 0.6, 6, 1, true); wall.rotateX(Math.PI / 2);
  const honeyM = HONEY(); const cells = [];
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
    const x = (i - (nx - 1) / 2) * r * 1.75 + (j % 2) * r * 0.875, y = (j - (ny - 1) / 2) * r * 1.52;
    const w = new THREE.Mesh(wall, wax); w.position.set(x, y, -0.1); w.rotation.z = Math.PI / 6; g.add(w);
    const h = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.9, r * 0.9, 0.55, 6), honeyM); h.rotation.x = Math.PI / 2; h.rotation.y = 0; h.position.set(x, y, -0.38); g.add(h);
    const c = new THREE.Mesh(new THREE.CircleGeometry(r * 0.98, 6), capM); c.position.set(x, y, 0.2); c.rotation.z = Math.PI / 6; g.add(c);
    cells.push({ h, c, x, y, i, j });
  }
  function set(fill, cap) { cells.forEach((o, k) => { const f = typeof fill === 'function' ? fill(o, k) : fill, cp = typeof cap === 'function' ? cap(o, k) : cap; o.h.scale.set(1, Math.max(0.001, f), 1); o.h.position.z = -0.38 + 0.275 * f; o.h.visible = f > 0.01; o.c.scale.setScalar(Math.max(0.001, cp)); o.c.visible = cp > 0.01; }); }
  set(0, 0);
  return { group: g, cells, set };
}

// sugar molecules: glucose (hexagon, blue) + fructose (pentagon, orange) joined by a bond; split(k) pulls them apart
function ring(n, r, color) { const g = new THREE.Group(); const m = std(color, 0.3, 0.1, { emissive: color, emissiveIntensity: 0.15 }); const pts = []; for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2 + Math.PI / 2; pts.push(new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, 0)); }
  pts.forEach((p, i) => { const q = pts[(i + 1) % n]; const d = q.clone().sub(p); const b = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, d.length(), 8), m); b.position.copy(p).add(q).multiplyScalar(0.5); b.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); g.add(b); const at = new THREE.Mesh(new THREE.SphereGeometry(0.11, 14, 10), m); at.position.copy(p); g.add(at); }); return g; }
export function sucrose() {
  const g = new THREE.Group(); const glu = ring(6, 0.5, 0x4aa8ff), fru = ring(5, 0.45, 0xff8a3a); g.add(glu, fru);
  const bond = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.6, 8), std(0xffffff, 0.3)); bond.rotation.z = Math.PI / 2; g.add(bond);
  return { group: g, split(k, t = 0) { glu.position.set(-0.7 - k * 0.2, k * 0.9, 0); fru.position.set(0.7 + k * 0.2, -k * 0.9, 0); glu.rotation.z = t * 0.5; fru.rotation.z = -t * 0.6; bond.scale.set(1, Math.max(0.001, 1 - k * 1.5), 1); bond.visible = k < 0.6; } };
}
// enzyme: purple blob with a notch
export function enzyme() { const g = new THREE.Group(); const m = std(0x9a5ad8, 0.4, 0, { emissive: 0x5a2a9a, emissiveIntensity: 0.3 }); const b = new THREE.Mesh(new THREE.SphereGeometry(0.4, 24, 16, 0.5, Math.PI * 2 - 1.0), m); b.rotation.y = Math.PI / 2; g.add(b); const inn = new THREE.Mesh(new THREE.SphereGeometry(0.38, 24, 16), m); inn.scale.set(0.2, 1, 1); g.add(inn); return g; }

// glass honey jar with honey
export function jar() {
  const g = new THREE.Group();
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.8, 2.0, 40, 1, true), new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transmission: 0.95, thickness: 0.1, transparent: true, opacity: 0.35, side: THREE.DoubleSide }));
  glass.position.y = 1.0; g.add(glass);
  const h = new THREE.Mesh(new THREE.CylinderGeometry(0.76, 0.76, 1.7, 40), HONEY()); h.position.y = 0.87; g.add(h);
  const lid = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.3, 40), std(0xd8a030, 0.4, 0.6)); lid.position.y = 2.1; g.add(lid);
  const lab = new THREE.Mesh(new THREE.CylinderGeometry(0.805, 0.805, 0.7, 40, 1, true, -0.9, 1.8), std(0xfff4d8, 0.8)); lab.position.y = 0.95; g.add(lab);
  return g;
}
// teaspoon with a honey drop of size k (1 = one twelfth of a spoonful)
export function spoon() {
  const g = new THREE.Group(); const m = std(0xd8dde4, 0.18, 1.0);
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.5, 32, 16, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), m); bowl.scale.set(1, 0.35, 0.7); g.add(bowl);
  const handle = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.05, 0.16), m); handle.position.set(-1.55, 0.0, 0); handle.rotation.z = -0.06; g.add(handle);
  const drop = new THREE.Mesh(new THREE.SphereGeometry(0.15, 24, 16), HONEY()); drop.scale.y = 0.5; drop.position.y = -0.1; g.add(drop);
  g.userData.drop = drop; return g;
}
export { std };
