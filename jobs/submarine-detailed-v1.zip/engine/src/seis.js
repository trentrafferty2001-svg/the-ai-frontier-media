// Zhang Heng seismoscope reel: bronze jar with 8 dragons (balls in mouths) and 8 toads, optional cut-away with a
// hanging pendulum and 8 levers, Han hall / courtyard, seismic ring waves, runner.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex } from './rome.js';

let SM = null;
export function seisMats() {
  if (SM) return SM;
  SM = {
    bronze: new THREE.MeshPhysicalMaterial({ color: 0xb88a3a, metalness: 0.9, roughness: 0.35, clearcoat: 0.2 }),
    patina: new THREE.MeshStandardMaterial({ color: 0x4f8a72, metalness: 0.4, roughness: 0.6 }),
    gold: new THREE.MeshStandardMaterial({ color: 0xf0c040, metalness: 0.95, roughness: 0.2, emissive: 0x3a2800, emissiveIntensity: 0.3 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x140c06, roughness: 0.9 }),
    eye: new THREE.MeshStandardMaterial({ color: 0xffe060, emissive: 0xffa020, emissiveIntensity: 0.6 }),
    red: new THREE.MeshStandardMaterial({ color: 0xa83a2a, roughness: 0.8 }),
    roof: new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.7, map: (() => { const t = canvasTex(256, 256, (x) => { x.fillStyle = '#4e5c58'; x.fillRect(0, 0, 256, 256); for (let i = 0; i < 16; i++) { x.fillStyle = i % 2 ? '#3a4644' : '#62706a'; x.fillRect(i * 16, 0, 9, 256); } x.fillStyle = 'rgba(0,0,0,0.25)'; for (let j = 0; j < 8; j++) x.fillRect(0, j * 32, 256, 3); }); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(6, 1); return t; })() }),
    stone: new THREE.MeshStandardMaterial({ color: 0x9a948a, roughness: 0.9, bumpMap: fabricTexture(9), bumpScale: 3 }),
  };
  return SM;
}
// one dragon on the jar wall, facing outward (+z local), head at the top, ball in its mouth
// jar outer radius at height y (from the lathe profile), so dragon bodies lie ON the jar, not inside it
const JAR = [[0, 0.55], [0.15, 0.7], [0.6, 0.9], [1.1, 0.95], [1.6, 0.85], [1.85, 0.6], [1.95, 0.3]];
const jarR = (y) => { for (let i = 1; i < JAR.length; i++) if (y <= JAR[i][0]) { const [y0, r0] = JAR[i - 1], [y1, r1] = JAR[i]; return r0 + (r1 - r0) * (y - y0) / (y1 - y0); } return 0.3; };
function dragon() {
  const M = seisMats(); const g = new THREE.Group();
  const ZD = 0.86, YD = 1.55;
  const curve = new THREE.CatmullRomCurve3([[0, -0.9], [0.12, -0.6], [-0.1, -0.3], [0.05, 0.0], [0, 0.18]].map(([x, y]) => new THREE.Vector3(x, y, jarR(YD + y) - ZD + 0.11)));
  g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 40, 0.07, 10), M.patina));
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.14, 0.26), M.patina); head.position.set(0, 0.22, 0.2); g.add(head);
  const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.04, 0.2), M.patina); jaw.position.set(0, 0.12, 0.24); jaw.rotation.x = 0.35; g.add(jaw);
  for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 8), M.eye); e.position.set(s * 0.06, 0.28, 0.28); g.add(e); const h = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.14, 8), M.bronze); h.position.set(s * 0.05, 0.34, 0.12); h.rotation.x = -0.6; g.add(h); }
  const ball = new THREE.Mesh(new THREE.SphereGeometry(0.055, 18, 14), M.gold); ball.position.set(0, 0.17, 0.36); g.add(ball);
  g.ball = ball; g.ball0 = ball.position.clone(); g.jaw = jaw;
  return g;
}
function toad() {
  const M = seisMats(); const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 14), M.patina); body.scale.set(1.1, 0.7, 1.0); body.position.y = 0.15; g.add(body);
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.025, 8, 20), M.patina); mouth.rotation.x = -Math.PI / 2 + 0.5; mouth.position.set(0, 0.32, 0.06); g.add(mouth);
  const hole = new THREE.Mesh(new THREE.CircleGeometry(0.085, 20), M.dark); hole.rotation.x = -Math.PI / 2 + 0.5; hole.position.set(0, 0.315, 0.06); g.add(hole);
  for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.03, 12, 8), M.patina); e.position.set(s * 0.1, 0.33, -0.07); g.add(e); const pu = new THREE.Mesh(new THREE.SphereGeometry(0.012, 8, 6), M.dark); pu.position.set(s * 0.1, 0.345, -0.045); g.add(pu); const leg = new THREE.Mesh(new THREE.SphereGeometry(0.08, 10, 8), M.patina); leg.scale.set(1, 0.5, 1.4); leg.position.set(s * 0.2, 0.05, 0.05); g.add(leg); }
  g.mouthPos = new THREE.Vector3(0, 0.32, 0.06);
  return g;
}
// the instrument: jar radius ~0.9 at the belly, ~2.0 tall; dragons at angle i*45deg (i=0 faces +z = "south"),
// cut(k) fades the front of the jar so the pendulum + levers show; swing(ax, az) tilts the pendulum
export function seismoscope({ cutaway = false } = {}) {
  const M = seisMats(); const g = new THREE.Group();
  const prof = [[0, 0], [0.55, 0], [0.7, 0.15], [0.9, 0.6], [0.95, 1.1], [0.85, 1.6], [0.6, 1.85], [0.3, 1.95], [0.28, 2.05], [0.4, 2.12], [0.1, 2.3], [0, 2.32]].map(([a, b]) => new THREE.Vector2(a, b));
  const jarM = M.bronze.clone(); jarM.transparent = true; jarM.side = THREE.DoubleSide;
  const jar = new THREE.Mesh(new THREE.LatheGeometry(prof, 64), jarM); g.add(jar);
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.93, 0.03, 8, 64), M.patina); band.rotation.x = Math.PI / 2; band.position.y = 1.1; g.add(band);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(1.7, 1.8, 0.12, 48), M.stone); base.position.y = -0.06; g.add(base);
  g.dragons = []; g.toads = [];
  for (let i = 0; i < 8; i++) {
    const a = i / 8 * Math.PI * 2;
    const d = dragon(); const piv = new THREE.Group(); piv.rotation.y = a; g.add(piv); d.position.set(0, 1.55, 0.86); piv.add(d); g.dragons.push(d);
    const t = toad(); t.position.set(Math.sin(a) * 1.35, 0, Math.cos(a) * 1.35); t.rotation.y = a + Math.PI; g.add(t); g.toads.push(t);
  }
  // interior: pendulum + levers
  const inner = new THREE.Group(); g.add(inner);
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.3, 10), M.bronze); rod.position.y = -0.65;
  const bob = new THREE.Mesh(new THREE.SphereGeometry(0.22, 24, 16), M.bronze); bob.position.y = -1.3;
  const pend = new THREE.Group(); pend.position.y = 1.85; pend.add(rod, bob); inner.add(pend);
  g.levers = [];
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; const piv = new THREE.Group(); piv.rotation.y = a; inner.add(piv); const L = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 0.75), M.gold); L.position.set(0, 0.62, 0.4); piv.add(L); g.levers.push(L); }
  inner.visible = cutaway;
  g.pend = pend; g.inner = inner; g.jar = jar;
  g.cut = (k) => { jarM.opacity = 1 - 0.8 * k; jarM.depthWrite = k < 0.05; inner.visible = k > 0.02; band.visible = k < 0.3; [0, 1, 7].forEach(i => { g.dragons[i].visible = k < 0.3; }); };
  g.swing = (ax, az) => { pend.rotation.set(ax, 0, az); };
  g.drop = (i, u) => { // u 0..1: ball falls from mouth into the toad below
    const d = g.dragons[i]; const t = g.toads[i];
    if (u <= 0) { d.ball.position.copy(d.ball0); d.ball.visible = true; return; }
    g.updateMatrixWorld(true);
    const p0 = d.localToWorld(d.ball0.clone()), p1 = t.localToWorld(t.mouthPos.clone()); g.worldToLocal(p0); g.worldToLocal(p1);
    const k = Math.min(1, u), e = k * k;
    const p = new THREE.Vector3(p0.x + (p1.x - p0.x) * k, p0.y + (p1.y - p0.y) * e, p0.z + (p1.z - p0.z) * k);
    d.worldToLocal(g.localToWorld(p)); d.ball.position.copy(p); d.ball.visible = u < 1.05; d.jaw.rotation.x = 0.35 + Math.min(1, u * 4) * 0.35;
  };
  if (cutaway) g.cut(1);
  return shadowAll(g);
}
// Han hall: stone floor, red pillars, back wall, roof beams (open front, +z)
export function hanHall(scene) {
  const M = seisMats();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(16, 16), M.stone); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const back = new THREE.Mesh(new THREE.BoxGeometry(14, 6, 0.3), M.red); back.position.set(0, 3, -5); back.receiveShadow = true; scene.add(back);
  for (const x of [-4.5, -1.5, 1.5, 4.5]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 5.5, 16), M.red); p.position.set(x, 2.75, -3.6); p.castShadow = true; scene.add(p); }
  const beam = new THREE.Mesh(new THREE.BoxGeometry(14, 0.4, 0.5), M.roof); beam.position.set(0, 5.6, -3.6); scene.add(beam);
  return floor;
}
// courtyard with a walled hall behind and a tiled roof
export function courtyard(scene) {
  const M = seisMats();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), M.stone); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.BoxGeometry(20, 4, 0.5), M.red); wall.position.set(0, 2, -7); wall.castShadow = wall.receiveShadow = true; scene.add(wall);
  const roof = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 21, 4, 1), M.roof); roof.rotation.set(0, 0, Math.PI / 2); roof.scale.set(1, 1, 0.5); roof.position.set(0, 4.4, -7); scene.add(roof);
  return floor;
}
// expanding seismic ring on the ground
export function ringWave(color = 0xffb040) {
  const m = new THREE.Mesh(new THREE.RingGeometry(0.96, 1.0, 96), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false, toneMapped: false }));
  m.rotation.x = -Math.PI / 2;
  m.set = (r, a) => { m.scale.setScalar(Math.max(0.01, r)); m.material.opacity = a; m.visible = a > 0.01; };
  return m;
}
