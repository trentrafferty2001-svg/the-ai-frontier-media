// The Explainer: how bees make honey. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { bee, flowerCup, comb, sucrose, enzyme, jar, spoon, HONEY, std } from './honey.js';
import { rnd } from './bolt.js';
import { trees } from './world.js';
import { label } from './gps.js';
import { VO } from './vo_hn.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *honeybee*', 2], ['makes just', 2], ['*one twelfth*', 2], ['of a *teaspoon*', 3], ['of honey', 2], ['in her', 2], ['*whole life*', 2]],
  [['It starts', 2], ['as *nectar*', 2], ['a sugary juice', 3], ['inside *flowers*', 2], ["and it's", 2], ['mostly *water*', 2]],
  [['The bee', 2], ['*sucks it up*', 3], ['with a *tongue*', 3], ['like a *straw*', 3], ['and stores it', 3], ['in a *second*', 3], ['*stomach*', 1]],
  [['There', 1], ['*enzymes*', 1], ['start *breaking*', 2], ['the sugar down', 3], ['into *simpler*', 2], ['*sugars*', 1]],
  [['Back at', 2], ['the *hive*', 2], ['she *passes* it', 3], ['*mouth to mouth*', 3], ['to other bees', 3], ['who add', 2], ['even *more*', 2], ['*enzymes*', 1]],
  [['They *spread* it', 3], ['into *wax cells*', 3], ['then *fan*', 2], ['their wings', 2], ['to blow the', 3], ['*extra water*', 2], ['away', 1]],
  [["When it's", 2], ['less than', 2], ['*a fifth water*', 3], ['they *seal*', 2], ['each cell', 2], ['with a *wax lid*', 4]],
  [['With so', 2], ['*little water*', 2], ["*germs* can't", 2], ['grow in it', 3], ['so *honey*', 2], ['*keeps for years*', 3]],
  [['A single *jar*', 3], ['can take nectar', 3], ['from about', 2], ['*two million*', 2], ['*flowers*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 38) => { const c = cam(fov); c.near = 0.02; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.45, warm: 1.12, sat: 1.22, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

// garden: grass disc, trees, a cluster of flowers; returns flower list
function garden(makeStage, n = 14) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.6, 0.5, 0.7], fog: 0.02, shadowSize: 3, envI: 1.0, cloud: 0.3 });
  const g = new THREE.Mesh(new THREE.CircleGeometry(80, 48), std(0x5f9a3c, 1)); g.rotation.x = -Math.PI / 2; scene.add(g);
  const spots = []; for (let k = 0; k < 50; k++) { const a = k * 2.4, r = 12 + (k % 7) * 3; spots.push([Math.cos(a) * r, 0, Math.sin(a) * r]); } scene.add(trees(spots, { seed: 3, scale: 1.4 }));
  const R = rnd(8); const F = []; const cols = [0xff7aa8, 0xb07aff, 0xffffff, 0xffa64a];
  for (let k = 0; k < n; k++) { const f = flowerCup(cols[k % 4]); const a = R() * 6.28, r = k === 0 ? 0 : 2.4 + R() * 3.5; f.position.set(Math.cos(a) * r, k === 0 ? 2.3 : 1.6 + R() * 0.6, Math.sin(a) * r - (k === 0 ? 0 : 2)); f.rotation.y = R() * 6; scene.add(f); F.push(f); }
  return { scene, F };
}
function hive(makeStage) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 5, 6] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x6a3e10); u.mid.value.set(0x4a2a0a); u.horizon.value.set(0x3a2008); u.floorC.value.set(0x2a1806); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xffe0a0, 0x3a2008, 0.6));
  const warm = new THREE.PointLight(0xffc060, 12, 30); warm.position.set(2, 3, 6); scene.add(warm);
  const Cm = comb(); scene.add(Cm.group);
  return { scene, Cm };
}

// ============ S0 hook: a bee lands next to a teaspoon holding a tiny drop: one twelfth ============
function sHook({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0xf7d58a); u.mid.value.set(0xf2c46a); u.horizon.value.set(0xe8b050); u.floorC.value.set(0xd9a040); }
  const table = new THREE.Mesh(new THREE.BoxGeometry(12, 0.2, 8), std(0x9a6a3a, 0.6)); table.position.y = -0.4; scene.add(table);
  const S = spoon(); S.position.set(0.3, 0, 0); scene.add(S);
  const J = jar(); J.position.set(-2.4, -0.3, -2.2); scene.add(J);
  const B = bee(); B.group.scale.setScalar(0.32); scene.add(B.group);
  const L = tag(scene, '1/12 teaspoon', 0.22, '#ffd34a', [0.3, 0.75, 0]);
  const c = C(36);
  return {
    scene, camera: c,
    update(t) {
      const land = easeOut(range(t, 0, 1.4));
      B.group.position.set(lerp(2.2, 0.55, land), lerp(1.4, 0.12, land) + 0.05 * Math.sin(t * 6) * (1 - land), lerp(0.2, -0.6, land)); B.group.rotation.y = lerp(0.6, 2.5, land);
      B.st.flap = t * 11; B.st.wingAmp = 1 - 0.8 * smooth(range(t, 1.2, 1.6)); B.update();
      S.userData.drop.scale.set(1, 0.5 + 0.03 * Math.sin(t * 3), 1);
      pop(L, easeOut(range(t, at(0, 'twelfth') - 0.2, at(0, 'twelfth') + 0.2)), 0.22);
      const k = easeInOut(range(t, 0, 4.6));
      orb(c, [0.3, 0.15, 0.2], lerp(4.0, 3.4, k), lerp(30, 14, k), lerp(30, 24, k));
      return { ...POST, dof: { focus: 2.8, aperture: 0.002, maxblur: 0.005 } };
    },
  };
}
// ============ S1: nectar in a flower, mostly water ============
function sNectar({ makeStage }) {
  const { scene, F } = garden(makeStage);
  const f0 = F[0]; const L = tag(scene, '~80% water', 0.2, '#bfe6ff', [f0.position.x, f0.position.y + 0.7, f0.position.z]);
  const c = C(36);
  return {
    scene, camera: c,
    update(t, T) {
      f0.userData.drop.scale.set(1, 0.75 + 0.04 * Math.sin(T * 3), 1);
      pop(L, easeOut(range(T, at(1, 'water') - 0.25, at(1, 'water') + 0.1)), 0.2);
      const k = easeInOut(range(t, 0, 4.8));
      const p = f0.position; orb(c, [p.x, p.y + 0.1, p.z], lerp(4.5, 2.0, k), lerp(20, 34, k), lerp(30, 40, k));
      return POST;
    },
  };
}
// ============ S2: the bee drinks; nectar fills its honey stomach (x-ray) ============
function sDrink({ makeStage }) {
  const { scene, F } = garden(makeStage);
  const f0 = F[0]; const B = bee(); B.group.scale.setScalar(0.55); scene.add(B.group);
  const p = f0.position; B.group.position.set(p.x - 0.5, p.y + 0.3, p.z); B.group.rotation.z = -0.25;
  const L = tag(scene, 'honey stomach', 0.16, '#ffd34a', [p.x - 0.3, p.y + 0.95, p.z]);
  const c = C(34);
  return {
    scene, camera: c,
    update(t, T) {
      B.st.flap = T * 0.3; B.st.wingAmp = 0.15; B.st.prob = smooth(range(T, at(2, 'sucks') - 0.3, at(2, 'sucks') + 0.2));
      const drink = smooth(range(T, at(2, 'sucks'), at(2, 'stores') + 0.3)); f0.userData.drop.scale.setScalar(Math.max(0.001, 1 - drink)); f0.userData.drop.scale.y *= 0.75;
      B.st.xray = smooth(range(T, at(2, 'stores') - 0.3, at(2, 'stores') + 0.1)); B.st.crop = drink; B.update();
      pop(L, easeOut(range(T, at(2, 'second') - 0.1, at(2, 'second') + 0.2)), 0.16);
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [p.x - 0.35, p.y + 0.3, p.z], lerp(3.0, 2.6, k), lerp(24, 10, k), lerp(16, 12, k));
      return POST;
    },
  };
}
// ============ S3: enzymes cut sucrose into glucose + fructose ============
function sEnzyme({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0xf2b54a); u.mid.value.set(0xe8a030); u.horizon.value.set(0xd48a20); u.floorC.value.set(0xc07810); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  const S = sucrose(); S.group.position.set(0, 0.3, 0); scene.add(S.group);
  const E = enzyme(); scene.add(E);
  const R = rnd(6); const bg = []; for (let i = 0; i < 18; i++) { const s = sucrose(); s.group.scale.setScalar(0.35); s.group.position.set((R() - 0.5) * 9, (R() - 0.5) * 9, -4 - R() * 4); s.split(R() < 0.5 ? 0 : 1); scene.add(s.group); bg.push([s, R()]); }
  const Lg = tag(scene, 'glucose', 0.42, '#7fc8ff', [-2.0, 1.5, 0]), Lf = tag(scene, 'fructose', 0.42, '#ffb07a', [2.0, -1.0, 0]);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      const tb = at(3, 'breaking');
      const ek = smooth(range(T, ls(3), tb)), eo = smooth(range(T, tb + 0.4, tb + 1.2)); E.position.set(lerp(0.2, 0, ek) + eo * 0.4, lerp(2.4, 0.3, ek) + eo * 1.6, 0.4); E.scale.setScalar(0.8); E.rotation.z = Math.sin(T * 3) * 0.2;
      const k = easeOut(range(T, tb + 0.1, tb + 0.8)); S.split(k, T - tb);
      bg.forEach(([s, ph]) => { s.group.rotation.set(T * 0.2 + ph * 6, T * 0.3, 0); });
      pop(Lg, easeOut(range(T, at(3, 'simpler'), at(3, 'simpler') + 0.25)), 0.42); pop(Lf, easeOut(range(T, at(3, 'sugars'), at(3, 'sugars') + 0.25)), 0.42);
      Lg.position.set(-0.8, 0.3 + 0.9 * k + 0.85, 0.5); Lf.position.set(0.8, 0.3 - 0.9 * k - 0.8, 0.5);
      const kk = easeInOut(range(t, 0, 4.0));
      orb(c, [0, 0.3, 0], lerp(7.5, 6.8, kk), lerp(-8, 8, kk), 4);
      return { ...POST, bloom: 0.5 };
    },
  };
}
// ============ S4: in the hive, two bees pass nectar mouth to mouth ============
function sPass({ makeStage }) {
  const { scene, Cm } = hive(makeStage);
  Cm.set((o) => (o.j < 4 ? 1 : 0), (o) => (o.j < 2 ? 1 : 0));
  const A = bee(), B = bee(); [A, B].forEach(b => { b.group.scale.setScalar(0.6); scene.add(b.group); });
  A.group.position.set(-0.62, 0.4, 0.75); B.group.position.set(0.62, 0.4, 0.75); B.group.rotation.y = Math.PI;
  const drop = new THREE.Mesh(new THREE.SphereGeometry(0.09, 16, 12), HONEY()); scene.add(drop);
  const c = C(36);
  return {
    scene, camera: c,
    update(t, T) {
      [A, B].forEach((b, i) => { b.st.flap = T * 0.2 + i; b.st.wingAmp = 0.1; b.st.prob = 0.6; b.update(); });
      const k = smooth(range(T, at(4, 'passes') - 0.1, at(4, 'mouth', 1) + 0.3)); drop.position.set(lerp(-0.25, 0.25, k), 0.33, 0.75); drop.scale.multiplyScalar(0.7); drop.scale.setScalar(0.8 + 0.2 * Math.sin(T * 5));
      const kk = easeInOut(range(t, 0, 5.4));
      orb(c, [0, 0.35, 0.7], lerp(6.4, 5.8, kk), lerp(52, 38, kk), lerp(20, 14, kk));
      return { ...POST, exposure: 1.1 };
    },
  };
}
// ============ S5: nectar spread into cells; bees fan their wings; water vapour rises ============
function sFan({ makeStage }) {
  const { scene, Cm } = hive(makeStage);
  const B = [bee(), bee(), bee()]; B.forEach((b, i) => { b.group.scale.setScalar(0.75); b.group.position.set(-1.6 + i * 1.6, -1.0 + (i % 2) * 1.6, 0.6); b.group.rotation.set(0, -0.3 + i * 0.3, Math.PI / 2 * (i % 2 ? -1 : 1) * 0.2); scene.add(b.group); });
  const R = rnd(17); const V = []; const vm = new THREE.MeshBasicMaterial({ color: 0xeaf6ff, transparent: true, opacity: 0.45, depthWrite: false });
  for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.07 + R() * 0.05, 10, 8), vm); scene.add(m); V.push([m, (R() - 0.5) * 4.5, (R() - 0.5) * 3, R()]); }
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      const fill = range(T, at(5, 'spread') - 0.2, at(5, 'cells') + 0.6);
      Cm.set((o) => smooth(range(fill * 1.6 - (o.j / 11) * 0.6 - (o.i / 9) * 0.2, 0, 1)) * 0.95, 0);
      const fan = smooth(range(T, at(5, 'fan') - 0.2, at(5, 'fan') + 0.2));
      B.forEach((b, i) => { b.st.flap = T * 13 + i; b.st.wingAmp = 0.1 + 0.9 * fan; b.update(); });
      const steam = smooth(range(T, at(5, 'blow') - 0.4, at(5, 'blow')));
      V.forEach(([m, x, y, ph]) => { const u = (ph + T * 0.5) % 1; m.position.set(x + Math.sin(T * 2 + ph * 6) * 0.1, y + u * 1.5, 0.4 + u * 1.2); m.scale.setScalar(Math.max(0.001, steam * (1 - u))); m.visible = steam > 0.01; });
      const kk = easeInOut(range(t, 0, 4.8));
      orb(c, [0, 0, 0], lerp(6.4, 5.6, kk), lerp(14, -6, kk), lerp(8, 4, kk));
      return { ...POST, exposure: 1.1 };
    },
  };
}
// ============ S6: under a fifth water -> cells capped with wax ============
function sCap({ makeStage }) {
  const { scene, Cm } = hive(makeStage);
  const L = tag(scene, 'under 20% water', 0.3, '#ffe8a0', [0, 1.95, 0.6]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      const cap = range(T, at(6, 'seal') - 0.2, le(6) + 0.3);
      Cm.set(0.95, (o) => easeOut(range(cap * 1.8 - (o.i / 9) * 0.5 - (o.j / 11) * 0.3, 0, 1)));
      pop(L, easeOut(range(T, at(6, 'fifth') - 0.2, at(6, 'fifth') + 0.2)) * (1 - range(T, at(6, 'seal') + 0.4, at(6, 'seal') + 0.8)), 0.3);
      const kk = easeInOut(range(t, 0, 3.8));
      orb(c, [0, 0, 0], lerp(5.0, 4.4, kk), lerp(-16, 6, kk), lerp(6, 10, kk));
      return { ...POST, exposure: 1.1 };
    },
  };
}
// ============ S7: germs can't grow in honey: they shrivel ============
function sGerms({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0xf2b54a); u.mid.value.set(0xe8a030); u.horizon.value.set(0xd48a20); u.floorC.value.set(0xc07810); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  const pool = new THREE.Mesh(new THREE.BoxGeometry(14, 4, 6), HONEY()); pool.position.y = -2.2; scene.add(pool);
  const R = rnd(23); const G = []; const gm = std(0x6ad84a, 0.5, 0, { emissive: 0x2a6a1a, emissiveIntensity: 0.3 });
  for (let i = 0; i < 6; i++) { const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.4, 6, 12), gm); b.rotation.z = Math.PI / 2; g.add(b); for (let k = 0; k < 6; k++) { const f = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.3, 4), gm); f.position.set(-0.4 + k * 0.16, 0.2, 0); g.add(f); } g.position.set(-0.8 + (i % 3) * 0.8, 0.8 + R() * 1.5, -0.3 + (i > 2 ? 0.8 : 0)); scene.add(g); G.push([g, R()]); }
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      G.forEach(([g, ph], i) => { const fall = smooth(range(T, ls(7) + 0.3 + ph * 0.6, ls(7) + 1.4 + ph * 0.6)); const die = smooth(range(T, at(7, 'grow') - 0.1 + ph * 0.4, at(7, 'grow') + 0.9 + ph * 0.4));
        g.position.y = lerp(1.4 + ph, 0.05, fall); g.rotation.z = T * (0.5 + ph) * (1 - die); g.scale.set(1 - 0.5 * die, 1 - 0.75 * die, 1); g.children[0].material.color.setRGB(lerp(0.42, 0.45, die), lerp(0.85, 0.38, die), lerp(0.29, 0.2, die)); });
      const kk = easeInOut(range(t, 0, 4.1));
      orb(c, [0, 0.7, 0], lerp(6.2, 5.6, kk), lerp(-6, 6, kk), lerp(18, 14, kk));
      return { ...POST, bloom: 0.4 };
    },
  };
}
// ============ S8: a jar in a meadow: about two million flowers ============
function sJar({ makeStage }) {
  const { scene, F } = garden(makeStage, 1);
  F[0].visible = false;
  const J = jar(); J.position.set(0, 2.0, 0); scene.add(J);
  const plinth = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.3, 2.0, 32), std(0x8a6a4a, 0.7)); plinth.position.y = 1.0; scene.add(plinth);
  // meadow: many small flowers as instanced discs
  const R = rnd(31); const n = 2400; const fm = new THREE.MeshStandardMaterial({ roughness: 0.6 });
  const im = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.2, 0.2, 0.05, 8), fm, n); scene.add(im);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), cl = new THREE.Color(); const cols = [0xff7aa8, 0xb07aff, 0xffffff, 0xffc21a, 0xffa64a];
  const P = []; for (let i = 0; i < n; i++) { const a = R() * 6.28, r = 1.6 + Math.sqrt(R()) * 30; P.push([Math.cos(a) * r, Math.sin(a) * r, R()]); im.setColorAt(i, cl.setHex(cols[i % 5])); }
  const L = tag(scene, '~2,000,000 flowers', 0.85, '#ffe14a', [0, 4.9, 0]);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      const grow = range(T, at(8, 'nectar') - 0.4, at(8, 'flowers') + 0.6);
      P.forEach(([x, z, d], i) => { const s = easeOut(range(grow * 1.4 - d * 0.4 - Math.hypot(x, z) / 60, 0, 0.3)); M.compose(new THREE.Vector3(x, 0.3, z), q, new THREE.Vector3(s, s, s).addScalar(0.0001)); im.setMatrixAt(i, M); });
      im.instanceMatrix.needsUpdate = true;
      pop(L, easeOut(range(T, at(8, 'two') - 0.1, at(8, 'two') + 0.2)), 0.85);
      const kk = easeInOut(range(t, 0, 5.0));
      orb(c, [0, 2.4, 0], lerp(6, 14, kk), lerp(20, 34, kk), lerp(10, 24, kk));
      return POST;
    },
  };
}

const SH = [sHook, sNectar, sDrink, sEnzyme, sPass, sFan, sCap, sGerms, sJar];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
