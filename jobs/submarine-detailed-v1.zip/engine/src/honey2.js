// detail kit for honey: fuzzy bee, veined wings, textured petals + stamens, waxy comb, flower-shaped meadow heads
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as H from './honey.js';
export * from './honey.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
const wingTex = () => cv(256, 512, (g, w, h) => { g.clearRect(0, 0, w, h); g.fillStyle = 'rgba(225,240,255,0.22)'; g.beginPath(); g.ellipse(w / 2, h / 2, w / 2 - 2, h / 2 - 2, 0, 0, 7); g.fill();
  g.strokeStyle = 'rgba(70,55,40,0.85)'; g.lineWidth = 3; g.beginPath(); g.ellipse(w / 2, h / 2, w / 2 - 3, h / 2 - 3, 0, 0, 7); g.stroke(); g.lineWidth = 2.2;
  [[0.5, 0.95, 0.35, 0.1], [0.5, 0.95, 0.62, 0.08], [0.5, 0.95, 0.2, 0.35], [0.5, 0.95, 0.85, 0.3], [0.42, 0.55, 0.75, 0.55], [0.3, 0.3, 0.7, 0.32]].forEach(([a, b, c, d]) => { g.beginPath(); g.moveTo(a * w, b * h); g.quadraticCurveTo((a + c) / 2 * w + 10, (b + d) / 2 * h, c * w, d * h); g.stroke(); }); });
const petalTex = (hex) => cv(256, 256, (g, w, h) => { const c = new THREE.Color(hex); const css = (k) => `rgb(${Math.min(255, c.r * 255 * k) | 0},${Math.min(255, c.g * 255 * k) | 0},${Math.min(255, c.b * 255 * k) | 0})`;
  const gr = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2); gr.addColorStop(0, css(0.7)); gr.addColorStop(0.35, css(1.0)); gr.addColorStop(1, css(1.12)); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.strokeStyle = css(0.78); g.globalAlpha = 0.45; g.lineWidth = 1.3; for (let k = 0; k < 28; k++) { const a = k / 28 * Math.PI * 2; g.beginPath(); g.moveTo(w / 2, h / 2); g.lineTo(w / 2 + Math.cos(a) * w * 0.5, h / 2 + Math.sin(a) * h * 0.5); g.stroke(); } });
const waxTex = () => { const t = cv(256, 256, (g, w, h) => { g.fillStyle = '#f2c860'; g.fillRect(0, 0, w, h); const R = rnd(5); for (let i = 0; i < 2500; i++) { const v = R(); g.fillStyle = v < 0.5 ? 'rgba(255,236,170,0.35)' : 'rgba(190,130,40,0.25)'; g.beginPath(); g.arc(R() * w, R() * h, 0.6 + R() * 2.2, 0, 7); g.fill(); } }); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(2, 2); return t; };

export function bee() {
  const B = H.bee(); const body = B.group.children[0]; const R = rnd(17);
  // hair: thin tapered strands over thorax, head and the yellow abdomen rings
  const hg = new THREE.ConeGeometry(0.008, 0.11, 4); hg.translate(0, 0.055, 0);
  const hm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 });
  const hairs = []; const up = new THREE.Vector3(0, 1, 0);
  const add = (c, r, n, col, sx = 1, filter = () => true) => { for (let i = 0; i < n; i++) { const d = new THREE.Vector3(R() - 0.5, R() - 0.5, R() - 0.5).normalize(); if (!filter(d)) continue; hairs.push([c.clone().add(new THREE.Vector3(d.x * r * sx, d.y * r, d.z * r)), d.add(new THREE.Vector3((R() - 0.5) * 0.5, 0.15, (R() - 0.5) * 0.5)).normalize(), col(R())]); } };
  add(new THREE.Vector3(0, 0, 0), 0.31, 1300, (v) => new THREE.Color().setHSL(0.1, 0.65, 0.42 + v * 0.2));
  add(new THREE.Vector3(0.44, 0.02, 0), 0.2, 160, (v) => new THREE.Color().setHSL(0.08, 0.35, 0.12 + v * 0.08), 1, d => d.x < -0.2);
  // abdomen bands: hairs follow the yellow rings (abdomen group at -0.55,-0.05; rings at x = 0.25 - k*0.14)
  for (let k = 0; k < 6; k += 2) { const r = 0.36 * Math.sin(Math.PI * (k + 0.8) / 6.6); for (let i = 0; i < 260; i++) { const a = R() * Math.PI * 2; const x = -0.55 + 0.25 - k * 0.14 + (R() - 0.5) * 0.1; const p = new THREE.Vector3(x, -0.05 + Math.cos(a) * r * 0.98, Math.sin(a) * r * 0.98); const d = new THREE.Vector3(-0.25, Math.cos(a), Math.sin(a)).normalize(); hairs.push([p, d, new THREE.Color().setHSL(0.11, 0.8, 0.5 + R() * 0.15)]); } }
  const im = new THREE.InstancedMesh(hg, hm, hairs.length); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  hairs.forEach(([p, d, c], i) => { q.setFromUnitVectors(up, d); M.compose(p, q, s.set(1, 0.4 + R() * 0.45, 1)); im.setMatrixAt(i, M); im.setColorAt(i, c); }); body.add(im);
  // veined wings
  const wt = tx('wing', wingTex);
  body.traverse(o => { if (o.isMesh && o.geometry.type === 'CircleGeometry' && o.material.transmission > 0) { o.material = new THREE.MeshPhysicalMaterial({ map: wt, transparent: true, roughness: 0.15, clearcoat: 0.5, iridescence: 0.8, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false }); } });
  // glossy compound eyes with a hex sheen + jointed legs
  body.traverse(o => { if (o.isMesh && o.material.color && o.material.color.getHex() === 0x0a0a0a) { o.material = new THREE.MeshPhysicalMaterial({ color: 0x15100c, roughness: 0.25, clearcoat: 1, sheen: 1, sheenColor: new THREE.Color(0x553a20) }); } });
  const blk = new THREE.MeshStandardMaterial({ color: 0x1c1610, roughness: 0.6 });
  for (let k = 0; k < 3; k++) [-1, 1].forEach(sd => { const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.008, 0.25, 6), blk); foot.position.set(0.15 - k * 0.15 + 0.06, -0.56, sd * 0.36); foot.rotation.x = sd * 1.1; body.add(foot);
    if (k === 2) { const pol = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 8), new THREE.MeshStandardMaterial({ color: 0xf2a020, roughness: 0.9 })); pol.position.set(-0.15, -0.42, sd * 0.3); body.add(pol); } });
  return B;
}
export function flowerCup(color = 0xff7aa8) {
  const g = H.flowerCup(color); const R = rnd(color % 97);
  const map = tx('petal' + color, () => petalTex(color));
  g.children.forEach(o => { if (o.isMesh && o.geometry.type === 'SphereGeometry' && o.scale.y < 0.2) { o.material = new THREE.MeshPhysicalMaterial({ map, roughness: 0.55, sheen: 0.8, sheenColor: new THREE.Color(0xffffff), side: THREE.DoubleSide }); } });
  // second petal layer, stamens with pollen tips, sepals and a leaf on the stem
  const pm = new THREE.MeshPhysicalMaterial({ map, roughness: 0.55, sheen: 0.8, side: THREE.DoubleSide });
  for (let k = 0; k < 8; k++) { const p = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 10), pm); p.scale.set(1, 0.1, 0.4); const a = (k + 0.5) / 8 * Math.PI * 2; p.position.set(Math.cos(a) * 0.36, 0.1, Math.sin(a) * 0.36); p.rotation.y = -a; p.rotation.z = 0.55; g.add(p); }
  const sm = new THREE.MeshStandardMaterial({ color: 0xf6e8a0, roughness: 0.6 }), tm = new THREE.MeshStandardMaterial({ color: 0xf29a10, roughness: 0.9 });
  for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2 + R() * 0.2, r = 0.17 + R() * 0.04; const st = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.008, 0.16, 5), sm); st.position.set(Math.cos(a) * r, 0.12, Math.sin(a) * r); st.rotation.set(Math.sin(a) * 0.4, 0, -Math.cos(a) * 0.4); g.add(st);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.018, 8, 6), tm); tip.position.set(Math.cos(a) * (r + 0.03), 0.2, Math.sin(a) * (r + 0.03)); tip.scale.set(1, 0.7, 1.6); g.add(tip); }
  const lm = new THREE.MeshStandardMaterial({ color: 0x3f8f3a, roughness: 0.6, side: THREE.DoubleSide });
  for (let k = 0; k < 5; k++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 6), lm); s.scale.set(1, 0.08, 0.35); const a = k / 5 * 6.28; s.position.set(Math.cos(a) * 0.15, -0.1, Math.sin(a) * 0.15); s.rotation.y = -a; s.rotation.z = -0.5; g.add(s); }
  const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.5, 14, 8), lm); leaf.scale.set(1, 0.05, 0.3); leaf.position.set(0.4, -1.4, 0); leaf.rotation.z = 0.5; g.add(leaf);
  return g;
}
export function comb(nx, ny, r) {
  const C = H.comb(nx, ny, r); const wt = tx('wax', waxTex);
  const seen = new Set(); C.group.traverse(o => { if (o.isMesh && !seen.has(o.material) && (o.material.color.getHex() === 0xf0c25a || o.material.color.getHex() === 0xc89a3a || o.material.color.getHex() === 0xf6dc8a)) { seen.add(o.material); o.material.map = wt; o.material.bumpMap = wt; o.material.bumpScale = 0.6; o.material.roughness = 0.42; o.material.color.multiplyScalar(1.15); o.material.needsUpdate = true; } });
  return C;
}
// 5-petal flat flower head geometry (for instanced meadows)
export function flowerHeadGeo(r = 0.22) { const sh = new THREE.Shape(); for (let i = 0; i <= 60; i++) { const a = i / 60 * Math.PI * 2; const rr = r * (0.45 + 0.55 * Math.abs(Math.cos(a * 2.5))); const x = Math.cos(a) * rr, y = Math.sin(a) * rr; i ? sh.lineTo(x, y) : sh.moveTo(x, y); } const g = new THREE.ShapeGeometry(sh); g.rotateX(-Math.PI / 2); return g; }
export function woodMat() { const t = cv(512, 512, (g, w, h) => { g.fillStyle = '#9a6a3a'; g.fillRect(0, 0, w, h); const R = rnd(29); for (let i = 0; i < 160; i++) { const y = R() * h; g.strokeStyle = R() < 0.5 ? 'rgba(90,52,22,0.35)' : 'rgba(190,140,80,0.25)'; g.lineWidth = 1 + R() * 3; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= w; x += 32) g.lineTo(x, y + Math.sin(x * 0.02 + i) * 4); g.stroke(); }
  for (let k = 1; k < 4; k++) { g.fillStyle = 'rgba(60,35,15,0.6)'; g.fillRect(0, k * h / 4, w, 3); } }); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(2, 1.4); return new THREE.MeshPhysicalMaterial({ map: t, roughness: 0.45, clearcoat: 0.5, clearcoatRoughness: 0.3 }); }
