import * as THREE from 'three';
const at_ = (m, x, y, z) => { m.position.set(x, y, z); return m; };
// detail kit for the jet engine: airport apron, terminal, hangars, trees, engine test stand, panel-lined nacelle
import { groundMat, leafyTrees, grass } from './hummer2.js';
import { rnd } from './bolt.js';
export * from './jet.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
function concreteTex() {
  return cv(512, 512, (g, w, h) => { g.fillStyle = '#8d9096'; g.fillRect(0, 0, w, h); const R = rnd(3);
    for (let i = 0; i < 14000; i++) { const v = 120 + R() * 40 | 0; g.fillStyle = `rgba(${v},${v},${v + 4},0.35)`; g.fillRect(R() * w, R() * h, 2, 2); }
    for (let i = 0; i < 30; i++) { g.fillStyle = 'rgba(60,60,64,0.12)'; g.beginPath(); g.ellipse(R() * w, R() * h, 10 + R() * 40, 6 + R() * 20, R() * 3, 0, 7); g.fill(); }
    g.strokeStyle = 'rgba(50,50,55,0.7)'; g.lineWidth = 3; g.strokeRect(0, 0, w, h); g.beginPath(); g.moveTo(w / 2, 0); g.lineTo(w / 2, h); g.moveTo(0, h / 2); g.lineTo(w, h / 2); g.stroke(); });
}
function glassTex() {
  return cv(256, 128, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#9fc4e0'); gr.addColorStop(1, '#3d5a74'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.strokeStyle = '#d9dee4'; g.lineWidth = 3; for (let x = 0; x <= w; x += 16) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); } for (let y = 0; y <= h; y += 32) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); } });
}
// gy = ground height; clear = keep this radius free of buildings
export function airport(scene, gy, { stand = false, seed = 4 } = {}) {
  const G = new THREE.Group(); G.position.y = gy; scene.add(G); const R = rnd(seed);
  const ct = concreteTex(); ct.repeat.set(30, 30);
  const apron = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), new THREE.MeshStandardMaterial({ map: ct, roughness: 0.9, color: 0xd8dade })); apron.rotation.x = -Math.PI / 2; apron.receiveShadow = true; G.add(apron);
  const gm = groundMat(); gm.map = gm.map.clone(); gm.map.repeat.set(120, 120); gm.map.needsUpdate = true;
  const field = new THREE.Mesh(new THREE.CircleGeometry(900, 64), gm); field.rotation.x = -Math.PI / 2; field.position.y = -0.03; G.add(field);
  // painted taxi lines + stand markings
  const yl = new THREE.MeshBasicMaterial({ color: 0xf2c21a }); const wl = new THREE.MeshBasicMaterial({ color: 0xf4f4f4 });
  const line = (x, z, l, w, ry, m) => { const p = new THREE.Mesh(new THREE.PlaneGeometry(l, w), m); p.rotation.set(-Math.PI / 2, 0, ry); p.position.set(x, 0.02, z); G.add(p); };
  line(0, 9, 200, 0.35, 0, yl); line(0, -9, 200, 0.35, 0, yl); line(-30, 0, 200, 0.35, Math.PI / 2, yl); line(30, 0, 200, 0.35, Math.PI / 2, yl);
  for (let k = -6; k <= 6; k++) line(k * 14, 20, 6, 0.6, Math.PI / 2, wl);
  // runway beyond the apron, with centre dashes
  const rw = new THREE.Mesh(new THREE.PlaneGeometry(1400, 45), new THREE.MeshStandardMaterial({ color: 0x3c3f44, roughness: 0.95 })); rw.rotation.x = -Math.PI / 2; rw.position.set(0, 0.01, -160); G.add(rw);
  for (let k = -40; k <= 40; k++) line(k * 18, -160, 9, 0.9, 0, wl);
  // terminal: long building with a glass band and a curved roof, plus jet bridges
  const gt = glassTex(); gt.repeat.set(14, 1);
  const term = new THREE.Group(); term.position.set(0, 0, 118); term.rotation.y = Math.PI; G.add(term);
  const base = new THREE.Mesh(new THREE.BoxGeometry(170, 6, 26), new THREE.MeshStandardMaterial({ color: 0xc9cdd3, roughness: 0.7 })); base.position.y = 3; term.add(base);
  const glass = new THREE.Mesh(new THREE.BoxGeometry(170, 9, 24), new THREE.MeshStandardMaterial({ map: gt, roughness: 0.15, metalness: 0.4 })); glass.position.y = 10.5; term.add(glass);
  const roof = new THREE.Mesh(new THREE.CylinderGeometry(20, 20, 176, 40, 1, false, -0.6, 1.2), new THREE.MeshStandardMaterial({ color: 0xe6e8ec, roughness: 0.4, metalness: 0.5 })); roof.rotation.z = Math.PI / 2; roof.position.y = -3.2; term.add(roof);
  const tower = new THREE.Group(); tower.position.set(62, 0, 6); term.add(tower);
  tower.add(at_(new THREE.Mesh(new THREE.CylinderGeometry(2.4, 3.2, 34, 20), new THREE.MeshStandardMaterial({ color: 0xd5d8dd, roughness: 0.6 })), 0, 17, 0));
  tower.add(at_(new THREE.Mesh(new THREE.CylinderGeometry(6, 4.5, 5, 16), new THREE.MeshStandardMaterial({ color: 0x4d7090, roughness: 0.1, metalness: 0.6 })), 0, 36, 0));
  tower.add(at_(new THREE.Mesh(new THREE.CylinderGeometry(6.6, 6.6, 1, 16), new THREE.MeshStandardMaterial({ color: 0xe8eaee })), 0, 39, 0));
  for (let k = -3; k <= 3; k++) { const b = new THREE.Mesh(new THREE.BoxGeometry(2.6, 3, 22), new THREE.MeshStandardMaterial({ color: 0xb4b9c0, roughness: 0.5, metalness: 0.3 })); b.position.set(k * 22, 6, 23); b.rotation.y = 0.15; term.add(b); }
  // hangars (half cylinders) on the other sides
  const hm = new THREE.MeshStandardMaterial({ color: 0xa9b2bc, roughness: 0.55, metalness: 0.5 });
  [[-115, -20, Math.PI / 2], [-110, 45, Math.PI / 2], [118, 30, -Math.PI / 2]].forEach(([x, z, ry]) => { const h = new THREE.Mesh(new THREE.CylinderGeometry(16, 16, 40, 32, 1, false, 0, Math.PI), hm); h.rotation.set(0, ry, Math.PI / 2); h.position.set(x, 0, z); G.add(h);
    const door = new THREE.Mesh(new THREE.CircleGeometry(15.5, 32, 0, Math.PI), new THREE.MeshStandardMaterial({ color: 0x3a4250, roughness: 0.6 })); door.position.set(x - Math.sin(ry) * 20.1, 0, z - Math.cos(ry) * 20.1); door.rotation.y = ry + Math.PI; G.add(door); });
  // parked service trucks and cones
  const truckC = [0xf2a516, 0xe9edf2, 0x2a6fd6];
  for (let k = 0; k < 6; k++) { const a = R() * Math.PI * 2, r = 26 + R() * 30; const t = new THREE.Group(); t.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); t.rotation.y = R() * 6;
    t.add(at_(new THREE.Mesh(new THREE.BoxGeometry(4, 1.8, 2), new THREE.MeshStandardMaterial({ color: truckC[k % 3], roughness: 0.5 })), 0, 1.3, 0));
    t.add(at_(new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 1.9), new THREE.MeshStandardMaterial({ color: 0x26303a, roughness: 0.3 })), 2.3, 1.2, 0));
    [-1.3, 1.3].forEach(x => [-1, 1].forEach(z => { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.3, 14), new THREE.MeshStandardMaterial({ color: 0x1a1a1a })); w.rotation.x = Math.PI / 2; w.position.set(x, 0.42, z); t.add(w); }));
    G.add(t); }
  // tree belt
  const spots = []; for (let i = 0; i < 120; i++) { const a = R() * Math.PI * 2, r = 170 + R() * 90; spots.push([Math.cos(a) * r, 0, Math.sin(a) * r]); }
  G.add(leafyTrees(spots, { seed: 12, leaves: 1700, scale: 3.0 }));
  const gb = grass(7000, 125, 165, 19); G.add(gb);
  // engine test stand: two yellow cradles + a base frame
  if (stand) { const sm = new THREE.MeshStandardMaterial({ color: 0xf2b21a, roughness: 0.45, metalness: 0.4 }), dm = new THREE.MeshStandardMaterial({ color: 0x6a717a, roughness: 0.5, metalness: 0.6 });
    const H = -gy - 1.42;
    [1.0, -1.4].forEach(x => { [-0.75, 0.75].forEach(z => { const p = new THREE.Mesh(new THREE.BoxGeometry(0.16, H, 0.16), sm); p.position.set(x, H / 2, z * 0.7); G.add(p); });
      const xb = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.16, 1.2), sm); xb.position.set(x, H * 0.45, 0); G.add(xb); const pad = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 1.25), dm); pad.position.set(x, H, 0); G.add(pad); });
    const frame = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.18, 1.8), dm); frame.position.set(-0.2, 0.09, 0); G.add(frame);
     }
  return G;
}
// panel seams + rivets on the white nacelle
export function panelNacelle(E) {
  const t = cv(1024, 256, (g, w, h) => { g.fillStyle = '#ffffff'; g.fillRect(0, 0, w, h); g.strokeStyle = 'rgba(90,100,115,0.55)'; g.lineWidth = 2;
    for (let x = 0; x <= w; x += 128) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); } [70, 190].forEach(y => { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); });
    g.fillStyle = 'rgba(110,118,130,0.6)'; for (let x = 6; x < w; x += 12) [64, 76, 184, 196].forEach(y => { g.beginPath(); g.arc(x, y, 1.6, 0, 7); g.fill(); }); });
  t.repeat.set(2, 1);
  E.group.traverse(o => { if (o.isMesh && o.material && o.material.color && o.material.color.getHex() === 0xe9edf2 && !o.material.map) { o.material = o.material.clone(); o.material.map = t; o.material.roughness = 0.38; o.material.metalness = 0.3; o.material.needsUpdate = true; } });
}
