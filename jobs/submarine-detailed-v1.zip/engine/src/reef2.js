// Detailed reef kit (Explainer detailed December, 17 Nov): staghorn coral (recursive branches), lattice sea fans,
// grooved brain coral, swaying anemones, tube sponges, kelp with blades, a school of small fish, textured rocks.
// Call reefDetail(scene, { cold, seed, keepClear }) after sea(); it registers its own animation updater.
import * as THREE from 'three';
import { rng } from './textures.js';
function canvasTex(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
let FAN = null, BRAIN = null, ROCK = null;
const fanTex = () => FAN || (FAN = canvasTex(256, 256, (g, w, h) => { g.clearRect(0, 0, w, h); g.strokeStyle = '#ffffff'; const R = rng(3);
  const br = (x, y, a, l, d) => { if (d > 7 || l < 4) return; const x2 = x + Math.cos(a) * l, y2 = y - Math.sin(a) * l; g.lineWidth = Math.max(1, 6 - d * 0.7); g.beginPath(); g.moveTo(x, y); g.lineTo(x2, y2); g.stroke(); br(x2, y2, a + 0.25 + R() * 0.2, l * 0.8, d + 1); br(x2, y2, a - 0.25 - R() * 0.2, l * 0.8, d + 1); };
  br(w / 2, h, Math.PI / 2, 52, 0); g.lineWidth = 1; g.globalAlpha = 0.6; for (let y = 20; y < h; y += 7) { g.beginPath(); g.arc(w / 2, h, h - y, Math.PI * 1.08, Math.PI * 1.92); g.stroke(); } }));
const brainTex = () => BRAIN || (BRAIN = canvasTex(256, 256, (g, w, h) => { g.fillStyle = '#c8a070'; g.fillRect(0, 0, w, h); g.strokeStyle = '#6a4a2a'; g.lineWidth = 4; const R = rng(5);
  for (let i = 0; i < 26; i++) { g.beginPath(); let x = R() * w, y = R() * h; g.moveTo(x, y); for (let k = 0; k < 30; k++) { x += Math.cos(k * 0.6 + i) * 9; y += Math.sin(k * 0.45 + i * 2) * 9; g.lineTo(x, y); } g.stroke(); } }));
const rockTex = () => ROCK || (ROCK = canvasTex(256, 256, (g, w, h) => { g.fillStyle = '#7a6f62'; g.fillRect(0, 0, w, h); const R = rng(8); for (let i = 0; i < 3000; i++) { const v = R(); g.fillStyle = v < 0.5 ? `rgba(40,35,30,${0.2 + R() * 0.3})` : v < 0.8 ? `rgba(160,150,130,0.3)` : `rgba(${80 + R() * 60},${110 + R() * 50},80,0.35)`; g.fillRect(R() * w, R() * h, 1 + R() * 4, 1 + R() * 4); } }));

let SKINB = null;
const skinBump = () => SKINB || (SKINB = (() => { const t = canvasTex(512, 512, (g, w, h) => { g.fillStyle = '#808080'; g.fillRect(0, 0, w, h); const R = rng(17); for (let i = 0; i < 2600; i++) { const x = R() * w, y = R() * h, r = 1.5 + R() * 4; const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(255,255,255,0.9)'); gr.addColorStop(1, 'rgba(128,128,128,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 6.3); g.fill(); } }); t.colorSpace = THREE.NoColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 3); return t; })());
export function bumpSkin(obj) { obj.traverse(o => { if (o.isMesh && o.geometry && o.geometry.attributes.uv && o.material && o.material.isMeshPhysicalMaterial && o.material.sheen > 0) { o.material.bumpMap = skinBump(); o.material.bumpScale = 1.2; o.material.needsUpdate = true; } }); }
export function rockMat() { const t = rockTex(); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(4, 4); return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 3, roughness: 0.92 }); }
export function reefDetail(scene, { cold = false, seed = 11, keepClear = 1.6, count = 1 } = {}) {
  const R = rng(seed); const G = new THREE.Group(); scene.add(G); const sway = [];
  const cols = cold ? [0x8a9aa8, 0x6f7f8e, 0xa8b0b8] : [0xf07a5a, 0xf2c14e, 0xb06ad8, 0x58c7a8, 0xf09ab8, 0xff9a3a, 0x7ad0ff];
  const spot = (rMin, rMax) => { for (let tries = 0; tries < 30; tries++) { const a = R() * Math.PI * 2, r = rMin + R() * (rMax - rMin); const x = Math.cos(a) * r, z = -Math.abs(Math.sin(a) * r) - 0.6; if (Math.hypot(x, z) > keepClear && z < -0.6) return [x, -0.11, z]; } return [rMax, -0.11, -rMax]; };
  // staghorn coral: recursive capsule branches
  const stag = (pos, col) => { const g = new THREE.Group(); g.position.set(...pos); G.add(g); const m = new THREE.MeshStandardMaterial({ color: col, roughness: 0.75 });
    const br = (p, dir, len, r, d) => { if (d > 4) return; const c = new THREE.Mesh(new THREE.CapsuleGeometry(r, len, 3, 6), m); c.position.copy(p).addScaledVector(dir, len / 2); c.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir); c.castShadow = true; g.add(c);
      const end = p.clone().addScaledVector(dir, len); const n = 2 + (R() < 0.4 ? 1 : 0); for (let i = 0; i < n; i++) { const nd = dir.clone().add(new THREE.Vector3((R() - 0.5) * 1.1, 0.2 + R() * 0.3, (R() - 0.5) * 1.1)).normalize(); br(end, nd, len * (0.7 + R() * 0.15), r * 0.8, d + 1); } };
    for (let i = 0; i < 4; i++) br(new THREE.Vector3((R() - 0.5) * 0.1, 0, (R() - 0.5) * 0.1), new THREE.Vector3((R() - 0.5) * 0.6, 1, (R() - 0.5) * 0.6).normalize(), 0.09 + R() * 0.05, 0.016, 0); };
  // sea fan: lattice texture on a plane, sways
  const fan = (pos, col) => { const s = 0.4 + R() * 0.35; const f = new THREE.Mesh(new THREE.PlaneGeometry(s * 1.4, s), new THREE.MeshStandardMaterial({ map: fanTex(), color: col, transparent: true, alphaTest: 0.3, side: THREE.DoubleSide, roughness: 0.8 })); f.geometry.translate(0, s / 2, 0); f.position.set(...pos); f.rotation.y = R() * 3; G.add(f); sway.push({ o: f, ph: R() * 6, ax: 'x', a: 0.08 }); };
  // brain coral: grooved dome
  const brain = (pos) => { const d = new THREE.Mesh(new THREE.SphereGeometry(0.16 + R() * 0.12, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ map: brainTex(), bumpMap: brainTex(), bumpScale: 3, roughness: 0.85, color: cold ? 0xa0a8b0 : 0xffffff })); d.scale.y = 0.75; d.position.set(...pos); d.castShadow = true; G.add(d); };
  // anemone: disc + swaying tentacles
  const anem = (pos, col) => { const g = new THREE.Group(); g.position.set(...pos); G.add(g); const m = new THREE.MeshStandardMaterial({ color: col, roughness: 0.5, emissive: col, emissiveIntensity: 0.12 });
    const stalk = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.08, 16), new THREE.MeshStandardMaterial({ color: 0x9a5a4a, roughness: 0.7 })); stalk.position.y = 0.04; g.add(stalk);
    for (let i = 0; i < 34; i++) { const a = i / 34 * Math.PI * 2, rr = 0.02 + (i % 3) * 0.012; const t = new THREE.Group(); t.position.set(Math.cos(a) * rr, 0.08, Math.sin(a) * rr); const c = new THREE.Mesh(new THREE.CapsuleGeometry(0.006, 0.09, 3, 6), m); c.position.y = 0.05; t.add(c); t.rotation.set(Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5); g.add(t); sway.push({ o: t, ph: R() * 6 + a, ax: 'z', a: 0.25, base: t.rotation.z }); } };
  // tube sponges
  const sponge = (pos, col) => { const m = new THREE.MeshStandardMaterial({ color: col, roughness: 0.9, side: THREE.DoubleSide }); for (let i = 0; i < 4; i++) { const h = 0.15 + R() * 0.2; const c = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.03, h, 14, 1, true), m); c.position.set(pos[0] + (R() - 0.5) * 0.12, pos[1] + h / 2, pos[2] + (R() - 0.5) * 0.12); c.rotation.set((R() - 0.5) * 0.3, 0, (R() - 0.5) * 0.3); c.castShadow = true; G.add(c); } };
  // kelp: stipe + blades
  const kelp = (pos) => { const g = new THREE.Group(); g.position.set(...pos); G.add(g); const H = 1.2 + R() * 1.4; const m = new THREE.MeshStandardMaterial({ color: cold ? 0x4a6a4a : 0x6a8a2a, roughness: 0.7, side: THREE.DoubleSide });
    const st = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.01, H, 6), m); st.position.y = H / 2; g.add(st);
    for (let i = 0; i < 12; i++) { const b = new THREE.Mesh(new THREE.PlaneGeometry(0.06, 0.22), m); b.geometry.translate(0.03, 0.11, 0); b.position.y = H * (0.15 + i / 12 * 0.85); b.rotation.set(0, i * 2.4, 0.6); g.add(b); }
    sway.push({ o: g, ph: R() * 6, ax: 'z', a: 0.1 }); };
  for (let k = 0; k < 14 * count; k++) stag(spot(0.7, 4), cols[k % cols.length]);
  for (let k = 0; k < 10 * count; k++) fan(spot(1.0, 4.5), cols[(k + 2) % cols.length]);
  for (let k = 0; k < 10 * count; k++) brain(spot(0.7, 4));
  for (let k = 0; k < 12 * count; k++) anem(spot(0.6, 3.5), cols[(k + 4) % cols.length]);
  for (let k = 0; k < 8 * count; k++) sponge(spot(0.9, 4.5), cols[(k + 1) % cols.length]);
  for (let k = 0; k < 18 * count; k++) { const p = spot(2.2, 6); if (p[2] < -1.8) kelp(p); }
  // texture any existing rocks
  scene.traverse(o => { if (o.isMesh && o.material && o.material.color && o.geometry && o.geometry.type === 'IcosahedronGeometry' && o.material.roughness > 0.9 && !o.material.map) { o.material.map = rockTex(); o.material.bumpMap = rockTex(); o.material.bumpScale = 2; o.material.color.set(0xffffff); o.material.needsUpdate = true; } });
  // a school of small fish
  const fg = new THREE.ConeGeometry(0.018, 0.07, 6); fg.rotateZ(-Math.PI / 2); const NF = 46;
  const fish = new THREE.InstancedMesh(fg, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3, metalness: 0.4 }), NF); G.add(fish); const FD = [];
  for (let i = 0; i < NF; i++) { FD.push([(R() - 0.5) * 0.9, (R() - 0.5) * 0.4, (R() - 0.5) * 0.6, R() * 6]); fish.setColorAt(i, new THREE.Color().setHSL(cold ? 0.58 : 0.12 + R() * 0.05, 0.8, 0.6)); }
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(1, 1, 1), e = new THREE.Euler();
  scene.userData.updaters.push((t) => {
    sway.forEach(w => { const v = Math.sin(t * 1.1 + w.ph) * w.a; if (w.ax === 'x') w.o.rotation.x = v; else w.o.rotation.z = (w.base || 0) + v; });
    const cx = Math.sin(t * 0.12) * 2, cz = -2.4 + Math.cos(t * 0.12) * 0.8, cy = 0.7 + Math.sin(t * 0.3) * 0.2; const hd = Math.atan2(-Math.sin(t * 0.12) * 1.2 * 0.12, Math.cos(t * 0.12) * 3 * 0.12);
    FD.forEach(([x, y, z, ph], i) => { e.set(0, -hd, Math.sin(t * 6 + ph) * 0.1); q.setFromEuler(e); M.compose(new THREE.Vector3(cx + x + Math.sin(t + ph) * 0.05, cy + y, cz + z), q, s); fish.setMatrixAt(i, M); }); fish.instanceMatrix.needsUpdate = true;
  });
  return G;
}
