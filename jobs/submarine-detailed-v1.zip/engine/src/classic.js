// Archimedes screw reel: the screw (helical blade, shaft, cut-away tube, crank, riding water pockets), Greek
// landscape, Greek temple, Roman mine tunnel, Assyrian relief wall, modern hydropower screw.
import * as THREE from 'three';
import { mountains, trees, ringSpots, waterMaterial } from './world.js';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex, archMats } from './rome.js';

// ---------- the screw: axis along +y in its own group (tilt the group), bottom at y=0 ----------
export function archScrew({ L = 3.2, R = 0.32, turns = 7, tube = true, steel = false, crank = true, stream = true } = {}) {
  const g = new THREE.Group(); const inner = new THREE.Group(); g.add(inner);
  const wood = new THREE.MeshStandardMaterial({ color: 0x8a5d34, roughness: 0.8, bumpMap: fabricTexture(5), bumpScale: 2, side: THREE.DoubleSide });
  const met = new THREE.MeshStandardMaterial({ color: 0x9aa2aa, metalness: 0.85, roughness: 0.3, side: THREE.DoubleSide });
  const M = steel ? met : wood;
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(R * 0.18, R * 0.18, L + 0.3, 16), M); shaft.position.y = L / 2; inner.add(shaft);
  // helical blade: ruled surface from the shaft to the rim
  const nu = turns * 48, nv = 6, pos = [], idx = [];
  for (let i = 0; i <= nu; i++) { const u = i / nu, a = u * turns * Math.PI * 2, y = u * L; for (let j = 0; j <= nv; j++) { const r = R * (0.18 + 0.8 * j / nv); pos.push(Math.cos(a) * r, y, Math.sin(a) * r); } }
  for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) { const a = i * (nv + 1) + j, b = a + nv + 1; idx.push(a, b, a + 1, b, b + 1, a + 1); }
  const bg = new THREE.BufferGeometry(); bg.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); bg.setIndex(idx); bg.computeVertexNormals();
  inner.add(new THREE.Mesh(bg, M));
  // tube: back half solid (staves), front half cut away so we see inside
  if (tube) {
    const tm = steel ? met : new THREE.MeshStandardMaterial({ color: 0x6a4524, roughness: 0.85, bumpMap: fabricTexture(9), bumpScale: 3, side: THREE.DoubleSide });
    const back = new THREE.Mesh(new THREE.CylinderGeometry(R * 1.02, R * 1.02, L, 32, 1, true, Math.PI * 0.5, Math.PI * 1.15), tm); back.position.y = L / 2; g.add(back);
    for (const y of [0.05, L * 0.35, L * 0.68, L - 0.05]) { const hoop = new THREE.Mesh(new THREE.TorusGeometry(R * 1.05, 0.025, 6, 32, Math.PI * 1.15), new THREE.MeshStandardMaterial({ color: 0x3a3a3a, metalness: 0.6, roughness: 0.4 })); hoop.rotation.x = Math.PI / 2; hoop.rotation.z = Math.PI * 0.5; hoop.position.y = y; g.add(hoop); }
  }
  if (crank) {
    const c = new THREE.Group(); c.position.y = L + 0.15; inner.add(c);
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.05, 0.05), M); arm.position.x = 0.21; c.add(arm);
    const hdl = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.28, 8), M); hdl.position.set(0.42, 0.14, 0); c.add(hdl);
    g.userData.handle = hdl;
  }
  // water pockets: one per flight, resting on the low side; they advance one pitch per turn
  const pitch = L / turns;
  const wm = new THREE.MeshPhysicalMaterial({ color: 0x4fa8d8, roughness: 0.05, transmission: 0.3, clearcoat: 1, emissive: 0x0e4a6a, emissiveIntensity: 0.35 });
  const pockets = [...Array(turns + 1)].map(() => { const p = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 14), wm); p.scale.set(R * 0.55, pitch * 0.22, R * 0.4); g.add(p); return p; });
  // spout stream at the top + spill
  let jet = null;
  if (stream) { jet = new THREE.Mesh(new THREE.CylinderGeometry(R * 0.25, R * 0.18, 1, 12, 1, true), new THREE.MeshStandardMaterial({ color: 0x6fbfe8, roughness: 0.05, transparent: true, opacity: 0.85, emissive: 0x0e3a5a, emissiveIntensity: 0.3 })); g.add(jet); }
  g.L = L; g.R = R; g.pitch = pitch;
  // angle: screw rotation (radians); fill: 0..1 how far up the water has climbed; flow: 0..1 spout
  g.set = (angle, fill = 1, flow = 1) => {
    inner.rotation.y = angle;
    const adv = (angle / (Math.PI * 2)) % 1;
    pockets.forEach((p, k) => {
      const y = (k + adv) * pitch - pitch * 0.5;
      const vis = y > 0 && y < L && y < fill * L;
      p.visible = vis; p.position.set(0, y, -R * 0.42); // low side is -z after tilting about x
    });
    if (jet) { jet.visible = flow > 0.02 && fill >= 0.98; jet.scale.set(1, 0.9, 1); jet.position.set(0, L + 0.05, -R * 0.9); jet.rotation.x = -0.6; }
  };
  g.set(0, 0, 0);
  return shadowAll(g);
}

// ---------- Greek inventor / workers ----------
export function greek({ color = 0xf2ede0, beard = true, skin = 0xd8a07a } = {}) {
  const h = romanBuilder({ color, skin });
  const M = new THREE.MeshStandardMaterial({ color: 0xe8e4da, roughness: 0.9, bumpMap: fabricTexture(13), bumpScale: 2, side: THREE.DoubleSide });
  const himation = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.33, 0.7, 24, 2, true, 0.3, Math.PI * 1.2), M); himation.position.set(0, -0.05, 0); himation.rotation.y = -0.4; himation.scale.z = 0.72; h.j.chest.add(himation);
  if (beard) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.1, 16, 12, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.55), new THREE.MeshStandardMaterial({ color: 0x8a8278, roughness: 0.9, bumpMap: fabricTexture(3), bumpScale: 4 })); b.position.set(0, -0.085, 0.07); b.scale.set(0.75, 0.9, 0.6); h.j.head.add(b); }
  return shadowAll(h.root), h;
}

// ---------- Mediterranean countryside ----------
export function medLand(scene, { y = 0, seed = 1, groundC = 0x9a9460 } = {}) {
  const gm = new THREE.MeshStandardMaterial({ color: groundC, roughness: 1, bumpMap: fabricTexture(23 + seed), bumpScale: 4 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 64), gm); ground.rotation.x = -Math.PI / 2; ground.position.y = y; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 90, rMax: 320, height: 30, seed: 4 + seed, color: 0x7a7a4a }));
  scene.add(trees(ringSpots(30, 40, 110, 7 + seed, [0, 0, 0], 0, Math.PI * 2, y - 0.1), { seed: 5 + seed, scale: 1.4 }));
  const cm = new THREE.MeshStandardMaterial({ color: 0x2f4a24, roughness: 0.9 });
  ringSpots(22, 14, 60, 21 + seed, [0, 0, 0], 0, Math.PI * 2, y).forEach(([x, yy, z], i) => { const h = 4 + (i % 4); const c = new THREE.Mesh(new THREE.ConeGeometry(0.55, h, 10), cm); c.position.set(x, yy + h / 2, z); c.castShadow = true; scene.add(c); });
  return ground;
}
// a river channel cut into the ground (water surface below ground level) and a raised field ditch
export function river(scene, { z = 0, w = 4, y = 0.02, len = 200 } = {}) {
  const water = new THREE.Mesh(new THREE.PlaneGeometry(len, w), waterMaterial({ color: 0x2f5a5a, opacity: 1, ripple: 1.5 })); water.rotation.x = -Math.PI / 2; water.position.set(0, y, z); scene.add(water);
  const bank = new THREE.MeshStandardMaterial({ color: 0x6a5a3a, roughness: 1 });
  for (const s of [-1, 1]) { const b = new THREE.Mesh(new THREE.BoxGeometry(len, 0.12, 0.5), bank); b.position.set(0, y + 0.03, z + s * (w / 2 + 0.2)); scene.add(b); }
  return water;
}
// simple Greek temple (Doric): stylobate, peristyle of columns, entablature, pediments, roof
export function greekTemple({ w = 8, d = 14, colH = 4.2 } = {}) {
  const A = archMats(); const g = new THREE.Group();
  const marble = new THREE.MeshStandardMaterial({ color: 0xe8dfcc, roughness: 0.6 });
  for (let i = 0; i < 3; i++) { const s = new THREE.Mesh(new THREE.BoxGeometry(w + 1.2 - i * 0.4, 0.25, d + 1.2 - i * 0.4), marble); s.position.y = 0.125 + i * 0.25; g.add(s); }
  const nx = 6, nz = 11;
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) { if (i > 0 && i < nx - 1 && j > 0 && j < nz - 1) continue; const c = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.36, colH, 16), marble); c.position.set(-w / 2 + 0.4 + i * (w - 0.8) / (nx - 1), 0.75 + colH / 2, -d / 2 + 0.4 + j * (d - 0.8) / (nz - 1)); g.add(c); }
  const ent = new THREE.Mesh(new THREE.BoxGeometry(w + 0.2, 0.9, d + 0.2), marble); ent.position.y = 0.75 + colH + 0.45; g.add(ent);
  const tri = new THREE.Shape(); tri.moveTo(-w / 2 - 0.1, 0); tri.lineTo(w / 2 + 0.1, 0); tri.lineTo(0, 1.4); tri.lineTo(-w / 2 - 0.1, 0);
  const roof = new THREE.Mesh(new THREE.ExtrudeGeometry(tri, { depth: d + 0.2, bevelEnabled: false }), new THREE.MeshStandardMaterial({ color: 0xb85a34, roughness: 0.8 })); roof.position.set(0, 0.75 + colH + 0.9, -d / 2 - 0.1); g.add(roof);
  return shadowAll(g);
}
// Roman mine tunnel: rock tube, flooded floor, lamps
export function mineTunnel(scene, { len = 30, r = 2.2 } = {}) {
  const rock = new THREE.MeshStandardMaterial({ color: 0x5a4a3a, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 8, flatShading: true, side: THREE.BackSide });
  const geo = new THREE.CylinderGeometry(r, r, len, 24, 30, true); const p = geo.attributes.position; const R = rng(5);
  for (let i = 0; i < p.count; i++) { const k = 1 + (R() - 0.5) * 0.18; p.setX(i, p.getX(i) * k); p.setZ(i, p.getZ(i) * k); }
  geo.computeVertexNormals();
  const t = new THREE.Mesh(geo, rock); t.rotation.x = Math.PI / 2; t.position.y = r * 0.6; t.receiveShadow = true; scene.add(t);
  const water = new THREE.Mesh(new THREE.PlaneGeometry(r * 2, len), waterMaterial({ color: 0x24302a, opacity: 1, ripple: 0.8 })); water.rotation.x = -Math.PI / 2; water.position.y = -0.4; scene.add(water);
  const lamps = [];
  for (let i = 0; i < 5; i++) { const l = new THREE.PointLight(0xffa050, 4, 9, 2); l.position.set(i % 2 ? 1.6 : -1.6, 1.8, -i * 5 + 4); scene.add(l); lamps.push(l); const fl = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffc070 })); fl.position.copy(l.position); scene.add(fl); }
  return { lamps };
}
// Assyrian-style carved relief panel (canvas), with a spiral screw motif among palace gardens
export function reliefWall() {
  const tex = canvasTex(512, 512, (x) => {
    x.fillStyle = '#b8a688'; x.fillRect(0, 0, 512, 512);
    const R = rng(4); for (let i = 0; i < 900; i++) { x.fillStyle = `rgba(80,65,45,${R() * 0.12})`; x.fillRect(R() * 512, R() * 512, 2 + R() * 4, 2 + R() * 4); }
    x.strokeStyle = 'rgba(60,48,32,0.85)'; x.lineWidth = 4; x.fillStyle = 'rgba(150,132,104,1)';
    for (const y of [16, 250, 496]) { x.beginPath(); x.moveTo(0, y); x.lineTo(512, y); x.stroke(); }
    // palm trees
    for (let i = 0; i < 5; i++) { const px = 40 + i * 110; x.beginPath(); x.moveTo(px, 240); x.lineTo(px + 6, 120); x.stroke(); for (let k = 0; k < 6; k++) { x.beginPath(); x.moveTo(px + 6, 120); x.quadraticCurveTo(px + 6 + Math.cos(k) * 30, 100, px + 6 + Math.cos(k * 1.1) * 50, 130 + k * 4); x.stroke(); } }
    // spiral screw shape in a tilted tube
    x.save(); x.translate(256, 380); x.rotate(-0.5); x.strokeRect(-150, -26, 300, 52);
    x.beginPath(); for (let t = -150; t <= 150; t += 2) { x.lineTo(t, Math.sin(t / 14) * 22); } x.stroke(); x.restore();
    // water lines
    for (let k = 0; k < 4; k++) { x.beginPath(); for (let t = 0; t < 512; t += 8) x.lineTo(t, 470 + k * 6 + Math.sin(t / 20 + k) * 3); x.stroke(); }
    // figures
    for (let i = 0; i < 3; i++) { const fx = 70 + i * 160; x.beginPath(); x.arc(fx, 300, 10, 0, 7); x.stroke(); x.beginPath(); x.moveTo(fx, 310); x.lineTo(fx, 350); x.lineTo(fx - 10, 380); x.moveTo(fx, 350); x.lineTo(fx + 10, 380); x.moveTo(fx, 320); x.lineTo(fx + 18, 335); x.stroke(); }
  });
  const m = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9, bumpMap: tex, bumpScale: 6 });
  const g = new THREE.Group();
  const wall = new THREE.Mesh(new THREE.BoxGeometry(6, 6, 0.4), m); wall.position.y = 3; g.add(wall);
  return shadowAll(g);
}
// modern hydropower screw: concrete trough at an incline, steel screw, generator box
export function hydroScrew() {
  const g = new THREE.Group();
  const conc = new THREE.MeshStandardMaterial({ color: 0x9a9a96, roughness: 0.9, bumpMap: fabricTexture(31), bumpScale: 2 });
  const tilt = new THREE.Group(); tilt.rotation.x = -Math.PI / 2 + 0.38; g.add(tilt); // axis tilted 22° up toward -z
  const slab = new THREE.Mesh(new THREE.BoxGeometry(2.8, 9.6, 0.3), conc); slab.position.set(0, 4.5, -1.35); tilt.add(slab);
  const scr = archScrew({ L: 9, R: 1.15, turns: 3, tube: false, steel: true, crank: false, stream: false }); tilt.add(scr);
  const walls = [-1, 1].map(s => { const w = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.4, 9.6), conc); w.position.set(s * 1.65, 0.4, -4.1); g.add(w); return w; });
  const gen = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.6, 1.6), new THREE.MeshStandardMaterial({ color: 0x2a5a8a, roughness: 0.4, metalness: 0.4 })); gen.position.set(0, 4.4, -9.4); g.add(gen);
  const bolt = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.6, 3), new THREE.MeshStandardMaterial({ color: 0xffd43b, emissive: 0xffb000, emissiveIntensity: 1.2 })); bolt.position.set(0, 4.4, -8.55); bolt.rotation.x = Math.PI / 2; g.add(bolt);
  g.screw = scr; g.bolt = bolt;
  return shadowAll(g);
}
