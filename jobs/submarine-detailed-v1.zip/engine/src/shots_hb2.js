// The Explainer: how hummingbirds hover. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { hummingbird, flower, songbird, arrow, grass, bush, groundMat, leafyTrees, flowerShrubs } from './hummer2.js';
import { mountains } from './world.js';
import { trees } from './world.js';
import { label } from './gps.js';
import { VO } from './vo_hb2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *hummingbird*', 2], ['can hang', 2], ['*perfectly still*', 2], ['in mid air', 3], ['beating its wings', 3], ['up to', 2], ['*80 times*', 2], ['a *second*', 2]],
  [['Most birds', 2], ['only get *lift*', 3], ['when their wings', 3], ['push *down*', 2]],
  [['A hummingbird', 2], ['gets lift', 2], ['on the way', 3], ['*back* too', 2]],
  [['Its wings', 2], ["*don't* really *flap*", 3], ['They *sweep*', 2], ['forwards', 1], ['and backwards', 2], ['in a', 2], ['*figure of eight*', 3]],
  [['At the end', 3], ['of each sweep', 3], ['the *shoulder*', 2], ['*flips* the wing', 3], ['almost', 1], ['*upside down*', 2]],
  [['So the wing', 3], ['pushes air *down*', 3], ['in *both*', 2], ['*directions*', 1]],
  [['About', 1], ['*three quarters*', 2], ['of the lift', 3], ['comes from the', 3], ['*forward* sweep', 2], ['and a *quarter*', 3], ['from the', 2], ['*back* sweep', 2]],
  [["That's how", 2], ['it *hovers*', 2], ['and even flies', 3], ['*backwards*', 1]],
  [['But it burns', 3], ['*energy* fast', 2], ['Its *heart*', 2], ['can beat', 2], ['over a *thousand*', 3], ['*times a minute*', 3]],
  [['So it sips', 3], ['*nectar* all day', 3], ['sometimes its', 2], ['*own body weight*', 3], ['just to stay', 3], ['in the air', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ---------- helpers ----------
const C = (fov = 36) => { const c = cam(fov); c.near = 0.002; c.far = 300; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.5, warm: 1.1, sat: 1.22, exposure: 1.02, aoRadius: 0.02 };
const FL = new THREE.Vector3(0.0, 1.0, 0); // flower mouth
function garden(makeStage) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.4, 0.7, 0.6], fog: 0.008, shadowSize: 0.5, shadowAt: [0, 1, 0], envI: 1.0, cloud: 0.42 });
  scene.userData.key.shadow.camera.near = 0.1; scene.userData.key.shadow.camera.far = 30;
  const g = new THREE.Mesh(new THREE.CircleGeometry(60, 48), groundMat()); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; scene.add(g);
  scene.add(grass());
  const shrubSpots = []; for (let k = 0; k < 22; k++) { const a = -2.9 + k * 0.12 + (k % 3) * 0.05, r = 1.6 + (k % 5) * 0.9; shrubSpots.push([Math.cos(a) * r, 0.15, Math.sin(a) * r]); } scene.add(flowerShrubs(shrubSpots)); const B1 = bush(3); B1.position.set(-0.15, 0.55, -0.45); scene.add(B1); const B2 = bush(5, 300, 0.3); B2.position.set(0.35, 0.5, -0.3); scene.add(B2);
  const spots = []; for (let k = 0; k < 26; k++) { const a = k * 2.4, r = 7 + (k % 7) * 3; spots.push([Math.cos(a) * r, 0, Math.sin(a) * r]); }
  scene.add(leafyTrees(spots, { seed: 7, leaves: 1800 }));
  const F = flower(1); F.position.copy(FL); F.scale.setScalar(0.7); scene.add(F);
  // a few more flowers behind for colour
  for (let k = 0; k < 6; k++) { const f = flower(k + 2); f.scale.setScalar(0.75); f.position.set(-0.25 + k * 0.1, 0.92 + (k % 3) * 0.05, -0.25 - (k % 2) * 0.15); f.rotation.y = k; scene.add(f); }
  const H = hummingbird(); scene.add(H.group);
  H.group.position.set(FL.x - 0.068, FL.y - 0.008, 0); // beak tip at the flower mouth
  return { scene, H };
}
const POSE = (H) => H.group.position;

// ============ S0 hook: hovering perfectly still at the flower, wings a blur ============
function sHook({ makeStage }) {
  const { scene, H } = garden(makeStage);
  const c = C(34);
  return {
    scene, camera: c,
    update(t) {
      H.st.blur = 1; H.st.phase = t * 9.7; H.update(); // aliased fast wingbeat; the fan shows the blur
      const k = easeInOut(range(t, 0, 5.8));
      orb(c, [FL.x - 0.06, FL.y + 0.0, 0], lerp(0.32, 0.22, k), lerp(35, 70, k), lerp(8, 4, k));
      return { ...POST, dof: { focus: 0.22, aperture: 0.005, maxblur: 0.006 } };
    },
  };
}
// ============ S1: a normal bird: lift only on the downstroke ============
function sSongbird({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.4, 0.7, 0.6], fog: 0.008, shadowSize: 1, shadowAt: [0, 2, 0], envI: 1.0, cloud: 0.42 });
  const B = songbird(); B.group.position.set(0, 2, 0); scene.add(B.group);
  const gr = new THREE.Mesh(new THREE.CircleGeometry(80, 48), groundMat()); gr.rotation.x = -Math.PI / 2; scene.add(gr); scene.add(mountains({ rMin: 60, rMax: 200, height: 28, color: 0x4a7a44 }));
  const ts = []; for (let k = 0; k < 18; k++) { const a = k * 2.4, r = 9 + (k % 6) * 3; ts.push([Math.cos(a) * r, 0, Math.sin(a) * r]); } scene.add(leafyTrees(ts, { seed: 9, leaves: 1500 }));
  const A = [arrow(), arrow()]; A.forEach((a, i) => { a.group.position.set(0, 2.02, (i ? 1 : -1) * 0.09); a.group.scale.setScalar(2); scene.add(a.group); });
  const c = C(36);
  return {
    scene, camera: c,
    update(t) {
      const ph = t * 1.1; B.flap(ph); B.group.position.y = 2 + 0.01 * Math.sin(ph * Math.PI * 2);
      const down = Math.max(0, Math.sin(ph * Math.PI * 2)); A.forEach((a) => { a.set(down * 1.5); a.group.position.y = 2.02 + 0.01; });
      orb(c, [0.02, 2.02, 0], 0.75, lerp(20, 35, smooth(range(t, 0, 3))), 10);
      return POST;
    },
  };
}
// shared slow-motion hummingbird shot with options
function slowShot({ arrows = false, trail = false, air = false, bars = false, back = false, heart = false, nectar = false, cam: camF, rate = 0.55 }) {
  return ({ makeStage }) => {
    const { scene, H } = garden(makeStage);
    const A = [arrow(), arrow()]; A.forEach((a) => { scene.add(a.group); a.group.visible = false; });
    let trailLine = null;
    if (trail) { // sample the wingtip over one cycle to draw the figure-eight
      const pts = []; const v = new THREE.Vector3();
      for (let k = 0; k <= 120; k++) { H.st.phase = k / 120; H.update(); H.group.updateMatrixWorld(true); H.tip.getWorldPosition(v); pts.push(v.clone()); }
      trailLine = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, true), 240, 0.0012, 6, true), new THREE.MeshBasicMaterial({ color: 0xffd21a })); scene.add(trailLine);
    }
    const NA = 70, airPts = new THREE.InstancedMesh(new THREE.SphereGeometry(0.0018, 6, 4), new THREE.MeshBasicMaterial({ color: 0xbfe8ff, transparent: true, opacity: 0.8 }), NA); airPts.frustumCulled = false; if (air) scene.add(airPts);
    const bar1 = new THREE.Mesh(new THREE.BoxGeometry(0.018, 1, 0.01), new THREE.MeshStandardMaterial({ color: 0x3fd0ff, emissive: 0x1a6080, emissiveIntensity: 0.4 }));
    const bar2 = bar1.clone(); bar2.material = bar1.material.clone(); bar2.material.color.set(0xffa040); bar2.material.emissive.set(0x80400a);
    const L1 = label('75%', { size: 0.02, color: '#7fe0ff' }), L2 = label('25%', { size: 0.02, color: '#ffc080' });
    if (bars) { [bar1, bar2].forEach((b, i) => { b.position.set(FL.x - 0.145 + i * 0.026, FL.y - 0.08, 0.04); scene.add(b); }); L1.sprite.position.set(FL.x - 0.145, FL.y - 0.0, 0.04); L2.sprite.position.set(FL.x - 0.119, FL.y - 0.0, 0.04); scene.add(L1.sprite, L2.sprite); }
    const L3 = label('1,000+ / min', { size: 0.016, color: '#ff8090' }); if (heart) { L3.sprite.position.set(FL.x - 0.07, FL.y + 0.05, 0.02); scene.add(L3.sprite); }
    const drops = []; if (nectar) for (let k = 0; k < 5; k++) { const d = new THREE.Mesh(new THREE.SphereGeometry(0.0022, 8, 6), new THREE.MeshStandardMaterial({ color: 0xffe080, emissive: 0xffc040, emissiveIntensity: 0.8 })); scene.add(d); drops.push(d); }
    const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), sc = new THREE.Vector3(1, 1, 1);
    const c = C(34);
    return {
      scene, camera: c,
      update(t, T) {
        const ph = t * rate; H.st.phase = ph; H.st.blur = 0;
        if (back) { const k = smooth(range(t, 0.8, 2.4)); H.group.position.set(FL.x - 0.075 - 0.12 * k, FL.y - 0.005 + 0.02 * k, 0); }
        if (heart) { H.st.heart = 1; H.st.beat = Math.max(0, Math.sin(t * Math.PI * 2 * 3)); }
        H.update();
        // lift arrows under each wing: strong on the forward sweep, weaker on the back sweep
        const fwd = Math.sin(ph * Math.PI * 2) >= 0; const k = Math.abs(Math.sin(ph * Math.PI * 2));
        A.forEach((a, i) => { a.group.visible = arrows; if (!arrows) return; a.group.position.set(POSE(H).x - 0.005, POSE(H).y + 0.012, (i ? 1 : -1) * 0.04); a.group.rotation.z = 0; a.group.scale.setScalar(0.9); a.set(k * (fwd ? 1.2 : 0.55)); });
        if (air) for (let i = 0; i < NA; i++) { const u = ((i / NA * 7.3) + t * 0.6) % 1; v.set(POSE(H).x + ((i * 37) % 11 - 5) * 0.006, POSE(H).y - 0.005 - u * 0.12, ((i * 53) % 13 - 6) * 0.007); m4.compose(v, q, sc); airPts.setMatrixAt(i, m4); }
        if (air) airPts.instanceMatrix.needsUpdate = true;
        if (bars) { const b1 = smooth(range(t, at(6, 'three') - ls(6), at(6, 'forward') - ls(6))), b2 = smooth(range(t, at(6, 'quarter') - ls(6) - 0.2, at(6, 'quarter') - ls(6) + 0.4)); bar1.scale.y = Math.max(0.001, 0.06 * b1); bar1.position.y = FL.y - 0.08 + 0.03 * b1; bar2.scale.y = Math.max(0.001, 0.02 * b2); bar2.position.y = FL.y - 0.08 + 0.01 * b2; L1.sprite.material.opacity = b1; L2.sprite.material.opacity = b2; }
        drops.forEach((d, i) => { const u = (t * 0.8 + i / 5) % 1; d.position.set(FL.x - 0.004 * u, FL.y + 0.003, 0.0); d.position.lerp(new THREE.Vector3(POSE(H).x + 0.025, POSE(H).y + 0.012, 0), u); d.scale.setScalar(1 - u * 0.6); });
        camF(c, t, T);
        return { ...POST, dof: { focus: 0.25, aperture: 0.0035, maxblur: 0.006 } };
      },
    };
  };
}
const sBoth = slowShot({ arrows: true, cam: (c, t) => orb(c, [FL.x - 0.075, FL.y - 0.01, 0], lerp(0.28, 0.24, smooth(range(t, 0, 2.4))), 15, 8) });
const sEight = slowShot({ trail: true, cam: (c, t) => orb(c, [FL.x - 0.075, FL.y, 0.02], lerp(0.3, 0.26, smooth(range(t, 0, 4.5))), lerp(80, 60, smooth(range(t, 0, 4.5))), 25) });
const sFlip = slowShot({ rate: 0.4, cam: (c, t) => orb(c, [FL.x - 0.075, FL.y, 0.04], 0.16, lerp(30, 55, smooth(range(t, 0, 4))), 18) });
const sAir = slowShot({ air: true, arrows: true, cam: (c, t) => orb(c, [FL.x - 0.075, FL.y - 0.04, 0], 0.32, 20, 4) });
const sBars = slowShot({ bars: true, arrows: true, cam: (c, t) => orb(c, [FL.x - 0.112, FL.y - 0.035, 0], lerp(0.44, 0.4, smooth(range(t, 0, 4.8))), 10, 6) });
const sBack = slowShot({ back: true, rate: 3, cam: (c, t) => orb(c, [FL.x - 0.12, FL.y + 0.005, 0], 0.4, 10, 6) });
const sHeart = slowShot({ heart: true, rate: 3, cam: (c, t) => orb(c, [FL.x - 0.075, FL.y + 0.01, 0], lerp(0.3, 0.22, smooth(range(t, 0, 4.5))), 25, 8) });
const sNectar = slowShot({ nectar: true, rate: 3, cam: (c, t) => orb(c, [FL.x - 0.05, FL.y, 0], lerp(0.2, 0.5, easeInOut(range(t, 0, 5.5))), lerp(60, 30, easeInOut(range(t, 0, 5.5))), lerp(4, 14, easeInOut(range(t, 0, 5.5)))) });

// ============ timeline ============
const SH = [sHook, sSongbird, sBoth, sEight, sFlip, sAir, sBars, sBack, sHeart, sNectar];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
