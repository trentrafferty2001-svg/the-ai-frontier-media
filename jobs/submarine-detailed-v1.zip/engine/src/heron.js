// Hero of Alexandria reel: temple front with two doors that turn on vertical posts, a hollow altar with fire,
// the hidden machinery under the floor (sealed water globe, pipes, bucket, ropes round the door-post drums,
// counterweight), earth cross-section, aeolipile, holy-water vending machine.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll } from './rome.js';
import { glowSprite } from './props.js';

let HM = null;
export function heronMats() {
  if (HM) return HM;
  HM = {
    marble: new THREE.MeshStandardMaterial({ color: 0xe8dfcc, roughness: 0.55 }),
    door: new THREE.MeshStandardMaterial({ color: 0x7a4a26, roughness: 0.6, bumpMap: fabricTexture(5), bumpScale: 2 }),
    bronze: new THREE.MeshPhysicalMaterial({ color: 0xc08a40, metalness: 0.9, roughness: 0.3 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, metalness: 0, transparent: true, opacity: 0.25, side: THREE.DoubleSide, depthWrite: false }),
    water: new THREE.MeshStandardMaterial({ color: 0x3a9ad8, roughness: 0.15, emissive: 0x0a3a6a, emissiveIntensity: 0.6, transparent: true, opacity: 0.9 }),
    rope: new THREE.MeshStandardMaterial({ color: 0xc8a868, roughness: 0.9 }),
    earth: new THREE.MeshStandardMaterial({ color: 0x5a4030, roughness: 1, bumpMap: fabricTexture(31), bumpScale: 4 }),
    iron: new THREE.MeshStandardMaterial({ color: 0x4a4a4e, metalness: 0.7, roughness: 0.5 }),
  };
  return HM;
}
const tube = (pts, r, m) => new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p)), false, 'catmullrom', 0), 64, r, 8), m);
// fire: a few additive flame sprites + light; set(k) scales it
export function fire(size = 1) {
  const g = new THREE.Group();
  const fl = [0, 1, 2, 3, 4].map(i => { const s = glowSprite([0xffa030, 0xff6a10, 0xffd060, 0xff8020, 0xffc040][i], 0.5 * size); g.add(s); return s; });
  const L = new THREE.PointLight(0xff8a30, 0, 6 * size, 1.6); L.position.y = 0.4 * size; g.add(L);
  g.set = (k, t) => { fl.forEach((s, i) => { const u = (t * 1.6 + i / 5) % 1; s.position.set(Math.sin(i * 2 + t * 3) * 0.08 * size, (0.1 + u * 0.6) * size * k, Math.cos(i * 3) * 0.05 * size); s.scale.setScalar((0.55 - u * 0.35) * size * k + 0.001); s.material.opacity = k * (1 - u * 0.6); }); L.intensity = 3 * k * (0.9 + 0.1 * Math.sin(t * 17)); g.visible = k > 0.01; };
  g.set(0, 0);
  return g;
}
// the whole rig. Temple front faces +z at z=0, floor at y=0. Doors hinge at x=±1.6 and swing inward (-z).
// set(k, f, t): k = how open (0..1), f = fire 0..1. cut(on): show the machinery/earth section.
export function rig() {
  const M = heronMats(); const g = new THREE.Group();
  const front = new THREE.Group(); g.add(front);
  // facade: wall with a doorway, columns, pediment
  const wallL = new THREE.Mesh(new THREE.BoxGeometry(2.4, 4.4, 0.5), M.marble); wallL.position.set(-2.8, 2.2, -0.3); front.add(wallL);
  const wallR = wallL.clone(); wallR.position.x = 2.8; front.add(wallR);
  const lint = new THREE.Mesh(new THREE.BoxGeometry(8, 0.9, 0.6), M.marble); lint.position.set(0, 4.85, -0.3); front.add(lint);
  for (const x of [-3.6, -2.2, 2.2, 3.6]) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.26, 4.4, 16), M.marble); c.position.set(x, 2.2, 0.35); front.add(c); }
  const tri = new THREE.Shape(); tri.moveTo(-4.1, 0); tri.lineTo(4.1, 0); tri.lineTo(0, 1.5); tri.lineTo(-4.1, 0);
  const ped = new THREE.Mesh(new THREE.ExtrudeGeometry(tri, { depth: 0.9, bevelEnabled: false }), M.marble); ped.position.set(0, 5.3, -0.6); front.add(ped);
  const dark = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 4.4), new THREE.MeshStandardMaterial({ color: 0x6a4a30, roughness: 1 })); dark.position.set(0, 2.2, -3); front.add(dark);
  // the cella behind the doors: side walls, floor and a warm lamp glow, instead of a black void
  const cellaM = new THREE.MeshStandardMaterial({ color: 0x8a6a48, roughness: 1 });
  for (const s of [-1, 1]) { const sw = new THREE.Mesh(new THREE.BoxGeometry(0.1, 4.4, 2.7), cellaM); sw.position.set(s * 1.62, 2.2, -1.7); front.add(sw); }
  const cf = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.05, 2.7), cellaM); cf.position.set(0, 0.03, -1.7); front.add(cf);
  const cc = new THREE.Mesh(new THREE.BoxGeometry(3.3, 0.1, 2.8), cellaM); cc.position.set(0, 4.42, -1.7); front.add(cc);
  const lamp = new THREE.PointLight(0xffb060, 6, 5, 1.5); lamp.position.set(0, 2.2, -1.6); front.add(lamp);
  const inner = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.8), new THREE.MeshStandardMaterial({ color: 0xffd080, emissive: 0xffa040, emissiveIntensity: 0.6 })); inner.position.set(0, 1.4, -2.95); front.add(inner); // the god's statue glow
  // doors: each pivots on a vertical post at its outer edge; post extends below the floor to a drum
  const doors = [-1, 1].map(s => {
    const piv = new THREE.Group(); piv.position.set(s * 1.6, 0, -0.3); g.add(piv);
    const d = new THREE.Mesh(new THREE.BoxGeometry(1.58, 4.3, 0.12), M.door); d.position.set(-s * 0.8, 2.15, 0); piv.add(d);
    for (let r = 0; r < 3; r++) { const stud = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.06, 0.03), M.bronze); stud.position.set(-s * 0.8, 0.8 + r * 1.3, 0.07); piv.add(stud); }
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 6.0, 10), M.iron); post.position.y = -0.7; piv.add(post);
    const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.3, 20), M.bronze); drum.position.y = -1.6; piv.add(drum);
    for (let w = 0; w < 4; w++) { const coil = new THREE.Mesh(new THREE.TorusGeometry(0.235, 0.022, 6, 28), M.rope); coil.rotation.x = Math.PI / 2; coil.position.y = -1.7 + w * 0.06; piv.add(coil); } // rope wound round the post
    return piv;
  });
  // altar in front
  const altar = new THREE.Group(); altar.position.set(0, 0, 2.6); g.add(altar);
  const ab = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.0, 1.0), M.marble); ab.position.y = 0.5; altar.add(ab);
  const top = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.12, 1.2), M.marble); top.position.y = 1.06; altar.add(top);
  const F = fire(1.2); F.position.y = 1.12; altar.add(F);
  const hotAir = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.85, 0.85), new THREE.MeshBasicMaterial({ color: 0xff6a20, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false })); hotAir.position.y = 0.5; altar.add(hotAir);
  // underground machinery
  const mech = new THREE.Group(); g.add(mech);
  const globe = new THREE.Mesh(new THREE.SphereGeometry(0.75, 32, 20), M.glass); globe.position.set(2.2, -1.4, 2.6); mech.add(globe);
  const gw = new THREE.Mesh(new THREE.SphereGeometry(0.72, 32, 20, 0, Math.PI * 2, Math.PI * 0.35, Math.PI * 0.65), M.water); gw.position.copy(globe.position); mech.add(gw);
  mech.add(tube([[0, 0.1, 2.6], [0, -0.8, 2.6], [1.0, -0.8, 2.6], [2.0, -0.7, 2.6]], 0.06, M.bronze)); // altar -> top of globe (air)
  mech.add(tube([[2.4, -1.9, 2.6], [3.2, -1.9, 2.4], [3.6, -1.0, 1.4], [3.95, -1.0, 0.4], [4.0, -1.5, 0.05], [3.85, -2.0, -0.15]], 0.05, M.bronze)); // siphon -> bucket
  const bucket = new THREE.Group(); mech.add(bucket);
  const bk = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.32, 0.6, 24, 1, true), M.bronze); bk.material = M.bronze; bucket.add(bk);
  const bkBase = new THREE.Mesh(new THREE.CircleGeometry(0.32, 24), M.bronze); bkBase.rotation.x = -Math.PI / 2; bkBase.position.y = -0.3; bucket.add(bkBase);
  const bw = new THREE.Mesh(new THREE.CylinderGeometry(0.37, 0.32, 1, 24), M.water); bucket.add(bw);
  const cw = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.6, 0.5), M.iron); mech.add(cw);
  const ropeB = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1, 6), M.rope); mech.add(ropeB);
  const ropeC = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1, 6), M.rope); mech.add(ropeC);
  const ropeH = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 7.2, 6), M.rope); ropeH.rotation.z = Math.PI / 2; ropeH.position.set(0, -1.6 + 0.16, -0.3); mech.add(ropeH); // pulley -> door-post drums -> pulley
  const pulleys = [-1, 1].map(s => { const p = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.04, 8, 20), M.iron); p.position.set(s * 3.6 - s * 0.16, -1.6, -0.3); mech.add(p); return p; });
  // earth section + floor
  const floorM = new THREE.MeshStandardMaterial({ color: 0xd8ccb0, roughness: 0.8 });
  const floor = new THREE.Mesh(new THREE.BoxGeometry(40, 0.3, 30), floorM); floor.position.set(0, -0.15, 0); floor.receiveShadow = true; g.add(floor);
  const earth = new THREE.Mesh(new THREE.BoxGeometry(14, 5, 0.2), M.earth); earth.position.set(0, -2.8, -2.2); g.add(earth);
  const earthB = new THREE.Mesh(new THREE.BoxGeometry(14, 0.2, 6), M.earth); earthB.position.set(0, -5.2, 1.4); g.add(earthB);
  g.cut = (on) => { floor.castShadow = !on; floorM.transparent = on; floorM.opacity = on ? 0.22 : 1; floorM.depthWrite = !on; floorM.needsUpdate = true; earth.visible = earthB.visible = on; mech.visible = on; doors.forEach(d => d.children.slice(-2).forEach(c => c.visible = on)); };
  g.set = (k, f, t = 0) => {
    doors.forEach((d, i) => { d.rotation.y = (i ? 1 : -1) * k * 1.35; });
    F.set(f, t); hotAir.material.opacity = 0.35 * f;
    gw.scale.set(1, Math.max(0.05, 1 - k * 0.85), 1); gw.position.y = -1.4 - k * 0.3;
    const by = -2.45 - k * 1.1; bucket.position.set(3.6, by, -0.3); bw.scale.y = Math.max(0.02, k * 0.5); bw.position.y = -0.3 + bw.scale.y / 2;
    ropeB.position.set(3.6, (by + 0.3 - 1.6) / 2, -0.3); ropeB.scale.y = Math.abs(-1.6 - (by + 0.3)) + 0.01;
    const cy = -3.8 + k * 1.0; cw.position.set(-3.6, cy, -0.3); ropeC.position.set(-3.6, (cy + 0.3 - 1.6) / 2, -0.3); ropeC.scale.y = Math.abs(-1.6 - (cy + 0.3)) + 0.01;
    pulleys.forEach(p => p.rotation.z = k * 6);
  };
  g.cut(false); g.set(0, 0, 0);
  g.altar = altar; g.doors = doors; g.globe = globe; g.bucket = bucket; g.cw = cw;
  return shadowAll(g);
}
// aeolipile: cauldron + sphere on pivots with two bent jets; spin(a), steam sprites
export function aeolipile() {
  const M = heronMats(); const g = new THREE.Group();
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.42, 0.6, 24), M.bronze); pot.position.y = 0.3; g.add(pot);
  for (const s of [-1, 1]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.9, 8), M.bronze); p.position.set(s * 0.45, 1.0, 0); g.add(p); }
  const ball = new THREE.Group(); ball.position.y = 1.3; g.add(ball);
  ball.add(new THREE.Mesh(new THREE.SphereGeometry(0.32, 24, 16), M.bronze));
  for (const s of [-1, 1]) { ball.add(tube([[s * 0.28, 0, 0], [s * 0.5, 0, 0], [s * 0.52, 0, s * 0.05], [s * 0.52, 0, s * 0.24]], 0.04, M.bronze)); const nz = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.08, 12), M.bronze); nz.rotation.x = s * Math.PI / 2; nz.position.set(s * 0.52, 0, s * 0.27); ball.add(nz); }
  for (const s of [-1, 1]) { const piv = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.14, 10), M.bronze); piv.rotation.z = Math.PI / 2; piv.position.set(s * 0.38, 1.3, 0); g.add(piv); }
  ball.rotation.z = Math.PI / 2;
  const F = fire(0.8); g.add(F);
  const steam = [...Array(8)].map(() => { const s = glowSprite(0xe8f0ff, 0.3); s.material.blending = THREE.NormalBlending; g.add(s); return s; });
  g.spin = (a, t) => { ball.rotation.x = a; F.set(1, t); steam.forEach((s, i) => { const u = (t * 1.5 + i / 8) % 1; const ang = a + (i % 2) * Math.PI; const sg = (i % 2) ? 1 : -1; const ty = sg * 0.52 * Math.cos(a) - sg * 0.3 * Math.sin(a), tz = sg * 0.52 * Math.sin(a) + sg * 0.3 * Math.cos(a); const dy = -sg * Math.sin(a), dz = sg * Math.cos(a); s.position.set(0, 1.3 + ty + dy * u * 0.7 + u * u * 0.3, tz + dz * u * 0.7); s.scale.setScalar(0.15 + u * 0.4); s.material.opacity = 0.5 * (1 - u); }); };
  return shadowAll(g);
}
// holy-water dispenser: box with coin slot on top, spout at the front
export function vending() {
  const M = heronMats(); const g = new THREE.Group();
  const box = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.5, 1.4, 24), M.bronze); box.position.y = 0.7; g.add(box);
  const lid = new THREE.Mesh(new THREE.SphereGeometry(0.45, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), M.bronze); lid.position.y = 1.4; g.add(lid);
  const slot = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.03, 0.04), M.iron); slot.position.set(0, 1.84, 0); g.add(slot);
  const spout = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.35, 10), M.bronze); spout.rotation.x = Math.PI / 2 - 0.4; spout.position.set(0, 0.5, 0.55); g.add(spout);
  const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.012, 20), new THREE.MeshStandardMaterial({ color: 0xf0c040, metalness: 0.95, roughness: 0.2 })); coin.rotation.x = Math.PI / 2; g.add(coin);
  const stream = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.015, 0.5, 8), M.water); stream.position.set(0, 0.25, 0.7); g.add(stream);
  g.set = (u) => { coin.position.set(0, 2.3 - Math.min(1, u * 2) * 0.5, 0); coin.visible = u < 0.5; stream.visible = u > 0.55; };
  g.set(0);
  return shadowAll(g);
}
