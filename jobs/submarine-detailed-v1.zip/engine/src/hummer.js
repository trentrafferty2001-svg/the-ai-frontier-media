// The Explainer: how hummingbirds hover. Hummingbird with sweeping, flipping wings, flower, lift arrows, comparison bird.
// Units: metres. Bird ~0.09 m long. Hover pose: body tilted ~40 deg, beak toward +x.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TIME, NOISE } from './world.js';

const irid = (c) => { const m = new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.3, metalness: 0.3, iridescence: 1, iridescenceIOR: 1.6, clearcoat: 0.6 }); return m; };
// wing blade: flattened ellipse, two-tone (top green, bottom pale) so the flip is visible; root at the origin, span along +z
function wingMesh() {
  const g = new THREE.Group();
  const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.bezierCurveTo(0.012, 0.004, 0.03, 0.012, 0.055, 0.008); sh.bezierCurveTo(0.062, 0.004, 0.062, -0.004, 0.055, -0.006); sh.bezierCurveTo(0.03, -0.01, 0.01, -0.006, 0, 0);
  const geo = new THREE.ShapeGeometry(sh, 24); geo.rotateX(Math.PI / 2); geo.rotateY(-Math.PI / 2); // span -> +z, chord -> x, normal -> y
  const top = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0x2e7d4a, roughness: 0.5, side: THREE.FrontSide }));
  const bot = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0xd8e4d0, roughness: 0.6, side: THREE.BackSide }));
  g.add(top, bot);
  for (let k = 1; k < 6; k++) { const ln = new THREE.Mesh(new THREE.BoxGeometry(0.0008, 0.0012, 0.05 - k * 0.006), new THREE.MeshBasicMaterial({ color: 0x1a4a2a })); ln.position.set(-0.004 + k * 0.0018, 0.0006, 0.026 - k * 0.003); g.add(ln); }
  return g;
}
export function hummingbird() {
  const G = new THREE.Group(); // pivot at the shoulders
  const body = new THREE.Group(); G.add(body);
  const green = irid(0x2f9e5a), white = new THREE.MeshStandardMaterial({ color: 0xeef0ea, roughness: 0.6 });
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.014, 28, 18), green); torso.scale.set(1, 1.6, 1); torso.position.set(0.004, -0.012, 0); body.add(torso);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.012, 24, 16), white); belly.scale.set(0.9, 1.4, 0.9); belly.position.set(0.007, -0.014, 0); body.add(belly);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.0095, 24, 16), green); head.position.set(0.006, 0.013, 0); body.add(head);
  const gorget = new THREE.Mesh(new THREE.SphereGeometry(0.0085, 20, 14, 0, Math.PI * 2, Math.PI * 0.5, Math.PI * 0.5), irid(0xe0202f)); gorget.position.set(0.009, 0.008, 0); gorget.rotation.z = -0.6; body.add(gorget);
  const beak = new THREE.Mesh(new THREE.CylinderGeometry(0.0007, 0.0016, 0.03, 8), new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.4 })); beak.rotation.z = -Math.PI / 2 + 0.25; beak.position.set(0.028, 0.017, 0); body.add(beak);
  [-1, 1].forEach((s) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.0022, 12, 8), new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 0.1 })); e.position.set(0.011, 0.016, s * 0.0072); body.add(e); });
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.022, 4), green); tail.position.set(-0.004, -0.042, 0); tail.rotation.z = 0.25; tail.scale.z = 0.35; body.add(tail);
  body.rotation.z = -0.65; // hover tilt (head up, body angled back)
  // glowing heart (shown in the energy shot)
  const heart = new THREE.Mesh(new THREE.SphereGeometry(0.0045, 16, 12), new THREE.MeshStandardMaterial({ color: 0xff2a3a, emissive: 0xff1020, emissiveIntensity: 1.2, transparent: true })); heart.position.set(0.006, -0.004, 0); body.add(heart); heart.visible = false;
  // wings at the shoulders, one per side
  const wings = [-1, 1].map((s) => { const sh = new THREE.Group(); sh.position.set(0.0, 0.004, s * 0.006); G.add(sh); const w = wingMesh(); if (s < 0) w.scale.z = -1; sh.add(w); return { sh, w, s }; });
  // motion-blur fan (for full-speed shots)
  const fanM = new THREE.MeshBasicMaterial({ color: 0xcfe8d8, transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false });
  const fans = [-1, 1].map((s) => { const f = new THREE.Mesh(new THREE.CircleGeometry(0.06, 32, -1.1, 2.2), fanM); f.rotation.x = -Math.PI / 2; f.position.set(0, 0.004, s * 0.006); f.scale.z = 1; G.add(f); f.rotation.z = s > 0 ? 0 : Math.PI; return f; });
  const tip = new THREE.Object3D(); tip.position.set(-0.0, 0, 0.058); wings[1].w.add(tip);
  const st = { phase: 0, blur: 0, heart: 0, beat: 0 };
  // wing kinematics from a phase (0..1 per stroke cycle): forward sweep (0..0.5), back sweep (0.5..1)
  function update() {
    const p = st.phase * Math.PI * 2;
    const sweep = 1.05 * Math.cos(p);                  // stroke angle: forward (+) / back (-) in the stroke plane
    const flipS = THREE.MathUtils.lerp(0, Math.PI * 0.9, 0.5 - 0.5 * Math.tanh(Math.sin(p) * 6)); // smooth flip near the stroke ends
    const elev = 0.18 * Math.sin(2 * p);               // figure-eight: small up/down at twice the frequency
    wings.forEach(({ sh, w, s }) => { sh.rotation.set(0, 0, 0); sh.rotateY(-s * sweep); sh.rotateX(s * elev); w.rotation.set(0, 0, s * flipS); });
    wings.forEach(({ w }) => { w.visible = st.blur < 0.6; });
    fanM.opacity = 0.35 * st.blur;
    heart.visible = st.heart > 0.01; heart.scale.setScalar(1 + 0.35 * st.beat); heart.material.emissiveIntensity = 0.8 + 1.5 * st.beat;
  }
  update();
  return { group: G, body, st, update, tip, wings };
}
// tube flower on a stem
export function flower() {
  const g = new THREE.Group();
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.0025, 0.003, 0.5, 8), new THREE.MeshStandardMaterial({ color: 0x3f8f3a, roughness: 0.7 })); stem.position.y = -0.25; g.add(stem);
  const prof = []; for (let k = 0; k <= 20; k++) { const s = k / 20; prof.push(new THREE.Vector2(0.004 + 0.012 * Math.pow(s, 3) + 0.002 * s, s * 0.05)); }
  const tube = new THREE.Mesh(new THREE.LatheGeometry(prof, 24), new THREE.MeshStandardMaterial({ color: 0xe0302f, roughness: 0.5, side: THREE.DoubleSide })); tube.rotation.z = Math.PI / 2 + 0.35; tube.position.set(0.0, 0.0, 0); g.add(tube);
  const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.02, 12, 8), new THREE.MeshStandardMaterial({ color: 0x4f9f45, roughness: 0.7 })); leaf.scale.set(1.6, 0.2, 0.7); leaf.position.set(-0.02, -0.12, 0.01); g.add(leaf);
  return g;
}
// simple songbird for the comparison (flaps up and down)
export function songbird() {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0x8a6a4a, roughness: 0.6 });
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.04, 20, 14), m); b.scale.set(1.8, 1, 1); g.add(b);
  const h = new THREE.Mesh(new THREE.SphereGeometry(0.026, 16, 12), m); h.position.set(0.07, 0.02, 0); g.add(h);
  const bk = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.025, 8), new THREE.MeshStandardMaterial({ color: 0xe0a030 })); bk.rotation.z = -Math.PI / 2; bk.position.set(0.1, 0.02, 0); g.add(bk);
  const wings = [-1, 1].map((s) => { const p = new THREE.Group(); p.position.set(0, 0.02, s * 0.03); g.add(p); const w = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.004, 0.12), m); w.position.z = s * 0.06; p.add(w); return { p, s }; });
  return { group: g, flap(ph) { const a = 0.9 * Math.cos(ph * Math.PI * 2); wings.forEach(({ p, s }) => { p.rotation.x = -s * a; }); } };
}
// lift arrow (cone + shaft), .set(strength)
export function arrow(color = 0x3fd0ff) {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.5, transparent: true });
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 0.05, 10), m); shaft.position.y = 0.025; g.add(shaft);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.016, 14), m); tip.position.y = 0.058; g.add(tip);
  return { group: g, set(k) { g.scale.set(1, Math.max(0.001, k), 1); m.opacity = Math.min(1, k * 1.5); g.visible = k > 0.02; } };
}
