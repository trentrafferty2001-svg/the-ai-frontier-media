// South-pointing chariot reel: two-wheeled cart with a pointing figure on top (pointer turns independently), see-through
// gearbox, route helper (drive along a curvature profile), soldiers, scholar, Chinese hills, scroll with gear drawings,
// car axle with differential, museum display.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { mountains, SKY_PRESETS } from './world.js';
SKY_PRESETS.fogc = { zenith: 0x8a96a0, horizon: 0xc8ccd0, ground: 0x6a7060, sunColor: 0xf0eee8, cloud: 0.9, haze: 0xc0c6ca, sunI: 2.2 };
import { gear, mechMats } from './mech.js';
import { cap } from './props60.js';

let CM = null;
export function chMats() {
  if (CM) return CM;
  CM = {
    wood: new THREE.MeshStandardMaterial({ color: 0x8a3a22, roughness: 0.6, bumpMap: fabricTexture(5), bumpScale: 2 }),
    woodDark: new THREE.MeshStandardMaterial({ color: 0x4a2a18, roughness: 0.7 }),
    gold: new THREE.MeshStandardMaterial({ color: 0xd8a83a, metalness: 0.85, roughness: 0.3 }),
    jade: new THREE.MeshStandardMaterial({ color: 0x4aa88a, roughness: 0.35, metalness: 0.1 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transmission: 0.9, thickness: 0.02, transparent: true, opacity: 0.35 }),
  };
  return CM;
}
// spoked wheel in the XY plane, axis z
export function wheel(r = 0.6) {
  const M = chMats(); const g = new THREE.Group();
  const rim = new THREE.Mesh(new THREE.TorusGeometry(r, 0.045, 10, 40), M.woodDark); g.add(rim);
  for (let i = 0; i < 12; i++) { const s = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, r, 6), M.woodDark); s.rotation.z = i / 12 * Math.PI * 2; s.translateY(r / 2); g.add(s); }
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.22, 14), M.gold); hub.rotation.x = Math.PI / 2; g.add(hub);
  return shadowAll(g);
}
// pointing figure: robed little man on a post, right arm stretched forward (+z local). origin at its feet.
export function pointer() {
  const M = chMats(); const g = new THREE.Group();
  const robe = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.42, 20), M.jade); robe.position.y = 0.21; g.add(robe);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.075, 20, 14), new THREE.MeshStandardMaterial({ color: 0xe8c090, roughness: 0.6 })); head.position.y = 0.48; g.add(head);
  const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 0.06, 16), M.woodDark); hat.position.y = 0.55; g.add(hat);
  const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.026, 0.3, 10), M.jade); arm.rotation.x = Math.PI / 2; arm.position.set(0.02, 0.36, 0.15); g.add(arm);
  const hand = new THREE.Mesh(new THREE.SphereGeometry(0.03, 10, 8), head.material); hand.position.set(0.02, 0.36, 0.31); g.add(hand);
  const finger = new THREE.Mesh(new THREE.ConeGeometry(0.012, 0.07, 8), head.material); finger.rotation.x = Math.PI / 2; finger.position.set(0.02, 0.36, 0.36); g.add(finger);
  return shadowAll(g);
}
// the chariot: body box on an axle (axis along x), shafts to the front (+z), pointer on a post on top.
// c.roll(d, turnL, turnR): wheel spin from distances; c.point(worldYaw): keep figure at a world heading
export function chariot({ seeThrough = false, track = 1.4, r = 0.6 } = {}) {
  const M = chMats(); const g = new THREE.Group();
  const bodyM = seeThrough ? M.glass : M.wood;
  const body = new THREE.Mesh(new THREE.BoxGeometry(track - 0.3, 0.5, 1.0), bodyM); body.position.y = r + 0.1; g.add(body);
  const rail = new THREE.Mesh(new THREE.BoxGeometry(track - 0.25, 0.06, 1.05), M.gold); rail.position.y = r + 0.37; g.add(rail);
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, track + 0.3, 10), M.woodDark); axle.rotation.z = Math.PI / 2; axle.position.y = r; g.add(axle);
  const wl = wheel(r), wr = wheel(r); wl.rotation.y = Math.PI / 2; wr.rotation.y = Math.PI / 2; wl.position.set(-track / 2, r, 0); wr.position.set(track / 2, r, 0); g.add(wl, wr);
  for (const s of [-1, 1]) { const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 2.2, 8), M.woodDark); sh.rotation.x = Math.PI / 2 - 0.12; sh.position.set(s * 0.35, r - 0.05, 1.5); g.add(sh); }
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.4, 12), M.gold); post.position.y = r + 0.55; g.add(post);
  const fig = pointer(); fig.position.y = r + 0.75; g.add(fig);
  // gearbox inside (visible when seeThrough): two wheel-driven gears + the central crown gear under the post
  const box = new THREE.Group(); box.position.y = r + 0.05; g.add(box);
  const gL = gear(0.16, 32, 0.03), gR = gear(0.16, 32, 0.03); gL.rotation.y = Math.PI / 2; gR.rotation.y = Math.PI / 2; gL.position.x = -0.3; gR.position.x = 0.3; box.add(gL, gR);
  const crown = gear(0.22, 44, 0.03); crown.rotation.x = Math.PI / 2; crown.position.y = 0.16; box.add(crown);
  box.visible = seeThrough;
  shadowAll(g);
  if (seeThrough) body.castShadow = false;
  // spin about each wheel's own axle (local z after the y quarter-turn), not about a diameter (that made the wheels wobble)
  g.roll = (dL, dR) => { wl.rotation.set(0, Math.PI / 2, dL / r, 'YXZ'); wr.rotation.set(0, Math.PI / 2, dR / r, 'YXZ'); gL.rotation.set(0, Math.PI / 2, dL / 0.16, 'YXZ'); gR.rotation.set(0, Math.PI / 2, -dR / 0.16, 'YXZ'); };
  g.point = (worldYaw) => { fig.rotation.y = worldYaw - g.rotation.y; crown.rotation.z = fig.rotation.y; };
  g.fig = fig; g.rail = rail; g.box = box; g.body = body; g.track = track; g.r = r;
  return g;
}
// route from a curvature profile k(s); returns sample(s) -> {x, z, yaw, dL, dR}
export function route(len, k, { x0 = 0, z0 = 0, yaw0 = 0, track = 1.4, ds = 0.02 } = {}) {
  const P = []; let x = x0, z = z0, yaw = yaw0, dL = 0, dR = 0;
  for (let s = 0; s <= len + ds; s += ds) {
    P.push([x, z, yaw, dL, dR]);
    const kk = k(s); x += Math.sin(yaw) * ds; z += Math.cos(yaw) * ds; yaw += kk * ds;
    dL += ds * (1 + kk * track / 2); dR += ds * (1 - kk * track / 2);
  }
  return (s) => { const i = Math.max(0, Math.min(P.length - 2, Math.floor(s / ds))), f = s / ds - i; const a = P[i], b = P[i + 1]; const L = (u, v) => u + (v - u) * Math.min(1, Math.max(0, f)); return { x: L(a[0], b[0]), z: L(a[1], b[1]), yaw: L(a[2], b[2]), dL: L(a[3], b[3]), dR: L(a[4], b[4]) }; };
}
// soldier: red tunic, dark cap
export function soldier(i = 0) {
  const h = romanBuilder({ color: [0xa83a2a, 0x8a2a20, 0xb84a30][i % 3], skin: [0xd8a878, 0xc89868, 0xe0b080][i % 3] });
  const c = cap(0x2a2a2a); c.position.set(0, 0.16, -0.005); h.j.head.add(c);
  const spear = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 2.2, 6), chMats().woodDark); spear.position.set(0.35, 1.1, 0.05); h.root.add(spear);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.16, 8), new THREE.MeshStandardMaterial({ color: 0xb0b4b8, metalness: 0.8, roughness: 0.3 })); tip.position.set(0.35, 2.26, 0.05); h.root.add(tip);
  shadowAll(h.root);
  return h;
}
// scholar-engineer: dark blue robe, black cap
export function scholar() {
  const h = romanBuilder({ color: 0x2a3a6a, skin: 0xd8a878 });
  const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.12, 16), new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.6 })); hat.position.set(0, 0.17, -0.01); h.j.head.add(hat);
  const robe = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.32, 0.75, 24, 1, true), new THREE.MeshStandardMaterial({ color: 0x2a3a6a, roughness: 0.85, side: THREE.DoubleSide })); robe.position.y = -0.45; h.j.spine.add(robe);
  shadowAll(h.root);
  return h;
}
// green Chinese hills + ground
export function hills(scene, { seed = 1, ground = 0x6a8a4a } = {}) {
  const gm = new THREE.MeshStandardMaterial({ color: ground, roughness: 1, bumpMap: fabricTexture(23 + seed), bumpScale: 4 });
  const g = new THREE.Mesh(new THREE.CircleGeometry(400, 64), gm); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; scene.add(g);
  scene.add(mountains({ rMin: 60, rMax: 260, height: 46, seed: 4 + seed, color: 0x3f6a4a }));
  const road = new THREE.Mesh(new THREE.PlaneGeometry(4, 400), new THREE.MeshStandardMaterial({ color: 0xa08a64, roughness: 1, bumpMap: fabricTexture(9), bumpScale: 3 })); road.rotation.x = -Math.PI / 2; road.position.y = 0.01; road.receiveShadow = true;
  return { ground: g, road };
}
// compass marker: a ring with a red "south" arrow, laid flat
export function southArrow(len = 1.2, color = 0xff3b30) {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.8 });
  const s = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.02, len), m); s.position.z = len / 2; g.add(s);
  const h = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.3, 14), m); h.rotation.x = Math.PI / 2; h.position.z = len + 0.12; g.add(h);
  return g;
}
// scroll with gear drawings (Song dynasty record)
export function gearScroll() {
  const tex = canvasTex(512, 320, (x) => {
    x.fillStyle = '#e8dcb8'; x.fillRect(0, 0, 512, 320); const R = rng(4);
    x.strokeStyle = 'rgba(40,30,20,0.85)'; x.lineWidth = 2;
    const gearC = (cx, cy, r, n) => { x.beginPath(); for (let i = 0; i <= n * 2; i++) { const a = i / (n * 2) * Math.PI * 2, rr = i % 2 ? r : r - 6; x.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); } x.stroke(); x.beginPath(); x.arc(cx, cy, 5, 0, 7); x.stroke(); };
    gearC(140, 170, 70, 24); gearC(240, 120, 40, 14); gearC(330, 190, 60, 20); gearC(420, 110, 30, 10);
    x.fillStyle = 'rgba(30,20,10,0.85)';
    for (let col = 0; col < 6; col++) for (let k = 0; k < 9; k++) if (R() < 0.85) x.fillRect(470 - col * 14 + 30, 20 + k * 30, 9, 9 + R() * 8);
    x.fillStyle = 'rgba(170,30,20,0.85)'; x.fillRect(30, 260, 26, 26);
  });
  const g = new THREE.Group();
  const paper = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.0), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9 })); paper.rotation.x = -Math.PI / 2; g.add(paper);
  for (const s of [-1, 1]) { const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.1, 12), chMats().woodDark); rod.position.set(s * 0.82, 0.03, 0); rod.rotation.x = Math.PI / 2; g.add(rod); }
  return shadowAll(g);
}
// car axle with a differential housing (wheels at x = ±0.8)
export function carAxle() {
  const g = new THREE.Group(); const steel = new THREE.MeshStandardMaterial({ color: 0x8a9098, metalness: 0.85, roughness: 0.35 });
  const ax = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1.5, 12), steel); ax.rotation.z = Math.PI / 2; g.add(ax);
  const house = new THREE.Mesh(new THREE.SphereGeometry(0.2, 24, 16), new THREE.MeshPhysicalMaterial({ color: 0x9aa4b0, metalness: 0.6, roughness: 0.3, transparent: true, opacity: 0.35 })); g.add(house);
  const ring = gear(0.16, 36, 0.03, mechMats().bronze); ring.rotation.y = Math.PI / 2; ring.position.x = -0.06; g.add(ring);
  const sp1 = gear(0.07, 14, 0.03), sp2 = gear(0.07, 14, 0.03); sp1.position.set(0.04, 0.09, 0); sp1.rotation.x = Math.PI / 2; sp2.position.set(0.04, -0.09, 0); sp2.rotation.x = Math.PI / 2; g.add(sp1, sp2);
  const tires = [-0.8, 0.8].map(x => { const t = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.1, 14, 30), new THREE.MeshStandardMaterial({ color: 0x1a1a1c, roughness: 0.8 })); t.rotation.y = Math.PI / 2; t.position.x = x; g.add(t); const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.12, 20), steel); rim.rotation.z = Math.PI / 2; rim.position.x = x; g.add(rim); return t; });
  g.spin = (a, b) => { tires[0].rotation.x = a; tires[1].rotation.x = b; ring.rotation.x = (a + b) / 2; sp1.rotation.z = (a - b) * 2; sp2.rotation.z = -(a - b) * 2; };
  return shadowAll(g);
}
