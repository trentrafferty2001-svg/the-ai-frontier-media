// The Explainer: why the sky is blue. Person, hills, prism + spectrum fan, molecules (N2/O2), travelling waves,
// scattered wavelets, sky streaks to the eye, an eye, earth + atmosphere path diagram.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.7, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
const glow = (c, o = {}) => new THREE.MeshBasicMaterial({ color: c, toneMapped: false, ...o });
export const SPEC = [0xff2a2a, 0xff8a1a, 0xffe02a, 0x3aff5a, 0x2a8aff, 0x3a3aff, 0x9a3aff];
export function person(color = 0x2a2a3a) {
  const G = new THREE.Group(); const m = std(color, 0.8);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, 1.0, 14), m); body.position.y = 0.95; G.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 12), m); head.position.y = 1.65; G.add(head);
  [-1, 1].forEach(s => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.5, 8), m); l.position.set(s * 0.12, 0.25, 0); G.add(l); });
  return G;
}
import { groundMat, grass, leafyTrees, flowerShrubs } from './hummer2.js';
export function hills(seed = 3) {
  const G = new THREE.Group(); const R = rnd(seed);
  const ground = new THREE.Mesh(new THREE.CircleGeometry(300, 48), groundMat()); ground.rotation.x = -Math.PI / 2; G.add(ground);
  const m = std(0x3a7a3a, 0.95); for (let i = 0; i < 14; i++) { const h = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), m); const s = 8 + R() * 14; h.scale.set(s * 1.6, s * (0.25 + R() * 0.2), s); const a = -1.2 + i / 13 * 2.4; h.position.set(Math.sin(a) * 70, 0, -Math.cos(a) * 70 - R() * 20); G.add(h); }
  G.add(grass(7000, 0.3, 7, 11));
  const ts = []; for (let k = 0; k < 18; k++) { const a = -1.3 + k / 17 * 2.6, r = 14 + (k % 4) * 6; ts.push([Math.sin(a) * r, 0, -Math.cos(a) * r]); } G.add(leafyTrees(ts, { seed: 6, leaves: 1500 }));
  const sh = []; for (let k = 0; k < 14; k++) { const a = -1.4 + k * 0.21, r = 3.5 + (k % 3) * 1.4; sh.push([Math.sin(a) * r, 0.2, -Math.cos(a) * r]); } G.add(flowerShrubs(sh));
  return G;
}
export function hillsOld(seed = 3) {
  const G = new THREE.Group(); const R = rnd(seed); const m = std(0x3a7a3a, 0.95);
  const ground = new THREE.Mesh(new THREE.CircleGeometry(300, 48), std(0x4a8a3a, 1)); ground.rotation.x = -Math.PI / 2; G.add(ground);
  for (let i = 0; i < 14; i++) { const h = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12), m); const s = 8 + R() * 14; h.scale.set(s * 1.6, s * (0.25 + R() * 0.2), s); const a = -1.2 + i / 13 * 2.4; h.position.set(Math.sin(a) * 70, 0, -Math.cos(a) * 70 - R() * 20); G.add(h); }
  return G;
}
export function prism() {
  const G = new THREE.Group();
  const sh = new THREE.Shape(); sh.moveTo(0, 1.3); sh.lineTo(-1.15, -0.7); sh.lineTo(1.15, -0.7); sh.closePath();
  const g = new THREE.ExtrudeGeometry(sh, { depth: 1.2, bevelEnabled: false }); g.translate(0, 0, -0.6);
  G.add(new THREE.Mesh(g, new THREE.MeshPhysicalMaterial({ color: 0xe8f4ff, transparent: true, opacity: 0.55, roughness: 0.02, metalness: 0, clearcoat: 1, clearcoatRoughness: 0.02, iridescence: 0.6, iridescenceIOR: 1.5, side: THREE.DoubleSide })));
  { const eg = new THREE.EdgesGeometry(g); G.add(new THREE.LineSegments(eg, new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 }))); const gl = new THREE.Mesh(new THREE.SphereGeometry(0.05, 12, 8), glow(0xffffff)); gl.position.set(0.4, 0.2, 0.62); G.add(gl); }
  const beam = new THREE.Mesh(new THREE.BoxGeometry(3, 0.14, 0.14), glow(0xffffff)); beam.position.set(-2.0, 0.33, 0); beam.rotation.z = -0.18; G.add(beam);
  const fan = SPEC.map((c, i) => { const b = new THREE.Mesh(new THREE.BoxGeometry(1, 0.11, 0.11), glow(c)); b.geometry.translate(0.5, 0, 0); b.position.set(0.45, 0.05, 0); b.rotation.z = -0.05 - i * 0.075; G.add(b); return b; });
  return { group: G, set(k) { fan.forEach(b => { b.scale.x = Math.max(0.001, 3 * k); b.visible = k > 0.01; }); } };
}
// instanced molecules: pairs of spheres, N2 (blue-grey) and O2 (red)
export function molecules(n = 160, area = [14, 16, 8], seed = 5) {
  const R = rnd(seed); const P = []; for (let i = 0; i < n; i++) P.push({ p: new THREE.Vector3((R() - 0.5) * area[0], (R() - 0.5) * area[1], (R() - 0.5) * area[2]), ph: R() * 6, o2: R() < 0.22, ax: new THREE.Vector3(R() - 0.5, R() - 0.5, R() - 0.5).normalize() });
  const geo = new THREE.SphereGeometry(0.16, 12, 8);
  const mk = (c) => { const m = new THREE.InstancedMesh(geo, new THREE.MeshPhysicalMaterial({ color: c, roughness: 0.15, clearcoat: 1, clearcoatRoughness: 0.1 }), n * 2); m.frustumCulled = false; return m; };
  const N = mk(0x7a9ad8), O = mk(0xe8504a); const G = new THREE.Group(); G.add(N, O);
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(1, 1, 1), a = new THREE.Vector3(), z = new THREE.Matrix4().makeScale(0, 0, 0);
  function update(T) { let ni = 0, oi = 0; P.forEach(o => { const c = o.p.clone().add(new THREE.Vector3(Math.sin(T * 1.3 + o.ph) * 0.15, Math.cos(T * 1.1 + o.ph) * 0.15, 0)); a.copy(o.ax).applyAxisAngle(new THREE.Vector3(0, 1, 0), T * 0.8 + o.ph).multiplyScalar(0.15);
    for (const sg of [1, -1]) { M.compose(c.clone().addScaledVector(a, sg), q, s); if (o.o2) O.setMatrixAt(oi++, M); else N.setMatrixAt(ni++, M); } });
    for (let i = ni; i < n * 2; i++) N.setMatrixAt(i, z); for (let i = oi; i < n * 2; i++) O.setMatrixAt(i, z); N.instanceMatrix.needsUpdate = true; O.instanceMatrix.needsUpdate = true; }
  update(0);
  return { group: G, update, P };
}
export function pair(o2 = false) { const G = new THREE.Group(); const m = new THREE.MeshPhysicalMaterial({ color: o2 ? 0xe8504a : 0x7a9ad8, roughness: 0.12, clearcoat: 1, clearcoatRoughness: 0.08, sheen: 0.5 }); [-1, 1].forEach(s => { const b = new THREE.Mesh(new THREE.SphereGeometry(0.5, 32, 24), m); b.position.x = s * 0.42; G.add(b); }); const bond = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.5, 16), new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.2, transmission: 0.3, transparent: true, opacity: 0.7 })); bond.rotation.z = Math.PI / 2; G.add(bond); return G; }
// a travelling wave along +x from x0 to x1 (local), wavelength lam; set(T) moves crests
export function wave(color, lam, amp = 0.35, x0 = -6, x1 = 6, r = 0.07) {
  const G = new THREE.Group(); const pts = []; const n = Math.max(60, Math.round((x1 - x0 + lam) / lam * 24));
  for (let i = 0; i <= n; i++) { const x = x0 - lam + (x1 - x0 + lam) * i / n; pts.push(new THREE.Vector3(x, amp * Math.sin(2 * Math.PI * x / lam), 0)); }
  const mesh = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), n * 2, r, 8), glow(color)); G.add(mesh);
  return { group: G, mesh, set(T, speed = 3) { mesh.position.x = ((T * speed) % lam); } };
}
export function eye() {
  const G = new THREE.Group();
  G.add(new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24), std(0xf4f0ea, 0.3)));
  const ic = document.createElement('canvas'); ic.width = ic.height = 256; { const g = ic.getContext('2d'); const gr = g.createRadialGradient(128, 128, 20, 128, 128, 128); gr.addColorStop(0, '#0a1a3a'); gr.addColorStop(0.35, '#2a6ad8'); gr.addColorStop(0.8, '#5aa0f0'); gr.addColorStop(1, '#1a3a7a'); g.fillStyle = gr; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 160; i++) { const a = i / 160 * Math.PI * 2; g.strokeStyle = `rgba(${i % 3 ? 180 : 20},${i % 3 ? 220 : 60},255,0.35)`; g.lineWidth = 1.5; g.beginPath(); g.moveTo(128 + Math.cos(a) * 30, 128 + Math.sin(a) * 30); g.lineTo(128 + Math.cos(a + 0.05) * 124, 128 + Math.sin(a + 0.05) * 124); g.stroke(); } }
  const it = new THREE.CanvasTexture(ic); it.colorSpace = THREE.SRGBColorSpace;
  const irisM = new THREE.MeshStandardMaterial({ map: it, color: 0xffffff, emissive: 0x2a6ad8, emissiveMap: it, emissiveIntensity: 0, roughness: 0.3 });
  const corn = new THREE.Mesh(new THREE.SphereGeometry(0.5, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.15, roughness: 0, clearcoat: 1 })); corn.rotation.x = Math.PI / 2; corn.position.z = 0.9; corn.scale.z = 0.4; G.add(corn);
  const iris = new THREE.Mesh(new THREE.CircleGeometry(0.45, 32), irisM); iris.position.z = 1.002; G.add(iris);
  const pupil = new THREE.Mesh(new THREE.CircleGeometry(0.2, 24), std(0x0a0a0a, 0.2)); pupil.position.z = 1.004; G.add(pupil);
  return { group: G, irisM };
}
export { std, glow };
