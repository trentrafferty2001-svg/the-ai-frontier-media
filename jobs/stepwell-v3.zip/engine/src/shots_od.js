// Roman odometer reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { mountains, birds } from './world.js';
import { glowSprite, sparks } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { romanBuilder } from './rome.js';
import { greek, medLand } from './classic.js';
import { gearScroll } from './chariot.js';
import { road, milestone, cart, dial } from './odometer.js';
import { VO } from './vo_od.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['How do you', 3], ['*measure a road*', 3], ['that runs for', 3], ['*hundreds of kilometers*', 3], ['with no satellites', 3], ['to help?', 2]],
  [['But a *Roman engineer*', 4], ['described a *cart*', 3], ['that *counted the miles*', 4], ['for you', 2]],
  [['*Vitruvius*', 1], ['wrote about it', 3], ['around', 1], ['*2,000 years* ago', 4]],
  [["The cart's *wheel*", 3], ['was *4 Roman feet*', 4], ['across', 1]],
  [['So it turned', 3], ['exactly', 1], ['*400 times*', 3], ['in one *Roman mile*', 4]],
  [['A *peg* on the axle', 5], ['*nudged a gear*', 3], ['with *400 teeth*', 4], ['one tooth', 2], ['per turn', 2]],
  [['After one', 2], ['*full mile*', 2], ['that gear', 2], ['had turned *once*', 3]],
  [['Then a *small stone*', 4], ['*dropped* from a hole', 4], ['and landed', 2], ['in a *bronze bowl*', 4], ['with a *clink*', 3]],
  [['Every *clink*', 2], ['meant *one more mile*', 4]],
  [['At the end', 3], ['of the day', 3], ['you just', 2], ['*counted the stones*', 3]],
  [['*Hero of Alexandria*', 3], ['described a', 2], ['similar machine', 2], ['with *dials*', 2]],
  [['*Historians* still argue', 3], ['about *how often*', 3], ['it was', 2], ['*really used*', 2]],
  [['But *Roman roads*', 3], ['were famously marked', 3], ['with *milestones*', 2], ['*mile after mile*', 3]],
  [['The *odometer*', 2], ['in *your car*', 3], ['started as a *cart*', 4], ['a *gear*', 2], ['and a *bowl of pebbles*', 5]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function land(makeStage, { preset = 'day', sunDir = [-0.5, 0.55, 0.6], shadowSize = 10, stones = true } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog: 0.004, shadowSize, envI: 0.9 });
  medLand(scene, { seed: 2, groundC: 0x8a9a5a }); road(scene);
  if (stones) for (let i = -6; i <= 6; i++) { const m = milestone(); m.position.set(3.2, 0, i * 40); scene.add(m); }
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xfff0e0);
  return scene;
}
function walker(scene, i = 0) { const w = romanBuilder({ color: [0xc8b088, 0xa86a3a][i % 2] }); scene.add(w.root); return w; }
const walk = (w, t, i = 0) => { const s = Math.sin(t * 6 + i); standPose(w, t, { lHip: [s * 0.4, 0, 0.06], rHip: [-s * 0.4, 0, -0.06], lKn: [Math.max(0, -s) * 0.5, 0, 0], rKn: [Math.max(0, s) * 0.5, 0, 0], lSh: [-1.2, 0, 0.2], rSh: [-1.2, 0, -0.2] }); w.setMood('happy'); w.setMouth(0); };
function studio(makeStage) {
  const scene = makeStage({ shadowSize: 2, sunDir: [-2, 5, 3], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x1a2230); u.mid.value.set(0x26303e); u.horizon.value.set(0x34404e); u.floorC.value.set(0x141a22);
  fillLight(scene, [0.5, 0.3, 1], 0.8);
  return scene;
}

// ============ S0: a Roman road running to the horizon ============
function sHook({ makeStage }) {
  const scene = land(makeStage, { sunDir: [-0.4, 0.4, -0.8], shadowSize: 30 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(12, 6, k), lerp(26, 14, k), lerp(40, 20, k)], [0, 0, lerp(-60, -120, k)]);
      return { bloom: 0.55, flare: 0.8, warm: 1.2 };
    },
  };
}
// ============ S1: a cart that counts the miles, pushed along the road ============
function sCart({ makeStage }) {
  const scene = land(makeStage);
  const C = cart(); C.rotation.y = Math.PI; scene.add(C);
  const w = walker(scene);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const z = 10 - t * 1.4; C.position.set(0, 0, z); C.roll(10 - z);
      w.root.position.set(0, 0, z - 2.4); w.root.rotation.y = Math.PI; walk(w, t);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(4, 3, k), lerp(2.2, 1.8, k), z + lerp(-5, -4, k)], [0, 0.9, z]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S2: Vitruvius with his book ============
function sVitruvius({ makeStage }) {
  const scene = studio(makeStage);
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a2016); u.mid.value.set(0x3a2a1c); u.horizon.value.set(0x4a3624); u.floorC.value.set(0x20160e);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0x8a7a64 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const table = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.08, 0.9), new THREE.MeshStandardMaterial({ color: 0x6a4428 })); table.position.set(0.4, 0.9, 0); scene.add(table);
  const sc = gearScroll(); sc.scale.setScalar(0.7); sc.position.set(0.4, 0.95, 0); scene.add(sc);
  const V1 = greek({ beard: true }); V1.root.position.set(-0.7, 0, 0.1); V1.root.rotation.y = 0.9; scene.add(V1.root);
  const lamp = new THREE.PointLight(0xffb060, 2.5, 4, 2); lamp.position.set(0.4, 1.6, 0.8); scene.add(lamp);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standPose(V1, t, { spine: [0.2, 0, 0], head: [0.25, 0.2, 0], rSh: [-0.7, 0, -0.3], rEl: [-0.6, 0, 0] }); V1.setMood('happy'); V1.setMouth(0); V1.blink(blinkK(t, [1.3, 3.2]));
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(0.6, 0.3, k), lerp(1.8, 1.7, k), lerp(3.6, 3.0, k)], [-0.1, 1.2, 0]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S3/S4: the 4-foot wheel; 400 turns per mile ============
function sWheel({ makeStage, start: ST }) {
  const tF = at(3, 'feet') - ST;
  const scene = land(makeStage, { shadowSize: 4 });
  const C = cart(); scene.add(C); C.rotation.y = Math.PI / 2;
  const line = new THREE.Mesh(new THREE.BoxGeometry(0.03, 1.2, 0.03), new THREE.MeshBasicMaterial({ color: 0xffd43b, toneMapped: false })); line.position.set(0.0, 0.6, 0.78); scene.add(line);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      C.roll(0); line.visible = t > tF - 0.4; line.scale.y = easeOut(range(t, tF - 0.4, tF + 0.2)) + 0.001;
      place(c, [lerp(0.6, 0.3, easeInOut(range(t, 0, 3))), 0.9, 3.2], [0, 0.6, 0.6]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
function sTurns({ makeStage }) {
  const scene = land(makeStage, { shadowSize: 6 });
  const C = cart(); C.rotation.y = Math.PI / 2; scene.add(C);
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 192; const cx = cv.getContext('2d');
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const counter = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false })); counter.scale.set(0.9, 0.34, 1); counter.position.set(0, 1.4, 0.6); counter.renderOrder = 5; scene.add(counter);
  let shown = -1; const draw = (n) => { if (n === shown) return; shown = n; cx.clearRect(0, 0, 512, 192); cx.fillStyle = 'rgba(20,14,8,0.75)'; cx.beginPath(); cx.roundRect(16, 16, 480, 160, 36); cx.fill(); cx.font = '700 104px Cap, sans-serif'; cx.textAlign = 'center'; cx.fillStyle = '#ffd43b'; cx.fillText(String(n), 256, 132); tex.needsUpdate = true; }; // turn counter: 1 -> 400
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const d = t * t * 6; C.position.set(0, 0, 0); C.roll(d);
      draw(Math.max(1, Math.min(400, Math.round(Math.pow(range(t, 0.2, 3.3), 1.6) * 400))));
      place(c, [lerp(1.2, 2.0, easeInOut(range(t, 0, 4))), 1.2, 3.6], [0, 0.7, 0.4]);
      return { bloom: 0.65, warm: 1.15 };
    },
  };
}
// ============ S5/S6: inside: the axle peg nudges the big gear one tooth per turn; a mile = one full turn ============
function sPeg({ makeStage }) {
  const scene = studio(makeStage);
  const C = cart({ seeThrough: true }); C.body.visible = false; scene.add(C);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      C.roll(t * 2.4);
      place(c, [lerp(1.4, 1.2, easeInOut(range(t, 0, 5))), 1.3, lerp(1.4, 1.1, easeInOut(range(t, 0, 5)))], [0.05, 0.95, 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
function sMile({ makeStage }) {
  const scene = studio(makeStage);
  const C = cart({ seeThrough: true }); C.body.visible = false; scene.add(C);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      C.roll(t * t * 180);
      place(c, [2.2, 1.4, 1.6], [0.05, 0.95, 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
// ============ S7: a stone drops into the bronze bowl: clink ============
function sDrop({ makeStage, start: ST }) {
  const tC = at(7, 'clink') - ST, tD = at(7, 'dropped') - ST;
  const scene = studio(makeStage);
  const C = cart({ seeThrough: true }); C.body.visible = false; scene.add(C);
  const sp = sparks(24, { speed: 0.8, spread: 1.5, life: 0.3, size: 0.02, color: [1, 0.9, 0.6] }); scene.add(sp);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      C.roll(0, { dropU: range(t, tD, tC), count: t > tC ? 1 : 0 });
      sp.position.set(-0.15, 0.85, 0.22); sp.update(t - tC);
      place(c, [lerp(1.1, 0.9, easeInOut(range(t, 0, 4))), lerp(1.8, 1.4, easeInOut(range(t, 0, 4))), 1.3], [-0.15, 1.15, 0.15]);
      return { bloom: 0.6, warm: 1.15 };
    },
  };
}
// ============ S8: every clink, one more mile: rolling past a milestone ============
function sClink({ makeStage }) {
  const scene = land(makeStage);
  const C = cart(); C.rotation.y = Math.PI; scene.add(C);
  const w = walker(scene, 1);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const z = 42 - t * 2; C.position.set(0, 0, z); C.roll(42 - z);
      w.root.position.set(0, 0, z - 2.4); w.root.rotation.y = Math.PI; walk(w, t, 1);
      place(c, [5, 1.6, 36], [1.5, 1.0, z]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S9: end of the day: counting the stones ============
function sCount({ makeStage }) {
  const scene = land(makeStage, { preset: 'golden', sunDir: [0.75, 0.15, -0.6], shadowSize: 4 });
  const w = walker(scene); w.root.position.set(-1.2, 0, 0.6); w.root.rotation.y = 0.6;
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xc08a40, metalness: 0.9, roughness: 0.3, side: THREE.DoubleSide })); bowl.position.set(-0.4, 0.22, 1.1); scene.add(bowl);
  const stones = [...Array(12)].map((_, i) => { const s = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 8), new THREE.MeshStandardMaterial({ color: 0xe8e0d0 })); scene.add(s); return s; });
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      standPose(w, t, { spine: [0.6, 0, 0], head: [0.4, 0, 0], rSh: [-1.2, 0, -0.1] }); w.setMood('happy'); w.setMouth(0);
      stones.forEach((s, i) => { const out = t > 0.3 + i * 0.25; s.position.set(out ? 0.1 + (i % 6) * 0.1 : -0.4 + Math.cos(i) * 0.08, out ? 0.04 : 0.1, out ? 1.1 + Math.floor(i / 6) * 0.12 : 1.1 + Math.sin(i) * 0.08); });
      place(c, [lerp(0.8, 0.5, easeInOut(range(t, 0, 4))), 1.4, 2.8], [-0.2, 0.4, 1.0]);
      return { bloom: 0.65, flare: 0.8, warm: 1.35 };
    },
  };
}
// ============ S10: Hero's version with dials ============
function sDials({ makeStage }) {
  const scene = studio(makeStage);
  const panel = new THREE.Mesh(new THREE.BoxGeometry(1.7, 3.8, 0.2), new THREE.MeshStandardMaterial({ color: 0x6a4424, roughness: 0.85 })); panel.position.set(0, 1.2, -0.12); scene.add(panel); // side of the cart
  for (const x of [-0.75, 0.75]) for (const y of [-0.6, 3.0]) { const nail = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 8), new THREE.MeshStandardMaterial({ color: 0xb08a3a, metalness: 0.8, roughness: 0.3 })); nail.position.set(x, y, 0); scene.add(nail); }
  const D = [0, 1, 2].map(i => { const d = dial({ greek: true }); d.position.set(0, 1.2 + (1 - i) * 1.15, 0.0); /* stacked: fits the vertical frame */ d.scale.setScalar([0.95, 0.85, 0.75][i]); scene.add(d); return d; });
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      D.forEach((d, i) => d.set(t * [3, 0.3, 0.03][i] * Math.PI));
      place(c, [lerp(-0.4, 0.3, easeInOut(range(t, 0, 4))), 1.3, 6.4], [0, 1.2, 0]); /* all three dials in frame */
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S11: historians argue ============
function sArgue({ makeStage }) {
  const scene = studio(makeStage);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0x6a6a70 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const A = greek({ beard: true, color: 0xd8c8a8 }), B = greek({ beard: false, color: 0xc8d0e0 }); A.root.position.set(-0.7, 0, 0); A.root.rotation.y = 0.9; B.root.position.set(0.7, 0, 0); B.root.rotation.y = -0.9; scene.add(A.root, B.root);
  const C = cart(); C.scale.setScalar(0.35); C.position.set(0, 0, -0.9); scene.add(C);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(14, 8), new THREE.MeshStandardMaterial({ color: 0x4a5260, roughness: 0.95 })); wall.position.set(0, 3, -3); scene.add(wall); /* backdrop: no sky glare */
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const a = Math.sin(t * 3), b = Math.sin(t * 3 + 2);
      standPose(A, t, { rSh: [-1.0 - a * 0.4, 0, -0.4], rEl: [-0.5, 0, 0] }); A.setMood('happy'); A.setMouth(Math.max(0, a) * 0.6);
      standPose(B, t, { lSh: [-1.0 - b * 0.4, 0, 0.4], lEl: [-0.5, 0, 0] }); B.setMood('happy'); B.setMouth(Math.max(0, b) * 0.6);
      place(c, [lerp(0.4, 0, easeInOut(range(t, 0, 4))), 1.6, 4.2], [0, 1.2, 0]);
      return { bloom: 0.3, warm: 1.1 };
    },
  };
}
// ============ S12: milestones, mile after mile ============
function sStones({ makeStage }) {
  const scene = land(makeStage, { sunDir: [-0.6, 0.4, 0.6], shadowSize: 40 });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const z = lerp(60, -20, easeInOut(range(t, 0, 4.6)));
      place(c, [6, 3, z], [2.5, 0.8, z - 30]);
      return { bloom: 0.55, flare: 0.7, warm: 1.2 };
    },
  };
}
// ============ S13: sunset, the cart on the road, pull back ============
function sEnd({ makeStage }) {
  const scene = land(makeStage, { preset: 'golden', sunDir: [0.0, 0.12, -1], shadowSize: 10 });
  const C = cart(); C.rotation.y = Math.PI; scene.add(C);
  const w = walker(scene);
  const b = birds(4, { from: [-20, 14, -40], to: [20, 16, -50], spread: 4, speed: 0.06, scale: 1.4, seed: 2 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const z = 2 - t * 1.2; C.position.set(0, 0, z); C.roll(2 - z);
      w.root.position.set(0, 0, z - 2.4); w.root.rotation.y = Math.PI; walk(w, t);
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(1.5, 4, k), lerp(1.6, 6, k), lerp(6, 14, k)], [0, 1, z - 3]);
      return { bloom: 0.7, flare: 1.1, warm: 1.4 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sCart], [ls(2), ls(3), sVitruvius], [ls(3), ls(4), sWheel], [ls(4), ls(5), sTurns],
  [ls(5), ls(6), sPeg], [ls(6), ls(7), sMile], [ls(7), ls(8), sDrop], [ls(8), ls(9), sClink], [ls(9), ls(10), sCount],
  [ls(10), ls(11), sDials], [ls(11), ls(12), sArgue], [ls(12), ls(13), sStones], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
