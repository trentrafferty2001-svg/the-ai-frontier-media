// The Explainer: how fireflies glow. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { firefly, swarm, meadow, chemistry, bulb, lanternCut, GLOW, std } from './firefly.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_ff.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*Fireflies*', 1], ['make *light*', 2], ['without', 1], ['*getting hot*', 2], ['and some *females*', 3], ['use it as a *trap*', 5]],
  [['The *glow* comes', 3], ['from a chemical', 3], ['called *luciferin*', 2], ['inside the *lantern*', 3], ['at the end', 3], ['of the *abdomen*', 3]],
  [['An *enzyme*', 2], ['called *luciferase*', 2], ['joins it', 2], ['with *oxygen*', 2], ['and *energy*', 2], ['from the cell', 3], ['and the reaction', 3], ['gives off *light*', 3]],
  [['*Hardly any* energy', 3], ['is *wasted*', 2], ['as heat', 2], ["so it's called", 3], ['*cold light*', 2]],
  [['To *flash*', 2], ['on and off', 3], ['the firefly', 2], ['*controls*', 1], ['the *oxygen* supply', 3], ['to its lantern', 3]],
  [['Each species', 2], ['has its own', 3], ['*flash code*', 2], ['*Males* flash', 2], ['while *flying*', 2], ['and *females*', 2], ['*answer*', 1], ['from the grass', 3]],
  [['But some *females*', 3], ['*copy* the reply', 3], ['of *another species*', 3], ['then *eat*', 2], ['the male', 2], ['who comes', 2], ['to visit', 2]],
  [['And in a few', 4], ['*forests*', 1], ['*thousands*', 1], ['of fireflies', 2], ['flash in', 2], ['*perfect sync*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 38) => { const c = cam(fov); c.near = 0.01; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 1.1, warm: 0.95, sat: 1.15, exposure: 1.05 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };
const blink = (T, per = 1.8, ph = 0) => { const u = ((T / per) + ph) % 1; return Math.max(0, 1 - Math.abs(u - 0.15) / 0.12); };

function night(makeStage) {
  const scene = makeStage({ shadowSize: 6, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x05081a); u.mid.value.set(0x0c1430); u.horizon.value.set(0x1a2448); u.floorC.value.set(0x05080e); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0x5a6ab0, 0x0a100a, 0.5));
  const moon = new THREE.DirectionalLight(0x9ab0ff, 0.5); moon.position.set(-4, 8, 3); scene.add(moon);
  scene.add(meadow()); const S = swarm(); scene.add(S.mesh);
  return { scene, S };
}
function lab(makeStage) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x0a1028); u.mid.value.set(0x121a3a); u.horizon.value.set(0x1a244a); u.floorC.value.set(0x05080e); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xdfe8ff, 0x101828, 0.9));
  return scene;
}

// ============ S0 hook: a dark meadow lights up with blinking fireflies; one glows right by the camera ============
function sHook({ makeStage }) {
  const W = night(makeStage); const F = firefly(); F.group.position.set(0, 1.2, 0); F.group.rotation.y = 0.6; W.scene.add(F.group);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t) {
      W.S.update(t, 0, smooth(range(t, 0, 1.2))); F.st.glow = blink(t, 1.4, 0.8); F.st.flap = t; F.update(); F.group.position.y = 1.2 + 0.05 * Math.sin(t * 2);
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [-0.03, 1.2, 0], lerp(2.0, 1.5, k), lerp(40, 60, k), lerp(6, 10, k));
      return { ...POST, dof: { focus: 1.6, aperture: 0.002, maxblur: 0.005 } };
    },
  };
}
// ============ S1: close on the lantern ============
function sLantern({ makeStage }) {
  const W = night(makeStage); const F = firefly(); F.group.position.set(0, 1.2, 0); W.scene.add(F.group); F.st.flying = 0;
  const L = tag(W.scene, 'lantern', 0.08, '#e8ff9a', [-0.17, 1.33, 0]);
  const c = C(38);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.S.update(T, 0, 0.6); F.st.glow = 0.4 + 0.6 * smooth(range(T, at(1, 'lantern') - 0.3, at(1, 'lantern') + 0.2)); F.update();
      pop(L, easeOut(range(T, at(1, 'lantern') - 0.1, at(1, 'lantern') + 0.2)), 0.08);
      const k = easeInOut(range(t, 0, 5.3));
      orb(c, [-0.05, 1.2, 0], lerp(1.3, 1.0, k), lerp(20, -10, k), lerp(14, 8, k));
      return POST;
    },
  };
}
// ============ S2: chemistry: luciferin + O2 + energy, luciferase -> light ============
function sChem({ makeStage }) {
  const scene = lab(makeStage); const Ch = chemistry(); scene.add(Ch.group);
  const L1 = tag(scene, 'luciferin', 0.6, '#f2d23a', [-0.9, 2.75, 0]), L2 = tag(scene, 'luciferase', 0.6, '#c89aff', [0, 1.1, 0.8]), L3 = tag(scene, 'O₂', 0.7, '#ff7a6a', [1.1, 2.75, 0]);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      Ch.set(smooth(range(T, at(2, 'joins') - 0.2, at(2, 'cell') + 0.2)), range(T, at(2, 'light') - 0.4, le(2) + 0.6), T);
      pop(L1, easeOut(range(T, ls(2), ls(2) + 0.3)) * (1 - range(T, at(2, 'joins'), at(2, 'joins') + 0.3)), 0.6); pop(L2, easeOut(range(T, at(2, 'luciferase') - 0.1, at(2, 'luciferase') + 0.2)), 0.6); pop(L3, easeOut(range(T, at(2, 'oxygen') - 0.2, at(2, 'oxygen') + 0.1)) * (1 - range(T, at(2, 'cell'), at(2, 'cell') + 0.3)), 0.7);
      const k = easeInOut(range(t, 0, 6.2));
      orb(c, [0, 0.3, 0], lerp(8.5, 7.5, k), lerp(-8, 8, k), 4);
      return POST;
    },
  };
}
// ============ S3: cold light: a hot bulb vs a firefly with no heat ============
function sCold({ makeStage }) {
  const scene = lab(makeStage); const B = bulb(); B.group.position.set(-1.0, 0, 0); scene.add(B.group);
  const F = firefly(); F.group.scale.setScalar(3); F.group.position.set(1.0, 0.6, 0); F.group.rotation.y = -0.6; F.st.flying = 0; scene.add(F.group);
  const Lh = tag(scene, 'hot', 0.5, '#ff8a4a', [-1.0, 2.9, 0]), Lc = tag(scene, 'cold', 0.5, '#cfff8a', [1.0, 2.0, 0]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      B.update(T); F.st.glow = 1; F.update();
      pop(Lh, easeOut(range(T, at(3, 'heat') - 0.2, at(3, 'heat') + 0.2)), 0.5); pop(Lc, easeOut(range(T, at(3, 'cold') - 0.2, at(3, 'cold') + 0.2)), 0.5);
      const k = easeInOut(range(t, 0, 3.8));
      orb(c, [0, 1.3, 0], lerp(9.5, 9.0, k), lerp(-6, 6, k), 6);
      return POST;
    },
  };
}
// ============ S4: oxygen valves open and close: the lantern flashes ============
function sOxygen({ makeStage }) {
  const scene = lab(makeStage); const Lc = lanternCut(); scene.add(Lc.group);
  const L = tag(scene, 'oxygen', 0.4, '#ff8a7a', [0, 2.9, 0.4]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      const open = T < at(4, 'controls') ? 0 : blink(T - at(4, 'controls'), 1.0, 0.85) > 0.05 ? 1 : 0; Lc.set(smooth(open), T);
      pop(L, easeOut(range(T, at(4, 'oxygen') - 0.15, at(4, 'oxygen') + 0.2)), 0.4);
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [0, 0.2, 0], lerp(10.5, 9.8, k), lerp(-10, 8, k), 6);
      return POST;
    },
  };
}
// ============ S5: flash code: a male's flash trail in the air, a female answers from a grass blade ============
function sCode({ makeStage }) {
  const W = night(makeStage); const M = firefly(), Fm = firefly({ female: true }); W.scene.add(M.group, Fm.group); Fm.group.position.set(0.25, 0.55, 0.3); Fm.st.flying = 0;
  const trail = []; const tm = new THREE.MeshBasicMaterial({ color: GLOW, transparent: true, toneMapped: false }); for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 4), tm.clone()); W.scene.add(m); trail.push(m); }
  const c = C(38); const tf = at(5, 'flash', 1), ta = at(5, 'answer');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.S.update(T, 0, 0.35);
      const px = (tt) => new THREE.Vector3(-1.1 + tt * 0.3, 1.45 + 0.25 * Math.sin(tt * 2), 0.2 * Math.sin(tt));
      M.group.position.copy(px(t)); M.st.flap = T; M.st.glow = T > tf - 0.2 ? blink(T - tf + 0.2, 1.6, 0) : 0; M.update();
      trail.forEach((m, i) => { const tt = t - i * 0.03; const g = T - i * 0.03 > tf - 0.2 ? blink(T - i * 0.03 - tf + 0.2, 1.6, 0) : 0; m.position.copy(px(tt)); m.material.opacity = g * (1 - i / 40); m.visible = g > 0.02; });
      Fm.st.glow = T > ta - 0.1 ? blink(T - ta + 0.1, 1.6, 0) : 0; Fm.update();
      const k = easeInOut(range(t, 0, 6.2));
      orb(c, [-0.3, 1.0, 0], lerp(4.6, 4.0, k), lerp(10, 22, k), lerp(8, 12, k));
      return POST;
    },
  };
}
// ============ S6: femme fatale: a bigger female copies the reply; the male lands, she pounces, his light goes out ============
function sTrap({ makeStage }) {
  const W = night(makeStage); const M = firefly(), Fm = firefly({ female: true }); W.scene.add(M.group, Fm.group); Fm.group.scale.setScalar(1.5); Fm.st.flying = 0;
  const c = C(38); const te = at(6, 'eat');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.S.update(T, 0, 0.3);
      const land = smooth(range(T, ls(6), te - 0.3)); M.group.position.set(lerp(-1.4, 0.32, land), lerp(1.4, 0.55, land), 0); M.st.flying = 1 - smooth(range(T, te - 0.6, te - 0.3)); M.st.flap = T; M.st.glow = T < te ? blink(T, 1.3, 0.2) : Math.max(0, 1 - (T - te) * 3) * 0.5; M.update();
      const pounce = easeIn(range(T, te - 0.1, te + 0.15)); Fm.group.position.set(lerp(0.75, 0.42, pounce), 0.55, 0); Fm.st.glow = T < te - 0.2 ? blink(T + 0.3, 1.3, 0.2) : 0.15; Fm.update();
      const k = easeInOut(range(t, 0, 5.3));
      orb(c, [lerp(0.1, 0.4, k), lerp(1.0, 0.7, k), 0], lerp(4.0, 3.0, k), lerp(14, 26, k), lerp(8, 14, k));
      return POST;
    },
  };
}
// ============ S7: thousands flash in perfect sync ============
function sSync({ makeStage }) {
  const W = night(makeStage); const big = swarm(900, 11, [60, 8, 40]); W.scene.add(big.mesh); W.S.mesh.visible = false;
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      big.update(T, smooth(range(T, at(7, 'flash') - 0.6, at(7, 'sync'))), 2.2);
      const k = easeInOut(range(t, 0, 4.8));
      orb(c, [0, 2.5, -4], lerp(18, 24, k), lerp(-10, 10, k), lerp(8, 14, k));
      return POST;
    },
  };
}

const SH = [sHook, sLantern, sChem, sCold, sOxygen, sCode, sTrap, sSync];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
