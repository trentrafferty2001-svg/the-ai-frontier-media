// The Explainer: how fireflies glow. Firefly (head +x, ~0.3 long), night meadow swarm, chemistry molecules,
// bulb vs cold light, lantern with oxygen tubes, flash trails.
import * as THREE from 'three';
import { rnd } from './bolt.js';

const std = (c, r = 0.6, m = 0, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, ...o });
export const GLOW = 0xcfff5a;
export function firefly({ female = false } = {}) {
  const G = new THREE.Group(); const body = new THREE.Group(); G.add(body);
  const dark = std(0x2a2620, 0.5), shield = std(0xd84a2a, 0.5), yel = std(0xe8c84a, 0.6);
  const thorax = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 12), dark); thorax.scale.set(1.2, 0.8, 1); body.add(thorax);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.04, 14, 10), dark); head.position.x = 0.09; body.add(head);
  const pro = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), shield); pro.scale.set(0.9, 0.5, 1.1); pro.position.set(0.06, 0.01, 0); body.add(pro);
  const abd = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 12), yel); abd.scale.set(1.6, 0.7, 0.9); abd.position.x = -0.1; body.add(abd);
  const lanternM = new THREE.MeshStandardMaterial({ color: 0xf6ffb0, emissive: GLOW, emissiveIntensity: 0, roughness: 0.4, toneMapped: false });
  const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 12), lanternM); lantern.scale.set(1.3, 0.75, 0.95); lantern.position.set(-0.17, -0.005, 0); body.add(lantern);
  const elytra = [-1, 1].map(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.07, 14, 8, 0, Math.PI), std(0x3a3226, 0.5)); e.scale.set(2.2, 0.35, 0.6); e.position.set(-0.04, 0.035, s * 0.03); e.rotation.x = -Math.PI / 2; body.add(e); return e; });
  const wm = new THREE.MeshPhysicalMaterial({ color: 0xdfefff, transparent: true, opacity: 0.4, side: THREE.DoubleSide });
  const wings = [-1, 1].map(s => { const w = new THREE.Mesh(new THREE.CircleGeometry(0.12, 14), wm); w.scale.set(1.3, 0.45, 1); w.rotation.x = -Math.PI / 2; w.position.set(-0.05, 0.05, s * 0.1); body.add(w); return { w, s }; });
  [-1, 1].forEach(s => { const a = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.12, 4), dark); a.position.set(0.15, 0.03, s * 0.025); a.rotation.z = -1.0; a.rotation.x = s * 0.4; body.add(a); });
  const light = new THREE.PointLight(GLOW, 0, 3, 2); light.position.set(-0.2, 0, 0); body.add(light);
  if (female) { wings.forEach(({ w }) => w.visible = false); body.scale.setScalar(1.25); }
  const st = { glow: 0, flap: 0, flying: 1 };
  function update() { lanternM.emissiveIntensity = 3.5 * st.glow; light.intensity = 1.5 * st.glow; wings.forEach(({ w, s }) => { w.rotation.x = -Math.PI / 2 + s * st.flying * 0.6 * Math.sin(st.flap * 40); w.visible = st.flying > 0.02 && !female; }); }
  update();
  return { group: G, body, st, update, lanternM };
}
// swarm of glowing dots over a meadow: blink pattern by phase; sync k pulls everyone onto the same beat
export function swarm(n = 260, seed = 4, area = [30, 4, 20]) {
  const R = rnd(seed); const P = []; for (let i = 0; i < n; i++) P.push({ x: (R() - 0.5) * area[0], y: 0.3 + R() * area[1], z: (R() - 0.5) * area[2], ph: R(), per: 1.6 + R() * 1.6, dx: R() * 6, dy: R() * 6 });
  const m = new THREE.MeshBasicMaterial({ color: GLOW, toneMapped: false });
  const im = new THREE.InstancedMesh(new THREE.SphereGeometry(0.06, 8, 6), m, n); im.frustumCulled = false;
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3();
  function blink(u) { return Math.max(0, 1 - Math.abs(u - 0.1) / 0.08); }
  return { mesh: im, update(T, sync = 0, k = 1) { P.forEach((o, i) => { const own = blink(((T / o.per) + o.ph) % 1); const all = blink(((T / 1.8) + o.x * 0.01) % 1); const b = (1 - sync) * own + sync * all; M.compose(new THREE.Vector3(o.x + Math.sin(T * 0.3 + o.dx) * 0.6, o.y + Math.sin(T * 0.4 + o.dy) * 0.3, o.z), q, s.setScalar(Math.max(0.0001, b * k * (0.6 + 0.6 * b)))); im.setMatrixAt(i, M); }); im.instanceMatrix.needsUpdate = true; } };
}
// meadow: dark grass blades + silhouetted trees
export function meadow() {
  const G = new THREE.Group(); const R = rnd(7);
  const ground = new THREE.Mesh(new THREE.CircleGeometry(80, 32), std(0x0e1a10, 1)); ground.rotation.x = -Math.PI / 2; G.add(ground);
  const gm = std(0x1c3a1e, 0.9, 0, { side: THREE.DoubleSide }); const blade = new THREE.ConeGeometry(0.03, 0.8, 3); blade.translate(0, 0.4, 0);
  const n = 2500; const im = new THREE.InstancedMesh(blade, gm, n); const Mx = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
  for (let i = 0; i < n; i++) { e.set((R() - 0.5) * 0.4, R() * 3, (R() - 0.5) * 0.4); q.setFromEuler(e); Mx.compose(new THREE.Vector3((R() - 0.5) * 30, 0, (R() - 0.5) * 20), q, new THREE.Vector3(1, 0.6 + R() * 0.9, 1)); im.setMatrixAt(i, Mx); }
  G.add(im);
  const tm = std(0x0a120c, 1); for (let k = 0; k < 30; k++) { const a = -0.8 - (k / 30) * 1.6, r = 18 + R() * 20; const t = new THREE.Mesh(new THREE.ConeGeometry(2 + R() * 2, 9 + R() * 8, 8), tm); t.position.set(Math.cos(a) * r, 5, Math.sin(a) * r); G.add(t); }
  return G;
}
// chemistry: luciferin (yellow ring), O2 (two red balls), ATP (blue chain), luciferase (purple enzyme); light burst
export function chemistry() {
  const G = new THREE.Group();
  const luc = new THREE.Group(); [0, 1, 2].forEach(k => { const r = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.07, 10, 6), std(0xf2d23a, 0.4)); r.position.x = k * 0.5 - 0.5; r.rotation.y = 0; luc.add(r); }); G.add(luc);
  const o2 = new THREE.Group(); [-1, 1].forEach(s => { const b = new THREE.Mesh(new THREE.SphereGeometry(0.22, 16, 12), std(0xe8443a, 0.35)); b.position.x = s * 0.2; o2.add(b); }); G.add(o2);
  const atp = new THREE.Group(); for (let k = 0; k < 4; k++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 10), std(k === 0 ? 0x5a8aff : 0x3ac8ff, 0.4)); b.position.x = k * 0.3; atp.add(b); } G.add(atp);
  const enz = new THREE.Mesh(new THREE.SphereGeometry(0.75, 28, 18, 0.6, Math.PI * 2 - 1.2), std(0x9a5ad8, 0.45, 0, { emissive: 0x4a1a8a, emissiveIntensity: 0.3, side: THREE.DoubleSide })); enz.rotation.y = Math.PI / 2; G.add(enz);
  const flash = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16), new THREE.MeshBasicMaterial({ color: GLOW, transparent: true, opacity: 0, toneMapped: false, blending: THREE.AdditiveBlending, depthWrite: false })); G.add(flash);
  return { group: G, set(come, react, T) {
    luc.position.set(lerp(-1.1, -0.25, come), lerp(2.0, 0.1, come), 0); luc.rotation.z = T * 0.5 * (1 - come);
    o2.position.set(lerp(1.1, 0.3, come), lerp(2.0, 0.25, come), 0.2); o2.rotation.z = T * (1 - come);
    atp.position.set(lerp(-0.4, -0.3, come), lerp(-2.0, -0.4, come), 0.1);
    const f = react > 0 ? Math.max(0, Math.sin(Math.min(1, react) * Math.PI)) : 0; flash.material.opacity = 0.6 * f; flash.scale.setScalar(0.4 + 1.1 * react);
  } };
}
const lerp = (a, b, t) => a + (b - a) * t;
// light bulb with heat shimmer
export function bulb() { const G = new THREE.Group(); const glass = new THREE.Mesh(new THREE.SphereGeometry(0.55, 24, 16), new THREE.MeshStandardMaterial({ color: 0xfff2c0, emissive: 0xffc860, emissiveIntensity: 1.0, transparent: true, opacity: 0.95, toneMapped: false })); glass.position.y = 0.6; G.add(glass); const base = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.4, 16), std(0xb0b0b0, 0.3, 0.9)); base.position.y = -0.05; G.add(base);
  const R = rnd(3); const waves = []; const wm = new THREE.MeshBasicMaterial({ color: 0xff7a3a, transparent: true, opacity: 0.6, toneMapped: false }); for (let k = 0; k < 6; k++) { const w = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.02, 6, 16, Math.PI), wm); G.add(w); waves.push({ w, x: (k - 2.5) * 0.18, ph: R() }); }
  return { group: G, update(T) { waves.forEach(o => { const u = (o.ph + T * 0.6) % 1; o.w.position.set(o.x + Math.sin(T * 4 + o.ph * 6) * 0.05, 1.3 + u * 1.4, 0); o.w.material.opacity = 0.6 * (1 - u); }); } }; }
// lantern cutaway: a slab of glowing cells fed by air tubes; oxygen dots flow in when the valve is open
export function lanternCut() {
  const G = new THREE.Group();
  const cellM = new THREE.MeshStandardMaterial({ color: 0xf6ffb0, emissive: GLOW, emissiveIntensity: 0.1, roughness: 0.5, toneMapped: false });
  const R = rnd(8); for (let k = 0; k < 24; k++) { const c = new THREE.Mesh(new THREE.SphereGeometry(0.35, 14, 10), cellM); c.position.set((k % 6) * 0.75 - 1.9, -Math.floor(k / 6) * 0.55 - 0.5, (R() - 0.5) * 0.3); c.scale.set(1, 0.7, 0.6); G.add(c); }
  const tm = new THREE.MeshPhysicalMaterial({ color: 0xcfe8ff, roughness: 0.2, transmission: 0.5, transparent: true, opacity: 0.6 });
  const tubes = [-1.5, 0, 1.5].map(x => { const t = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 2.4, 12), tm); t.position.set(x, 1.0, 0.4); G.add(t); return x; });
  const valves = tubes.map(x => { const v = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.08, 0.36), std(0xff6a3a, 0.4)); v.position.set(x, 0.05, 0.4); G.add(v); return v; });
  const dots = []; const dm = new THREE.MeshBasicMaterial({ color: 0xff5a4a, toneMapped: false }); for (let i = 0; i < 36; i++) { const d = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), dm); G.add(d); dots.push({ d, x: tubes[i % 3], ph: R() }); }
  return { group: G, set(open, T) { cellM.emissiveIntensity = 0.1 + 3.2 * open; valves.forEach(v => { v.rotation.z = open * 1.3; }); dots.forEach(o => { const u = (o.ph + T * 0.8) % 1; const y = 2.2 - u * (open > 0.3 ? 3.2 : 1.9); o.d.position.set(o.x, y, 0.4); o.d.visible = !(open < 0.3 && y < 0.15); }); } };
}
export { std };
