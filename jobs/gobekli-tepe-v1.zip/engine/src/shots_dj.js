// Dujiangyan reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { splash2 } from './farm2.js';
import { birds, waterMaterial, mountains } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll, crackPath, ribbon } from './rome.js';
import { mingWorker } from './rice.js';
import { headworks, flow, zhulong, liBing, scroll, landMats } from './dujiang.js';
import { VO } from './vo_dj.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(9) + 1.2) * 24) / 24;

const CHUNKS = [
  [['A *fish*', 2], ['built over', 2], ['*2,000 years*', 3], ['ago', 1], ['still *controls*', 2], ['this *river*', 2]],
  [["It's a", 2], ['*stone levee*', 2], ['shaped like', 2], ['the *mouth*', 2], ['of a *fish*', 3], ['*splitting*', 1], ['the river', 2], ['in *two*', 2]],
  [['Around', 1], ['*256 BC*', 5], ['governor', 1], ['*Li Bing*', 2], ['set out', 2], ['to stop', 2], ['the *floods*', 2]],
  [['His workers', 2], ['piled long', 2], ['*bamboo baskets*', 2], ['full of *stones*', 3], ['into the river', 3]],
  [['In *dry* months', 3], ['the deeper', 2], ['*inner channel*', 2], ['takes about', 2], ['*60 percent*', 2], ['for the *farms*', 3]],
  [['In *floods*', 2], ['the split *flips*', 3], ['and most water', 3], ['rushes down', 2], ['the *outer river*', 3]],
  [['A low *spillway*', 3], ['dumps', 1], ['extra *water*', 2], ['and *sand*', 2], ['back out', 2]],
  [['Then the rest', 3], ['*squeezes* through', 2], ['a *gap*', 2], ['cut through', 2], ['a *mountain*', 2]],
  [['Workers', 1], ['*reportedly*', 1], ['cracked that rock', 3], ['by heating it', 3], ['with *fire*', 2], ['then dousing it', 3], ['with *cold water*', 3]],
  [["There's no *dam*", 3], ['and it still', 3], ['*waters* the farms', 3], ['around *Chengdu*', 2], ['*today*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, Math.min(wl[2] + 0.3, DURATION - 0.05)] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared world ============
function world(makeStage, { outdoor = 'day', sunDir = [-0.45, 0.55, 0.7], cloud = 0.4, fog = 0.003, flood = 0 } = {}) {
  const scene = makeStage({ outdoor, sunDir, fog, shadowSize: 60, envI: 0.9, cloud });
  const hw = headworks(); scene.add(hw);
  const fl = flow(); scene.add(fl);
  fillLight(scene, [0.5, 0.6, -0.8], 0.5);
  const b = birds(4, { from: [-40, 22, -30], to: [40, 26, -10], spread: 8, speed: 0.04, scale: 2.0, seed: 5 }); scene.add(b);
  scene.userData.updaters.push((t) => b.update(t));
  const setFlood = (k) => { hw.water.position.y = k * 0.9; hw.water.material.uniforms ? 0 : 0; hw.water.material.color.set(0x2f5a5a).lerp(new THREE.Color(0x4a3a22), k); hw.water.material.roughness = 0.03 + 0.55 * k; hw.water.material.envMapIntensity = 1 - 0.7 * k; fl.material.opacity = 0.75 + 0.2 * k; };
  setFlood(flood);
  return { scene, hw, fl, setFlood };
}

// ============ S0 hook: the fish-shaped levee splits the river, seen from above ============
function sHook({ makeStage }) {
  const { scene, fl } = world(makeStage, { outdoor: 'golden', sunDir: [-0.6, 0.45, -0.65] });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      fl.set(t, { inner: 0.55, speed: 0.045 });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-14, -9, k), lerp(46, 30, k), lerp(-50, -38, k)], [lerp(0, 0, k), 0, lerp(2, -2, k)]);
      return { bloom: 0.55, flare: 0.8, warm: 1.15 };
    },
  };
}
// ============ S1: low over the water at the levee's nose ============
function sNose({ makeStage, start: ST }) {
  const { scene, fl } = world(makeStage, { sunDir: [0.5, 0.5, 0.7] });
  const spl = [0, 1, 2].map(i => { const s = splash2(1.2, 30 + i); scene.add(s); return s; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      fl.set(t, { inner: 0.55, speed: 0.05 });
      spl.forEach((s, i) => { s.position.set((i - 1) * 0.9, 0.02, -12.4 + Math.abs(i - 1) * 1.2); s.update(((t + i * 0.4) % 1.2)); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-3.0, 2.5, k), lerp(2.2, 3.4, k), lerp(-24, -21, k)], [0, 0.6, lerp(-8, -5, k)]);
      return { bloom: 0.5, warm: 1.0 };
    },
  };
}
// ============ S2: Li Bing on the bank, the river in flood, plan in hand ============
function sLiBing({ makeStage, start: ST }) {
  const tF = at(2, 'floods') - ST;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.4, 0.6, 0.7], fog: 0.012, shadowSize: 3, envI: 0.6, cloud: 0.9 });
  const M = landMats();
  const water = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), waterMaterial({ color: 0x6a5a40, opacity: 1, ripple: 2.6 })); water.rotation.x = -Math.PI / 2; water.position.y = 0.4; scene.add(water);
  const bank = new THREE.Mesh(new THREE.BoxGeometry(30, 2, 30), M.grass); bank.position.set(0, 0, 14); bank.receiveShadow = true; scene.add(bank);
  scene.add(mountains({ rMin: 60, rMax: 200, height: 40, seed: 3, color: 0x4f6a40 }));
  // half-drowned huts and debris
  const A = archMats();
  [[-7, -9], [6, -14], [-2, -20]].forEach(([x, z], i) => { const hut = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.6, 2), A.wood); hut.position.set(x, 0.6, z); hut.rotation.y = i; scene.add(shadowAll(hut)); const r = new THREE.Mesh(new THREE.ConeGeometry(1.9, 1.2, 4), new THREE.MeshStandardMaterial({ color: 0xa88a50, roughness: 1 })); r.rotation.y = Math.PI / 4 + i; r.position.set(x, 2.0, z); scene.add(shadowAll(r)); });
  const logs = [0, 1, 2, 3].map(i => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 2, 8), A.wood); l.rotation.z = Math.PI / 2; scene.add(l); return l; });
  const man = liBing(); man.root.position.set(0.8, 1.0, -0.4); man.root.rotation.y = Math.PI - 0.5; scene.add(man.root);
  const sc = scroll(); scene.add(sc);
  const N = 300; const drops = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.01, 0.01, 0.4, 4), new THREE.MeshBasicMaterial({ color: 0xd4e4f2, transparent: true, opacity: 0.45 }), N); scene.add(drops);
  const D = [...Array(N)].map((_, i) => [Math.sin(i * 12.9898) * 8, Math.cos(i * 78.233) * 6 - 2, (i * 0.618) % 1]);
  fillLight(scene, [0.4, 0.5, 1], 0.6);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      standPose(man, t, { head: [0.1, 0.25, 0], neck: [0.05, 0, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [1.0, 3.2])); man.grip(0.8, 0.8);
      man.root.updateMatrixWorld(true);
      const sp = wpos(man.root, V(0, 1.15, 0.36)); sc.position.copy(sp); sc.quaternion.copy(man.root.quaternion); sc.rotateX(-0.5); sc.updateMatrixWorld(true);
      ikArm(man, 'l', wpos(sc, V(0.16, 0, 0)), wpos(man.root, V(0.7, 0.2, 0)), V(0, 1, 0));
      ikArm(man, 'r', wpos(sc, V(-0.16, 0, 0)), wpos(man.root, V(-0.7, 0.2, 0)), V(0, 1, 0));
      logs.forEach((l, i) => l.position.set(-12 + ((t * 1.6 + i * 6) % 24), 0.45, -5 - i * 2.5));
      const m4 = new THREE.Matrix4();
      D.forEach(([x, z, ph], i) => { m4.makeTranslation(x, 6 - ((t * 1.5 + ph) % 1) * 6, z); drops.setMatrixAt(i, m4); }); drops.instanceMatrix.needsUpdate = true;
      const k = easeInOut(range(t, 0, 4.4));
      const pos = [lerp(3.6, 3.3, k), lerp(2.4, 2.3, k), lerp(2.0, 1.5, k)], look = [lerp(0.4, 0.1, k), lerp(1.7, 1.6, k), lerp(-1.4, -1.8, k)];
      place(c, pos, look);
      return { bloom: 0.3, warm: 0.75, sat: 0.9 };
    },
  };
}
// ============ S3: two workers lower a bamboo basket of stones onto the growing levee ============
function sBaskets({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.6, 0.6], fog: 0.004, shadowSize: 3, envI: 0.9, cloud: 0.35 });
  const water = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), waterMaterial({ color: 0x2f5a5a, opacity: 1, ripple: 1.5 })); water.rotation.x = -Math.PI / 2; scene.add(water);
  scene.add(mountains({ rMin: 70, rMax: 220, height: 45, seed: 5, color: 0x4f6a40 }));
  // stacked zhulong forming the levee edge (pyramid of baskets), plus wooden tripods (macha)
  for (let r = 0; r < 3; r++) for (let i = 0; i < 6 - r; i++) { const z = zhulong(); z.position.set(-3.2 + i * 1.15 + r * 0.55, -0.1 + r * 0.5, -1.2 - r * 0.15); z.rotation.y = Math.PI / 2; scene.add(z); }
  const A = archMats();
  for (const x of [-3.6, 2.8]) for (let k = 0; k < 3; k++) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 3.2, 8), A.wood); const a = k / 3 * Math.PI * 2; p.position.set(x + Math.cos(a) * 0.5, 1.3, -2.6 + Math.sin(a) * 0.5); p.lookAt(x, 3.2, -2.6); p.rotateX(Math.PI / 2); scene.add(shadowAll(p)); }
  // workers stand on the top of the pile and lower one more basket
  const a = mingWorker(0), b = mingWorker(1);
  a.root.position.set(-0.7, 1.1, -1.0); a.root.rotation.y = Math.PI / 2; b.root.position.set(0.9, 1.1, -1.0); b.root.rotation.y = -Math.PI / 2; scene.add(a.root, b.root);
  const zl = zhulong(1.4, 0.24); scene.add(zl);
  const spl = splash2(1.0, 4); scene.add(spl);
  fillLight(scene, [0.4, 0.5, 1], 0.6);
  const c = cam(38);
  const tDrop = 2.6;
  return {
    scene, camera: c,
    update(t) {
      const swing = Math.sin(t * 2.2) * 0.12 * (1 - range(t, tDrop - 0.6, tDrop));
      const y = t < tDrop ? 1.45 + swing * 0.3 : lerp(1.45, 0.05, easeIn(range(t, tDrop, tDrop + 0.45)));
      zl.position.set(0.1, y, -0.15 + (t < tDrop ? swing : 0.25)); zl.rotation.set(0, 0, 0);
      spl.visible = t > tDrop + 0.4 && t < tDrop + 1.6; spl.position.set(0.1, 0.02, 0.2); spl.update(t - tDrop - 0.4);
      [a, b].forEach((p, i) => { standPose(p, t + i, { spine: [0.35, 0, 0], chest: [0.15, 0, 0], head: [0.2, 0, 0], lKn: [0.4, 0, 0], rKn: [0.4, 0, 0], lHip: [-0.3, 0, 0.07], rHip: [-0.3, 0, -0.07], drop: -0.06 }); p.setMood('happy'); p.setMouth(0); p.blink(blinkK(t, [0.7 + i])); p.grip(0.9, 0.9); });
      a.root.updateMatrixWorld(true); b.root.updateMatrixWorld(true); zl.updateMatrixWorld(true);
      const holding = t < tDrop;
      const ea = holding ? wpos(zl, V(0, 0.55, 0)) : wpos(a.root, V(0.15, 0.9, 0.45)), eb = holding ? wpos(zl, V(0, -0.55, 0)) : wpos(b.root, V(-0.15, 0.9, 0.45));
      ikArm(a, 'l', ea.clone().add(V(0, 0.2, -0.08)), wpos(a.root, V(0.6, 0.2, 0)), V(0, 1, 0)); ikArm(a, 'r', ea.clone().add(V(0, 0.2, 0.08)), wpos(a.root, V(-0.6, 0.2, 0)), V(0, 1, 0));
      ikArm(b, 'l', eb.clone().add(V(0, 0.2, 0.08)), wpos(b.root, V(0.6, 0.2, 0)), V(0, 1, 0)); ikArm(b, 'r', eb.clone().add(V(0, 0.2, -0.08)), wpos(b.root, V(-0.6, 0.2, 0)), V(0, 1, 0));
      const k = easeInOut(range(t, 0, 4.0));
      const pos = [lerp(1.6, 1.0, k), lerp(2.2, 1.9, k), lerp(5.2, 4.4, k)], look = [lerp(0.1, 0.0, k), lerp(1.2, 0.8, k), -0.8];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.05, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S4 / S5: the split, dry season vs flood ============
function sDry({ makeStage, start: ST }) {
  const tS = at(4, 'sixty') - ST;
  const { scene, fl } = world(makeStage, { sunDir: [-0.4, 0.6, 0.7] });
  const glint = [...Array(3)].map(() => { const s = glowSprite(0xbff0ff, 1.2); s.material.opacity = 0; scene.add(s); return s; });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      fl.set(t, { inner: 0.6, speed: 0.04, level: 0, width: 2.4 });
      glint.forEach((s, i) => { s.position.set(-6.8, 0.3, 4 + i * 8); s.material.opacity = 0.6 * Math.sin(Math.PI * range(t, tS - 0.3 + i * 0.12, tS + 0.9 + i * 0.12)); });
      const k = easeInOut(range(t, 0, 5.0));
      place(c, [lerp(-26, -22, k), lerp(34, 30, k), lerp(-26, -20, k)], [lerp(-1, -2, k), 0, lerp(8, 12, k)]);
      return { bloom: 0.5, warm: 1.0 };
    },
  };
}
function sFlood({ makeStage, start: ST }) {
  const tF = at(5, 'flips') - ST;
  const { scene, fl, setFlood } = world(makeStage, { sunDir: [-0.3, 0.6, 0.7], cloud: 0.85, fog: 0.006 });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const k1 = easeInOut(range(t, 0, tF));
      setFlood(k1);
      fl.set(t, { inner: lerp(0.6, 0.35, easeInOut(range(t, tF - 0.4, tF + 0.6))), speed: lerp(0.04, 0.08, k1), level: k1 * 0.9, width: 3.2 });
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(22, 20, k), lerp(32, 28, k), lerp(-28, -22, k)], [lerp(1, 2, k), 0, lerp(6, 10, k)]);
      return { bloom: 0.2, warm: 0.85, sat: 0.95 };
    },
  };
}
// ============ S6: the flying-sand spillway: water and sand thrown over the low weir ============
function sSpill({ makeStage, start: ST }) {
  const tSa = at(6, 'sand') - ST;
  const { scene, fl, setFlood } = world(makeStage, { sunDir: [-0.5, 0.5, 0.7], cloud: 0.6 });
  setFlood(0.39);
  const sand = [...Array(40)].map((_, i) => { const s = glowSprite(0x9a7a4a, 0.22); s.material.blending = THREE.NormalBlending; s.material.opacity = 0; scene.add(s); return { s, i }; });
  const spl = [0, 1, 2, 3].map(i => { const s = splash2(1.0, 40 + i); scene.add(s); return s; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      fl.set(t, { inner: 0.5, spill: 0.6, speed: 0.06, level: 0.36, width: 2.6 });
      spl.forEach((s, i) => { s.position.set(2.4, 0.37, 23 + i * 2); s.update(((t + i * 0.3) % 1.0)); });
      sand.forEach(({ s, i }) => { const a = ((t * 0.7 + i / 40) % 1); const on = t > tSa - 1.2; s.visible = on; if (!on) return; s.position.set(-1.5 + a * 7, 0.45 + Math.sin(a * Math.PI) * 0.4, 22.5 + (i % 8) * 0.95); s.material.opacity = 0.6 * Math.sin(Math.PI * a); });
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(10, 8.5, k), lerp(6.5, 5.5, k), lerp(38, 35, k)], [lerp(0, 0.5, k), 0.3, lerp(26, 25.5, k)]);
      return { bloom: 0.15, warm: 0.95 };
    },
  };
}
// ============ S7: flying down the inner channel through the bottle-neck gap ============
function sGap({ makeStage }) {
  const { scene, fl } = world(makeStage, { outdoor: 'golden', sunDir: [0.5, 0.35, 0.8] });
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      fl.set(t, { inner: 0.6, speed: 0.05 });
      const k = easeInOut(range(t, 0, 3.3));
      const z = lerp(16, 41, k);
      place(c, [lerp(-6.0, -4.4, k), lerp(4.0, 2.2, k), z], [-4.4, lerp(1.0, 1.2, k), z + 10]);
      return { bloom: 0.55, flare: 0.8, warm: 1.2 };
    },
  };
}
// ============ S8: fire against the rock face, then cold water: steam and a crack ============
function sFire({ makeStage, start: ST }) {
  const tF = at(8, 'fire') - ST, tC = at(8, 'cold') - ST, tCr = at(8, 'cracked') - ST;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.45, 0.75], fog: 0.004, shadowSize: 3, envI: 0.8, cloud: 0.5 });
  const M = landMats();
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), M.grass); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const rock = new THREE.Mesh(new THREE.BoxGeometry(8, 6, 3), new THREE.MeshStandardMaterial({ color: 0x6a645a, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 8 })); rock.position.set(0, 3, -1.6); rock.receiveShadow = rock.castShadow = true; scene.add(rock);
  scene.add(mountains({ rMin: 60, rMax: 200, height: 40, seed: 3, color: 0x4f6a40 }));
  // heat glow on the rock face
  const hot = new THREE.Mesh(new THREE.CircleGeometry(0.6, 32), new THREE.MeshBasicMaterial({ color: 0xff6a20, transparent: true, opacity: 0 })); hot.position.set(0, 0.9, -0.09); scene.add(hot);
  const crack = ribbon(crackPath(5, { top: 2.0, bottom: 0.2, x0: 0.0, wander: 0.18, steps: 26 }), 0.035, new THREE.MeshBasicMaterial({ color: 0x0e0c0a }), -0.08); scene.add(crack);
  // fire: log pile + flame sprites
  const A = archMats();
  for (let i = 0; i < 5; i++) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.09, 1.1, 8), A.wood); l.rotation.set(Math.PI / 2, (i - 2) * 0.5, 0); l.position.set(0, 0.1 + (i % 2) * 0.12, 0.25); scene.add(shadowAll(l)); }
  const flames = [...Array(12)].map((_, i) => { const s = glowSprite(i % 2 ? 0xff8a2a : 0xffc04a, 0.45); scene.add(s); return { s, i }; });
  const fireL = new THREE.PointLight(0xff8a3a, 0, 6, 2); fireL.position.set(0, 0.8, 0.6); scene.add(fireL);
  const steam = [...Array(26)].map((_, i) => { const s = glowSprite(0xf4f4f0, 0.6); s.material.blending = THREE.NormalBlending; scene.add(s); return { s, i }; });
  const man = mingWorker(3); man.root.position.set(1.2, 0, 1.3); man.root.rotation.y = -2.6; scene.add(man.root);
  const bk = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.11, 0.24, 16), A.wood); scene.add(shadowAll(bk));
  const stream = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.05, 1, 10, 1, true), new THREE.MeshStandardMaterial({ color: 0xbfd8e0, roughness: 0.05, transparent: true, opacity: 0.8 })); scene.add(stream);
  fillLight(scene, [0.4, 0.5, 1], 0.6);
  const c = cam(38);
  const tOut = tC - 0.2;
  return {
    scene, camera: c,
    update(t) {
      const fireOn = 1 - easeIn(range(t, tOut, tOut + 0.5));
      flames.forEach(({ s, i }) => { s.visible = fireOn > 0.02; s.position.set(Math.sin(i * 2.3) * 0.35, 0.3 + ((t * 1.4 + i / 12) % 1) * 0.9, 0.2 + Math.cos(i) * 0.15); s.scale.setScalar((0.3 + 0.15 * Math.sin(t * 9 + i)) * fireOn); });
      fireL.intensity = 4 * fireOn * (0.85 + 0.15 * Math.sin(t * 11));
      hot.material.opacity = 0.35 * easeOut(range(t, 0, tF + 0.4)) * (1 - easeIn(range(t, tC, tC + 1.2)));
      crack.reveal(easeOut(range(t, tC + 0.2, tC + 0.9)));
      const pour = range(t, tC - 0.5, tC + 1.4);
      steam.forEach(({ s, i }) => { const a = ((t * 0.6 + i / 26) % 1); const on = t > tC - 0.1; s.visible = on; if (!on) return; s.position.set(Math.sin(i * 1.7) * 0.8, 0.5 + a * 2.6, 0.1 + a * 0.3); s.scale.setScalar(0.4 + a * 1.4); s.material.opacity = 0.5 * Math.sin(Math.PI * a) * (1 - range(t, tC + 2.0, tC + 3.5) * 0.6); });
      standPose(man, t, { spine: [0.15, 0, 0], head: [0.15, 0, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.8, 2.6])); man.grip(0.9, 0.9);
      man.root.updateMatrixWorld(true);
      const tilt = easeInOut(range(t, tC - 0.6, tC - 0.1)) * 1.7;
      const bp = wpos(man.root, V(0, 1.15, 0.45)); bk.position.copy(bp); bk.quaternion.copy(man.root.quaternion).multiply(new THREE.Quaternion().setFromAxisAngle(V(1, 0, 0), tilt)); bk.updateMatrixWorld(true);
      ikArm(man, 'l', wpos(bk, V(0.13, 0, 0)), wpos(man.root, V(0.8, 0.4, 0)), V(0, 0, 1)); ikArm(man, 'r', wpos(bk, V(-0.13, -0.05, 0)), wpos(man.root, V(-0.8, 0.4, 0)), V(0, 0, 1));
      const lip = wpos(bk, V(0, 0.12, 0.12)); const pouring = pour > 0 && pour < 1 && tilt > 1.0;
      stream.visible = pouring; if (pouring) { const end = V(0.1, 0.9, -0.05); const d = end.clone().sub(lip); stream.position.copy(lip).addScaledVector(d, 0.5); stream.quaternion.setFromUnitVectors(V(0, 1, 0), d.clone().normalize()); stream.scale.y = d.length(); }
      const k = easeInOut(range(t, 0, 5.0));
      const sh = t > tC + 0.2 && t < tC + 0.6 ? shake(t * 5, 2, 3) : [0, 0, 0];
      const pos = [lerp(-3.4, -2.8, k) + sh[0] * 0.02, lerp(2.0, 1.8, k) + sh[1] * 0.02, lerp(9.0, 7.6, k)], look = [lerp(0.4, 0.3, k), lerp(1.3, 1.2, k), 0.2];
      place(c, pos, look);
      return { bloom: 0.4 + fireOn * 0.4, warm: 1.0 + fireOn * 0.2, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S9: golden pull-back over the whole system and the green plain ============
function sEnd({ makeStage, start: ST }) {
  const { scene, fl } = world(makeStage, { outdoor: 'golden', sunDir: [-0.7, 0.3, 0.65] });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      fl.set(t, { inner: 0.6, speed: 0.045 });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-30, -46, k), lerp(26, 52, k), lerp(78, 100, k)], [lerp(-14, -8, k), 0, lerp(40, 28, k)]);
      return { bloom: 0.6, flare: 1.0, warm: 1.25 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sNose, 'nose'],
  [ls(2), ls(3), sLiBing, 'libing'],
  [ls(3), ls(4), sBaskets, 'baskets'],
  [ls(4), ls(5), sDry, 'dry'],
  [ls(5), ls(6), sFlood, 'flood'],
  [ls(6), ls(7), sSpill, 'spill'],
  [ls(7), ls(8), sGap, 'gap'],
  [ls(8), ls(9), sFire, 'fire'],
  [ls(9), DURATION + 1, sEnd, 'end'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
