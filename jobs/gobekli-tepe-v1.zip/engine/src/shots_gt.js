// Göbekli Tepe reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, birds } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll } from './rome.js';
import { tPillar, enclosure, hunter, hideTent, wildWheat } from './gobekli.js';
import { VO } from './vo_gt.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(9) + 1.5) * 24) / 24;

const CHUNKS = [
  [['These stones', 2], ['are *6,000 years*', 4], ['*older* than', 2], ['*Stonehenge*', 1]],
  [['This is', 2], ['*Göbekli Tepe*', 2], ['in southern', 2], ['*Turkey*', 1]],
  [['About', 1], ['*11,500 years*', 5], ['ago', 1], ['people raised', 2], ['*rings*', 1], ['of giant', 2], ['*T-shaped pillars*', 3], ['here', 1]],
  [['The biggest', 2], ['stand over', 2], ['*5 meters*', 2], ['tall', 1], ['and weigh', 2], ['around', 1], ['*10 tonnes*', 2]],
  [["They're carved", 2], ['with *foxes*', 2], ['*boars*', 1], ['*snakes*', 1], ['and *vultures*', 2]],
  [['Some even', 2], ['have *arms*', 2], ['and *hands*', 2], ['like giant', 2], ['*stone people*', 2]],
  [['But the builders', 3], ['had *no metal*', 3], ['*no pottery*', 2], ['and had barely', 3], ['started *farming*', 2]],
  [['They shaped', 2], ['the stone', 2], ['with *flint* tools', 3], ['and moved it', 3], ['by *muscle power*', 3]],
  [['Later', 1], ['the rings', 2], ['were *buried*', 2], ['*possibly*', 1], ['on purpose', 2], ['and stayed hidden', 3], ['for *10,000 years*', 4]],
  [['It hints that', 3], ['big *temples*', 2], ['may have come', 3], ['*before farming*', 2], ['not after', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: the hilltop on the Anatolian plateau ============
function plateau(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.32, 0.73], fog: 0.003, shadowSize: 12, envI: 0.95, cloud: 0.3, ...opts });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(500, 64), new THREE.MeshStandardMaterial({ color: 0xa8945a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 160, rMax: 360, height: 28, seed: 11, color: 0x9a8a5a }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  const b = birds(3, { from: [-40, 20, -40], to: [40, 24, -60], spread: 6, speed: 0.04, scale: 1.8, seed: 9 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  return scene;
}
function site(scene) {
  const e1 = enclosure({ r: 7, n: 11, seed: 3 }); scene.add(e1);
  const e2 = enclosure({ r: 5.5, n: 9, seed: 5, centralH: 4.6 }); e2.position.set(-17, 0, -6); scene.add(e2);
  const e3 = enclosure({ r: 6, n: 10, seed: 7, centralH: 5 }); e3.position.set(14, 0, -10); scene.add(e3);
  return [e1, e2, e3];
}

// ============ S0 hook: sunrise behind the twin central pillars ============
function sHook({ makeStage }) {
  const scene = plateau(makeStage, { sunDir: [0.15, 0.12, -0.98] });
  const [e1] = site(scene);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.8));
      place(c, [lerp(0.9, 2.6, k), lerp(0.8, 2.2, k), lerp(5.5, 9.5, k)], [lerp(0, 0, k), lerp(4.0, 3.0, k), lerp(0, -1, k)]);
      return { bloom: 0.7, flare: 1.3, warm: 1.3 };
    },
  };
}
// ============ S1: aerial over the rings on the hill ============
function sAerial({ makeStage }) {
  const scene = plateau(makeStage);
  site(scene);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const a = lerp(0.6, 0.9, easeInOut(range(t, 0, 3.2)));
      place(c, [Math.sin(a) * 34, lerp(26, 22, range(t, 0, 3.2)), Math.cos(a) * 34], [-1, 0, -4]);
      return { bloom: 0.55, flare: 0.9, warm: 1.2 };
    },
  };
}
// ============ S2: hunter-gatherers haul a pillar upright with ropes ============
function ropeMesh() { return new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1, 6), new THREE.MeshStandardMaterial({ color: 0x8a7048, roughness: 1 })); }
function setRope(r, a, b) { const d = b.clone().sub(a); r.position.copy(a).addScaledVector(d, 0.5); r.quaternion.setFromUnitVectors(V(0, 1, 0), d.clone().normalize()); r.scale.y = d.length(); }
function sRaise({ makeStage, start: ST }) {
  const tR = at(2, 'raised') - ST;
  const scene = plateau(makeStage, { sunDir: [-0.5, 0.4, 0.77] });
  const e = enclosure({ r: 7, n: 7, seed: 13 }); e.position.set(-2, 0, -13); scene.add(e);
  const pv = new THREE.Group(); pv.position.set(0, 0, 0); scene.add(pv);
  const p = tPillar({ h: 3.6, kinds: [['fox', 256, 420, 1.2]], seed: 77 }); pv.add(p);
  const men = [0, 1, 2, 3, 4].map(i => { const m = hunter(i); m.root.position.set(-0.6 + (i % 2) * 1.2, 0, 4.2 + Math.floor(i / 2) * 0.9); m.root.rotation.y = Math.PI; scene.add(m.root); return m; });
  const ropes = men.map(() => { const r = ropeMesh(); scene.add(r); return r; });
  const prop = [0, 1].map(i => { const m = hunter(i + 2); m.root.position.set(i ? 1.4 : -1.4, 0, -0.9); m.root.rotation.y = 0; scene.add(m.root); return m; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const up = easeInOut(range(t, 0.2, tR + 1.8));
      pv.rotation.x = lerp(-1.25, 0, up);
      pv.updateMatrixWorld(true);
      const top = pv.localToWorld(V(0, 3.2, 0.1));
      men.forEach((m, i) => { const lean = 0.35; standPose(m, t + i, { spine: [-lean * 0.5, 0, 0], lHip: [0.35, 0, 0.07], rHip: [-0.2, 0, -0.07], lKn: [0.3, 0, 0], head: [-0.1, 0, 0] }); m.setMood('happy'); m.setMouth(0.3); m.grip(0.95, 0.95); m.root.position.z = 4.2 + Math.floor(i / 2) * 0.9 + up * 0.8; m.root.updateMatrixWorld(true); const h = wpos(m.root, V(0, 1.05, 0.35)); setRope(ropes[i], top, h); ikArm(m, 'l', h.clone().add(V(0.06, 0, 0)), wpos(m.root, V(0.7, 0.2, 0)), V(0, 1, 0)); ikArm(m, 'r', h.clone().add(V(-0.06, -0.05, 0.05)), wpos(m.root, V(-0.7, 0.2, 0)), V(0, 1, 0)); });
      prop.forEach((m, i) => { standPose(m, t, { spine: [0.3, 0, 0], head: [0.2, 0, 0] }); m.setMood('happy'); m.grip(0.9, 0.9); m.root.updateMatrixWorld(true); const h = pv.localToWorld(V(i ? 0.5 : -0.5, 1.0, -0.2)); ikArm(m, 'l', h, wpos(m.root, V(0.7, 0.2, 0)), V(0, 1, 0)); ikArm(m, 'r', h.clone().add(V(0, -0.15, 0)), wpos(m.root, V(-0.7, 0.2, 0)), V(0, 1, 0)); });
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(17, 15, k), lerp(3.6, 3.2, k), lerp(3.6, 2.8, k)], [0, lerp(1.5, 1.9, k), 2.0]);
      return { bloom: 0.55, flare: 0.9, warm: 1.25 };
    },
  };
}
// ============ S3: a man beside the 5.5 m central pillar ============
function sScale({ makeStage }) {
  const scene = plateau(makeStage, { sunDir: [-0.6, 0.38, 0.7] });
  const [e1] = site(scene);
  const m = hunter(1); m.root.position.set(0.9, 0, 2.3); m.root.rotation.y = -0.3; scene.add(m.root);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      standPose(m, t, { head: [-0.6, 0, 0], neck: [-0.3, 0, 0] }); m.setMood('happy'); m.setMouth(0.4); m.blink(blinkK(t, [1.1]));
      const k = easeInOut(range(t, 0, 3.8));
      place(c, [lerp(2.8, 3.4, k), lerp(0.6, 0.9, k), lerp(5.5, 7.5, k)], [0, lerp(2.0, 2.8, k), 1.6]);
      return { bloom: 0.55, flare: 0.9, warm: 1.25 };
    },
  };
}
// ============ S4: macro pan across carved animals, each lit as it is named ============
function sCarvings({ makeStage, start: ST }) {
  const scene = plateau(makeStage, { sunDir: [-0.9, 0.25, 0.35] });
  const kinds = [['fox', 256, 420, 1.3], ['boar', 256, 430, 1.25], ['snake', 256, 520, 1.6], ['vulture', 256, 380, 1.4]];
  const ps = kinds.map((kd, i) => { const p = tPillar({ h: 3.4, kinds: [kd], seed: 200 + i }); p.position.set(i * 1.6, 0, 0); scene.add(p); return p; });
  const words = ['foxes', 'boars', 'snakes', 'vultures'].map(w => at(4, w) - ST);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const x = kf(t, [[0, -0.2], [words[0] + 0.2, 0], [words[1] + 0.1, 1.6], [words[2] + 0.1, 3.2], [words[3] + 0.2, 4.8], [6, 4.9]], easeInOut);
      ps.forEach((p, i) => { p.face.emissive = p.face.emissive || new THREE.Color(); p.face.emissive.setRGB(0.25, 0.18, 0.08); p.face.emissiveIntensity = 0.8 * Math.sin(Math.PI * clamp((t - words[i] + 0.15) / 0.9)); });
      const pos = [x, 1.45, 1.9], look = [x, 1.35, 0];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.2, dof: dofTo(pos, look, 0.004, 0.008) };
    },
  };
}
// ============ S5: the central pillar's carved arms and hands ============
function sArms({ makeStage, start: ST }) {
  const tH = at(5, 'hands') - ST;
  const scene = plateau(makeStage, { sunDir: [-0.7, 0.3, 0.65] });
  const p = tPillar({ h: 5.5, w: 1.2, d: 0.4, head: 1.9, headH: 1.0, kinds: [['arms', 256, 560, 1.0], ['fox', 256, 820, 0.9]], seed: 23 }); scene.add(p);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const y = kf(t, [[0, 4.2], [tH - 0.3, 3.0], [tH + 0.6, 2.2], [3.4, 2.4]], easeInOut);
      const z = kf(t, [[0, 4.4], [tH, 5.0], [3.4, 7.5]], easeInOut);
      place(c, [0.5, y, z], [0, lerp(y, 2.6, range(t, tH + 0.6, 3.4)), 0]);
      return { bloom: 0.5, warm: 1.25 };
    },
  };
}
// ============ S6: the builders' camp: hide tents, a fire, flint, no pots ============
function sCamp({ makeStage, start: ST }) {
  const scene = plateau(makeStage, { sunDir: [0.5, 0.25, -0.83] });
  [[-3, -2], [2.5, -3.5], [-0.5, -6]].forEach(([x, z]) => { const tn = hideTent(); tn.position.set(x, 0, z); scene.add(tn); });
  const A = archMats();
  for (let i = 0; i < 6; i++) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.8, 8), A.wood); l.rotation.set(Math.PI / 2, i * 0.55, 0.2); l.position.y = 0.08; scene.add(shadowAll(l)); }
  const flames = [...Array(10)].map((_, i) => { const s = glowSprite(i % 2 ? 0xff7a2a : 0xffc04a, 0.35); scene.add(s); return { s, i }; });
  const fl = new THREE.PointLight(0xff8a3a, 3, 6, 2); fl.position.set(0, 0.6, 0); scene.add(fl);
  const ppl = [0, 1, 2, 3].map(i => { const m = hunter(i); const a = i / 4 * 6.28 + 0.4; m.root.position.set(Math.cos(a) * 1.4, 0, Math.sin(a) * 1.4); m.root.rotation.y = -a - Math.PI / 2; scene.add(m.root); return m; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      flames.forEach(({ s, i }) => { s.position.set(Math.sin(i * 2.3) * 0.2, 0.15 + ((t * 1.3 + i / 10) % 1) * 0.6, Math.cos(i * 1.7) * 0.15); s.scale.setScalar(0.25 + 0.12 * Math.sin(t * 9 + i)); });
      fl.intensity = 2.6 + 0.5 * Math.sin(t * 11);
      ppl.forEach((m, i) => { standPose(m, t + i, { head: [0.2, 0, 0], lSh: [-0.5, 0, 0.3], lEl: [-0.8, 0, 0], rSh: [-0.5, 0, -0.3], rEl: [-0.8, 0, 0] }); m.setMood('happy'); m.setMouth(i === 1 ? 0.4 * Math.max(0, Math.sin(t * 8)) : 0); m.blink(blinkK(t, [0.8 + i])); });
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(3.6, 2.8, k), lerp(1.9, 1.6, k), lerp(3.8, 3.0, k)], [0, 0.8, 0]);
      return { bloom: 0.7, flare: 0.9, warm: 1.35 };
    },
  };
}
// ============ S7: flint carving close-up, then a pillar dragged on log rollers ============
function sFlint({ makeStage, start: ST }) {
  const tM = at(7, 'moved') - ST;
  const scene = plateau(makeStage, { sunDir: [-0.5, 0.4, 0.77] });
  const p = tPillar({ h: 3.4, kinds: [['boar', 256, 430, 1.25]], seed: 301 }); p.rotation.x = -Math.PI / 2; p.position.set(0, 0.18, 0); scene.add(p);
  const logs = [0, 1, 2, 3].map(i => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 1.6, 10), archMats().wood); l.rotation.z = Math.PI / 2; l.position.set(0, 0.0, -0.4 - i * 0.9); scene.add(shadowAll(l)); return l; });
  const carver = hunter(2); carver.root.position.set(0.95, 0, -1.3); carver.root.rotation.y = -Math.PI / 2; scene.add(carver.root);
  const flint = new THREE.Mesh(new THREE.TetrahedronGeometry(0.06, 0), new THREE.MeshStandardMaterial({ color: 0x4a4440, roughness: 0.4 })); scene.add(flint);
  const pullers = [0, 1, 2, 3].map(i => { const m = hunter(i); m.root.position.set(-0.5 + (i % 2), 0, -5 - Math.floor(i / 2) * 0.9); m.root.rotation.y = Math.PI; scene.add(m.root); return m; });
  const ropes = pullers.map(() => { const r = ropeMesh(); scene.add(r); return r; });
  const chipsS = [...Array(10)].map((_, i) => { const s = glowSprite(0xe8dcc0, 0.02); scene.add(s); return { s, i }; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const drag = easeInOut(range(t, tM - 0.2, tM + 2.5)) * 1.4;
      p.position.z = -drag; logs.forEach((l, i) => { l.rotation.x = drag / 0.12; });
      standPose(carver, t, { spine: [0.6, 0, 0], chest: [0.2, 0, 0], head: [0.3, 0, 0], lKn: [0.5, 0, 0], rKn: [0.5, 0, 0], drop: -0.15 }); carver.setMood('happy'); carver.grip(0.9, 0.9);
      carver.root.updateMatrixWorld(true);
      const hit = Math.abs(Math.sin(t * 7));
      const fp = V(0.35, 0.42 + hit * 0.08, -1.3 - drag); flint.position.copy(fp);
      ikArm(carver, 'r', fp, wpos(carver.root, V(-0.6, 0.3, 0.2)), V(0, 1, 0));
      ikArm(carver, 'l', V(0.3, 0.38, -1.15 - drag), wpos(carver.root, V(0.6, 0.3, 0.2)), V(0, 1, 0));
      chipsS.forEach(({ s, i }) => { const a = ((t * 2 + i / 10) % 1); s.position.set(fp.x + Math.sin(i * 2) * a * 0.2, 0.38 + a * 0.2 - a * a * 0.3, fp.z + Math.cos(i * 3) * a * 0.2); s.material.opacity = 1 - a; });
      p.updateMatrixWorld(true); const front = p.localToWorld(V(0, 3.3, 0));
      pullers.forEach((m, i) => { standPose(m, t + i, { spine: [-0.2, 0, 0], lHip: [0.35, 0, 0.07], rHip: [-0.2, 0, -0.07], lKn: [0.3, 0, 0] }); m.setMood('happy'); m.setMouth(0.3); m.grip(0.95, 0.95); m.root.position.z = -5 - Math.floor(i / 2) * 0.9 - drag; m.root.updateMatrixWorld(true); const h = wpos(m.root, V(0, 1.05, 0.35)); setRope(ropes[i], front, h); ikArm(m, 'l', h.clone().add(V(0.06, 0, 0)), wpos(m.root, V(0.7, 0.2, 0)), V(0, 1, 0)); ikArm(m, 'r', h.clone().add(V(-0.06, -0.05, 0.05)), wpos(m.root, V(-0.7, 0.2, 0)), V(0, 1, 0)); });
      const k = easeInOut(range(t, tM - 0.6, tM + 0.6));
      const pos = [lerp(2.6, 4.5, k), lerp(1.7, 3.0, k), lerp(0.6, 1.5, k)], look = [lerp(0.4, 0, k), lerp(0.5, 0.8, k), lerp(-1.4, -3.5, k)];
      place(c, pos, look);
      return { bloom: 0.55, warm: 1.25, dof: k < 0.5 ? dofTo(pos, look, 0.004, 0.008) : undefined };
    },
  };
}
// ============ S8: the ring fills with rubble and earth, grass grows over ============
function sBuried({ makeStage, start: ST }) {
  const tB = at(8, 'buried') - ST, tH = at(8, 'hidden') - ST;
  const scene = plateau(makeStage, { sunDir: [-0.55, 0.45, 0.7] });
  const [e1] = site(scene);
  const fill = new THREE.Mesh(new THREE.CylinderGeometry(8.6, 9.5, 1, 48), new THREE.MeshStandardMaterial({ color: 0x9a8458, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 8 })); fill.receiveShadow = fill.castShadow = true; scene.add(fill);
  const mound = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 16, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x8a8a4a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 6 })); mound.receiveShadow = true; scene.add(mound);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const h = 6.2 * easeInOut(range(t, tB - 0.4, tH));
      fill.scale.y = Math.max(0.001, h); fill.position.y = h / 2;
      const g = easeInOut(range(t, tH - 0.4, tH + 1.4));
      mound.visible = g > 0.01; mound.scale.set(18 * (0.6 + 0.4 * g), 7 * g, 18 * (0.6 + 0.4 * g)); mound.position.y = 0;
      const k = easeInOut(range(t, 0, 5.6));
      const a = lerp(0.2, 0.9, k);
      place(c, [Math.sin(a) * 26, lerp(14, 12, k), Math.cos(a) * 26], [0, lerp(2, 3, k), 0]);
      return { bloom: 0.5, warm: lerp(1.2, 1.0, k) };
    },
  };
}
// ============ S9: wild wheat in the foreground, the rings at sunset ============
function sEnd({ makeStage }) {
  const scene = plateau(makeStage, { sunDir: [0.4, 0.15, -0.9] });
  site(scene);
  const ww = wildWheat(1600, { area: 14, seed: 7 }); ww.position.set(4, 0, 14); scene.add(ww);
  const ppl = [0, 1].map(i => { const m = hunter(i); m.root.position.set(3 + i * 1.2, 0, 11); m.root.rotation.y = Math.PI + 0.3; scene.add(m.root); return m; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      ww.rotation.z = Math.sin(t * 1.2) * 0.005;
      ppl.forEach((m, i) => { standPose(m, t + i, { head: [0.1, 0, 0] }); m.setMood('happy'); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(5.5, 7, k), lerp(1.2, 3.5, k), lerp(19, 24, k)], [lerp(3, 0, k), lerp(1.4, 2.0, k), lerp(8, 0, k)]);
      return { bloom: 0.75, flare: 1.3, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sAerial, 'aerial'],
  [ls(2), ls(3), sRaise, 'raise'],
  [ls(3), ls(4), sScale, 'scale'],
  [ls(4), ls(5), sCarvings, 'carvings'],
  [ls(5), ls(6), sArms, 'arms'],
  [ls(6), ls(7), sCamp, 'camp'],
  [ls(7), ls(8), sFlint, 'flint'],
  [ls(8), ls(9), sBuried, 'buried'],
  [ls(9), DURATION + 1, sEnd, 'end'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
