// Göbekli Tepe reel: T-shaped limestone pillars with animal reliefs, stone-ring enclosures, hunter-gatherers.
import * as THREE from 'three';
import { fabricTexture } from './textures.js';
import { shadowAll, canvasTex, romanBuilder } from './rome.js';

const rng = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;

// relief texture for one pillar face: base limestone noise + raised animal silhouettes (used as colour + bump)
const RELIEF = {};
function drawAnimal(x, kind, cx, cy, s) {
  x.save(); x.translate(cx, cy); x.scale(s, s);
  x.lineCap = 'round'; x.lineJoin = 'round';
  if (kind === 'fox') { x.beginPath(); x.ellipse(0, 0, 60, 22, 0, 0, 7); x.fill(); x.beginPath(); x.moveTo(50, -10); x.lineTo(95, -5); x.lineTo(70, 18); x.fill(); x.beginPath(); x.moveTo(60, -14); x.lineTo(68, -40); x.lineTo(76, -12); x.fill(); x.lineWidth = 14; x.beginPath(); x.moveTo(-55, 0); x.quadraticCurveTo(-95, -10, -110, 25); x.stroke(); for (const lx of [-35, 35]) { x.lineWidth = 9; x.beginPath(); x.moveTo(lx, 15); x.lineTo(lx + 4, 55); x.stroke(); } }
  if (kind === 'boar') { x.beginPath(); x.ellipse(0, 0, 70, 38, 0, 0, 7); x.fill(); x.beginPath(); x.moveTo(55, -20); x.lineTo(110, 5); x.lineTo(55, 30); x.fill(); x.lineWidth = 6; x.beginPath(); x.moveTo(95, 10); x.quadraticCurveTo(105, -15, 92, -22); x.stroke(); for (const lx of [-40, -15, 20, 45]) { x.lineWidth = 11; x.beginPath(); x.moveTo(lx, 25); x.lineTo(lx, 62); x.stroke(); } for (let i = -50; i < 50; i += 12) { x.lineWidth = 5; x.beginPath(); x.moveTo(i, -36); x.lineTo(i + 4, -50); x.stroke(); } }
  if (kind === 'snake') { x.lineWidth = 16; x.beginPath(); x.moveTo(0, -150); for (let i = 0; i <= 12; i++) x.lineTo(Math.sin(i * 1.3) * 30, -150 + i * 25); x.stroke(); x.beginPath(); x.ellipse(0, -160, 14, 20, 0, 0, 7); x.fill(); }
  if (kind === 'vulture') { x.beginPath(); x.ellipse(0, 0, 22, 45, 0, 0, 7); x.fill(); x.beginPath(); x.arc(0, -55, 15, 0, 7); x.fill(); x.beginPath(); x.moveTo(-15, -20); x.lineTo(-120, -45); x.lineTo(-110, -20); x.lineTo(-20, 15); x.fill(); x.beginPath(); x.moveTo(15, -20); x.lineTo(120, -45); x.lineTo(110, -20); x.lineTo(20, 15); x.fill(); x.lineWidth = 6; for (let k = -1; k <= 1; k++) { x.beginPath(); x.moveTo(k * 8, 40); x.lineTo(k * 14, 70); x.stroke(); } }
  if (kind === 'arms') { x.lineWidth = 34; x.beginPath(); x.moveTo(-180, -420); x.quadraticCurveTo(-200, 0, -40, 120); x.stroke(); x.beginPath(); x.moveTo(180, -420); x.quadraticCurveTo(200, 0, 40, 120); x.stroke(); x.lineWidth = 12; for (let k = 0; k < 5; k++) { x.beginPath(); x.moveTo(-40 + k * 4, 120 - k * 6); x.lineTo(-5, 135 - k * 10); x.stroke(); x.beginPath(); x.moveTo(40 - k * 4, 120 - k * 6); x.lineTo(5, 135 - k * 10); x.stroke(); } x.fillRect(-170, 190, 340, 40); for (let i = 0; i < 4; i++) { x.beginPath(); x.moveTo(-30 + i * 20, 230); x.lineTo(-40 + i * 20, 330); x.lineTo(-20 + i * 20, 330); x.fill(); } }
  x.restore();
}
export function reliefTex(kinds = [], seed = 1) {
  const key = kinds.join(',') + seed; if (RELIEF[key]) return RELIEF[key];
  const make = (bump) => canvasTex(512, 1024, (x) => {
    const R = rng(seed);
    x.fillStyle = bump ? '#303030' : '#cfc0a0'; x.fillRect(0, 0, 512, 1024);
    for (let i = 0; i < 2500; i++) { const g = bump ? 40 + R() * 30 | 0 : 170 + R() * 50 | 0; x.fillStyle = bump ? `rgb(${g},${g},${g})` : `rgb(${g},${g - 10},${g - 30})`; x.fillRect(R() * 512, R() * 1024, 2 + R() * 6, 2 + R() * 6); }
    x.fillStyle = bump ? '#d8d8d8' : '#bcab88'; x.strokeStyle = x.fillStyle;
    kinds.forEach(([k, cx, cy, s]) => drawAnimal(x, k, cx, cy, s));
  });
  RELIEF[key] = { map: make(false), bump: make(true) };
  return RELIEF[key];
}
// T pillar: a slab (front face +z) with a wider head block on top
export function tPillar({ h = 3.6, w = 1.0, d = 0.35, head = 1.6, headH = 0.8, kinds = [], seed = 1 } = {}) {
  const g = new THREE.Group();
  const T = reliefTex(kinds, seed);
  const face = new THREE.MeshStandardMaterial({ map: T.map, bumpMap: T.bump, bumpScale: 6, roughness: 0.95 });
  const plain = new THREE.MeshStandardMaterial({ color: 0xcfc0a0, roughness: 1, bumpMap: fabricTexture(29), bumpScale: 3 });
  const shaft = new THREE.Mesh(new THREE.BoxGeometry(w, h - headH, d), [plain, plain, plain, plain, face, plain]); shaft.position.y = (h - headH) / 2; g.add(shaft);
  const hd = new THREE.Mesh(new THREE.BoxGeometry(head, headH, d * 1.1), plain); hd.position.set((head - w) / 2 * 0.6, h - headH / 2, 0); g.add(hd);
  g.traverse(o => { if (o.isMesh) { o.castShadow = o.receiveShadow = true; } });
  g.face = face;
  return g;
}
const ANIMALS = [['fox', 256, 420, 1.2], ['boar', 256, 420, 1.1], ['snake', 256, 520, 1.6], ['vulture', 256, 380, 1.3]];
// a ring enclosure: low drystone wall with pillars set in it, two tall central pillars facing each other
export function enclosure({ r = 7, n = 11, seed = 3, centralH = 5.5 } = {}) {
  const g = new THREE.Group(); const R = rng(seed);
  const wallM = new THREE.MeshStandardMaterial({ color: 0xb8a888, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 6 });
  const wall = new THREE.Mesh(new THREE.TorusGeometry(r + 0.6, 0.8, 8, 48), wallM); wall.rotation.x = Math.PI / 2; wall.scale.set(1, 1, 1.4); wall.position.y = 0.4; wall.receiveShadow = wall.castShadow = true; g.add(wall);
  g.ring = [];
  for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; const p = tPillar({ h: 3.2 + R() * 0.6, kinds: [ANIMALS[i % 4]], seed: seed * 10 + i }); p.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); p.rotation.y = -a - Math.PI / 2; g.add(p); g.ring.push(p); }
  g.central = [-1, 1].map((s) => { const p = tPillar({ h: centralH, w: 1.2, d: 0.4, head: 1.9, headH: 1.0, kinds: [['arms', 256, 560, 1.0], ['fox', 256, 820, 0.9]], seed: seed * 7 + (s > 0 ? 1 : 2) }); p.position.set(0, 0, s * 1.6); p.rotation.y = s > 0 ? 0 : Math.PI; g.add(p); return p; });
  return g;
}
export function hunter(i = 0) {
  const h = romanBuilder({ color: [0x7a5a3a, 0x8a6a44, 0x6a4a30, 0x9a7a54][i % 4], skin: [0xb88058, 0xa87048, 0xc89068, 0x986040][i % 4] });
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), new THREE.MeshStandardMaterial({ color: 0x2a1e16, roughness: 1 })); hair.position.set(0, 0.04, -0.02); hair.scale.set(1.08, 1, 1.1); h.j.head.add(hair);
  shadowAll(h.root);
  return h;
}
export function hideTent() {
  const g = new THREE.Group();
  const hide = new THREE.MeshStandardMaterial({ color: 0x9a7a54, roughness: 1, bumpMap: fabricTexture(15), bumpScale: 4, side: THREE.DoubleSide });
  const c = new THREE.Mesh(new THREE.ConeGeometry(1.4, 2.6, 9, 1, true), hide); c.position.y = 1.3; g.add(c);
  const wood = new THREE.MeshStandardMaterial({ color: 0x5a3a20 });
  for (let i = 0; i < 5; i++) { const a = i / 5 * 6.28; const p = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.0, 6), wood); p.position.set(Math.cos(a) * 0.15, 2.9, Math.sin(a) * 0.15); p.rotation.set(Math.sin(a) * 0.3, 0, -Math.cos(a) * 0.3); g.add(p); }
  return shadowAll(g);
}
export function wildWheat(n = 600, { area = 20, seed = 5 } = {}) {
  const R = rng(seed);
  const stem = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.006, 0.008, 0.9, 4), new THREE.MeshStandardMaterial({ color: 0xc8a850, roughness: 1 }), n);
  const ear = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.018, 0.08, 4, 6), new THREE.MeshStandardMaterial({ color: 0xd8b860, roughness: 1 }), n);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  for (let i = 0; i < n; i++) { const x = (R() - 0.5) * area, z = (R() - 0.5) * area; q.setFromEuler(new THREE.Euler((R() - 0.5) * 0.3, 0, (R() - 0.5) * 0.3)); m4.compose(new THREE.Vector3(x, 0.45, z), q, new THREE.Vector3(1, 1, 1)); stem.setMatrixAt(i, m4); m4.compose(new THREE.Vector3(x + (R() - 0.5) * 0.05, 0.95, z), q, new THREE.Vector3(1, 1, 1)); ear.setMatrixAt(i, m4); }
  const g = new THREE.Group(); g.add(stem, ear); return g;
}
