// The Explainer, DETAILED look (sample, 17 Nov): hummingbird with individual feathers (instanced coats on body/head,
// iridescent gorget, separate wing primaries/secondaries with shafts, fanned tail with white tips), glossy eye with the
// white post-ocular spot; salvia flower spikes with petals, calyx, stamens and veined leaves; garden detail helpers
// (grass blades, leafy bush, background flower bokeh). Same API as hummer.js: hummingbird(), flower(), songbird(), arrow().
import * as THREE from 'three';
import { rng } from './textures.js';
export { arrow } from './hummer.js';

// ---------- canvas textures ----------
function canvasTex(w, h, draw, srgb = true) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); if (srgb) t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
// a feather: vane gradient + rachis + barb lines, alpha edge (UV: u along length 0..1, v across 0..1)
function featherTex(base, tip, white = false) {
  return canvasTex(256, 64, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, 0); gr.addColorStop(0, base); gr.addColorStop(0.7, base); gr.addColorStop(1, white ? '#f4f4f0' : tip);
    g.fillStyle = gr; g.beginPath(); g.moveTo(0, h / 2); g.bezierCurveTo(w * 0.2, -h * 0.05, w * 0.85, h * 0.02, w, h / 2); g.bezierCurveTo(w * 0.85, h * 0.98, w * 0.2, h * 1.05, 0, h / 2); g.fill();
    g.globalCompositeOperation = 'source-atop'; g.strokeStyle = 'rgba(0,0,0,0.22)'; g.lineWidth = 1;
    for (let x = 6; x < w; x += 5) { g.beginPath(); g.moveTo(x, h / 2); g.lineTo(x + 14, 2); g.moveTo(x, h / 2); g.lineTo(x + 14, h - 2); g.stroke(); }
    g.strokeStyle = 'rgba(240,235,210,0.85)'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, h / 2); g.lineTo(w * 0.97, h / 2); g.stroke();
  });
}
function leafTex() {
  return canvasTex(256, 128, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#2f7a2a'); gr.addColorStop(0.5, '#4a9a38'); gr.addColorStop(1, '#2a6a26'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const R = rng(4); for (let i = 0; i < 400; i++) { g.fillStyle = `rgba(${20 + R() * 40},${60 + R() * 60},${20 + R() * 20},0.25)`; g.fillRect(R() * w, R() * h, 2, 2); }
    g.strokeStyle = 'rgba(200,230,150,0.75)'; g.lineWidth = 3; g.beginPath(); g.moveTo(0, h / 2); g.lineTo(w, h / 2); g.stroke();
    g.lineWidth = 1.4; g.strokeStyle = 'rgba(190,225,140,0.55)'; for (let x = 18; x < w - 10; x += 22) { g.beginPath(); g.moveTo(x, h / 2); g.quadraticCurveTo(x + 18, h * 0.3, x + 34, 6); g.moveTo(x, h / 2); g.quadraticCurveTo(x + 18, h * 0.7, x + 34, h - 6); g.stroke(); }
  });
}
function groundTex() {
  const t = canvasTex(512, 512, (g, w, h) => { g.fillStyle = '#4e7c30'; g.fillRect(0, 0, w, h); const R = rng(9); for (let i = 0; i < 9000; i++) { const l = R(); g.fillStyle = l < 0.5 ? `rgba(40,${70 + R() * 50},25,0.5)` : l < 0.85 ? `rgba(${90 + R() * 40},${120 + R() * 40},50,0.4)` : `rgba(${100 + R() * 40},80,50,0.5)`; g.fillRect(R() * w, R() * h, 1 + R() * 3, 1 + R() * 3); } });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(40, 40); return t;
}
const TEX = {};
const tex = (k, f) => TEX[k] || (TEX[k] = f());

// ---------- feather coat on an ellipsoid ----------
// center c, radii r=[rx,ry,rz]; colorAt(p unit-sphere point) -> THREE.Color or null (skip)
function featherCoat({ c, r, n = 220, size = 0.0032, colorAt, irid = 1, seed = 2, lift = 0.25 }) {
  const R = rng(seed); const geo = new THREE.SphereGeometry(1, 10, 6); geo.translate(0.75, 0, 0); geo.scale(1, 0.18, 0.62);
  const mat = new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.32, metalness: 0.25, iridescence: irid, iridescenceIOR: 1.7, clearcoat: 0.5, clearcoatRoughness: 0.3 });
  const im = new THREE.InstancedMesh(geo, mat, n); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), basis = new THREE.Matrix4();
  const g = Math.PI * (3 - Math.sqrt(5)); let k = 0;
  for (let i = 0; i < n; i++) {
    const y = 1 - (i + 0.5) / n * 2, rr = Math.sqrt(1 - y * y), a = i * g; const p = new THREE.Vector3(Math.cos(a) * rr, y, Math.sin(a) * rr);
    const col = colorAt(p, R); if (!col) continue;
    const pos = new THREE.Vector3(p.x * r[0], p.y * r[1], p.z * r[2]).add(c);
    const nrm = new THREE.Vector3(p.x / r[0], p.y / r[1], p.z / r[2]).normalize();
    let d = new THREE.Vector3(-0.35, -1, 0); d.addScaledVector(nrm, -d.dot(nrm)); if (d.lengthSq() < 1e-6) d.set(1, 0, 0); d.normalize();
    d.addScaledVector(nrm, lift).normalize(); const z = new THREE.Vector3().crossVectors(d, nrm).normalize(); const yv = new THREE.Vector3().crossVectors(z, d);
    basis.makeBasis(d, yv, z); q.setFromRotationMatrix(basis); const sz = size * (0.8 + R() * 0.45);
    M.compose(pos.addScaledVector(nrm, size * 0.08), q, s.set(sz, sz, sz)); im.setMatrixAt(k, M); im.setColorAt(k, col); k++;
  }
  im.count = k; im.castShadow = true; return im;
}
// ---------- a separate flight feather (UV-mapped plane, two-sided tint) ----------
function featherGeo(len, wid) { const g = new THREE.PlaneGeometry(len, wid, 8, 1); g.translate(len / 2, 0, 0); return g; }
function wingMesh() {
  const g = new THREE.Group();
  const topT = tex('wtop', () => featherTex('#34603e', '#1e2a22')), botT = tex('wbot', () => featherTex('#b8c4b2', '#6a7468'));
  const top = new THREE.MeshStandardMaterial({ map: topT, transparent: true, alphaTest: 0.35, roughness: 0.55, side: THREE.FrontSide });
  const bot = new THREE.MeshStandardMaterial({ map: botT, transparent: true, alphaTest: 0.35, roughness: 0.6, side: THREE.BackSide });
  // primaries (long, toward the tip) + secondaries (shorter, near the body); span along +z, chord along x, normal +y
  const F = [];
  for (let i = 0; i < 10; i++) { const u = i / 9; F.push({ z: 0.006 + u * 0.026, len: 0.022 + u * 0.03, wid: 0.007 - u * 0.0015, ang: -1.25 + u * 0.95, x: -0.002 - u * 0.002, y: 0.0002 * i }); }
  for (let i = 0; i < 6; i++) { const u = i / 5; F.push({ z: 0.001 + u * 0.008, len: 0.016 + u * 0.004, wid: 0.0065, ang: -2.2 + u * 0.6, x: 0.0, y: -0.0003 - 0.0001 * i }); }
  F.forEach(f => { const geo = featherGeo(f.len, f.wid); geo.rotateX(-Math.PI / 2); [top, bot].forEach(m => { const mesh = new THREE.Mesh(geo, m); mesh.position.set(f.x, f.y, f.z); mesh.rotation.y = f.ang; mesh.castShadow = true; g.add(mesh); }); });
  // coverts: small overlapping feathers along the leading edge
  const cov = featherCoat({ c: new THREE.Vector3(0.002, 0.0012, 0.012), r: [0.006, 0.0012, 0.012], n: 70, size: 0.0028, colorAt: (p, R) => p.y > 0 ? new THREE.Color().setHSL(0.36 + R() * 0.04, 0.55, 0.3 + R() * 0.08) : null, seed: 5, lift: 0.1 });
  g.add(cov);
  return g;
}
export function hummingbird() {
  const G = new THREE.Group(); const body = new THREE.Group(); G.add(body);
  const under = new THREE.MeshStandardMaterial({ color: 0x3c6a40, roughness: 0.7 });
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.0135, 28, 18), under); torso.scale.set(1, 1.6, 1); torso.position.set(0.004, -0.012, 0); body.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.009, 24, 16), under); head.position.set(0.006, 0.013, 0); body.add(head);
  const green = (R) => new THREE.Color().setHSL(0.34 + R() * 0.08, 0.7 + R() * 0.2, 0.2 + R() * 0.1);
  body.add(featherCoat({ c: new THREE.Vector3(0.004, -0.012, 0), r: [0.0142, 0.0225, 0.0142], n: 1100, size: 0.0027, seed: 3, lift: 0.12,
    colorAt: (p, R) => (p.x > 0.35 && p.y < 0.55) ? new THREE.Color().setHSL(0.1, 0.06, 0.72 + R() * 0.12) : (p.y < -0.75 ? new THREE.Color().setHSL(0.1, 0.4, 0.22 + R() * 0.08) : green(R)) }));
  body.add(featherCoat({ c: new THREE.Vector3(0.006, 0.013, 0), r: [0.0097, 0.0097, 0.0097], n: 600, size: 0.0017, seed: 4, lift: 0.08,
    colorAt: (p, R) => (p.x > 0.15 && p.y < 0.15) ? new THREE.Color().setHSL(0.97 + R() * 0.03, 0.9, 0.36 + R() * 0.14) : green(R) }));
  // beak: tapered, slightly down-curved
  const bpts = []; for (let i = 0; i <= 12; i++) { const u = i / 12; bpts.push(new THREE.Vector3(u * 0.03, -0.002 * u * u, 0)); }
  const beak = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(bpts), 24, 0.0012, 10), new THREE.MeshPhysicalMaterial({ color: 0x141414, roughness: 0.25, clearcoat: 0.6 }));
  beak.geometry.computeBoundingBox(); const pos = beak.geometry.attributes.position; for (let i = 0; i < pos.count; i++) { const x = pos.getX(i); const t = 1 - 0.75 * (x / 0.03); const cy = -0.002 * (x / 0.03) ** 2; pos.setY(i, cy + (pos.getY(i) - cy) * t); pos.setZ(i, pos.getZ(i) * t); } pos.needsUpdate = true; beak.geometry.computeVertexNormals();
  beak.rotation.z = 0.25; beak.position.set(0.0135, 0.0135, 0); body.add(beak);
  [-1, 1].forEach((s) => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.0021, 16, 12), new THREE.MeshPhysicalMaterial({ color: 0x050505, roughness: 0.05, clearcoat: 1 })); e.position.set(0.0105, 0.0158, s * 0.0074); body.add(e);
    const hl = new THREE.Mesh(new THREE.SphereGeometry(0.00045, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff })); hl.position.set(0.0118, 0.0168, s * 0.0091); body.add(hl);
    const spot = new THREE.Mesh(new THREE.SphereGeometry(0.0011, 10, 8), new THREE.MeshStandardMaterial({ color: 0xf4f4f0, roughness: 0.6 })); spot.scale.set(1, 0.6, 0.4); spot.position.set(0.0068, 0.0156, s * 0.0089); body.add(spot);
  });
  // tail: fanned feathers with white tips
  const tT = tex('tail', () => featherTex('#2e4a34', '#141a16', true)); const tm = new THREE.MeshStandardMaterial({ map: tT, transparent: true, alphaTest: 0.35, roughness: 0.55, side: THREE.DoubleSide });
  for (let i = 0; i < 6; i++) { const geo = featherGeo(0.022, 0.0055); const m = new THREE.Mesh(geo, tm); m.rotation.set(0, 0, -Math.PI / 2 - 0.12); m.rotation.x = (i - 2.5) * 0.18; m.position.set(-0.001, -0.03, (i - 2.5) * 0.0012); body.add(m); }
  // tiny tucked feet
  [-1, 1].forEach(s => { const f = new THREE.Mesh(new THREE.CapsuleGeometry(0.0006, 0.003, 4, 6), new THREE.MeshStandardMaterial({ color: 0x2a2420 })); f.position.set(0.006, -0.03, s * 0.003); f.rotation.z = 1.0; body.add(f); });
  body.rotation.z = -0.65;
  const heart = new THREE.Mesh(new THREE.SphereGeometry(0.0045, 16, 12), new THREE.MeshStandardMaterial({ color: 0xff2a3a, emissive: 0xff1020, emissiveIntensity: 1.2, transparent: true, depthTest: false })); heart.renderOrder = 20; heart.position.set(0.006, -0.004, 0); body.add(heart); heart.visible = false;
  const wings = [-1, 1].map((s) => { const sh = new THREE.Group(); sh.position.set(0.0, 0.004, s * 0.006); G.add(sh); const w = wingMesh(); if (s < 0) w.scale.z = -1; sh.add(w); return { sh, w, s }; });
  // motion-blur fan: soft radial gradient instead of a flat disc
  const fanT = tex('fan', () => canvasTex(256, 256, (g, w, h) => { const gr = g.createRadialGradient(w / 2, h / 2, w * 0.05, w / 2, h / 2, w / 2); gr.addColorStop(0, 'rgba(60,100,70,0.0)'); gr.addColorStop(0.25, 'rgba(70,110,80,0.55)'); gr.addColorStop(0.85, 'rgba(150,180,160,0.35)'); gr.addColorStop(1, 'rgba(200,220,210,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); }));
  const fanM = new THREE.MeshBasicMaterial({ map: fanT, transparent: true, opacity: 0.0, side: THREE.DoubleSide, depthWrite: false });
  [-1, 1].forEach((s) => { const f = new THREE.Mesh(new THREE.CircleGeometry(0.06, 48, -1.1, 2.2), fanM); f.rotation.x = -Math.PI / 2; f.position.set(0, 0.004, s * 0.006); G.add(f); f.rotation.z = s > 0 ? 0 : Math.PI; });
  const tip = new THREE.Object3D(); tip.position.set(-0.0, 0, 0.058); wings[1].w.add(tip);
  const st = { phase: 0, blur: 0, heart: 0, beat: 0 };
  function update() {
    const p = st.phase * Math.PI * 2;
    const sweep = 1.05 * Math.cos(p);
    const flipS = THREE.MathUtils.lerp(0, Math.PI * 0.9, 0.5 - 0.5 * Math.tanh(Math.sin(p) * 6));
    const elev = 0.18 * Math.sin(2 * p);
    wings.forEach(({ sh, w, s }) => { sh.rotation.set(0, 0, 0); sh.rotateY(-s * sweep); sh.rotateX(s * elev); w.rotation.set(0, 0, s * flipS); });
    wings.forEach(({ w }) => { w.visible = st.blur < 0.6; });
    fanM.opacity = 0.9 * st.blur;
    heart.visible = st.heart > 0.01; heart.scale.setScalar(1 + 0.35 * st.beat); heart.material.emissiveIntensity = 0.8 + 1.5 * st.beat;
  }
  update();
  return { group: G, body, st, update, tip, wings };
}
// ---------- salvia-like flower spike; the top blossom's mouth sits at the group origin (same as hummer.js) ----------
function blossom(R) {
  const g = new THREE.Group(); const red = new THREE.MeshPhysicalMaterial({ color: 0xd8202a, roughness: 0.45, sheen: 1, sheenColor: new THREE.Color(0xff8080), side: THREE.DoubleSide });
  const prof = []; for (let k = 0; k <= 20; k++) { const s = k / 20; prof.push(new THREE.Vector2(0.0035 + 0.006 * Math.pow(s, 4) + 0.0015 * s, s * 0.045)); }
  const tube = new THREE.Mesh(new THREE.LatheGeometry(prof, 28), red); g.add(tube);
  // upper hood + lower lip petals at the mouth
  const hood = new THREE.Mesh(new THREE.SphereGeometry(0.0055, 20, 12, 0, Math.PI * 2, 0, Math.PI * 0.45), red); hood.scale.set(0.8, 1.3, 1.2); hood.position.set(0.004, 0.046, 0); hood.rotation.z = -0.9; g.add(hood);
  const lip = new THREE.Mesh(new THREE.SphereGeometry(0.005, 20, 12, 0, Math.PI * 2, 0, Math.PI * 0.4), red); lip.scale.set(0.9, 0.6, 1.4); lip.position.set(-0.004, 0.045, 0); lip.rotation.z = 1.4; g.add(lip);
  const stm = new THREE.MeshStandardMaterial({ color: 0xffe060, emissive: 0x403000, roughness: 0.5 });
  [-1, 1].forEach(s => { const f = new THREE.Mesh(new THREE.CylinderGeometry(0.0003, 0.0003, 0.012, 5), new THREE.MeshStandardMaterial({ color: 0xd84050 })); f.position.set(0.003, 0.05, s * 0.0012); f.rotation.z = -0.5; g.add(f); const a = new THREE.Mesh(new THREE.SphereGeometry(0.0009, 8, 6), stm); a.position.set(0.006, 0.055, s * 0.0012); g.add(a); });
  const calyx = new THREE.Mesh(new THREE.ConeGeometry(0.0055, 0.014, 10, 1, true), new THREE.MeshStandardMaterial({ color: 0x8a1a3a, roughness: 0.6, side: THREE.DoubleSide })); calyx.rotation.z = Math.PI; calyx.position.y = 0.006; g.add(calyx);
  return g;
}
function leaf(len = 0.07) { const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.bezierCurveTo(len * 0.25, len * 0.22, len * 0.7, len * 0.2, len, 0); sh.bezierCurveTo(len * 0.7, -len * 0.2, len * 0.25, -len * 0.22, 0, 0); const geo = new THREE.ShapeGeometry(sh, 16); const uv = geo.attributes.uv, p = geo.attributes.position; for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / len, 0.5 + p.getY(i) / (len * 0.5)); const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: tex('leaf', leafTex), roughness: 0.6, side: THREE.DoubleSide })); m.castShadow = true; return m; }
export function flower(seed = 1) {
  const g = new THREE.Group(); const R = rng(seed);
  const top = blossom(R); top.rotation.z = Math.PI / 2 + 0.35; top.position.set(0.0, 0, 0); g.add(top);
  // move so the top blossom's mouth (tube end) lands on the origin
  top.updateMatrixWorld(true); const mouth = new THREE.Vector3(0, 0.045, 0).applyMatrix4(top.matrix); top.position.sub(mouth);
  const stemM = new THREE.MeshStandardMaterial({ color: 0x3f7f30, roughness: 0.7 });
  const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.0022, 0.0032, 0.5, 8), stemM); stem.position.set(0.035, -0.25, 0); g.add(stem);
  for (let i = 0; i < 7; i++) { const b = blossom(R); const y = -0.03 - i * 0.022; b.position.set(0.035, y, 0); b.rotation.set(R() * 0.3, i * 2.1, (i % 2 ? 1 : -1) * (0.9 + R() * 0.3)); b.scale.setScalar(0.8 - i * 0.05); g.add(b); }
  for (let i = 0; i < 4; i++) { const l = leaf(0.06 + R() * 0.03); l.position.set(0.035, -0.2 - i * 0.06, 0); l.rotation.set(0.4, i * 1.9, (i % 2 ? 0.5 : -0.5) + Math.PI * (i % 2)); g.add(l); }
  return g;
}
// ---------- garden detail ----------
export function grass(n = 5000, rMin = 0.15, rMax = 3.5, seed = 6) {
  const R = rng(seed); const geo = new THREE.PlaneGeometry(0.006, 0.12, 1, 4); geo.translate(0, 0.06, 0); const p = geo.attributes.position; for (let i = 0; i < p.count; i++) { const y = p.getY(i) / 0.12; p.setX(i, p.getX(i) * (1 - y)); p.setZ(i, 0.02 * y * y); } geo.computeVertexNormals();
  const im = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8, side: THREE.DoubleSide }), n); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), c = new THREE.Color();
  for (let i = 0; i < n; i++) { const a = R() * Math.PI * 2, r = rMin + Math.sqrt(R()) * (rMax - rMin); e.set((R() - 0.5) * 0.5, R() * Math.PI, (R() - 0.5) * 0.5); q.setFromEuler(e); const h = 0.6 + R() * 1.3; M.compose(new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r), q, s.set(1 + R(), h, 1)); im.setMatrixAt(i, M); im.setColorAt(i, c.setHSL(0.22 + R() * 0.08, 0.5 + R() * 0.2, 0.25 + R() * 0.15)); }
  im.receiveShadow = true; return im;
}
export function bush(seed = 3, n = 380, r = 0.35) {
  const R = rng(seed); const sh = new THREE.Shape(); const L = 0.05; sh.moveTo(0, 0); sh.bezierCurveTo(L * 0.25, L * 0.22, L * 0.7, L * 0.2, L, 0); sh.bezierCurveTo(L * 0.7, -L * 0.2, L * 0.25, -L * 0.22, 0, 0);
  const geo = new THREE.ShapeGeometry(sh, 8); const uv = geo.attributes.uv, p = geo.attributes.position; for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / L, 0.5 + p.getY(i) / (L * 0.5));
  const im = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ map: tex('leaf', leafTex), roughness: 0.6, side: THREE.DoubleSide }), n); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), c = new THREE.Color();
  for (let i = 0; i < n; i++) { const v = new THREE.Vector3(R() - 0.5, R() * 0.8, R() - 0.5).normalize().multiplyScalar(r * (0.6 + R() * 0.4)); e.set(R() * 6, R() * 6, R() * 6); q.setFromEuler(e); M.compose(v, q, s.setScalar(0.8 + R() * 0.7)); im.setMatrixAt(i, M); im.setColorAt(i, c.setHSL(0.27 + R() * 0.06, 0.45, 0.5 + R() * 0.3)); }
  im.castShadow = true; return im;
}
// colourful blossoms far behind (they blur into bokeh with depth of field)
export function bokehFlowers(n = 300, seed = 8) {
  const R = rng(seed); const im = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6, emissive: 0x111111 }), n); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), s = new THREE.Vector3(), c = new THREE.Color();
  const hues = [0.0, 0.08, 0.13, 0.85, 0.95, 0.75];
  for (let i = 0; i < n; i++) { const a = -2.6 + R() * 2.2, r = 2.5 + R() * 4.5; M.compose(new THREE.Vector3(Math.cos(a) * r, 0.05 + R() * 0.45, Math.sin(a) * r), q, s.setScalar(0.012 + R() * 0.02)); im.setMatrixAt(i, M); im.setColorAt(i, c.setHSL(hues[i % hues.length], 0.8, 0.55)); }
  return im;
}
export function groundMat() { return new THREE.MeshStandardMaterial({ map: groundTex(), roughness: 1 }); }
// songbird with a feather coat (for the comparison shot)
export function songbird() {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0x7a5a3c, roughness: 0.7 });
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.04, 20, 14), m); b.scale.set(1.8, 1, 1); g.add(b);
  const brown = (p, R) => p.y < -0.3 && p.x > -0.3 ? new THREE.Color().setHSL(0.09, 0.35, 0.72 + R() * 0.1) : new THREE.Color().setHSL(0.07 + R() * 0.03, 0.45, 0.3 + R() * 0.12);
  g.add(featherCoat({ c: new THREE.Vector3(), r: [0.073, 0.041, 0.041], n: 420, size: 0.011, colorAt: brown, irid: 0, seed: 11, lift: 0.2 }));
  const h = new THREE.Mesh(new THREE.SphereGeometry(0.026, 16, 12), m); h.position.set(0.07, 0.02, 0); g.add(h);
  g.add(featherCoat({ c: new THREE.Vector3(0.07, 0.02, 0), r: [0.027, 0.027, 0.027], n: 180, size: 0.007, colorAt: brown, irid: 0, seed: 12 }));
  const bk = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.025, 10), new THREE.MeshStandardMaterial({ color: 0xe0a030, roughness: 0.4 })); bk.rotation.z = -Math.PI / 2; bk.position.set(0.1, 0.02, 0); g.add(bk);
  [-1, 1].forEach(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.004, 12, 8), new THREE.MeshPhysicalMaterial({ color: 0x050505, clearcoat: 1, roughness: 0.05 })); e.position.set(0.088, 0.03, s * 0.02); g.add(e); });
  const wT = tex('swing', () => featherTex('#6a4a30', '#2a1a10')); const wm = new THREE.MeshStandardMaterial({ map: wT, transparent: true, alphaTest: 0.35, roughness: 0.6, side: THREE.DoubleSide });
  const wings = [-1, 1].map((s) => { const p = new THREE.Group(); p.position.set(0, 0.02, s * 0.03); g.add(p); for (let i = 0; i < 8; i++) { const geo = featherGeo(0.11 - i * 0.004, 0.022); geo.rotateX(-Math.PI / 2); geo.rotateY(-Math.PI / 2); const f = new THREE.Mesh(geo, wm); f.scale.z = s; f.position.set(0.03 - i * 0.009, 0, 0); f.rotation.y = s * (0.05 * i); p.add(f); } return { p, s }; });
  return { group: g, flap(ph) { const a = 0.9 * Math.cos(ph * Math.PI * 2); wings.forEach(({ p, s }) => { p.rotation.x = -s * a; }); } };
}

// ---------- detailed background (17 Nov): leafy trees, flowering shrubs, distant hills ----------
function barkTex() {
  return canvasTex(128, 512, (g, w, h) => { g.fillStyle = '#5a4434'; g.fillRect(0, 0, w, h); const R = rng(13);
    for (let i = 0; i < 70; i++) { const x = R() * w; g.strokeStyle = `rgba(${30 + R() * 20},${22 + R() * 15},${15 + R() * 10},0.7)`; g.lineWidth = 1 + R() * 3; g.beginPath(); g.moveTo(x, 0); for (let y = 0; y < h; y += 16) g.lineTo(x + Math.sin(y * 0.05 + i) * 4, y); g.stroke(); }
    for (let i = 0; i < 900; i++) { g.fillStyle = `rgba(${110 + R() * 50},${95 + R() * 40},${70 + R() * 30},0.25)`; g.fillRect(R() * w, R() * h, 2, 3); } });
}
// one shared leaf geometry for canopies
function leafGeo(L = 0.16) { const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.bezierCurveTo(L * 0.25, L * 0.24, L * 0.7, L * 0.22, L, 0); sh.bezierCurveTo(L * 0.7, -L * 0.22, L * 0.25, -L * 0.24, 0, 0); const geo = new THREE.ShapeGeometry(sh, 6); const uv = geo.attributes.uv, p = geo.attributes.position; for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / L, 0.5 + p.getY(i) / (L * 0.5)); return geo; }
// trees: tapered bark trunks with a few branches, canopies of instanced leaves in clusters
export function leafyTrees(spots, { seed = 7, leaves = 900 } = {}) {
  const R = rng(seed); const G = new THREE.Group();
  const bark = new THREE.MeshStandardMaterial({ map: tex('bark', barkTex), roughness: 0.95 });
  const leafM = new THREE.MeshStandardMaterial({ map: tex('leaf', leafTex), roughness: 0.7, side: THREE.DoubleSide });
  const lg = leafGeo(); const total = spots.length * leaves; const im = new THREE.InstancedMesh(lg, leafM, total); im.castShadow = true; let k = 0;
  const M = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), c = new THREE.Color();
  spots.forEach(([x, y, z]) => {
    const H = 3.5 + R() * 3, r0 = 0.12 + R() * 0.08;
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(r0 * 0.6, r0, H, 10, 4), bark); trunk.position.set(x, y + H / 2, z); trunk.castShadow = true; G.add(trunk);
    const tilt = (R() - 0.5) * 0.1; trunk.rotation.z = tilt;
    const clusters = []; const nC = 7 + Math.floor(R() * 4);
    for (let j = 0; j < nC; j++) { const a = R() * Math.PI * 2, rr = 0.4 + R() * 1.0, hy = H * (0.7 + R() * 0.45); const cpos = new THREE.Vector3(x + Math.cos(a) * rr, y + hy, z + Math.sin(a) * rr); clusters.push(cpos);
      const br = new THREE.Mesh(new THREE.CylinderGeometry(r0 * 0.15, r0 * 0.35, 1, 6), bark); const from = new THREE.Vector3(x, y + H * (0.55 + R() * 0.25), z); const dir = cpos.clone().sub(from); br.position.copy(from).addScaledVector(dir, 0.5); br.scale.y = dir.length(); br.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize()); G.add(br); }
    const hue = 0.24 + R() * 0.07;
    for (let i = 0; i < leaves && k < total; i++) { const cp = clusters[i % clusters.length]; const v = new THREE.Vector3(R() - 0.5, (R() - 0.5) * 0.8, R() - 0.5).normalize().multiplyScalar(Math.cbrt(R()) * (0.9 + R() * 0.5));
      e.set(R() * 6.3, R() * 6.3, R() * 6.3); q.setFromEuler(e); M.compose(cp.clone().add(v), q, s.setScalar(1.6 + R() * 1.2)); im.setMatrixAt(k, M); im.setColorAt(k, c.setHSL(hue + (R() - 0.5) * 0.04, 0.4 + R() * 0.2, 0.42 + R() * 0.35)); k++; }
  });
  im.count = k; G.add(im); return G;
}
// flowering shrubs: leafy mounds dotted with small 5-petal blossoms
function petalFlowerGeo(r = 0.025) { const sh = new THREE.Shape(); for (let i = 0; i <= 50; i++) { const a = i / 50 * Math.PI * 2; const rr = r * (0.55 + 0.45 * Math.abs(Math.cos(a * 2.5))); const px = Math.cos(a) * rr, py = Math.sin(a) * rr; if (i === 0) sh.moveTo(px, py); else sh.lineTo(px, py); } return new THREE.ShapeGeometry(sh, 2); }
export function flowerShrubs(spots, { seed = 21, leaves = 260, blooms = 70 } = {}) {
  const R = rng(seed); const G = new THREE.Group();
  const leafM = new THREE.MeshStandardMaterial({ map: tex('leaf', leafTex), roughness: 0.7, side: THREE.DoubleSide });
  const L = new THREE.InstancedMesh(leafGeo(0.1), leafM, spots.length * leaves); const F = new THREE.InstancedMesh(petalFlowerGeo(), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6, side: THREE.DoubleSide, emissive: 0x181010 }), spots.length * blooms);
  const ctr = new THREE.InstancedMesh(new THREE.SphereGeometry(0.008, 8, 6), new THREE.MeshStandardMaterial({ color: 0xffd23a, roughness: 0.5 }), spots.length * blooms);
  const hues = [0.95, 0.0, 0.08, 0.13, 0.8, 0.6]; const M = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), c = new THREE.Color(); let li = 0, fi = 0;
  spots.forEach(([x, y, z], j) => { const rad = 0.35 + R() * 0.4, hue = hues[j % hues.length];
    for (let i = 0; i < leaves; i++) { const v = new THREE.Vector3(R() - 0.5, R() * 0.9, R() - 0.5).normalize().multiplyScalar(rad * Math.cbrt(R())); e.set(R() * 6.3, R() * 6.3, R() * 6.3); q.setFromEuler(e); M.compose(new THREE.Vector3(x, y, z).add(v), q, s.setScalar(0.8 + R() * 0.6)); L.setMatrixAt(li, M); L.setColorAt(li, c.setHSL(0.26 + R() * 0.06, 0.45, 0.45 + R() * 0.3)); li++; }
    for (let i = 0; i < blooms; i++) { const v = new THREE.Vector3(R() - 0.5, 0.15 + R() * 0.85, R() - 0.5).normalize().multiplyScalar(rad * (0.92 + R() * 0.1)); const p = new THREE.Vector3(x, y, z).add(v); const n = v.clone().normalize(); q.setFromUnitVectors(new THREE.Vector3(0, 0, 1), n); M.compose(p, q, s.setScalar(0.8 + R() * 0.5)); F.setMatrixAt(fi, M); F.setColorAt(fi, c.setHSL(hue + (R() - 0.5) * 0.03, 0.75, 0.6 + R() * 0.15)); M.compose(p.clone().addScaledVector(n, 0.003), q, s.setScalar(1)); ctr.setMatrixAt(fi, M); fi++; } });
  L.castShadow = true; G.add(L, F, ctr); return G;
}
