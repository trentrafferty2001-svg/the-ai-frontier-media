// Antikythera mechanism reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK, stripStudio } from './shots4.js';
import { underwaterWorld } from './uw.js';
import { glowSprite } from './props.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { shadowAll } from './rome.js';
import { fabricTexture } from './textures.js';
import { greek, medLand, greekTemple } from './classic.js';
import { mechMats, gear, gearTrain, mechanism, corrodedLump, diver, amphora, planets } from './mech.js';
import { VO } from './vo_an.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you found', 3], ['a lump of', 3], ['*corroded bronze*', 2], ['at the bottom', 3], ['of the *sea*', 3], ['you would probably', 3], ['*throw it back*', 3]],
  [['But in *1901*', 5], ['*divers* pulled one', 3], ['from an ancient', 3], ['*Greek shipwreck*', 2], ['and it turned out', 4], ['to be a *computer*', 4]],
  [["It's called", 2], ['the *Antikythera*', 2], ['*mechanism*', 1], ['and it is over', 4], ['*2,000 years* old', 4]],
  [['Inside were', 2], ['*dozens*', 1], ['of interlocking', 2], ['*bronze gears*', 2], ['the biggest with', 3], ['*223 teeth*', 6]],
  [['Turn a', 2], ['*hand crank*', 2], ['and the gears', 3], ['move *pointers*', 2], ['around its *dials*', 3]],
  [['One showed', 2], ['where the *sun*', 3], ['and *moon*', 2], ['were in the sky', 4]],
  [['Another showed', 2], ['the *phases*', 2], ['of the *moon*', 3]],
  [['It could even', 3], ['*predict*', 1], ['*solar and lunar*', 3], ['*eclipses*', 1], ['years in advance', 3]],
  [['A small dial', 3], ['tracked the', 2], ['*4-year cycle*', 3], ['of the', 2], ['*Olympic Games*', 2]],
  [['For about', 2], ['a *century*', 2], ['*nobody*', 1], ['could read', 2], ['its *secrets*', 2]],
  [['Then in *2005*', 5], ['*scans* revealed', 2], ['*hidden gears*', 2], ['and *thousands*', 2], ['of tiny *letters*', 3]],
  [['The text describes', 3], ['the *sun*', 2], ['the *moon*', 2], ['and all *five planets*', 4], ['the Greeks knew', 3]],
  [['*Nothing* this complex', 3], ['would appear again', 3], ['for over', 2], ['*1,000 years*', 3]],
  [['A *pocket universe*', 3], ['made of *bronze*', 3], ['*2,000 years* ago', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared stages ============
function seabed(makeStage) {
  const scene = makeStage({ shadowSize: 1.5 }); stripStudio(scene);
  underwaterWorld(scene, { surf: 3.0, density: 0.28, leaves: 0, size: 10, fogColor: 0x1a4a5a, particles: 900 });
  const wm = new THREE.MeshStandardMaterial({ color: 0x3a2e22, roughness: 1 });
  [[-0.8, 0.05, -0.6, 0.3, 2.4], [0.7, 0.06, -0.9, -0.3, 2.0], [-0.2, 0.05, -1.4, 0.1, 1.8]].forEach(([x, y, z, ry, l]) => { const b = new THREE.Mesh(new THREE.BoxGeometry(l, 0.1, 0.18), wm); b.position.set(x, y, z); b.rotation.y = ry; b.castShadow = b.receiveShadow = true; scene.add(b); });
  [[-0.6, -0.3, 0.3], [0.5, -0.5, 1.2], [0.9, -0.2, 2.0], [-1.1, -0.9, 0.7]].forEach(([x, z, rz], i) => { const a = amphora(0.6); a.position.set(x, 0.05, z); a.rotation.set(Math.PI / 2, 0, rz); scene.add(a); });
  return scene;
}
function studio(makeStage, { c1 = 0x2a2018, c2 = 0x4e3c2a, warm = true } = {}) {
  const scene = makeStage({ shadowSize: 0.6, sunDir: [-1, 3, 2], sun: 1.6 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(c1); u.mid.value.set(c2); u.horizon.value.set(c2); u.floorC.value.set(c1);
  scene.fog = new THREE.Fog(c2, 1.5, 6);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ color: 0x3a2c20, roughness: 0.6 })); fl.rotation.x = -Math.PI / 2; fl.receiveShadow = true; scene.add(fl);
  const spot = new THREE.SpotLight(warm ? 0xfff0d8 : 0xd8e8ff, 10, 3, 0.45, 0.5, 1.2); spot.position.set(0.3, 1.4, 0.6); spot.target.position.set(0, 0.1, 0); spot.castShadow = true; scene.add(spot, spot.target);
  return scene;
}

// ============ S0: a green corroded lump lying on the seabed ============
function sLump({ makeStage }) {
  const scene = seabed(makeStage);
  const L = corrodedLump(); L.position.set(0.05, 0.04, 0.1); L.rotation.y = 0.4; scene.add(L);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.6));
      const pos = [lerp(0.6, 0.25, k), lerp(0.4, 0.22, k), lerp(0.8, 0.45, k)];
      place(c, pos, [0.05, 0.05, 0.1]);
      return { bloom: 0.6, warm: 0.5, sat: 1.05, dof: dofTo(pos, [0.05, 0.05, 0.1], 0.008, 0.012) };
    },
  };
}
// ============ S1: a 1901 sponge diver lifts it from the wreck ============
function sDiver({ makeStage }) {
  const scene = seabed(makeStage);
  const d = diver(); d.root.position.set(0.3, 0, 0.3); d.root.rotation.y = -0.5; scene.add(d.root);
  const L = corrodedLump(); scene.add(L);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const up = easeInOut(range(t, 0.5, 4.5));
      standPose(d, t, { spine: [0.4 - up * 0.3, 0, 0], lSh: [-1.0 - up * 0.4, 0, 0.3], rSh: [-1.0 - up * 0.4, 0, -0.3], lEl: [-0.6, 0, 0], rEl: [-0.6, 0, 0], lHip: [-0.3, 0, 0.1], rHip: [-0.3, 0, -0.1], lKn: [0.4, 0, 0], rKn: [0.4, 0, 0] }); d.grip(0.8, 0.8);
      d.root.position.y = up * 0.4 + Math.sin(t * 1.2) * 0.02;
      scene.updateMatrixWorld(true);
      const hp = wpos(d.j.lWr, V(0, -0.1, 0)).add(wpos(d.j.rWr, V(0, -0.1, 0))).multiplyScalar(0.5);
      L.position.copy(hp); L.rotation.set(0.2, t * 0.2, 0);
      const k = easeInOut(range(t, 0, 6.3));
      place(c, [lerp(1.9, 1.5, k), lerp(1.5, 1.9, k), lerp(3.0, 2.6, k)], [0.3, lerp(1.3, 1.6, k), 0.3]);
      return { bloom: 0.6, warm: 0.5, sat: 1.05 };
    },
  };
}
// ============ S2: the complete mechanism under a museum spotlight, slow orbit ============
function sReveal({ makeStage }) {
  const scene = studio(makeStage);
  const m = mechanism(); m.position.y = 0.1; scene.add(m);
  const ped = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.0, 0.3), mechMats().wood);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      m.set(t * 0.3);
      const a = lerp(-0.6, 0.5, easeInOut(range(t, 0, 4.6)));
      place(c, [Math.sin(a) * 0.65, 0.3, Math.cos(a) * 0.65], [0, 0.1, 0]);
      return { bloom: 0.6, warm: 1.2, dof: dofTo([Math.sin(a) * 0.65, 0.3, Math.cos(a) * 0.65], [0, 0.1, 0], 0.008, 0.01) };
    },
  };
}
// ============ S3: macro on the meshing bronze gears ============
function sGears({ makeStage }) {
  const scene = studio(makeStage);
  const tr = gearTrain(); tr.rotation.x = -Math.PI / 2 + 0.25; tr.position.y = 0.06; scene.add(tr);
  const tr2 = gearTrain([[0.08, 40], [0.04, 20], [0.1, 50]]); tr2.rotation.x = -Math.PI / 2 + 0.25; tr2.position.set(-0.15, 0.03, -0.1); scene.add(tr2);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      tr.spin(t * 0.5); tr2.spin(-t * 0.4);
      const k = easeInOut(range(t, 0, 6.2));
      const pos = [lerp(-0.05, 0.2, k), lerp(0.3, 0.22, k), lerp(0.35, 0.3, k)], look = [lerp(0.0, 0.12, k), 0.06, lerp(-0.02, 0.0, k)];
      place(c, pos, look);
      return { bloom: 0.55, warm: 1.2, dof: dofTo(pos, look, 0.01, 0.012) };
    },
  };
}
// ============ S4/S5/S6: crank and dials ============
function sCrank(view) {
  return ({ makeStage }) => {
    const scene = studio(makeStage);
    const m = mechanism(); m.position.y = 0.1; scene.add(m);
    const c = cam(view === 'crank' ? 32 : 26);
    return {
      scene, camera: c,
      update(t, T) {
        const turn = T * 0.35; m.set(turn);
        let pos, look;
        if (view === 'crank') { const k = easeInOut(range(t, 0, 4)); pos = [lerp(0.5, 0.35, k), lerp(0.25, 0.18, k), lerp(0.35, 0.4, k)]; look = [lerp(0.12, 0.0, k), 0.1, 0.02]; }
        else if (view === 'sun') { pos = [0.03, 0.12, 0.42]; look = [0.0, 0.1, 0.045]; }
        else { m.updateMatrixWorld(true); const b = m.ball.getWorldPosition(V(0, 0, 0)); pos = [b.x + 0.02, b.y + 0.02, b.z + 0.13]; look = [b.x, b.y, b.z]; }
        place(c, pos, look);
        return { bloom: 0.55, warm: 1.2, dof: view === 'sun' ? undefined : dofTo(pos, look, 0.012, 0.012) };
      },
    };
  };
}
// ============ S7: a solar eclipse: the moon slides across the sun over a Greek temple ============
function sEclipse({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.0, 0.35, -0.94], fog: 0.004, shadowSize: 20, envI: 0.8 });
  medLand(scene, { seed: 6 });
  const tmp = greekTemple(); tmp.position.set(0, 0, -30); scene.add(tmp);
  const sd = V(0, 0.35, -0.94).normalize();
  const sun = glowSprite(0xfff0c0, 1); sun.material.fog = false; sun.material.blending = THREE.AdditiveBlending; sun.scale.setScalar(26); scene.add(sun);
  sun.renderOrder = 1; const moon = new THREE.Mesh(new THREE.CircleGeometry(4.2, 48), new THREE.MeshBasicMaterial({ color: 0x0a0a0c, fog: false, depthTest: false })); moon.renderOrder = 5; scene.add(moon);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const eye = V(0, 2, 10); const sp = eye.clone().addScaledVector(sd, 200);
      sun.position.copy(sp);
      const k = easeInOut(range(t, 0.2, 3.6)); const off = lerp(-14, 3, k);
      moon.position.copy(sp).add(V(off, off * 0.2, 2)); moon.lookAt(eye);
      place(c, [eye.x, eye.y, eye.z], [sp.x, sp.y - 30, sp.z]);
      const dark = Math.max(0, 1 - Math.abs(off) / 4);
      return { bloom: 0.8, warm: 1.2, exposure: 1.0 - dark * 0.55 };
    },
  };
}
// ============ S8: runners at Olympia, four-yearly games ============
function sOlympia({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.6, 0.6], fog: 0.004, shadowSize: 8, envI: 0.9 });
  medLand(scene, { seed: 9, groundC: 0xb89a6a });
  const track = new THREE.Mesh(new THREE.PlaneGeometry(40, 6), new THREE.MeshStandardMaterial({ color: 0xc8a878, roughness: 1 })); track.rotation.x = -Math.PI / 2; track.position.y = 0.01; scene.add(track);
  for (const s of [-1]) { const bank = new THREE.Mesh(new THREE.BoxGeometry(40, 1.2, 3), new THREE.MeshStandardMaterial({ color: 0x8a9a5a, roughness: 1 })); bank.position.set(0, 0.4, s * 4.6); bank.rotation.x = s * 0.35; scene.add(bank); }
  const runners = [0, 1, 2, 3].map(i => { const r = greek({ color: [0xf2ede0, 0xb8342a, 0x2a5a8a, 0xd8a83a][i], beard: false }); r.root.rotation.y = Math.PI / 2; scene.add(r.root); return r; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      runners.forEach((r, i) => { const x = -8 + t * 4.6 - i * 0.6 + Math.sin(t * 0.9 + i * 2) * 0.15; r.root.position.set(x, 0, -1.8 + i * 1.2); const w = Math.sin(t * 11 + i * 1.7); standPose(r, t, { lHip: [w * 0.8, 0, 0.07], rHip: [-w * 0.8, 0, -0.07], lKn: [Math.max(0, -w) * 1.2, 0, 0], rKn: [Math.max(0, w) * 1.2, 0, 0], lSh: [-w * 0.8, 0, 0.15], rSh: [w * 0.8, 0, -0.15], lEl: [-1.2, 0, 0], rEl: [-1.2, 0, 0], spine: [0.2, 0, 0] }); r.setMood('happy'); r.setMouth(0); r.grip(0.9, 0.9); });
      const lead = -8 + t * 4.6 - 0.9;
      place(c, [lead + 6.0, 2.1, 9.0], [lead, 0.8, 0]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S9: the lump in a dim museum case, nobody understanding it ============
function sCase({ makeStage }) {
  const scene = studio(makeStage, { c1: 0x1c2026, c2: 0x343a44, warm: false });
  const L = corrodedLump(); L.position.y = 0.06; scene.add(L);
  const glass = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.35, 0.35), new THREE.MeshPhysicalMaterial({ color: 0xffffff, transmission: 0.95, roughness: 0.02, transparent: true, opacity: 0.18 })); glass.position.y = 0.175; scene.add(glass);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(0.6, 0.45, k), lerp(0.3, 0.22, k), lerp(0.7, 0.55, k)], [0, 0.07, 0]);
      return { bloom: 0.45, warm: 0.6, sat: 0.6 };
    },
  };
}
// ============ S10: X-ray scan sweeps through the lump: glowing hidden gears and letters ============
function sScan({ makeStage, start: ST }) {
  const tG = at(10, 'hidden') - ST, tL = at(10, 'letters') - ST;
  const scene = studio(makeStage, { c1: 0x020610, c2: 0x06101c, warm: false });
  const L = corrodedLump(); L.position.y = 0.06; scene.add(L);
  const ghosts = gearTrain([[0.05, 50], [0.022, 22], [0.04, 40], [0.016, 16]]); ghosts.rotation.x = -Math.PI / 2; ghosts.position.set(-0.04, 0.06, 0.0);
  ghosts.traverse(o => { if (o.isMesh) o.material = mechMats().xray; }); scene.add(ghosts);
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.3), new THREE.MeshBasicMaterial({ color: 0x7fd8ff, transparent: true, opacity: 0.1, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false })); scene.add(plane);
  const letters = [...'ΗΛΙΟΣΣΕΛΗΝΗΑΦΡΟΔΙΤΗΕΡΜΗΣΑΡΗΣΖΕΥΣΚΡΟΝΟΣ'].map((ch, i) => { const cv = document.createElement('canvas'); cv.width = cv.height = 64; const x = cv.getContext('2d'); x.fillStyle = '#9fe4ff'; x.font = 'bold 48px serif'; x.textAlign = 'center'; x.fillText(ch, 32, 48); const tx = new THREE.CanvasTexture(cv); const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tx, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })); s.scale.setScalar(0.018); s.position.set(-0.13 + (i % 12) * 0.024, 0.11 + Math.floor(i / 12) * 0.022, 0.05); scene.add(s); return s; });
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      const sx = lerp(-0.25, 0.25, (t * 0.4) % 1); plane.position.set(sx, 0.08, 0); plane.rotation.y = Math.PI / 2;
      const gv = easeOut(range(t, tG - 0.4, tG + 0.4)); ghosts.visible = gv > 0.01; mechMats().xray.opacity = 0.6 * gv; ghosts.spin(t * 0.3);
      L.children[0].material.opacity = 1; L.traverse(o => { if (o.isMesh) { o.material.transparent = true; o.material.opacity = 1 - 0.7 * gv; } });
      letters.forEach((s, i) => s.material.opacity = easeOut(range(t, tL - 0.6 + i * 0.02, tL + i * 0.02)));
      const k = easeInOut(range(t, 0, 5.5));
      place(c, [lerp(0.4, 0.15, k), lerp(0.35, 0.2, k), lerp(0.55, 0.45, k)], [0, 0.08, 0]);
      return { bloom: 0.9, warm: 0.4, sat: 1.1 };
    },
  };
}
// ============ S11: the five planets orbit above the dial ============
function sPlanets({ makeStage }) {
  const scene = studio(makeStage);
  const m = mechanism(); m.position.y = 0.1; scene.add(m);
  const P = planets(); P.position.set(0, 0.35, 0.05); P.rotation.x = 0.35; scene.add(P);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t, T) {
      m.set(T * 0.35); P.update(t * 1.2);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(0.3, 0.1, k), lerp(0.45, 0.55, k), lerp(0.75, 0.9, k)], [0, lerp(0.22, 0.3, k), 0]);
      return { bloom: 0.8, warm: 1.2 };
    },
  };
}
// ============ S12: pull back into darkness: a lone mechanism, a millennium ahead of its time ============
function sAlone({ makeStage }) {
  const scene = studio(makeStage);
  const m = mechanism(); m.position.y = 0.1; scene.add(m);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t, T) {
      m.set(T * 0.35);
      const k = easeOut(range(t, 0, 4.2));
      place(c, [lerp(0.25, 0.9, k), lerp(0.2, 0.6, k), lerp(0.35, 1.6, k)], [0, 0.1, 0]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
// ============ S13: the mechanism glowing, planets turning, golden ============
function sEnd({ makeStage }) {
  const scene = studio(makeStage, { c1: 0x3a2410, c2: 0x6a4420 });
  const m = mechanism(); m.position.y = 0.1; scene.add(m);
  const P = planets(); P.position.set(0, 0.33, 0.05); P.rotation.x = 0.3; scene.add(P);
  const halo = glowSprite(0xffc070, 1); halo.scale.setScalar(0.6); halo.position.set(0, 0.12, -0.1); halo.material.blending = THREE.AdditiveBlending; scene.add(halo);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t, T) {
      m.set(T * 0.35); P.update(t);
      const a = lerp(0.4, -0.3, easeInOut(range(t, 0, 5)));
      place(c, [Math.sin(a) * 0.8, 0.35, Math.cos(a) * 0.8], [0, 0.18, 0]);
      return { bloom: 0.9, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sLump], [ls(1), ls(2), sDiver], [ls(2), ls(3), sReveal], [ls(3), ls(4), sGears], [ls(4), ls(5), sCrank('crank')],
  [ls(5), ls(6), sCrank('sun')], [ls(6), ls(7), sCrank('moon')], [ls(7), ls(8), sEclipse], [ls(8), ls(9), sOlympia], [ls(9), ls(10), sCase],
  [ls(10), ls(11), sScan], [ls(11), ls(12), sPlanets], [ls(12), ls(13), sAlone], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
