// Persian ice house reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake, ikArm } from './anim.js';
import { shadowAll } from './rome.js';
import { persiaMats, desertGround, palm, yakhchal, yakhchalCut, shadeWall, freezeChannel, qanatLine, persianWorker, iceBlock, meltingCube, airFlow, arrow, ingredients, faloodeh } from './persia.js';
import { VO } from './vo_ih.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you lived', 3], ['in the *desert*', 3], ['*2,000 years ago*', 4], ['you might think', 3], ['*ice*', 1], ['was *impossible*', 2]],
  [['But the *Persians*', 3], ['made *ice*', 2], ['in the *desert*', 3], ['and kept it', 3], ['*frozen*', 1], ['all *summer*', 2]],
  [['They built', 2], ['giant mud *domes*', 3], ['called *yakhchals*', 2], ['up to', 2], ['*20 meters* tall', 3]],
  [['In *winter*', 2], ['water from', 2], ['*underground canals*', 2], ['flowed into', 2], ['long, *shallow*', 2], ['*channels*', 1]],
  [['A tall *wall*', 3], ['*shaded* them', 2], ['from the *sun*', 3]],
  [['On *cold nights*', 3], ['the water', 2], ['*froze*', 1]],
  [['Workers cut', 2], ['the ice', 2], ['into *blocks*', 2], ['and stored them', 3], ['in a *deep pit*', 4], ['under the *dome*', 3]],
  [['The walls were', 3], ['up to', 2], ['*2 meters*', 2], ['*thick*', 1], ['at the base', 3]],
  [['They were made', 3], ['of a mortar', 3], ['called *sarooj*', 2], ['with *sand*', 2], ['*clay*', 1], ['*lime*', 1], ['*egg whites*', 2], ['and *goat hair*', 3]],
  [['It kept', 2], ['the *heat out*', 3], ['and the *cold in*', 4]],
  [['*Warm air*', 2], ['*rose*', 1], ['to the top', 3], ['of the dome', 3], ['while the', 2], ['*coldest air*', 2], ['*sank*', 1], ['to the ice', 3]],
  [['*Melted* ice', 2], ['drained into', 2], ['a *trench*', 2], ['where it could', 3], ['*freeze again*', 2]],
  [['Persians used', 2], ['the ice', 2], ['to *chill drinks*', 3], ['and make', 2], ['*faloodeh*', 1], ['an ancient', 2], ['*frozen dessert*', 2]],
  [['Some of these', 3], ['*desert fridges*', 2], ['are still', 2], ['*standing today*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: the ice-house site (dome, shade wall to its south, channel north of the wall) ============
function site(scene, { palms = true, workers = 0, channel = null, seed = 1 } = {}) {
  desertGround(scene, { seed });
  const y = yakhchal(); y.position.set(0, 0, 0); scene.add(y);
  const wall = shadeWall(40, 10); wall.position.set(-36, 0, 4); scene.add(wall);
  const ch = freezeChannel(36, 3.4); ch.position.set(-36, 0, 0.4); scene.add(ch);
  if (channel != null) ch.set(channel, 1);
  if (palms) [[-26, -14, 4.5], [-22, -18, 5.5], [24, -10, 5], [28, -16, 4.2], [18, 26, 4.6]].forEach(([x, z, h], i) => { const p = palm(h, i + 3); p.position.set(x, 0, z); p.rotation.y = i; scene.add(p); });
  return { dome: y, wall, ch };
}

// ============ S0: an ice cube melting on hot sand ============
function sMelt({ makeStage, start: ST }) {
  const tI = at(0, 'ice') - ST;
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.3, 0.75, 0.55], fog: 0.004, shadowSize: 0.6, envI: 0.9 });
  desertGround(scene, { seed: 2 });
  const cube = meltingCube(); scene.add(cube);
  // heat shimmer: faint additive sprites drifting up
  const tex = glowSprite().material.map;
  const hz = [...Array(10)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color: 0xfff0d0, transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending })); scene.add(s); return { s, i }; });
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      cube.set(easeIn(range(t, 0.2, 4.9)) * 0.92);
      hz.forEach(({ s, i }) => { const a = ((t * 0.25 + i / 10) % 1); s.position.set(-0.4 + i * 0.09, 0.05 + a * 0.4, -0.5); s.scale.setScalar(0.25); s.material.opacity = 0.08 * Math.sin(Math.PI * a); });
      const k = easeInOut(range(t, 0, 5));
      const pos = [lerp(0.55, 0.4, k), lerp(0.32, 0.24, k), lerp(0.95, 0.72, k)], look = [0, 0.05, 0];
      place(c, pos, look);
      return { bloom: 0.7, warm: 1.35, flare: 0.0, exposure: 1.05, dof: dofTo(pos, look, 0.012, 0.012) };
    },
  };
}

// ============ S1: the yakhchal in the blazing desert ============
function sReveal({ makeStage }) {
  const scene = makeStage({ outdoor: 'desert', sunDir: [0.4, 0.62, -0.68], fog: 0.0025, shadowSize: 30, shadowAt: [0, 0, 6], envI: 0.95 });
  site(scene, {});
  const b = birds(3, { from: [-40, 22, -20], to: [40, 26, -30], spread: 6, speed: 0.05, scale: 2.0, seed: 3 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  fillLight(scene, [0.3, 0.4, 1], 0.6, 0xffe6c8);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(26, 18, k), lerp(4, 7, k), lerp(52, 44, k)], [lerp(-2, 0, k), lerp(9, 8, k), 4]);
      return { bloom: 0.55, flare: 0.9, warm: 1.25 };
    },
  };
}

// ============ S2: low angle tilt up the dome, a worker at the base for scale ============
function sScale({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.6, 0.55, 0.58], fog: 0.002, shadowSize: 14, shadowAt: [0, 0, 6], envI: 0.95 });
  site(scene, {});
  const man = persianWorker(); man.root.position.set(1.6, 0, 11.2); man.root.rotation.y = 0.4; scene.add(man.root);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      standPose(man, t, { head: [-0.5, 0.2, 0], neck: [-0.3, 0, 0] }); man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [1.2, 3.1]));
      const k = easeInOut(range(t, 0, 4.3));
      place(c, [lerp(6, 9, k), lerp(1.2, 2.0, k), lerp(24, 36, k)], [lerp(1.5, 0, k), lerp(1.7, 10, k), lerp(11, 0, k)]);
      return { bloom: 0.5, flare: 0.5, warm: 1.2 };
    },
  };
}

// ============ S3: winter: qanat wells across the plain, water filling the shallow channel ============
function sQanat({ makeStage, start: ST }) {
  const tCh = at(3, 'flowed') - ST;
  const scene = makeStage({ outdoor: 'winter', sunDir: [0.3, 0.4, 0.86], fog: 0.0035, shadowSize: 30, shadowAt: [-36, 0, 2], envI: 0.85 });
  const S = site(scene, { palms: true });
  scene.add(qanatLine(10, { from: [-120, 0, -60], to: [-57, 0, -0.5] }));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      S.ch.set(0, easeInOut(range(t, tCh - 0.4, tCh + 2.4)));
      const k = easeInOut(range(t, 0, 5.1));
      place(c, [lerp(-118, -82, k), lerp(7, 9, k), lerp(-74, -46, k)], [lerp(-80, -40, k), lerp(0, 2, k), lerp(-38, 0, k)]);
      return { bloom: 0.4, warm: 0.7, sat: 1.1 };
    },
  };
}

// ============ S4: the shade wall's long shadow over the channel ============
function sShade({ makeStage }) {
  const scene = makeStage({ outdoor: 'winter', sunDir: [0.15, 0.32, 0.94], fog: 0.003, shadowSize: 26, shadowAt: [-36, 0, 2], envI: 0.85 });
  const S = site(scene, {}); S.ch.set(0, 1);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 2.3));
      place(c, [lerp(-14, -18, k), lerp(9, 11, k), lerp(-16, -12, k)], [-38, 1.5, lerp(1, 2, k)]);
      return { bloom: 0.45, flare: 0.6, warm: 0.8 };
    },
  };
}

// ============ S5: night: the channel freezes over ============
function sFreeze({ makeStage, start: ST }) {
  const tF = at(5, 'froze') - ST;
  const scene = makeStage({ outdoor: 'night', sunDir: [-0.4, 0.45, -0.8], fog: 0.004, shadowSize: 22, shadowAt: [-36, 0, 1], envI: 0.5, hemi: 0.25 });
  const S = site(scene, { palms: true });
  const moon = glowSprite(0xdfe8ff, 1); moon.scale.setScalar(14); moon.position.set(-60, 75, -120); scene.add(moon);
  // stars
  const N = 400, pos = new Float32Array(N * 3); for (let i = 0; i < N; i++) { const a = Math.random() * Math.PI * 2, e = 0.15 + Math.random() * 1.3; pos.set([Math.cos(a) * Math.cos(e) * 380, Math.sin(e) * 380, Math.sin(a) * Math.cos(e) * 380], i * 3); }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 1.2, sizeAttenuation: false, fog: false })); scene.add(stars);
  fillLight(scene, [0.3, 0.6, -1], 0.9, 0xdfe6ff);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      S.ch.set(easeInOut(range(t, 0.2, tF + 0.5)), 1);
      const k = easeInOut(range(t, 0, 2.0));
      place(c, [lerp(-26, -28, k), lerp(4.5, 3.2, k), lerp(-7, -6, k)], [lerp(-36, -38, k), 0.3, 0.4]);
      return { bloom: 0.7, warm: 0.3, sat: 0.95, exposure: 1.55 };
    },
  };
}

// ============ S6a: workers break the ice into blocks on the channel ============
function sCut({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'winter', sunDir: [0.4, 0.3, -0.86], fog: 0.003, shadowSize: 5, shadowAt: [-36, 0, 0.4], envI: 0.9 });
  const S = site(scene, {}); S.ch.set(1, 1);
  const men = [[-36.5, 0.0, 0.4 + Math.PI], [-33.5, 1.2, -2.6 + Math.PI]].map(([x, z, ry], i) => { const m = persianWorker({ color: i ? 0xb8a688 : 0xd9cdb0 }); m.root.position.set(x, 0.33, z); m.root.rotation.y = ry; scene.add(m.root); return m; });
  const pick = new THREE.Group(); const wm = new THREE.MeshStandardMaterial({ color: 0x6a4a2a, roughness: 0.8 });
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.9, 8), wm); handle.position.y = 0.45; pick.add(handle);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.05, 0.05), new THREE.MeshStandardMaterial({ color: 0x5a5a5e, metalness: 0.8, roughness: 0.4 })); head.position.y = 0.9; pick.add(head);
  scene.add(shadowAll(pick));
  const blocks = [0, 1, 2].map(i => { const b = iceBlock(0.9, 0.25, 0.6); b.position.set(-35.2 + i * 1.0, 0.45, 0.6); scene.add(b); return b; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const sw = Math.sin(t * Math.PI * 2 / 0.9);
      const m0 = men[0];
      standPose(m0, t, { spine: [0.35, 0, 0], chest: [0.2, 0, 0], head: [0.3, 0, 0], lHip: [-0.2, 0, 0.1], rHip: [-0.2, 0, -0.1], lKn: [0.3, 0, 0], rKn: [0.3, 0, 0] });
      m0.setMood('happy'); m0.setMouth(0); m0.grip(0.9, 0.9);
      m0.root.updateMatrixWorld(true);
      const pv = wpos(m0.root, V(0, 1.05, 0.25));
      pick.position.copy(pv); pick.rotation.set(0, m0.root.rotation.y, 0); pick.rotateX(-0.6 + sw * 0.9); pick.updateMatrixWorld(true);
      ikArm(m0, 'l', wpos(pick, V(0, 0.15, 0)), wpos(m0.root, V(0.8, 0.4, 0)), V(0, 1, 0));
      ikArm(m0, 'r', wpos(pick, V(0, 0.4, 0)), wpos(m0.root, V(-0.8, 0.4, 0)), V(0, 1, 0));
      const m1 = men[1]; standPose(m1, t, { spine: [0.5, 0, 0], chest: [0.3, 0, 0], lSh: [-0.9, 0, 0.2], rSh: [-0.9, 0, -0.2], lEl: [-0.3, 0, 0], rEl: [-0.3, 0, 0], lHip: [-0.4, 0, 0.12], rHip: [-0.4, 0, -0.12], lKn: [0.6, 0, 0], rKn: [0.6, 0, 0], drop: -0.12 }); m1.setMood('happy'); m1.grip(0.8, 0.8);
      blocks.forEach((b, i) => { const u = easeOut(range(t, 1.0 + i * 0.6, 1.6 + i * 0.6)); b.position.y = 0.45 + u * 0.15; b.rotation.z = u * 0.08 * (i - 1); });
      const k = easeInOut(range(t, 0, 2.6));
      const pos = [lerp(-31.5, -30.5, k), lerp(3.6, 3.2, k), lerp(-7.5, -6.5, k)], look = [-34.8, 0.9, 0.8];
      place(c, pos, look);
      return { bloom: 0.5, warm: 0.85, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}

// ============ cut-away stage ============
function cutStage(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.5, 0.6, 0.62], fog: 0.0018, shadowSize: 22, shadowAt: [0, 2, 0], envI: 0.9, ...opts });
  desertGround(scene, { seed: 4, half: true });
  // ground with a hole: cover around the pit with a ring so the desert floor stops at the cut
  const Y = yakhchalCut(); scene.add(Y);
  // hide desert ground in the pit footprint with a dark-earth disc below, and a front earth wall
  fillLight(scene, [0.2, 0.4, 1], 0.9, 0xffeedd);
  const inside = new THREE.PointLight(0x9fd8ff, 30, 16, 1.6); inside.position.set(0, -3, 1); scene.add(inside);
  return { scene, Y, inside };
}
// ground disc must not cover the pit: desertGround is a full circle at y=0, so cut the view from above ground level
// ============ S6b: blocks slide into the pit under the dome ============
function sStore({ makeStage, start: ST }) {
  const C = cutStage(makeStage);
  const c = cam(40);
  return {
    scene: C.scene, camera: c,
    update(t) {
      C.Y.setFill(lerp(0.15, 0.85, easeInOut(range(t, 0, 2.4))));
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(10, 6, k), lerp(4, 6, k), lerp(34, 38, k)], [0, lerp(1, 4, k), 0]);
      return { bloom: 0.5, warm: 1.0 };
    },
  };
}
// ============ S7: thick walls at the base, worker for scale, a yellow measuring bar ============
function sWall({ makeStage, start: ST }) {
  const tT = at(7, 'thick') - ST;
  const C = cutStage(makeStage);
  const man = persianWorker(); man.root.position.set(10.6, 0, 1.4); man.root.rotation.y = -0.4; C.scene.add(man.root);
  const bar = new THREE.Group(); const ym = new THREE.MeshStandardMaterial({ color: 0xffd43b, emissive: 0x806a1e, emissiveIntensity: 0.7 });
  const b0 = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.08, 0.08), ym); bar.add(b0);
  for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.5, 0.08), ym); e.position.x = s; bar.add(e); }
  bar.position.set(8.0, 1.8, 0.15); C.scene.add(bar);
  const c = cam(38);
  return {
    scene: C.scene, camera: c,
    update(t) {
      C.Y.setFill(0.85);
      standPose(man, t, { head: [0, -0.4, 0] }); man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.8]));
      const g = easeOut(range(t, tT - 0.6, tT + 0.1)); bar.scale.set(Math.max(0.01, g), 1, 1); bar.visible = g > 0.01;
      const k = easeInOut(range(t, 0, 2.4));
      const pos = [lerp(9.5, 8.6, k), lerp(2.6, 2.3, k), lerp(9, 7.5, k)], look = [8.6, 1.6, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.1, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S8: sarooj ingredients pop onto a board ============
function sSarooj({ makeStage, start: ST }) {
  const times = ['sand', 'clay', 'lime', 'egg', 'goat'].map(w => at(8, w) - ST);
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.4, 0.6, 0.7], fog: 0.004, shadowSize: 1.5, envI: 0.9 });
  desertGround(scene, { seed: 5 });
  const y = yakhchal(); y.position.set(4, 0, -22); scene.add(y);
  const ing = ingredients(); ing.position.set(0, 0.6, 0); ing.scale.setScalar(1.0); scene.add(ing);
  const labels = ['sand', 'clay', 'lime', 'egg whites', 'goat hair'].map((w, i) => {
    const cv = document.createElement('canvas'); cv.width = 512; cv.height = 128; const x = cv.getContext('2d');
    x.font = '700 64px Cap, sans-serif'; x.textAlign = 'center'; x.lineWidth = 14; x.strokeStyle = '#111'; x.strokeText(w, 256, 88); x.fillStyle = '#fff'; x.fillText(w, 256, 88);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(cv), depthTest: false, transparent: true })); sp.material.map.colorSpace = THREE.SRGBColorSpace;
    sp.scale.set(0.34, 0.085, 1); sp.position.set(ing.items[i].position.x, 0.62, 0.3); sp.renderOrder = 5; scene.add(sp); return sp;
  });
  const table = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.6, 0.8), persiaMats().mud); table.position.y = 0.3; scene.add(shadowAll(table));
  const mix = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.18, 0.12, 24), new THREE.MeshStandardMaterial({ color: 0x9a7048, roughness: 1 })); mix.position.set(0, 0.66, 0.25); scene.add(mix);
  fillLight(scene, [0.2, 0.5, 1], 0.7, 0xffeedd);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      ing.items.forEach((it, i) => { const a = t - times[i] + 0.06; const s = a < 0 ? 0.001 : a < 0.08 ? lerp(0.5, 1.2, a / 0.08) : a < 0.18 ? lerp(1.2, 1, (a - 0.08) / 0.1) : 1; it.scale.setScalar(s); it.visible = a > 0; labels[i].visible = a > 0; labels[i].material.opacity = Math.min(1, a / 0.12); });
      mix.visible = t < times[0] - 0.1;
      const k = easeInOut(range(t, 0, 5.2));
      const tx = kf(t, [[0, 0], [times[0] - 0.45, 0], [times[0], -0.7], [times[1], -0.36], [times[2], -0.05], [times[3], 0.3], [times[4], 0.5], [times[4] + 2, 0.55]], easeInOut);
      const pos = [tx, 1.65, 1.55], look = [tx, 0.7, -0.25];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.15 };
    },
  };
}
// ============ S9: heat bounces off the outside, the inside stays cold ============
function sHeat({ makeStage, start: ST }) {
  const tO = at(9, 'out') - ST, tC = at(9, 'cold') - ST;
  const C = cutStage(makeStage, { sunDir: [-0.7, 0.6, 0.38] });
  const arrows = [0, 1, 2, 3].map(i => { const a = arrow(0xff6a2a, 2.4); C.scene.add(a); return a; });
  const coldGlow = glowSprite(0x7fd0ff, 1); coldGlow.scale.setScalar(12); coldGlow.position.set(0, -2.5, 0.5); coldGlow.material.blending = THREE.AdditiveBlending; C.scene.add(coldGlow);
  const c = cam(40);
  return {
    scene: C.scene, camera: c,
    update(t) {
      C.Y.setFill(0.85);
      arrows.forEach((a, i) => { const d = (t * 0.8 + i * 0.25) % 1; const bounce = d > 0.5; const y = 4 + i * 2.6; const dist = bounce ? lerp(0, 6, (d - 0.5) * 2) : lerp(6, 0, d * 2); const r = 9 * (1 - y / 18) + 0.4 + dist; a.position.set(-r, y, 0.5); a.rotation.z = bounce ? Math.PI / 2 : -Math.PI / 2; a.visible = t > tO - 0.8; });
      coldGlow.material.opacity = 0.5 * easeOut(range(t, tC - 0.3, tC + 0.3));
      const k = easeInOut(range(t, 0, 2.1));
      place(c, [lerp(-6, -2, k), lerp(8, 6, k), lerp(36, 34, k)], [-2, 5, 0]);
      return { bloom: 0.6, warm: 1.0 };
    },
  };
}
// ============ S10: warm air rises out the top, cold air sinks onto the ice ============
function sAir({ makeStage, start: ST }) {
  const tW = at(10, 'warm') - ST, tC = at(10, 'coldest') - ST;
  const C = cutStage(makeStage);
  const warm = airFlow(50, { color: 0xff7a3a, up: true, R: 6, H: 19, seed: 3 }); warm.position.y = 0; C.scene.add(warm);
  const cold = airFlow(60, { color: 0x6fc8ff, up: false, R: 7, H: 12, seed: 5 }); cold.position.y = -5.5; C.scene.add(cold);
  const c = cam(40);
  return {
    scene: C.scene, camera: c,
    update(t) {
      C.Y.setFill(0.85);
      warm.update(t, easeOut(range(t, tW - 0.3, tW + 0.4)));
      cold.update(t, easeOut(range(t, tC - 0.3, tC + 0.4)));
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(3, -3, k), lerp(6, 4, k), lerp(40, 37, k)], [0, lerp(7, 4, k), 0]);
      return { bloom: 0.75, warm: 1.0 };
    },
  };
}
// ============ S11: drips fall into the trench, which freezes again ============
function sTrench({ makeStage, start: ST }) {
  const tF = at(11, 'freeze') - ST;
  const C = cutStage(makeStage);
  const tw = C.Y.userData.trenchWater;
  const dm = new THREE.MeshStandardMaterial({ color: 0x9fd8ff, roughness: 0.05, emissive: 0x2a6a9a, emissiveIntensity: 0.5 });
  const drops = [...Array(12)].map((_, i) => { const d = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), dm); d.scale.y = 1.5; C.scene.add(d); return { d, x: -5.5 + (i % 6) * 0.25, ph: i / 12 }; });
  const c = cam(36);
  return {
    scene: C.scene, camera: c,
    update(t) {
      C.Y.setFill(0.85);
      drops.forEach(({ d, x, ph }) => { const a = (t * 0.9 + ph) % 1; d.position.set(x, -2.2 - a * 3.5, -0.2); d.visible = t < tF + 0.3; });
      const f = easeInOut(range(t, tF - 0.5, tF + 0.6));
      tw.material.color.set(0x4f9ad0).lerp(new THREE.Color(0xe8f6ff), f); tw.material.emissiveIntensity = 0.5 - 0.3 * f; tw.material.roughness = 0.05 + 0.3 * f;
      const k = easeInOut(range(t, 0, 3.4));
      const pos = [lerp(-3.5, -4.5, k), lerp(-1.0, -1.8, k), lerp(12, 10.5, k)], look = [-6.6, -5.4, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 0.85 };
    },
  };
}
// ============ S12: faloodeh and a chilled drink on a courtyard table ============
function sFaloodeh({ makeStage, start: ST }) {
  const tF = at(12, 'faloodeh') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.5, 0.3, -0.81], fog: 0.004, shadowSize: 1.2, envI: 0.95 });
  desertGround(scene, { seed: 6 });
  const y = yakhchal(); y.position.set(-6, 0, -26); scene.add(y);
  [[5, -12, 4.5], [8, -16, 5.2]].forEach(([x, z, h], i) => { const p = palm(h, i + 9); p.position.set(x, 0, z); scene.add(p); });
  const tm = new THREE.MeshStandardMaterial({ color: 0x6a3f24, roughness: 0.6 });
  const table = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.05, 32), tm); table.position.y = 0.7; scene.add(table);
  const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 0.7, 12), tm); leg.position.y = 0.35; scene.add(leg);
  const cloth = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.006, 32), new THREE.MeshStandardMaterial({ color: 0x8a3a2a, roughness: 0.9 })); cloth.position.y = 0.728; scene.add(cloth);
  const f = faloodeh(); f.position.set(0.05, 0.73, 0.05); scene.add(f);
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.03, 0.12, 24), new THREE.MeshPhysicalMaterial({ color: 0xffffff, transmission: 0.95, roughness: 0.03, transparent: true, opacity: 0.4 })); glass.position.set(-0.18, 0.79, -0.05); scene.add(glass);
  const drink = new THREE.Mesh(new THREE.CylinderGeometry(0.031, 0.027, 0.09, 24), new THREE.MeshStandardMaterial({ color: 0xc8486a, roughness: 0.1, transparent: true, opacity: 0.8 })); drink.position.set(-0.18, 0.775, -0.05); scene.add(drink);
  for (let i = 0; i < 3; i++) { const cu = iceBlock(0.022, 0.022, 0.022); cu.position.set(-0.18 + (i - 1) * 0.012, 0.825, -0.05 + (i % 2) * 0.01); cu.rotation.set(i, i * 2, 0); scene.add(cu); }
  shadowAll(scene);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5));
      const tx = kf(t, [[0, -0.18], [tF - 0.6, -0.18], [tF, 0.05], [5, 0.05]], easeInOut);
      const pos = [lerp(0.3, 0.4, k), lerp(1.15, 1.08, k), lerp(0.95, 0.7, k)], look = [tx, 0.78, 0.0];
      place(c, pos, look);
      return { bloom: 0.6, flare: 0.6, warm: 1.3, dof: dofTo(pos, look, 0.006, 0.012) };
    },
  };
}
// ============ S13: sunset over several ice houses ============
function sEnd({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.1, -0.79], fog: 0.0028, shadowSize: 60, shadowAt: [0, 0, -10], envI: 0.95 });
  desertGround(scene, { seed: 7 });
  [[0, 0, 1], [-34, -30, 0.85], [30, -44, 0.9], [-12, -70, 0.8]].forEach(([x, z, s], i) => { const y = yakhchal(); y.scale.setScalar(s); y.position.set(x, 0, z); scene.add(y); const w = shadeWall(40, 9); w.scale.setScalar(s); w.position.set(x - 36 * s, 0, z + 4 * s); scene.add(w); });
  [[-20, 10, 5], [16, 6, 4.4], [24, 14, 5.2]].forEach(([x, z, h], i) => { const p = palm(h, i + 20); p.position.set(x, 0, z); scene.add(p); });
  const b = birds(4, { from: [-40, 16, -30], to: [40, 20, -40], spread: 6, speed: 0.05, scale: 2.0, seed: 6 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(22, 30, k), lerp(5, 10, k), lerp(48, 60, k)], [lerp(0, -4, k), lerp(8, 9, k), lerp(-6, -12, k)]);
      return { bloom: 0.65, flare: 1.0, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const cutS = at(6, 'stored') - 0.1;
const S = [
  [0, ls(1), sMelt], [ls(1), ls(2), sReveal], [ls(2), ls(3), sScale], [ls(3), ls(4), sQanat], [ls(4), ls(5), sShade],
  [ls(5), ls(6), sFreeze], [ls(6), cutS, sCut], [cutS, ls(7), sStore], [ls(7), ls(8), sWall], [ls(8), ls(9), sSarooj],
  [ls(9), ls(10), sHeat], [ls(10), ls(11), sAir], [ls(11), ls(12), sTrench], [ls(12), ls(13), sFaloodeh], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
