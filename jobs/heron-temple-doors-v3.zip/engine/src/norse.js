// Viking navigation reel: rolling sea, longship (hull, striped sail, dragon prow, shields), navigator,
// sun-compass disc (whole + broken half), Iceland spar crystal, shipwreck timbers + dividers, ravens, icebergs, coast.
import * as THREE from 'three';
import { SKY_PRESETS, TIME, NOISE } from './world.js';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';

SKY_PRESETS.north = { zenith: 0x3a62a0, horizon: 0xc6d2dc, ground: 0x4a5a5a, sunColor: 0xfff0dc, cloud: 0.45, haze: 0xb8c6d0, sunI: 3.6 };
SKY_PRESETS.storm = { zenith: 0x4a5462, horizon: 0x9aa4ac, ground: 0x3a4246, sunColor: 0xe8ecf0, cloud: 0.95, haze: 0x8a949c, sunI: 1.6 };

// ---------- sea: displaced plane, waves evaluated identically on CPU (for bobbing) and in the shader ----------
const WAVES = [[0.18, 0.9, 0.0, 1.0], [0.12, 1.4, 0.8, 0.7], [0.07, 2.3, 2.1, 1.3], [0.04, 3.7, 4.0, 1.9]]; // amp, k, dir, speed
export function waveH(x, z, t, s = 1) { let h = 0; for (const [a, k, d, w] of WAVES) h += a * s * Math.sin(k * (x * Math.cos(d) + z * Math.sin(d)) + t * w * 1.6); return h; }
export function sea(scene, { size = 600, color = 0x2a4a5a, scale = 1 } = {}) {
  const geo = new THREE.PlaneGeometry(size, size, 1, 1);
  const near = new THREE.PlaneGeometry(80, 80, 220, 220);
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.18, metalness: 0.1 });
  const U = { uS: { value: scale } };
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = TIME; sh.uniforms.uS = U.uS;
    const W = WAVES.map(([a, k, d, w]) => `h += ${a.toFixed(3)} * uS * sin(${k.toFixed(3)} * (p.x * ${Math.cos(d).toFixed(4)} + p.z * ${Math.sin(d).toFixed(4)}) + uTime * ${(w * 1.6).toFixed(3)});`).join('\n');
    sh.vertexShader = sh.vertexShader.replace('#include <common>', `#include <common>\nuniform float uTime, uS; varying vec3 vWP4;\nfloat wh(vec3 p){ float h = 0.0; ${W} return h; }`)
      .replace('#include <begin_vertex>', `#include <begin_vertex>\nvec3 wp0 = (modelMatrix * vec4(transformed, 1.0)).xyz; transformed.z += wh(wp0);`)
      .replace('#include <project_vertex>', '#include <project_vertex>\nvWP4 = (modelMatrix * vec4(transformed, 1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWP4; uniform float uTime, uS;\n${NOISE}`)
      .replace('#include <normal_fragment_maps>', `#include <normal_fragment_maps>
        vec3 dx = dFdx(vWP4), dy = dFdy(vWP4); vec3 n = normalize(cross(dx, dy));
        vec2 q = vWP4.xz * 3.0 + vec2(uTime * 0.5, uTime * 0.3);
        float h0 = fbm(q), hx = fbm(q + vec2(0.1, 0.0)), hz = fbm(q + vec2(0.0, 0.1));
        n = normalize(n + vec3(h0 - hx, 0.0, h0 - hz) * 0.6);
        normal = normalize((viewMatrix * vec4(n, 0.0)).xyz);`)
      .replace('#include <color_fragment>', `#include <color_fragment>
        float foam = smoothstep(0.3, 0.5, vWP4.y / max(uS, 0.3)) * smoothstep(0.35, 0.75, fbm(vWP4.xz * 4.0 + uTime * 0.6));
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.82, 0.88, 0.9), foam * 0.45);`);
  };
  const far = new THREE.Mesh(geo, mat); far.rotation.x = -Math.PI / 2; far.position.y = -0.02; scene.add(far);
  const nm = new THREE.Mesh(near, mat); nm.rotation.x = -Math.PI / 2; scene.add(nm);
  nm.receiveShadow = true;
  // below-horizon sky = far sea colour, so no green/brown band shows past the edge of the water
  const sk = scene.userData.sky && scene.userData.sky.material.uniforms;
  if (sk && sk.uGround) sk.uGround.value = new THREE.Color(color).lerp(scene.fog ? scene.fog.color : sk.uHorizon.value, 0.45);
  return { mat, near: nm, U };
}

// ---------- longship ----------
let NM = null;
function norseMats() {
  if (NM) return NM;
  const planks = canvasTex(256, 128, (x) => {
    x.fillStyle = '#6a4a2c'; x.fillRect(0, 0, 256, 128); const R = rng(3);
    for (let j = 0; j < 8; j++) { x.fillStyle = `hsl(28,${35 + R() * 10}%,${22 + R() * 10}%)`; x.fillRect(0, j * 16 + 1, 256, 14); x.fillStyle = 'rgba(0,0,0,0.35)'; x.fillRect(0, j * 16 + 14, 256, 2); for (let i = 0; i < 6; i++) { x.fillStyle = 'rgba(30,20,10,0.6)'; x.beginPath(); x.arc(i * 44 + (j % 2) * 22, j * 16 + 8, 1.2, 0, 7); x.fill(); } }
  }, [3, 1]);
  const sail = canvasTex(128, 128, (x) => { for (let i = 0; i < 8; i++) { x.fillStyle = i % 2 ? '#f0e6d0' : '#b8302a'; x.fillRect(i * 16, 0, 16, 128); } const R = rng(5); for (let i = 0; i < 400; i++) { x.fillStyle = `rgba(80,60,40,${R() * 0.08})`; x.fillRect(R() * 128, R() * 128, 2, 2); } });
  NM = {
    hull: new THREE.MeshStandardMaterial({ map: planks, roughness: 0.75, side: THREE.DoubleSide }),
    wood: new THREE.MeshStandardMaterial({ color: 0x5a3a20, roughness: 0.8 }),
    sail: new THREE.MeshStandardMaterial({ map: sail, roughness: 0.9, side: THREE.DoubleSide }),
    rope: new THREE.MeshStandardMaterial({ color: 0xb89a6a, roughness: 0.9 }),
    iron: new THREE.MeshStandardMaterial({ color: 0x4a4a4e, metalness: 0.8, roughness: 0.4 }),
  };
  return NM;
}
// L ~ 16 m, W ~ 3.6 m. +x is forward.
export function longship({ L = 16, W = 3.6, D = 1.3 } = {}) {
  const M = norseMats(); const g = new THREE.Group();
  const nu = 60, nv = 20;
  const pos = [], uv = [], idx = [];
  const halfW = (u) => W / 2 * Math.pow(Math.sin(Math.PI * u), 0.55);
  const sheer = (u) => D * 0.55 + 1.1 * Math.pow(Math.abs(2 * u - 1), 3.2);
  const depth = (u) => D * Math.pow(Math.sin(Math.PI * u), 0.4);
  for (let i = 0; i <= nu; i++) { const u = i / nu; for (let j = 0; j <= nv; j++) { const v = -1 + 2 * j / nv; const a = v * Math.PI / 2; pos.push((u - 0.5) * L, sheer(u) - depth(u) * Math.cos(a), halfW(u) * Math.sin(a)); uv.push(u * 3, Math.abs(v)); } }
  for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) { const a = i * (nv + 1) + j, b = a + nv + 1; idx.push(a, b, a + 1, b, b + 1, a + 1); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); geo.setIndex(idx); geo.computeVertexNormals();
  const hull = new THREE.Mesh(geo, M.hull); g.add(hull);
  // deck boards
  const deck = new THREE.Mesh(new THREE.BoxGeometry(L * 0.78, 0.06, W * 0.8), M.wood); deck.position.y = 0.35; g.add(deck);
  // dragon prow + stern curl
  for (const s of [1, -1]) {
    const c = new THREE.QuadraticBezierCurve3(new THREE.Vector3(s * L * 0.47, sheer(s > 0 ? 0.97 : 0.03) - 0.2, 0), new THREE.Vector3(s * L * 0.53, sheer(1) + 0.6, 0), new THREE.Vector3(s * L * 0.5, sheer(1) + 1.5, 0));
    g.add(new THREE.Mesh(new THREE.TubeGeometry(c, 20, 0.12, 8), M.wood));
    if (s > 0) {
      const head = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.7, 8), M.wood); head.rotation.z = -Math.PI / 2; head.position.set(L * 0.53, sheer(1) + 1.5, 0); g.add(head);
      for (const zz of [-0.1, 0.1]) { const eye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), new THREE.MeshStandardMaterial({ color: 0xe8c040, emissive: 0x403000 })); eye.position.set(L * 0.5 + 0.05, sheer(1) + 1.6, zz); g.add(eye); }
    } else { const curl = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.08, 8, 16, Math.PI * 1.4), M.wood); curl.position.set(-L * 0.5 - 0.1, sheer(1) + 1.5, 0); g.add(curl); }
  }
  // shields along both rails
  const sc = [0xb8302a, 0xe8d040, 0x2a5a8a, 0xf0e6d0];
  for (const s of [-1, 1]) for (let i = 0; i < 9; i++) { const u = 0.22 + i * 0.07; const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.04, 20), new THREE.MeshStandardMaterial({ color: sc[i % 4], roughness: 0.6 })); sh.rotation.x = Math.PI / 2; sh.position.set((u - 0.5) * L, sheer(u) - 0.15, s * (halfW(u) + 0.03)); g.add(sh); const boss = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), M.iron); boss.position.copy(sh.position); boss.position.z += s * 0.03; g.add(boss); }
  // mast, yard, sail (billowed plane)
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 8, 10), M.wood); mast.position.set(0, 4.3, 0); g.add(mast);
  const yard = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 6.4, 8), M.wood); yard.rotation.x = Math.PI / 2; yard.position.set(0.05, 7.6, 0); g.add(yard);
  const sg = new THREE.PlaneGeometry(6.2, 4.6, 20, 14); const sp = sg.attributes.position;
  for (let i = 0; i < sp.count; i++) { const x = sp.getX(i) / 3.1, y = (sp.getY(i) + 2.3) / 4.6; sp.setZ(i, 0.9 * (1 - x * x) * Math.sin(Math.PI * Math.min(1, y * 1.1))); }
  sg.computeVertexNormals();
  const sail = new THREE.Mesh(sg, M.sail); sail.rotation.y = Math.PI / 2; sail.position.set(0.15, 5.3, 0); g.add(sail);
  for (const s of [-1, 1]) { const st = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 8.5, 4), M.rope); st.position.set(0, 4, s * 1.6); st.rotation.x = s * 0.2; g.add(st); }
  g.sheerAt = sheer; g.L = L;
  return shadowAll(g);
}
// ship rides the waves: set position + pitch/roll from the shared wave function
export function rideWaves(ship, x, z, heading, t, s = 1) {
  const h = waveH(x, z, t, s); const L = 6;
  const hf = waveH(x + Math.cos(heading) * L, z - Math.sin(heading) * L, t, s), hb = waveH(x - Math.cos(heading) * L, z + Math.sin(heading) * L, t, s);
  const hl = waveH(x - Math.sin(heading) * 1.5, z - Math.cos(heading) * 1.5, t, s), hr = waveH(x + Math.sin(heading) * 1.5, z + Math.cos(heading) * 1.5, t, s);
  ship.position.set(x, h - 0.15, z);
  ship.rotation.set(0, heading, 0); ship.rotateZ(Math.atan2(hf - hb, 2 * L)); ship.rotateX(Math.atan2(hl - hr, 3) * 0.6);
}

// ---------- navigator: tunic, cloak, round iron helmet (no horns), beard ----------
export function viking({ color = 0x4a6a4a, cloak = 0x8a2a24, helmet = true } = {}) {
  const h = romanBuilder({ color, skin: 0xe0a888 });
  const M = norseMats();
  const cm = new THREE.MeshStandardMaterial({ color: cloak, roughness: 0.95, bumpMap: fabricTexture(41), bumpScale: 2, side: THREE.DoubleSide });
  const cl = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.36, 0.95, 24, 4, true, Math.PI * 0.75, Math.PI * 1.5), cm); cl.position.set(0, -0.12, -0.02); cl.scale.z = 0.75; h.j.chest.add(cl);
  const brooch = new THREE.Mesh(new THREE.TorusGeometry(0.03, 0.01, 6, 16), new THREE.MeshStandardMaterial({ color: 0xd8b040, metalness: 0.8, roughness: 0.3 })); brooch.position.set(0.12, 0.3, 0.12); h.j.chest.add(brooch);
  const beard = new THREE.Mesh(new THREE.SphereGeometry(0.11, 16, 12, 0, Math.PI * 2, Math.PI * 0.45, Math.PI * 0.55), new THREE.MeshStandardMaterial({ color: 0xa8682c, roughness: 0.9, bumpMap: fabricTexture(3), bumpScale: 4 }));
  beard.position.set(0, -0.085, 0.07); beard.scale.set(0.75, 0.9, 0.6); h.j.head.add(beard);
  if (helmet) { const hm = new THREE.Mesh(new THREE.SphereGeometry(0.165, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), M.iron); hm.position.y = 0.04; hm.scale.set(1, 1.05, 1.1); h.j.head.add(hm); const nose = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.11, 0.02), M.iron); nose.position.set(0, 0.0, 0.17); h.j.head.add(nose); }
  return shadowAll(h.root), h;
}

// ---------- sun compass disc (Uunartoq-style): wooden disc, notched rim, gnomon, engraved lines ----------
export function sunCompass({ broken = false } = {}) {
  const g = new THREE.Group();
  const tex = canvasTex(256, 256, (x) => {
    x.fillStyle = '#8a6438'; x.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 30; i++) { x.strokeStyle = `rgba(60,40,20,${0.2 + (i % 3) * 0.1})`; x.beginPath(); x.arc(128, 128, 20 + i * 3.5, 0, 7); x.stroke(); }
    x.strokeStyle = 'rgba(40,25,10,0.9)'; x.lineWidth = 2;
    x.beginPath(); for (let a = 0; a <= 6.3; a += 0.05) { const r = 40 + 35 * Math.abs(Math.cos(a)); const px = 128 + Math.cos(a) * r, py = 128 + Math.sin(a) * r; a === 0 ? x.moveTo(px, py) : x.lineTo(px, py); } x.stroke();
    x.beginPath(); x.moveTo(128, 20); x.lineTo(128, 236); x.stroke();
  });
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.006, 48, 1, false, 0, broken ? Math.PI : Math.PI * 2), [new THREE.MeshStandardMaterial({ color: 0x6a4a28, roughness: 0.8 }), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.75 }), new THREE.MeshStandardMaterial({ color: 0x6a4a28 })]);
  g.add(disc);
  // notches on the rim
  const nm = new THREE.MeshStandardMaterial({ color: 0x4a3018 });
  const n = broken ? 16 : 32; for (let i = 0; i < n; i++) { const a = i / 32 * Math.PI * 2; const b = new THREE.Mesh(new THREE.BoxGeometry(0.003, 0.0065, 0.004), nm); b.position.set(Math.sin(a) * 0.034, 0, Math.cos(a) * 0.034); b.rotation.y = a; g.add(b); }
  if (!broken) { const gn = new THREE.Mesh(new THREE.ConeGeometry(0.004, 0.03, 8), new THREE.MeshStandardMaterial({ color: 0x5a3a1c })); gn.position.y = 0.018; g.add(gn); const hd = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.05, 10), new THREE.MeshStandardMaterial({ color: 0x5a3a1c })); hd.position.y = -0.028; g.add(hd); }
  g.scale.setScalar(4); // ~28 cm across in world units
  return shadowAll(g);
}
// ---------- Iceland spar: clear rhombohedron ----------
export function icelandSpar(s = 0.06) {
  const geo = new THREE.BoxGeometry(s, s * 0.7, s * 0.8);
  const m = new THREE.Matrix4().makeShear(0.35, 0, 0.25, 0, 0, 0); geo.applyMatrix4(m);
  const mesh = new THREE.Mesh(geo, new THREE.MeshPhysicalMaterial({ color: 0xf6fbff, roughness: 0.02, transmission: 0.95, thickness: s, ior: 1.66, clearcoat: 1, iridescence: 0.3, transparent: true }));
  mesh.castShadow = true;
  return mesh;
}
// ---------- dividers (navigation tool) ----------
export function dividers() {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0x5a6a5a, metalness: 0.6, roughness: 0.6 });
  for (const s of [-1, 1]) { const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.001, 0.16, 6), m); leg.position.set(s * 0.025, 0, 0); leg.rotation.z = s * 0.3; g.add(leg); }
  const top = new THREE.Mesh(new THREE.SphereGeometry(0.008, 8, 6), m); top.position.y = 0.078; g.add(top);
  return shadowAll(g);
}
// ---------- ravens ----------
export function raven(s = 1) {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0x14141a, roughness: 0.5, metalness: 0.2 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.06, 0.18, 6, 10), m); body.rotation.z = Math.PI / 2; g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.055, 12, 10), m); head.position.x = 0.16; g.add(head);
  const beak = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.08, 8), m); beak.rotation.z = -Math.PI / 2; beak.position.x = 0.23; g.add(beak);
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.14, 4), m); tail.rotation.z = Math.PI / 2; tail.scale.z = 0.3; tail.position.x = -0.18; g.add(tail);
  const wings = [-1, 1].map(sd => { const p = new THREE.Group(); g.add(p); const w = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.01, 0.34), m); w.position.z = sd * 0.17; p.add(w); return [p, sd]; });
  g.flap = (t, k = 1) => wings.forEach(([p, sd]) => { p.rotation.x = sd * Math.sin(t * 14) * 0.7 * k; });
  g.scale.setScalar(s);
  return shadowAll(g);
}
// ---------- icebergs and a coast ----------
export function iceberg(s = 1, seed = 1) {
  // a few smooth, chunky ice masses fused together, flat-ish top, translucent blue-white
  const R = rng(seed); const g = new THREE.Group();
  const m = new THREE.MeshPhysicalMaterial({ color: 0xeef8ff, roughness: 0.28, clearcoat: 0.6, transmission: 0.15, thickness: 2, attenuationColor: new THREE.Color(0x8fd0ee), attenuationDistance: 3, emissive: 0x3a7a9a, emissiveIntensity: 0.12 });
  for (let k = 0; k < 4; k++) {
    const geo = new THREE.IcosahedronGeometry(1, 4); const p = geo.attributes.position;
    const f = [R() * 6, R() * 6, R() * 6];
    for (let i = 0; i < p.count; i++) {
      let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      const n = 1 + 0.12 * Math.sin(x * 3 + f[0]) * Math.sin(z * 2.6 + f[1]) + 0.06 * Math.sin(y * 5 + f[2]);
      x *= n; z *= n; y = y > 0.35 ? 0.35 + (y - 0.35) * 0.25 : y; // flattened top
      p.setXYZ(i, x * 1.25, Math.max(-0.6, y) * 1.1, z);
    }
    geo.computeVertexNormals();
    const b = new THREE.Mesh(geo, m); const sc = 0.55 + R() * 0.5; b.scale.setScalar(sc); b.position.set((R() - 0.5) * 1.6, (sc - 0.8) * 0.6, (R() - 0.5) * 1.2); b.rotation.y = R() * 3; g.add(b);
  }
  g.scale.setScalar(s); return g;
}
export function coast({ x = 0, z = -120, w = 260, h = 26, seed = 4, snow = true } = {}) {
  const g = new THREE.Group(); const R = rng(seed);
  const rockM = new THREE.MeshStandardMaterial({ color: 0x4a4a46, roughness: 1, flatShading: true });
  const greenM = new THREE.MeshStandardMaterial({ color: 0x5a7040, roughness: 1, flatShading: true });
  const snowM = new THREE.MeshStandardMaterial({ color: 0xf2f6f8, roughness: 0.6, flatShading: true });
  for (let i = 0; i < 18; i++) {
    const xx = x - w / 2 + i * w / 17 + (R() - 0.5) * 8, hh = h * (0.5 + R() * 0.8);
    const m = new THREE.Mesh(new THREE.ConeGeometry(hh * 1.3, hh, 7), i % 3 ? rockM : greenM); m.position.set(xx, hh / 2 - 2, z + (R() - 0.5) * 20); m.rotation.y = R() * 3; g.add(m);
    if (snow && hh > h * 0.9) { const c = new THREE.Mesh(new THREE.ConeGeometry(hh * 0.45, hh * 0.35, 7), snowM); c.position.set(xx, hh - 2 - hh * 0.17, m.position.z); c.rotation.y = m.rotation.y; g.add(c); }
  }
  return g;
}
export { norseMats };
