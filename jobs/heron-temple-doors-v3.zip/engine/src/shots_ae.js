// al-Jazari elephant clock reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite, sparks } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { gearScroll } from './chariot.js';
import { smith } from './damascus.js';
import { elephantClock, palace } from './elephant.js';
import { VO } from './vo_ae.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['In *1206*', 4], ['an *engineer*', 2], ['built a *clock*', 3], ['that was also', 3], ['an *elephant*', 2]],
  [['But this clock', 3], ['had *no springs*', 3], ['and *no pendulum*', 3], ['It ran on *water*', 4]],
  [['His name was', 3], ['*al-Jazari*', 2], ['and he worked', 3], ['for a *royal court*', 4], ['in what is now', 4], ['*Turkey*', 1]],
  [['Inside the elephant', 3], ['sat a *tank of water*', 5], ['with a *bowl*', 3], ['floating on top', 3]],
  [['The bowl had', 3], ['a *tiny hole*', 3], ['in its bottom', 3], ['so it slowly', 3], ['*filled* and *sank*', 3]],
  [['It took about', 3], ['*half an hour*', 3], ['to sink', 2]],
  [['As it went down', 4], ['*strings* pulled', 2], ['a little *scribe*', 3], ["on the elephant's back", 4], ['and his *pen*', 3], ['marked the *minutes*', 3]],
  [['When the bowl', 3], ['reached the *bottom*', 3], ['it *released a ball*', 4], ['from the *tower*', 3], ['on top', 2]],
  [['A *bird*', 2], ['on the tower', 3], ['*whirled* and *whistled*', 3]],
  [['The ball', 2], ['*rolled down*', 2], ['into a *vase*', 3], ['and the elephant driver', 4], ['struck a *cymbal*', 3]],
  [['That same motion', 3], ['*tipped the bowl*', 3], ['*emptied* it', 2], ['and started', 2], ['the half hour', 3], ['*again*', 1]],
  [['Its design', 2], ['mixed *styles*', 2], ['from *India*', 2], ['*Persia*', 1], ['*China*', 1], ['*Egypt* and *Greece*', 3]],
  [['*Modern builders*', 2], ['have made', 2], ['*working copies*', 2], ['from his *drawings*', 3]],
  [['A *clock*', 2], ['a *robot*', 2], ['and an *elephant*', 3], ['all powered by', 3], ['*dripping water*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function court(makeStage, { preset = 'golden', sunDir = [0.6, 0.45, 0.7], ghost = false } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog: 0.004, shadowSize: 7, shadowAt: [0, 2, 0], envI: 0.95 });
  palace(scene); fillLight(scene, [0.3, 0.4, 1], 0.6, 0xffe6c8);
  const E = elephantClock({ ghost }); scene.add(E);
  return { scene, E };
}
function studio(makeStage, ghost = true) {
  const scene = makeStage({ shadowSize: 5, sunDir: [-2, 6, 4], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x1a2230); u.mid.value.set(0x26303e); u.horizon.value.set(0x34404e); u.floorC.value.set(0x141a22);
  const E = elephantClock({ ghost }); scene.add(E);
  fillLight(scene, [0.5, 0.3, 1], 0.8);
  return { scene, E };
}

// ============ S0: the elephant clock in a palace courtyard ============
function sHook({ makeStage }) {
  const { scene, E } = court(makeStage);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: 0.3, birdA: t * 0.5 });
      const a = lerp(1.2, 0.6, easeInOut(range(t, 0, 5)));
      place(c, [Math.sin(a) * 12, lerp(2.6, 4.0, easeInOut(range(t, 0, 5))), Math.cos(a) * 12], [0.3, 3.0, 0]);
      return { bloom: 0.6, flare: 0.7, warm: 1.3 };
    },
  };
}
// ============ S1: no springs, no pendulum: it runs on water (drips) ============
function sWater({ makeStage, start: ST }) {
  const tW = at(1, 'water') - ST;
  const { scene, E } = court(makeStage);
  const drops = [...Array(6)].map(() => { const d = glowSprite(0x8ad0ff, 0.18); scene.add(d); return d; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: 0.35, birdA: 0 });
      const show = easeOut(range(t, tW - 0.6, tW));
      drops.forEach((d, i) => { const u = (t * 0.8 + i / 6) % 1; d.position.set(0.0, 3.5 - u * 1.4, 1.2); d.material.opacity = show * Math.sin(u * Math.PI); });
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(1.5, 1.0, k), lerp(3.4, 3.0, k), lerp(9.5, 8.0, k)], [0.3, 2.9, 0]);
      return { bloom: 0.6, warm: 1.25 };
    },
  };
}
// ============ S2: al-Jazari with his book of machines ============
function sAuthor({ makeStage }) {
  const { scene, E } = court(makeStage);
  const A = smith(2); A.root.position.set(-1.0, 0, 3.4); A.root.rotation.y = 0.3; scene.add(A.root);
  const book = gearScroll(); book.scale.setScalar(0.35); book.visible = false; scene.add(book);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: 0.4 });
      standPose(A, t, { lSh: [-1.1, 0, 0.2], rSh: [-1.1, 0, -0.2], lEl: [-0.5, 0, 0], rEl: [-0.5, 0, 0], head: [-0.05, 0.2, 0] }); A.setMood('happy'); A.setMouth(0); A.blink(blinkK(t, [1.5, 4.0]));
      scene.updateMatrixWorld(true); const hp = A.j.rWr.getWorldPosition(V(0, 0, 0)); book.position.set(hp.x + 0.15, hp.y + 0.05, hp.z + 0.1); book.rotation.set(-0.8, 0.8, 0);
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(-3.2, -2.4, k), lerp(2.2, 2.4, k), lerp(9.5, 8.5, k)], [-0.6, 2.0, 1.8]);
      return { bloom: 0.55, flare: 0.6, warm: 1.3 };
    },
  };
}
// ============ S3/S4: inside: a tank with a floating bowl; the hole lets it fill and sink ============
function sTank({ makeStage }) {
  const { scene, E } = studio(makeStage);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: lerp(0.0, 0.1, range(t, 0, 4)) });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(3.5, 2.4, k), lerp(3.8, 3.0, k), lerp(9, 5.6, k)], [0, lerp(2.8, 2.2, k), 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
function sHole({ makeStage }) {
  const { scene, E } = studio(makeStage);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: lerp(0.1, 0.45, easeInOut(range(t, 0.3, 4.4))) });
      place(c, [1.2, lerp(2.8, 2.5, easeInOut(range(t, 0, 4.4))), 3.0], [0, lerp(2.3, 2.0, easeInOut(range(t, 0, 4.4))), 0]);
      return { bloom: 0.6, warm: 1.1 };
    },
  };
}
// ============ S5: about half an hour: time-lapse, the bowl sinks, the scribe's pen turns ============
function sHalf({ makeStage }) {
  const { scene, E } = studio(makeStage);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: lerp(0.45, 0.7, easeInOut(range(t, 0, 2.6))) });
      place(c, [lerp(3.2, 3.6, easeInOut(range(t, 0, 2.6))), 3.0, 5.4], [0.2, 2.8, 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
// ============ S6: strings pull the scribe; his pen marks the minutes ============
function sScribe({ makeStage }) {
  const { scene, E } = court(makeStage);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: lerp(0.4, 0.75, easeInOut(range(t, 0, 6))) });
      const k = easeInOut(range(t, 0, 6));
      place(c, [lerp(2.8, 2.4, k), lerp(4.6, 4.4, k), lerp(3.4, 2.9, k)], [0.6, 3.6, 0.15]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S7: the bowl reaches the bottom: a ball is released from the tower ============
function sRelease({ makeStage, start: ST }) {
  const tR = at(7, 'released') - ST;
  const { scene, E } = court(makeStage);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: lerp(0.85, 1, range(t, 0, tR)), ballU: range(t, tR, tR + 3.0) * 0.6, birdA: 0 });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-1.6, -0.6, k), lerp(5.6, 5.2, k), lerp(5.0, 4.4, k)], [0.1, lerp(4.6, 4.0, k), 0.2]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S8: the bird on the tower whirls and whistles ============
function sBird({ makeStage }) {
  const { scene, E } = court(makeStage);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: 1, birdA: t * 6, ballU: 0.6 + range(t, 0, 2.6) * 0.15 });
      place(c, [lerp(1.8, 1.2, easeInOut(range(t, 0, 2.6))), 6.6, 3.4], [-0.5, 5.8, 0]);
      return { bloom: 0.6, warm: 1.3 };
    },
  };
}
// ============ S9: ball into the vase; the driver strikes the cymbal ============
function sCymbal({ makeStage, start: ST }) {
  const tC = at(9, 'cymbal') - ST;
  const { scene, E } = court(makeStage);
  const sp = sparks(30, { speed: 1, spread: 1.5, life: 0.35, size: 0.03, color: [1, 0.9, 0.5] }); scene.add(sp);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const strike = easeIn(range(t, tC - 0.4, tC)); E.set({ sink: 1, ballU: 0.75 + range(t, 0, tC - 0.5) * 0.25, strike: t > tC + 0.2 ? 1 - range(t, tC + 0.2, tC + 0.8) : strike });
      sp.position.copy(E.cymbal.position); sp.update(t - tC);
      const s = shake(t, Math.max(0, 1 - Math.abs(t - tC) * 4) * 4, 3);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(4.6, 4.0, k) + s[0], lerp(4.6, 4.3, k) + s[1], lerp(4.0, 3.4, k)], [1.4, 3.5, 0.1]);
      return { bloom: 0.65, warm: 1.3 };
    },
  };
}
// ============ S10: the bowl tips, empties and floats up: the cycle restarts ============
function sReset({ makeStage }) {
  const { scene, E } = studio(makeStage);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const tip = Math.sin(Math.PI * range(t, 0.3, 2.0)); const up = easeInOut(range(t, 1.6, 3.8));
      E.set({ sink: 1 - up, tip, flow: t > 3.6 });
      place(c, [1.8, 2.9, lerp(5.6, 4.8, easeInOut(range(t, 0, 4.5)))], [0, 2.2, 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
// ============ S11: styles from many cultures: orbit, with glints on each part ============
function sStyles({ makeStage, start: ST }) {
  const { scene, E } = court(makeStage);
  const words = ['india', 'persia', 'china', 'egypt', 'greece'].map(w => at(11, w) - ST);
  const spots = [[1.9, 2.8, 0.8], [-0.1, 2.95, 0.95], [-0.5, 5.2, 0.4], [-0.5, 5.9, 0], [0, 2.1, 1.0]];
  const gl = spots.map(p => { const s = glowSprite(0xffe080, 0.9); s.position.set(...p); scene.add(s); return s; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: 0.3, birdA: t * 0.6 });
      gl.forEach((s, i) => { s.material.opacity = Math.max(0, 1 - Math.abs(t - words[i] - 0.2) * 2.5) * 0.9; });
      const a = lerp(0.2, 1.6, easeInOut(range(t, 0, 5)));
      place(c, [Math.sin(a) * 8.5, 3.4, Math.cos(a) * 8.5], [0.2, 3.0, 0]);
      return { bloom: 0.6, warm: 1.3 };
    },
  };
}
// ============ S12: a modern working copy in a big hall ============
function sCopy({ makeStage }) {
  const scene = makeStage({ shadowSize: 6, sunDir: [0.5, 5, 2], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x3a3020); u.mid.value.set(0x4a3a28); u.horizon.value.set(0x5a4830); u.floorC.value.set(0x2a2016);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshStandardMaterial({ color: 0xa89878, roughness: 0.5, metalness: 0.1 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const plinth = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.4, 0.5, 40), new THREE.MeshStandardMaterial({ color: 0x3a2a1a, roughness: 0.6 })); plinth.position.y = 0.25; scene.add(plinth);
  const E = elephantClock(); E.position.y = 0.5; scene.add(E);
  const spot = new THREE.SpotLight(0xfff0d8, 40, 14, 0.5, 0.5, 1.4); spot.position.set(3, 10, 5); spot.target.position.set(0, 2.5, 0); spot.castShadow = true; scene.add(spot, spot.target);
  const visitors = [smith(0), smith(1)]; visitors.forEach((v, i) => { v.root.position.set(-2.5 + i * 5, 0, 4); v.root.rotation.y = Math.PI + (i ? 0.5 : -0.5); scene.add(v.root); });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: 0.5, birdA: t * 0.5 });
      visitors.forEach((v, i) => { standPose(v, t + i, { head: [-0.2, 0, 0] }); v.setMood('happy'); v.setMouth(0); });
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(-3, -1.5, k), lerp(2.2, 2.6, k), lerp(11, 10, k)], [0.3, 3.0, 0]);
      return { bloom: 0.6, warm: 1.25 };
    },
  };
}
// ============ S13: sunset, pull back ============
function sEnd({ makeStage }) {
  const { scene, E } = court(makeStage, { sunDir: [0.75, 0.15, -0.6] });
  const b = birds(4, { from: [-20, 12, -20], to: [20, 14, -30], spread: 4, speed: 0.06, scale: 1.4, seed: 5 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      E.set({ sink: 0.2, birdA: t * 0.4 });
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(4, 7, k), lerp(3, 5, k), lerp(5, 11, k)], [0.2, lerp(3, 3.2, k), 0]);
      return { bloom: 0.7, flare: 1.0, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sWater], [ls(2), ls(3), sAuthor], [ls(3), ls(4), sTank], [ls(4), ls(5), sHole],
  [ls(5), ls(6), sHalf], [ls(6), ls(7), sScribe], [ls(7), ls(8), sRelease], [ls(8), ls(9), sBird], [ls(9), ls(10), sCymbal],
  [ls(10), ls(11), sReset], [ls(11), ls(12), sStyles], [ls(12), ls(13), sCopy], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
