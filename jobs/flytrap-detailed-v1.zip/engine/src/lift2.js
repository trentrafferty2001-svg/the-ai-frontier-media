// detail kit for lifts: board-formed concrete shaft with floor numbers, landing doors, rail brackets, conduit, lights;
// brushed-steel car with seams; 1854 hall backdrop with brick + arched windows and a plank floor
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as L from './lift.js';
export { counterweight, governor, cables, TOPY, std } from './lift.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const concreteTex = () => cv(512, 512, (g, w, h) => { g.fillStyle = '#b8b2a8'; g.fillRect(0, 0, w, h); const R = rnd(4);
  for (let i = 0; i < 9000; i++) { const v = 150 + R() * 70 | 0; g.fillStyle = `rgba(${v},${v - 4},${v - 10},0.35)`; g.fillRect(R() * w, R() * h, 1.5, 1.5); }
  for (let i = 0; i < 50; i++) { g.fillStyle = 'rgba(70,64,56,0.08)'; g.beginPath(); g.ellipse(R() * w, R() * h, 10 + R() * 50, 20 + R() * 80, 0, 0, 7); g.fill(); }
  g.strokeStyle = 'rgba(90,84,76,0.6)'; g.lineWidth = 2; for (let y = 0; y <= h; y += 128) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); } for (let x = 0; x <= w; x += 256) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); }
  g.fillStyle = 'rgba(60,56,50,0.7)'; for (let y = 64; y < h; y += 128) for (let x = 64; x < w; x += 128) { g.beginPath(); g.arc(x, y, 3, 0, 7); g.fill(); }
  for (let i = 0; i < 12; i++) { const x = R() * w; const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, 'rgba(90,80,64,0.25)'); gr.addColorStop(1, 'rgba(90,80,64,0)'); g.fillStyle = gr; g.fillRect(x, R() * h * 0.5, 2 + R() * 4, h * 0.4); } });
const brushedTex = () => cv(512, 512, (g, w, h) => { g.fillStyle = '#d8dce2'; g.fillRect(0, 0, w, h); const R = rnd(6); for (let i = 0; i < 1600; i++) { const v = 190 + R() * 60 | 0; g.strokeStyle = `rgba(${v},${v},${v + 6},0.4)`; g.lineWidth = 1; const y = R() * h; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y + (R() - 0.5) * 2); g.stroke(); }
  g.strokeStyle = 'rgba(80,88,98,0.7)'; g.lineWidth = 3; for (let x = 0; x <= w; x += 170) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); } });
const numTex = (n) => { const c = document.createElement('canvas'); c.width = 256; c.height = 256; const g = c.getContext('2d'); g.clearRect(0, 0, 256, 256); g.font = '900 170px Poppins, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = 'rgba(40,40,44,0.75)'; g.fillText(String(n), 128, 140); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; };
export function shaft() {
  const S = L.shaft(); const ct = concreteTex(); ct.repeat.set(2, 9);
  const seen = new Set(); S.group.traverse(o => { if (o.isMesh && o.material.color && o.material.color.getHex() === 0xb8b2a8 && !seen.has(o.material)) { seen.add(o.material); o.material.map = ct; o.material.bumpMap = ct; o.material.bumpScale = 1.2; o.material.color.set(0xffffff); o.material.needsUpdate = true; } });
  const G = S.group; const dark = new THREE.MeshStandardMaterial({ color: 0x4a5058, roughness: 0.5, metalness: 0.6 }), door = new THREE.MeshStandardMaterial({ color: 0x8a929c, roughness: 0.35, metalness: 0.7 });
  const conduit = new THREE.MeshStandardMaterial({ color: 0x9a9890, roughness: 0.4, metalness: 0.6 }); const lampM = new THREE.MeshBasicMaterial({ color: 0xfff2d0, toneMapped: false });
  for (let k = 1; k < 8; k++) { const y = k * 3.2;
    // floor number stencil on the back wall + landing door backs on both side walls
    const nm = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.9), new THREE.MeshBasicMaterial({ map: numTex(k), transparent: true, depthWrite: false })); nm.position.set(0.4, y + 0.9, -2.44); G.add(nm);
    [-1, 1].forEach(s => { const d = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.1, 1.3), door); d.position.set(s * 2.82, y + 1.05 - 3.2 + 0.2, 1.2); G.add(d); const fr = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.12, 1.5), dark); fr.position.set(s * 2.8, y - 3.2 + 2.35, 1.2); G.add(fr); });
    // lamp
    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.12, 0.08), lampM); lamp.position.set(1.8, y + 1.6, -2.42); G.add(lamp); }
  // rail brackets every 2 m
  for (let y = 1; y < L.TOPY; y += 4) [-1, 1].forEach(s => { const b = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.06, 0.16), dark); b.position.set(s * 2.1, y, 0); G.add(b); const bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.12, 8), conduit); bolt.rotation.z = Math.PI / 2; bolt.position.set(s * 1.48, y, 0.08); G.add(bolt); });
  // conduits running up the back wall
  [1.2, 1.35, 2.3].forEach(x => { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, L.TOPY + 2, 10), conduit); c.position.set(x, (L.TOPY + 2) / 2 - 1.5, -2.38); G.add(c); for (let y = 0; y < L.TOPY; y += 1.5) { const cl = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.05, 0.1), dark); cl.position.set(x, y, -2.4); G.add(cl); } });
  return S;
}
export function car() {
  const C = L.car(); const bt = brushedTex();
  C.group.traverse(o => { if (!o.isMesh) return; const c = o.material.color && o.material.color.getHex();
    if (c === 0xd9dde2) { o.material = new THREE.MeshStandardMaterial({ map: bt, roughness: 0.32, metalness: 0.75, color: 0xffffff }); }
    if (c === 0xaab2bc) { const t2 = bt.clone(); t2.needsUpdate = true; t2.repeat.set(0.5, 1); o.material = new THREE.MeshStandardMaterial({ map: t2, roughness: 0.22, metalness: 0.9, color: 0xc8ced6 }); } });
  // car-top railing, hatch, top light
  const G = C.group; const rail = new THREE.MeshStandardMaterial({ color: 0xf2c21a, roughness: 0.5, metalness: 0.3 });
  [[-1.05, -1], [1.05, -1], [-1.05, 0.95], [1.05, 0.95]].forEach(([x, z]) => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.9, 8), rail); p.position.set(x, 3.05, z); G.add(p); });
  [[0, -1, 2.1, 0], [0, 0.95, 2.1, 0]].forEach(([x, z, l]) => { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, l, 8), rail); b.rotation.z = Math.PI / 2; b.position.set(x, 3.5, z); G.add(b); });
  const hatch = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.03, 0.5), new THREE.MeshStandardMaterial({ color: 0x5a626c, roughness: 0.5, metalness: 0.6 })); hatch.position.set(0.3, 2.62, 0.2); G.add(hatch);
  // door indicator panel next to the doors
  const pn = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.5), new THREE.MeshStandardMaterial({ color: 0x20262e, emissive: 0x2a5a8a, emissiveIntensity: 0.6 })); pn.position.set(0.85, 1.3, 1.112); G.add(pn);
  return C;
}
export function demo() {
  const D = L.demo(); const wt = cv(256, 512, (g, w, h) => { g.fillStyle = '#8a5a32'; g.fillRect(0, 0, w, h); const R = rnd(2); for (let i = 0; i < 90; i++) { const x = R() * w; g.strokeStyle = R() < 0.5 ? 'rgba(90,54,26,0.28)' : 'rgba(170,120,70,0.22)'; g.lineWidth = 1 + R() * 2; g.beginPath(); g.moveTo(x, 0); for (let y = 0; y <= h; y += 32) g.lineTo(x + Math.sin(y * 0.02 + i) * 5, y); g.stroke(); } });
  const seen = new Set(); D.group.traverse(o => { if (o.isMesh && o.material.color && o.material.color.getHex() === 0x8a5a32 && !seen.has(o.material)) { seen.add(o.material); o.material.map = wt; o.material.bumpMap = wt; o.material.bumpScale = 1; o.material.color.set(0xffffff); o.material.needsUpdate = true; } });
  return D;
}
// 1854 exhibition hall: brick back wall with tall arched windows, iron columns, plank floor, a crowd of silhouettes
export function hall(scene) {
  const bt = cv(512, 512, (g, w, h) => { g.fillStyle = '#7a4a34'; g.fillRect(0, 0, w, h); const R = rnd(5); const bw = 64, bh = 24;
    for (let y = 0; y < h; y += bh) for (let x = -bw; x < w; x += bw) { const ox = ((y / bh) & 1) * bw / 2; const v = R(); g.fillStyle = `rgb(${120 + v * 40 | 0},${64 + v * 22 | 0},${44 + v * 14 | 0})`; g.fillRect(x + ox + 2, y + 2, bw - 4, bh - 4); } });
  bt.repeat.set(8, 3);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(60, 22), new THREE.MeshStandardMaterial({ map: bt, roughness: 0.9 })); wall.position.set(0, 11, -14); scene.add(wall);
  const winT = cv(128, 256, (g, w, h) => { g.fillStyle = '#e8e0c8'; g.beginPath(); g.moveTo(0, h); g.lineTo(0, w / 2); g.arc(w / 2, w / 2, w / 2, Math.PI, 0); g.lineTo(w, h); g.closePath(); g.fill(); g.strokeStyle = '#3a2a20'; g.lineWidth = 5; for (let x = w / 4; x < w; x += w / 4) { g.beginPath(); g.moveTo(x, 10); g.lineTo(x, h); g.stroke(); } for (let y = w / 2; y < h; y += 40) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); } });
  for (const k of [-3, -2, -1, 1, 2, 3]) { const wn = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 5.5), new THREE.MeshBasicMaterial({ map: winT, transparent: true, color: 0xd8ccb0 })); wn.position.set(k * 5, 9, -13.95); scene.add(wn); }
  const im = new THREE.MeshStandardMaterial({ color: 0x3a3e44, roughness: 0.5, metalness: 0.7 });
  [-12.5, -7.5, 7.5, 12.5].forEach(x => { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.22, 16, 12), im); c.position.set(x, 8, -12.5); scene.add(c); });
  const pt = cv(512, 512, (g, w, h) => { g.fillStyle = '#9a7048'; g.fillRect(0, 0, w, h); const R = rnd(3); for (let x = 0; x < w; x += 42) { g.fillStyle = `rgb(${140 + R() * 30 | 0},${100 + R() * 22 | 0},${64 + R() * 14 | 0})`; g.fillRect(x + 1, 0, 40, h); g.fillStyle = 'rgba(50,30,16,0.8)'; g.fillRect(x, 0, 2, h); } }); pt.repeat.set(8, 8);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 40), new THREE.MeshStandardMaterial({ map: pt, roughness: 0.8 })); floor.rotation.x = -Math.PI / 2; floor.position.set(0, -0.01, 6); scene.add(floor);
  const cm = new THREE.MeshStandardMaterial({ color: 0x24242c, roughness: 0.8 }); const hm = new THREE.MeshStandardMaterial({ color: 0xd8b8a0, roughness: 0.7 }); const R = rnd(9);
  for (let i = 0; i < 26; i++) { const a = -2.6 + R() * 2.0, r = 5 + R() * 3; const x = Math.cos(a) * r, z = -Math.sin(a) * r * 0.5 - 2.5; if (Math.abs(x) < 2.6) continue; const p = new THREE.Group(); const b = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.3, 1.2, 10), cm); b.position.y = 0.6; p.add(b); const hd = new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 10), hm); hd.position.y = 1.35; p.add(hd); if (R() < 0.6) { const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.28, 12), cm); hat.position.y = 1.58; p.add(hat); const br = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.02, 12), cm); br.position.y = 1.45; p.add(br); } p.position.set(x, 0, z); scene.add(p); }
}
