// The Explainer: how a chameleon changes colour. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { chameleon, branch, skinSection, ray, skinColour, std } from './chameleon2.js';
import { rnd } from './bolt.js';
import { trees } from './world.js';
import { groundMat, leafyTrees, bush, grass as grassBlades } from './hummer2.js';
import { label } from './gps.js';
import { VO } from './vo_ch2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*Chameleons*', 1], ['change *colour*', 2], ['using *tiny*', 2], ['*crystals*', 1], ['hidden in', 2], ['their *skin*', 2]],
  [['Under the surface', 3], ['are *cells*', 2], ['packed with', 2], ['these *crystals*', 2], ['lined up', 2], ['in a *neat grid*', 4]],
  [['When the', 2], ['chameleon', 1], ['is *calm*', 2], ['the crystals', 2], ['sit *close together*', 3], ['and reflect', 2], ['mostly *blue light*', 3]],
  [['That *blue* mixes', 3], ['with a *yellow*', 3], ['*pigment*', 1], ['in the top layer', 4], ['of skin', 2], ['so the chameleon', 3], ['looks *green*', 2]],
  [['When it gets', 3], ['*excited*', 1], ['it *stretches*', 2], ['its skin', 2], ['and the crystals', 3], ['*spread* further', 2], ['*apart*', 1]],
  [['Now they reflect', 3], ['*longer waves*', 2], ['of light', 2], ['like *yellow*', 2], ['*orange*', 1], ['and *red*', 2]],
  [["And it's mostly", 3], ['*not* about *hiding*', 3], ['Colour shows', 2], ['*mood*', 1], ['warns *rivals*', 2], ['and attracts', 2], ['*mates*', 1]],
  [['Some chameleons', 2], ['also turn', 2], ['*darker*', 1], ['to *soak up heat*', 4], ['on a', 2], ['*cold morning*', 2]],
  [['So their colours', 3], ['come from', 2], ['*spacing*', 1], ['not just', 2], ['*pigment*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 38) => { const c = cam(fov); c.near = 0.05; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.4, warm: 1.05, sat: 1.25, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

function jungle(makeStage, golden = false) {
  const scene = makeStage({ outdoor: golden ? 'golden' : 'day', sunDir: golden ? [0.9, 0.25, 0.4] : [0.5, 0.7, 0.6], fog: 0.018, shadowSize: 4, envI: 1.0, cloud: 0.3 });
  const spots = []; for (let k = 0; k < 60; k++) { const a = -0.4 - (k / 60) * 2.4, r = 14 + (k % 7) * 4; spots.push([Math.cos(a) * r, -6, Math.sin(a) * r]); } scene.add(leafyTrees(spots, { seed: 5, leaves: 1300, scale: 2.0 }));
  const gm = groundMat(); gm.map.repeat.set(60, 60); const gr = new THREE.Mesh(new THREE.CircleGeometry(120, 32), gm); gr.rotation.x = -Math.PI / 2; gr.position.y = -6; scene.add(gr);
  { const gb = grassBlades(9000, 0.5, 9, 61); gb.scale.setScalar(3); gb.position.y = -6; scene.add(gb); }
  { const R2 = rnd(77); const vm = new THREE.MeshStandardMaterial({ color: 0x3f6a2a, roughness: 0.8 }); for (let k = 0; k < 14; k++) { const x = (R2() - 0.5) * 26, z = -5 - R2() * 10; const pts = []; for (let i = 0; i <= 10; i++) pts.push(new THREE.Vector3(x + Math.sin(i * 0.7 + k) * 0.3, 9 - i * (0.9 + R2() * 0.4), z)); const v = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.05, 5), vm); scene.add(v); for (let i = 2; i < 10; i += 2) { const b = bush(200 + k * 10 + i, 40, 0.35); b.scale.setScalar(2); b.position.copy(pts[i]); scene.add(b); } } }
  { const R3 = rnd(78); for (let k = 0; k < 10; k++) { const b = bush(300 + k, 300, 1.2); b.scale.setScalar(2.2); b.position.set((R3() - 0.5) * 24, -6, -3 - R3() * 8); scene.add(b); } }
  const B = branch(); B.position.y = -1.32; scene.add(B);
  return scene;
}
// the lab: soft studio look for the skin section
function lab(makeStage) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x1a2a3a); u.mid.value.set(0x223446); u.horizon.value.set(0x2a3e52); u.floorC.value.set(0x101820); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xdfefff, 0x203040, 0.8));
  const S = skinSection(); S.group.scale.setScalar(0.55); scene.add(S.group);
  const IN = ray(), OUT = ray(); scene.add(IN.group, OUT.group);
  return { scene, S, IN, OUT };
}
const BLUE = new THREE.Color(0x3a8aff);
function reflected(k) { // colour of the reflected light from spacing k (no pigment)
  const st = [[0, 0x3a8aff], [0.45, 0xf2e23a], [0.7, 0xff9a2a], [1, 0xff3a1e]]; const c = new THREE.Color();
  for (let i = 0; i < st.length - 1; i++) { const [a, ca] = st[i], [b, cb] = st[i + 1]; if (k <= b) return c.set(ca).lerp(new THREE.Color(cb), (k - a) / (b - a)); } return c.set(st[3][1]);
}

// ============ S0 hook: a chameleon on a branch flashes from green through orange to red and back ============
function sHook({ makeStage }) {
  const scene = jungle(makeStage); const Ch = chameleon(); scene.add(Ch.group);
  const c = C(36);
  return {
    scene, camera: c,
    update(t) {
      Ch.st.k = 0.5 - 0.5 * Math.cos(Math.min(t, 3.6) * 1.75); Ch.update(t);
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0.4, 0.0, 0], lerp(9.5, 10.5, k), lerp(34, 22, k), lerp(8, 12, k));
      return POST;
    },
  };
}
// ============ S1-S5: the skin section ============
function sectionShot(cam0, cam1, fn) {
  return ({ makeStage }) => {
    const L = lab(makeStage); const ex = fn ? fn(L) : null; const c = C(38);
    return {
      scene: L.scene, camera: c,
      update(t, T) {
        if (ex) ex(t, T);
        const k = easeInOut(range(t, 0, 4.6));
        orb(c, cam0.tg.map((v, i) => lerp(v, cam1.tg[i], k)), lerp(cam0.d, cam1.d, k), lerp(cam0.az, cam1.az, k), lerp(cam0.el, cam1.el, k));
        return { ...POST, bloom: 0.55 };
      },
    };
  };
}
const A0 = new THREE.Vector3(-1.4, 2.7, 0.8), HIT = new THREE.Vector3(0, -0.25, 0.4), A1 = new THREE.Vector3(1.4, 2.7, 0.8);
const sCells = sectionShot({ tg: [0, 0, 0], d: 9, az: 30, el: 26 }, { tg: [0, -0.3, 0], d: 7, az: 18, el: 16 }, (L) => {
  const lb = tag(L.scene, 'crystals', 0.42, '#cfe6ff', [0, -1.55, 0.9]);
  return (t, T) => { L.S.spacing(0); L.IN.set(A0, HIT, 0); L.OUT.set(HIT, A1, 0); pop(lb, easeOut(range(T, at(1, 'crystals') - 0.15, at(1, 'crystals') + 0.2)), 0.42); };
});
const sCalm = sectionShot({ tg: [0, 1.0, 0], d: 10, az: 10, el: 10 }, { tg: [0, 1.0, 0], d: 10, az: -6, el: 8 }, (L) => {
  const lb = tag(L.scene, 'blue', 0.62, '#7fb6ff', [0, 3.2, 0.8]);
  return (t, T) => { L.S.spacing(0); L.IN.set(A0, HIT, easeOut(range(T, at(2, 'reflect') - 0.6, at(2, 'reflect') - 0.1)), new THREE.Color(0xffffff)); L.OUT.set(HIT, A1, easeOut(range(T, at(2, 'reflect') - 0.1, at(2, 'reflect') + 0.4)), BLUE); pop(lb, easeOut(range(T, at(2, 'blue') - 0.1, at(2, 'blue') + 0.2)), 0.62); };
});
const sGreen = sectionShot({ tg: [0, 1.0, 0], d: 10, az: -6, el: 8 }, { tg: [0, 1.0, 0], d: 10, az: 8, el: 10 }, (L) => {
  const lb = tag(L.scene, 'green', 0.62, '#7fe07a', [0, 3.2, 0.8]); const ly = tag(L.scene, 'yellow pigment', 0.3, '#ffe14a', [0, 1.0, 0.9]);
  return (t, T) => { L.S.spacing(0); L.IN.set(A0, HIT, 1, new THREE.Color(0xffffff)); const g = smooth(range(T, at(3, 'yellow') - 0.2, at(3, 'green'))); L.OUT.set(HIT, A1, 1, BLUE.clone().lerp(new THREE.Color(0x3fd04a), g));
    L.S.top.material.emissive = new THREE.Color(0xf2d22a); L.S.top.material.emissiveIntensity = 0.6 * smooth(range(T, at(3, 'yellow') - 0.2, at(3, 'pigment') + 0.2)) * (0.7 + 0.3 * Math.sin(T * 6));
    pop(ly, easeOut(range(T, at(3, 'yellow') - 0.1, at(3, 'yellow') + 0.2)) * (1 - range(T, at(3, 'chameleon'), at(3, 'chameleon') + 0.3)), 0.32); pop(lb, easeOut(range(T, at(3, 'green') - 0.1, at(3, 'green') + 0.2)), 0.62); };
});
const sSpread = sectionShot({ tg: [0, -0.3, 0], d: 6.5, az: 26, el: 18 }, { tg: [0, -0.3, 0], d: 7.5, az: 12, el: 12 }, (L) => {
  return (t, T) => { L.S.spacing(smooth(range(T, at(4, 'crystals') - 0.2, le(4) + 0.2))); L.IN.set(A0, HIT, 0); L.OUT.set(HIT, A1, 0); };
});
const sColours = sectionShot({ tg: [0, 1.0, 0], d: 10, az: 6, el: 8 }, { tg: [0, 1.0, 0], d: 10.5, az: -8, el: 10 }, (L) => {
  const lb = tag(L.scene, '', 0.45, '#ffffff', [2.9, 3.9, 1.2]); const L2 = label('yellow', { size: 0.45, color: '#ffe14a' });
  const words = [['yellow', 0.45, '#f2e23a'], ['orange', 0.72, '#ff9a2a'], ['red', 1.0, '#ff4a2a']].map(([w, k, col]) => { const s = tag(L.scene, w, 0.62, col, [0, 3.2, 0.8]); return { s, w, k }; });
  return (t, T) => {
    L.S.spacing(1); L.IN.set(A0, HIT, 1, new THREE.Color(0xffffff));
    let k = 0.45; words.forEach(({ w, k: kk }) => { if (T >= at(5, w) - 0.05) k = kk; });
    L.OUT.set(HIT, A1, easeOut(range(T, ls(5), ls(5) + 0.5)), reflected(k));
    words.forEach(({ s, w }, i) => { const on = T >= at(5, w) - 0.05 && (i === 2 || T < at(5, words[i + 1].w) - 0.05); pop(s, on ? 1 : 0, 0.62); }); pop(lb, 0, 0.45);
  };
});
// ============ S6: not about hiding: two males on a branch, one flares bright ============
function sRivals({ makeStage }) {
  const scene = jungle(makeStage); const A = chameleon(), B = chameleon(); scene.add(A.group, B.group);
  A.group.position.set(-2.2, 0, 0); B.group.position.set(2.2, 0, 0); B.group.rotation.y = Math.PI;
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      A.st.k = 0.05; B.st.k = smooth(range(T, at(6, 'mood') - 0.3, at(6, 'rivals'))) * (0.9 + 0.1 * Math.sin(T * 4)); A.update(T); B.update(T);
      const k = easeInOut(range(t, 0, 5.2));
      orb(c, [0.3, 0.2, 0], lerp(21, 20, k), lerp(14, 22, k), lerp(10, 6, k));
      return POST;
    },
  };
}
// ============ S7: dark on a cold morning to soak up heat ============
function sCold({ makeStage }) {
  const scene = jungle(makeStage, true); const Ch = chameleon(); scene.add(Ch.group);
  const c = C(36);
  return {
    scene, camera: c,
    update(t, T) {
      Ch.st.k = 0.1; Ch.st.dark = smooth(range(T, at(7, 'darker') - 0.3, at(7, 'darker') + 0.4)); Ch.update(T);
      const k = easeInOut(range(t, 0, 4.0));
      orb(c, [0.1, 0, 0], lerp(10.5, 9.5, k), lerp(-36, -24, k), lerp(6, 10, k));
      return { ...POST, warm: 1.2 };
    },
  };
}
// ============ S8: colour from spacing: chameleon cycles colours, crystals inset ============
function sEnd({ makeStage }) {
  const scene = jungle(makeStage); const Ch = chameleon(); scene.add(Ch.group);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      Ch.st.k = 0.5 - 0.5 * Math.cos(t * 1.4); Ch.update(T);
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0.4, 0.1, 0], lerp(9.5, 12.5, k), lerp(26, 36, k), lerp(8, 14, k));
      return POST;
    },
  };
}

const SH = [sHook, sCells, sCalm, sGreen, sSpread, sColours, sRivals, sCold, sEnd];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
