// detail kit for the flytrap: gland-dotted red lobes, veined green backs, sphagnum moss, terracotta pot
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as V from './flytrap.js';
export { fly, popper, std } from './flytrap.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
// inner face: deep red centre fading to a green-yellow rim, dense gland dots, faint radial veins (v = hinge -> rim)
const glandTex = () => cv(512, 512, (g, w, h) => { const gr = g.createLinearGradient(0, h, 0, 0); gr.addColorStop(0, '#b02030'); gr.addColorStop(0.7, '#d83a40'); gr.addColorStop(0.9, '#d8a040'); gr.addColorStop(1, '#a8c850'); g.fillStyle = gr; g.fillRect(0, 0, w, h); const R = rnd(4);
  g.strokeStyle = 'rgba(120,10,20,0.35)'; g.lineWidth = 2; for (let k = 0; k < 26; k++) { const x0 = w / 2 + (k - 13) * 6; g.beginPath(); g.moveTo(x0, h); g.quadraticCurveTo(x0 + (k - 13) * 10, h * 0.5, (k + 0.5) / 26 * w, 0); g.stroke(); }
  for (let i = 0; i < 2600; i++) { const x = R() * w, y = h * 0.12 + R() * h * 0.88; const r = 1.6 + R() * 2.2; g.fillStyle = R() < 0.6 ? 'rgba(240,80,80,0.5)' : 'rgba(120,10,20,0.4)'; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); } });
const leafTex = () => cv(512, 512, (g, w, h) => { const gr = g.createLinearGradient(0, h, 0, 0); gr.addColorStop(0, '#4a9a34'); gr.addColorStop(1, '#7ac04a'); g.fillStyle = gr; g.fillRect(0, 0, w, h); g.strokeStyle = 'rgba(30,80,20,0.5)'; g.lineWidth = 2.5;
  for (let k = 0; k < 18; k++) { const x0 = w / 2; g.beginPath(); g.moveTo(x0, h); g.quadraticCurveTo(x0 + (k - 9) * 14, h * 0.5, (k + 0.5) / 18 * w, 0); g.stroke(); } const R = rnd(7); for (let i = 0; i < 900; i++) { g.fillStyle = 'rgba(200,240,150,0.25)'; g.fillRect(R() * w, R() * h, 2, 2); } });
function dress(group) {
  const gt = tx('gland', glandTex), lt = tx('leaf', leafTex);
  group.traverse(o => { if (!o.isMesh) return; const m = o.material; if (!m.color) return; const c = m.color.getHex();
    if (c === 0xc8303a) { m.map = gt; m.bumpMap = gt; m.bumpScale = 0.8; m.color.set(0xffffff); m.roughness = 0.38; m.needsUpdate = true; }
    else if (c === 0x5ea83a && o.geometry.type === 'PlaneGeometry') { m.map = lt; m.bumpMap = lt; m.bumpScale = 0.6; m.color.set(0xffffff); m.needsUpdate = true; } });
}
export function trap(seed) { const T = V.trap(seed); dress(T.group); return T; }
export function plant() {
  const P = V.plant(); dress(P.group);
  // remove the blob moss, add sphagnum: star-topped stems
  P.group.children.filter(o => o.isMesh && o.material.color && o.material.color.getHex() === 0x5a8a2a).forEach(o => P.group.remove(o));
  const R = rnd(12); const n = 2200; const sg = new THREE.ConeGeometry(0.022, 0.08, 5); sg.translate(0, 0.04, 0);
  const sm = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85 }); const im = new THREE.InstancedMesh(sg, sm, n); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), c = new THREE.Color();
  for (let i = 0; i < n; i++) { const a = R() * 6.28, r = Math.sqrt(R()) * 1.5; e.set((R() - 0.5) * 0.6, R() * 6, (R() - 0.5) * 0.6); q.setFromEuler(e); M.compose(new THREE.Vector3(Math.cos(a) * r, 0.02, Math.sin(a) * r), q, new THREE.Vector3(1, 0.6 + R() * 0.8, 1)); im.setMatrixAt(i, M); im.setColorAt(i, c.setHSL(0.24 + R() * 0.07, 0.6, 0.16 + R() * 0.12)); }
  P.group.add(im);
  const sp = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(0.03, 1), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8 }), 900);
  for (let i = 0; i < 900; i++) { const a = R() * 6.28, r = Math.sqrt(R()) * 1.5; M.compose(new THREE.Vector3(Math.cos(a) * r, 0.06 + R() * 0.04, Math.sin(a) * r), q, new THREE.Vector3(1, 0.6, 1)); sp.setMatrixAt(i, M); sp.setColorAt(i, c.setHSL(0.2 + R() * 0.12, 0.6, 0.2 + R() * 0.15)); }
  P.group.add(sp);
  // terracotta pot texture
  const pt = cv(512, 128, (g, w, h) => { g.fillStyle = '#b0603a'; g.fillRect(0, 0, w, h); const R2 = rnd(2); for (let i = 0; i < 3000; i++) { const v = R2(); g.fillStyle = v < 0.5 ? 'rgba(140,70,40,0.35)' : 'rgba(210,140,100,0.3)'; g.fillRect(R2() * w, R2() * h, 2, 2); } g.fillStyle = 'rgba(240,230,210,0.25)'; for (let i = 0; i < 20; i++) g.fillRect(R2() * w, h * 0.7 + R2() * h * 0.3, 20 + R2() * 40, 3); });
  P.group.children.forEach(o => { if (o.isMesh && o.material.color && o.material.color.getHex() === 0xb0603a) { o.material.map = pt; o.material.bumpMap = pt; o.material.bumpScale = 0.6; o.material.color.set(0xffffff); o.material.needsUpdate = true; } });
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1.6, 0.09, 10, 48), new THREE.MeshStandardMaterial({ map: pt, roughness: 0.7 })); rim.rotation.x = Math.PI / 2; rim.position.y = 0.0; P.group.add(rim);
  return P;
}
