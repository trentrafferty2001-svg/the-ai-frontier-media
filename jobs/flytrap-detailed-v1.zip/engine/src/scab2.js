// The Explainer: how a scab forms. Microscopic skin cutaway: wound, vessel, red cells, platelets, fibrin, scab, repair.
// Units: 1 = 100 micrometres. Skin block spans x -6..6, top surface y = 0, z -3..3. Wound: V notch at x = 0 down to y = -2.2.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { TIME, NOISE } from './world.js';
import { rng } from './textures.js';

export const WD = 2.2, WW = 1.4; // wound depth and half-width at the top
const wallX = (y) => WW * (1 + y / WD) + 0.08; // half-width of the notch at height y (y from -WD to 0)

function tissueMat(c1, c2, scale = 2.0, mode = 1) {
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.75 });
  m.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWt;').replace('#include <project_vertex>', '#include <project_vertex>\nvWt = (modelMatrix * vec4(transformed,1.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vWt;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      vec2 q = vWt.xy * ${scale.toFixed(1)} + vWt.z * 0.7;
      vec3 c = mix(vec3(${c1}), vec3(${c2}), fbm(q * 0.8));
      float k = 1.0;
      if (${mode} == 0) { float strata = fbm(vec2(vWt.y * 26.0 + fbm(vWt.xz * 4.0) * 2.0, (vWt.x + vWt.z) * 3.0)); k = 0.8 + 0.28 * strata; vec2 cg = (vWt.xz + vWt.xy) * 22.0; vec2 cf = fract(cg) - 0.5; float cell = smoothstep(0.5, 0.35, length(cf)); k *= 0.93 + 0.07 * cell; float fl = step(0.84, fbm(vWt.xy * 18.0 + vWt.zx * 9.0)); k *= 1.0 - 0.08 * fl; c *= vec3(1.0, 0.92, 0.9); }
      else if (${mode} == 1) { float fib = abs(sin((vWt.x * 1.3 + fbm(vWt.xy * 2.0 + vWt.z) * 3.0) * 9.0)); k = 0.62 + 0.4 * smoothstep(0.2, 0.9, fib); float cap = smoothstep(0.86, 0.9, fbm(vWt.xy * 6.0 + vWt.zy * 4.0)); c = mix(c, vec3(0.75, 0.12, 0.16), cap * 0.8); c *= vec3(1.0, 0.82, 0.86); }
      else { vec2 g = vWt.xy * 3.2 + vWt.z * 0.4; vec2 id = floor(g); vec2 fp = fract(g) - 0.5 + 0.25 * vec2(fbm(id * 1.7) - 0.5, fbm(id * 2.3) - 0.5); float lob = smoothstep(0.42, 0.36, length(fp)); k = 0.6 + 0.45 * lob; c *= vec3(1.05, 0.95, 0.6); }
      diffuseColor.rgb *= c * k;`);
  };
  return m;
}
// skin block with a V notch, epidermis on top, dermis below
export function skin() {
  const g = new THREE.Group();
  const mk = (y0, y1, mat) => {
    const s = new THREE.Shape(); const half = 6;
    // left part then right part, separated by the notch (only where the notch reaches)
    const parts = [-1, 1].map((sg) => {
      const p = new THREE.Shape(); const xin = (y) => sg * (y >= -WD ? wallX(y) : 0.0);
      if (y0 >= -WD) { p.moveTo(sg * half, y0); p.lineTo(sg * half, y1); p.lineTo(xin(y1), y1); p.lineTo(xin(y0), y0); p.closePath(); }
      return p;
    });
    parts.forEach((p) => { const geo = new THREE.ExtrudeGeometry(p, { depth: 5.2, bevelEnabled: false }); geo.translate(0, 0, -2.6); const m = new THREE.Mesh(geo, mat); m.receiveShadow = true; m.castShadow = true; g.add(m); });
  };
  const epi = tissueMat('0.84, 0.52, 0.42', '0.7, 0.4, 0.32', 2.6, 0), derm = tissueMat('0.9, 0.45, 0.5', '0.78, 0.34, 0.4', 1.2, 1), deep = tissueMat('0.95, 0.8, 0.45', '0.85, 0.66, 0.35', 1.0, 2);
  mk(-0.5, 0, epi); mk(-WD, -0.5, derm);
  // below the notch: one solid block
  const low = new THREE.Mesh(new THREE.BoxGeometry(12, 2.2, 5.2), derm); low.position.y = -WD - 1.1; g.add(low);
  const fat = new THREE.Mesh(new THREE.BoxGeometry(12, 1.6, 5.2), deep); fat.position.y = -WD - 3.0; g.add(fat);
  { const R = rng(21); const hm = new THREE.MeshStandardMaterial({ color: 0x4a3224, roughness: 0.45 }); const hg = (() => { const cu = new THREE.QuadraticBezierCurve3(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0.04, 0.35, 0), new THREE.Vector3(0.22, 0.62, 0)); const g2 = new THREE.TubeGeometry(cu, 14, 0.014, 6, false); const pp = g2.attributes.position; for (let i = 0; i < pp.count; i++) { const t = Math.floor(i / 7) / 14; const c0 = cu.getPoint(t); const v = new THREE.Vector3().fromBufferAttribute(pp, i).sub(c0).multiplyScalar(1 - 0.75 * t).add(c0); pp.setXYZ(i, v.x, v.y, v.z); } g2.computeVertexNormals(); return g2; })();
    const N = 70; const H = new THREE.InstancedMesh(hg, hm, N); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(); let k = 0;
    for (let i = 0; i < N; i++) { const x = (R() < 0.5 ? -1 : 1) * (WW + 0.5 + R() * 4.2), z = -2.5 + R() * 5.0; e.set((R() - 0.5) * 0.3, R() * 6.28, (R() - 0.5) * 0.3); q.setFromEuler(e); const sc = 0.6 + R() * 0.6; M.compose(new THREE.Vector3(x, 0, z), q, new THREE.Vector3(sc, sc, sc)); H.setMatrixAt(k++, M); } H.count = k; g.add(H);
    const pm = new THREE.MeshStandardMaterial({ color: 0x8a4a3a, roughness: 0.8 }); for (let i = 0; i < 40; i++) { const p = new THREE.Mesh(new THREE.CircleGeometry(0.035, 10), pm); p.rotation.x = -Math.PI / 2; p.position.set((R() < 0.5 ? -1 : 1) * (WW + 0.4 + R() * 4.4), 0.004, -2.5 + R() * 5); g.add(p); } }
  { const plain = tissueMat('0.86, 0.56, 0.44', '0.74, 0.44, 0.34', 2.6, 0); [[-36, -20, 60, 35], [6, -2.6, 30, 5.2], [-36, -2.6, 30, 5.2]].forEach(([x, z, w, dd]) => { const pl = new THREE.Mesh(new THREE.PlaneGeometry(w, dd, 40, 20), plain); const pp = pl.geometry.attributes.position; for (let i = 0; i < pp.count; i++) pp.setZ(i, 0.06 * Math.sin(pp.getX(i) * 1.7) * Math.sin(pp.getY(i) * 2.1)); pl.geometry.computeVertexNormals(); pl.rotation.x = -Math.PI / 2; pl.position.set(x + w / 2, 0, z + dd / 2 - (z === -20 ? 15.2 : 0)); g.add(pl); }); }
  return g;
}
// red blood cell: biconcave disc
const rbcGeo = (() => { const pts = []; for (let k = 0; k <= 24; k++) { const a = k / 24 * Math.PI; const r = Math.sin(a) * 0.5; const y = Math.cos(a) * (0.12 + 0.18 * Math.pow(Math.sin(a), 6)) * (r < 0.25 ? 0.6 : 1); pts.push(new THREE.Vector2(Math.max(0.001, r), y)); } return new THREE.LatheGeometry(pts, 24); })();
export function scabScene(scene, { seed = 3 } = {}) {
  const R = rng(seed);
  const S = skin(); scene.add(S);
  // blood vessel along z under the wound, broken where the notch meets it
  const vy = -WD - 0.25;
  const vesM = new THREE.MeshPhysicalMaterial({ color: 0xd84a5a, roughness: 0.35, transparent: true, opacity: 0.55, depthWrite: false, side: THREE.DoubleSide });
  const ves = [-1, 1].map((s) => { const v = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 3.6, 32, 1, true), vesM); v.rotation.x = Math.PI / 2; v.position.set(0, vy, s * 2.45); scene.add(v); return v; });
  // red blood cells: flowing along the vessel, spilling into the wound, later trapped in the mesh
  const NR = 320; const rbcM = new THREE.MeshPhysicalMaterial({ color: 0xd8202f, roughness: 0.3, clearcoat: 0.8, clearcoatRoughness: 0.25, sheen: 0.6, sheenColor: new THREE.Color(0xff8090), emissive: 0x400008, emissiveIntensity: 0.35 });
  const rbc = new THREE.InstancedMesh(rbcGeo, rbcM, NR); rbc.geometry = rbcGeo.clone().scale(0.42, 0.42, 0.42); rbc.castShadow = true; rbc.frustumCulled = false; scene.add(rbc);
  const rs = []; for (let i = 0; i < NR; i++) { const y = -WD + 0.15 + R() * (WD - 0.25); rs.push({ ph: R(), lane: (R() - 0.5) * 0.6, tx: (R() * 2 - 1) * wallX(y) * 0.8, ty: y, tz: (R() - 0.5) * 4.6, rot: [R() * 6, R() * 6, R() * 6] }); }
  // platelets: small lilac discs that rush to the wound walls, then pile into a plug at the top of the notch
  const NP = 140; const pM = new THREE.MeshStandardMaterial({ color: 0xb98ad8, roughness: 0.5, emissive: 0x30104a, emissiveIntensity: 0.4 });
  const pGeo = new THREE.IcosahedronGeometry(0.08, 2); { const p = pGeo.attributes.position; for (let i = 0; i < p.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(p, i); const sp = Math.pow(Math.abs(Math.sin(v.x * 90) * Math.sin(v.y * 80) * Math.sin(v.z * 70)), 3); v.multiplyScalar(1 + 1.4 * sp); p.setXYZ(i, v.x, v.y, v.z); } pGeo.computeVertexNormals(); }
  const plt = new THREE.InstancedMesh(pGeo, pM, NP); plt.frustumCulled = false; scene.add(plt);
  const ps = []; for (let i = 0; i < NP; i++) { const y = -WD + R() * WD; const side = R() < 0.5 ? -1 : 1; const plug = i > NP * 0.55; ps.push({ y, side, z: (R() - 0.5) * 4.8, plug, px: (R() * 2 - 1) * 0.9, py: -0.35 - R() * 0.7, ph: R() * 6 }); }
  // fibrin threads: random strands across the notch
  const NF = 70; const fM = new THREE.MeshPhysicalMaterial({ color: 0xf2e6b0, roughness: 0.25, clearcoat: 1, emissive: 0x5a4a10, emissiveIntensity: 0.35 });
  const fib = []; for (let i = 0; i < NF; i++) { const y1 = -WD + 0.1 + R() * (WD - 0.15), y2 = Math.min(-0.05, Math.max(-WD + 0.1, y1 + (R() - 0.5) * 0.9)); const a = new THREE.Vector3(-wallX(y1), y1, (R() - 0.5) * 5), b = new THREE.Vector3(wallX(y2), y2, (R() - 0.5) * 5);
    const mid = a.clone().lerp(b, 0.5).add(new THREE.Vector3(0, (R() - 0.5) * 0.4, (R() - 0.5) * 0.6)); const curve = new THREE.QuadraticBezierCurve3(a, mid, b);
    const m = new THREE.Mesh(new THREE.TubeGeometry(curve, 16, 0.025, 5), fM); scene.add(m); fib.push({ m, curve, delay: R() * 0.6, flip: R() < 0.5 }); }
  // crust (scab) on top of the wound
  const crustM = new THREE.MeshStandardMaterial({ color: 0x7a1a14, roughness: 0.95 });
  crustM.onBeforeCompile = (sh) => { sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vOc;').replace('#include <project_vertex>', '#include <project_vertex>\nvOc = position;'); sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nvarying vec3 vOc;\n${NOISE}`).replace('#include <color_fragment>', `#include <color_fragment>
      float gr = fbm(vOc.xz * 9.0); float crk = 1.0 - smoothstep(0.0, 0.03, abs(fbm(vOc.xz * 2.2) - 0.5)); float glint = step(0.9, fbm(vOc.xz * 30.0));
      diffuseColor.rgb *= (0.7 + 0.5 * gr) * (1.0 - 0.6 * crk); diffuseColor.rgb += vec3(0.12, 0.04, 0.02) * glint;`); };
  const crustGeo = new THREE.BoxGeometry(WW * 2 + 0.6, 0.35, 5.3, 60, 2, 60); { const p = crustGeo.attributes.position; for (let i = 0; i < p.count; i++) if (p.getY(i) > 0) p.setY(i, p.getY(i) + Math.sin(p.getX(i) * 7) * Math.sin(p.getZ(i) * 5) * 0.06 + 0.04 * Math.sin(p.getX(i) * 19 + p.getZ(i) * 13) + 0.025 * Math.sin(p.getX(i) * 41 + 2.0) * Math.sin(p.getZ(i) * 37)); crustGeo.computeVertexNormals(); }
  const crust = new THREE.Mesh(crustGeo, crustM); crust.castShadow = true; scene.add(crust); crust.scale.y = 0.6;
  // white blood cells and germs
  const wbM = new THREE.MeshStandardMaterial({ color: 0xf4f2ea, roughness: 0.55, transparent: true, opacity: 0.92 });
  const wbcs = []; for (let i = 0; i < 4; i++) { const w = new THREE.Mesh(new THREE.IcosahedronGeometry(0.3, 3), wbM); const p = w.geometry.attributes.position; for (let k = 0; k < p.count; k++) { const v = new THREE.Vector3().fromBufferAttribute(p, k); v.multiplyScalar(1 + 0.12 * Math.sin(v.x * 9 + i) * Math.sin(v.y * 8)); p.setXYZ(k, v.x, v.y, v.z); } w.geometry.computeVertexNormals();
    const nuc = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 8), new THREE.MeshStandardMaterial({ color: 0x8a5ac8 })); w.add(nuc); scene.add(w); wbcs.push(w); }
  const germM = new THREE.MeshStandardMaterial({ color: 0x5ac85a, roughness: 0.5, emissive: 0x104010, emissiveIntensity: 0.3 });
  const germs = []; for (let i = 0; i < 4; i++) { const gm = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.25, 4, 8), germM); scene.add(gm); germs.push(gm); }
  // new skin cells growing in from the edges under the scab
  const ncM = new THREE.MeshStandardMaterial({ color: 0xf0a8a0, roughness: 0.6 });
  const NC = 48; const nc = new THREE.InstancedMesh(new RoundedBoxGeometry(0.42, 0.3, 0.42, 2, 0.08), ncM, NC); nc.frustumCulled = false; scene.add(nc);
  const ncs = []; for (let i = 0; i < NC; i++) { const row = i % 2, col = Math.floor(i / 2) % 6, zi = Math.floor(i / 12); ncs.push({ side: col < 3 ? -1 : 1, k: (col % 3) / 3, y: -0.2 - row * 0.32, z: -2.25 + zi * 1.5 }); }
  // signal pulses from the platelets
  const sigM = new THREE.MeshBasicMaterial({ color: 0xffe080, transparent: true, opacity: 0, depthWrite: false });
  const sigs = []; for (let i = 0; i < 6; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 12), sigM.clone()); scene.add(s); sigs.push(s); }

  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), sc = new THREE.Vector3(), e = new THREE.Euler();
  const st = { flow: 1, constrict: 0, spill: 1, platelets: 0, plug: 0, signal: 0, fibrin: 0, trapped: 0, dry: 0, wbc: 0, grow: 0, fall: 0 };
  function update(t) {
    ves.forEach((vv) => { const s = 1 - 0.35 * st.constrict; vv.scale.set(s, 1, s); });
    // red cells: either flowing in the vessel / spilling up into the notch, or settled in the mesh
    for (let i = 0; i < NR; i++) {
      const r = rs[i]; const u = (r.ph + t * 0.18 * st.flow) % 1;
      // flow path: along the vessel toward the break (z from +-3 to 0), then up into the wound
      const sgn = i % 2 ? 1 : -1; let fx, fy, fz;
      if (u < 0.5) { fz = sgn * (4.2 - u * 8.4); fx = r.lane * (1 - 0.35 * st.constrict); fy = vy + r.lane * 0.4; }
      else { const k = (u - 0.5) / 0.5; fz = r.tz * k; fy = vy + k * (r.ty - vy) * st.spill; fx = r.tx * k; }
      const T = st.trapped; v.set(THREE.MathUtils.lerp(fx, r.tx, T), THREE.MathUtils.lerp(fy, r.ty, T), THREE.MathUtils.lerp(fz, r.tz, T));
      e.set(r.rot[0] + t * (1 - T), r.rot[1], r.rot[2] + t * 0.7 * (1 - T)); q.setFromEuler(e);
      const dark = st.dry; sc.setScalar(1 - 0.15 * dark); m4.compose(v, q, sc); rbc.setMatrixAt(i, m4);
    }
    rbc.instanceMatrix.needsUpdate = true; rbcM.color.set(0xd8202f).lerp(new THREE.Color(0x5a120e), st.dry * 0.8);
    // platelets
    for (let i = 0; i < NP; i++) {
      const p = ps[i]; const k = THREE.MathUtils.clamp(st.platelets * 1.4 - (i / NP) * 0.4, 0, 1);
      const start = new THREE.Vector3(0, vy, p.z * 0.5), wall = new THREE.Vector3(p.side * (wallX(p.y) - 0.12), p.y, p.z);
      const plugPos = new THREE.Vector3(p.px * wallX(p.py), p.py, p.z * 0.9);
      v.copy(start).lerp(p.plug ? plugPos : wall, THREE.MathUtils.smoothstep(k, 0, 1));
      if (p.plug) v.lerp(plugPos, st.plug);
      v.x += Math.sin(t * 3 + p.ph) * 0.03 * (1 - k);
      e.set(p.ph, p.ph * 2, t * 0.5); q.setFromEuler(e); const s = k > 0.01 ? 1 + 0.3 * st.plug : 0.0001; sc.set(s, s * 0.55, s); m4.compose(v, q, sc); plt.setMatrixAt(i, m4);
    }
    plt.instanceMatrix.needsUpdate = true;
    // signal pulses
    sigs.forEach((s, i) => { const f = ((t * 0.7 + i / 6) % 1); s.position.set((i % 3 - 1) * 0.6, -0.6 - (i % 2) * 0.6, (i - 2.5) * 0.7); s.scale.setScalar(0.1 + f * 1.1); s.material.opacity = st.signal * 0.35 * (1 - f); s.visible = st.signal > 0.01; });
    // fibrin threads grow (draw range) across the notch
    fib.forEach((f) => { const k = THREE.MathUtils.clamp((st.fibrin - f.delay * 0.6) / 0.4, 0, 1); f.m.visible = k > 0.01; const idx = f.m.geometry.index.count; f.m.geometry.setDrawRange(0, Math.floor(idx * k / 6) * 6); });
    fM.color.set(0xf2e6b0).lerp(new THREE.Color(0x6a2a18), st.dry * 0.8);
    // crust
    crust.visible = st.dry > 0.01; crust.scale.set(1, Math.max(0.01, st.dry) * 0.6, 1);
    crust.position.set(st.fall * 1.8, 0.04 + st.fall * 1.6, 0); crust.rotation.z = -st.fall * 0.5; crustM.color.set(0x8a2018).lerp(new THREE.Color(0x4a1a10), st.dry);
    // white cells chase germs
    wbcs.forEach((w, i) => { const gz = -1.8 + i * 1.2, gy = -0.9 - (i % 2) * 0.6; const k = THREE.MathUtils.clamp(st.wbc * 1.3 - i * 0.1, 0, 1);
      w.visible = st.wbc > 0.01; w.position.set(THREE.MathUtils.lerp((i % 2 ? 1 : -1) * 0.9, 0.05, k), THREE.MathUtils.lerp(vy, gy, k), gz); w.rotation.y = t * 0.5 + i;
      const gm = germs[i]; gm.visible = st.wbc > 0.01 && k < 0.95; gm.position.set(0.05 + Math.sin(t * 4 + i) * 0.05, gy + 0.05, gz); gm.rotation.set(t + i, t * 0.7, 0); gm.scale.setScalar(1 - k * 0.9); });
    // new skin cells fill the notch from the edges inward
    for (let i = 0; i < NC; i++) { const c = ncs[i]; const k = THREE.MathUtils.clamp(st.grow * 1.25 - c.k * 0.5, 0, 1); const xEdge = c.side * wallX(c.y), xIn = c.side * (0.22 + c.k * 0.42);
      v.set(THREE.MathUtils.lerp(xEdge, xIn, k), c.y, c.z); sc.setScalar(k > 0.01 ? Math.min(1, k * 1.5) : 0.0001); m4.compose(v, q.identity(), sc); nc.setMatrixAt(i, m4); }
    nc.instanceMatrix.needsUpdate = true;
  }
  update(0);
  return { st, update, skin: S, crust };
}
