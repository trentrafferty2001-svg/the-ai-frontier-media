// detail kit for sharks: denticle skin, glossy eyes, gill shading; camouflaged flatfish; tissue textures; reef dressing
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as K from './shark.js';
import { reefDetail, rockMat } from './reef2.js';
export { fieldRings, magLines, std } from './shark.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
const dentTex = () => cv(256, 256, (g, w, h) => { g.fillStyle = '#d8d8d8'; g.fillRect(0, 0, w, h); const R = rnd(3); const s = 8;
  for (let y = 0; y < h; y += s * 0.8) for (let x = 0; x < w; x += s) { const ox = (Math.round(y / (s * 0.8)) & 1) * s / 2; g.fillStyle = `rgb(${235 + R() * 20 | 0},${235 + R() * 20 | 0},${235 + R() * 20 | 0})`; g.beginPath(); g.moveTo(x + ox, y - s * 0.35); g.lineTo(x + ox + s * 0.42, y + s * 0.3); g.lineTo(x + ox - s * 0.42, y + s * 0.3); g.closePath(); g.fill(); }
  for (let i = 0; i < 260; i++) { g.fillStyle = 'rgba(90,100,110,0.25)'; g.beginPath(); g.arc(R() * w, R() * h, 1 + R() * 3, 0, 7); g.fill(); } });
export function shark(o) {
  const S = K.shark(o); const dt = tx('dent', dentTex); const dtm = dt.clone(); dtm.needsUpdate = true; dtm.repeat.set(30, 10);
  S.group.traverse(m => { if (!m.isMesh) return; const mt = m.material;
    if (mt.vertexColors) { mt.map = dtm; mt.bumpMap = dtm; mt.bumpScale = 0.5; mt.roughness = 0.42; mt.needsUpdate = true; }
    else if (mt.color && mt.color.getHex() === 0x66727f) { mt.map = dt; mt.bumpMap = dt; mt.bumpScale = 0.4; mt.needsUpdate = true; }
    else if (mt.color && mt.color.getHex() === 0x080808 && m.geometry.type === 'SphereGeometry') { m.material = new THREE.MeshPhysicalMaterial({ color: 0x050608, roughness: 0.05, clearcoat: 1 }); const ring = new THREE.Mesh(new THREE.TorusGeometry(0.042, 0.007, 6, 20), new THREE.MeshStandardMaterial({ color: 0x3a3a30, roughness: 0.6 })); ring.rotation.x = Math.PI / 2; ring.rotation.y = Math.PI / 2; m.add(ring); } });
  return S;
}
export function flatfish() {
  const F = K.flatfish(); const R = rnd(8);
  const mt = cv(256, 256, (g, w, h) => { g.fillStyle = '#cdb48c'; g.fillRect(0, 0, w, h); for (let i = 0; i < 260; i++) { const v = R(); g.fillStyle = v < 0.4 ? 'rgba(140,110,70,0.55)' : v < 0.75 ? 'rgba(230,214,180,0.6)' : 'rgba(90,70,50,0.45)'; g.beginPath(); g.arc(R() * w, R() * h, 2 + R() * 9, 0, 7); g.fill(); } for (let i = 0; i < 30; i++) { g.strokeStyle = 'rgba(120,90,60,0.5)'; g.lineWidth = 2; g.beginPath(); g.arc(R() * w, R() * h, 6 + R() * 10, 0, 7); g.stroke(); } });
  const body = F.group.children[0]; body.material = new THREE.MeshStandardMaterial({ map: mt, bumpMap: mt, bumpScale: 0.6, roughness: 0.9 });
  // fringe fin all round the body
  const fin = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.035, 4, 48), new THREE.MeshStandardMaterial({ map: mt, roughness: 0.9, transparent: true, opacity: 0.85 })); fin.rotation.x = Math.PI / 2; fin.scale.set(1.08, 0.75, 0.25); fin.position.y = -0.02; F.group.add(fin);
  return F;
}
const fleshTex = () => cv(512, 512, (g, w, h) => { g.fillStyle = '#d8a8a0'; g.fillRect(0, 0, w, h); const R = rnd(13); for (let i = 0; i < 220; i++) { const y = R() * h; g.strokeStyle = R() < 0.5 ? 'rgba(170,110,105,0.45)' : 'rgba(240,200,190,0.5)'; g.lineWidth = 1 + R() * 3; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= w; x += 32) g.lineTo(x, y + Math.sin(x * 0.03 + i) * 8); g.stroke(); }
  for (let i = 0; i < 300; i++) { g.fillStyle = 'rgba(150,80,80,0.5)'; g.beginPath(); g.ellipse(R() * w, R() * h, 2.5, 1.5, R() * 3, 0, 7); g.fill(); } });
export function ampulla() {
  const A = K.ampulla(); const kids = A.group.children; const dt = tx('dent', dentTex);
  kids[0].material = new THREE.MeshStandardMaterial({ color: 0x6f7c8a, map: dt, bumpMap: dt, bumpScale: 1, roughness: 0.5 });
  kids[1].material = new THREE.MeshStandardMaterial({ map: fleshTex(), transparent: true, opacity: 0.45, depthWrite: false, roughness: 0.8 });
  return A;
}
// seabed dressing: textured smooth rocks, reef life scaled to shark size, swaying weed
export function reefUp(scene, { scale = 2.4, clear = 1.4 } = {}) {
  const rm = rockMat(); scene.traverse(o => { if (o.isMesh && o.geometry && o.geometry.type === 'IcosahedronGeometry' && o.material && o.material.roughness > 0.85 && !o.material.map) { o.material = rm; } });
  const holder = new THREE.Group(); holder.userData = scene.userData; reefDetail(holder, { count: 1, seed: 17, keepClear: clear }); holder.userData = {}; holder.scale.setScalar(scale); holder.position.y = 0.11 * (scale - 1); scene.add(holder);
}
