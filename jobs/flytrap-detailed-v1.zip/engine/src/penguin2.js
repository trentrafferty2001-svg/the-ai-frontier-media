// detail kit for penguins: feathered body texture, gradient ear patch, striped bill; sastrugi snow, ice cliffs, sparkles;
// close-up feathers with a shaft and barbs over fluffy down filaments
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as P from './penguin.js';
export { blizzard, bodySection, exchanger, std } from './penguin.js';
function cv(w, h, f, rep = true) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; if (rep) t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
const featherTex = () => cv(256, 256, (g, w, h) => { g.fillStyle = '#e6e6e6'; g.fillRect(0, 0, w, h); const s = 16;
  for (let y = -s; y < h + s; y += s * 0.7) for (let x = -s; x < w + s; x += s) { const ox = (Math.round(y / (s * 0.7)) & 1) * s / 2; const cx = x + ox, cy = y; g.fillStyle = 'rgba(255,255,255,0.9)'; g.beginPath(); g.ellipse(cx, cy, s * 0.5, s * 0.62, 0, 0, Math.PI); g.fill(); g.strokeStyle = 'rgba(120,120,120,0.55)'; g.lineWidth = 1.3; g.beginPath(); g.ellipse(cx, cy, s * 0.5, s * 0.62, 0, 0.1, Math.PI - 0.1); g.stroke(); } });
let configured = false;
function dress(p) {
  if (!configured) { configured = true; const ft = tx('feather', featherTex); ft.repeat.set(6, 6);
    p.group.traverse(o => { if (!o.isMesh) return; const m = o.material; const c = m.color.getHex();
      if (c === 0x15181f) { m.map = ft; m.bumpMap = ft; m.bumpScale = 0.6; m.roughness = 0.42; m.color.set(0x1c2028); m.needsUpdate = true; }
      if (c === 0xf4f4f0) { m.map = ft; m.bumpMap = ft; m.bumpScale = 0.4; m.color.set(0xfffdf6); m.needsUpdate = true; }
      if (c === 0xffb52a) { m.map = cv(64, 128, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#ffd84a'); gr.addColorStop(0.6, '#ffb030'); gr.addColorStop(1, '#fff3c0'); g.fillStyle = gr; g.fillRect(0, 0, w, h); }, false); m.color.set(0xffffff); m.needsUpdate = true; }
      if (c === 0xff8a3a) { m.emissive = new THREE.Color(0x401808); m.needsUpdate = true; } }); }
  return p;
}
export function penguin() { return dress(P.penguin()); }
export function huddle(n, seed) { const H = P.huddle(n, seed); dress(H.P[0].p); return H; }
// snowfield: wind-sculpted snow texture (sastrugi), drifts, ice cliffs on the horizon, sparkles
export function snowfield(scene) {
  const st = cv(512, 512, (g, w, h) => { g.fillStyle = '#eef4fa'; g.fillRect(0, 0, w, h); const R = rnd(5);
    for (let i = 0; i < 260; i++) { const y = R() * h, x = R() * w, l = 40 + R() * 160; g.strokeStyle = R() < 0.5 ? 'rgba(180,200,225,0.35)' : 'rgba(255,255,255,0.8)'; g.lineWidth = 1 + R() * 4; g.beginPath(); g.moveTo(x, y); g.bezierCurveTo(x + l * 0.3, y - 6, x + l * 0.7, y + 6, x + l, y); g.stroke(); }
    for (let i = 0; i < 3000; i++) { g.fillStyle = `rgba(200,215,235,${0.2 + R() * 0.3})`; g.fillRect(R() * w, R() * h, 1.5, 1.5); } });
  st.repeat.set(40, 40);
  const g = new THREE.Mesh(new THREE.CircleGeometry(200, 64), new THREE.MeshStandardMaterial({ map: st, bumpMap: st, bumpScale: 2, roughness: 0.85, color: 0xffffff })); g.rotation.x = -Math.PI / 2; g.position.y = 0.002; g.receiveShadow = true; scene.add(g);
  // drifts: low smooth mounds
  const R = rnd(9); const dm = new THREE.MeshStandardMaterial({ map: st, roughness: 0.85 });
  for (let i = 0; i < 26; i++) { const a = R() * Math.PI * 2, r = 9 + R() * 40; const d = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), dm); d.scale.set(2 + R() * 5, 0.3 + R() * 0.7, 1 + R() * 2); d.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); d.rotation.y = R() * 3; scene.add(d); }
  // ice cliffs / bergs far away
  const im = new THREE.MeshPhysicalMaterial({ color: 0xcfe8f8, roughness: 0.25, clearcoat: 0.6, sheen: 0.5, sheenColor: new THREE.Color(0x8fd0ff) });
  for (let i = 0; i < 14; i++) { const a = -2.6 + i * 0.4 + R() * 0.2, r = 90 + R() * 40; const geo = new THREE.BoxGeometry(14 + R() * 18, 6 + R() * 10, 8, 4, 3, 2); const p = geo.attributes.position; for (let k = 0; k < p.count; k++) p.setXYZ(k, p.getX(k) * (1 + (R() - 0.5) * 0.12), p.getY(k) * (1 + (R() - 0.5) * 0.15), p.getZ(k) * (1 + (R() - 0.5) * 0.2)); geo.computeVertexNormals(); const b = new THREE.Mesh(geo, im); b.position.set(Math.cos(a) * r, 3, Math.sin(a) * r); b.rotation.y = -a; scene.add(b); }
  // sparkles: tiny bright glints in the snow
  const sp = new THREE.InstancedMesh(new THREE.OctahedronGeometry(0.03, 0), new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }), 1400); const M = new THREE.Matrix4();
  for (let i = 0; i < 1400; i++) { const a = R() * Math.PI * 2, r = 1 + Math.sqrt(R()) * 30; M.makeTranslation(Math.cos(a) * r, 0.02, Math.sin(a) * r); sp.setMatrixAt(i, M); } scene.add(sp);
  return g;
}
const vaneTex = () => cv(256, 512, (g, w, h) => { g.clearRect(0, 0, w, h); const cx = w / 2;
  g.save(); g.beginPath(); g.moveTo(cx, h * 0.02); g.bezierCurveTo(w * 0.98, h * 0.2, w * 0.92, h * 0.85, cx, h * 0.98); g.bezierCurveTo(w * 0.08, h * 0.85, w * 0.02, h * 0.2, cx, h * 0.02); g.closePath(); g.clip();
  const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#2a2f3a'); gr.addColorStop(0.75, '#1a1e26'); gr.addColorStop(1, '#8a8e96'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.strokeStyle = 'rgba(120,130,150,0.45)'; g.lineWidth = 1.2; for (let y = 0; y < h * 1.2; y += 6) { [-1, 1].forEach(s => { g.beginPath(); g.moveTo(cx, y); g.quadraticCurveTo(cx + s * w * 0.2, y - 14, cx + s * w * 0.5, y - 40); g.stroke(); }); }
  g.restore(); g.strokeStyle = '#d8dce4'; g.lineWidth = 5; g.beginPath(); g.moveTo(cx, h * 0.02); g.lineTo(cx, h); g.stroke(); }, false);
export function featherPatch() {
  const F = P.featherPatch(); const vt = tx('vane', vaneTex);
  // curved feather vane geometry, tip toward -z (pointing back, overlapping like roof tiles)
  const fg = new THREE.PlaneGeometry(0.62, 0.95, 4, 8); const p = fg.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); p.setZ(i, -0.12 * (x / 0.31) ** 2 + 0.05 * (y / 0.475)); } fg.computeVertexNormals(); fg.rotateX(-Math.PI / 2);
  const fm = new THREE.MeshPhysicalMaterial({ map: vt, transparent: true, alphaTest: 0.4, side: THREE.DoubleSide, roughness: 0.5, sheen: 0.15, sheenColor: new THREE.Color(0x6a7a9a), color: 0x9098a8 });
  F.feathers.forEach(f => { f.geometry = fg; f.material = fm; f.scale.set(1, 1, 1); f.rotation.x = -0.32; });
  // fluffy down: tufts of fine filaments instead of balls
  const fil = new THREE.CylinderGeometry(0.005, 0.002, 0.15, 3); fil.translate(0, 0.075, 0); const R = rnd(4); const dm = new THREE.MeshStandardMaterial({ color: 0xf6f4ee, roughness: 1 });
  const tufts = F.down.map(d => d.position.clone()); F.down.forEach(d => { d.scale.setScalar(0.45); });
  const n = tufts.length * 60; const im = new THREE.InstancedMesh(fil, dm, n); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), up = new THREE.Vector3(0, 1, 0); let k = 0;
  tufts.forEach(c => { for (let j = 0; j < 60; j++) { const d = new THREE.Vector3(R() - 0.5, R() * 0.45 + 0.02, R() - 0.5).normalize(); q.setFromUnitVectors(up, d); M.compose(c, q, new THREE.Vector3(1, 0.6 + R() * 0.6, 1)); im.setMatrixAt(k++, M); } });
  F.group.add(im); F.downFil = im;
  // skin: pinkish with pores
  F.group.children[0].material = new THREE.MeshStandardMaterial({ map: cv(256, 256, (g, w, h) => { g.fillStyle = '#e4b4a0'; g.fillRect(0, 0, w, h); const R2 = rnd(2); for (let i = 0; i < 400; i++) { g.fillStyle = 'rgba(170,110,95,0.5)'; g.beginPath(); g.arc(R2() * w, R2() * h, 1 + R2() * 2, 0, 7); g.fill(); } }), roughness: 0.75 });
  return F;
}
