// The Explainer: how sharks sense electricity. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { shark, flatfish, fieldRings, ampulla, magLines, std, reefUp } from './shark2.js';
import { sea } from './ocean.js';
import { rnd } from './bolt.js';
import { label } from './gps.js';
import { VO } from './vo_sk2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *shark* can find', 4], ['a *fish* hiding', 3], ['*under the sand*', 3], ['without *seeing*', 2], ['*smelling*', 1], ['or *hearing* it', 3]],
  [['Every *living* thing', 3], ['gives off', 2], ['a tiny', 2], ['*electric field*', 2], ['from its', 2], ['*heartbeat*', 1], ['and moving', 2], ['*muscles*', 1]],
  [["A shark's *snout*", 3], ['is covered in', 3], ['*hundreds*', 1], ['of little', 2], ['*pores*', 1]],
  [['Each one leads', 3], ['into a *canal*', 3], ['filled with', 2], ['a special', 2], ['*jelly*', 1], ['ending in', 2], ['a *sensor*', 2]],
  [["They're called the", 3], ['*ampullae*', 1], ['of *Lorenzini*', 2]],
  [['They can sense', 3], ['fields as *faint*', 3], ['as a few', 3], ['*billionths*', 1], ['of a *volt*', 3]],
  [['So right before', 3], ['it *bites*', 2], ['when the prey', 3], ['is *too close*', 3], ['to see', 2], ['the shark *follows*', 3], ['its *electricity*', 2]],
  [["A *hammerhead's*", 2], ['wide head', 2], ['*spreads* these', 2], ['sensors out', 2], ['like a *metal*', 3], ['*detector*', 1], ['sweeping', 1], ['the seabed', 2]],
  [['They may even', 3], ['help sharks', 2], ['*navigate*', 1], ["by Earth's", 2], ['*magnetic field*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.02; c.far = 600; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.5, warm: 0.95, sat: 1.15, exposure: 1.05 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

function seabed(makeStage) {
  const scene = makeStage({ shadowSize: 4, sunDir: [0.6, 6, 1.2] });
  sea(scene, { rocks: true, coral: false, fogColor: 0x125a7c, density: 0.06 }); reefUp(scene);
  const F = flatfish(); F.group.position.set(0, 0.0, 0); scene.add(F.group);
  const RG = fieldRings(); RG.group.position.set(0, 0.05, 0); scene.add(RG.group);
  return { scene, F, RG };
}
const heartbeat = (T) => Math.max(0, Math.sin(T * 7.5)) ** 8;

// ============ S0 hook: a shark cruises low, stops dead over the sand and strikes at a hidden fish ============
function sHook({ makeStage }) {
  const W = seabed(makeStage); const S = shark(); W.scene.add(S.group);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t) {
      const k1 = range(t, 0, 3.2), turn = smooth(range(t, 2.2, 3.4)), dive = easeIn(range(t, 3.4, 4.6));
      const x = lerp(-5, -1.6, easeOut(k1)) + dive * 1.4; S.group.position.set(x, lerp(1.0, 0.55, turn) - dive * 0.45, lerp(0.6, 0, turn)); S.body.rotation.z = -0.35 * dive;
      S.st.swim = t * (1.4 - 0.6 * turn); S.st.sense = smooth(range(t, 1.6, 2.6)); S.update(t);
      W.RG.set(t, smooth(range(t, 1.2, 2.2))); W.F.heart.material.opacity = heartbeat(t);
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [lerp(-2.2, -0.2, k), 0.5, 0], lerp(5.5, 4.2, k), lerp(30, 50, k), lerp(14, 22, k));
      return POST;
    },
  };
}
// ============ S1: the hidden fish's heartbeat and muscles make an electric field ============
function sField({ makeStage }) {
  const W = seabed(makeStage); const L = tag(W.scene, 'electric field', 0.22, '#ffe14a', [0, 0.95, 0]);
  const c = C(38);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.RG.set(T, 1); W.F.heart.material.opacity = heartbeat(T) * smooth(range(T, at(1, 'heartbeat') - 0.4, at(1, 'heartbeat')));
      W.F.group.rotation.z = 0.04 * Math.sin(T * 3) * smooth(range(T, at(1, 'muscles') - 0.3, at(1, 'muscles')));
      pop(L, easeOut(range(T, at(1, 'electric') - 0.15, at(1, 'electric') + 0.2)), 0.22);
      const k = easeInOut(range(t, 0, 5.2));
      orb(c, [0, 0.1, 0], lerp(4.2, 3.2, k), lerp(-20, 10, k), lerp(34, 28, k));
      return POST;
    },
  };
}
// ============ S2: close on the snout: hundreds of little pores ============
function sPores({ makeStage }) {
  const scene = makeStage({ shadowSize: 4, sunDir: [0.6, 6, 1.2] }); sea(scene, { rocks: false, coral: false, fogColor: 0x125a7c, density: 0.05 }); reefUp(scene);
  const S = shark(); S.group.position.set(0, 1.4, 0); scene.add(S.group);
  const c = C(34);
  return {
    scene, camera: c,
    update(t, T) {
      S.st.swim = T * 0.4; S.update(T);
      const k = easeInOut(range(t, 0, 2.9));
      orb(c, [1.2, 1.4, 0], lerp(2.0, 1.15, k), lerp(50, 70, k), lerp(10, 16, k));
      return { ...POST, dof: { focus: 1.2, aperture: 0.002, maxblur: 0.004 } };
    },
  };
}
// ============ S3/S4: ampulla cutaway, named ============
function sCanal({ makeStage }) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x123a5a); u.mid.value.set(0x164666); u.horizon.value.set(0x1a4c6c); u.floorC.value.set(0x0a1a2a); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xdff0ff, 0x203040, 0.9));
  const A = ampulla(); scene.add(A.group);
  const Lj = tag(scene, 'jelly', 0.45, '#9ae6ff', [1.1, 0.9, 0.7]), Ls = tag(scene, 'sensor', 0.45, '#ffe14a', [1.3, -1.2, 0.7]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      A.set(T, smooth(range(T, at(3, 'jelly') - 0.3, at(3, 'jelly') + 0.2)), smooth(range(T, at(3, 'sensor') - 0.2, at(3, 'sensor') + 0.3)));
      pop(Lj, easeOut(range(T, at(3, 'jelly') - 0.1, at(3, 'jelly') + 0.2)), 0.45); pop(Ls, easeOut(range(T, at(3, 'sensor') - 0.1, at(3, 'sensor') + 0.2)), 0.45);
      const k = easeInOut(range(t, 0, 4.5));
      orb(c, [0.3, 0.2, 0.6], lerp(8.5, 7.5, k), lerp(-14, 8, k), lerp(6, 4, k));
      return { ...POST, bloom: 0.6 };
    },
  };
}
function sName({ makeStage }) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x123a5a); u.mid.value.set(0x164666); u.horizon.value.set(0x1a4c6c); u.floorC.value.set(0x0a1a2a); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xdff0ff, 0x203040, 0.9));
  const A = ampulla(); scene.add(A.group);
  const L = tag(scene, 'ampullae', 0.5, '#ffffff', [0.3, 3.2, 0.6]);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      A.set(T, 1, 1); pop(L, easeOut(range(T, at(4, 'ampullae') - 0.15, at(4, 'ampullae') + 0.2)), 0.5);
      const k = easeInOut(range(t, 0, 2.5));
      orb(c, [0.3, 0.8, 0.6], lerp(9.5, 10.5, k), lerp(8, 16, k), lerp(4, 6, k));
      return { ...POST, bloom: 0.6 };
    },
  };
}
// ============ S5: a few billionths of a volt ============
function sFaint({ makeStage }) {
  const W = seabed(makeStage); const S = shark(); W.scene.add(S.group); S.group.position.set(-1.6, 0.7, 0.2);
  const L = tag(W.scene, '0.000000005 V', 0.24, '#ffe14a', [-0.4, 1.7, 0]);
  const c = C(38);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      S.st.swim = T * 0.5; S.st.sense = 1; S.update(T); W.RG.set(T, 0.6); W.F.heart.material.opacity = heartbeat(T);
      pop(L, easeOut(range(T, at(5, 'billionths') - 0.2, at(5, 'billionths') + 0.2)), 0.24);
      const k = easeInOut(range(t, 0, 3.5));
      orb(c, [-0.6, 0.6, 0], lerp(5.0, 4.4, k), lerp(20, 34, k), lerp(14, 18, k));
      return POST;
    },
  };
}
// ============ S6: last moment: too close to see, it follows the electricity and bites ============
function sStrike({ makeStage }) {
  const W = seabed(makeStage); const S = shark(); W.scene.add(S.group);
  const sand = []; const R = rnd(8); const sm = std(0xc8b08a, 0.9); for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.03 + R() * 0.04, 6, 4), sm); W.scene.add(m); sand.push({ m, vx: (R() - 0.5) * 1.6, vy: 0.6 + R(), vz: (R() - 0.5) * 1.6 }); }
  const c = C(38); const tb = at(6, 'follows');
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const app = smooth(range(T, ls(6), tb)), hit = easeIn(range(T, tb, tb + 0.6));
      S.group.position.set(lerp(-3.0, -1.6, app) + hit * 0.45, lerp(0.9, 0.5, app) - hit * 0.3, 0); S.body.rotation.z = -0.3 * app - 0.2 * hit;
      S.st.swim = T * 0.9; S.st.sense = smooth(range(T, at(6, 'too') - 0.2, at(6, 'too') + 0.2)); S.update(T); W.RG.set(T, 1 - hit); W.F.heart.material.opacity = heartbeat(T) * (1 - hit);
      sand.forEach(o => { const u = Math.max(0, T - tb - 0.45); o.m.visible = u > 0; o.m.position.set(o.vx * u, 0.05 + o.vy * u - 1.5 * u * u, o.vz * u); });
      const k = easeInOut(range(t, 0, 5.6));
      orb(c, [-0.8, 0.5, 0], lerp(5.2, 3.6, k), lerp(70, 50, k), lerp(10, 18, k));
      return POST;
    },
  };
}
// ============ S7: hammerhead sweeps the seabed like a metal detector ============
function sHammer({ makeStage }) {
  const W = seabed(makeStage); const H = shark({ hammer: true }); W.scene.add(H.group); W.F.group.position.set(1.4, 0, 0.8); W.RG.group.position.set(1.4, 0.05, 0.8);
  const c = C(40);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      const sw = Math.sin(t * 1.8); H.group.position.set(-2.5 + t * 0.6, 0.55, 0.0); H.group.rotation.y = 0.45 * sw; H.st.swim = T * 0.8; H.st.sense = 0.6 + 0.4 * Math.max(0, sw); H.update(T);
      W.RG.set(T, 0.8); W.F.heart.material.opacity = heartbeat(T);
      const k = easeInOut(range(t, 0, 5.3));
      orb(c, [-1.6 + t * 0.6, 0.4, 0.3], lerp(6.5, 7.2, k), lerp(-20, -6, k), lerp(36, 46, k));
      return POST;
    },
  };
}
// ============ S8: swimming away under faint magnetic field lines ============
function sNavigate({ makeStage }) {
  const W = seabed(makeStage); W.F.group.visible = false; const S = shark(); W.scene.add(S.group); const ML = magLines(); W.scene.add(ML.group);
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      S.group.position.set(-3 + t * 1.2, 1.4 + 0.1 * Math.sin(t), -1); S.st.swim = T; S.update(T); W.RG.set(T, 0);
      ML.mat.opacity = 0.6 * smooth(range(T, at(8, 'magnetic') - 0.5, at(8, 'field') + 0.2));
      const k = easeInOut(range(t, 0, 5.0));
      orb(c, [S.group.position.x - 0.5, 1.8, -1], lerp(7, 11, k), lerp(40, 25, k), lerp(8, 14, k));
      return POST;
    },
  };
}

const SH = [sHook, sField, sPores, sCanal, sName, sFaint, sStrike, sHammer, sNavigate];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
