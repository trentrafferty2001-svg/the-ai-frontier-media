// detail kit for chameleon: tubercle scale skin with bands, ridged eye turrets, bark branch with leaves, cell-textured skin section
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as C from './chameleon.js';
import { bush } from './hummer2.js';
export { skinColour, ray, std } from './chameleon.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
// greyscale tubercles (multiplied by the live skin colour) + darker vertical bands + pale speckles
const scaleTex = () => cv(1024, 512, (g, w, h) => { g.fillStyle = '#d8d8d8'; g.fillRect(0, 0, w, h); const R = rnd(12);
  for (let b = 0; b < 7; b++) { const x = (b + 0.3) * w / 7; const gr = g.createLinearGradient(x - 40, 0, x + 40, 0); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.5, 'rgba(40,40,40,0.38)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(x - 40, 0, 80, h); }
  const s = 9; for (let y = 0; y < h + s; y += s * 0.86) for (let x = 0; x < w + s; x += s) { const ox = (Math.round(y / (s * 0.86)) % 2) * s / 2; const r = s * (0.42 + R() * 0.1); const cx = x + ox, cy = y; const gr = g.createRadialGradient(cx - r * 0.3, cy - r * 0.3, 0, cx, cy, r); const v = R(); const hi = v > 0.93 ? 255 : 245, lo = 150; gr.addColorStop(0, `rgb(${hi},${hi},${hi})`); gr.addColorStop(1, `rgb(${lo},${lo},${lo})`); g.fillStyle = gr; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fill(); }
  for (let i = 0; i < 120; i++) { g.fillStyle = 'rgba(255,255,255,0.7)'; g.beginPath(); g.arc(R() * w, R() * h, 2 + R() * 3, 0, 7); g.fill(); } });
const eyeTex = () => cv(256, 256, (g, w, h) => { g.fillStyle = '#d0d0d0'; g.fillRect(0, 0, w, h); g.strokeStyle = 'rgba(70,70,70,0.6)'; for (let y = 6; y < h; y += 12) { g.lineWidth = 3; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); } const R = rnd(3); for (let i = 0; i < 300; i++) { g.fillStyle = 'rgba(255,255,255,0.5)'; g.fillRect(R() * w, R() * h, 3, 3); } });
const barkTex = () => cv(512, 256, (g, w, h) => { g.fillStyle = '#6a4a2a'; g.fillRect(0, 0, w, h); const R = rnd(8); for (let i = 0; i < 140; i++) { const y = R() * h; g.strokeStyle = R() < 0.5 ? 'rgba(40,24,12,0.6)' : 'rgba(140,104,70,0.4)'; g.lineWidth = 1 + R() * 3; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= w; x += 24) g.lineTo(x, y + (R() - 0.5) * 6); g.stroke(); }
  for (let i = 0; i < 30; i++) { g.fillStyle = `rgba(${90 + R() * 40 | 0},${130 + R() * 40 | 0},${50 + R() * 20 | 0},0.6)`; g.beginPath(); g.ellipse(R() * w, R() * h, 8 + R() * 20, 4 + R() * 10, 0, 0, 7); g.fill(); } });
export function chameleon() {
  const Ch = C.chameleon(); const st = tx('scales', scaleTex), et = tx('eye', eyeTex);
  const skin = Ch.group.children[0].material; skin.map = st; skin.bumpMap = st; skin.bumpScale = 1.4; skin.roughness = 0.45; skin.needsUpdate = true;
  Ch.group.traverse(o => { if (o.isMesh && o.material !== skin && o.material.color && o.geometry.type === 'SphereGeometry' && o.geometry.parameters.radius === 1 && o.scale.y < 0.2) { o.material.map = st; o.material.needsUpdate = true; } });
  // eye turrets: ridged rings (separate material that follows the skin colour)
  const eyeM = new THREE.MeshStandardMaterial({ map: et, bumpMap: et, bumpScale: 1.5, roughness: 0.5 });
  Ch.group.traverse(o => { if (o.isMesh && o.material === skin && o.geometry.type === 'SphereGeometry' && Math.abs(o.geometry.parameters.radius - 0.2) < 1e-6) o.material = eyeM; });
  // glossy eye with a gold iris ring around the pupil
  Ch.group.traverse(o => { if (o.isMesh && o.material.color && o.material.color.getHex() === 0x0a0a0a && o.geometry.type === 'SphereGeometry') { o.material = new THREE.MeshPhysicalMaterial({ color: 0x050505, roughness: 0.05, clearcoat: 1 }); const ir = new THREE.Mesh(new THREE.TorusGeometry(0.065, 0.014, 8, 20), new THREE.MeshStandardMaterial({ color: 0xd8a830, roughness: 0.3, metalness: 0.4 })); ir.rotation.y = Math.PI / 2; o.add(ir); } });
  const up = Ch.update; Ch.update = (T) => { up(T); eyeM.color.copy(skin.color); };
  Ch.update(0); return Ch;
}
export function branch(len = 14) {
  const B = C.branch(len); const bt = tx('bark', barkTex); const btm = bt.clone(); btm.needsUpdate = true; btm.repeat.set(len / 2, 1);
  B.children[0].material = new THREE.MeshStandardMaterial({ map: btm, bumpMap: btm, bumpScale: 3, roughness: 0.95 });
  // side twigs with leaf clusters
  const R = rnd(31); const tm = B.children[0].material;
  for (let k = 0; k < 7; k++) { const x = (R() - 0.5) * len * 0.9; if (Math.abs(x) < 2.5) continue; const tw = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.08, 1.8, 8), tm); tw.geometry.translate(0, 0.9, 0); tw.position.set(x, 0, 0); tw.rotation.set((R() - 0.5) * 1.2, 0, (R() - 0.5) * 1.4); B.add(tw);
    const b = bush(70 + k, 260, 0.9); b.scale.setScalar(1.6); const tip = new THREE.Vector3(0, 1.8, 0).applyEuler(tw.rotation).add(tw.position); b.position.copy(tip); B.add(b); }
  return B;
}
const cellTex = (base, line, n, seed) => cv(512, 256, (g, w, h) => { g.fillStyle = base; g.fillRect(0, 0, w, h); const R = rnd(seed);
  const pts = []; for (let i = 0; i < n; i++) { const x = R() * w, y = R() * h; [-w, 0, w].forEach(dx => [-h, 0, h].forEach(dy => pts.push([x + dx, y + dy]))); }
  const img = g.getImageData(0, 0, w, h); const d = img.data; const lc = line.match(/[\d.]+/g).map(Number);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { let d1 = 1e9, d2 = 1e9, ni = 0; for (let i = 0; i < pts.length; i++) { const dx = pts[i][0] - x, dy = pts[i][1] - y; const dd = dx * dx + dy * dy; if (dd < d1) { d2 = d1; d1 = dd; ni = i; } else if (dd < d2) d2 = dd; }
    const e = Math.sqrt(d2) - Math.sqrt(d1); const k = 4 * (y * w + x); const shade = 0.9 + 0.1 * ((ni * 7919) % 13) / 13;
    if (e < 2.4) { const a = lc[3]; d[k] = d[k] * (1 - a) + lc[0] * a; d[k + 1] = d[k + 1] * (1 - a) + lc[1] * a; d[k + 2] = d[k + 2] * (1 - a) + lc[2] * a; } else if (d1 < 9) { d[k] *= 0.7; d[k + 1] *= 0.6; d[k + 2] *= 0.6; } else { d[k] *= shade; d[k + 1] *= shade; d[k + 2] *= shade; } }
  g.putImageData(img, 0, 0); });
export function skinSection() {
  const S = C.skinSection(); const kids = S.group.children;
  const block = kids[0], top = kids[1], cell = kids[2];
  block.material = new THREE.MeshStandardMaterial({ map: cellTex('#e6b8a4', 'rgba(150,80,70,0.55)', 120, 4), transparent: true, opacity: 0.55, depthWrite: false, roughness: 0.8 });
  top.material = new THREE.MeshPhysicalMaterial({ map: cellTex('#f2d22a', 'rgba(170,120,10,0.7)', 60, 7), transparent: true, opacity: 0.8, roughness: 0.4, clearcoat: 0.6 });
  cell.material = new THREE.MeshStandardMaterial({ map: cellTex('#c8dcff', 'rgba(90,130,200,0.5)', 24, 9), transparent: true, opacity: 0.3, depthWrite: false, roughness: 0.3 });
  // crystals: smoother, faceted-glass look
  S.group.traverse(o => { if (o.isInstancedMesh) { o.geometry = new THREE.OctahedronGeometry(0.1, 0); o.material.roughness = 0.02; o.material.iridescence = 1; o.material.transmission = 0.2; o.material.thickness = 0.1; o.material.needsUpdate = true; } });
  return S;
}
