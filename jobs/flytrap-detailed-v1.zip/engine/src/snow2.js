// detail kit for snowflakes: ridged translucent ice arms, hexagonal-ring core plates, frost sparkle; bokeh snow backdrop
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as S from './snow.js';
export { lattice, vapour, water } from './snow.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
// arm: bright edges + central ridge + faint parallel grooves (u = along the arm, v = across)
const armTex = () => cv(64, 128, (g, w, h) => { const gr = g.createLinearGradient(0, 0, 0, h); [[0, '#ffffff'], [0.12, '#b8dcf4'], [0.4, '#d8eefc'], [0.5, '#ffffff'], [0.6, '#d8eefc'], [0.88, '#b8dcf4'], [1, '#ffffff']].forEach(([s, c]) => gr.addColorStop(s, c)); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.strokeStyle = 'rgba(150,200,235,0.6)'; g.lineWidth = 1; [0.28, 0.36, 0.64, 0.72].forEach(s => { g.beginPath(); g.moveTo(0, s * h); g.lineTo(w, s * h); g.stroke(); }); });
const coreTex = () => cv(512, 512, (g, w, h) => { g.fillStyle = '#cfe8fa'; g.fillRect(0, 0, w, h); const cx = w / 2, cy = h / 2; const hex = (r) => { g.beginPath(); for (let k = 0; k <= 6; k++) { const a = k * Math.PI / 3; const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r; k ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); };
  for (let r = 30; r < 260; r += 26) { g.strokeStyle = `rgba(255,255,255,${0.35 + 0.4 * (r % 52 === 30 ? 1 : 0)})`; g.lineWidth = r % 52 === 30 ? 4 : 2; hex(r); }
  g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = 5; for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a) * 256, cy + Math.sin(a) * 256); g.stroke(); }
  const R = rnd(6); for (let i = 0; i < 80; i++) { g.fillStyle = 'rgba(255,255,255,0.6)'; g.beginPath(); g.arc(R() * w, R() * h, 1 + R() * 2.5, 0, 7); g.fill(); } });
export const ICE = () => { const m = S.ICE(); m.map = tx('arm', armTex); m.emissiveMap = m.map; m.emissive.set(0x9ad0ff); m.emissiveIntensity = 0.35; m.iridescence = 0.8; m.transmission = 0.25; m.sheen = 0.6; m.sheenColor = new THREE.Color(0xcfeaff); return m; };
export function flake(seed, o) {
  const F = S.flake(seed, o); const am = ICE(); const cm = ICE(); cm.map = tx('core', coreTex); cm.emissiveMap = cm.map;
  F.group.children.forEach(c => { if (c.isMesh && c.material === F.mat) c.material = cm; });
  F.group.traverse(c => { if (c.isMesh && c.material === F.mat) c.material = am; });
  // frost sparkle: tiny glints along the arms
  const R = rnd((seed || 1) * 13); const gm = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false, transparent: true });
  const glints = []; for (let i = 0; i < 24; i++) { const s = new THREE.Mesh(new THREE.OctahedronGeometry(0.018, 0), gm); const a = (i % 6) * Math.PI / 3 + Math.PI / 6; s.userData = { a, u: 0.25 + R() * 0.75, ph: R() * 6 }; F.group.add(s); glints.push(s); }
  const grow = F.grow; F.grow = (g) => { grow(g); cm.emissiveIntensity = am.emissiveIntensity; cm.opacity = am.opacity; cm.transparent = am.transparent; const L = Math.max(0, (g - 0.22) / 0.78) * ((o && o.armMax) || 1.6); const rc = 0.08 + 0.32 * Math.min(1, g / 0.3); glints.forEach(s => { const r = rc * 0.866 + s.userData.u * L; s.position.set(Math.cos(s.userData.a) * r, Math.sin(s.userData.a) * r, 0.02); s.visible = L > 0.05; }); };
  F.tick = (T) => { glints.forEach(s => { const k = Math.max(0, Math.sin(T * 3 + s.userData.ph)); s.scale.setScalar(0.3 + 1.4 * k * k); }); };
  F.mat = am; F.grow(0.05); return F;
}
// soft round bokeh texture for falling snow
export function softDot() { return tx('dot', () => cv(64, 64, (g, w, h) => { const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.4, 'rgba(235,245,255,0.6)'); gr.addColorStop(1, 'rgba(220,235,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); })); }
