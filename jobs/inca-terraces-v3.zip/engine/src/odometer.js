// Roman odometer reel: paved Roman road + milestones, cart with spoked wheels and a see-through gearbox (axle peg,
// 400-tooth gear drawn with fewer teeth, pebble disc with stones, bronze bowl), Hero-style dial face.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex } from './rome.js';
import { wheel } from './chariot.js';
import { gear, mechMats } from './mech.js';

export function road(scene, { len = 600, w = 5 } = {}) {
  const tex = canvasTex(256, 256, (x) => { x.fillStyle = '#7a7466'; x.fillRect(0, 0, 256, 256); const R = rng(3); for (let i = 0; i < 70; i++) { const c = 110 + R() * 50; x.fillStyle = `rgb(${c},${c - 4},${c - 14})`; x.beginPath(); x.ellipse(R() * 256, R() * 256, 12 + R() * 14, 10 + R() * 10, R() * 3, 0, 7); x.fill(); } }, [2, 120]);
  const r = new THREE.Mesh(new THREE.PlaneGeometry(w, len), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9 })); r.rotation.x = -Math.PI / 2; r.position.y = 0.03; r.receiveShadow = true; scene.add(r);
  const kerbM = new THREE.MeshStandardMaterial({ color: 0x9a948a, roughness: 0.9 });
  for (const s of [-1, 1]) { const k = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.2, len), kerbM); k.position.set(s * (w / 2 + 0.15), 0.1, 0); scene.add(k); }
  return r;
}
export function milestone() {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 1.8, 20), new THREE.MeshStandardMaterial({ color: 0xd8d0c0, roughness: 0.7 })); m.position.y = 0.9;
  const g = new THREE.Group(); g.add(m);
  const band = new THREE.Mesh(new THREE.CylinderGeometry(0.31, 0.31, 0.12, 20), new THREE.MeshStandardMaterial({ color: 0xa8402a })); band.position.y = 1.3; g.add(band);
  return shadowAll(g);
}
// cart: body on an axle along x, wheels r=0.6 (4 Roman feet ~ 1.2 m), shafts to +z; gearbox inside the body
export function cart({ seeThrough = false } = {}) {
  const g = new THREE.Group(); const r = 0.6;
  const wood = new THREE.MeshStandardMaterial({ color: 0x8a5a32, roughness: 0.8, bumpMap: fabricTexture(5), bumpScale: 2 });
  const glass = new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.25, roughness: 0.05, depthWrite: false });
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.8, 1.4), seeThrough ? glass : wood); body.position.y = r + 0.45; g.add(body);
  const wl = wheel(r), wr = wheel(r); [wl, wr].forEach((w, i) => { w.rotation.y = Math.PI / 2; w.position.set(i ? 0.7 : -0.7, r, 0); g.add(w); });
  for (const s of [-1, 1]) { const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.0, 8), wood); sh.rotation.x = Math.PI / 2 - 0.1; sh.position.set(s * 0.3, r, 1.6); g.add(sh); }
  // gearbox: peg on the axle, big gear (vertical, facing x), pebble disc on top with a bowl below
  const box = new THREE.Group(); box.position.y = r; g.add(box);
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.6, 10), wood); axle.rotation.z = Math.PI / 2; box.add(axle);
  const pegP = new THREE.Group(); box.add(pegP);
  const peg = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.16, 0.04), mechMats().bronze); peg.position.y = 0.1; pegP.add(peg);
  const big = gear(0.34, 80, 0.03); big.rotation.y = Math.PI / 2; big.position.set(0.0, 0.0, 0.0); const bigP = new THREE.Group(); bigP.position.set(0.12, 0.34 + 0.12, 0); bigP.add(big); box.add(bigP);
  const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.04, 40), mechMats().bronze); disc.position.set(-0.15, 0.86, 0); box.add(disc);
  const stones = new THREE.Group(); disc.add(stones);
  const sm = new THREE.MeshStandardMaterial({ color: 0xe8e0d0, roughness: 0.6 });
  for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; const s = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), sm); s.position.set(Math.cos(a) * 0.22, 0.04, Math.sin(a) * 0.22); stones.add(s); }
  const bowl = new THREE.Mesh(new THREE.SphereGeometry(0.16, 20, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), mechMats().bronze); bowl.material = mechMats().bronze.clone(); bowl.material.side = THREE.DoubleSide; bowl.position.set(-0.15, 0.25, 0.22); box.add(bowl);
  const drop = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), sm); box.add(drop);
  const inBowl = [...Array(8)].map((_, i) => { const s = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), sm); s.position.set(-0.15 + Math.cos(i * 2.4) * 0.06, 0.16 + (i > 4 ? 0.04 : 0), 0.22 + Math.sin(i * 2.4) * 0.06); s.visible = false; box.add(s); return s; });
  box.visible = seeThrough;
  shadowAll(g); if (seeThrough) body.castShadow = false;
  // d = distance rolled (m); miles counted from d; dropU 0..1 animates the next stone falling
  g.roll = (d, { dropU = -1, count = 0 } = {}) => {
    const turns = d / (2 * Math.PI * r);
    [wl, wr].forEach(w => w.rotation.set(0, Math.PI / 2, turns * Math.PI * 2, 'YXZ'));
    pegP.rotation.x = turns * Math.PI * 2;
    big.rotation.z = Math.floor(turns) / 80 * Math.PI * 2 + Math.min(1, (turns % 1) * 8) / 80 * Math.PI * 2;
    disc.rotation.y = big.rotation.z * 0.1;
    drop.visible = dropU >= 0 && dropU <= 1; drop.position.set(-0.15, 0.84 - Math.max(0, dropU) ** 2 * 0.6, 0.22 * Math.min(1, Math.max(0, dropU) * 4));
    inBowl.forEach((s, i) => s.visible = i < count);
  };
  g.roll(0); g.box = box; g.body = body; g.big = big;
  return g;
}
// Hero-style dial face with a pointer
export function dial() {
  const tex = canvasTex(256, 256, (x) => { x.fillStyle = '#c89a52'; x.beginPath(); x.arc(128, 128, 124, 0, 7); x.fill(); x.strokeStyle = '#3a2410'; x.lineWidth = 4; for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; x.beginPath(); x.moveTo(128 + Math.cos(a) * 90, 128 + Math.sin(a) * 90); x.lineTo(128 + Math.cos(a) * 115, 128 + Math.sin(a) * 115); x.stroke(); } x.beginPath(); x.arc(128, 128, 118, 0, 7); x.stroke(); });
  const g = new THREE.Group();
  const face = new THREE.Mesh(new THREE.CircleGeometry(0.5, 40), new THREE.MeshStandardMaterial({ map: tex, metalness: 0.6, roughness: 0.4 })); g.add(face);
  const ptr = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.4, 0.02), new THREE.MeshStandardMaterial({ color: 0x2a1a0a })); ptr.position.set(0, 0.18, 0.02); const pp = new THREE.Group(); pp.add(ptr); pp.position.z = 0.01; g.add(pp);
  g.set = (a) => { pp.rotation.z = -a; };
  return shadowAll(g);
}
