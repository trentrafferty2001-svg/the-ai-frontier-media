// Archimedes screw reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { birds, waterMaterial } from './world.js';
import { riceClumps, clumpGrid, splash2 } from './farm2.js';
import { glowSprite } from './props.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake, ikArm } from './anim.js';
import { shadowAll } from './rome.js';
import { sea, longship, rideWaves } from './norse.js';
import { archScrew, greek, medLand, river, greekTemple, mineTunnel, reliefWall, hydroScrew } from './classic.js';
import { VO } from './vo_ar.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you needed', 3], ['to lift *water*', 3], ['*uphill*', 1], ['*2,000 years* ago', 4], ['you had no', 3], ['*electric pumps*', 2]],
  [['But one', 2], ['*simple tube*', 2], ['could do it', 3], ['just by *turning*', 3], ['a *handle*', 2]],
  [["It's called", 2], ['the *Archimedes*', 2], ['*screw*', 1], ['named after', 2], ['the *Greek genius*', 3], ['from *Syracuse*', 2]],
  [['Inside', 1], ['a *tilted tube*', 3], ['a wide *spiral*', 3], ['winds around', 2], ['a *central pole*', 3]],
  [['*Dip*', 1], ['the bottom end', 3], ['into *water*', 2], ['and start *turning*', 3]],
  [['*Each turn*', 2], ['*scoops* up', 2], ['a little', 2], ['*pocket* of water', 3]],
  [['The pockets', 2], ["*can't* slide", 2], ['back down', 2], ['so they *ride*', 3], ['the *spiral upward*', 3]],
  [['Turn after turn', 3], ['the water *climbs*', 3], ['until it *spills*', 3], ['out of the *top*', 4]],
  [['*Farmers* used it', 3], ['to water', 2], ['their *fields*', 2], ['and *Romans*', 2], ['used it to drain', 4], ['*flooded mines*', 2]],
  [['One *story* says', 3], ['Archimedes', 1], ['used it to pump', 4], ['water out of', 3], ['a *giant ship*', 3]],
  [['Some *historians*', 2], ['think the idea', 3], ['is *even older*', 3], ['from', 1], ['*ancient Assyria*', 2]],
  [["And it's", 2], ['*still working*', 2], ['*today*', 1]],
  [['*Modern* versions', 2], ['run in *reverse*', 3], ['letting *falling water*', 3], ['spin the screw', 3], ['to make *electricity*', 3]],
  [['A *2,000-year-old*', 5], ['*idea*', 1], ['still *turning*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: a riverside field with a screw lifting water into a ditch ============
// river along x at z = 3, field up the bank toward -z; screw from the river (bottom) up to the ditch (top)
const TILT = 0.62; // radians from horizontal
function riverside(makeStage, { preset = 'golden', sunDir = [0.45, 0.4, 0.8], dry = false, fog = 0.004, field = true, ...o } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize: 5, shadowAt: [0, 1, 1], envI: 0.9, ...o });
  medLand(scene, { seed: 3 });
  const W = river(scene, { z: 3.2, w: 4 });
  const ditch = new THREE.Mesh(new THREE.PlaneGeometry(60, 0.6), waterMaterial({ color: 0x3a6a7a, opacity: 1, ripple: 1.0 })); ditch.rotation.x = -Math.PI / 2; ditch.position.set(0, 0.03, 0.55); ditch.visible = !dry; scene.add(ditch);
  if (field) scene.add(riceClumps(clumpGrid(-12, 12, -9, -2.2, 0.4, { y: 0.0, seed: 41 }), dry ? { h: 0.5, blades: 8, seed: 42, color: 0x9a8a48, color2: 0xc8b46a } : { h: 0.7, blades: 10, seed: 42 }));
  const s = archScrew({ L: 3.4, R: 0.3, turns: 7 }); s.rotation.x = -(Math.PI / 2 - TILT); s.position.set(0, -0.3, 3.9); scene.add(s);
  fillLight(scene, [0.4, 0.5, 1], 0.7, 0xffe6c8);
  return { scene, s, W, ditch };
}
// world point at distance d up the screw axis (on its centre line)
const axisPt = (s, d) => { s.updateMatrixWorld(true); return s.localToWorld(V(0, d, 0)); };

// ============ S0: a dry field; the river lies below, out of reach ============
function sDry({ makeStage }) {
  const R = riverside(makeStage, { dry: true, sunDir: [0.3, 0.7, 0.6] }); R.s.visible = false;
  const f = greek({ color: 0xc8b48a, beard: false }); f.root.position.set(-0.6, 0, 0.2); f.root.rotation.y = Math.PI * 0.9; R.scene.add(f.root);
  const jar = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 12), new THREE.MeshStandardMaterial({ color: 0xa85a34, roughness: 0.8 })); jar.scale.y = 1.3; R.scene.add(jar);
  const c = cam(38);
  return {
    scene: R.scene, camera: c,
    update(t) {
      standPose(f, t, { head: [0.45, 0, 0], neck: [0.2, 0, 0], rSh: [-0.3, 0, -0.2], rEl: [-0.6, 0, 0] }); f.setMood('happy'); f.setMouth(0); f.blink(blinkK(t, [1.6, 3.8])); f.grip(0.3, 0.9);
      R.scene.updateMatrixWorld(true); jar.position.copy(wpos(f.j.rWr, V(0, -0.15, 0.08)));
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(-3.2, -2.4, k), lerp(1.4, 2.2, k), lerp(-3.0, -3.6, k)], [lerp(-0.4, 0.4, k), lerp(0.6, -0.4, k), lerp(1.0, 3.0, k)]);
      return { bloom: 0.6, flare: 0.7, warm: 1.3, sat: 1.05 };
    },
  };
}
// ============ S1: a hand on the crank, the screw starts to turn ============
function sCrank({ makeStage }) {
  const R = riverside(makeStage, {});
  const top = axisPt(R.s, R.s.L + 0.15);
  const c = cam(34);
  return {
    scene: R.scene, camera: c,
    update(t) {
      const a = easeIn(range(t, 0.3, 1.2)) * (t - 0.3) * 2.6;
      R.s.set(a, 1, 1);
      const k = easeInOut(range(t, 0, 3.5));
      const pos = [top.x + lerp(1.4, 1.0, k), top.y + lerp(0.6, 0.4, k), top.z + lerp(0.6, 1.1, k)];
      place(c, pos, [top.x, top.y - 0.2, top.z + 0.2]);
      return { bloom: 0.55, warm: 1.2, dof: dofTo(pos, [top.x, top.y, top.z], 0.005, 0.01) };
    },
  };
}
// ============ S2: Archimedes in Syracuse, a temple on the hill behind ============
function sSyracuse({ makeStage }) {
  const R = riverside(makeStage, { sunDir: [0.6, 0.25, -0.76] });
  const tmp = greekTemple(); tmp.position.set(-10, 0, -26); tmp.rotation.y = 0.3; R.scene.add(tmp);
  const tmp2 = greekTemple({ w: 6, d: 10, colH: 3.4 }); tmp2.position.set(12, 0, -34); tmp2.rotation.y = -0.4; R.scene.add(tmp2);
  const a = greek(); a.root.position.set(0.9, 0, 0.3); a.root.rotation.y = -0.5; R.scene.add(a.root);
  const c = cam(38);
  return {
    scene: R.scene, camera: c,
    update(t) {
      R.s.set(t * 2.2, 1, 1);
      standPose(a, t, { rSh: [-1.2, 0, -0.3], rEl: [-0.4, 0, 0], head: [0, -0.4, 0] }); a.setMood('happy'); a.setMouth(0); a.blink(blinkK(t, [1.2, 3.3])); a.grip(0.2, 0.1);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(3.4, 2.6, k), lerp(1.4, 1.8, k), lerp(4.6, 5.4, k)], [lerp(0.6, -1.5, k), lerp(1.3, 2.5, k), lerp(0, -14, k)]);
      return { bloom: 0.6, flare: 1.0, warm: 1.3 };
    },
  };
}
// ============ S3: cut-away: the spiral around the central pole (no water yet), slow orbit ============
function sInside({ makeStage }) {
  const R = riverside(makeStage, {});
  const mid = axisPt(R.s, R.s.L * 0.5);
  const c = cam(36);
  return {
    scene: R.scene, camera: c,
    update(t) {
      R.s.set(t * 0.8, 0, 0);
      const a = lerp(0.5, 1.3, easeInOut(range(t, 0, 4.4)));
      place(c, [mid.x + Math.sin(a) * 2.6, mid.y + 0.9, mid.z + Math.cos(a) * 2.6], [mid.x, mid.y, mid.z]);
      return { bloom: 0.5, warm: 1.1, dof: dofTo([mid.x + Math.sin(a) * 2.6, mid.y + 0.9, mid.z + Math.cos(a) * 2.6], [mid.x, mid.y, mid.z], 0.004, 0.008) };
    },
  };
}
// ============ S4: the bottom end in the river; Archimedes turns the crank ============
function sDip({ makeStage, start: ST }) {
  const tT = at(4, 'turning') - ST;
  const R = riverside(makeStage, {});
  const a = greek(); R.scene.add(a.root);
  const top = axisPt(R.s, R.s.L + 0.15);
  a.root.position.set(top.x + 0.75, 0, top.z - 0.2); a.root.rotation.y = -Math.PI / 2;
  const sp = splash2(0.5, 5); R.scene.add(sp);
  const c = cam(38);
  return {
    scene: R.scene, camera: c,
    update(t) {
      const ang = t > tT - 0.3 ? (t - tT + 0.3) * 2.4 : 0;
      R.s.set(ang, 0.12, 0);
      standPose(a, t, { spine: [0.15, 0, 0] }); a.setMood('happy'); a.setMouth(0); a.grip(0.9, 0.9);
      R.scene.updateMatrixWorld(true);
      if (R.s.userData.handle) { const hp = R.s.userData.handle.getWorldPosition(V(0, 0, 0)); ikArm(a, 'r', hp, wpos(a.root, V(-0.6, 0.4, 0.2)), V(0, 1, 0)); }
      const b = axisPt(R.s, 0.5); sp.position.set(b.x, 0.03, b.z); sp.update((t * 0.8) % 1.2);
      const k = easeInOut(range(t, 0, 3.2));
      place(c, [lerp(3.6, 3.0, k), lerp(0.6, 1.4, k), lerp(4.8, 4.2, k)], [0, lerp(-0.2, 0.8, k), lerp(2.6, 1.6, k)]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S5/S6/S7: water pockets climbing; camera tracks from bottom to top ============
function sClimb(phase) {
  return ({ makeStage, start: ST }) => {
    const R = riverside(makeStage, {});
    const sp = splash2(0.6, 7); R.scene.add(sp);
    const c = cam(36);
    const L = 3.4;
    return {
      scene: R.scene, camera: c,
      update(t, T) {
        const ang = T * 2.4;
        const fill = phase === 0 ? lerp(0.15, 0.3, range(t, 0, 2.6)) : phase === 1 ? lerp(0.3, 0.9, range(t, 0, 4)) : 1;
        R.s.set(ang, fill, phase === 2 ? 1 : 0);
        const d = phase === 0 ? 0.9 : phase === 1 ? lerp(0.9, 2.6, easeInOut(range(t, 0, 4))) : L + 0.1;
        const p = axisPt(R.s, d);
        if (phase === 2) { const top = axisPt(R.s, L + 0.3); sp.position.set(top.x, 0.02, top.z - 0.6); sp.update((t * 0.9) % 1.1); } else sp.update(-1);
        const off = phase === 2 ? [1.4, 0.6, 1.2] : [1.1, 0.5, 0.9];
        const pos = [p.x + off[0], p.y + off[1], p.z + off[2]];
        place(c, pos, [p.x, p.y - (phase === 2 ? 0.3 : 0), p.z]);
        return { bloom: 0.55, warm: 1.15, dof: dofTo(pos, [p.x, p.y, p.z], 0.005, 0.01) };
      },
    };
  };
}
// ============ S8a: farmers and green fields ============
function sFields({ makeStage }) {
  const R = riverside(makeStage, { sunDir: [0.5, 0.45, -0.74] });
  const fs = [[-3, -4, 0.4], [2.5, -5.5, -0.8]].map(([x, z, ry], i) => { const f = greek({ color: i ? 0xa8805a : 0xc8b48a, beard: !!i }); f.root.position.set(x, 0, z); f.root.rotation.y = ry; R.scene.add(f.root); return f; });
  const b = birds(4, { from: [-30, 9, -20], to: [30, 12, -30], spread: 6, speed: 0.05, scale: 1.5, seed: 4 }); R.scene.add(b); R.scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene: R.scene, camera: c,
    update(t, T) {
      R.s.set(T * 2.4, 1, 1);
      fs.forEach((f, i) => { standPose(f, t + i, { spine: [0.3 * (i === 0), 0, 0], lSh: [-0.6, 0, 0.2] }); f.setMood('happy'); f.setMouth(0); });
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(6, 4.5, k), lerp(4, 3, k), lerp(6, 5, k)], [lerp(-1, 0, k), 0.5, lerp(-3, -3.5, k)]);
      return { bloom: 0.55, flare: 0.8, warm: 1.2 };
    },
  };
}
// ============ S8b: a Roman mine: a worker treads a screw lifting water out of the flooded tunnel ============
function sMine({ makeStage }) {
  const scene = makeStage({ shadowSize: 3, sunDir: [0, 4, 1], sun: 0.4 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x0a0806); u.mid.value.set(0x0c0a08); u.horizon.value.set(0x100c0a); u.floorC.value.set(0x080604);
  scene.environmentIntensity = 0.25;
  mineTunnel(scene);
  const s = archScrew({ L: 3.2, R: 0.3, turns: 7, crank: false }); s.rotation.x = -(Math.PI / 2 - 0.5); s.position.set(0, -0.55, 1.5); scene.add(s);
  const w = greek({ color: 0x8a7a5a, beard: false, skin: 0xb98060 }); scene.add(w.root);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t, T) {
      s.set(T * 2.0, 1, 1);
      const top = axisPt(s, 2.6); w.root.position.set(top.x + 0.45, top.y - 0.2, top.z); w.root.rotation.y = -Math.PI / 2;
      const st = Math.sin(t * 4);
      standPose(w, t, { lHip: [-0.4 + st * 0.3, 0, 0.1], rHip: [-0.4 - st * 0.3, 0, -0.1], lKn: [0.4, 0, 0], rKn: [0.4, 0, 0], lSh: [-1.2, 0, 0.3], rSh: [-1.2, 0, -0.3] }); w.setMood('happy'); w.setMouth(0); w.grip(0.9, 0.9);
      const k = easeInOut(range(t, 0, 2.8));
      place(c, [lerp(1.8, 1.4, k), lerp(1.4, 1.6, k), lerp(4.4, 3.8, k)], [0, 0.8, 0]);
      return { bloom: 0.7, warm: 1.3, exposure: 1.3 };
    },
  };
}
// ============ S9: the giant ship: a screw pumping bilge water over the side ============
function sShip({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.35, 0.79], fog: 0.004, shadowSize: 12, shadowAt: [0, 1, 0], envI: 0.9 });
  const S = sea(scene, { scale: 0.6, color: 0x2a4a6a });
  const ship = longship({ L: 22, W: 5, D: 1.8 }); scene.add(ship);
  ship.traverse(o => { if (o.isMesh && o.geometry.type === 'ConeGeometry' && o.position.y > 2) o.visible = false; });
  const s = archScrew({ L: 2.4, R: 0.25, turns: 6, crank: false }); s.rotation.set(0, 0, 0); s.rotation.x = -0.9; s.position.set(1.5, 0.0, 1.0); ship.add(s);
  const sp = splash2(0.8, 3); scene.add(sp);
  const crew = [0, 1].map(i => { const g = greek({ color: i ? 0x8a6a4a : 0xc8b48a, beard: !i }); g.root.position.set(1.5 + (i ? -0.8 : 0.6), 0.38, 0.2); g.root.rotation.y = 0.2; ship.add(g.root); return g; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t, T) {
      rideWaves(ship, 0, 0, 0, T, 0.6);
      s.set(T * 2.2, 1, 1);
      crew.forEach((g, i) => { standPose(g, t + i, { lSh: [-1.0, 0, 0.3], rSh: [-1.0, 0, -0.3], spine: [0.2, 0, 0] }); g.setMood('happy'); g.setMouth(0); });
      scene.updateMatrixWorld(true); const tp = s.localToWorld(V(0, 2.5, -0.3)); sp.position.set(tp.x, 0.05, tp.z + 0.6); sp.update((t * 0.9) % 1.1);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(8, 5, k), lerp(4.5, 3.2, k), lerp(14, 10, k)], [lerp(0, 1.5, k), 1.6, 0.5]);
      return { bloom: 0.6, flare: 0.9, warm: 1.25 };
    },
  };
}
// ============ S10: an Assyrian relief carved in stone, torch-lit ============
function sRelief({ makeStage }) {
  const scene = makeStage({ shadowSize: 4, sunDir: [-2, 3, 3], sun: 1.0 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x120e0a); u.mid.value.set(0x18120c); u.horizon.value.set(0x20180e); u.floorC.value.set(0x0c0a08);
  const w = reliefWall(); scene.add(w);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), new THREE.MeshStandardMaterial({ color: 0x4a3a2a, roughness: 1 })); fl.rotation.x = -Math.PI / 2; fl.receiveShadow = true; scene.add(fl);
  const torch = new THREE.PointLight(0xffa050, 18, 12, 1.6); torch.position.set(2.5, 3.5, 2.5); scene.add(torch);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      torch.intensity = 18 + Math.sin(t * 13) * 2 + Math.sin(t * 7.3) * 1.5;
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(-1.6, 1.2, k), lerp(3.4, 2.8, k), lerp(9.5, 8.0, k)], [lerp(-0.6, 0.4, k), lerp(3.2, 2.6, k), 0]);
      return { bloom: 0.5, warm: 1.35 };
    },
  };
}
// ============ S11/S12: modern hydropower screw ============
function sHydro(close) {
  return ({ makeStage, start: ST }) => {
    const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.6, 0.62], fog: 0.004, shadowSize: 10, shadowAt: [0, 2, -4], envI: 0.9 });
    medLand(scene, { seed: 8, groundC: 0x6f8a4a });
    const H = hydroScrew(); scene.add(H);
    const upper = new THREE.Mesh(new THREE.PlaneGeometry(4, 20), waterMaterial({ color: 0x3a6a7a, opacity: 1, ripple: 1.5 })); upper.rotation.x = -Math.PI / 2; upper.position.set(0, 4.0, -19); scene.add(upper);
    const lower = new THREE.Mesh(new THREE.PlaneGeometry(6, 20), waterMaterial({ color: 0x3a6a7a, opacity: 1, ripple: 2.0 })); lower.rotation.x = -Math.PI / 2; lower.position.set(0, -0.6, 9); scene.add(lower);
    const wm = new THREE.MeshStandardMaterial({ color: 0x8fd0f0, roughness: 0.05, transparent: true, opacity: 0.55, emissive: 0x1a4a6a, emissiveIntensity: 0.3 });
    const flow = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.25, 9.4), wm); flow.rotation.x = 0.38 - 0.0; flow.position.set(0, 1.6, -4.3); flow.rotation.x = Math.atan2(4.6, 9) * 1; flow.visible = false;
    fillLight(scene, [0.4, 0.5, 1], 0.6);
    const c = cam(close ? 34 : 40);
    return {
      scene, camera: c,
      update(t, T) {
        H.screw.set(-T * 1.6, 0, 0);
        H.bolt.material.emissiveIntensity = close ? 1.2 + 0.8 * Math.max(0, Math.sin(t * 9)) * range(t, 2.5, 3.5) : 0.6;
        if (close) { const k = easeInOut(range(t, 0, 5.6)); place(c, [lerp(3.5, 2.6, k), lerp(3.2, 5.6, k), lerp(2.5, -4.5, k)], [0, lerp(1.6, 4.4, k), lerp(-2, -9.2, k)]); }
        else { const k = easeInOut(range(t, 0, 1.9)); place(c, [lerp(9, 7, k), lerp(5, 6, k), lerp(9, 7, k)], [0, 2, -4]); }
        return { bloom: 0.5, warm: 1.0 };
      },
    };
  };
}
// ============ S13: sunset field, the screw turning, the farmer at the crank ============
function sEnd({ makeStage }) {
  const R = riverside(makeStage, { sunDir: [0.6, 0.1, -0.79] });
  const a = greek(); R.scene.add(a.root);
  const top = axisPt(R.s, R.s.L + 0.15);
  a.root.position.set(top.x + 0.75, 0, top.z - 0.2); a.root.rotation.y = -Math.PI / 2;
  const sp = splash2(0.6, 7); R.scene.add(sp);
  const c = cam(38);
  return {
    scene: R.scene, camera: c,
    update(t, T) {
      R.s.set(T * 2.4, 1, 1);
      standPose(a, t, { spine: [0.15, 0, 0] }); a.setMood('happy'); a.setMouth(0); a.grip(0.9, 0.9);
      R.scene.updateMatrixWorld(true);
      if (R.s.userData.handle) { const hp = R.s.userData.handle.getWorldPosition(V(0, 0, 0)); ikArm(a, 'r', hp, wpos(a.root, V(-0.6, 0.4, 0.2)), V(0, 1, 0)); }
      const tp = axisPt(R.s, R.s.L + 0.3); sp.position.set(tp.x, 0.02, tp.z - 0.6); sp.update((t * 0.9) % 1.1);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(4.5, 7, k), lerp(1.6, 3.6, k), lerp(5.5, 8, k)], [0, lerp(1.0, 1.6, k), lerp(0.5, -2, k)]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const cutR = at(8, 'romans') - 0.1;
const S = [
  [0, ls(1), sDry], [ls(1), ls(2), sCrank], [ls(2), ls(3), sSyracuse], [ls(3), ls(4), sInside], [ls(4), ls(5), sDip],
  [ls(5), ls(6), sClimb(0)], [ls(6), ls(7), sClimb(1)], [ls(7), ls(8), sClimb(2)], [ls(8), cutR, sFields], [cutR, ls(9), sMine],
  [ls(9), ls(10), sShip], [ls(10), ls(11), sRelief], [ls(11), ls(12), sHydro(false)], [ls(12), ls(13), sHydro(true)], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
