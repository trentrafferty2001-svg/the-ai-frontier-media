// South-pointing chariot reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { fabricTexture } from './textures.js';
import { chariot, route, soldier, scholar, hills, southArrow, gearScroll, carAxle, chMats } from './chariot.js';
import { VO } from './vo_sp.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Imagine a *cart*', 3], ['with a little *statue*', 4], ['whose arm', 2], ['*always points south*', 3], ['no matter', 2], ['how you *steer*', 3]],
  [['But there\'s *no magnet*', 4], ['inside', 1], ['Just *wooden gears*', 3]],
  [["It's the", 2], ['*south pointing*', 2], ['*chariot*', 1], ['and *Chinese legends*', 3], ['say it led', 3], ['*armies* through *fog*', 3]],
  [['The first', 2], ['*reliable record*', 2], ['says an engineer', 3], ['named *Ma Jun*', 3], ['built one', 2], ['almost', 1], ['*1,800 years* ago', 4]],
  [['The *trick*', 2], ['when a cart *turns*', 4], ['its *outer wheel*', 3], ['rolls *farther*', 2], ['than the *inner* one', 4]],
  [['*Gears compare*', 2], ['the *two wheels*', 3]],
  [['Any *difference*', 2], ['turns the statue', 3], ['the *other way*', 3], ['by *exactly*', 2], ['the angle', 2], ['the cart turned', 3]],
  [['So the cart', 3], ['can *spin*', 2], ['but the statue', 3], ['keeps pointing', 2], ['the *same way*', 3]],
  [['Set it to *south*', 4], ['*once*', 1], ['and it', 2], ['*stays south*', 2]],
  [['Some *historians*', 2], ['think it', 2], ['may have used', 3], ['a *differential*', 2], ['like the gears', 3], ["in a *car's axle*", 4]],
  [["It wasn't *perfect*", 2], ['*Bumps*', 1], ['and *slipping wheels*', 3], ['slowly', 1], ['*threw it off*', 4]],
  [['*Song dynasty*', 2], ['engineers', 1], ['later *rebuilt it*', 3], ['and *wrote down*', 3], ['their *gear designs*', 3]],
  [['No *original*', 2], ['*survives*', 1], ['but *modern models*', 3], ['*still work*', 2]],
  [['A *compass*', 2], ['with *no magnet*', 3], ['Just *gears*', 2], ['and *geometry*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
const SOUTH = Math.PI / 2; // world yaw the figure points at (towards +x)

// ============ shared ============
function field(makeStage, { preset = 'day', sunDir = [-0.5, 0.6, 0.6], fog = 0.003, seed = 1, shadowSize = 8, shadowAt = [0, 0, 0] } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt, envI: 0.9 });
  hills(scene, { seed });
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xfff0e0);
  return scene;
}
const drive = (C, R, s) => { const p = R(s); C.position.set(p.x, 0, p.z); C.rotation.y = p.yaw; C.roll(p.dL, p.dR); return p; };
function trail(scene, color, w = 0.08) { const m = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshBasicMaterial({ color, toneMapped: false, side: THREE.DoubleSide })); scene.add(m); m.frustumCulled = false; m.set = (pts) => { if (pts.length < 2) { m.visible = false; return; } m.visible = true; const P = []; for (let i = 0; i < pts.length - 1; i++) { const [a, b] = [pts[i], pts[i + 1]]; const dx = b[0] - a[0], dz = b[1] - a[1], L = Math.hypot(dx, dz) || 1, nx = -dz / L * w, nz = dx / L * w; P.push(a[0] + nx, 0.03, a[1] + nz, a[0] - nx, 0.03, a[1] - nz, b[0] + nx, 0.03, b[1] + nz, a[0] - nx, 0.03, a[1] - nz, b[0] - nx, 0.03, b[1] - nz, b[0] + nx, 0.03, b[1] + nz); } m.geometry.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); m.geometry.attributes.position.needsUpdate = true; m.geometry.computeBoundingSphere(); }; return m; }
const wheelPos = (p, side, T = 1.4) => [p.x + Math.cos(p.yaw) * side * T / 2, p.z - Math.sin(p.yaw) * side * T / 2];

// ============ S0: the chariot weaves across a field; the little figure keeps pointing one way ============
function sHook({ makeStage }) {
  const scene = field(makeStage, { sunDir: [-0.6, 0.55, 0.5] });
  const C = chariot(); scene.add(C);
  const R = route(20, s => 0.35 * Math.sin(s * 0.55), { z0: -6 });
  const ar = southArrow(1.4); scene.add(ar);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const p = drive(C, R, t * 1.6); C.point(SOUTH);
      ar.position.set(p.x, 2.3, p.z); ar.rotation.y = SOUTH; ar.visible = t > 2.2; ar.scale.setScalar(easeOut(range(t, 2.2, 2.8)) + 0.001);
      const k = easeInOut(range(t, 0, 5.8));
      place(c, [p.x + lerp(-4, -5, k), lerp(4.5, 5.5, k), p.z + lerp(-4, -5.5, k)], [p.x, 1.2, p.z]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S1: see-through body: wooden gears, no magnet ============
function sGears({ makeStage }) {
  const scene = field(makeStage, { sunDir: [-0.4, 0.7, 0.6], shadowSize: 3 });
  const C = chariot({ seeThrough: true }); scene.add(C);
  const R = route(10, s => 0.3, { yaw0: 0.6 });
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const p = drive(C, R, t * 0.6); C.point(SOUTH);
      scene.updateMatrixWorld(true);
      const ctr = C.localToWorld(V(0, 0.68, 0));
      const k = easeInOut(range(t, 0, 3.4));
      const off = C.localToWorld(V(lerp(1.7, 1.3, k), lerp(1.05, 0.9, k), lerp(2.9, 2.3, k)));
      place(c, [off.x, off.y, off.z], [ctr.x, ctr.y, ctr.z]);
      return { bloom: 0.5, warm: 1.1, dof: dofTo([off.x, off.y, off.z], [ctr.x, ctr.y, ctr.z], 0.003, 0.008) };
    },
  };
}
// ============ S2: legend: the chariot leads an army through thick fog ============
function sFog({ makeStage }) {
  const scene = field(makeStage, { preset: 'fogc', sunDir: [0.3, 0.8, 0.4], fog: 0.06, seed: 2 });
  const C = chariot(); scene.add(C);
  const men = [...Array(9)].map((_, i) => { const s = soldier(i); scene.add(s.root); return s; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const z = -4 + t * 1.1; C.position.set(0, 0, z); C.rotation.y = 0; C.roll(z, z); C.point(SOUTH - 0.25);
      men.forEach((e, i) => { const r = Math.floor(i / 3), cc = i % 3; e.root.position.set((cc - 1) * 1.1, 0, z - 2.6 - r * 1.4); const w = Math.sin(t * 6 + i); standPose(e, t, { lHip: [w * 0.4, 0, 0.06], rHip: [-w * 0.4, 0, -0.06], lKn: [Math.max(0, -w) * 0.5, 0, 0], rKn: [Math.max(0, w) * 0.5, 0, 0], lSh: [-w * 0.3, 0, 0.12], rSh: [-0.3, 0, -0.2] }); e.setMood('happy'); e.setMouth(0); });
      const k = easeInOut(range(t, 0, 5.0));
      place(c, [lerp(3.5, 2.6, k), lerp(2.4, 2.0, k), z + lerp(4.5, 3.4, k)], [0, 1.3, z - 1.6]);
      return { bloom: 0.55, warm: 1.0 };
    },
  };
}
// ============ S3: the engineer Ma Jun with his chariot ============
function sMaJun({ makeStage }) {
  const scene = field(makeStage, { preset: 'golden', sunDir: [0.6, 0.35, 0.7], seed: 3, shadowSize: 4 });
  const wall = new THREE.Mesh(new THREE.BoxGeometry(14, 2.6, 0.4), new THREE.MeshStandardMaterial({ color: 0xa83a2a, roughness: 0.8 })); wall.position.set(0, 1.3, -4); wall.castShadow = wall.receiveShadow = true; scene.add(wall);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(14.6, 0.25, 1.2), new THREE.MeshStandardMaterial({ color: 0x2a3a3a, roughness: 0.6 })); roof.position.set(0, 2.7, -4); scene.add(roof);
  const C = chariot(); C.rotation.y = -0.6; C.position.set(0.55, 0, -1.2); C.roll(0, 0); C.point(1.2); scene.add(C);
  const M = scholar(); M.root.position.set(-0.45, 0, 0.5); M.root.rotation.y = 0.5; scene.add(M.root);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      standPose(M, t, { rSh: [-0.9, 0, -0.35], rEl: [-0.3, 0, 0], head: [0.05, 0.3, 0] }); M.setMood('happy'); M.setMouth(0); M.blink(blinkK(t, [1.2, 4.6]));
      const k = easeInOut(range(t, 0, 6.6));
      place(c, [lerp(-0.6, -0.2, k), lerp(1.8, 1.6, k), lerp(7.0, 5.8, k)], [0, 1.1, -0.3]);
      return { bloom: 0.55, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S4: top view of a turn: the outer wheel's track is longer than the inner one's ============
function sTrack({ makeStage, start: ST }) {
  const tO = at(4, 'outer') - ST;
  const scene = field(makeStage, { sunDir: [-0.3, 0.9, 0.3], seed: 4, shadowSize: 6 });
  const C = chariot(); scene.add(C);
  const R = route(9, s => (s > 1.5 && s < 7.5 ? 0.42 : 0), { x0: -2.5, z0: -3, yaw0: 0 });
  const tOut = trail(scene, 0xffd43b, 0.13), tIn = trail(scene, 0x6fd0ff, 0.13);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const S = t * 1.3; const p = drive(C, R, S); C.point(SOUTH);
      const o = [], n = [];
      for (let s = 0; s <= S; s += 0.1) { const q = R(s); o.push(wheelPos(q, -1)); n.push(wheelPos(q, 1)); }
      const show = t > tO - 1.0; tOut.set(show ? o : []); tIn.set(show ? n : []);
      place(c, [-0.3, lerp(11.5, 13, easeInOut(range(t, 0, 5))), 0.2], [-0.3, 0, -0.9]);
      return { bloom: 0.6, warm: 1.1 };
    },
  };
}
// ============ S5: inside: the two wheel gears turn at different speeds ============
function sCompare({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [-2, 5, 3], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x1a2230); u.mid.value.set(0x26303e); u.horizon.value.set(0x34404e); u.floorC.value.set(0x141a22);
  const C = chariot({ seeThrough: true }); C.body.visible = false; C.rail.visible = false; scene.add(C);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      C.roll(t * 1.6, t * 0.8); C.rotation.y = 0; C.point(SOUTH - t * 0.3);
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(0.5, 0.3, k), lerp(1.05, 0.95, k), lerp(1.9, 1.5, k)], [0, 0.72, 0]);
      return { bloom: 0.55, warm: 1.0 };
    },
  };
}
// ============ S6: the cart turns; the figure turns back by the same angle (arc overlays) ============
function sCancel({ makeStage, start: ST }) {
  const tD = at(6, 'other') - ST;
  const scene = field(makeStage, { sunDir: [-0.3, 0.9, 0.3], seed: 5, shadowSize: 4 });
  const C = chariot(); scene.add(C);
  const ar = southArrow(1.2); scene.add(ar);
  const arcC = new THREE.Mesh(new THREE.TorusGeometry(2.3, 0.05, 8, 64, 0.01), new THREE.MeshBasicMaterial({ color: 0xffd43b, toneMapped: false })); arcC.rotation.x = Math.PI / 2; arcC.position.y = 0.05; scene.add(arcC);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const yaw = lerp(0, 1.3, easeInOut(range(t, 0.4, 4.4))); C.rotation.y = yaw; C.roll(yaw * 1.2, -yaw * 1.2);
      C.point(SOUTH);
      ar.position.set(0, 2.25, 0); ar.rotation.y = SOUTH; ar.scale.setScalar(easeOut(range(t, tD - 0.3, tD + 0.3)) + 0.001);
      arcC.geometry.dispose(); arcC.geometry = new THREE.TorusGeometry(2.3, 0.05, 8, 64, Math.max(0.01, yaw)); arcC.rotation.set(Math.PI / 2, 0, -Math.PI / 2);
      place(c, [2.5, 7.5, 4.5], [0, 0.6, 0]);
      return { bloom: 0.6, warm: 1.1 };
    },
  };
}
// ============ S7: the cart spins a full loop; the figure never turns away ============
function sSpin({ makeStage }) {
  const scene = field(makeStage, { sunDir: [-0.5, 0.6, 0.6], seed: 6 });
  const C = chariot(); scene.add(C);
  const R = route(14, () => 0.62, { x0: 0, z0: 1.6, yaw0: Math.PI / 2 });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const p = drive(C, R, t * 2.4); C.point(SOUTH);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-5.5, -5, k), lerp(8.5, 7.8, k), lerp(9.5, 8.5, k)], [0, 0.5, 0]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S8: set it to south once ============
function sSet({ makeStage, start: ST }) {
  const tS = at(8, 'south') - ST, tO = at(8, 'once') - ST;
  const scene = field(makeStage, { sunDir: [-0.5, 0.6, 0.6], seed: 7, shadowSize: 3 });
  const C = chariot(); C.rotation.y = 0.4; C.roll(0, 0); scene.add(C);
  const ar = southArrow(1.0); ar.position.set(0, 0.04, 0); ar.rotation.y = SOUTH; scene.add(ar);
  const gl = glowSprite(0xffe08a, 0.8); scene.add(gl);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const a = lerp(SOUTH + 2.0, SOUTH, easeInOut(range(t, tS - 0.7, tS + 0.1))); C.point(a);
      scene.updateMatrixWorld(true); const fp = C.fig.getWorldPosition(V(0, 0, 0)); gl.position.set(fp.x, fp.y + 0.4, fp.z); gl.material.opacity = Math.sin(Math.PI * range(t, tO - 0.1, tO + 0.8)) * 0.9;
      ar.position.set(fp.x, fp.y + 0.37, fp.z); ar.scale.setScalar(0.5 * easeOut(range(t, 0.1, 0.6)) + 0.001);
      place(c, [fp.x + lerp(1.6, 1.3, easeInOut(range(t, 0, 3))), fp.y + 0.9, fp.z + lerp(2.4, 1.9, easeInOut(range(t, 0, 3)))], [fp.x, fp.y + 0.3, fp.z]);
      return { bloom: 0.6, warm: 1.15 };
    },
  };
}
// ============ S9: a modern car axle's differential ============
function sDiff({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [-2, 5, 3], sun: 2.4 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x1a2230); u.mid.value.set(0x26303e); u.horizon.value.set(0x34404e); u.floorC.value.set(0x141a22);
  const A = carAxle(); A.position.y = 0.5; scene.add(A);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      A.spin(t * 6, t * 4.5);
      const a = lerp(0.9, 0.4, easeInOut(range(t, 0, 6.8)));
      place(c, [Math.sin(a) * 1.7, lerp(1.1, 0.85, easeInOut(range(t, 0, 6.8))), Math.cos(a) * 1.7], [0, 0.5, 0]);
      return { bloom: 0.5, warm: 1.0 };
    },
  };
}
// ============ S10: bumps and slips: the figure slowly drifts off south ============
function sBumps({ makeStage, start: ST }) {
  const tT = at(10, 'threw') - ST;
  const scene = field(makeStage, { sunDir: [-0.5, 0.6, 0.6], seed: 8 });
  const C = chariot(); scene.add(C);
  const ar = southArrow(1.2); scene.add(ar);
  const R = route(14, s => 0.2 * Math.sin(s * 0.8), { z0: -4 });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const p = drive(C, R, t * 1.5);
      const b = Math.abs(Math.sin(t * 7)) * 0.06 + Math.abs(Math.sin(t * 11.3)) * 0.04;
      C.position.y = b; C.rotation.z = Math.sin(t * 9) * 0.04;
      const drift = lerp(0, 0.9, easeInOut(range(t, 0.5, tT + 0.6))); C.point(SOUTH + drift + Math.sin(t * 13) * 0.04);
      scene.updateMatrixWorld(true); const fp = C.fig.getWorldPosition(V(0, 0, 0));
      ar.position.set(fp.x, fp.y + 0.75, fp.z); ar.rotation.y = SOUTH; ar.scale.setScalar(0.6);
      place(c, [p.x + 3.4, 3.2, p.z + 4.2], [p.x, 1.2, p.z]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S11: Song dynasty record: a scroll with gear drawings ============
function sScroll({ makeStage }) {
  const scene = makeStage({ shadowSize: 1.2, sunDir: [-1, 3, 2], sun: 2.0 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a2016); u.mid.value.set(0x3a2a1c); u.horizon.value.set(0x4a3624); u.floorC.value.set(0x20160e);
  const table = new THREE.Mesh(new THREE.PlaneGeometry(5, 5), new THREE.MeshStandardMaterial({ color: 0x4a2a1a, roughness: 0.6, bumpMap: fabricTexture(5), bumpScale: 2 })); table.rotation.x = -Math.PI / 2; table.receiveShadow = true; scene.add(table);
  const S = gearScroll(); S.position.y = 0.01; scene.add(S);
  const brush = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.015, 0.4, 8), chMats().woodDark); brush.rotation.set(0, 0.5, Math.PI / 2); brush.position.set(0.5, 0.02, 0.62); scene.add(brush);
  const lamp = new THREE.PointLight(0xffb060, 2.5, 3, 2); lamp.position.set(0.7, 0.6, 0.5); scene.add(lamp);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.2));
      const pos = [lerp(0.5, 0.0, k), lerp(1.9, 1.5, k), lerp(1.2, 0.8, k)], look = [lerp(0.2, -0.1, k), 0, lerp(0.1, 0, k)];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.3, dof: dofTo(pos, look, 0.004, 0.01) };
    },
  };
}
// ============ S12: a modern model on a museum plinth ============
function sMuseum({ makeStage }) {
  const scene = makeStage({ shadowSize: 1.5, sunDir: [0.5, 4, 1.5], sun: 2.4 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x101418); u.mid.value.set(0x181e26); u.horizon.value.set(0x222a34); u.floorC.value.set(0x0c1014);
  const plinth = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.0, 1.0), new THREE.MeshStandardMaterial({ color: 0xa8a49c, roughness: 0.6 })); plinth.position.y = 0.5; plinth.castShadow = plinth.receiveShadow = true; scene.add(plinth);
  const C = chariot(); C.scale.setScalar(0.32); C.position.y = 1.0; C.roll(0, 0); scene.add(C);
  const spot = new THREE.SpotLight(0xfff0d8, 12, 6, 0.5, 0.5, 1.5); spot.position.set(0.5, 3.2, 1.2); spot.target.position.set(0, 1.1, 0); spot.castShadow = true; scene.add(spot, spot.target);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      C.rotation.y = t * 0.45; C.point(SOUTH); C.roll(t * 0.4, -t * 0.4);
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(0.4, 0.2, k), lerp(1.7, 1.6, k), lerp(3.1, 2.4, k)], [0, 1.15, 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
// ============ S13: sunset: the chariot rolls away down a winding road, the figure still pointing ============
function sEnd({ makeStage }) {
  const scene = field(makeStage, { preset: 'golden', sunDir: [0.75, 0.13, -0.6], fog: 0.004, seed: 9, shadowSize: 10 });
  const C = chariot(); scene.add(C);
  const R = route(14, s => 0.18 * Math.sin(s * 0.5 + 1), { z0: 0, yaw0: Math.PI });
  const b = birds(4, { from: [-20, 14, -40], to: [20, 16, -50], spread: 5, speed: 0.06, scale: 1.6, seed: 4 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const p = drive(C, R, 1 + t * 1.3); C.point(SOUTH);
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(2, 3, k), lerp(2.2, 3.4, k), lerp(4, 6, k)], [p.x, 1.0, p.z]);
      return { bloom: 0.7, flare: 1.0, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sGears], [ls(2), ls(3), sFog], [ls(3), ls(4), sMaJun], [ls(4), ls(5), sTrack],
  [ls(5), ls(6), sCompare], [ls(6), ls(7), sCancel], [ls(7), ls(8), sSpin], [ls(8), ls(9), sSet], [ls(9), ls(10), sDiff],
  [ls(10), ls(11), sBumps], [ls(11), ls(12), sScroll], [ls(12), ls(13), sMuseum], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
