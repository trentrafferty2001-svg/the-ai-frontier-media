// Roman concrete reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, STAND, wpos, stripStudio, blinkK } from './shots4.js';
import { splash2 } from './farm2.js';
import { mountains, trees, ringSpots, birds, mist, waterMaterial, TIME } from './world.js';
import { underwaterWorld } from './uw.js';
import { riceBasket } from './props60.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { concreteMaterial, romanBuilder, engineer, pantheon, pantheonInterior, aqueduct, formwork, quicklimeTrough, crackPath, ribbon, volcano, crystals, modernWall, archMats, shadowAll } from './rome.js';
import { VO } from './vo_rc.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const end = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][2];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you poured', 3], ['*concrete*', 1], ['today', 1], ['it would start', 3], ['*crumbling*', 1], ['within a *century*', 3]],
  [['But *Roman*', 2], ['*concrete*', 1], ['has stood for', 3], ['*2,000 years*', 3]],
  [["The *Pantheon's*", 2], ['dome', 1], ['is still', 2], ['the *biggest*', 2], ['concrete dome', 2], ['ever built', 2], ['without *steel*', 2]],
  [['For years', 2], ['scientists', 1], ['blamed', 1], ['the little', 2], ['*white lumps*', 2], ['inside it', 2], ['on *sloppy*', 2], ['*mixing*', 1]],
  [['But in *2023*', 5], ['researchers', 1], ['at *MIT*', 4], ['found they were', 3], ['the *secret*', 2]],
  [['Romans', 1], ['mixed in', 2], ['*quicklime*', 1], ['which gets', 2], ['*boiling hot*', 2], ['when it meets', 3], ['*water*', 1]],
  [['That *heat*', 2], ['left behind', 2], ['tiny *chunks*', 2], ['of *lime*', 2]],
  [['When a *crack*', 3], ['forms', 1], ['*rainwater*', 1], ['seeps in', 2], ['and *dissolves*', 2], ['the lime', 2]],
  [['It *hardens*', 2], ['again', 1], ['as *calcite*', 2], ['sealing', 1], ['the crack *shut*', 3]],
  [['The concrete', 2], ['*heals itself*', 2]],
  [['In *harbors*', 2], ['they added', 2], ['*volcanic ash*', 2]],
  [['*Seawater*', 1], ['soaking through', 2], ['grew new', 2], ['*crystals*', 1], ['inside the walls', 3]],
  [['So Roman', 2], ['*piers*', 1], ['got *stronger*', 2], ['over time', 2]],
  [['Now *engineers*', 2], ['are copying', 2], ['the *recipe*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

// ============ shared: Roman countryside ============
function romanLand(scene, { y = 0, seed = 1, cypress = true, hills = true, groundC = 0x8a8a4e } = {}) {
  const gm = new THREE.MeshStandardMaterial({ color: groundC, roughness: 1, bumpMap: fabricTexture(23 + seed), bumpScale: 4 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 64), gm); ground.rotation.x = -Math.PI / 2; ground.position.y = y; ground.receiveShadow = true; scene.add(ground);
  if (hills) scene.add(mountains({ rMin: 90, rMax: 320, height: 30, seed: 4 + seed, color: 0x6f7a46 }));
  scene.add(trees(ringSpots(30, 40, 110, 7 + seed, [0, 0, 0], 0, Math.PI * 2, y - 0.1), { seed: 5 + seed, scale: 1.5 }));
  if (cypress) {
    const cm = new THREE.MeshStandardMaterial({ color: 0x2f4a24, roughness: 0.9 });
    const spots = ringSpots(26, 12, 60, 21 + seed, [0, 0, 0], 0, Math.PI * 2, y);
    const g = new THREE.Group();
    spots.forEach(([x, yy, z], i) => { const h = 4 + (i % 4); const c = new THREE.Mesh(new THREE.ConeGeometry(0.55, h, 10), cm); c.scale.set(1, 1, 1); c.position.set(x, yy + h / 2, z); g.add(c); const tr = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.6, 6), new THREE.MeshStandardMaterial({ color: 0x4a3426 })); tr.position.set(x, yy + 0.3, z); g.add(tr); });
    shadowAll(g); scene.add(g);
  }
  return ground;
}
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ S0: modern concrete wall cracks and crumbles ============
function sModern({ makeStage, start: ST }) {
  const tCr = at(0, 'crumbling') - ST, tCon = at(0, 'concrete') - ST;
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.55, 0.65], fog: 0.004, shadowSize: 3, envI: 0.85, cloud: 0.62 });
  romanLand(scene, { cypress: false, groundC: 0x7c7f62, seed: 3 });
  const road = new THREE.Mesh(new THREE.PlaneGeometry(6, 60), new THREE.MeshStandardMaterial({ color: 0x3a3b3d, roughness: 0.9 })); road.rotation.x = -Math.PI / 2; road.position.set(0, 0.003, 0); scene.add(road);
  const w = modernWall({ W: 2.2, H: 1.9 }); w.position.set(0, 0, -0.6); scene.add(w);
  // a modern bridge pier + deck in the back
  const cm = concreteMaterial({ base: 0x8e8f8f, modern: true, scale: 0.6 });
  const deck = new THREE.Mesh(new THREE.BoxGeometry(40, 0.7, 3), cm); deck.position.set(0, 5.5, -9); scene.add(deck);
  for (const x of [-9, 0, 9]) { const p = new THREE.Mesh(new THREE.BoxGeometry(1, 5.5, 1.6), cm); p.position.set(x, 2.75, -9); scene.add(p); }
  shadowAll(scene);
  fillLight(scene, [0.6, 0.5, 1], 0.6);
  const dust = [...Array(18)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowSprite().material.map, color: 0xb9b4aa, transparent: true, opacity: 0, depthWrite: false })); scene.add(s); return { s, i }; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      w.update(range(t, tCon, tCr + 0.3), t - tCr);
      dust.forEach(({ s, i }) => { const a = t - tCr - 0.1 - i * 0.03; s.visible = a > 0; if (a <= 0) return; s.position.set(0.25 + Math.sin(i * 2.1) * 0.5 + a * 0.2, 0.9 - a * 0.4 + Math.cos(i) * 0.3, -0.3 + a * 0.5); s.scale.setScalar(0.25 + a * 0.6); s.material.opacity = 0.45 * Math.max(0, 1 - a / 1.4); });
      const k = easeInOut(range(t, 0, 4.4));
      const sh = shake(t, t > tCr ? 2.5 : 0.6, 1);
      const pos = [lerp(-2.0, -1.4, k) + sh[0], lerp(1.3, 1.1, k) + sh[1], lerp(7.2, 6.0, k)], look = [lerp(0.0, 0.2, k), 0.9, -0.4];
      place(c, pos, look);
      return { bloom: 0.25, sat: 0.95, warm: 0.6, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}

// ============ S1: Roman builder rams concrete into a formwork wall, aqueduct behind ============
function rammer() {
  const A = archMats(); const g = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.25, 10), A.wood); pole.position.y = 0.62; g.add(pole);
  const head = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.12, 14), A.wood); head.position.y = 0.0; g.add(head);
  return shadowAll(g);
}
function sBuild({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.55, 0.32, 0.77], fog: 0.0035, shadowSize: 3, envI: 0.95, cloud: 0.3 });
  romanLand(scene, { seed: 2 });
  const aq = aqueduct(12, { span: 2.4, h: 5 }); aq.position.set(-2, 0, 14); aq.rotation.y = -0.25; scene.add(aq);
  const fw = formwork(2.0, 0.55, 0.42); fw.position.set(0.1, 0, -0.1); scene.add(fw);
  const wallMat = concreteMaterial({ base: 0x9d968a, clasts: 0.35, scale: 1.0 });
  const fill = new THREE.Mesh(new THREE.BoxGeometry(1.98, 0.4, 0.42), wallMat); fill.position.set(0.1, 0.2, -0.1); fill.receiveShadow = true; scene.add(fill);
  // finished wall sections beside it
  const done = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.3, 0.42), wallMat); done.position.set(-2.1, 0.65, -0.1); scene.add(shadowAll(done));
  const man = romanBuilder(); man.root.position.set(0.25, 0, 0.38); man.root.rotation.y = Math.PI + 0.35; scene.add(man.root);
  const ram = rammer(); scene.add(ram);
  fillLight(scene, [0.4, 0.5, -1], 0.9, 0xffe0bc);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const cyc = 0.5 - 0.5 * Math.cos(t * Math.PI * 2 / 0.75);
      const ry = 0.42 + 0.06 + cyc * 0.28;
      standPose(man, t, { spine: [0.25, 0, 0], chest: [0.15, 0, 0], neck: [0.05, 0, 0], head: [0.35, 0, 0], lHip: [-0.25, 0, 0.1], rHip: [-0.25, 0, -0.1], lKn: [0.35, 0, 0], rKn: [0.35, 0, 0], drop: -0.05 });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.9, 2.6])); man.grip(0.9, 0.9);
      man.root.updateMatrixWorld(true);
      const base = wpos(man.root, V(0, 0, 0.42));
      ram.position.set(base.x, ry, base.z);
      ram.updateMatrixWorld(true);
      ikArm(man, 'l', V(base.x, ry + 0.75, base.z), wpos(man.root, V(0.6, 0.6, 0.2)), V(0, 1, 0));
      ikArm(man, 'r', V(base.x, ry + 0.55, base.z), wpos(man.root, V(-0.6, 0.4, 0.2)), V(0, 1, 0));
      const k = easeInOut(range(t, 0, 3.4));
      const pos = [lerp(1.9, 1.5, k), lerp(1.3, 1.5, k), lerp(-2.4, -2.9, k)], look = [lerp(0.25, 0.1, k), lerp(0.95, 1.05, k), 0.2];
      place(c, pos, look);
      return { bloom: 0.5, flare: 0.8, warm: 1.2, dof: dofTo(pos, [base.x, 0.9, base.z], 0.0025, 0.008) };
    },
  };
}

// ============ S2a: Pantheon at golden hour, rising orbit ============
function piazzaFolk(scene) {
  [[1.6, 4.4, 0.3, 0xd8c7a2], [-1.2, 5.2, 2.5, 0xa8402c], [2.5, 6.4, -2.2, 0x6f8f5a]].forEach(([x, z, ry, col], i) => {
    const p = romanBuilder({ color: col }); p.root.scale.setScalar(0.18); p.root.position.set(x, 0, z); p.root.rotation.y = ry; scene.add(p.root);
    standPose(p, 0.3 * i, {}); p.setMood('happy');
  });
}
function sPantheon({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.7, 0.26, 0.66], fog: 0.006, shadowSize: 6, envI: 0.95, cloud: 0.3 });
  romanLand(scene, { seed: 5, groundC: 0x9a8c6a });
  const p = pantheon(); scene.add(p);
  // surrounding Roman buildings
  const A = archMats();
  [[-6, -2, 3, 2.2], [6.5, -1, 3.5, 2.6], [-5.5, 6, 3, 1.8], [8.5, 3.5, 2.8, 2.0], [0, -7, 6, 2.4]].forEach(([x, z, w, h], i) => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, 2.6), A.stone); b.position.set(x, h / 2, z); scene.add(b);
    const r = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 1.6, 0.6, 4, 1), A.roofTile); r.rotation.y = Math.PI / 4; r.scale.set(w / 2.2, 1, 2.6 / 2.2); r.position.set(x, h + 0.3, z); scene.add(r);
  });
  piazzaFolk(scene);
  shadowAll(scene);
  fillLight(scene, [0.3, 0.4, 1], 0.7, 0xffe0bc);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 2.6));
      const a = lerp(0.55, 0.15, k);
      const r = lerp(11.5, 9.5, k);
      place(c, [Math.sin(a) * r, lerp(1.2, 4.5, k), Math.cos(a) * r], [0, lerp(2.4, 2.9, k), 0]);
      return { bloom: 0.6, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2b: inside the dome looking up at the oculus ============
function sDome({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.3, 0.9, 0.3], fog: 0.0, shadowSize: 3, envI: 0.5, cloud: 0.3, hemi: 0.25 });
  const g = pantheonInterior(); scene.add(g);
  const sun = new THREE.SpotLight(0xffe2b0, 60, 9, 0.2, 0.6, 1.2); sun.position.set(-0.5, 4.5, -0.1); sun.target.position.set(1.05, 0, 0.55); sun.castShadow = true; scene.add(sun, sun.target);
  scene.add(new THREE.AmbientLight(0xc9b49a, 0.25));
  const people = [[0.9, 0.7, 0.4], [-0.6, -0.4, 2.0]].map(([x, z, ry], i) => { const p = romanBuilder({ color: i ? 0x6f8f5a : 0xd8c7a2 }); p.root.scale.setScalar(0.32); p.root.position.set(x, 0, z); p.root.rotation.y = ry; scene.add(p.root); return p; });
  const c = cam(62);
  return {
    scene, camera: c,
    update(t) {
      people.forEach((p, i) => { standPose(p, t + i, { neck: [-0.4, 0, 0], head: [-0.4, 0, 0] }); p.setMood('happy'); });
      const k = easeInOut(range(t, 0, 2.9));
      place(c, [0.1, lerp(0.55, 0.75, k), lerp(1.6, 1.3, k)], [0, 4.34, lerp(-0.3, 0.0, k)], lerp(0, 0.35, k));
      return { bloom: 0.9, warm: 1.2, exposure: 1.1 };
    },
  };
}

// ============ S3/S4: macro of a broken Roman concrete chunk with white lime clasts; magnifier finds them ============
function macroStage(makeStage) {
  const scene = makeStage({ shadowSize: 0.5, sunDir: [-1.5, 3, 2], sun: 2.6 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x3a3530); u.mid.value.set(0x524a42); u.horizon.value.set(0x6a6056); u.floorC.value.set(0x2a2620);
  const table = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), new THREE.MeshStandardMaterial({ color: 0x4a3a2c, roughness: 0.7, bumpMap: fabricTexture(3), bumpScale: 2 })); table.rotation.x = -Math.PI / 2; table.receiveShadow = true; scene.add(table);
  return scene;
}
function chunk(glowU) {
  // rough chunk: displaced icosahedron, flat-ish broken top face
  const geo = new THREE.IcosahedronGeometry(0.22, 5);
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) { const v = V(p.getX(i), p.getY(i), p.getZ(i)); const n = 1 + 0.12 * Math.sin(v.x * 31 + v.z * 17) * Math.sin(v.y * 23) + 0.05 * Math.sin(v.x * 70 + v.y * 50); v.multiplyScalar(n); if (v.y > 0.05) v.y = 0.05 + (v.y - 0.05) * 0.15; p.setXYZ(i, v.x * 1.3, v.y, v.z); }
  geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, concreteMaterial({ base: 0x8a8378, clasts: 0.35, scale: 1.8, glow: glowU }));
  m.position.y = 0.12; m.castShadow = m.receiveShadow = true;
  return m;
}
function magnifier() {
  const g = new THREE.Group();
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.008, 12, 48), new THREE.MeshStandardMaterial({ color: 0x2a2a2e, metalness: 0.7, roughness: 0.3 })); g.add(rim);
  const lens = new THREE.Mesh(new THREE.CircleGeometry(0.09, 48), new THREE.MeshPhysicalMaterial({ color: 0xffffff, transmission: 1, roughness: 0, thickness: 0.02, transparent: true, opacity: 0.25 })); g.add(lens);
  const h = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.014, 0.16, 12), new THREE.MeshStandardMaterial({ color: 0x5a3a20, roughness: 0.6 })); h.position.y = -0.17; g.add(h);
  return shadowAll(g);
}
function sLumps({ makeStage, start: ST }) {
  const tL = at(3, 'white') - ST, tS = at(3, 'sloppy') - ST;
  const scene = macroStage(makeStage);
  const glowU = { value: 0 };
  const ch = chunk(glowU); scene.add(ch);
  // a few loose crumbs
  const cm = ch.material;
  for (let i = 0; i < 9; i++) { const b = new THREE.Mesh(new THREE.IcosahedronGeometry(0.012 + (i % 3) * 0.008, 1), cm); b.position.set(Math.sin(i * 2.3) * 0.38, 0.01, Math.cos(i * 1.7) * 0.3 + 0.1); b.castShadow = true; scene.add(b); }
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      glowU.value = 0.25 * Math.max(0, Math.sin(Math.PI * range(t, tL - 0.1, tL + 0.9)));
      const k = easeInOut(range(t, 0, 5.2));
      const pos = [lerp(-0.35, 0.15, k), lerp(0.42, 0.3, k), lerp(0.42, 0.36, k)], look = [lerp(-0.08, 0.06, k), 0.15, lerp(0.0, 0.02, k)];
      place(c, pos, look, Math.sin(t * 0.5) * 0.03);
      return { bloom: 0.35, warm: 1.1, dof: dofTo(pos, look, 0.012, 0.012) };
    },
  };
}
function sSecret({ makeStage, start: ST }) {
  const tS = at(4, 'secret') - ST, tMIT = at(4, 'm') - ST;
  const scene = macroStage(makeStage);
  const glowU = { value: 0 };
  const ch = chunk(glowU); scene.add(ch);
  const mag = magnifier(); scene.add(mag);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      glowU.value = easeOut(range(t, tS - 0.2, tS + 0.4)) * (0.8 + 0.2 * Math.sin(t * 9));
      const mx = kf(t, [[0, -0.35], [tMIT, -0.1], [tS - 0.3, 0.05], [5, 0.08]], easeInOut);
      mag.scale.setScalar(0.55); mag.position.set(mx, 0.2, 0.05 + Math.sin(t * 1.3) * 0.02); mag.rotation.set(-1.0, 0, 0.3);
      const k = easeInOut(range(t, 0, 4.9));
      const pos = [lerp(0.25, 0.1, k), lerp(0.62, 0.52, k), lerp(0.5, 0.4, k)], look = [lerp(-0.05, 0.05, k), 0.15, 0.02];
      place(c, pos, look);
      return { bloom: 0.5 + glowU.value * 0.5, warm: 1.15, dof: dofTo(pos, [mx, 0.2, 0.05], 0.008, 0.01) };
    },
  };
}

// ============ S5: builder pours water onto quicklime, it boils and steams ============
function workyard(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.55, 0.6, 0.55], fog: 0.004, shadowSize: 2.2, envI: 0.9, cloud: 0.35, ...opts });
  romanLand(scene, { seed: 7, groundC: 0x9a8a62 });
  const aq = aqueduct(10, { span: 2.4, h: 5 }); aq.position.set(4, 0, -18); aq.rotation.y = -0.4; scene.add(aq);
  fillLight(scene, [0.6, 0.4, 0.9], 0.6);
  return scene;
}
function bucketMesh() {
  const A = archMats(); const g = new THREE.Group();
  const b = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.09, 0.2, 20, 1, true), A.wood); b.material = A.wood.clone(); b.material.side = THREE.DoubleSide; g.add(b);
  const bot = new THREE.Mesh(new THREE.CircleGeometry(0.09, 20), A.wood); bot.rotation.x = Math.PI / 2; bot.position.y = -0.1; g.add(bot);
  for (const y of [-0.06, 0.06]) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.105 - y * 0.1, 0.006, 6, 24), new THREE.MeshStandardMaterial({ color: 0x3a3a3a, metalness: 0.6, roughness: 0.4 })); r.rotation.x = Math.PI / 2; r.position.y = y; g.add(r); }
  const w = new THREE.Mesh(new THREE.CircleGeometry(0.1, 20), new THREE.MeshStandardMaterial({ color: 0x6f8f9a, roughness: 0.1 })); w.rotation.x = -Math.PI / 2; w.position.y = 0.06; g.add(w); g.userData.water = w;
  return shadowAll(g);
}
function sQuicklime({ makeStage, start: ST }) {
  const tQ = at(5, 'quicklime') - ST, tB = at(5, 'boiling') - ST, tW = at(5, 'water') - ST;
  const scene = workyard(makeStage);
  const tr = quicklimeTrough(); tr.position.set(0, 0, 0); scene.add(tr);
  const man = romanBuilder(); man.root.position.set(-0.2, 0, -0.6); man.root.rotation.y = 0.65; scene.add(man.root);
  const bk = bucketMesh(); scene.add(bk);
  const streamMat = new THREE.MeshStandardMaterial({ color: 0xbfd8e0, roughness: 0.05, transparent: true, opacity: 0.8 });
  const stream = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.012, 1, 10, 1, true), streamMat); scene.add(stream);
  const sp = splash2(0.35, 3); scene.add(sp);
  const c = cam(36);
  const tPour = tQ + 0.2;
  return {
    scene, camera: c,
    update(t) {
      const tilt = easeInOut(range(t, tPour - 0.5, tPour)) * 1.6 - easeIn(range(t, tB + 1.6, tB + 2.2)) * 0.6;
      standPose(man, t, { spine: [0.25, 0, 0], chest: [0.1, 0, 0], neck: [-0.15, 0, 0], head: [-0.1, -0.35, 0] });
      man.setMood(t > tB ? 'happy' : 'happy'); man.setMouth(0); man.blink(blinkK(t, [0.6, 2.9])); man.grip(0.85, 0.85);
      man.root.updateMatrixWorld(true);
      const bp = wpos(man.root, V(0.0, 1.0, 0.52));
      bk.position.copy(bp); bk.rotation.set(tilt, 0, 0);
      bk.updateMatrixWorld(true);
      ikArm(man, 'l', wpos(bk, V(0.11, 0.0, 0)), wpos(man.root, V(0.8, 0.4, 0)), V(0, 0, 1));
      ikArm(man, 'r', wpos(bk, V(-0.11, -0.05, 0)), wpos(man.root, V(-0.8, 0.4, 0)), V(0, 0, 1));
      const lip = wpos(bk, V(0, 0.1, 0.1));
      const pouring = t > tPour && t < tB + 1.9;
      stream.visible = pouring; sp.visible = pouring;
      if (pouring) { const yb = 0.08; stream.position.set(lip.x, (lip.y + yb) / 2, lip.z + 0.02); stream.scale.y = Math.max(0.01, lip.y - yb); sp.position.set(lip.x, yb, lip.z + 0.02); sp.update(((t - tPour) % 0.6)); }
      bk.userData.water.visible = tilt < 1.2;
      const level = easeOut(range(t, tPour, tB + 0.8));
      const heat = easeOut(range(t, tB - 0.4, tB + 0.3)) * (0.85 + 0.15 * Math.sin(t * 13));
      tr.set(level, heat, t);
      const k = easeInOut(range(t, 0, 4.3));
      const pos = [lerp(2.4, 2.1, k), lerp(1.25, 1.2, k), lerp(2.1, 1.8, k)], look = [lerp(0.0, 0.0, k), lerp(0.85, 0.8, k), lerp(-0.3, -0.25, k)];
      place(c, pos, look);
      return { bloom: 0.5 + heat * 0.4, warm: 1.0 + heat * 0.2, dof: dofTo(pos, look, 0.003, 0.009) };
    },
  };
}

// ============ S6: fresh concrete face, tiny lime chunks left behind, last wisps of heat ============
function sChunks({ makeStage, start: ST }) {
  const tCh = at(6, 'chunks') - ST;
  const scene = workyard(makeStage, { sunDir: [-0.4, 0.5, 0.75] });
  const glowU = { value: 0 };
  const mat = concreteMaterial({ base: 0x8a8378, clasts: 0.3, scale: 1.4, glow: glowU });
  const wall = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.8, 0.5), mat); wall.position.set(0, 0.4, 0); scene.add(shadowAll(wall));
  const fw = formwork(1.7, 0.6, 0.52); fw.position.set(0, 0, 0); fw.children.forEach(m => { if (m.position.z > 0) m.visible = false; }); scene.add(fw);
  const tex = glowSprite().material.map;
  const steam = [...Array(10)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color: 0xf2f2ee, transparent: true, opacity: 0, depthWrite: false })); scene.add(s); return { s, i }; });
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      glowU.value = 0.45 * Math.sin(Math.PI * range(t, tCh - 0.15, tCh + 1.2));
      steam.forEach(({ s, i }) => { const a = ((t * 0.3 + i / 10) % 1); s.position.set(-0.6 + i * 0.13, 0.82 + a * 0.4, 0.1); s.scale.setScalar(0.12 + a * 0.25); s.material.opacity = 0.3 * Math.sin(Math.PI * a) * (1 - range(t, 0, 2.6) * 0.7); });
      const k = easeInOut(range(t, 0, 2.8));
      const pos = [lerp(1.2, 0.6, k), lerp(1.0, 0.75, k), lerp(3.0, 2.0, k)], look = [lerp(0.05, 0.0, k), 0.42, 0.25];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.1, dof: dofTo(pos, look, 0.006, 0.01) };
    },
  };
}

// ============ S7/S8: cut-away wall: crack, rain seeps in, clast dissolves; calcite seals it ============
function crackScene(makeStage, rain) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.4, 0.6, 0.7], fog: 0.005, shadowSize: 1.4, envI: 0.75, cloud: rain ? 0.85 : 0.35 });
  romanLand(scene, { seed: 9 });
  fillLight(scene, [0.4, 0.5, 1], 0.7);
  const mat = concreteMaterial({ base: 0x8a8378, clasts: 0.12, scale: 1.2 });
  const wall = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.0, 0.45), mat); wall.position.set(0, 0.5, -0.225); scene.add(shadowAll(wall));
  // the clast the crack runs into
  const clast = new THREE.Mesh(new THREE.SphereGeometry(0.045, 24, 16), new THREE.MeshStandardMaterial({ color: 0xf4f2ea, roughness: 0.9 })); clast.scale.set(1.3, 1, 0.3); clast.position.set(0.06, 0.42, 0.003); scene.add(clast);
  const pts = crackPath(7, { top: 1.0, bottom: 0.44, x0: 0.02, wander: 0.05, steps: 22 });
  pts[pts.length - 1][0] = 0.05;
  const crack = ribbon(pts, 0.016, new THREE.MeshBasicMaterial({ color: 0x141210 }), 0.002); scene.add(crack);
  const water = ribbon(pts, 0.011, new THREE.MeshStandardMaterial({ color: 0x3f8fd0, roughness: 0.05, emissive: 0x0c3a66, emissiveIntensity: 0.6 }), 0.003); scene.add(water);
  const calcite = ribbon(pts, 0.019, new THREE.MeshStandardMaterial({ color: 0xf6f4ee, roughness: 0.4, emissive: 0x6a6a64, emissiveIntensity: 0.25 }), 0.004); scene.add(calcite);
  // rain
  const N = 260; const drops = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.0015, 0.0015, 0.06, 4), new THREE.MeshBasicMaterial({ color: 0xcfe2f2, transparent: true, opacity: 0.6 }), N); scene.add(drops);
  const D = [...Array(N)].map((_, i) => [Math.sin(i * 12.9898) * 1.4, Math.cos(i * 78.233) * 0.8 + 0.3, (i * 0.618) % 1]);
  const m4 = new THREE.Matrix4();
  scene.userData.rain = (t, on) => { drops.visible = on; if (!on) return; D.forEach(([x, z, ph], i) => { const y = 2.0 - ((t * 2.2 + ph) % 1) * 2.2; m4.makeTranslation(x, y, z); drops.setMatrixAt(i, m4); }); drops.instanceMatrix.needsUpdate = true; };
  return { scene, crack, water, calcite, clast, wall };
}
function sCrack({ makeStage, start: ST }) {
  const tC = at(7, 'crack') - ST, tR = at(7, 'rainwater') - ST, tD = at(7, 'dissolves') - ST;
  const S = crackScene(makeStage, true);
  const c = cam(34);
  return {
    scene: S.scene, camera: c,
    update(t) {
      S.crack.reveal(easeOut(range(t, tC - 0.1, tC + 0.6)));
      S.water.reveal(easeIn(range(t, tR, tD + 0.2)));
      S.calcite.reveal(0);
      S.clast.scale.set(1.3, 1, 0.3).multiplyScalar(lerp(1, 0.45, easeInOut(range(t, tD, tD + 1.1))));
      S.scene.userData.rain(t, t > tR - 0.6);
      const k = easeInOut(range(t, 0, 3.9));
      const sh = t < tC + 0.3 && t > tC - 0.1 ? shake(t * 4, 3, 2) : [0, 0, 0];
      const pos = [lerp(0.8, 0.35, k) + sh[0], lerp(1.05, 0.85, k) + sh[1], lerp(3.2, 2.0, k)], look = [0.04, lerp(0.6, 0.7, k), 0];
      place(c, pos, look);
      return { bloom: 0.35, warm: 0.7, sat: 1.05, dof: dofTo(pos, look, 0.004, 0.009) };
    },
  };
}
function sHeal({ makeStage, start: ST }) {
  const tH = at(8, 'hardens') - ST, tS = at(8, 'shut') - ST;
  const S = crackScene(makeStage, false);
  const c = cam(34);
  return {
    scene: S.scene, camera: c,
    update(t) {
      S.crack.reveal(1);
      S.water.reveal(1 - easeInOut(range(t, tH, tS)));
      // calcite grows from the clast (bottom) upward: reveal from the bottom by flipping the draw order is not possible, so fade in along the whole length
      S.calcite.reveal(easeInOut(range(t, tH - 0.1, tS + 0.1)));
      S.calcite.material.emissiveIntensity = 0.25 + 0.5 * Math.sin(Math.PI * range(t, tS - 0.2, tS + 0.8));
      S.clast.scale.set(1.3, 1, 0.3).multiplyScalar(0.45);
      S.scene.userData.rain(t, false);
      const k = easeInOut(range(t, 0, 3.4));
      const pos = [lerp(0.35, 0.25, k), lerp(0.85, 0.8, k), lerp(2.0, 1.6, k)], look = [0.04, lerp(0.7, 0.7, k), 0];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.0, dof: dofTo(pos, look, 0.005, 0.009) };
    },
  };
}
// ============ S9: pull back: the wall stands whole in the sun, builder pats it ============
function sWhole({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.5, 0.3, -0.81], fog: 0.0035, shadowSize: 3, envI: 0.95, cloud: 0.3 });
  romanLand(scene, { seed: 2 });
  const aq = aqueduct(12, { span: 2.4, h: 5 }); aq.position.set(-2, 0, -14); aq.rotation.y = 0.25; scene.add(aq);
  const mat = concreteMaterial({ base: 0x8f887c, clasts: 0.15, scale: 1.0 });
  const wall = new THREE.Mesh(new THREE.BoxGeometry(4.2, 1.3, 0.42), mat); wall.position.set(-0.6, 0.65, -0.1); scene.add(shadowAll(wall));
  const man = romanBuilder(); man.root.position.set(0.55, 0, 0.42); man.root.rotation.y = -0.6; scene.add(man.root);
  fillLight(scene, [-0.4, 0.5, 1], 0.9, 0xffe0bc);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const pat = Math.max(0, Math.sin(t * 7)) * range(t, 0.3, 0.6);
      standPose(man, t, { lSh: [-1.3 - pat * 0.15, 0, 0.5], lEl: [-0.5, 0, 0], rSh: [0.05, 0, -0.2], head: [0, 0.6, 0], neck: [0, 0.2, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [1.2])); man.grip(0.1, 0.4);
      const k = easeOut(range(t, 0, 1.9));
      const pos = [lerp(0.9, 2.4, k), lerp(1.2, 1.7, k), lerp(1.6, 3.6, k)], look = [lerp(0.2, -0.3, k), lerp(1.0, 0.9, k), -0.2];
      place(c, pos, look);
      return { bloom: 0.55, flare: 0.9, warm: 1.25 };
    },
  };
}

// ============ S10: harbour — builder tips volcanic ash into a pier form, Vesuvius smoking behind ============
function seaStage(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.25, -0.76], fog: 0.0028, shadowSize: 3, envI: 0.95, cloud: 0.3, ...opts });
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(800, 800), waterMaterial({ color: 0x1d4a66, opacity: 1, ripple: 1.4 })); sea.rotation.x = -Math.PI / 2; sea.position.y = 0; scene.add(sea);
  const v = volcano({ r: 48, h: 34 }); v.position.set(-70, -1, -210); scene.add(v); scene.userData.updaters.push((t) => v.update(t));
  scene.add(mountains({ rMin: 160, rMax: 340, height: 20, seed: 12, color: 0x6a7a4c, thetaFrom: Math.PI * 0.6, thetaTo: Math.PI * 1.4 }));
  const b = birds(4, { from: [-30, 9, -40], to: [30, 12, -50], spread: 6, speed: 0.05, scale: 1.6, seed: 3 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  return scene;
}
function sAsh({ makeStage, start: ST }) {
  const tA = at(10, 'volcanic') - ST;
  const scene = seaStage(makeStage);
  const mat = concreteMaterial({ base: 0x8e877c, clasts: 0.3, scale: 1.2 });
  const pier = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 12), mat); pier.position.set(0, 0.3, -5); scene.add(shadowAll(pier));
  const fw = formwork(1.2, 0.45, 1.0); fw.rotation.y = Math.PI / 2; fw.position.set(0, 0.9, 0.6); scene.add(fw);
  const ashBed = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.3, 1.18), new THREE.MeshStandardMaterial({ color: 0x4e4a46, roughness: 1, bumpMap: fabricTexture(44), bumpScale: 4 })); ashBed.position.set(0, 1.05, 0.6); scene.add(ashBed);
  const man = romanBuilder({ color: 0xc9b48a }); man.root.position.set(0.85, 0.9, 0.55); man.root.rotation.y = -Math.PI / 2; scene.add(man.root);
  const bas = riceBasket(); bas.scale.setScalar(0.9); scene.add(bas);
  const tex = glowSprite().material.map;
  const ash = [...Array(40)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color: 0x5a5550, transparent: true, opacity: 0, depthWrite: false })); scene.add(s); return { s, i }; });
  fillLight(scene, [0.4, 0.5, 1], 0.8, 0xffe0bc);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const tip = easeInOut(range(t, tA - 0.8, tA - 0.1));
      standPose(man, t, { spine: [0.2, 0, 0], chest: [0.1, 0, 0], head: [0.3, 0, 0] });
      man.setMood('happy'); man.setMouth(0); man.blink(blinkK(t, [0.5, 2.1])); man.grip(0.85, 0.85);
      man.root.updateMatrixWorld(true);
      const bp = wpos(man.root, V(0, 1.05, 0.45));
      bas.position.copy(bp); bas.rotation.set(0, 0, 0); bas.rotateOnWorldAxis(V(0, 0, 1), tip * 1.5);
      bas.updateMatrixWorld(true);
      ikArm(man, 'l', wpos(bas, V(0, 0.08, -0.14)), wpos(man.root, V(0.8, 0.3, 0)), V(0, 1, 0));
      ikArm(man, 'r', wpos(bas, V(0, 0.08, 0.14)), wpos(man.root, V(-0.8, 0.3, 0)), V(0, 1, 0));
      ashBed.scale.y = 0.2 + 0.8 * easeOut(range(t, tA - 0.2, tA + 1.4)); ashBed.position.y = 0.9 + 0.15 * ashBed.scale.y;
      ash.forEach(({ s, i }) => { const a = ((t - tA + 0.3) * 1.3 + i / 40) % 1; const on = t > tA - 0.3 && t < tA + 2.0; s.visible = on; if (!on) return; s.position.set(bp.x - 0.25 - a * 0.1 + Math.sin(i * 3) * 0.05, bp.y - a * 0.75, bp.z + Math.cos(i * 2) * 0.12); s.scale.setScalar(0.06 + a * 0.18); s.material.opacity = 0.6 * Math.sin(Math.PI * a); });
      const k = easeInOut(range(t, 0, 2.7));
      const pos = [lerp(-2.6, -2.1, k), lerp(1.9, 1.75, k), lerp(3.4, 2.9, k)], look = [lerp(0.3, 0.4, k), 1.35, lerp(0.3, 0.5, k)];
      place(c, pos, look);
      return { bloom: 0.55, flare: 0.8, warm: 1.2, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}

// ============ S11: underwater, seawater soaks into the pier and plate crystals grow ============
function sCrystals({ makeStage, start: ST }) {
  const tCr = at(11, 'crystals') - ST, tSoak = at(11, 'soaking') - ST;
  const scene = makeStage({ shadowSize: 1 }); stripStudio(scene);
  underwaterWorld(scene, { surf: 1.1, density: 1.0, leaves: 0.0, size: 8, fogColor: 0x1d5f7a, particles: 900 });
  const mat = concreteMaterial({ base: 0x7d786e, clasts: 0.25, scale: 2.2 });
  const wall = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.3, 0.6), mat); wall.position.set(0, 0.6, -0.5); scene.add(shadowAll(wall));
  // inset window into the wall: darker recess where the crystals grow
  const recess = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.5), new THREE.MeshStandardMaterial({ color: 0x3c3a36, roughness: 1 })); recess.position.set(0.1, 0.62, -0.199); scene.add(recess);
  const frame = new THREE.Mesh(new THREE.TorusGeometry(0.43, 0.012, 6, 4), new THREE.MeshStandardMaterial({ color: 0xffd43b, emissive: 0x806a1e, emissiveIntensity: 0.6 })); frame.rotation.z = Math.PI / 4; frame.scale.set(1.15, 0.82, 1); frame.position.set(0.1, 0.62, -0.19); scene.add(frame);
  const cr = crystals(160, { w: 0.62, h: 0.42, seed: 6 }); cr.position.set(0.1, 0.62, -0.19); scene.add(cr);
  // seawater "soaking in": blue sprites drifting into the recess
  const tex = glowSprite().material.map;
  const flow = [...Array(30)].map((_, i) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, color: 0x7fd0ff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending })); scene.add(s); return { s, i }; });
  const tiny = [...Array(5)].map((_, i) => { const f = new THREE.Mesh(new THREE.ConeGeometry(0.012, 0.05, 6), new THREE.MeshStandardMaterial({ color: 0xc0d8e0, metalness: 0.5, roughness: 0.3 })); f.rotation.z = -Math.PI / 2; scene.add(f); return f; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      cr.grow(easeOut(range(t, tCr - 0.6, tCr + 1.4)));
      frame.visible = t > tCr - 0.3; frame.scale.set(1.15, 0.82, 1).multiplyScalar(lerp(0.9, 1, easeOut(range(t, tCr - 0.3, tCr))));
      flow.forEach(({ s, i }) => { const a = ((t * 0.5 + i / 30) % 1); const on = t > tSoak - 0.4; s.visible = on; if (!on) return; s.position.set(0.1 + Math.sin(i * 2.7) * 0.5 * (1 - a), 0.62 + Math.cos(i * 1.9) * 0.35 * (1 - a), 0.4 - a * 0.6); s.scale.setScalar(0.03 + 0.02 * Math.sin(i)); s.material.opacity = 0.5 * Math.sin(Math.PI * a); });
      tiny.forEach((f, i) => { f.position.set(-1.2 + ((t * 0.12 + i * 0.21) % 1) * 2.6, 0.35 + i * 0.12, 0.3 + i * 0.05); });
      const k = easeInOut(range(t, 0, 3.6));
      const pos = [lerp(-0.5, -0.05, k), lerp(0.7, 0.66, k), lerp(1.6, 0.85, k)], look = [lerp(0.0, 0.1, k), 0.62, -0.2];
      place(c, pos, look);
      return { bloom: 0.7, warm: 0.4, sat: 1.15, dof: dofTo(pos, look, 0.004, 0.01) };
    },
  };
}

// ============ S12: waves crash on the Roman pier; it stands ============
function sWaves({ makeStage, start: ST }) {
  const tS = at(12, 'stronger') - ST;
  const scene = seaStage(makeStage, { sunDir: [0.65, 0.2, -0.73] });
  const mat = concreteMaterial({ base: 0x8a8378, clasts: 0.3, scale: 1.0 });
  const pier = new THREE.Mesh(new THREE.BoxGeometry(2.2, 2.0, 18), mat); pier.position.set(0, 0.2, -6); scene.add(shadowAll(pier));
  const lh = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.7, 2.4, 16), archMats().stone); lh.position.set(0, 2.4, 2.4); scene.add(shadowAll(lh));
  const fire = glowSprite(0xffb050, 1.2); fire.position.set(0, 3.8, 2.4); scene.add(fire);
  const spl = [0, 1, 2].map(i => { const s = splash2(5.0, 7 + i); scene.add(s); return s; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      spl.forEach((s, i) => { const t0 = 0.3 + i * 0.85; s.position.set(1.15, 0.02, 1.4 - i * 1.8); s.update(((t - t0) % 2.4 + 2.4) % 2.4); });
      const k = easeInOut(range(t, 0, 2.7));
      const pos = [lerp(7.5, 6.2, k), lerp(2.2, 2.8, k), lerp(9.5, 8.0, k)], look = [0, lerp(1.5, 1.9, k), lerp(-1.5, -2.0, k)];
      place(c, pos, look);
      return { bloom: 0.6, flare: 0.9, warm: 1.3 };
    },
  };
}

// ============ S13: a modern engineer holds up a concrete core at a harbour site ============
function sEngineer({ makeStage, start: ST }) {
  const tR = at(13, 'recipe') - ST;
  const scene = seaStage(makeStage, { sunDir: [0.55, 0.12, -0.83] });
  const mat = concreteMaterial({ base: 0x9a948a, clasts: 0.3, scale: 1.0 });
  const quay = new THREE.Mesh(new THREE.BoxGeometry(16, 1.0, 6), mat); quay.position.set(0, 0.3, 1.5); scene.add(shadowAll(quay));
  // crane silhouette
  const steel = new THREE.MeshStandardMaterial({ color: 0xe0a020, roughness: 0.5, metalness: 0.4 });
  const mast = new THREE.Mesh(new THREE.BoxGeometry(0.4, 12, 0.4), steel); mast.position.set(6, 6.8, -4); scene.add(mast);
  const jib = new THREE.Mesh(new THREE.BoxGeometry(12, 0.35, 0.35), steel); jib.position.set(3, 12.6, -4); scene.add(jib);
  const man = engineer(); man.root.position.set(0, 0.8, 0.6); man.root.rotation.y = 0.2; scene.add(man.root);
  const core = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.2, 24), concreteMaterial({ base: 0x9b9488, clasts: 0.6, scale: 4 })); core.castShadow = true; scene.add(core);
  fillLight(scene, [-0.3, 0.4, 1], 1.0, 0xffe0bc);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const up = easeOut(range(t, 0.1, 0.7));
      standPose(man, t, { rSh: [lerp(0.05, -1.9, up), 0, lerp(-0.16, -0.35, up)], rEl: [lerp(-0.25, -0.6, up), 0, 0], lSh: [0.05, 0, 0.2], head: [-0.05, -0.2, 0] });
      man.setMood('happy'); man.setMouth(0.0); man.blink(blinkK(t, [1.4, 2.9])); man.grip(0.25, 0.95);
      scene.updateMatrixWorld(true);
      const rh = wpos(man.j.rWr, V(0, -0.07, 0.02));
      core.position.copy(rh); core.rotation.set(0.2, 0, 0.1 + Math.sin(t * 2) * 0.05);
      const k = easeInOut(range(t, 0, 3.6));
      const pos = [lerp(0.2, 0.5, k), lerp(2.15, 2.25, k), lerp(3.4, 4.0, k)], look = [lerp(-0.15, -0.1, k), lerp(2.15, 2.15, k), 0.5];
      place(c, pos, look);
      return { bloom: 0.6, flare: 1.0, warm: 1.3, dof: dofTo(pos, [rh.x, rh.y, rh.z], 0.0025, 0.008) };
    },
  };
}

// ============ timeline ============
const cutB = at(2, 'biggest') - 0.06;
const S = [
  [0, ls(1), sModern, 'modern'],
  [ls(1), ls(2), sBuild, 'build'],
  [ls(2), cutB, sPantheon, 'pantheon'],
  [cutB, ls(3), sDome, 'dome'],
  [ls(3), ls(4), sLumps, 'lumps'],
  [ls(4), ls(5), sSecret, 'secret'],
  [ls(5), ls(6), sQuicklime, 'quicklime'],
  [ls(6), ls(7), sChunks, 'chunks'],
  [ls(7), ls(8), sCrack, 'crack'],
  [ls(8), ls(9), sHeal, 'heal'],
  [ls(9), ls(10), sWhole, 'whole'],
  [ls(10), ls(11), sAsh, 'ash'],
  [ls(11), ls(12), sCrystals, 'crystals'],
  [ls(12), ls(13), sWaves, 'waves'],
  [ls(13), DURATION + 1, sEngineer, 'engineer'],
];
// cut slightly before each sentence so the picture leads the voice
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
