// Stepwell reel (Chand Baori style): square inverted pyramid of 13 terraces, zigzag stair flights on three sides,
// a pavilion of galleries on the fourth (back, -z) side, water at the bottom that can rise/fall, cut-away option.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex, romanBuilder } from './rome.js';
import { waterMaterial } from './world.js';

export const LEVELS = 13, TOP = 13, BOT = 2.6, DEPTH = 26;
export const lvY = (i) => -i * DEPTH / LEVELS;               // terrace height of level i (0 = ground)
export const lvW = (i) => TOP + (BOT - TOP) * i / LEVELS;     // inner half width at level i
export const wAt = (y) => lvW(Math.min(LEVELS, Math.max(0, -y / DEPTH * LEVELS)));

let SM = null;
export function swMats() {
  if (SM) return SM;
  const st = canvasTex(256, 256, (x) => {
    x.fillStyle = '#b9926a'; x.fillRect(0, 0, 256, 256); const R = rng(11);
    for (let i = 0; i < 500; i++) { x.fillStyle = `rgba(${110 + R() * 70},${80 + R() * 40},${50 + R() * 30},${R() * 0.18})`; x.fillRect(R() * 256, R() * 256, 2 + R() * 7, 2 + R() * 7); }
    x.strokeStyle = 'rgba(80,55,30,0.45)'; x.lineWidth = 2; for (let r = 0; r < 8; r++) { x.beginPath(); x.moveTo(0, r * 32); x.lineTo(256, r * 32); x.stroke(); }
  }, [3, 3]);
  const dirt = new THREE.MeshStandardMaterial({ color: 0x8a6a46, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 });
  SM = {
    stone: new THREE.MeshStandardMaterial({ map: st, roughness: 0.9, bumpMap: st, bumpScale: 2 }),
    step: new THREE.MeshStandardMaterial({ color: 0xc8a478, roughness: 0.85 }),
    dirt,
    ground: new THREE.MeshStandardMaterial({ color: 0xc89a62, roughness: 1, bumpMap: fabricTexture(31), bumpScale: 3 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x2a1c12, roughness: 1 }),
    wet: new THREE.MeshBasicMaterial({ color: 0x3a8ac8, transparent: true, opacity: 0.4, depthWrite: false }),
  };
  return SM;
}

// stair flight geometry list for level i on one side: Λ pairs along the side
function flights(i, cut) {
  const geos = []; const w0 = lvW(i), w1 = lvW(i + 1), y0 = lvY(i), y1 = lvY(i + 1);
  const n = 8, rise = (y0 - y1) / n, run = 0.34, depth = (w0 - w1) * 0.9;
  const sides = [[0, 1], [1, 0], [-1, 0]]; // front (+z), right (+x), left (-x)
  for (const [sx, sz] of sides) {
    const L = w1 - 0.5; // usable half length along the side
    for (let c = -L + 1.5; c < L - 2.5; c += 5.2) {
      for (const dir of [1, -1]) for (let k = 0; k < n; k++) {
        const a = dir > 0 ? c + k * run : c + (2 * n - 1 - k) * run;
        const g = new THREE.BoxGeometry(sz ? run + 0.02 : depth, rise * (n - k), sz ? depth : run + 0.02);
        const h = rise * (n - k);
        const px = sz ? a : sx * (w1 + depth / 2), pz = sz ? sz * (w1 + depth / 2) : a;
        if (cut && px > 0.01) continue;
        g.translate(px, y1 + h / 2, pz); geos.push(g);
      }
    }
  }
  return geos;
}
export function stepwell(scene, { cut = false, pavilion = true } = {}) {
  const M = swMats(); const g = new THREE.Group(); scene.add(g);
  const XM = cut ? 0 : 60;
  const ring = (i, mat) => { // solid square ring from far below up to terrace i, inner half width lvW(i), outer half width O
    const w = lvW(i), O = i === 0 ? 60 : lvW(i - 1) + 0.001, yT = lvY(i), yB = -DEPTH - 3; const ms = [];
    const box = (x0, x1, z0, z1) => { x1 = Math.min(x1, XM); if (x1 <= x0) return; const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, yT - yB, z1 - z0), mat); m.position.set((x0 + x1) / 2, (yT + yB) / 2, (z0 + z1) / 2); m.castShadow = m.receiveShadow = true; g.add(m); ms.push(m); };
    box(-O, O, w, O); box(-O, O, -O, -w); box(-O, -w, -w, w); box(w, O, -w, w);
    return ms;
  };
  const rings = [...Array(LEVELS + 1)].map((_, i) => ring(i, i === 0 ? M.ground : M.stone));
  // pit floor
  const floor = new THREE.Mesh(new THREE.BoxGeometry(2 * BOT, 0.4, 2 * BOT), M.stone); floor.position.y = -DEPTH - 0.2; g.add(floor);
  // stairs, one merged mesh per level
  const stairs = [];
  for (let i = 0; i < LEVELS; i++) { const geos = flights(i, cut); if (!geos.length) { stairs.push(new THREE.Group()); continue; } const m = new THREE.Mesh(mergeGeometries(geos), M.step); m.castShadow = m.receiveShadow = true; g.add(m); stairs.push(m); }
  // pavilion on the back side: stacked galleries with dark arches
  const pav = new THREE.Group(); g.add(pav);
  if (pavilion) {
    const floors = 7;
    for (let f = 0; f < floors; f++) {
      const y = -f * 3.0, zb = -wAt(y - 3) + 0.2, w = 8 - f * 0.4;
      const slab = new THREE.Mesh(new THREE.BoxGeometry(2 * w, 0.4, 2.4), M.stone); slab.position.set(0, y - 0.2, zb + 1.2); pav.add(slab);
      for (let c = 0; c <= 6; c++) { const x = -w + 0.3 + c * (2 * w - 0.6) / 6; if (cut && x > 0) continue; const col = new THREE.Mesh(new THREE.BoxGeometry(0.35, 2.6, 0.35), M.stone); col.position.set(x, y - 1.7, zb + 2.2); pav.add(col); }
      const back = new THREE.Mesh(new THREE.BoxGeometry(2 * w, 2.6, 0.3), M.dark); back.position.set(0, y - 1.7, zb + 0.15); pav.add(back);
    }
    shadowAll(pav);
  }
  // water: rippling top + a box in the cut view; wet ground overlay on the cut face
  const wTop = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), waterMaterial({ color: 0x2f6a5a, opacity: 0.95, ripple: 0.8 })); wTop.rotation.x = -Math.PI / 2; g.add(wTop);
  const wBox = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: 0x2f6a78, transparent: true, opacity: 0.75, roughness: 0.2 })); g.add(wBox);
  const wet = new THREE.Mesh(new THREE.PlaneGeometry(120, 1), M.wet); wet.rotation.y = Math.PI / 2; wet.position.x = 0.03; wet.visible = cut; g.add(wet);
  g.setWater = (y) => {
    const w = wAt(y) + 0.3;
    wTop.scale.set(cut ? w : 2 * w, 2 * w, 1); wTop.position.set(cut ? -w / 2 : 0, y, 0);
    wBox.visible = cut; wBox.scale.set(w, y + DEPTH, 2 * w); wBox.position.set(-w / 2, (y - DEPTH) / 2, 0);
    wet.scale.y = y + DEPTH + 3; wet.position.y = (y - DEPTH - 3) / 2;
  };
  // building progress: k 0..1, levels deeper than k*LEVELS show dirt instead of stone, stairs hidden
  g.setLining = (k) => rings.forEach((ms, i) => { if (i) ms.forEach(m => m.material = i <= k * LEVELS ? M.stone : M.dirt); });
  g.setStairs = (k) => stairs.forEach((m, i) => { const v = Math.min(1, Math.max(0, k * LEVELS - i)); m.visible = v > 0; });
  g.stairs = stairs; g.pav = pav;
  g.setWater(lvY(11));
  return g;
}
// surroundings: dusty ground ring is the top ring; add a few houses and trees around
export function swVillage(scene, { seed = 4 } = {}) {
  const R = rng(seed); const g = new THREE.Group(); scene.add(g);
  const mud = new THREE.MeshStandardMaterial({ color: 0xc89060, roughness: 1 }), roof = new THREE.MeshStandardMaterial({ color: 0x8a4a2a, roughness: 0.9 });
  for (let i = 0; i < 30; i++) {
    const a = R() * Math.PI * 2, r = 24 + R() * 25; const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (Math.abs(x) < 26 && Math.abs(z) < 26) continue;
    const w = 3 + R() * 2, h = 2.4 + R() * 1.5;
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w * 0.8), mud); b.position.set(x, h / 2, z); b.rotation.y = R() * 3; g.add(b);
    const rf = new THREE.Mesh(new THREE.BoxGeometry(w + 0.4, 0.3, w * 0.8 + 0.4), roof); rf.position.set(x, h + 0.15, z); rf.rotation.y = b.rotation.y; g.add(rf);
  }
  const trunk = new THREE.MeshStandardMaterial({ color: 0x5a3a22 }), leaf = new THREE.MeshStandardMaterial({ color: 0x5a7a2a, roughness: 0.9 });
  for (let i = 0; i < 14; i++) {
    const a = R() * Math.PI * 2, r = 18 + R() * 30; const x = Math.cos(a) * r, z = Math.sin(a) * r; if (Math.abs(x) < 15 && Math.abs(z) < 15) continue;
    const t = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.35, 3, 8), trunk); t.position.set(x, 1.5, z); g.add(t);
    const c = new THREE.Mesh(new THREE.SphereGeometry(2.2 + R(), 12, 10), leaf); c.scale.y = 0.6; c.position.set(x, 3.6, z); g.add(c);
  }
  // far ground
  const far = new THREE.Mesh(new THREE.RingGeometry(58, 500, 64), swMats().ground); far.rotation.x = -Math.PI / 2; far.position.y = -0.02; g.add(far);
  return shadowAll(g), g;
}
// Indian villager (bright clothes) with an optional water pot on the head
export function villager(i = 0, { pot = true } = {}) {
  const h = romanBuilder({ color: [0xd8402a, 0xf0a020, 0x2a8a7a, 0xc8306a][i % 4], skin: [0x8a5a3a, 0x9a6440, 0x7a4a30][i % 3] });
  if (pot) { const p = new THREE.Mesh(new THREE.SphereGeometry(0.17, 14, 10), new THREE.MeshStandardMaterial({ color: 0xb8803a, metalness: 0.5, roughness: 0.4 })); p.scale.y = 0.9; p.position.y = 0.3; h.j.head.add(p); h.pot = p; }
  shadowAll(h.root);
  return h;
}
// a route down the front-right flights: u 0..1 -> position on terraces (zigzags in x while stepping down)
export function route(u, from = 0, to = 11) {
  const f = from + (to - from) * u; const i = Math.floor(f), k = f - i;
  const yA = lvY(i), yB = lvY(i + 1);
  const x = 2 + (i % 2 ? 1 - k : k) * 2.6;
  const zA = lvW(i) - 0.45, zB = lvW(i + 1) - 0.45;
  return new THREE.Vector3(x, yA + (yB - yA) * k, zA + (zB - zA) * k);
}
