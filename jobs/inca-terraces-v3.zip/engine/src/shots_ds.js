// Damascus steel reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, birds } from './world.js';
import { glowSprite, sparks } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { fabricTexture } from './textures.js';
import { desertGround, palm, yakhchal } from './persia.js';
import { engineer } from './rome.js';
import { blade, crucible, cake, coals, furnace, anvil, hammer, smith, forgeRoom, grains, oreLump, nanotube, hut, waterPattern } from './damascus.js';
import { VO } from './vo_ds.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Look closely', 2], ['at an old', 3], ['*Damascus sword*', 2], ["and you'll see", 3], ['a *pattern*', 2], ['like *flowing water*', 3], ['in the *steel*', 3]],
  [['But *nobody*', 2], ['*painted* it on', 3], ['It *grew*', 2], ['from *inside*', 2], ['the *metal*', 2]],
  [['It started in', 3], ['*southern India*', 2], ['with a steel', 3], ['called *wootz*', 2]],
  [['*Smiths* sealed', 2], ['*iron*', 1], ['and *plant matter*', 3], ['in *clay pots*', 3], ['and *heated* them', 3], ['for *hours*', 2]],
  [['The iron', 2], ['soaked up *carbon*', 3], ['and *melted*', 2], ['into a hard', 3], ['little *cake*', 2]],
  [['*Traders*', 1], ['carried these cakes', 3], ['*west*', 1], ['where smiths', 2], ['*forged* them', 2], ['into *blades*', 2]],
  [['They worked', 2], ['at *low heat*', 3], ['*Too hot*', 2], ['and the cake', 3], ['would *crumble*', 2]],
  [['With each', 2], ['*hammer blow*', 2], ['tiny *carbide*', 2], ['*grains*', 1], ['lined up', 2], ['in *wavy bands*', 3]],
  [['*Traces*', 1], ['of *vanadium*', 2], ['in the *Indian ore*', 4], ['probably *helped*', 2]],
  [['*Hard bands*', 2], ['for a *keen edge*', 4], ['*softer steel*', 2], ['for *toughness*', 2]],
  [['By the early', 3], ['*1800s*', 2], ['the *recipe*', 2], ['was *lost*', 2]],
  [['In the *1990s*', 4], ['a *scientist*', 2], ['and a *bladesmith*', 3], ['finally *recreated* it', 3]],
  [['Some researchers', 2], ['even reported', 2], ['*carbon nanotubes*', 2], ['in an old blade', 4], ['though others', 2], ['*doubt it*', 2]],
  [['A *secret*', 2], ['written in *steel*', 3], ['read again', 2], ['after *200 years*', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared ============
function darkStudio(makeStage, { top = 0x14100c, mid = 0x1e1812, horizon = 0x2a2018, floor = 0x100c08, sunDir = [-1, 3, 2], sun = 2.2, shadowSize = 1 } = {}) {
  const scene = makeStage({ shadowSize, sunDir, sun });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(top); u.mid.value.set(mid); u.horizon.value.set(horizon); u.floorC.value.set(floor);
  return scene;
}
// blade lying flat, running along screen-vertical (-z = tip) for a camera above; centred on the origin
function flatBlade(opts) { const B = blade(opts); B.rotation.x = -Math.PI / 2; B.position.x = -0.38; const g = new THREE.Group(); g.add(B); g.rotation.y = Math.PI / 2; g.B = B; return g; }
function cloth(scene, w = 3, d = 2, color = 0x3a1a14) { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ color, roughness: 0.85, bumpMap: fabricTexture(5), bumpScale: 2 })); m.rotation.x = -Math.PI / 2; m.receiveShadow = true; scene.add(m); return m; }
const hammerPose = (e, t, ph, { down = 1 } = {}) => { // ph 0..1 swing phase: 0 raised, 1 strike
  const k = ph < 0.7 ? 1 - easeInOut(ph / 0.7) * 0.15 : 1 - easeIn((ph - 0.7) / 0.3);
  standPose(e, t, { spine: [0.4, 0, 0], head: [0.2, 0, 0], rSh: [-0.75 - k * 1.75 * down, 0, -0.15], rEl: [-0.5 - k * 0.6, 0, 0], lSh: [-0.9, 0, 0.25], lEl: [-0.7, 0, 0] });
  e.setMood('happy'); e.setMouth(0); e.grip(0.8, 1);
};
const swing = (t, period = 0.7, off = 0) => ((t + off) / period) % 1;
function holdHammer(e) { const h = hammer(); h.rotation.set(Math.PI / 2, 0, 0); h.position.set(0, -0.06, 0.02); e.j.rWr.add(h); return h; }
function indiaGround(scene, seed = 1) {
  const g = new THREE.Mesh(new THREE.CircleGeometry(400, 64), new THREE.MeshStandardMaterial({ color: 0x9a6a44, roughness: 1, bumpMap: fabricTexture(23 + seed), bumpScale: 4 })); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; scene.add(g);
  scene.add(mountains({ rMin: 120, rMax: 320, height: 34, seed: 4 + seed, color: 0x4f6a3a }));
  return g;
}

// ============ S0: an old Damascus sword, close, the watered pattern catching the light ============
function sHook({ makeStage }) {
  const scene = darkStudio(makeStage, { sunDir: [-1, 2.5, 2] });
  cloth(scene, 4, 3, 0x4a1c16).position.y = -0.02;
  const B = flatBlade({ L: 1.0, pattern: 1 }); B.position.y = 0.012; B.rotation.y = Math.PI / 2 + 0.12; scene.add(B);
  const warm = new THREE.PointLight(0xffc890, 2.5, 3, 2); warm.position.set(0.4, 0.6, 0.5); scene.add(warm);
  fillLight(scene, [1, 0.6, -0.5], 0.8, 0xbcd4ff);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.6));
      const pos = [lerp(0.05, 0.0, k), lerp(1.0, 0.75, k), lerp(0.75, 0.2, k)], look = [0, 0, lerp(0.2, -0.25, k)];
      warm.position.set(0.3, 0.5, lerp(0.6, -0.6, k));
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.25, dof: dofTo(pos, look, 0.006, 0.012) };
    },
  };
}
// ============ S1: plain steel; the pattern grows out from inside ============
function sReveal({ makeStage, start: ST }) {
  const tG = at(1, 'grew') - ST;
  const scene = darkStudio(makeStage, { sunDir: [0.5, 2.5, 2] });
  const B = flatBlade({ L: 1.0, pattern: 1, plain: true }).B; B.parent.rotation.y = Math.PI / 2 + 0.05; scene.add(B.parent);
  cloth(scene, 4, 3, 0x2a1410).position.y = -0.02;
  const warm = new THREE.PointLight(0xffd0a0, 2.2, 3, 2); warm.position.set(0.1, 0.5, 0.3); scene.add(warm);
  const c = cam(28);
  return {
    scene, camera: c,
    update(t) {
      B.reveal(easeInOut(range(t, tG - 0.6, tG + 1.2)));
      const k = easeInOut(range(t, 0, 3.6));
      const pos = [0.035, lerp(0.42, 0.34, k), lerp(0.05, -0.05, k)], look = [0.035, 0, lerp(-0.1, -0.2, k)];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.2 };
    },
  };
}
// ============ S2: a village in southern India, a crucible furnace smoking ============
function sIndia({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.6, 0.35, -0.7], fog: 0.004, shadowSize: 8, envI: 0.95 });
  indiaGround(scene, 2);
  [[-5, -6, 0.2], [5.5, -7, 1], [-1, -12, 2]].forEach(([x, z, s]) => { const h = hut(s + 1); h.position.set(x, 0, z); scene.add(h); });
  [[-8, -3, 6], [8, -2, 5.5], [3, -16, 6.5], [-10, -14, 7], [12, -12, 6]].forEach(([x, z, h], i) => { const p = palm(h, i + 3); p.position.set(x, 0, z); scene.add(p); });
  const F = furnace({ n: 5 }); scene.add(F);
  const men = [smith(0), smith(1)]; men.forEach(e => scene.add(e.root));
  men[0].root.position.set(-1.3, 0, 0.6); men[0].root.rotation.y = 1.0;
  men[1].root.position.set(1.4, 0, 0.3); men[1].root.rotation.y = -1.2;
  const smoke = [...Array(6)].map((_, i) => { const s = glowSprite(0x8a7a6a, 1.2); s.material.blending = THREE.NormalBlending; s.material.opacity = 0.25; scene.add(s); return s; });
  fillLight(scene, [0.3, 0.4, 1], 0.6, 0xffe6c8);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      men.forEach((e, i) => { standPose(e, t + i, { lSh: [-0.4, 0, 0.3], rSh: [-0.4, 0, -0.3], head: [0.3, 0, 0] }); e.setMood('happy'); e.setMouth(0); });
      smoke.forEach((s, i) => { const u = ((t * 0.25 + i / 6) % 1); s.position.set(Math.sin(u * 4 + i) * 0.3, 0.8 + u * 4, -u * 0.8); s.scale.setScalar(0.8 + u * 2.5); s.material.opacity = 0.3 * (1 - u); });
      F.fire.intensity = 3 + Math.sin(t * 11) * 0.4;
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(2.0, 1.2, k), lerp(3.6, 2.8, k), lerp(12, 9.5, k)], [0, lerp(1.6, 1.2, k), -2]);
      return { bloom: 0.6, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S3: iron bits and leaves dropped into a clay pot, sealed, then heated ============
function sSeal({ makeStage, start: ST }) {
  const tI = at(3, 'iron') - ST, tP = at(3, 'plant') - ST, tS = at(3, 'sealed') - ST, tH = at(3, 'heated') - ST;
  const scene = darkStudio(makeStage, { top: 0x1a120c, mid: 0x2a1c12, horizon: 0x3a2818, sunDir: [-1, 3, 2] });
  cloth(scene, 4, 4, 0x5a3c26);
  const pot = crucible(3, { lid: true }); scene.add(pot); const lid = pot.lid; const lidY = lid.position.y;
  const iron = [...Array(5)].map((_, i) => { const b = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, 0.05), new THREE.MeshStandardMaterial({ color: 0x4a4440, metalness: 0.6, roughness: 0.6 })); b.castShadow = true; scene.add(b); return b; });
  const leaves = [...Array(5)].map((_, i) => { const l = new THREE.Mesh(new THREE.PlaneGeometry(0.06, 0.03), new THREE.MeshStandardMaterial({ color: 0x5a8a2a, side: THREE.DoubleSide, roughness: 0.8 })); scene.add(l); return l; });
  const potMat = pot.children[0].material; potMat.emissive = new THREE.Color(0xff4a10);
  const glow = glowSprite(0xff6a20, 1.4); glow.position.set(0, 0.35, 0); scene.add(glow);
  const bed = coals(1.6, 1.2, { n: 120 }); scene.add(bed);
  const fire = new THREE.PointLight(0xff7028, 0, 2.5, 2); fire.position.set(0.2, 0.3, 0.4); scene.add(fire);
  const c = cam(32);
  const top = 0.66;
  return {
    scene, camera: c,
    update(t) {
      iron.forEach((b, i) => { const t0 = tI - 0.5 + i * 0.12, u = range(t, t0, t0 + 0.45); b.visible = u > 0 && u < 1; b.position.set((i - 2) * 0.012, lerp(top + 0.5, top - 0.1, easeIn(u)), (i % 2) * 0.02); b.rotation.set(t * 3 + i, i, 0); });
      leaves.forEach((l, i) => { const t0 = tP - 0.4 + i * 0.1, u = range(t, t0, t0 + 0.6); l.visible = u > 0 && u < 1; l.position.set(Math.sin(u * 6 + i) * 0.05, lerp(top + 0.5, top - 0.1, u), 0.02 * i - 0.04); l.rotation.set(u * 5, i, u * 3); });
      const s = easeInOut(range(t, tP + 0.7, tP + 1.2)); lid.position.y = lerp(lidY + 0.4, lidY, s); lid.visible = s > 0.01;
      const h = easeInOut(range(t, tH - 0.2, tH + 1.3));
      potMat.emissiveIntensity = h * 0.18; glow.material.opacity = h * 0.5; fire.intensity = h * 1.5; bed.visible = h > 0.01; bed.hot.emissiveIntensity = 1.6 * h;
      const k = easeInOut(range(t, 0, 4.6));
      const pos = [lerp(0.5, 0.8, k), lerp(1.5, 1.1, k), lerp(1.7, 2.2, k)], look = [0, lerp(0.5, 0.4, k), 0];
      place(c, pos, look);
      return { bloom: 0.6, warm: 1.25 };
    },
  };
}
// ============ S4: inside the pot: iron glows, melts, soaks up carbon, cools into a cake ============
function sMelt({ makeStage, start: ST }) {
  const tC = at(4, 'carbon') - ST, tM = at(4, 'melted') - ST, tK = at(4, 'cake') - ST;
  const scene = darkStudio(makeStage, { top: 0x1a0c06, mid: 0x2a1408, horizon: 0x3a1c0c });
  const pot = crucible(4, { lid: false }); scene.add(pot);
  const lumps = [...Array(6)].map((_, i) => { const m = new THREE.MeshStandardMaterial({ color: 0x4a4440, metalness: 0.5, roughness: 0.6, emissive: 0xff5010, emissiveIntensity: 0 }); const b = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.09, 0.11), m); b.position.set(Math.cos(i * 1.1) * 0.14, 0.14 + (i % 2) * 0.06, Math.sin(i * 1.1) * 0.14); b.scale.setScalar(0.8); b.rotation.set(i, i * 2, 0); scene.add(b); return b; });
  const dots = [...Array(80)].map((_, i) => { const d = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 4), new THREE.MeshBasicMaterial({ color: 0x111111 })); scene.add(d); return d; });
  const melt = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.28, 0.04, 40), new THREE.MeshStandardMaterial({ color: 0xffa040, emissive: 0xff7020, emissiveIntensity: 2.5, roughness: 0.2 })); melt.position.y = 0.12; scene.add(melt);
  const K = cake(3.4); scene.add(K);
  const bedM = coals(2.2, 2.2, { n: 220, seed: 6 }); scene.add(bedM);
  const glow = glowSprite(0xff7020, 0.9); glow.position.y = 0.3; scene.add(glow);
  const light = new THREE.PointLight(0xff7a28, 3, 3, 2); light.position.set(0, 0.8, 0.3); scene.add(light);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const hot = easeInOut(range(t, 0, tM)); const liq = easeInOut(range(t, tM - 0.4, tM + 0.8));
      lumps.forEach((b, i) => { b.material.emissiveIntensity = hot * 2; b.scale.setScalar(0.8 * Math.max(0.01, 1 - liq)); });
      dots.forEach((d, i) => { const a = i * 2.4, u = range(t, tC - 0.6 + (i % 10) * 0.05, tC + 0.6 + (i % 10) * 0.05); d.visible = u < 1 && t > 0.1; const r = lerp(0.3, 0.03, easeIn(u)); d.position.set(Math.cos(a) * r, lerp(1.5, 0.95, u), Math.sin(a) * r); });
      melt.visible = liq > 0.01 && t < tK; melt.scale.set(liq, 1, liq);
      const up = easeOut(range(t, tK - 0.35, tK + 0.6)); K.visible = t > tK - 0.35; K.position.set(0, lerp(0.12, 0.98, up), 0); K.rotation.set(lerp(0, -0.9, up), t * 0.5, 0); K.heat(lerp(0.55, 0.12, range(t, tK, tK + 0.9)), 0.1);
      glow.material.opacity = (0.2 + hot * 0.4) * (1 - up); light.intensity = 1.5 + hot * 2;
      const k = easeInOut(range(t, 0, 4.0));
      const pos = [lerp(0.0, 0.2, k), lerp(2.7, 2.2, k), lerp(1.0, 2.3, k)], look = [0, lerp(0.3, 0.75, k), 0];
      place(c, pos, look);
      return { bloom: 0.75, warm: 1.25 };
    },
  };
}
// ============ S5: traders carry the cakes west across the desert to a domed city ============
function sTrade({ makeStage }) {
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.6, 0.4, 0.7], fog: 0.004, shadowSize: 6, envI: 0.9 });
  desertGround(scene, { seed: 4 });
  [[-30, -50], [-18, -58], [-6, -54]].forEach(([x, z], i) => { const d = yakhchal({ R: 5 + i, H: 9 + i * 2 }); d.position.set(x - 6, 0, z); scene.add(d); });
  [[-16, -36, 6], [-24, -40, 5], [4, -42, 5.5]].forEach(([x, z, h], i) => { const p = palm(h, i + 21); p.position.set(x, 0, z); scene.add(p); });
  const men = [smith(1), smith(2), smith(0)]; men.forEach(e => scene.add(e.root));
  men.forEach(e => { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.15, 0.12, 18), new THREE.MeshStandardMaterial({ color: 0xb89a6a, roughness: 1, bumpMap: fabricTexture(3), bumpScale: 4 })); b.position.set(0, 0.26, 0); b.castShadow = true; e.j.head.add(b); for (let i = 0; i < 3; i++) { const k = cake(1.4); k.position.set((i - 1) * 0.09, 0.32, 0); k.rotation.z = (i - 1) * 0.3; e.j.head.add(k); } });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      men.forEach((e, i) => {
        const x = -t * 0.9 - i * 1.6; e.root.position.set(x, 0, i * 0.5 - 0.3); e.root.rotation.y = -Math.PI / 2;
        const w = Math.sin(t * 6 + i * 2);
        standPose(e, t, { lHip: [w * 0.4, 0, 0.06], rHip: [-w * 0.4, 0, -0.06], lKn: [Math.max(0, -w) * 0.5, 0, 0], rKn: [Math.max(0, w) * 0.5, 0, 0], lSh: [-w * 0.3, 0, 0.12], rSh: [-2.9, 0, -0.3], rEl: [-0.9, 0, 0] });
        e.setMood('happy'); e.setMouth(0);
      });
      const k = easeInOut(range(t, 0, 4.2)); const cx = -t * 0.9 - 1.6;
      place(c, [cx + lerp(5, 3.5, k), lerp(2.0, 1.7, k), lerp(8.5, 7, k)], [cx - 2.2, 1.3, -1]);
      return { bloom: 0.55, flare: 0.8, warm: 1.25 };
    },
  };
}
// ============ S6: forging at low heat; too hot and the cake crumbles ============
function sCrumble({ makeStage, start: ST }) {
  const tH = at(6, 'too') - ST, tC = at(6, 'crumble') - ST;
  const scene = darkStudio(makeStage, { sunDir: [1, 3, 2], sun: 0.6, shadowSize: 2 });
  forgeRoom(scene);
  const A = anvil(); scene.add(A);
  const K = cake(1.6); K.position.set(0, A.topY, 0); scene.add(K);
  const frags = [...Array(10)].map((_, i) => { const f = new THREE.Mesh(new THREE.DodecahedronGeometry(0.03, 0), K.material); f.castShadow = true; scene.add(f); return f; });
  const sp = sparks(80, { speed: 2.2, spread: 1.2, life: 0.5, size: 0.025, dir: V(0, 1, 0) }); sp.position.set(0, A.topY + 0.05, 0); scene.add(sp);
  const S = smith(2); S.root.position.set(-0.08, 0, -0.45); scene.add(S.root); holdHammer(S);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.fire(1, t);
      const hot = easeInOut(range(t, tH - 0.1, tH + 0.5));
      const brk = t > tC + 0.1;
      K.visible = !brk; K.heat(lerp(0.45, 1.0, hot), hot); K.material.emissiveIntensity = lerp(0.9, 2.6, hot);
      frags.forEach((f, i) => { const u = Math.max(0, t - tC - 0.1); f.visible = brk; const a = i * 0.63; f.position.set(Math.cos(a) * (0.03 + u * 0.4), A.topY + 0.02 + u * 0.6 - 3 * u * u, Math.sin(a) * (0.03 + u * 0.3)); f.rotation.set(u * 9 + i, u * 7, 0); });
      sp.update(t - (tC + 0.1));
      const ph = brk ? 0.2 : swing(t, 0.8);
      hammerPose(S, t, ph);
      const k = easeInOut(range(t, 0, 3.4));
      const pos = [lerp(2.0, 1.7, k), lerp(1.7, 1.5, k), lerp(2.6, 2.2, k)], look = [-0.15, lerp(0.95, 0.85, k), -0.3];
      place(c, pos, look);
      return { bloom: 0.7, warm: 1.25, dof: dofTo(pos, look, 0.004, 0.01) };
    },
  };
}
// ============ S7: inside the steel: each hammer blow pulls the carbide grains into wavy bands ============
function sGrains({ makeStage, start: ST }) {
  const tB = at(7, 'blow') - ST;
  const scene = darkStudio(makeStage, { top: 0x0a1018, mid: 0x101a26, horizon: 0x18263a, floor: 0x080c12, sunDir: [1, 2, 3] });
  const bg = new THREE.Mesh(new THREE.PlaneGeometry(6, 8), new THREE.MeshStandardMaterial({ color: 0x4a5462, metalness: 0.6, roughness: 0.5 })); bg.position.z = -0.25; scene.add(bg);
  const G = grains(900); scene.add(G);
  fillLight(scene, [0, 0, 1], 1.4, 0xcfe0ff);
  const c = cam(40);
  const blows = [0, 1, 2, 3, 4, 5].map(i => tB + i * 0.62);
  return {
    scene, camera: c,
    update(t) {
      let k = 0, sh = 0; blows.forEach((b, i) => { k += easeOut(range(t, b, b + 0.3)) / blows.length; sh = Math.max(sh, Math.max(0, 1 - (t - b) / 0.15) * (t >= b ? 1 : 0)); });
      G.set(k, t);
      const s = shake(t, sh * 6, 3);
      place(c, [s[0], s[1], lerp(5.2, 4.6, easeInOut(range(t, 0, 4)))], [0, 0, 0]);
      return { bloom: 0.5, warm: 0.9 };
    },
  };
}
// ============ S8: the Indian ore, with traces of vanadium sparkling ============
function sOre({ makeStage, start: ST }) {
  const tV = at(8, 'vanadium') - ST;
  const scene = darkStudio(makeStage, { top: 0x101418, mid: 0x1a2028, horizon: 0x262e38, sunDir: [-1, 2, 2] });
  const O = oreLump(); O.position.y = 0.55; scene.add(O);
  cloth(scene, 4, 4, 0x3a2e24);
  const bl = new THREE.PointLight(0x5ac0ff, 0, 2, 2); bl.position.set(0.3, 0.9, 0.7); scene.add(bl);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      O.rotation.y = t * 0.35;
      const g = easeOut(range(t, tV - 0.1, tV + 0.6)); O.glow(g * (0.85 + 0.15 * Math.sin(t * 9))); bl.intensity = g * 1.5;
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(0.5, 0.3, k), lerp(1.3, 1.0, k), lerp(3.2, 2.5, k)], [0, 0.5, 0]);
      return { bloom: 0.8, warm: 1.0 };
    },
  };
}
// ============ S9: the edge: a glint runs along the hard bands ============
function sEdge({ makeStage, start: ST }) {
  const tE = at(9, 'edge') - ST, tS = at(9, 'softer') - ST;
  const scene = darkStudio(makeStage, { sunDir: [0.5, 2, 2] });
  const B = blade({ L: 1.0, pattern: 2 }); B.position.set(0.04, -0.6, 0); B.rotation.set(0, 0.25, Math.PI / 2); scene.add(B);
  const gl = glowSprite(0xffffff, 0.12); scene.add(gl);
  const warm = new THREE.PointLight(0xffd0a0, 2, 3, 2); warm.position.set(0, 0.3, 0.6); scene.add(warm);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      const u = easeInOut(range(t, tE - 0.4, tE + 0.8));
      scene.updateMatrixWorld(true);
      const x = lerp(0.1, 0.92, u), y = -0.11 * x * x - 0.072 * (1 - x * 0.15);
      gl.position.copy(B.localToWorld(V(x, y, 0.01))); gl.material.opacity = Math.sin(u * Math.PI); gl.scale.setScalar(0.1 + 0.08 * Math.sin(u * Math.PI));
      B.rotation.y = 0.25 + easeInOut(range(t, tS - 0.3, tS + 0.9)) * 0.5;
      const k = easeInOut(range(t, 0, 3.6));
      const pos = [0.0, lerp(-0.1, 0.1, k), lerp(1.9, 1.5, k)], look = [0.0, lerp(-0.05, 0.1, k), 0];
      place(c, pos, look);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
// ============ S10: the forge goes cold; the recipe is lost ============
function sLost({ makeStage, start: ST }) {
  const tL = at(10, 'lost') - ST;
  const scene = darkStudio(makeStage, { sunDir: [3, 3, 1], sun: 0.35, shadowSize: 3 });
  forgeRoom(scene);
  const A = anvil(); scene.add(A);
  const h = hammer(); h.rotation.set(0, 0.3, Math.PI / 2); h.position.set(-0.05, A.topY + 0.03, 0.02); scene.add(h);
  const moon = new THREE.DirectionalLight(0x8ab0ff, 0); moon.position.set(3, 3, 2); scene.add(moon);
  const dust = [...Array(40)].map((_, i) => { const s = glowSprite(0xd8c8b0, 0.025); s.position.set(Math.sin(i * 7.3) * 1.2, 0.4 + (i * 0.37 % 1.8), Math.cos(i * 3.1) * 0.8); scene.add(s); return s; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const f = 1 - easeInOut(range(t, 0.2, tL + 0.4)); scene.userData.fire(Math.max(0.03, f), t);
      moon.intensity = (1 - f) * 0.9;
      dust.forEach((s, i) => { s.position.y += Math.sin(t + i) * 0.0005; s.material.opacity = 0.4 * (1 - f * 0.6); });
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(1.9, 1.5, k), lerp(1.6, 1.4, k), lerp(3.4, 2.8, k)], [-0.6, 0.7, -0.6]);
      return { bloom: 0.55, warm: lerp(1.25, 0.8, 1 - f) };
    },
  };
}
// ============ S11: 1990s workshop: a scientist and a bladesmith; the pattern returns ============
function sModern({ makeStage, start: ST }) {
  const tR = at(11, 'recreated') - ST;
  const scene = makeStage({ shadowSize: 3, sunDir: [-2, 5, 3], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x6a7480); u.mid.value.set(0x8a929c); u.horizon.value.set(0xa8b0b8); u.floorC.value.set(0x4a4e54);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(14, 14), new THREE.MeshStandardMaterial({ color: 0x6a6e72, roughness: 0.9 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const table = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.06, 0.6), new THREE.MeshStandardMaterial({ color: 0x8a6a4a, roughness: 0.7 })); table.position.set(0.2, 0.9, 0.2); table.castShadow = table.receiveShadow = true; scene.add(table);
  [[-0.4, -0.05], [0.8, -0.05], [-0.4, 0.45], [0.8, 0.45]].forEach(([x, z]) => { const l = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.88, 0.05), table.material); l.position.set(x, 0.44, z); scene.add(l); });
  const B = blade({ L: 0.9, pattern: 3, plain: true }); B.rotation.x = -Math.PI / 2; B.position.set(-0.2, 0.94, 0.25); scene.add(B);
  const sci = engineer(); sci.root.position.set(0.55, 0, -0.35); sci.root.rotation.y = -0.2; scene.add(sci.root);
  sci.root.traverse(o => { if (o.isMesh && o.material.color && o.material.color.getHex() === 0xff7a1a) o.material = new THREE.MeshStandardMaterial({ color: 0xf4f4f0, roughness: 0.8 }); if (o.isMesh && o.material.color && o.material.color.getHex() === 0xffc81a) o.visible = false; });
  const bs = smith(1); bs.root.position.set(-0.75, 0, -0.35); bs.root.rotation.y = 0.35; scene.add(bs.root);
  const glow = glowSprite(0xbfe0ff, 0.6); glow.position.set(0.25, 0.97, 0.25); scene.add(glow);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const r = easeInOut(range(t, tR - 0.3, tR + 1.0)); B.reveal(r); glow.material.opacity = Math.sin(r * Math.PI) * 0.8;
      standPose(sci, t, { spine: [0.3, 0, 0], head: [0.4, 0, 0], rSh: [-0.6, 0, -0.2], rEl: [-0.8, 0, 0] }); sci.setMood('happy'); sci.setMouth(0); sci.blink(blinkK(t, [1.1, 3.2]));
      standPose(bs, t + 1, { spine: [0.25, 0, 0], head: [0.45, 0, 0], lSh: [-0.6, 0, 0.2], lEl: [-0.8, 0, 0] }); bs.setMood('happy'); bs.setMouth(0); bs.blink(blinkK(t, [2.0, 4.0]));
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(0.5, 0.3, k), lerp(2.0, 1.8, k), lerp(4.4, 3.4, k)], [0.0, lerp(1.1, 1.0, k), -0.1]);
      return { bloom: 0.5, warm: 1.05 };
    },
  };
}
// ============ S12: carbon nanotubes? (debated) ============
function sTube({ makeStage, start: ST }) {
  const tD = at(12, 'doubt') - ST;
  const scene = darkStudio(makeStage, { top: 0x04060c, mid: 0x080c18, horizon: 0x0c1428, floor: 0x04060a });
  const tubes = [[0, 0, 0, 1], [-1.3, -0.4, -1.5, 0.7], [1.4, 0.6, -2, 0.6]].map(([x, y, z, s]) => { const tb = nanotube(5, 0.5 * s); tb.position.set(x, y, z); tb.rotation.z = 0.6; scene.add(tb); return tb; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const d = easeInOut(range(t, tD - 0.2, tD + 0.6));
      tubes.forEach((tb, i) => { tb.rotation.y = t * (0.3 + i * 0.1); tb.material.opacity = lerp(1, 0.35, d) * (0.9 + 0.1 * Math.sin(t * 7 + i)); });
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(0.5, -0.3, k), lerp(0.4, 0.2, k), lerp(8.5, 7, k)], [0, 0, -0.5]);
      return { bloom: 0.9, warm: 0.9 };
    },
  };
}
// ============ S13: the sword on a stand in a shaft of sunlight ============
function sEnd({ makeStage }) {
  const scene = darkStudio(makeStage, { sunDir: [-1.5, 2.5, 1.2], sun: 2.6, shadowSize: 1.2 });
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(6, 4), new THREE.MeshStandardMaterial({ color: 0x5a3a28, roughness: 1, bumpMap: fabricTexture(17), bumpScale: 4 })); wall.position.set(0, 1, -0.4); wall.receiveShadow = true; scene.add(wall);
  const pm = new THREE.MeshStandardMaterial({ color: 0x4a2a18, roughness: 0.7 });
  [0.75, 1.45].forEach(y => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.2, 8), pm); p.rotation.x = Math.PI / 2; p.position.set(0.06, y, -0.3); p.castShadow = true; scene.add(p); });
  const B = blade({ L: 1.0, pattern: 1 }); B.position.set(0.04, 0.5, -0.27); B.rotation.z = Math.PI / 2; scene.add(B);
  const dust = [...Array(30)].map((_, i) => { const s = glowSprite(0xffe0b0, 0.02); s.position.set(Math.sin(i * 7.3) * 0.8, 0.9 + (i * 0.37 % 0.8), Math.cos(i * 3.1) * 0.3); scene.add(s); return s; });
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      dust.forEach((s, i) => { s.position.y = 0.9 + ((i * 0.37 + t * 0.03) % 0.8); s.material.opacity = 0.5; });
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(0.15, 0.25, k), lerp(1.25, 1.05, k), lerp(0.7, 2.4, k)], [0, lerp(1.25, 1.0, k), -0.27]);
      return { bloom: 0.6, warm: 1.3 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sReveal], [ls(2), ls(3), sIndia], [ls(3), ls(4), sSeal], [ls(4), ls(5), sMelt],
  [ls(5), ls(6), sTrade], [ls(6), ls(7), sCrumble], [ls(7), ls(8), sGrains], [ls(8), ls(9), sOre], [ls(9), ls(10), sEdge],
  [ls(10), ls(11), sLost], [ls(11), ls(12), sModern], [ls(12), ls(13), sTube], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
