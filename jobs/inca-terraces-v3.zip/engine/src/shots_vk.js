// Viking navigation reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { birds, mist } from './world.js';
import { glowSprite } from './props.js';
import { underwaterWorld } from './uw.js';
import { stripStudio } from './shots4.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { shadowAll } from './rome.js';
import { sea, waveH, longship, rideWaves, viking, sunCompass, icelandSpar, dividers, raven, iceberg, coast, norseMats } from './norse.js';
import { VO } from './vo_vk.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you sailed', 3], ['the *North Atlantic*', 3], ['*1,000 years* ago', 4], ['you had', 2], ['*no compass*', 2], ['and *no maps*', 3]],
  [['But the *Vikings*', 3], ['still found', 2], ['*Iceland*', 1], ['*Greenland*', 1], ['and even', 2], ['*North America*', 2]],
  [['Their first', 2], ['*trick*', 1], ['was the *sun*', 3]],
  [['By watching', 2], ['how high', 2], ['the *sun* climbed', 3], ['at *noon*', 2], ['they could hold', 3], ['a *steady course*', 3], ['east or west', 3]],
  [['On *clear days*', 3], ['a wooden', 2], ['*sun compass*', 2], ['may have helped', 3], ['them *steer*', 2]],
  [['*Half* of a disc', 4], ['like this', 2], ['was found', 2], ['in *Greenland*', 2], ['in *1948*', 4]],
  [['But what about', 3], ['*cloudy days?*', 2]],
  [['The *sagas*', 2], ['mention a', 2], ['*mysterious*', 1], ['*sunstone*', 1]],
  [['It may have been', 4], ['a clear *crystal*', 3], ['called', 1], ['*Iceland spar*', 2]],
  [['Hold it up', 3], ['to a *cloudy sky*', 4], ['and it can show', 4], ['where the', 2], ['*hidden sun* is', 3]],
  [['A crystal like this', 4], ['was even found', 3], ['in a *shipwreck*', 3], ['from *1592*', 4], ['next to its', 3], ['*navigation tools*', 2]],
  [['They also watched', 3], ['*seabirds*', 1], ['and *coastlines*', 2], ['to find *land*', 3]],
  [['One sailor', 2], ['named *Floki*', 2], ['took', 1], ['*three ravens*', 2], ['and followed', 2], ['the one that', 3], ['*flew ahead*', 2], ['and never', 2], ['*came back*', 2]],
  [['It led him', 3], ['to *Iceland*', 2], ['and he became', 3], ['known as', 2], ['*Raven Floki*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: open sea with the longship ============
function ocean(makeStage, { preset = 'north', sunDir = [-0.5, 0.45, 0.7], fog = 0.006, waves = 1, crew = true, cloud = null, ...o } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize: 12, shadowAt: [0, 1, 0], envI: 0.85, ...(cloud != null ? { cloud } : {}), ...o });
  const S = sea(scene, { scale: waves });
  const ship = longship(); scene.add(ship);
  const men = [];
  if (crew) [[3.0, 0.6, 0x4a6a4a, 0x8a2a24], [-2.2, -0.7, 0x6a5a3a, 0x2a4a6a], [-4.5, 0.5, 0x5a4a6a, 0x6a6a3a]].forEach(([x, z, c, k]) => { const v = viking({ color: c, cloak: k }); v.root.position.set(x, 0.38, z); v.root.rotation.y = Math.PI / 2; ship.add(v.root); men.push(v); });
  fillLight(scene, [0.4, 0.5, 1], 0.5);
  return { scene, ship, men, S, waves };
}
const crewIdle = (men, t) => men.forEach((m, i) => { standPose(m, t + i, {}); m.setMood('happy'); m.setMouth(0); m.blink(blinkK(t + i, [1.4, 3.6])); });

// ============ S0: a lone longship on a grey, empty sea ============
function sAlone({ makeStage }) {
  const O = ocean(makeStage, { preset: 'storm', sunDir: [0.3, 0.4, -0.86], fog: 0.012, waves: 1.3 });
  const m = mist(300, 300, { y: 3, opacity: 0.18, color: 0xdfe6ea, scale: 0.02 }); O.scene.add(m);
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, t * 0.8, 0, 0, T, O.waves); crewIdle(O.men, t);
      const k = easeInOut(range(t, 0, 5.3));
      place(c, [lerp(-26, -18, k), lerp(9, 4, k), lerp(26, 18, k)], [t * 0.8 + 2, 3, 0]);
      return { bloom: 0.4, warm: 0.6, sat: 0.85 };
    },
  };
}
// ============ S1: sailing past icebergs toward a snowy coast ============
function sFound({ makeStage, start: ST }) {
  const O = ocean(makeStage, { preset: 'golden', sunDir: [0.55, 0.2, -0.81], fog: 0.004 });
  O.scene.add(coast({ x: 30, z: -140, w: 300, h: 34 }));
  [[30, -40, 5, 1], [-24, -60, 7, 2], [55, -80, 9, 3], [-60, -30, 4, 4]].forEach(([x, z, s, sd]) => { const b = iceberg(s, sd); b.position.set(x, 0, z); O.scene.add(b); });
  const c = cam(38);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, -t * 1.2, Math.PI / 2, T, O.waves); crewIdle(O.men, t);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(24, 18, k), lerp(5, 7, k), lerp(20, 16, k) - t * 1.2], [-4, 4, -30 - t * 1.2]);
      return { bloom: 0.6, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2: the sun breaks through, the navigator looks up ============
function sSun({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [-0.2, 0.55, -0.8], cloud: 0.5 });
  const nav = O.men[0];
  const c = cam(36);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, 0, 0, T, O.waves); crewIdle(O.men.slice(1), t);
      standPose(nav, t, { neck: [-0.35, 0, 0], head: [-0.35, 0.2, 0], rSh: [-2.1, 0, -0.75], rEl: [-0.2, 0, 0] }); nav.setMood('happy'); nav.setMouth(0); nav.blink(blinkK(t, [1.0]));
      O.scene.updateMatrixWorld(true);
      const hp = wpos(nav.j.head, V(0, 0, 0));
      const k = easeInOut(range(t, 0, 1.9));
      const pos = [hp.x + lerp(2.4, 1.8, k), hp.y + lerp(-0.3, -0.5, k), hp.z + lerp(2.2, 1.6, k)];
      place(c, pos, [hp.x - 1, hp.y + 1.2, hp.z - 1.2]);
      return { bloom: 0.8, flare: 1.2, warm: 1.2 };
    },
  };
}
// ============ S3: noon sun height: the navigator measures with an outstretched hand ============
function sNoon({ makeStage, start: ST }) {
  const O = ocean(makeStage, { sunDir: [0.0, 0.62, -0.78], cloud: 0.3 });
  const nav = O.men[0];
  const arc = new THREE.Mesh(new THREE.TorusGeometry(30, 0.15, 6, 80, Math.PI), new THREE.MeshBasicMaterial({ color: 0xffd43b, transparent: true, opacity: 0.0, depthWrite: false, fog: false })); arc.position.set(0, 0, -60); O.scene.add(arc);
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, 0, 0, T, O.waves); crewIdle(O.men.slice(1), t);
      standPose(nav, t, { lSh: [-1.9, 0, 0.25], lEl: [-0.05, 0, 0], head: [-0.25, 0, 0], neck: [-0.2, 0, 0] }); nav.setMood('happy'); nav.setMouth(0); nav.grip(0.95, 0.3); nav.blink(blinkK(t, [2.0]));
      arc.material.opacity = 0.55 * easeOut(range(t, 0.6, 1.8));
      O.scene.updateMatrixWorld(true);
      const hp = wpos(nav.j.head, V(0, 0, 0));
      const k = easeInOut(range(t, 0, 5.0));
      place(c, [hp.x + lerp(-2.6, -3.4, k), hp.y + lerp(-0.4, 0.0, k), hp.z + lerp(3.4, 4.6, k)], [hp.x + 0.6, hp.y + lerp(0.5, 1.6, k), hp.z - 2]);
      return { bloom: 0.6, flare: 0.9, warm: 1.1 };
    },
  };
}
// ============ S4: sun compass on the deck, the gnomon's shadow swinging to the line ============
function sCompass({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [-0.5, 0.55, 0.65], cloud: 0.3, crew: false, waves: 0.5 });
  const sc = sunCompass(); O.ship.add(sc); sc.position.set(2.0, 0.42, 0);
  const hand = viking(); hand.root.position.set(2.0, 0.38, -0.6); hand.root.rotation.y = 0; O.ship.add(hand.root);
  const c = cam(32);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, 0, 0.3, T, O.waves);
      sc.rotation.y = lerp(0.9, 0.0, easeInOut(range(t, 0.3, 2.6)));
      standPose(hand, t, { spine: [0.5, 0, 0], chest: [0.3, 0, 0], lSh: [-1.0, 0, 0.2], rSh: [-1.0, 0, -0.2], lEl: [-0.4, 0, 0], rEl: [-0.4, 0, 0], head: [0.5, 0, 0] }); hand.setMood('happy'); hand.setMouth(0);
      O.scene.updateMatrixWorld(true);
      const p = wpos(sc, V(0, 0, 0));
      const k = easeInOut(range(t, 0, 3.9));
      const pos = [p.x + lerp(0.9, 0.6, k), p.y + lerp(0.8, 0.6, k), p.z + lerp(0.7, 0.5, k)];
      place(c, pos, [p.x, p.y, p.z]);
      return { bloom: 0.5, warm: 1.15, dof: dofTo(pos, [p.x, p.y, p.z], 0.01, 0.012) };
    },
  };
}
// ============ S5: the broken half disc on dark cloth under a museum spotlight ============
function sDisc({ makeStage, start: ST }) {
  const scene = makeStage({ shadowSize: 0.6, sunDir: [-1, 3, 1.5], sun: 1.6 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x0c0c10); u.mid.value.set(0x121216); u.horizon.value.set(0x18181c); u.floorC.value.set(0x0a0a0c);
  const cloth = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), new THREE.MeshStandardMaterial({ color: 0x1a2440, roughness: 1, bumpMap: norseMats().sail.map, bumpScale: 0.5 })); cloth.rotation.x = -Math.PI / 2; cloth.receiveShadow = true; scene.add(cloth);
  const d = sunCompass({ broken: true }); d.position.y = 0.013; scene.add(d);
  const spot = new THREE.SpotLight(0xfff0d8, 8, 3, 0.35, 0.6, 1.2); spot.position.set(0.2, 1.4, 0.4); spot.target.position.set(0, 0, 0); spot.castShadow = true; scene.add(spot, spot.target);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.4));
      const pos = [lerp(-0.35, 0.25, k), lerp(0.75, 0.62, k), lerp(0.6, 0.5, k)];
      place(c, pos, [0, 0, 0.02]);
      return { bloom: 0.4, warm: 1.1, dof: dofTo(pos, [0, 0, 0], 0.01, 0.012) };
    },
  };
}
// ============ S6: cloudy, rough sea, no sun ============
function sCloudy({ makeStage }) {
  const O = ocean(makeStage, { preset: 'storm', sunDir: [0.2, 0.5, -0.84], fog: 0.012, waves: 1.1 });
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, t * 0.6, 0, 0, T, O.waves); O.ship.position.y += 0.3; crewIdle(O.men, t);
      const sh = shake(t, 2, 4);
      place(c, [t * 0.6 - 9 + sh[0], 2.4 + sh[1], 8.5], [t * 0.6 + 1, 3.2, 0]);
      return { bloom: 0.35, warm: 0.5, sat: 0.8 };
    },
  };
}
// ============ S7: the navigator raises the sunstone ============
function sRaise({ makeStage }) {
  const O = ocean(makeStage, { preset: 'storm', sunDir: [0.2, 0.5, -0.84], fog: 0.01, waves: 1.2 });
  const nav = O.men[0];
  const xs = icelandSpar(0.07); O.scene.add(xs);
  const glow = glowSprite(0xdff2ff, 1); glow.scale.setScalar(0.35); glow.material.blending = THREE.AdditiveBlending; O.scene.add(glow);
  const c = cam(34);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, 0, 0, T, O.waves); crewIdle(O.men.slice(1), t);
      const up = easeOut(range(t, 0.2, 1.2));
      standPose(nav, t, { rSh: [lerp(0.05, -2.5, up), 0, lerp(-0.2, -0.65, up)], rEl: [lerp(-0.25, -0.2, up), 0, 0], neck: [-0.3 * up, 0, 0], head: [-0.4 * up, 0, 0] }); nav.setMood('happy'); nav.setMouth(0); nav.grip(0.3, 0.7); nav.blink(blinkK(t, [1.8]));
      O.scene.updateMatrixWorld(true);
      const hp = wpos(nav.j.rWr, V(0, -0.1, 0.03)); xs.position.copy(hp); xs.rotation.set(t * 0.4, t * 0.6, 0.3); glow.position.copy(hp); glow.material.opacity = 0.6 * up * (0.7 + 0.3 * Math.sin(t * 4));
      const hd = wpos(nav.j.head, V(0, 0, 0));
      const k = easeInOut(range(t, 0, 2.7));
      place(c, [hd.x + lerp(2.6, 2.0, k), hd.y + lerp(-0.6, -0.9, k), hd.z + lerp(1.8, 1.2, k)], [hd.x - 0.2, hd.y + 0.5, hd.z - 0.2]);
      return { bloom: 0.7, warm: 0.7 };
    },
  };
}
// ============ S8: macro of the crystal: a dot seen twice through it (double refraction) ============
function sSpar({ makeStage }) {
  const scene = makeStage({ shadowSize: 0.4, sunDir: [-1, 3, 2], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a3440); u.mid.value.set(0x3a4654); u.horizon.value.set(0x56626e); u.floorC.value.set(0x20262c);
  const wood = new THREE.Mesh(new THREE.PlaneGeometry(3, 3), norseMats().hull); wood.rotation.x = -Math.PI / 2; wood.receiveShadow = true; scene.add(wood);
  const xs = icelandSpar(0.1); xs.position.set(0, 0.04, 0); scene.add(xs);
  // one dot on the wood outside the crystal, and the same dot doubled inside its footprint
  const dm = new THREE.MeshBasicMaterial({ color: 0x1a1008 });
  const d0 = new THREE.Mesh(new THREE.CircleGeometry(0.006, 16), dm); d0.rotation.x = -Math.PI / 2; d0.position.set(0.09, 0.001, 0.02); scene.add(d0);
  const d1 = d0.clone(); d1.position.set(-0.008, 0.001, 0.0); scene.add(d1);
  const d2 = d0.clone(); d2.position.set(0.006, 0.001, 0.012); scene.add(d2);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      const a = t * 0.35;
      place(c, [Math.sin(a) * 0.22, 0.2, Math.cos(a) * 0.22], [0, 0.03, 0]);
      return { bloom: 0.6, warm: 1.0, dof: { focus: 0.29, aperture: 0.012, maxblur: 0.012 } };
    },
  };
}
// ============ S9: looking through the crystal at a grey sky, the hidden sun's spot lights up ============
function sHidden({ makeStage, start: ST }) {
  const tH = at(9, 'hidden') - ST;
  const O = ocean(makeStage, { preset: 'storm', sunDir: [0.35, 0.42, -0.84], fog: 0.008, waves: 1.0, crew: false, sun: 0.5 });
  const xs = icelandSpar(0.08); O.scene.add(xs);
  const sunGlow = glowSprite(0xfff2c8, 1); sunGlow.material.blending = THREE.AdditiveBlending; sunGlow.material.fog = false; sunGlow.scale.setScalar(14); O.scene.add(sunGlow);
  const rc = document.createElement('canvas'); rc.width = rc.height = 256; { const x = rc.getContext('2d'); x.strokeStyle = '#ffd43b'; x.lineWidth = 26; x.shadowColor = '#ff9a00'; x.shadowBlur = 18; x.beginPath(); x.arc(128, 128, 96, 0, Math.PI * 2); x.stroke(); }
  const rt = new THREE.CanvasTexture(rc); rt.colorSpace = THREE.SRGBColorSpace;
  const ring = new THREE.Sprite(new THREE.SpriteMaterial({ map: rt, transparent: true, opacity: 0, depthTest: false, depthWrite: false, fog: false, toneMapped: false })); ring.renderOrder = 10; O.scene.add(ring);
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, 0, 0, T, O.waves);
      const sd = V(0.35, 0.42, -0.84).normalize();
      const eye = V(2.5, 3.0, 0);
      const sunPos = eye.clone().addScaledVector(sd, 200);
      const g = easeOut(range(t, tH - 0.6, tH + 0.4));
      sunGlow.position.copy(sunPos); sunGlow.material.opacity = 0.9 * g; sunGlow.scale.setScalar(14 + 10 * g);
      ring.position.copy(sunPos); ring.material.opacity = g; ring.scale.setScalar(lerp(70, 40, g));
      const look = eye.clone().addScaledVector(sd, 10).add(V(lerp(-2, 0, easeInOut(range(t, 0, tH))), -2.6, 0));
      xs.position.copy(eye).addScaledVector(look.clone().sub(eye).normalize(), 0.3); xs.position.y -= 0.1; xs.position.x += 0.04; xs.lookAt(look);
      place(c, [eye.x, eye.y, eye.z], [look.x, look.y, look.z]);
      return { bloom: 0.35 + g * 0.2, warm: 0.6 + g * 0.5, sat: 1.0, exposure: 0.62 };
    },
  };
}
// ============ S10: underwater shipwreck, a calcite crystal next to a pair of dividers ============
function sWreck({ makeStage, start: ST }) {
  const tN = at(10, 'navigation') - ST;
  const scene = makeStage({ shadowSize: 1 }); stripStudio(scene);
  underwaterWorld(scene, { surf: 1.2, density: 1.1, leaves: 0.0, size: 8, fogColor: 0x1f4a5a, particles: 800 });
  const wm = new THREE.MeshStandardMaterial({ color: 0x3a2e22, roughness: 1 });
  [[-0.5, 0.05, -0.3, 0.3, 2.4], [0.4, 0.06, -0.5, -0.2, 2.0], [0.1, 0.04, 0.4, 0.1, 1.6], [-0.9, 0.12, 0.1, 1.2, 1.4]].forEach(([x, y, z, ry, l]) => { const b = new THREE.Mesh(new THREE.BoxGeometry(l, 0.08, 0.16), wm); b.position.set(x, y, z); b.rotation.y = ry; b.rotation.z = 0.05; b.castShadow = b.receiveShadow = true; scene.add(b); });
  const rib = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.05, 6, 20, Math.PI * 0.7), wm); rib.position.set(-0.6, 0.0, -0.8); rib.rotation.set(0, 0.4, 0.2); scene.add(rib);
  const xs = icelandSpar(0.05); xs.material = xs.material.clone(); xs.material.roughness = 0.35; xs.material.color.set(0xe8eee8); xs.position.set(0.05, 0.03, 0.05); scene.add(xs);
  const dv = dividers(); dv.rotation.z = Math.PI / 2; dv.position.set(-0.07, 0.012, 0.06); scene.add(dv);
  const glow = glowSprite(0xffd43b, 1); glow.material.blending = THREE.AdditiveBlending; glow.scale.setScalar(0.25); scene.add(glow);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      glow.position.set(0.05, 0.05, 0.05); glow.material.opacity = 0.5 * Math.sin(Math.PI * range(t, 0.8, 2.6));
      const g2 = Math.sin(Math.PI * range(t, tN - 0.4, tN + 1.4)); dv.children.forEach(m => { if (m.material.emissive) { m.material.emissive.set(0x806a1e); m.material.emissiveIntensity = g2 * 0.6; } });
      const k = easeInOut(range(t, 0, 6.3));
      const pos = [lerp(0.6, 0.18, k), lerp(0.45, 0.2, k), lerp(0.9, 0.35, k)], look = [lerp(-0.1, 0.0, k), 0.03, 0.05];
      place(c, pos, look);
      return { bloom: 0.6, warm: 0.5, sat: 1.1, dof: dofTo(pos, look, 0.006, 0.01) };
    },
  };
}
// ============ S11: seabirds over the ship, heading for a coastline ============
function sBirds({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [-0.4, 0.4, -0.82], cloud: 0.35 });
  O.scene.add(coast({ x: 0, z: -160, w: 260, h: 22, seed: 7, snow: false }));
  const b = birds(9, { from: [-14, 9, 6], to: [10, 11, -40], spread: 5, speed: 0.12, scale: 1.4, seed: 2 }); O.scene.add(b); O.scene.userData.updaters.push((t) => b.update(t));
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, -t * 0.8, Math.PI / 2, T, O.waves); crewIdle(O.men, t);
      O.men[0].setPose && null;
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-14, -11, k), lerp(4, 5, k), lerp(10, 6, k) - t * 0.8], [lerp(0, 2, k), lerp(6, 6, k), -40]);
      return { bloom: 0.55, warm: 1.0 };
    },
  };
}
// ============ S12: Floki releases three ravens; one flies ahead ============
function sRavens({ makeStage, start: ST }) {
  const tR = at(12, 'ravens') - ST, tA = at(12, 'ahead') - ST;
  const O = ocean(makeStage, { sunDir: [-0.4, 0.42, -0.8], cloud: 0.4 });
  const floki = O.men[0];
  const R = [0, 1, 2].map(i => { const r = raven(1.4); O.scene.add(r); return r; });
  const c = cam(38);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, 0, 0, T, O.waves); crewIdle(O.men.slice(1), t);
      const up = easeOut(range(t, tR - 0.6, tR));
      standPose(floki, t, { rSh: [lerp(0.05, -2.6, up), 0, lerp(-0.2, -0.75, up)], lSh: [lerp(0.05, -2.6, up), 0, lerp(0.2, 0.75, up)], neck: [-0.3 * up, 0, 0], head: [-0.4 * up, 0, 0] }); floki.setMood('happy'); floki.setMouth(0); floki.grip(0.4, 0.4); floki.blink(blinkK(t, [1.1]));
      O.scene.updateMatrixWorld(true);
      const h0 = wpos(floki.j.rWr, V(0, -0.1, 0));
      R.forEach((r, i) => {
        const a = t - tR - i * 0.25;
        r.visible = up > 0.7;
        if (a < 0) { r.position.copy(h0).add(V(0.05, 0.3 + i * 0.12, (i - 1) * 0.25)); r.rotation.set(0, 0, 0.3); r.flap(t, 0.15); return; }
        let p;
        if (i === 0) p = V(h0.x - a * 4, h0.y + 0.3 + a * 2.4, h0.z + a * 2.5);           // back the way they came
        else if (i === 1) p = V(h0.x + 4 * Math.sin(a * 1.5), h0.y + 0.42 + Math.min(1, a) * 1.6 + Math.sin(a) * 0.5, h0.z + 4 * (1 - Math.cos(a * 1.5))); // circles back to the ship
        else p = V(h0.x + a * 6, h0.y + 0.54 + a * 2.2, h0.z - a * 0.5);                 // flies ahead
        const q = (i === 0) ? V(-1, 0.4, 0.3) : (i === 1) ? V(Math.cos(a * 1.5), 0, Math.sin(a * 1.5)) : V(1, 0.35, -0.08);
        r.position.copy(p); r.rotation.set(0, Math.atan2(-q.z, q.x), Math.atan2(q.y, Math.hypot(q.x, q.z)) * 0.6); r.flap(t, 1);
      });
      const fA = easeInOut(range(t, tA - 0.6, tA + 1.0));
      const hd = wpos(floki.j.head, V(0, 0, 0));
      place(c, [hd.x + lerp(-3.5, -4.5, fA), hd.y + lerp(0.2, 1.2, fA), hd.z + lerp(4.5, 3.5, fA)], [hd.x + lerp(0.5, 9, fA), hd.y + lerp(1.0, 4, fA), hd.z + lerp(-0.5, -1, fA)]);
      return { bloom: 0.55, flare: 0.6, warm: 1.0 };
    },
  };
}
// ============ S13: Iceland at sunset, a raven ahead of the ship ============
function sIceland({ makeStage }) {
  const O = ocean(makeStage, { preset: 'golden', sunDir: [0.6, 0.12, -0.79], fog: 0.004 });
  O.scene.add(coast({ x: 20, z: -110, w: 280, h: 40, seed: 11 }));
  const rv = raven(1.6); O.scene.add(rv);
  const c = cam(38);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.ship, 0, -t * 1.2, Math.PI / 2, T, O.waves); crewIdle(O.men, t);
      rv.position.set(Math.sin(t) * 1.5, 10 + Math.sin(t * 2) * 0.3, -14 - t * 1.6); rv.rotation.set(0, Math.PI / 2, 0); rv.flap(t, 1);
      const k = easeInOut(range(t, 0, 5.5));
      place(c, [lerp(-3, -8, k), lerp(4, 9, k), lerp(16, 22, k) - t * 1.2], [0, lerp(7, 9, k), -40 - t * 1.2]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sAlone], [ls(1), ls(2), sFound], [ls(2), ls(3), sSun], [ls(3), ls(4), sNoon], [ls(4), ls(5), sCompass],
  [ls(5), ls(6), sDisc], [ls(6), ls(7), sCloudy], [ls(7), ls(8), sRaise], [ls(8), ls(9), sSpar], [ls(9), ls(10), sHidden],
  [ls(10), ls(11), sWreck], [ls(11), ls(12), sBirds], [ls(12), ls(13), sRavens], [ls(13), DURATION + 1, sIceland],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
