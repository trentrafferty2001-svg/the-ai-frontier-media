// Pyramid ramps reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { shadowAll } from './rome.js';
import { fabricTexture } from './textures.js';
import { desertGround, palm } from './persia.js';
import { pyramid, constructionRamp, quarry, barge, papyrus, sledge, egyptian, waterJar, steepRamp, workerTomb, nile } from './egypt.js';
import { VO } from './vo_py.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you had to', 4], ['stack over', 2], ['*2 million*', 2], ['stone blocks', 2], ['into a *mountain*', 3], ['how would you', 3], ['even *start?*', 2]],
  [['But the *Egyptians*', 3], ['built the', 2], ['*Great Pyramid*', 2], ['with *no cranes*', 3], ['and *no engines*', 3]],
  [['Most of its blocks', 4], ['were cut from', 3], ['*limestone*', 1], ['right next to', 3], ['the *site*', 2]],
  [['*Finer stone*', 2], ['came by *boat*', 3], ['along the *Nile*', 3]],
  [['A *logbook*', 2], ['written by', 2], ['an official', 2], ['named *Merer*', 2], ['describes those *trips*', 3]],
  [['On land', 2], ['the blocks rode', 3], ['on wooden *sledges*', 3]],
  [['A *tomb painting*', 3], ['shows a worker', 3], ['*pouring water*', 2], ['in front of one', 4]],
  [['*Scientists* found', 2], ['that *wet sand*', 3], ['can cut', 2], ['the *pulling force*', 3], ['*in half*', 2]],
  [['To *raise* the blocks', 4], ['they most likely', 3], ['used *ramps*', 2]],
  [['In *2018*', 3], ['*archaeologists*', 1], ['found a', 2], ['*steep ramp*', 2], ['at an', 2], ['*ancient quarry*', 2], ['with *post holes*', 3], ['beside it', 2]],
  [['*Ropes* wrapped', 2], ['around', 1], ['*wooden posts*', 2], ['helped teams', 2], ['*haul* stones', 2], ['up very', 2], ['*steep slopes*', 2]],
  [['*No one knows*', 3], ['exactly which', 2], ['*ramp design*', 2], ['built the', 2], ['*Great Pyramid*', 2]],
  [['And the builders', 3], ['were *not slaves*', 3], ['Their *tombs* show', 3], ['they were', 2], ['*skilled*', 1], ['*respected workers*', 2]],
  [['*4,500 years*', 5], ['later', 1], ['their pyramid', 2], ['*still stands*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: the construction site ============
function site(makeStage, { preset = 'desert', sunDir = [-0.5, 0.55, 0.65], build = 0.55, ramp = true, fog = 0.0025, shadowSize = 40, shadowAt = [0, 4, 20], ...o } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt, envI: 0.9, ...o });
  desertGround(scene, { seed: 3 });
  const P = pyramid(); P.build(build); scene.add(P);
  let Rp = null;
  if (ramp) { const top = P.courseH * Math.round(build * P.levels); Rp = constructionRamp(top / 0.24, 6, top); Rp.rotation.y = Math.PI / 2; Rp.position.set(0, 0, P.base / 2 + top / 0.24 - 0.3); scene.add(Rp); }
  [[-62, 44, 6], [-68, 36, 5], [60, 52, 5.5]].forEach(([x, z, h], i) => { const p = palm(h, i + 5); p.position.set(x, 0, z); scene.add(p); });
  fillLight(scene, [0.3, 0.4, 1], 0.6, 0xffe6c8);
  return { scene, P, Rp };
}
function crew(scene, n, pos0, step, ry, i0 = 0) { return [...Array(n)].map((_, i) => { const e = egyptian(i + i0); e.root.position.set(pos0[0] + step[0] * i, pos0[1] + step[1] * i, pos0[2] + step[2] * i); e.root.rotation.y = ry; scene.add(e.root); return e; }); }
const haul = (e, t, i) => { const w = Math.sin(t * 5 + i); standPose(e, t, { spine: [0.45, 0, 0], chest: [0.15, 0, 0], lSh: [-1.4, 0, 0.1], rSh: [-1.4, 0, -0.1], lEl: [-0.2, 0, 0], rEl: [-0.2, 0, 0], lHip: [-0.3 + w * 0.35, 0, 0.08], rHip: [-0.3 - w * 0.35, 0, -0.08], lKn: [0.3 + Math.max(0, w) * 0.4, 0, 0], rKn: [0.3 + Math.max(0, -w) * 0.4, 0, 0], drop: -0.06 }); e.setMood('happy'); e.setMouth(0); e.grip(0.95, 0.95); };
function ropeLine(scene, len = 10) { const r = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, len, 6), new THREE.MeshStandardMaterial({ color: 0xc8a868, roughness: 0.9 })); r.rotation.z = Math.PI / 2; scene.add(r); return r; }

// ============ S0: aerial over the half-built pyramid ============
function sAerial({ makeStage }) {
  const S = site(makeStage, { build: 0.45, sunDir: [0.5, 0.35, -0.79] });
  const c = cam(40);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const a = lerp(0.9, 0.5, easeInOut(range(t, 0, 5.4)));
      const r = lerp(150, 115, easeInOut(range(t, 0, 5.4)));
      place(c, [Math.sin(a) * r, lerp(70, 50, easeInOut(range(t, 0, 5.4))), Math.cos(a) * r], [0, 4, 10]);
      return { bloom: 0.55, flare: 0.9, warm: 1.25 };
    },
  };
}
// ============ S1: a hauling team drags a block up the ramp, no machines anywhere ============
function sTeam({ makeStage }) {
  const S = site(makeStage, { build: 0.55 });
  const top = S.P.courseH * Math.round(0.55 * S.P.levels); const ang = Math.atan2(top, top / 0.24);
  const sl = sledge(); S.scene.add(sl);
  const men = crew(S.scene, 6, [0, 0, 0], [0, 0, 0], Math.PI, 0);
  const rope = ropeLine(S.scene, 9);
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const d = 40 + t * 0.6; // distance along the ramp from the pyramid face (z decreasing toward the pyramid)
      const z = S.P.base / 2 + d * Math.cos(ang), y = top - d * Math.sin(ang);
      sl.position.set(0, y, z); sl.rotation.set(-ang, Math.PI / 2, 0);
      men.forEach((e, i) => { const dz = 2.6 + (i >> 1) * 1.2; e.root.position.set((i % 2 ? 0.7 : -0.7), y + dz * Math.sin(ang), z - dz * Math.cos(ang)); haul(e, t, i); });
      rope.position.set(0, y + 0.6 + 4.5 * Math.sin(ang), z - 4.5 * Math.cos(ang)); rope.rotation.set(Math.PI / 2 - ang, 0, 0);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(10, 7, k), y + lerp(3, 2.2, k), z + lerp(8, 5, k)], [0, y + 1.2, z - 3]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S2: the quarry right next to the site ============
function sQuarry({ makeStage }) {
  const S = site(makeStage, { build: 0.55, sunDir: [-0.4, 0.6, 0.7] });
  const Q = quarry(); Q.position.set(-40, 0, 30); S.scene.add(Q);
  const men = crew(S.scene, 3, [-37, 1.2, 35.5], [1.8, 0, -0.2], Math.PI, 2);
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      men.forEach((e, i) => { const ch = Math.max(0, Math.sin(t * 6 + i)); standPose(e, t, { spine: [0.5, 0, 0], lSh: [-1.6 + ch, 0, 0.2], rSh: [-1.6 + ch, 0, -0.2], lEl: [-0.3, 0, 0], rEl: [-0.3, 0, 0] }); e.setMood('happy'); e.setMouth(0); e.grip(0.9, 0.9); });
      const k = easeInOut(range(t, 0, 3.8));
      place(c, [lerp(-24, -26, k), lerp(7, 6, k), lerp(52, 49, k)], [-38, lerp(2.5, 2.0, k), lerp(32, 31, k)]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S3: a barge carrying fine stone along the Nile ============
function sNile({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.55, 0.25, -0.8], fog: 0.004, shadowSize: 8, envI: 0.95 });
  desertGround(scene, { seed: 6 });
  nile(scene, { z: 0 });
  const b = barge(); scene.add(b);
  [[-20, 18, 6], [-14, 20, 5], [10, 19, 5.6], [30, -19, 5], [-6, -20, 6]].forEach(([x, z, h], i) => { const p = palm(h, i + 11); p.position.set(x, 0, z); scene.add(p); });
  const P = pyramid(); P.scale.setScalar(0.6); P.position.set(40, 0, -90); scene.add(P);
  const crewB = crew(scene, 2, [0, 0, 0], [0, 0, 0], 0, 1); crewB.forEach(e => b.add(e.root));
  crewB[0].root.position.set(3.6, 0.9, 0.4); crewB[1].root.position.set(-3.6, 0.9, -0.3);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      b.position.set(-6 + t * 1.6, Math.sin(t * 1.3) * 0.05, 0); b.rotation.z = Math.sin(t * 0.9) * 0.015;
      crewB.forEach((e, i) => { standPose(e, t + i, { lSh: [-0.9, 0, 0.3], rSh: [-0.9, 0, -0.3] }); e.setMood('happy'); e.setMouth(0); });
      const k = easeInOut(range(t, 0, 2.8));
      place(c, [b.position.x + lerp(-8, -5, k), lerp(5, 4, k), lerp(17, 14, k)], [b.position.x + 1, 2.0, 0]);
      return { bloom: 0.65, flare: 1.0, warm: 1.3 };
    },
  };
}
// ============ S4: Merer's papyrus logbook ============
function sLog({ makeStage }) {
  const scene = makeStage({ shadowSize: 0.8, sunDir: [-1, 3, 2], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a2016); u.mid.value.set(0x3a2a1c); u.horizon.value.set(0x4a3624); u.floorC.value.set(0x20160e);
  const table = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.7, bumpMap: fabricTexture(5), bumpScale: 2 })); table.rotation.x = -Math.PI / 2; table.receiveShadow = true; scene.add(table);
  const p = papyrus(); p.position.y = 0.01; scene.add(p);
  const lamp = new THREE.PointLight(0xffb060, 3, 3, 2); lamp.position.set(0.6, 0.5, 0.4); scene.add(lamp);
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.3));
      const pos = [lerp(0.35, -0.2, k), lerp(1.1, 0.95, k), lerp(0.75, 0.65, k)], look = [lerp(0.2, -0.15, k), 0, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.3, dof: dofTo(pos, look, 0.008, 0.012) };
    },
  };
}
// ============ S5/S6/S7: the sledge on sand; water poured in front; the pulling force halves ============
function sandStage(makeStage) {
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.5, 0.55, 0.65], fog: 0.004, shadowSize: 6, shadowAt: [0, 0, 0], envI: 0.9 });
  desertGround(scene, { seed: 8 });
  const P = pyramid(); P.build(0.5); P.position.set(-10, 0, -70); scene.add(P);
  return scene;
}
function sSledge({ makeStage }) {
  const scene = sandStage(makeStage);
  const sl = sledge(); scene.add(sl);
  const men = crew(scene, 6, [0, 0, 0], [0, 0, 0], Math.PI / 2, 1);
  const rope = ropeLine(scene, 8);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const x = -4 + t * 0.7; sl.position.set(x, 0, 0);
      men.forEach((e, i) => { e.root.position.set(x + 3 + (i >> 1) * 1.1, 0, i % 2 ? 0.6 : -0.6); haul(e, t, i); });
      rope.position.set(x + 4.3, 0.75, 0);
      const k = easeInOut(range(t, 0, 2.8));
      place(c, [x + lerp(-2, 1, k), lerp(2.0, 1.6, k), lerp(7, 6, k)], [x + 2.2, 0.9, 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
function sPour({ makeStage, start: ST }) {
  const tP = at(6, 'pouring') - ST;
  const scene = sandStage(makeStage);
  const sl = sledge(); scene.add(sl);
  const pourer = egyptian(2); scene.add(pourer.root);
  const jar = waterJar(); scene.add(jar);
  const wet = new THREE.Mesh(new THREE.CircleGeometry(1, 32), new THREE.MeshStandardMaterial({ color: 0x7a5a36, roughness: 0.35, transparent: true, opacity: 0 })); wet.rotation.x = -Math.PI / 2; wet.scale.set(1.4, 0.7, 1); wet.position.set(2.1, 0.004, 0); scene.add(wet);
  const stream = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.02, 1, 8, 1, true), new THREE.MeshStandardMaterial({ color: 0xa8d8f0, transparent: true, opacity: 0.8, roughness: 0.05 })); scene.add(stream);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      sl.position.set(0, 0, 0);
      pourer.root.position.set(2.1, 0.78, -0.2); pourer.root.rotation.y = Math.PI / 2 + 0.5;
      const tilt = easeInOut(range(t, tP - 0.8, tP - 0.2));
      standPose(pourer, t, { spine: [0.2, 0, 0], rSh: [-1.0 - tilt * 0.3, 0, -0.2], rEl: [-0.6, 0, 0], head: [0.5, 0, 0] }); pourer.setMood('happy'); pourer.setMouth(0); pourer.grip(0.3, 0.9);
      scene.updateMatrixWorld(true);
      const hp = wpos(pourer.j.rWr, V(0, -0.12, 0.05)); jar.position.copy(hp); jar.rotation.set(0, 0, -tilt * 1.6);
      const pouring = t > tP - 0.25;
      stream.visible = pouring; if (pouring) { const lip = jar.localToWorld(V(0, 0.22, 0)); stream.position.set(lip.x, lip.y / 2, lip.z); stream.scale.y = lip.y; }
      wet.material.opacity = 0.75 * easeOut(range(t, tP, tP + 1.6)); wet.scale.set(1.4, 0.7, 1).multiplyScalar(0.4 + 0.6 * easeOut(range(t, tP, tP + 2)));
      const k = easeInOut(range(t, 0, 3.8));
      place(c, [lerp(6.5, 5.8, k), lerp(2.4, 2.1, k), lerp(5.5, 4.8, k)], [1.4, 0.9, 0]);
      return { bloom: 0.5, warm: 1.2, dof: dofTo([4.5, 1.6, 3.6], [1.6, 0.8, 0], 0.003, 0.009) };
    },
  };
}
function arrowMesh(color) { const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.7 }); const s = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1, 10), m); s.rotation.z = -Math.PI / 2; s.position.x = 0.5; g.add(s); const h = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.34, 14), m); h.rotation.z = -Math.PI / 2; h.position.x = 1.15; g.add(h); return g; }
function sHalf({ makeStage, start: ST }) {
  const tH = at(7, 'half') - ST, tW = at(7, 'wet') - ST;
  const scene = sandStage(makeStage);
  const sl = sledge(); scene.add(sl);
  const wet = new THREE.Mesh(new THREE.PlaneGeometry(14, 2), new THREE.MeshStandardMaterial({ color: 0x7a5a36, roughness: 0.35, transparent: true, opacity: 0 })); wet.rotation.x = -Math.PI / 2; wet.position.set(5, 0.004, 0); scene.add(wet);
  const ar = arrowMesh(0xffd43b); scene.add(ar);
  const men = crew(scene, 2, [0, 0, 0], [0, 0, 0], Math.PI / 2, 0);
  const rope = ropeLine(scene, 5);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const x = -1 + t * 0.6; sl.position.set(x, 0, 0);
      men.forEach((e, i) => { e.root.position.set(x + 3.2 + i * 1.1, 0, i ? 0.5 : -0.5); haul(e, t, i); });
      rope.position.set(x + 3.4, 0.75, 0);
      wet.material.opacity = 0.75 * easeOut(range(t, tW - 0.3, tW + 0.5));
      const len = lerp(3.2, 1.6, easeInOut(range(t, tH - 0.5, tH + 0.2)));
      ar.position.set(x + 1.6, 2.2, 0); ar.scale.set(len, 1, 1); ar.visible = t > 0.3;
      const k = easeInOut(range(t, 0, 3.9));
      place(c, [x + lerp(1.5, 2.2, k), lerp(2.4, 2.1, k), lerp(7.5, 6.5, k)], [x + 2.2, 1.3, 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S8: ramps against the rising pyramid, teams on them ============
function sRamps({ makeStage }) {
  const S = site(makeStage, { build: 0.6, sunDir: [0.5, 0.45, 0.74] });
  const top = S.P.courseH * Math.round(0.6 * S.P.levels); const ang = Math.atan2(top, top / 0.24);
  const sleds = [0.25, 0.5, 0.75].map(f => { const s = sledge(); const d = f * top / 0.24; s.position.set(0, top - d * Math.sin(ang), S.P.base / 2 + d * Math.cos(ang)); s.rotation.set(-ang, Math.PI / 2, 0); S.scene.add(s); return s; });
  const c = cam(40);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.1));
      place(c, [lerp(-45, -38, k), lerp(22, 26, k), lerp(62, 56, k)], [0, lerp(6, 8, k), lerp(26, 22, k)]);
      return { bloom: 0.55, flare: 0.8, warm: 1.2 };
    },
  };
}
// ============ S9/S10: the steep quarry ramp with posts; ropes around the posts ============
function steepStage(makeStage) {
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.4, 0.7, 0.6], fog: 0.003, shadowSize: 10, shadowAt: [6, 2, 0], envI: 0.9 });
  desertGround(scene, { seed: 10 });
  const R = steepRamp(); scene.add(R);
  return { scene, R };
}
function sSteep({ makeStage }) {
  const { scene, R } = steepStage(makeStage);
  const sl = sledge(); R.slope.add(sl);
  const men = crew(scene, 4, [0, 0, 0], [0, 0, 0], 0, 0); men.forEach(e => R.slope.add(e.root));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const x = 2 + t * 0.35; sl.position.set(x, 0, 0);
      men.forEach((e, i) => { e.root.position.set(x + 2.2 + (i >> 1) * 1.0, 0, i % 2 ? 0.6 : -0.6); e.root.rotation.y = Math.PI / 2; haul(e, t, i); });
      const k = easeInOut(range(t, 0, 6.0));
      place(c, [lerp(-6, -3, k), lerp(4, 5.5, k), lerp(9, 7, k)], [lerp(4, 7, k), lerp(1, 2.2, k), 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
function sPost({ makeStage }) {
  const { scene, R } = steepStage(makeStage);
  const post = R.posts[2]; scene.updateMatrixWorld(true);
  const pp = post.getWorldPosition(V(0, 0, 0));
  const coil = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.03, 8, 24), new THREE.MeshStandardMaterial({ color: 0xc8a868, roughness: 0.9 })); coil.rotation.x = Math.PI / 2; coil.position.copy(pp).add(V(0, 0.2, 0)); scene.add(coil);
  const coil2 = coil.clone(); coil2.position.y += 0.08; scene.add(coil2);
  const ropeA = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 6, 6), coil.material); scene.add(ropeA);
  const man = egyptian(1); scene.add(man.root);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      ropeA.position.copy(pp).add(V(-2.8, 0.25, -0.4)); ropeA.rotation.set(0, 0.15, Math.PI / 2 - 0.2);
      man.root.position.copy(pp).add(V(-1.8, -0.4, -1.1)); man.root.rotation.y = -Math.PI / 2 + 0.3; haul(man, t, 0);
      coil.rotation.z = t * 0.5; coil2.rotation.z = -t * 0.4;
      const k = easeInOut(range(t, 0, 4.6));
      const pos = [pp.x + lerp(2.2, 1.6, k), pp.y + lerp(1.4, 1.0, k), pp.z + lerp(2.4, 1.8, k)];
      place(c, pos, [pp.x, pp.y + 0.3, pp.z]);
      return { bloom: 0.5, warm: 1.2, dof: dofTo(pos, [pp.x, pp.y + 0.3, pp.z], 0.004, 0.01) };
    },
  };
}
// ============ S11: which ramp? straight, zig-zag and spiral options appear as glowing outlines ============
function sWhich({ makeStage, start: ST }) {
  const S = site(makeStage, { build: 0.7, ramp: false, sunDir: [-0.5, 0.5, 0.7] });
  const top = S.P.courseH * Math.round(0.7 * S.P.levels), half = S.P.base / 2;
  const mk = (pts, color) => { const curve = new THREE.CatmullRomCurve3(pts.map(p => V(...p)), false, 'catmullrom', 0); const m = new THREE.Mesh(new THREE.TubeGeometry(curve, 200, 0.6, 8), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0, depthWrite: false })); S.scene.add(m); return m; };
  const straight = mk([[0, 0, half + top / 0.2], [0, top, half]], 0xffd43b);
  const zig = mk([[half + 0.5, 0, half * 0.8], [half + 0.5, top * 0.33, -half * 0.6], [half * 0.7, top * 0.33, -half * 0.7], [half * 0.7, top * 0.66, half * 0.5], [half * 0.4, top, half * 0.4]], 0x6fd0ff);
  const sp = []; for (let i = 0; i <= 64; i++) { const u = i / 64, a = u * Math.PI * 3, r = half * (1 - u * 0.7) + 1; sp.push([Math.sin(a) * r, u * top, Math.cos(a) * r]); }
  const spiral = mk(sp, 0xff7a6a);
  const c = cam(40);
  return {
    scene: S.scene, camera: c,
    update(t) {
      [straight, zig, spiral].forEach((m, i) => { m.material.opacity = 0.85 * easeOut(range(t, 0.4 + i * 0.9, 1.0 + i * 0.9)); });
      const a = lerp(0.7, 1.2, easeInOut(range(t, 0, 4)));
      place(c, [Math.sin(a) * 115, 52, Math.cos(a) * 115], [0, 8, 0]);
      return { bloom: 0.7, warm: 1.1 };
    },
  };
}
// ============ S12: the workers' tombs, the builders standing proud ============
function sTombs({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.5, 0.3, -0.81], fog: 0.003, shadowSize: 8, shadowAt: [0, 0, 0], envI: 0.95 });
  desertGround(scene, { seed: 12 });
  [[-4, -2, 0.1], [3.5, -4, -0.2], [-1, -9, 0], [6, -11, 0.2]].forEach(([x, z, ry]) => { const t = workerTomb(); t.position.set(x, 0, z); t.rotation.y = ry; scene.add(t); });
  const P = pyramid(); P.casing(1); P.position.set(10, 0, -120); scene.add(P);
  const men = crew(scene, 3, [-1.6, 0, 2.2], [1.6, 0, 0.2], 0, 0);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      men.forEach((e, i) => { standPose(e, t + i, { lSh: [0.05, 0, 0.35], rSh: [0.05, 0, -0.35], head: [-0.05, (i - 1) * 0.2, 0] }); e.setMood('happy'); e.setMouth(0); e.blink(blinkK(t + i, [1.3, 3.5])); });
      const k = easeInOut(range(t, 0, 4.9));
      place(c, [lerp(0.5, 1.5, k), lerp(1.7, 2.6, k), lerp(7.5, 10, k)], [0, lerp(1.4, 2.0, k), -3]);
      return { bloom: 0.6, flare: 0.9, warm: 1.3 };
    },
  };
}
// ============ S13: the finished, cased pyramid at sunset ============
function sEnd({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.12, -0.79], fog: 0.0025, shadowSize: 50, shadowAt: [0, 10, 0], envI: 0.95 });
  desertGround(scene, { seed: 14 });
  const P = pyramid(); P.casing(1); scene.add(P);
  const P2 = pyramid({ base: 36, levels: 16 }); P2.casing(1); P2.position.set(-55, 0, -50); scene.add(P2);
  const P3 = pyramid({ base: 20, levels: 10 }); P3.casing(1); P3.position.set(-85, 0, -90); scene.add(P3);
  const b = birds(4, { from: [-40, 30, 20], to: [40, 34, 10], spread: 6, speed: 0.05, scale: 2.0, seed: 6 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(30, 42, k), lerp(6, 12, k), lerp(70, 85, k)], [lerp(-6, -12, k), lerp(16, 18, k), lerp(-8, -14, k)]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sAerial], [ls(1), ls(2), sTeam], [ls(2), ls(3), sQuarry], [ls(3), ls(4), sNile], [ls(4), ls(5), sLog],
  [ls(5), ls(6), sSledge], [ls(6), ls(7), sPour], [ls(7), ls(8), sHalf], [ls(8), ls(9), sRamps], [ls(9), ls(10), sSteep],
  [ls(10), ls(11), sPost], [ls(11), ls(12), sWhich], [ls(12), ls(13), sTombs], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
