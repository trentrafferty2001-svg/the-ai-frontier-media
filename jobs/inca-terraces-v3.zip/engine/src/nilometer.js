// Nilometer reel: stone pit with a marble column marked in cubits, tunnels to the river, Roda-style building with a
// conical roof, Nile valley with flood + fields + village, grain sacks, lantern boats, staircase nilometer.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex } from './rome.js';
import { waterMaterial } from './world.js';
import { persiaMats, palm } from './persia.js';

export const CUB = 0.52;          // one cubit in metres
export const BASE = -11;          // pit floor
export const COL0 = -10.6;        // column foot
export const lvl = (c) => COL0 + c * CUB; // water height for a reading in cubits
export const PIT = 2.6;           // pit half width (inside)
export const RIVZ = 9;            // river starts at this z

let NM = null;
export function nmMats() {
  if (NM) return NM;
  const stone = canvasTex(256, 256, (x) => {
    x.fillStyle = '#c9ad7e'; x.fillRect(0, 0, 256, 256); const R = rng(7);
    for (let i = 0; i < 400; i++) { x.fillStyle = `rgba(${120 + R() * 60},${90 + R() * 40},${50 + R() * 30},${R() * 0.15})`; x.fillRect(R() * 256, R() * 256, 2 + R() * 8, 2 + R() * 8); }
    x.strokeStyle = 'rgba(90,65,35,0.55)'; x.lineWidth = 2;
    for (let r = 0; r < 4; r++) { x.beginPath(); x.moveTo(0, r * 64); x.lineTo(256, r * 64); x.stroke(); for (let c = 0; c < 3; c++) { const cx = (c * 96 + (r % 2) * 48) % 256; x.beginPath(); x.moveTo(cx, r * 64); x.lineTo(cx, r * 64 + 64); x.stroke(); } }
  }, [2, 4]);
  const earth = canvasTex(256, 256, (x) => {
    const R = rng(5); for (let i = 0; i < 16; i++) { x.fillStyle = ['#6a4a2c', '#5a3e24', '#7a5a36', '#4a3420'][i % 4]; x.fillRect(0, i * 16, 256, 16); }
    for (let i = 0; i < 300; i++) { x.fillStyle = `rgba(30,20,10,${R() * 0.25})`; x.beginPath(); x.arc(R() * 256, R() * 256, 1 + R() * 4, 0, 7); x.fill(); }
  }, [3, 2]);
  const marble = canvasTex(128, 512, (x) => {
    x.fillStyle = '#f2eee6'; x.fillRect(0, 0, 128, 512); const R = rng(9);
    x.strokeStyle = 'rgba(150,150,160,0.35)'; for (let i = 0; i < 14; i++) { x.beginPath(); let px = R() * 128, py = R() * 512; x.moveTo(px, py); for (let k = 0; k < 6; k++) { px += (R() - 0.5) * 40; py += R() * 40; x.lineTo(px, py); } x.stroke(); }
  });
  NM = {
    stone: new THREE.MeshStandardMaterial({ map: stone, roughness: 0.9, bumpMap: stone, bumpScale: 3 }),
    earth: new THREE.MeshStandardMaterial({ map: earth, roughness: 1 }),
    top: new THREE.MeshStandardMaterial({ color: 0xa8875a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 }),
    marble,
    water: new THREE.MeshStandardMaterial({ color: 0x2f6a78, roughness: 0.15, transparent: true, opacity: 0.82, emissive: 0x0a2a34, emissiveIntensity: 0.3 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x1a1410, roughness: 1 }),
  };
  return NM;
}

// marble column: octagonal shaft with cubit marks; c16 = glow uniform for the 16 mark
export function column() {
  const M = nmMats();
  const H = 19 * CUB + 0.2;
  const tex = canvasTex(256, 1024, (x) => {
    x.drawImage(M.marble.image, 0, 0, 256, 1024);
    for (let c = 0; c <= 19; c++) {
      const y = 1024 - (c * CUB + 0.1) / H * 1024;
      x.fillStyle = c === 16 ? '#c8901a' : '#3a2c22'; x.fillRect(0, y - (c === 16 ? 5 : 2.5), 256, c === 16 ? 10 : 5);
      for (let h = 1; h < 4; h++) { const yh = y - h * CUB / H * 1024 / 4; if (c < 19) x.fillRect(0, yh - 1, h === 2 ? 70 : 40, 2); }
      if (c > 0) { x.font = 'bold 34px Poppins, sans-serif'; x.textAlign = 'center'; x.fillStyle = c === 16 ? '#b07a10' : '#3a2c22'; for (const cx of [32, 160]) x.fillText(String(c), cx, y + 36); }
    }
  });
  tex.wrapS = THREE.RepeatWrapping; tex.repeat.set(2, 1);
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.35, emissive: 0xffb030, emissiveIntensity: 0 });
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, H, 8, 1), mat); shaft.position.y = H / 2; g.add(shaft);
  const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.0, 0.4, 24), new THREE.MeshStandardMaterial({ color: 0x8a8070, roughness: 0.8 })); foot.position.y = -0.2; g.add(foot);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.44, 0.5, 8), new THREE.MeshStandardMaterial({ map: M.marble, roughness: 0.4 })); cap.position.y = H + 0.25; g.add(cap);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.47, 0.035, 8, 8), new THREE.MeshStandardMaterial({ color: 0xffc040, emissive: 0xffa020, emissiveIntensity: 0 })); ring.rotation.x = Math.PI / 2; ring.rotation.z = Math.PI / 8; ring.position.y = 16 * CUB + 0.1; g.add(ring);
  g.glow = (k) => { ring.material.emissiveIntensity = 3 * k; ring.scale.setScalar(1 + 0.15 * k); };
  g.H = H; g.position.y = COL0 - 0.1;
  return shadowAll(g);
}

// the pit + column + stairs + tunnels + river; cut=true slices everything at x=0 to show the inside
export function nilometer(scene, { cut = false, building = true, riverLen = 300 } = {}) {
  const M = nmMats(); const g = new THREE.Group(); scene.add(g);
  const X1 = cut ? 0 : 40; const X0 = -40;
  const box = (x0, x1, y0, y1, z0, z1, mat) => { if (x1 <= x0) return null; const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0), mat === M.earth ? [M.earth, M.earth, M.top, M.earth, M.earth, M.earth] : mat); m.position.set((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2); m.castShadow = m.receiveShadow = true; g.add(m); return m; };
  const W = PIT, T = 0.7; // inner half width, lining thickness
  // earth: behind, left/right, below, and the bank between pit and river (sliced into layers around 3 tunnels)
  box(X0, X1, BASE - 3, 0, -40, -W - T, M.earth);
  box(X0, Math.min(X1, -W - T), BASE - 3, 0, -W - T, RIVZ, M.earth);
  if (!cut) box(W + T, X1, BASE - 3, 0, -W - T, RIVZ, M.earth);
  box(X0, X1, BASE - 3, BASE - 0.4, -W - T, RIVZ, M.earth);
  const TUN = [lvl(3), lvl(8), lvl(13)]; const th = 0.9;
  let y = BASE - 0.4; const layers = [];
  for (const ty of TUN) { layers.push([y, ty - th / 2]); y = ty + th / 2; } layers.push([y, 0]);
  for (const [a, b] of layers) box(-W - T, Math.min(X1, W + T), a, b, W + T, RIVZ, M.earth);
  // stone lining around the pit (4 walls) with a low parapet, and the floor
  box(-W - T, Math.min(X1, W + T), BASE - 0.4, 0.5, -W - T, -W, M.stone);
  box(-W - T, -W, BASE - 0.4, 0.5, -W, W, M.stone);
  if (!cut) box(W, W + T, BASE - 0.4, 0.5, -W, W, M.stone);
  for (const [a, b] of layers) box(-W - T, Math.min(X1, W + T), Math.max(a, BASE - 0.4), b, W, W + T, M.stone);
  box(-W - T, Math.min(X1, W + T), 0, 0.5, W, W + T, M.stone);
  box(-W, Math.min(X1, W), BASE - 0.4, BASE, -W, W, M.stone);
  // tunnel water channels (dark slots with flowing water inside)
  const tunnels = TUN.map(ty => { const m = box(-0.55, Math.min(X1, 0.55), ty - th / 2, ty + th / 2, W, RIVZ + 0.1, M.dark); return ty; });
  // stairs down the back and left walls
  const steps = new THREE.Group(); g.add(steps);
  const N = 30;
  for (let i = 0; i < N; i++) {
    const yy = -0.25 - i * (-(BASE) - 0.3) / N; const s = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.22, 0.9), M.stone);
    const u = i / (N - 1); // along back wall from +x to -x, then down left wall toward +z
    if (u < 0.5) s.position.set(Math.min(W - 0.45, cut ? -0.45 : W - 0.45) - (u / 0.5) * (cut ? W - 0.9 : 2 * W - 0.9), yy, -W + 0.45);
    else s.position.set(-W + 0.45, yy, -W + 0.45 + ((u - 0.5) / 0.5) * (2 * W - 0.9));
    s.castShadow = s.receiveShadow = true; steps.add(s);
  }
  // column
  const C = column(); g.add(C);
  // pit water (box from floor to level)
  const pw = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), M.water); g.add(pw);
  const pwTop = new THREE.Mesh(new THREE.PlaneGeometry(2 * W, 2 * W), waterMaterial({ color: 0x2f5a5a, opacity: 0.9, ripple: 0.6 })); pwTop.rotation.x = -Math.PI / 2; g.add(pwTop);
  // river: bed, side water box (for the cut view) and a big rippling surface
  box(X0 - 200, X1 + 200, BASE - 3, BASE - 2, RIVZ, 80, M.earth);
  const rw = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), M.water); g.add(rw);
  const rTop = new THREE.Mesh(new THREE.PlaneGeometry(riverLen, 160), waterMaterial({ color: 0x2f5a5a, opacity: 0.97, ripple: 1.3 })); rTop.rotation.x = -Math.PI / 2; g.add(rTop);
  const far = new THREE.Mesh(new THREE.PlaneGeometry(riverLen, 60), new THREE.MeshStandardMaterial({ color: 0x5a7a34, roughness: 1 })); far.rotation.x = -Math.PI / 2; far.position.set(0, 0.3, RIVZ + 120); g.add(far);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(riverLen, 120), new THREE.MeshStandardMaterial({ color: 0xa8875a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); ground.rotation.x = -Math.PI / 2; ground.position.set(0, 0.0, -W - T - 60 + 0.01); ground.receiveShadow = true; if (cut) ground.visible = false; g.add(ground);
  const tw = TUN.map(ty => { const m = new THREE.Mesh(new THREE.BoxGeometry(cut ? 0.55 : 1.1, th - 0.1, RIVZ - W), M.water); m.position.set(cut ? -0.275 : 0, ty, (W + RIVZ) / 2); g.add(m); return m; });
  // flow sprites inside the tunnels
  const flow = [];
  // the house over the pit: square walls with arched windows + conical roof
  const house = new THREE.Group(); g.add(house);
  if (building) {
    const P = persiaMats(); const hw = W + T + 0.3, hh = 4.2;
    for (const [px, pz, rx] of [[0, -hw, 0], [0, hw, 0], [-hw, 0, 1], [hw, 0, 1]]) {
      const wall = new THREE.Mesh(new THREE.BoxGeometry(2 * hw + 0.6, hh, 0.6), M.stone); wall.position.set(px, 0.5 + hh / 2, pz); wall.rotation.y = rx * Math.PI / 2; house.add(wall);
      for (const o of [-1.4, 1.4]) { const win = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 1.5), M.dark); win.position.set(px + (rx ? Math.sign(px) * 0.31 : o), 2.7, pz + (rx ? o : Math.sign(pz) * 0.31)); win.rotation.y = rx ? Math.sign(px) * Math.PI / 2 : (pz < 0 ? Math.PI : 0); house.add(win); }
    }
    const roof = new THREE.Mesh(new THREE.ConeGeometry(hw * 1.45, 5.5, 4, 1), new THREE.MeshStandardMaterial({ color: 0x8a8a84, roughness: 0.6, metalness: 0.2, flatShading: true })); roof.rotation.y = Math.PI / 4; roof.position.y = 0.5 + hh + 2.75; house.add(roof);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.25, 12, 8), new THREE.MeshStandardMaterial({ color: 0xd8b040, metalness: 0.7, roughness: 0.3 })); tip.position.y = 0.5 + hh + 5.6; house.add(tip);
    house.roof = roof; house.tip = tip; shadowAll(house);
  }
  const sc = scene;
  g.set = (c, t = 0, { flowOn = false } = {}) => {
    const h = lvl(c);
    pw.scale.set(cut ? W : 2 * W, h - BASE, 2 * W); pw.position.set(cut ? -W / 2 : 0, (h + BASE) / 2, 0);
    pwTop.position.set(0, h, 0); pwTop.scale.x = cut ? 0.5 : 1; pwTop.position.x = cut ? -W / 2 : 0;
    rw.scale.set(cut ? 120 : 240, h - BASE + 2, 160); rw.position.set(cut ? -60 : 0, (h + BASE - 2) / 2, RIVZ + 80);
    rTop.position.set(0, h + 0.01, RIVZ + 80); rTop.visible = true;
    tw.forEach((m, i) => { m.visible = h > TUN[i] - th / 2 + 0.05; });
    flow.forEach(f => f.visible = false);
  };
  g.column = C; g.house = house; g.steps = steps; g.tunnels = TUN; g.W = W;
  g.set(6);
  return g;
}

// Nile valley: desert sides, green fields, river, flood water that can rise over the fields; village of mud houses
export function valley(scene, { seed = 3 } = {}) {
  const P = persiaMats(); const R = rng(seed); const g = new THREE.Group(); scene.add(g);
  const sand = new THREE.Mesh(new THREE.PlaneGeometry(900, 900), P.sand); sand.rotation.x = -Math.PI / 2; sand.position.y = -0.05; sand.receiveShadow = true; g.add(sand);
  const fieldM = new THREE.MeshStandardMaterial({ color: 0x5a9a2a, roughness: 0.9, bumpMap: fabricTexture(11), bumpScale: 3 });
  const fields = [];
  for (let i = 0; i < 24; i++) { const f = new THREE.Mesh(new THREE.PlaneGeometry(8.5, 6.5), fieldM); f.rotation.x = -Math.PI / 2; f.position.set(-30 + (i % 6) * 10 + (R() - 0.5), 0.02, -6 - Math.floor(i / 6) * 8); f.receiveShadow = true; g.add(f); fields.push(f); }
  const river = new THREE.Mesh(new THREE.PlaneGeometry(900, 26), waterMaterial({ color: 0x2f5a5a, opacity: 1, ripple: 1.4 })); river.rotation.x = -Math.PI / 2; river.position.set(0, 0.02, 16); g.add(river);
  const bankM = new THREE.MeshStandardMaterial({ color: 0x6a5232, roughness: 1 });
  const bank = new THREE.Mesh(new THREE.PlaneGeometry(900, 3), bankM); bank.rotation.x = -Math.PI / 2 + 0.3; bank.position.set(0, -0.3, 2.4); bank.visible = false; g.add(bank);
  const flood = new THREE.Mesh(new THREE.PlaneGeometry(900, 70), waterMaterial({ color: 0x5a4a32, opacity: 0.93, ripple: 1.0 })); flood.rotation.x = -Math.PI / 2; flood.position.set(0, -0.1, -18); g.add(flood);
  const houses = new THREE.Group(); g.add(houses);
  for (let i = 0; i < 9; i++) { const w = 2 + R() * 1.6, h = 1.8 + R() * 1.2; const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w * (0.8 + R() * 0.3)), P.mud); b.position.set(14 + (i % 3) * 3.4 + R(), h / 2, -4 - Math.floor(i / 3) * 3.6 + R()); houses.add(b); }
  shadowAll(houses);
  [[-12, -3, 6], [8, -2, 5.5], [-26, -30, 6.5], [30, -12, 5], [3, -36, 6]].forEach(([x, z, h], i) => { const p = palm(h, i + 21); p.position.set(x, 0, z); g.add(p); });
  const green = new THREE.Color(0x5a9a2a), mud = new THREE.Color(0x2a2016), dry = new THREE.Color(0xb09060);
  // flood k: 0 normal, 1 fields covered; state: 'green' | 'mud' | 'dry'; f2 >1 water over houses
  g.set = ({ flood: k = 0, field = 0, dryK = 0, high = 0 } = {}) => {
    flood.position.y = lerpN(-0.1, 0.12, k) + high * 1.4;
    fieldM.color.copy(green).lerp(mud, field).lerp(dry, dryK);
    river.position.y = 0.02 + k * 0.1 + high * 1.4;
  };
  g.fields = fields; g.houses = houses;
  return g;
}
const lerpN = (a, b, k) => a + (b - a) * k;

// grain sacks pile (n visible)
export function sacks(n = 20, seed = 5) {
  const R = rng(seed); const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0xc8b080, roughness: 1, bumpMap: fabricTexture(5), bumpScale: 2 });
  const list = [];
  for (let i = 0; i < n; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 10), m); s.scale.set(1, 1.25, 0.85); const row = Math.floor(i / 5), col = i % 5; s.position.set(col * 0.62 - 1.24 + row * 0.12, 0.38 + row * 0.55, (R() - 0.5) * 0.2 - row * 0.15); g.add(s); list.push(s); }
  g.show = (k) => list.forEach((s, i) => { const v = Math.min(1, Math.max(0, k * n - i)); s.visible = v > 0; s.scale.set(v, 1.25 * v, 0.85 * v); });
  return shadowAll(g), g;
}
// papyrus scroll for the official
export function scroll() {
  const tex = canvasTex(256, 128, (x) => { x.fillStyle = '#e8d8a8'; x.fillRect(0, 0, 256, 128); x.strokeStyle = '#4a3020'; x.lineWidth = 3; for (let i = 0; i < 6; i++) { x.beginPath(); x.moveTo(20, 20 + i * 17); x.lineTo(150 + (i * 37) % 80, 20 + i * 17); x.stroke(); } x.font = 'bold 40px Poppins'; x.fillStyle = '#8a2010'; x.fillText('16', 190, 80); });
  const g = new THREE.Group();
  const s = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.26), new THREE.MeshStandardMaterial({ map: tex, side: THREE.DoubleSide })); g.add(s);
  for (const e of [-0.25, 0.25]) { const r = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.3, 8), new THREE.MeshStandardMaterial({ color: 0xc8b078 })); r.position.x = e; g.add(r); }
  return g;
}
// small felucca-style boat with a lantern
export function boat(seed = 1) {
  const g = new THREE.Group(); const wood = new THREE.MeshStandardMaterial({ color: 0x6a4a2a, roughness: 0.9 });
  const hull = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.4, 4, 10, 1, false, 0, Math.PI), wood); hull.rotation.set(0, 0, Math.PI / 2); hull.rotation.x = Math.PI / 2; hull.rotation.z = Math.PI / 2; hull.scale.set(1, 1, 0.8); g.add(hull);
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 4.5, 6), wood); mast.position.y = 2.2; g.add(mast);
  const sail = new THREE.Mesh(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0.6, 0), new THREE.Vector3(0, 4.6, -0.2), new THREE.Vector3(0, 0.8, 2.2)]), new THREE.MeshStandardMaterial({ color: 0xf2ece0, side: THREE.DoubleSide, roughness: 0.9 })); sail.geometry.computeVertexNormals(); g.add(sail);
  return shadowAll(g);
}
// staircase nilometer on a river bank (Elephantine style): steps down into the water with marks on the side wall
export function stairNilometer() {
  const M = nmMats(); const g = new THREE.Group();
  for (let i = 0; i < 12; i++) { const s = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.5 - i * 0.2, 0.55), M.stone); s.position.set(0, (1.5 - i * 0.2) / 2 - 0.3, i * 0.55); g.add(s); }
  const wall = new THREE.Mesh(new THREE.BoxGeometry(0.5, 2.6, 6.8), M.stone); wall.position.set(-1.05, 0.7, 3.0); g.add(wall);
  for (let i = 0; i < 9; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.07, 0.4), new THREE.MeshStandardMaterial({ color: 0x3a2a1a })); m.position.set(-0.79, 1.6 - i * 0.22, 0.4 + i * 0.6); g.add(m); }
  return shadowAll(g);
}
