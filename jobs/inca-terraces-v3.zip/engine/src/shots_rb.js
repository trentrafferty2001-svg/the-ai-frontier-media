// Inca rope bridge reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK, STAND } from './shots4.js';
import { birds, mist } from './world.js';
import { splash2 } from './farm2.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake, ikArm } from './anim.js';
import { shadowAll } from './rome.js';
import { andesMats, gorge, ichuTufts, anchor, ropeBridge, twisted, grassBundle, quechua, horseAndRider } from './andes.js';
import { VO } from './vo_rb.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you had to', 4], ['cross a *canyon*', 3], ['with no *steel*', 3], ['and no *wood*', 3], ['how would', 2], ['you do it?', 3]],
  [['The *Incas*', 2], ['did it', 2], ['with *grass*', 2]],
  [['They built', 2], ['around *200*', 3], ['*rope bridges*', 2], ['across the *Andes*', 3]],
  [['And one of them', 4], ['is still *rebuilt*', 3], ['*by hand*', 2], ['every single *year*', 3]],
  [["It's called", 2], ["*Q'eswachaka*", 1], ['and it hangs', 3], ['over the', 2], ['*Apurímac River*', 2], ['in *Peru*', 2]],
  [['Each *June*', 2], ['four *Quechua*', 2], ['*communities*', 1], ['gather', 1], ['to *rebuild* it', 3]],
  [['They *twist*', 2], ['a local grass', 3], ['called *ichu*', 2], ['into thin *cords*', 3]],
  [['The cords', 2], ['are *braided*', 2], ['into thick *ropes*', 3], ['then into', 2], ['huge *cables*', 2]],
  [['The cables', 2], ['are *stretched*', 2], ['across the *gorge*', 3], ['and tied to', 3], ['*stone anchors*', 2]],
  [['*Bridge masters*', 2], ['hang over', 2], ['the river', 2], ['to *weave*', 2], ['the *floor*', 2], ['and *handrails*', 2]],
  [['The *old bridge*', 3], ['is *cut loose*', 3], ['and it *falls*', 3], ['into the river', 3]],
  [['In about', 2], ['*3 days*', 2], ['a *28-meter*', 4], ['bridge', 1], ['is *finished*', 2]],
  [['Bridges like this', 3], ['once carried', 2], ['*Spanish soldiers*', 2], ['on *horseback*', 2]],
  [['Today', 1], ['*UNESCO* honors', 2], ['the *skills*', 2], ['behind it', 2], ['passed down', 2], ['for over', 2], ['*500 years*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: the gorge site ============
function site(makeStage, { preset = 'andes', sunDir = [-0.5, 0.6, 0.6], bridge = true, tufts = true, fog = 0.003, shadowSize = 22, shadowAt = [0, -4, 0], ...o } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt, envI: 0.9, cloud: 0.4, ...o });
  const G = gorge(scene, {});
  for (const s of [-1, 1]) { const a = anchor(s); a.position.set(s * 15.6, 0, 0); scene.add(a); }
  if (tufts) { const sp = []; for (let i = 0; i < 160; i++) { const s = i % 2 ? 1 : -1; const x = s * (14.6 + (i * 0.37 % 1) * 10), z = ((i * 0.618) % 1 - 0.5) * 26; if (Math.abs(z) < 2 && Math.abs(x) < 18) continue; sp.push([x, 0, z]); } scene.add(ichuTufts(sp, { h: 0.6 })); }
  let B = null; if (bridge) { B = ropeBridge(); scene.add(B); }
  const m = mist(120, 40, { y: -14, opacity: 0.12, color: 0xffffff, scale: 0.05 }); scene.add(m);
  const b = birds(3, { from: [-40, 6, -20], to: [40, 9, -30], spread: 5, speed: 0.05, scale: 1.4, seed: 5 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  fillLight(scene, [0.4, 0.5, 1], 0.6);
  return { scene, B, G };
}
function crowd(scene, list, pose = {}) {
  return list.map(([x, z, ry], i) => { const p = quechua(i); p.root.position.set(x, 0, z); p.root.rotation.y = ry; scene.add(p.root); return p; });
}

// ============ S0: a lone figure at the edge of the gorge, no bridge ============
function sEdge({ makeStage }) {
  const S = site(makeStage, { bridge: false, sunDir: [0.5, 0.45, -0.75] });
  const p = quechua(0); p.root.position.set(-14.8, 0, 3.4); p.root.rotation.y = Math.PI / 2; S.scene.add(p.root);
  const c = cam(40);
  return {
    scene: S.scene, camera: c,
    update(t) {
      standPose(p, t, { head: [0.35, 0, 0], neck: [0.2, 0, 0] }); p.setMood('happy'); p.setMouth(0); p.blink(blinkK(t, [1.5, 3.4]));
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-18.2, -17.6, k), lerp(2.0, 3.6, k), lerp(5.6, 6.4, k)], [lerp(-14, -6, k), lerp(1.1, -6, k), lerp(3.2, 2, k)]);
      return { bloom: 0.5, flare: 0.8, warm: 1.15 };
    },
  };
}
// ============ S1: golden ichu grass swaying in the wind ============
function sGrass({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.4, 0.2, -0.9], fog: 0.004, shadowSize: 1.5, envI: 0.95 });
  const G = gorge(scene, {});
  const sp = []; for (let i = 0; i < 260; i++) sp.push([-15 - (i * 0.37 % 1) * 4, 0, ((i * 0.618) % 1 - 0.5) * 6]);
  scene.add(ichuTufts(sp, { h: 0.7 }));
  const B = ropeBridge(); scene.add(B);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 2.1));
      const pos = [lerp(-18.6, -18.2, k), 0.55, lerp(1.6, 0.6, k)], look = [lerp(-16.5, -14, k), lerp(0.5, 0.2, k), lerp(0.2, 0, k)];
      place(c, pos, look);
      return { bloom: 0.7, flare: 1.0, warm: 1.3, dof: dofTo(pos, [-16.8, 0.5, 0.2], 0.01, 0.014) };
    },
  };
}
// ============ S2: aerial over the Andes, the bridge far below ============
function sAerial({ makeStage }) {
  const S = site(makeStage, { sunDir: [-0.6, 0.5, 0.6], shadowSize: 40 });
  const c = cam(42);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-40, -26, k), lerp(42, 26, k), lerp(46, 30, k)], [lerp(-2, 0, k), lerp(-8, -4, k), 0]);
      return { bloom: 0.5, warm: 1.05 };
    },
  };
}
// ============ S3: people at both ends working on the bridge ============
function sWork({ makeStage, start: ST }) {
  const S = site(makeStage, { sunDir: [-0.5, 0.6, 0.6], shadowSize: 10, shadowAt: [-14, 0, 0] });
  S.B.set({ floor: 0.6, sides: 0.4 });
  const P = crowd(S.scene, [[-16.5, 1.8, 1.2], [-17.5, -1.6, 1.9], [-18.8, 0.5, 1.6], [-16.0, -2.4, 2.4], [16.5, 1.2, -1.7], [17.6, -1.4, -1.3]]);
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      P.forEach((p, i) => { const pull = Math.sin(t * 2.2 + i) * 0.5 + 0.5; standPose(p, t + i, { spine: [0.2 + pull * 0.15, 0, 0], lSh: [-1.0 - pull * 0.3, 0, 0.2], rSh: [-1.0 - pull * 0.3, 0, -0.2], lEl: [-0.4, 0, 0], rEl: [-0.4, 0, 0] }); p.setMood('happy'); p.setMouth(0); p.grip(0.9, 0.9); });
      const k = easeInOut(range(t, 0, 3.7));
      place(c, [lerp(-24, -23, k), lerp(4.5, 3.6, k), lerp(9, 6.5, k)], [lerp(-15, -13, k), 0.5, 0]);
      return { bloom: 0.5, warm: 1.1 };
    },
  };
}
// ============ S4: low angle from the river up at the bridge ============
function sBelow({ makeStage }) {
  const S = site(makeStage, { sunDir: [0.3, 0.75, -0.5], shadowSize: 30, tufts: false });
  const c = cam(62);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-4.0, -5.0, k), lerp(-23.5, -21.5, k), lerp(9, 5, k)], [lerp(4.5, 3, k), lerp(-5, -2, k), 0], lerp(-0.12, 0.0, k));
      return { bloom: 0.6, flare: 0.8, warm: 1.0 };
    },
  };
}
// ============ S5: people walk along the plateau carrying grass bundles ============
function sGather({ makeStage }) {
  const S = site(makeStage, { sunDir: [-0.45, 0.4, -0.8], bridge: true, shadowSize: 8, shadowAt: [-22, 0, 4] });
  S.B.set({ cables: 0, rails: 0, floor: 0, sides: 0 });
  const people = [0, 1, 2, 3, 4].map(i => { const p = quechua(i); S.scene.add(p.root); const b = grassBundle(160, { len: 0.7, seed: i + 3 }); b.scale.setScalar(2.2); p.j.chest.add(b); b.position.set(-0.4, 0.15, -0.22); b.rotation.set(0, Math.PI / 2, 0.2); return p; });
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      people.forEach((p, i) => { const x = -36 + i * 2.1 + t * 1.1; p.root.position.set(x, 0, 4 + Math.sin(i * 2) * 0.6); p.root.rotation.y = Math.PI / 2; const w = Math.sin((t + i * 0.3) * 6); standPose(p, t, { lHip: [w * 0.4, 0, 0.07], rHip: [-w * 0.4, 0, -0.07], lKn: [Math.max(0, -w) * 0.5, 0, 0], rKn: [Math.max(0, w) * 0.5, 0, 0], spine: [0.25, 0, 0], lSh: [-0.6, 0, 0.3], rSh: [-0.6, 0, -0.3], lEl: [-1.4, 0, 0], rEl: [-1.4, 0, 0] }); p.setMood('happy'); p.setMouth(0); p.grip(0.9, 0.9); });
      const k = easeInOut(range(t, 0, 3.5));
      place(c, [lerp(-24, -22, k), lerp(1.6, 2.0, k), lerp(13, 11, k)], [lerp(-32, -27, k), 1.1, 4]);
      return { bloom: 0.55, flare: 0.8, warm: 1.2 };
    },
  };
}
// ============ S6: grass twisted into a thin cord (close-up on a stone) ============
function macroStage(makeStage) {
  const scene = makeStage({ outdoor: 'andes', sunDir: [-0.5, 0.55, 0.7], fog: 0.002, shadowSize: 0.6, envI: 0.95 });
  const M = andesMats();
  const g = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshStandardMaterial({ color: 0x6a5a40, roughness: 1, bumpMap: M.grass.bumpMap, bumpScale: 3 })); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; scene.add(g);
  const stone = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.1, 0.8, 4, 1, 4), M.stone); stone.position.y = 0.05; scene.add(shadowAll(stone));
  scene.add(ichuTufts([[-1.4, 0, -1], [1.6, 0, -1.4], [0.4, 0, -2.2], [-2.2, 0, -2.6]], { h: 0.6 }));
  return scene;
}
function sTwist({ makeStage, start: ST }) {
  const tT = at(6, 'twist') - ST, tC = at(6, 'cords') - ST;
  const scene = macroStage(makeStage);
  const bundle = grassBundle(260, { len: 0.5, seed: 4 }); bundle.position.set(-0.45, 0.1, 0); scene.add(bundle);
  const cord = twisted({ strands: 2, R: 0.006, r: 0.005, len: 0.7, turns: 16 }); cord.position.set(-0.2, 0.13, 0.02); scene.add(cord);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      cord.grow(easeInOut(range(t, tT - 0.2, tC + 0.6)));
      cord.rotation.x = t * 1.5;
      const k = easeInOut(range(t, 0, 3.5));
      const pos = [lerp(-0.1, 0.15, k), lerp(0.42, 0.36, k), lerp(0.55, 0.45, k)], look = [lerp(-0.2, 0.05, k), 0.12, 0];
      place(c, pos, look);
      return { bloom: 0.55, warm: 1.25, dof: dofTo(pos, look, 0.012, 0.014) };
    },
  };
}
// ============ S7: cords braided into ropes, ropes into a cable ============
function sBraid({ makeStage, start: ST }) {
  const tR = at(7, 'ropes') - ST, tC = at(7, 'cables') - ST;
  const scene = macroStage(makeStage);
  const M = andesMats();
  const cords = [0, 1, 2].map(i => { const c = twisted({ strands: 2, R: 0.006, r: 0.005, len: 1.0, turns: 22 }); c.position.set(-0.5, 0.13, -0.2 + i * 0.04); scene.add(c); return c; });
  const rope = twisted({ strands: 3, R: 0.014, r: 0.011, len: 1.0, turns: 10, mat: M.rope(10) }); rope.position.set(-0.5, 0.14, 0.05); scene.add(rope);
  const cable = twisted({ strands: 3, R: 0.04, r: 0.032, len: 1.0, turns: 5, mat: M.rope(6) }); cable.position.set(-0.5, 0.17, 0.28); scene.add(cable);
  const c = cam(30);
  return {
    scene, camera: c,
    update(t) {
      cords.forEach(cd => cd.grow(1));
      rope.grow(easeInOut(range(t, tR - 0.5, tR + 0.6)));
      cable.grow(easeInOut(range(t, tC - 0.4, tC + 0.7)));
      const k = easeInOut(range(t, 0, 3.9));
      const pos = [lerp(-0.15, 0.25, k), lerp(0.4, 0.62, k), lerp(0.25, 0.95, k)], look = [lerp(-0.2, 0.0, k), 0.14, lerp(-0.15, 0.08, k)];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.2, dof: dofTo(pos, look, 0.008, 0.012) };
    },
  };
}
// ============ S8: the cables are hauled across the gorge to the stone anchors ============
function sStretch({ makeStage, start: ST }) {
  const tS = at(8, 'stretched') - ST, tA = at(8, 'anchors') - ST;
  const S = site(makeStage, { sunDir: [-0.5, 0.55, 0.65], shadowSize: 14, shadowAt: [10, 0, 0] });
  S.B.set({ cables: 0, rails: 0, floor: 0, sides: 0 });
  const P = crowd(S.scene, [[17.5, 0.2, -Math.PI / 2], [19.0, -0.1, -Math.PI / 2], [20.5, 0.25, -Math.PI / 2], [22.0, -0.15, -Math.PI / 2]]);
  const c = cam(40);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const kc = easeInOut(range(t, tS - 0.6, tA - 0.2));
      S.B.set({ cables: kc, rails: 0, floor: 0, sides: 0 });
      P.forEach((p, i) => { const lean = 0.35 + 0.1 * Math.sin(t * 3 + i); standPose(p, t + i, { spine: [-lean, 0, 0], lSh: [-1.3, 0, 0.15], rSh: [-1.3, 0, -0.15], lEl: [-0.2, 0, 0], rEl: [-0.2, 0, 0], lHip: [0.35, 0, 0.1], rHip: [-0.2, 0, -0.1], lKn: [0.3, 0, 0], drop: -0.06 }); p.setMood('happy'); p.setMouth(0); p.grip(0.95, 0.95); p.root.position.x = [17.5, 19.0, 20.5, 22.0][i] + kc * 1.2; });
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(24, 26, k), lerp(5, 4, k), lerp(14, 9, k)], [lerp(6, 14, k), lerp(-1, 0.4, k), 0]);
      return { bloom: 0.5, warm: 1.1 };
    },
  };
}
// ============ S9: a bridge master standing on the cables mid-span weaves the floor and handrails ============
function sWeave({ makeStage, start: ST }) {
  const tF = at(9, 'floor') - ST, tH = at(9, 'handrails') - ST;
  const S = site(makeStage, { sunDir: [-0.4, 0.6, 0.7], shadowSize: 6, shadowAt: [0, -2.4, 0] });
  const m = quechua(1); S.scene.add(m.root);
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const kf = lerp(0.25, 0.62, easeInOut(range(t, 0, tF + 1.0))), ks = lerp(0.1, 0.5, easeInOut(range(t, tH - 0.8, tH + 0.9)));
      S.B.set({ floor: kf, sides: ks });
      const x = -14 + kf * 28 - 0.4; m.root.position.set(x, S.B.yAt(x) + 0.1, 0); m.root.rotation.y = -Math.PI / 2;
      const w = Math.sin(t * 5);
      standPose(m, t, { spine: [0.55, 0, 0], chest: [0.3, 0, 0], lSh: [-1.1 + w * 0.2, 0, 0.3], rSh: [-1.1 - w * 0.2, 0, -0.3], lEl: [-0.6, 0, 0], rEl: [-0.6, 0, 0], lHip: [-0.6, 0, 0.15], rHip: [-0.6, 0, -0.15], lKn: [1.0, 0, 0], rKn: [1.0, 0, 0], drop: -0.25 });
      m.setMood('happy'); m.setMouth(0); m.grip(0.8, 0.8); m.blink(blinkK(t, [1.3, 3.0]));
      const k = easeInOut(range(t, 0, 4.1));
      const pos = [x + lerp(-3.5, -2.5, k), lerp(0.6, 0.2, k), lerp(4.5, 3.2, k)], look = [x, S.B.yAt(x) + 0.6, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.1, dof: dofTo(pos, look, 0.003, 0.009) };
    },
  };
}
// ============ S10: the old bridge is cut loose and swings down into the river ============
function sFall({ makeStage, start: ST }) {
  const tC = at(10, 'cut') - ST;
  const S = site(makeStage, { sunDir: [-0.5, 0.55, 0.65], shadowSize: 26 });
  S.B.set({ floor: 0.9, sides: 0.7 });
  S.B.position.z = 2.6;
  const pivot = new THREE.Group(); pivot.position.set(-14, 0, -2.4); S.scene.add(pivot);
  const old = ropeBridge({ old: true, sag: 3.2 }); old.position.x = 14; pivot.add(old);
  const AMAX = 1.1, tHit = Math.sqrt(AMAX / 2.0);
  const sp = splash2(4.5, 4); S.scene.add(sp);
  const sp2 = splash2(3.2, 9); S.scene.add(sp2);
  const c = cam(48);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const a = t - tC;
      let ang = a <= 0 ? 0 : Math.min(AMAX, 2.0 * a * a);
      if (a > tHit) ang = AMAX + Math.sin((a - tHit) * 6) * 0.05 * Math.exp(-(a - tHit) * 2.5);
      pivot.rotation.z = -ang;
      const ex = -14 + 28 * Math.cos(AMAX);
      sp.position.set(ex, -25.4, -2.4); sp.update(t - tC - tHit);
      sp2.position.set(ex - 6, -25.4, -2.2); sp2.update(t - tC - tHit - 0.12);
      const k = easeInOut(range(t, 0, 3.4)), f = easeInOut(range(t, tC, tC + tHit + 0.4));
      place(c, [lerp(5, 3, k), lerp(-2, -7, f), lerp(32, 36, k)], [lerp(-4, -6, k), lerp(-6, -15, f), -1]);
      return { bloom: 0.55, warm: 1.0 };
    },
  };
}
// ============ S11: the finished bridge, light sweeping across ============
function sDone({ makeStage }) {
  const S = site(makeStage, { preset: 'golden', sunDir: [0.6, 0.3, -0.74], shadowSize: 22 });
  const P = crowd(S.scene, [[-16.2, 1.6, 1.4], [-17.4, -1.4, 1.9], [16.4, 1.4, -1.6], [17.0, -1.2, -1.2]]);
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      P.forEach((p, i) => { standPose(p, t + i, { rSh: [i % 2 ? -2.4 : 0.05, 0, -0.3] }); p.setMood('happy'); p.setMouth(0); });
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-6, 6, k), lerp(5, 6, k), lerp(26, 24, k)], [0, lerp(-1.5, -1, k), 0]);
      return { bloom: 0.65, flare: 1.0, warm: 1.3 };
    },
  };
}
// ============ S12: a Spanish rider crosses on horseback ============
function sHorse({ makeStage }) {
  const S = site(makeStage, { sunDir: [-0.5, 0.55, 0.65], shadowSize: 6, shadowAt: [0, -2, 0] });
  const H = horseAndRider(); H.scale.setScalar(0.85); S.scene.add(H);
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      const x = -12 + t * 1.9; H.position.set(x, S.B.yAt(x) + 0.08, 0); H.rotation.z = Math.atan(2.6 * 8 * x / (28 * 28)); H.walk(t);
      standPose(H.rider, t, { lHip: [-1.3, 0, 0.5], rHip: [-1.3, 0, -0.5], lKn: [1.3, 0, 0], rKn: [1.3, 0, 0], lSh: [-0.5, 0, 0.1], rSh: [-0.5, 0, -0.1], lEl: [-0.8, 0, 0], rEl: [-0.8, 0, 0] }); H.rider.setMood('happy'); H.rider.setMouth(0); H.rider.grip(0.8, 0.8);
      const k = easeInOut(range(t, 0, 3.6));
      const pos = [x + lerp(2.5, 3.5, k), lerp(1.2, 1.6, k), lerp(5.5, 5.0, k)], look = [x, S.B.yAt(x) + 1.3, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.1, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S13: an elder and a child on the bridge at sunset ============
function sEnd({ makeStage }) {
  const S = site(makeStage, { preset: 'golden', sunDir: [0.55, 0.12, -0.83], shadowSize: 8, shadowAt: [-3, -2, 0] });
  const elder = quechua(2), kid = quechua(4, { kid: true });
  const xs = [-3.2, -2.5];
  [elder, kid].forEach((p, i) => { const x = xs[i]; p.root.position.set(x, S.B.yAt(x) + 0.1, i ? 0.2 : -0.2); p.root.rotation.y = Math.PI / 2 - 0.4; S.scene.add(p.root); });
  const c = cam(38);
  return {
    scene: S.scene, camera: c,
    update(t) {
      standPose(elder, t, { rSh: [-0.6, 0, -0.5], rEl: [-0.3, 0, 0], head: [0, -0.3, 0] }); elder.setMood('happy'); elder.setMouth(0); elder.blink(blinkK(t, [1.4, 3.6]));
      standPose(kid, t + 1, { lSh: [-1.6, 0, 0.3], head: [-0.2, 0.3, 0] }); kid.setMood('happy'); kid.setMouth(0); kid.blink(blinkK(t, [2.2]));
      const k = easeInOut(range(t, 0, 6.5));
      place(c, [lerp(-7.5, -11, k), lerp(0.4, 2.8, k), lerp(3.6, 7.5, k)], [lerp(-2.8, -1, k), lerp(-1.4, -1.6, k), 0]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sEdge], [ls(1), ls(2), sGrass], [ls(2), ls(3), sAerial], [ls(3), ls(4), sWork], [ls(4), ls(5), sBelow],
  [ls(5), ls(6), sGather], [ls(6), ls(7), sTwist], [ls(7), ls(8), sBraid], [ls(8), ls(9), sStretch], [ls(9), ls(10), sWeave],
  [ls(10), ls(11), sFall], [ls(11), ls(12), sDone], [ls(12), ls(13), sHorse], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
