// Chinampas reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { lake, chinampa, chinampaField, canoe, aztec, islandCity, trajinera, willow } from './chinampa.js';
import { VO } from './vo_ch.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['What if you', 3], ['needed *farmland*', 2], ['but your *city*', 3], ['was built', 2], ['in the middle', 3], ['of a *lake?*', 3]],
  [['But the *Aztecs*', 3], ['simply built', 2], ['their *fields*', 2], ['*on the water*', 3]],
  [["They're called", 2], ['*chinampas*', 1], ['the famous', 2], ['*floating gardens*', 2], ['of *Mexico*', 2]],
  [['Farmers drove', 2], ['*wooden posts*', 2], ['into the shallow', 3], ['*lake bed*', 2], ['and wove', 2], ['*reeds* and *branches*', 3], ['between them', 2]],
  [['Then they *filled*', 3], ['the frame', 2], ['with *mud*', 2], ['scooped from', 2], ['the bottom', 2], ['and *rotting plants*', 3]],
  [['*Willow trees*', 2], ['were planted', 2], ['at the *corners*', 3], ['Their *roots*', 2], ['held everything', 2], ['*together*', 1]],
  [["The beds weren't", 3], ['really *floating*', 2], ['They *rested*', 2], ['on the *lake bottom*', 4], ['just *above* the water', 4]],
  [['*Canals*', 1], ['between them', 2], ['became *watery streets*', 3], ['for *canoes*', 2]],
  [['*Water soaked up*', 3], ['from *below*', 2], ['so the crops', 3], ['*never* went *thirsty*', 3]],
  [['And *fresh mud*', 3], ['from the canals', 3], ['kept the soil', 3], ['*rich*', 1]],
  [['Some sources say', 3], ['a chinampa', 2], ['could give', 2], ['up to', 2], ['*7 harvests*', 2], ['*a year*', 2]],
  [['These gardens', 2], ['helped *feed*', 2], ['*Tenochtitlan*', 1], ['one of the', 3], ['*biggest cities*', 2], ['in the world', 3], ['at the time', 3]],
  [['In *Xochimilco*', 2], ['farmers *still grow*', 3], ['food on chinampas', 3], ['*today*', 1]],
  [['*Farmland*', 1], ['made of *mud*', 3], ['*reeds* and *trees*', 3], ['right *on a lake*', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function stage(makeStage, { preset = 'day', sunDir = [-0.5, 0.55, 0.6], shadowSize = 25, fog = 0.003 } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, envI: 0.9 });
  lake(scene);
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xfff0e0);
  return scene;
}
// underwater cut-away: camera under the surface; murky backdrop
function underStage(makeStage) {
  const scene = makeStage({ shadowSize: 6, sunDir: [-1, 5, 3], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x6a9ac8); u.mid.value.set(0x3a6a8a); u.horizon.value.set(0x2a5a6a); u.floorC.value.set(0x2a3020);
  const bed = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ color: 0x6a5a3e, roughness: 1 })); bed.rotation.x = -Math.PI / 2; bed.position.y = -1.2; bed.receiveShadow = true; scene.add(bed);
  const surf = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.MeshStandardMaterial({ color: 0x5ab0d0, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false })); surf.rotation.x = -Math.PI / 2; scene.add(surf);
  const tint = new THREE.Mesh(new THREE.BoxGeometry(40, 1.2, 40), new THREE.MeshBasicMaterial({ color: 0x2a7a8a, transparent: true, opacity: 0.12, depthWrite: false })); tint.position.y = -0.6; scene.add(tint);
  fillLight(scene, [0.4, 0.3, 1], 0.9);
  return scene;
}
function farmer(scene, x, z, ry, i = 0) { const e = aztec(i); e.root.position.set(x, 0.35, z); e.root.rotation.y = ry; scene.add(e.root); return e; }

// ============ S0: a city in the middle of a lake ============
function sHook({ makeStage }) {
  const scene = stage(makeStage, { sunDir: [-0.6, 0.45, 0.6], shadowSize: 80 });
  islandCity(scene, { at: [0, 0, -40], r: 32 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const a = lerp(0.6, 0.2, easeInOut(range(t, 0, 5.8)));
      place(c, [Math.sin(a) * 110, lerp(70, 50, easeInOut(range(t, 0, 5.8))), -40 + Math.cos(a) * 110], [0, 4, -40]);
      return { bloom: 0.55, flare: 0.8, warm: 1.2 };
    },
  };
}
// ============ S1: fields built on the water ============
function sFields({ makeStage }) {
  const scene = stage(makeStage, { shadowSize: 40 });
  chinampaField(scene, { nx: 6, nz: 4 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-30, -22, k), lerp(34, 26, k), lerp(46, 38, k)], [0, 0, 0]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S2: chinampas: one bed with willows, a canoe gliding past ============
function sOne({ makeStage }) {
  const scene = stage(makeStage, { shadowSize: 18 });
  chinampaField(scene, { nx: 3, nz: 2 });
  const C = canoe(); scene.add(C);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      C.position.set(3.2, 0, 10 - t * 1.4); C.rotation.y = Math.PI;
      if (C.man) { standPose(C.man, t, { lSh: [-1.5, 0, 0.3], rSh: [-1.2 + Math.sin(t * 2) * 0.3, 0, -0.3] }); C.man.setMood('happy'); C.man.setMouth(0); }
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(10, 8, k), lerp(5, 4, k), lerp(16, 12, k)], [2, 1, lerp(2, -1, k)]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S3/S4/S5: building a chinampa: posts and woven reeds; mud fill; willows ============
function buildShot(from, to, camFn) {
  return ({ makeStage }) => {
    const scene = stage(makeStage, { shadowSize: 12, sunDir: [-0.5, 0.6, 0.6] });
    const B = chinampa(4, 10, { seed: 3 }); scene.add(B);
    const nb = chinampa(4, 10, { seed: 9 }); nb.position.x = -6.5; scene.add(nb);
    const C = canoe(); C.position.set(3.4, 0, 3); C.rotation.y = 0.1; scene.add(C);
    const c = cam(38);
    return {
      scene, camera: c,
      update(t) {
        B.build(lerp(from[0], to[0], easeInOut(range(t, from[1], to[1]))));
        if (C.man) { standPose(C.man, t, { spine: [0.4, 0, 0], lSh: [-1.6 + Math.sin(t * 3) * 0.3, 0, 0.3], rSh: [-1.6 + Math.sin(t * 3) * 0.3, 0, -0.3] }); C.man.setMood('happy'); C.man.setMouth(0); }
        camFn(c, t);
        return { bloom: 0.5, warm: 1.15 };
      },
    };
  };
}
const sPosts = buildShot([0, 0.2], [2, 4.6], (c, t) => { const k = easeInOut(range(t, 0, 5)); place(c, [lerp(8, 7, k), lerp(5, 4, k), lerp(11, 9, k)], [0, 0, 0]); });
const sFill = buildShot([2, 0.2], [3, 4.0], (c, t) => { const k = easeInOut(range(t, 0, 4.4)); place(c, [lerp(6, 5, k), lerp(4.5, 3.5, k), lerp(8, 7, k)], [0, 0, 1]); });
const sWillow = buildShot([3, 0.2], [3.5, 3.4], (c, t) => { const k = easeInOut(range(t, 0, 4.4)); place(c, [lerp(9, 10, k), lerp(4, 6, k), lerp(12, 14, k)], [0, lerp(2, 3, k), 0]); });
// ============ S6: not floating: under the water, the bed rests on the lake bottom ============
function sRest({ makeStage }) {
  const scene = underStage(makeStage);
  const B = chinampa(4, 10, { seed: 3 }); B.build(4); scene.add(B);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(7.5, 6.5, k), lerp(0.45, 0.25, k), lerp(10, 9, k)], [0, -0.35, 0]);
      return { bloom: 0.5, warm: 0.95 };
    },
  };
}
// ============ S7: canals as streets for canoes ============
function sCanal({ makeStage }) {
  const scene = stage(makeStage, { shadowSize: 20 });
  chinampaField(scene, { nx: 2, nz: 4 });
  const C = canoe(); scene.add(C);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const z = 26 - t * 2.2; C.position.set(0, 0, z); C.rotation.y = Math.PI;
      if (C.man) { standPose(C.man, t, { lSh: [-1.5, 0, 0.3], rSh: [-1.2 + Math.sin(t * 2) * 0.3, 0, -0.3] }); C.man.setMood('happy'); C.man.setMouth(0); }
      place(c, [1.2, 2.4, z + 6], [0, 1.0, z - 4]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S8: water soaks up from below into the roots ============
function sSoak({ makeStage }) {
  const scene = underStage(makeStage);
  const B = chinampa(4, 10, { seed: 3 }); scene.add(B);
  const drops = [...Array(40)].map((_, i) => { const d = glowSprite(0x7ad8ff, 0.18); scene.add(d); return d; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      B.build(lerp(3.5, 4, easeInOut(range(t, 0.5, 3.2))));
      drops.forEach((d, i) => { const u = (t * 0.4 + i / 40) % 1; d.position.set(((i * 37) % 40) / 40 * 3.6 - 1.8, -1.1 + u * 1.5, 2.2 + (i % 5) * 0.4); d.material.opacity = Math.sin(u * Math.PI); });
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(5.5, 4.5, k), lerp(0.3, 0.45, k), lerp(11.5, 10, k)], [0, -0.2, 1.5]);
      return { bloom: 0.6, warm: 0.95 };
    },
  };
}
// ============ S9: fresh mud scooped from the canal onto the bed ============
function sScoop({ makeStage }) {
  const scene = stage(makeStage, { shadowSize: 10 });
  const B = chinampa(4, 10, { seed: 3 }); scene.add(B);
  const C = canoe(); C.position.set(3.2, 0, 1); scene.add(C);
  const lump = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), new THREE.MeshStandardMaterial({ color: 0x3a2a18, roughness: 1 })); scene.add(lump);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const ph = (t / 1.6) % 1; const lift = Math.sin(ph * Math.PI);
      if (C.man) { standPose(C.man, t, { spine: [0.5 - lift * 0.4, 0, 0], lSh: [-1.0 - lift * 1.2, 0, 0.3], rSh: [-1.0 - lift * 1.2, 0, -0.3] }); C.man.setMood('happy'); C.man.setMouth(0); C.man.root.rotation.y = -Math.PI / 2; }
      lump.position.set(lerp(3.6, 1.6, ph), 0.2 + lift * 1.2, 0); lump.visible = ph > 0.05 && ph < 0.95;
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(6, 5, k), lerp(2.6, 2.2, k), lerp(6, 5, k)], [2.2, 0.6, 0]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S10: harvest after harvest (time-lapse) ============
function sHarvest({ makeStage }) {
  const scene = stage(makeStage, { shadowSize: 10 });
  const B = chinampa(4, 10, { seed: 3 }); scene.add(B);
  const f = farmer(scene, 0, 3, Math.PI, 1);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const cyc = (t / 0.75) % 1; B.grow(Math.min(1, cyc * 1.3)); // 7 cycles in ~5 s
      standPose(f, t, { spine: [0.6 * (cyc > 0.8 ? 1 : 0), 0, 0], lSh: [-1.0, 0, 0.3], rSh: [-1.0, 0, -0.3] }); f.setMood('happy'); f.setMouth(0);
      const a = lerp(0.6, 1.0, easeInOut(range(t, 0, 5)));
      place(c, [Math.sin(a) * 9, 5, Math.cos(a) * 9], [0, 0.6, 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S11: Tenochtitlan, ringed by chinampas ============
function sCity({ makeStage }) {
  const scene = stage(makeStage, { preset: 'golden', sunDir: [0.6, 0.35, 0.7], shadowSize: 90 });
  islandCity(scene, { at: [0, 0, -60], r: 34 });
  chinampaField(scene, { nx: 7, nz: 2, l: 12 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.6));
      place(c, [lerp(18, 8, k), lerp(14, 26, k), lerp(26, 34, k)], [0, lerp(4, 8, k), lerp(-20, -50, k)]);
      return { bloom: 0.6, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S12: Xochimilco today: colourful boats on a willow-lined canal ============
function sToday({ makeStage }) {
  const scene = stage(makeStage, { shadowSize: 20 });
  chinampaField(scene, { nx: 2, nz: 3, gap: 4.5 });
  const boats = [0, 1, 2].map(i => { const b = trajinera(i); scene.add(b); return b; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      boats.forEach((b, i) => { b.position.set((i - 1) * 0.3, 0, 6 - i * 9 - t * 0.8); b.rotation.y = 0; });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(5, 3.5, k), lerp(4.5, 3.6, k), lerp(30, 25, k)], [0, 1.4, 2]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S13: sunset over the gardens ============
function sEnd({ makeStage }) {
  const scene = stage(makeStage, { preset: 'golden', sunDir: [0.7, 0.12, -0.7], shadowSize: 40 });
  chinampaField(scene, { nx: 5, nz: 3 });
  const C = canoe(); scene.add(C);
  const b = birds(4, { from: [-20, 12, -20], to: [20, 14, -30], spread: 4, speed: 0.06, scale: 1.6, seed: 2 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      C.position.set(3.2, 0, 8 - t * 1.0); C.rotation.y = Math.PI;
      if (C.man) { standPose(C.man, t, { lSh: [-1.5, 0, 0.3], rSh: [-1.2 + Math.sin(t * 2) * 0.3, 0, -0.3] }); C.man.setMood('happy'); C.man.setMouth(0); }
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(6, 14, k), lerp(3, 14, k), lerp(14, 30, k)], [2, 1, -4]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sFields], [ls(2), ls(3), sOne], [ls(3), ls(4), sPosts], [ls(4), ls(5), sFill],
  [ls(5), ls(6), sWillow], [ls(6), ls(7), sRest], [ls(7), ls(8), sCanal], [ls(8), ls(9), sSoak], [ls(9), ls(10), sScoop],
  [ls(10), ls(11), sHarvest], [ls(11), ls(12), sCity], [ls(12), ls(13), sToday], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
