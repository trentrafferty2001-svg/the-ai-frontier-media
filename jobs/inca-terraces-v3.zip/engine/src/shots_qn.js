// Persian qanat reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { desertGround, palm, yakhchal, qanatLine, persianWorker } from './persia.js';
import { section, windlass, village, gardenPool, surf, tunnelY, MW } from './qanat.js';
import { VO } from './vo_qn.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['How do you', 3], ['*grow food*', 2], ['in a *desert*', 3], ['where it', 2], ['*almost never rains?*', 3]],
  [['But *Persian farmers*', 3], ['found *water*', 2], ['*hidden* under the hills', 4], ['and brought it', 3], ['to the surface', 3], ['without a', 2], ['*single pump*', 2]],
  [["It's called a", 3], ['*qanat*', 1]],
  [['First', 1], ['diggers sank', 2], ['a deep *mother well*', 4], ['into the hills', 3], ['until they', 2], ['*hit water*', 2]],
  [['Some mother wells', 3], ['go down', 2], ['about *300 meters*', 4]],
  [['Then they dug', 3], ['a *tunnel*', 2], ['back toward it', 3], ['starting from', 2], ['the *village*', 2]],
  [['The tunnel', 2], ['sloped down', 2], ['*very gently*', 2], ['so water', 2], ['could *flow*', 2], ['but not', 2], ['*wash* the tunnel away', 4]],
  [['Every *20 or 30*', 4], ['meters', 1], ['a *shaft*', 2], ['went up to', 3], ['the surface', 2], ['for *fresh air*', 3], ['and for', 2], ['*hauling out*', 2], ['the dirt', 2]],
  [['From *above*', 2], ['they look like', 3], ['a line of *craters*', 4], ['across the *desert*', 3]],
  [['The water flowed', 3], ['for *kilometers*', 2], ['by *gravity alone*', 3], ['and came out *cool*', 4], ['into *fields* and *towns*', 4]],
  [['It filled', 2], ['*pools* and *gardens*', 3], ['and even', 2], ['the famous', 2], ['*ice houses*', 2]],
  [['Many qanats', 2], ['are *thousands*', 2], ['of *years old*', 3]],
  [['Some *still flow*', 3], ['*today*', 1], ['and *UNESCO*', 2], ['now lists', 2], ['the Persian qanat', 3], ['as *World Heritage*', 3]],
  [['*Water* in the *desert*', 4], ['moved by', 2], ['nothing but', 2], ['a *slope*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function desert(makeStage, { sunDir = [-0.5, 0.55, 0.65], preset = 'desert', fog = 0.003, shadowSize = 30, seed = 2 } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, envI: 0.9 });
  desertGround(scene, { seed });
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xffe6c8);
  return scene;
}
// cross-section stage: dark backdrop, section facing +z
function secStage(makeStage) {
  const scene = makeStage({ outdoor: 'desert', sunDir: [-0.3, 0.7, 0.65], fog: 0.0, shadowSize: 40, shadowAt: [0, 5, 0], envI: 0.9 });
  const S = section(); scene.add(S);
  fillLight(scene, [0.2, 0.3, 1], 1.0, 0xfff0e0);
  return { scene, S };
}
const crater = (x0, x1, n) => qanatLine(n, { from: [x0, 0, -2], to: [x1, 0, -2] });

// ============ S0: an empty, burning desert ============
function sHook({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [0.4, 0.6, -0.7] });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(-20, -10, k), lerp(12, 6, k), lerp(30, 20, k)], [0, 2, -40]);
      return { bloom: 0.6, flare: 1.2, warm: 1.35 };
    },
  };
}
// ============ S1: a green oasis village fed by water from under the hills ============
function sOasis({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.6, 0.35, 0.7], seed: 5 });
  village(scene);
  [[-10, 8, 6], [10, 9, 5.5], [-12, -4, 6.5], [12, -2, 6], [4, 12, 5]].forEach(([x, z, h], i) => { const p = palm(h, i + 31); p.position.set(x, 0, z); scene.add(p); });
  const L = qanatLine(10, { from: [-1, 0, -70], to: [-1, 0, -22] }); scene.add(L);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 6));
      place(c, [lerp(14, 8, k), lerp(9, 14, k), lerp(26, 22, k)], [0, 1, lerp(-4, -14, k)]);
      return { bloom: 0.6, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S2: "a qanat": the crater line running to the hills ============
function sLine({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [-0.6, 0.35, 0.7], seed: 7 });
  const L = qanatLine(14, { from: [0, 0, -90], to: [0, 0, -4] }); scene.add(L);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 2.2));
      place(c, [lerp(5, 4, k), lerp(3, 4, k), lerp(4, 2, k)], [0, 0, -30]);
      return { bloom: 0.55, warm: 1.3 };
    },
  };
}
// ============ S3/S4: the mother well goes down to the water ============
function sWell({ makeStage, start: ST }) {
  const tH = at(3, 'hit') - ST;
  const { scene, S } = secStage(makeStage);
  S.dig(0); S.shafts(0); S.water(0);
  const w = windlass(); w.position.set(MW, surf(MW), -3); scene.add(w);
  const men = [persianWorker(), persianWorker({ color: 0xb8a888 })]; men.forEach((e, i) => { e.root.position.set(MW - 1.4 + i * 2.8, surf(MW - 1.4 + i * 2.8), -3); e.root.rotation.y = i ? -1.2 : 1.2; e.root.scale.setScalar(1.2); scene.add(e.root); });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      S.well(easeInOut(range(t, 0.3, tH)));
      S.aquifer.material.emissive = new THREE.Color(0x1a5aa0); S.aquifer.material.emissiveIntensity = Math.max(0, 1 - Math.abs(t - tH - 0.3) * 1.5) * 0.8;
      w.set(Math.sin(t * 2) * 0.4);
      men.forEach((e, i) => { standPose(e, t + i, { spine: [0.3, 0, 0], lSh: [-1.2, 0, 0.2], rSh: [-1.2 + Math.sin(t * 4 + i) * 0.3, 0, -0.2] }); e.setMood('happy'); e.setMouth(0); });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [MW + lerp(-5, -8, k), lerp(surf(MW) + 5, 14, k), lerp(20, 34, k)], [MW - 2, lerp(surf(MW) - 2, 8, k), 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
function sDeep({ makeStage }) {
  const { scene, S } = secStage(makeStage);
  S.dig(0); S.shafts(0); S.water(0); S.well(1);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const y = lerp(surf(MW) + 1, tunnelY(MW) + 1, easeInOut(range(t, 0.2, 3.0)));
      place(c, [MW - 3, y + 2, 17], [MW, y - 1, 0]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S5: the tunnel is dug from the village back toward the well ============
function sDig({ makeStage }) {
  const { scene, S } = secStage(makeStage);
  S.shafts(0); S.water(0); S.well(1);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      S.dig(easeInOut(range(t, 0.2, 3.8)));
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-14, 6, k), lerp(4, 8, k), lerp(26, 36, k)], [lerp(-18, 4, k), lerp(1, 5, k), 0]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S6: the gentle slope: water starts to flow ============
function sSlope({ makeStage }) {
  const { scene, S } = secStage(makeStage);
  S.shafts(0); S.well(1);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      S.water(easeInOut(range(t, 0.3, 3)), t * 12);
      const x = lerp(10, -2, easeInOut(range(t, 0, 5)));
      place(c, [x, tunnelY(x) + 2.0, 9], [x - 2, tunnelY(x - 2) + 0.3, 0]);
      return { bloom: 0.6, warm: 1.1 };
    },
  };
}
// ============ S7: shafts every 20-30 m, dirt hauled up by windlass ============
function sShafts({ makeStage, start: ST }) {
  const { scene, S } = secStage(makeStage);
  S.well(1);
  const w = windlass(); const sx = S.sx[5]; w.position.set(sx, surf(sx), -3); scene.add(w);
  const man = persianWorker(); man.root.position.set(sx + 1.3, surf(sx + 1.3), -3); man.root.rotation.y = -1.3; man.root.scale.setScalar(1.2); scene.add(man.root);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      S.shafts(easeInOut(range(t, 0.2, 3.0))); S.water(1, t * 12);
      w.set(lerp(-(surf(sx) - tunnelY(sx)) + 0.6, 0.4, (t * 0.4) % 1));
      standPose(man, t, { spine: [0.3, 0, 0], lSh: [-1.3, 0, 0.2], rSh: [-1.3 + Math.sin(t * 5) * 0.4, 0, -0.2] }); man.setMood('happy'); man.setMouth(0);
      const k = easeInOut(range(t, 0, 6.5));
      place(c, [lerp(-6, sx + 2, k), lerp(9, surf(sx) + 3, k), lerp(32, 14, k)], [lerp(-2, sx, k), lerp(4, surf(sx) - 1, k), 0]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S8: from above: a line of craters across the desert ============
function sAbove({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [-0.4, 0.5, 0.7], seed: 9, shadowSize: 60 });
  const L = qanatLine(24, { from: [-10, 0, -140], to: [8, 0, 20] }); scene.add(L);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-30, -24, k), lerp(55, 45, k), lerp(30, 18, k)], [lerp(0, -2, k), 0, lerp(-30, -45, k)]);
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S9: gravity alone: the full section, water running to the outlet ============
function sFlow({ makeStage }) {
  const { scene, S } = secStage(makeStage);
  const fields = new THREE.Mesh(new THREE.PlaneGeometry(14, 6), new THREE.MeshStandardMaterial({ color: 0x5a8a2a, roughness: 0.9 })); fields.rotation.x = -Math.PI / 2; fields.position.set(-32, 0.05, -3); scene.add(fields);
  [[-30, -4, 5], [-35, -2, 6]].forEach(([x, z, h], i) => { const p = palm(h, i + 5); p.position.set(x, 0, z); scene.add(p); });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      S.water(1, t * 16);
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(6, -18, k), lerp(10, 4, k), lerp(46, 22, k)], [lerp(2, -26, k), lerp(6, 1, k), 0]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
// ============ S10: pools, gardens and the ice houses ============
function sGarden({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.6, 0.35, 0.7], seed: 11, shadowSize: 20 });
  const G = gardenPool(); scene.add(G);
  const Y = yakhchal({ R: 7, H: 14 }); Y.position.set(14, 0, -30); scene.add(Y);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      G.update(t);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-2, 2, k), lerp(2.2, 3.5, k), lerp(9, 11, k)], [lerp(0, 6, k), lerp(1, 4, k), lerp(-2, -18, k)]);
      return { bloom: 0.6, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S11: thousands of years old ============
function sOld({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.75, 0.12, -0.6], seed: 13 });
  const L = qanatLine(14, { from: [-6, 0, -100], to: [2, 0, -6] }); scene.add(L);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3));
      place(c, [lerp(6, 8, k), lerp(4, 5, k), lerp(4, 6, k)], [-2, 1, -40]);
      return { bloom: 0.65, flare: 1.1, warm: 1.35 };
    },
  };
}
// ============ S12: still flowing today: the outlet stream into green fields ============
function sToday({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.6, 0.35, 0.7], seed: 15, shadowSize: 15 });
  village(scene, { seed: 8 });
  [[-6, 6, 5], [5, 7, 6]].forEach(([x, z, h], i) => { const p = palm(h, i + 41); p.position.set(x, 0, z); scene.add(p); });
  const sp = [...Array(16)].map((_, i) => { const s = glowSprite(0xdff4ff, 0.25); scene.add(s); return s; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      sp.forEach((s, i) => { const u = (t * 0.3 + i / 16) % 1; s.position.set(-1 + Math.sin(i) * 0.2, 0.12, -14 + u * 24); s.material.opacity = 0.6 * Math.sin(u * Math.PI); });
      const k = easeInOut(range(t, 0, 5.3));
      place(c, [lerp(3, 4, k), lerp(1.6, 3, k), lerp(10, 14, k)], [-1, 0.5, lerp(-2, -6, k)]);
      return { bloom: 0.6, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S13: sunset over the crater line leading to the oasis ============
function sEnd({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [-0.7, 0.1, -0.7], seed: 17, shadowSize: 40 });
  village(scene, { seed: 4 });
  const L = qanatLine(16, { from: [-1, 0, -130], to: [-1, 0, -24] }); scene.add(L);
  [[-10, 8, 6], [10, 9, 5.5]].forEach(([x, z, h], i) => { const p = palm(h, i + 51); p.position.set(x, 0, z); scene.add(p); });
  const b = birds(4, { from: [-20, 14, -20], to: [20, 16, -30], spread: 4, speed: 0.06, scale: 1.6, seed: 9 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(8, 14, k), lerp(8, 24, k), lerp(20, 34, k)], [-1, 0, lerp(-10, -40, k)]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sOasis], [ls(2), ls(3), sLine], [ls(3), ls(4), sWell], [ls(4), ls(5), sDeep],
  [ls(5), ls(6), sDig], [ls(6), ls(7), sSlope], [ls(7), ls(8), sShafts], [ls(8), ls(9), sAbove], [ls(9), ls(10), sFlow],
  [ls(10), ls(11), sGarden], [ls(11), ls(12), sOld], [ls(12), ls(13), sToday], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
