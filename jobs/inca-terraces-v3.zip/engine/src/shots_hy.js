// Roman hypocaust reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { romanBuilder } from './rome.js';
import './persia.js';
import { bathRoom, furnace, villa, snowfall } from './hypo.js';
import { VO } from './vo_hy.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*2,000 years* ago', 4], ['some *Romans*', 2], ['walked on', 2], ['*warm floors*', 2], ['in the middle', 3], ['of *winter*', 2]],
  [['But there were', 3], ['*no radiators*', 2], ['The heat came', 3], ['from a *fire*', 3], ['*under the floor*', 3]],
  [["It's called a", 3], ['*hypocaust*', 1], ['which means', 2], ['*heated from below*', 3]],
  [['Builders *raised*', 2], ['the floor', 2], ['on short', 2], ['*stacks of tiles*', 3], ['called *pilae*', 2]],
  [['That left a', 3], ['*hollow space*', 2], ['underneath', 1], ['often about', 2], ['*knee high*', 2]],
  [['Outside the room', 3], ['a *furnace*', 2], ['burned *wood*', 2], ['for *hours*', 2]],
  [['*Hot air* and *smoke*', 4], ['flowed from', 2], ['the fire', 2], ['into the *hollow space*', 4]],
  [['It *warmed*', 2], ['the *thick floor*', 3], ['which kept', 2], ['*giving off heat*', 3], ['long after', 2]],
  [['*Hollow box tiles*', 3], ['inside the *walls*', 3], ['let the hot air', 4], ['*rise up*', 2], ['warming the walls *too*', 4]],
  [['Then the *smoke*', 3], ['*escaped*', 1], ['through *vents*', 2], ['near the *roof*', 3]],
  [['The *hottest room*', 3], ['the *caldarium*', 2], ['sat right', 2], ['next to', 2], ['the *furnace*', 2]],
  [['*Workers*', 1], ['often *enslaved*', 2], ['had to keep', 3], ['*feeding the fire*', 3]],
  [['*Baths*', 1], ['and *rich homes*', 3], ['across the *empire*', 3], ['used it', 2], ['from *Britain*', 2], ['to *North Africa*', 3]],
  [['*Central heating*', 2], ['built from *tiles*', 3], ['*fire*', 1], ['and a *gap*', 3], ['under the floor', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function interior(makeStage, { cut = false } = {}) {
  const scene = makeStage({ shadowSize: 6, sunDir: [2, 6, 5], sun: 1.8 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a2018); u.mid.value.set(0x3a2a1e); u.horizon.value.set(0x4a3626); u.floorC.value.set(0x20160e);
  const R = bathRoom({ cutFloor: cut }); scene.add(R);
  const F = furnace(); scene.add(F);
  const lamp = new THREE.PointLight(0xffb060, 2.5, 9, 1.6); lamp.position.set(0, 3.5, 1.5); scene.add(lamp);
  fillLight(scene, [0.3, 0.4, 1], 0.6, 0xfff0e0);
  return { scene, R, F };
}
function bather(scene, x, z, ry, i = 0) { const b = romanBuilder({ color: [0xf2ece0, 0xe0d8c8][i % 2], skin: [0xd8a07a, 0xc08860][i % 2] }); b.root.position.set(x, 1.0, z); b.root.rotation.y = ry; scene.add(b.root); return b; }
function stoker(scene) { const w = romanBuilder({ color: 0x7a6a5a, skin: 0x9a6a4a }); w.root.position.set(-4.4, 0, 1.6); w.root.rotation.y = Math.PI; scene.add(w.root); return w; }

// ============ S0: winter: snow on a villa, warm light inside ============
function sHook({ makeStage }) {
  const scene = makeStage({ outdoor: 'winter', sunDir: [-0.5, 0.35, 0.7], fog: 0.012, shadowSize: 12, envI: 0.9 });
  const sm = villa(scene); const sn = snowfall(scene);
  scene.userData.updaters.push(sm, sn);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(-19, -15, k), lerp(3.0, 2.4, k), lerp(17, 13, k)], [-2, 2.8, -4]); // three-quarter view: snowy ground, wall, roof, smoke
      return { bloom: 0.6, warm: 1.0 };
    },
  };
}
// ============ S1: inside, bare feet on a warm mosaic; no radiators, the heat is under the floor ============
function sInside({ makeStage }) {
  const { scene, R, F } = interior(makeStage);
  const b = [bather(scene, -1.2, 0.8, 0.4, 0), bather(scene, 0.6, 1.4, -0.6, 1)];
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.warm(0.6); R.steam(1, t); F.fire.set(1, t);
      b.forEach((e, i) => { standPose(e, t + i, { head: [0.2, 0, 0] }); e.setMood('happy'); e.setMouth(0); e.blink(blinkK(t + i, [1.2, 3.5])); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(0.5, 0.2, k), lerp(2.8, 2.0, k), lerp(7.5, 5.5, k)], [lerp(-0.3, -0.5, k), lerp(2.0, 1.5, k), 0.5]);
      return { bloom: 0.55, warm: 1.25 };
    },
  };
}
// ============ S2: "hypocaust": the floor turns see-through, showing the space below ============
function sReveal({ makeStage }) {
  const { scene, R, F } = interior(makeStage);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.cutFloor(easeInOut(range(t, 0.4, 2.2))); F.fire.set(1, t); R.flow(easeOut(range(t, 1.5, 3)), t); R.steam(1, t);
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(1.5, 3.0, k), lerp(3.5, 4.6, k), lerp(7.5, 8.5, k)], [0, lerp(1.4, 0.8, k), 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S3/S4: the pilae stacks; the knee-high hollow ============
function sPilae({ makeStage }) {
  const { scene, R, F } = interior(makeStage, { cut: true });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      F.fire.set(1, t);
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(1.6, 0.8, k), lerp(1.4, 0.9, k), lerp(4.6, 3.6, k)], [lerp(0, -0.6, k), 0.45, 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
function sGap({ makeStage }) {
  const { scene, R, F } = interior(makeStage, { cut: false });
  const w = stoker(scene); w.root.position.set(-2.0, 0, 3.4); w.root.rotation.y = 0.6;
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      F.fire.set(1, t); R.flow(0.6, t);
      standPose(w, t, { head: [0, 0.5, 0] }); w.setMood('happy'); w.setMouth(0);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(2.5, 1.6, k), 0.5, lerp(5.0, 4.0, k)], [lerp(0.5, -0.5, k), 0.5, 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S5: the furnace outside, wood burning ============
function sFurnace({ makeStage }) {
  const { scene, R, F } = interior(makeStage);
  const w = stoker(scene);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      F.fire.set(1, t);
      standPose(w, t, { spine: [0.5, 0, 0], lSh: [-1.3, 0, 0.2], rSh: [-1.3 + Math.sin(t * 3) * 0.3, 0, -0.2] }); w.setMood('happy'); w.setMouth(0);
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-6.8, -6.2, k), lerp(1.8, 1.4, k), lerp(5.5, 4.6, k)], [-4.3, 0.6, 0.8]);
      return { bloom: 0.65, warm: 1.25 };
    },
  };
}
// ============ S6: hot air and smoke flow into the hollow ============
function sFlow({ makeStage }) {
  const { scene, R, F } = interior(makeStage, { cut: true });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      F.fire.set(1, t); R.flow(easeOut(range(t, 0, 1.2)), t);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-2.5, 0.5, k), lerp(2.6, 2.8, k), lerp(6.5, 7.5, k)], [lerp(-2.5, 0.5, k), 0.4, 0]);
      return { bloom: 0.65, warm: 1.2 };
    },
  };
}
// ============ S7: the thick floor warms up ============
function sWarm({ makeStage }) {
  const { scene, R, F } = interior(makeStage);
  const b = bather(scene, 0.2, 1.2, 0.3, 1);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      R.warm(easeInOut(range(t, 0.2, 3.5))); F.fire.set(1, t);
      standPose(b, t, { head: [0.4, 0, 0] }); b.setMood('happy'); b.setMouth(0);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(2.0, 1.6, k), lerp(2.4, 2.1, k), lerp(5.2, 4.4, k)], [0.2, 1.6, 1.0]);
      return { bloom: 0.6, warm: 1.3 };
    },
  };
}
// ============ S8: box tiles in the walls: the hot air rises ============
function sWalls({ makeStage }) {
  const { scene, R, F } = interior(makeStage, { cut: true });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      F.fire.set(1, t); R.flow(1, t);
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(6.5, 7.5, k), lerp(1.5, 3.4, k), lerp(4.5, 3.0, k)], [3.1, lerp(1.4, 3.2, k), 0]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
// ============ S9: smoke escapes through vents near the roof ============
function sVents({ makeStage }) {
  const { scene, R, F } = interior(makeStage);
  { const u = scene.userData.sky.material.uniforms; u.top.value.set(0x6a7a8e); u.mid.value.set(0x8a96a6); u.horizon.value.set(0xa8b0b8); } // winter sky above the roof, not a black void
  const puffs = [...Array(12)].map(() => { const s = glowSprite(0x9a9a9a, 0.8); s.material.blending = THREE.NormalBlending; scene.add(s); return s; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      R.flow(1, t);
      puffs.forEach((s, i) => { const u = (t * 0.35 + i / 12) % 1; const v = R.vents[i % 3].position; s.position.set(v.x + u * 0.5, v.y + 0.3 + u * 2.4, v.z); s.scale.setScalar(0.3 + u * 1.4); s.material.opacity = 0.5 * (1 - u); });
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(7, 8, k), lerp(5.5, 6.5, k), lerp(5, 6, k)], [3.2, 5.2, 0]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S10: the caldarium, next to the furnace, steaming ============
function sCaldarium({ makeStage }) {
  const { scene, R, F } = interior(makeStage);
  const b = [bather(scene, 1.0, -0.2, -0.3, 0), bather(scene, 2.2, 0.3, -0.9, 1)];
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.warm(0.8); R.steam(1, t); F.fire.set(1, t);
      b.forEach((e, i) => { standPose(e, t + i, { lSh: [0.05, 0, 0.3], rSh: [0.05, 0, -0.3] }); e.setMood('happy'); e.setMouth(0); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-1.5, -0.5, k), lerp(3.0, 2.4, k), lerp(7.5, 6.0, k)], [lerp(-1.5, 0.5, k), 1.5, -0.5]);
      return { bloom: 0.6, warm: 1.3 };
    },
  };
}
// ============ S11: a worker keeps feeding the fire ============
function sStoker({ makeStage }) {
  const { scene, R, F } = interior(makeStage);
  const w = stoker(scene); w.root.position.set(-4.0, 0, 1.7);
  const log = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.7, 8), new THREE.MeshStandardMaterial({ color: 0x6a4424 })); scene.add(log);
  const c = cam(34);
  return {
    scene, camera: c,
    update(t) {
      F.fire.set(1, t);
      const ph = (t / 1.8) % 1; const reach = Math.sin(ph * Math.PI);
      standPose(w, t, { spine: [0.3 + reach * 0.5, 0, 0], lSh: [-1.0 - reach * 0.5, 0, 0.2], rSh: [-1.0 - reach * 0.5, 0, -0.2], head: [0.2, 0, 0] }); w.setMood('happy'); w.setMouth(0);
      log.position.set(-4.0, 0.9 - reach * 0.6, 1.2 - reach * 0.4); log.rotation.z = Math.PI / 2;
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-6.8, -6.4, k), lerp(1.9, 1.6, k), lerp(5.0, 4.4, k)], [-4.1, 0.8, 1.2]);
      return { bloom: 0.6, warm: 1.25 };
    },
  };
}
// ============ S12: bath buildings across the empire: a big bath complex ============
function sEmpire({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.6, 0.35, 0.7], fog: 0.003, shadowSize: 40, envI: 0.95 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: 0x8a9a5a, roughness: 1 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const wm = new THREE.MeshStandardMaterial({ color: 0xd8c8a8, roughness: 0.8 }), tm = new THREE.MeshStandardMaterial({ color: 0xb85a34, roughness: 0.8 });
  [[0, 0, 24, 8, 14], [-18, 4, 10, 6, 10], [18, 4, 10, 6, 10], [0, -14, 14, 10, 10]].forEach(([x, z, w, h, d]) => { const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wm); b.position.set(x, h / 2, z); b.castShadow = b.receiveShadow = true; scene.add(b); const r = new THREE.Mesh(new THREE.BoxGeometry(w + 0.6, 0.6, d + 0.6), tm); r.position.set(x, h + 0.3, z); scene.add(r); });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(6, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), wm); dome.position.set(0, 10, -14); scene.add(dome);
  const smoke = [...Array(16)].map(() => { const s = glowSprite(0xaaaaaa, 2); s.material.blending = THREE.NormalBlending; scene.add(s); return s; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      smoke.forEach((s, i) => { const u = (t * 0.2 + i / 16) % 1; s.position.set(-20 + (i % 4) * 13, 9 + u * 8, 2); s.scale.setScalar(1 + u * 4); s.material.opacity = 0.3 * (1 - u); });
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(30, 20, k), lerp(26, 20, k), lerp(46, 40, k)], [0, 4, -4]);
      return { bloom: 0.6, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S13: warm room, pull out to the snowy night ============
function sEnd({ makeStage }) {
  const { scene, R, F } = interior(makeStage, { cut: true });
  const b = bather(scene, -0.8, -0.8, 0.3, 0); // stands on the floor that remains after the cut
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      R.warm(0.7); R.flow(1, t); R.steam(1, t); F.fire.set(1, t);
      standPose(b, t, { lSh: [0.05, 0, 0.3], rSh: [0.05, 0, -0.3] }); b.setMood('happy'); b.setMouth(0);
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(1.0, 4.0, k), lerp(2.2, 5.5, k), lerp(5.0, 12.0, k)], [-0.3, lerp(1.4, 2.0, k), 0]);
      return { bloom: 0.65, warm: 1.3 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sInside], [ls(2), ls(3), sReveal], [ls(3), ls(4), sPilae], [ls(4), ls(5), sGap],
  [ls(5), ls(6), sFurnace], [ls(6), ls(7), sFlow], [ls(7), ls(8), sWarm], [ls(8), ls(9), sWalls], [ls(9), ls(10), sVents],
  [ls(10), ls(11), sCaldarium], [ls(11), ls(12), sStoker], [ls(12), ls(13), sEmpire], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
