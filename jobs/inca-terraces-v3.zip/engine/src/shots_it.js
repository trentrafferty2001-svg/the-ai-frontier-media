// Inca terraces reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { mountains, birds } from './world.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { quechua } from './andes.js';
import { terracedHill, moray, terraceSection, steepSlope, incaMats } from './inca.js';
import { VO } from './vo_it.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['How do you', 3], ['*farm*', 1], ['on a *mountainside*', 3], ['so *steep*', 2], ['you can *barely stand*', 4], ['on it?', 2]],
  [['But the *Inca*', 3], ['turned whole *mountains*', 3], ['into giant', 2], ['*staircases of fields*', 3]],
  [['These *terraces*', 2], ['are called', 2], ['*andenes*', 1]],
  [['Each *step*', 2], ['was held up', 3], ['by a *stone wall*', 4], ['built', 1], ['*without mortar*', 2]],
  [['Behind the wall', 3], ['builders packed', 2], ['*layers*', 1], ['with *big stones*', 3], ['at the bottom', 3]],
  [['Then a layer', 3], ['of *gravel* and *sand*', 4]],
  [['And on top', 3], ['*rich soil*', 2], ['for the crops', 3]],
  [['When *heavy rain* fell', 4], ['water *drained down*', 3], ['through the stones', 3], ['instead of *washing*', 3], ['the hill away', 3]],
  [['The stone walls', 3], ['may have', 2], ['*soaked up heat*', 3], ['by day', 2], ['helping *protect crops*', 3], ['from *frost* at night', 4]],
  [['*Flat steps*', 2], ['also meant', 2], ['*more land* to plant', 4], ['and less soil', 3], ['*sliding away*', 2]],
  [['At *Moray*', 2], ['*circular terraces*', 2], ['sink deep', 2], ['into the ground', 3], ['like a *giant bowl*', 4]],
  [['From top to bottom', 4], ['the temperature', 2], ['can differ', 2], ['by up to', 3], ['*15 degrees*', 2], ['and some think', 3], ['the Inca used it', 4], ['to *test crops*', 3]],
  [['Many terraces', 2], ['are *still farmed*', 3], ['*today*', 1], ['more than', 2], ['*500 years* later', 4]],
  [['*Mountains*', 1], ['turned into *farms*', 3], ['one *stone step*', 3], ['at a time', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function andes(makeStage, { preset = 'day', sunDir = [-0.5, 0.6, 0.6], shadowSize = 40, fog = 0.003, shadowAt = [0, 8, 0], ground = true } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt, envI: 0.9 });
  if (ground) { const g = new THREE.Mesh(new THREE.CircleGeometry(400, 48), incaMats().slope); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; scene.add(g); }
  scene.add(mountains({ rMin: 110, rMax: 320, height: 90, seed: 5, color: 0x5a6a4a }));
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xfff0e0);
  return scene;
}
const hill = (scene, o = {}) => { const H = terracedHill(o); scene.add(H); return H; };
function secStage(makeStage) {
  const scene = makeStage({ shadowSize: 4, sunDir: [-2, 5, 4], sun: 2.2 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x3a5a8a); u.mid.value.set(0x6a8aaa); u.horizon.value.set(0x9ab0c0); u.floorC.value.set(0x4a5a3a);
  const S = terraceSection(); scene.add(S);
  fillLight(scene, [0.4, 0.3, 1], 0.9);
  return { scene, S };
}

// ============ S0: a mountainside too steep to stand on ============
function sHook({ makeStage }) {
  const scene = andes(makeStage, { sunDir: [-0.6, 0.45, 0.5] });
  const S = steepSlope(); scene.add(S);
  const man = quechua(0); man.root.position.set(0, 0.4, 0); man.root.rotation.x = -0.25; scene.add(man.root);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      standPose(man, t, { spine: [0.5, 0, 0], lSh: [-1.4, 0, 0.6], rSh: [-1.4, 0, -0.6], lHip: [-0.6, 0, 0.1], rHip: [0.2, 0, -0.1] }); man.setMood('happy'); man.setMouth(0.3);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(8, 6, k), lerp(2, 3, k), lerp(10, 8, k)], [0, lerp(1.5, 3, k), lerp(0, -4, k)]);
      return { bloom: 0.5, warm: 1.1 };
    },
  };
}
// ============ S1: whole mountains turned into staircases of fields ============
function sStair({ makeStage }) {
  const scene = andes(makeStage, { sunDir: [-0.5, 0.5, 0.7] });
  hill(scene);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-30, -18, k), lerp(14, 24, k), lerp(70, 62, k)], [0, lerp(8, 12, k), 0]);
      return { bloom: 0.55, flare: 0.7, warm: 1.15 };
    },
  };
}
// ============ S2: andenes: close along the curving steps ============
function sAndenes({ makeStage }) {
  const scene = andes(makeStage, { sunDir: [-0.5, 0.5, 0.7] });
  hill(scene);
  const ppl = [quechua(1), quechua(2)]; ppl.forEach((e, i) => { const r = 40 - (3 + i) * 2.6 - 1.2, a = 0.25 + i * 0.12; e.root.position.set(Math.sin(a) * r, (3 + i) * 1.6 + 1.6, Math.cos(a) * r); e.root.rotation.y = a; scene.add(e.root); });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      ppl.forEach((e, i) => { standPose(e, t + i, { spine: [0.4, 0, 0], lSh: [-1.0, 0, 0.2], rSh: [-1.0, 0, -0.2] }); e.setMood('happy'); e.setMouth(0); });
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(16, 14, k), lerp(10, 9, k), lerp(42, 40, k)], [6, 7, 30]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S3: each step held by a dry stone wall ============
function sWall({ makeStage }) {
  const scene = andes(makeStage, { sunDir: [0.3, 0.5, 0.8], shadowSize: 15, shadowAt: [0, 4, 36] });
  hill(scene);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(-4, 4, k), lerp(3.4, 4.0, k), lerp(52, 50, k)], [lerp(-2, 2, k), 3.0, 37]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S4/S5/S6: the layers behind the wall ============
function layerShot(from, to) {
  return ({ makeStage }) => {
    const { scene, S } = secStage(makeStage);
    const c = cam(38);
    return {
      scene, camera: c,
      update(t) {
        S.setLayers(lerp(from, to, easeInOut(range(t, 0.4, 2.2))));
        const k = easeInOut(range(t, 0, 4));
        place(c, [lerp(1.5, 2.2, k), lerp(2.6, 2.9, k), lerp(8.5, 8.0, k)], [-1.2, 1.5, 0]);
        return { bloom: 0.5, warm: 1.1 };
      },
    };
  };
}
const sStones = layerShot(0, 1), sGravel = layerShot(1, 2), sSoil = layerShot(2, 4);
// ============ S7: heavy rain drains down through the stones ============
function sRain({ makeStage }) {
  const { scene, S } = secStage(makeStage);
  const drops = [...Array(60)].map(() => { const d = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.25, 4), new THREE.MeshBasicMaterial({ color: 0xbfe0ff, transparent: true, opacity: 0.7 })); scene.add(d); return d; });
  const flow = [...Array(30)].map(() => { const s = glowSprite(0x5ab0ff, 0.25); scene.add(s); return s; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      drops.forEach((d, i) => { const u = (t * 1.6 + i / 60) % 1; d.position.set(-4 + ((i * 37) % 60) / 60 * 6, 7 - u * 4, -1 + (i % 7) * 0.3); });
      flow.forEach((s, i) => { const u = (t * 0.35 + i / 30) % 1; const x = -0.8 - ((i * 13) % 30) / 30 * 3; s.position.set(u < 0.6 ? x : x + (u - 0.6) / 0.4 * (0.8 - x + 1.2), u < 0.6 ? 3.0 - u / 0.6 * 2.6 : 0.4, 1.55); s.material.opacity = 0.8; });
      place(c, [2.0, 2.6, 8.0], [-1.2, 1.5, 0]);
      return { bloom: 0.55, warm: 0.95 };
    },
  };
}
// ============ S8: walls store the day's heat; frosty night, crops stay safe ============
function sFrost({ makeStage, start: ST }) {
  const tN = at(8, 'night') - ST;
  const scene = andes(makeStage, { preset: 'day', sunDir: [0.3, 0.5, 0.8], shadowSize: 15, shadowAt: [0, 4, 36] });
  const H = hill(scene); const W = incaMats().wall.clone(); H.traverse(o => { if (o.material === incaMats().wall) o.material = W; }); const glow = new THREE.Color(0xff6a20);
  const sparkle = [...Array(40)].map(() => { const s = glowSprite(0xdff4ff, 0.25); scene.add(s); return s; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const n = easeInOut(range(t, tN - 1.5, tN)); W.emissive = glow; W.emissiveIntensity = 0.25 * (1 - Math.abs(n - 0.5) * 2) + 0.15 * n;
      sparkle.forEach((s, i) => { s.position.set(-6 + ((i * 37) % 40) / 40 * 12, 1.5 + (i % 5) * 1.6 + Math.sin(t + i) * 0.1, 30 + (i % 7)); s.material.opacity = n * (0.5 + 0.5 * Math.sin(t * 5 + i)); });
      place(c, [lerp(2, -2, easeInOut(range(t, 0, 5.5))), 4, 50], [0, 3, 36]);
      return { bloom: 0.55 + n * 0.2, warm: lerp(1.15, 0.6, n), exposure: lerp(1, 0.45, n) };
    },
  };
}
// ============ S9: flat steps: more land, no sliding soil ============
function sFlat({ makeStage }) {
  const scene = andes(makeStage, { sunDir: [-0.5, 0.6, 0.6] });
  hill(scene);
  const ppl = [0, 1, 2].map(i => { const e = quechua(i); const r = 40 - (1 + i) * 2.6 - 1.2, a = -0.3 + i * 0.25; e.root.position.set(Math.sin(a) * r, (1 + i) * 1.6 + 1.6, Math.cos(a) * r); e.root.rotation.y = a + Math.PI; scene.add(e.root); return e; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      ppl.forEach((e, i) => { const sw = Math.sin(t * 3 + i); standPose(e, t + i, { spine: [0.6, 0, 0], lSh: [-1.5 + sw * 0.4, 0, 0.2], rSh: [-1.5 + sw * 0.4, 0, -0.2] }); e.setMood('happy'); e.setMouth(0); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(10, 4, k), lerp(9, 8, k), lerp(52, 48, k)], [0, 4, 34]);
      return { bloom: 0.55, warm: 1.15 };
    },
  };
}
// ============ S10: Moray: circular terraces like a giant bowl ============
function sMoray({ makeStage }) {
  const scene = andes(makeStage, { sunDir: [-0.5, 0.6, 0.6], shadowSize: 40, shadowAt: [0, -6, 0], ground: false });
  const M = moray(); M.position.y = 0.2; scene.add(M);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const a = lerp(0.3, 1.0, easeInOut(range(t, 0, 4.8)));
      place(c, [Math.sin(a) * 50, lerp(36, 28, easeInOut(range(t, 0, 4.8))), Math.cos(a) * 50], [0, -8, 0]);
      return { bloom: 0.55, flare: 0.7, warm: 1.15 };
    },
  };
}
// ============ S11: up to 15 degrees warmer at the bottom: colour gradient, crops tested ============
function sTemp({ makeStage }) {
  const scene = andes(makeStage, { sunDir: [-0.5, 0.6, 0.6], shadowSize: 40, shadowAt: [0, -6, 0], ground: false });
  const M = moray(); M.position.y = 0.2; scene.add(M);
  const heat = [...Array(9)].map((_, i) => { const r = new THREE.Mesh(new THREE.TorusGeometry(30 - i * 2.4 - 1.2, 0.25, 6, 72), new THREE.MeshBasicMaterial({ color: new THREE.Color().setHSL(0.6 - i * 0.065, 0.9, 0.55), transparent: true, opacity: 0, toneMapped: false })); r.rotation.x = Math.PI / 2; r.position.y = 0.2 - i * 1.4 - 1.3; scene.add(r); return r; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      heat.forEach((r, i) => { r.material.opacity = 0.9 * easeOut(range(t, 0.3 + i * 0.25, 0.8 + i * 0.25)); });
      const k = easeInOut(range(t, 0, 7));
      place(c, [lerp(14, 6, k), lerp(26, 16, k), lerp(40, 30, k)], [0, -9, 0]);
      return { bloom: 0.65, warm: 1.1 };
    },
  };
}
// ============ S12: still farmed today ============
function sToday({ makeStage }) {
  const scene = andes(makeStage, { preset: 'golden', sunDir: [0.6, 0.35, 0.7] });
  hill(scene);
  const ppl = [quechua(0), quechua(2, { kid: true })]; ppl.forEach((e, i) => { const r = 40 - 2.6 - 1.0, a = 0.05 + i * 0.05; e.root.position.set(Math.sin(a) * r, 2 * 1.6 + 0.0, Math.cos(a) * r); e.root.rotation.y = a; scene.add(e.root); });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      ppl.forEach((e, i) => { standPose(e, t + i, { head: [0, 0.2 * (i ? -1 : 1), 0] }); e.setMood('happy'); e.setMouth(0); e.blink(blinkK(t + i, [1.2, 3.0])); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(3, 2, k), lerp(5, 4.6, k), lerp(46, 44, k)], [1.2, 4, 36]);
      return { bloom: 0.6, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S13: sunset over the terraced mountain ============
function sEnd({ makeStage }) {
  const scene = andes(makeStage, { preset: 'golden', sunDir: [0.75, 0.15, -0.6] });
  hill(scene);
  const b = birds(4, { from: [-30, 26, 20], to: [30, 30, 10], spread: 6, speed: 0.05, scale: 2, seed: 8 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.2));
      place(c, [lerp(10, 26, k), lerp(10, 26, k), lerp(56, 76, k)], [0, lerp(8, 12, k), 0]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sStair], [ls(2), ls(3), sAndenes], [ls(3), ls(4), sWall], [ls(4), ls(5), sStones],
  [ls(5), ls(6), sGravel], [ls(6), ls(7), sSoil], [ls(7), ls(8), sRain], [ls(8), ls(9), sFrost], [ls(9), ls(10), sFlat],
  [ls(10), ls(11), sMoray], [ls(11), ls(12), sTemp], [ls(12), ls(13), sToday], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
