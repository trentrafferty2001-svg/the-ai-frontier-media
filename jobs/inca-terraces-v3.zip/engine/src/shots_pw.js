// Polynesian wayfinding reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, V, cam, place, shake } from './anim.js';
import { shadowAll } from './rome.js';
import { sea, rideWaves } from './norse.js';
import { canoe, polynesian, starSky, starCompass, island, cumulus } from './pacific.js';
import { VO } from './vo_pw.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['If you sailed into', 4], ['the *open Pacific*', 3], ['with *no map*', 3], ['*no compass*', 2], ['and *no land*', 3], ['in sight', 2], ['could you find', 3], ['a *tiny island?*', 3]],
  [['*Polynesian*', 1], ['*navigators*', 1], ['did it', 2], ['for *centuries*', 2]],
  [['They found', 2], ['and *settled*', 2], ['islands across', 2], ['the *Pacific*', 2], ['from *Hawaii*', 2], ['to *New Zealand*', 3], ['to *Rapa Nui*', 3]],
  [['Their canoes', 2], ['were big', 2], ['*double hulled*', 2], ['boats', 1], ['strong enough', 2], ['for *weeks at sea*', 4]],
  [['And they *steered*', 3], ['by *nature*', 2]],
  [['At *night*', 2], ['they *memorized*', 2], ['where dozens', 2], ['of *stars*', 2], ['*rise* and *set*', 3], ['on the *horizon*', 3]],
  [['It worked', 2], ['like a *compass*', 3], ['made of *stars*', 3]],
  [['By *day*', 2], ['they *felt*', 2], ['the *ocean swells*', 3], ['rolling under', 2], ['the *hull*', 2], ['to hold', 2], ['their *course*', 2]],
  [['Near *land*', 2], ['they watched', 2], ['for *seabirds*', 2], ['like *fairy terns*', 3], ['which fly out', 3], ['to *fish*', 2], ['and *return*', 2], ['to *islands*', 2]],
  [['*Clouds* piling up', 3], ['on the *horizon*', 3], ['could also hint', 3], ['at *hidden land*', 3]],
  [['Over time', 2], ['much of', 2], ['this *knowledge*', 2], ['almost *disappeared*', 2]],
  [['Then in *1976*', 5], ['a *master navigator*', 3], ['named', 1], ['*Mau Piailug*', 2], ['guided the canoe', 3], ['*Hōkūleʻa*', 1], ['from *Hawaii*', 2], ['to *Tahiti*', 2], ['with *no instruments*', 3]],
  [['*17,000* people', 3], ['were *waiting*', 2], ['when it *arrived*', 3]],
  [['Today', 1], ['a *new generation*', 3], ['of *wayfinders*', 2], ['still sails', 2], ['by the *stars*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ============ shared: open tropical ocean with the voyaging canoe ============
function ocean(makeStage, { preset = 'tropic', sunDir = [-0.5, 0.5, 0.7], fog = 0.004, waves = 0.9, crew = 3, color = 0x1f5a8a, ...o } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize: 12, shadowAt: [0, 1, 0], envI: 0.9, ...o });
  const S = sea(scene, { scale: waves, color });
  const boat = canoe(); scene.add(boat);
  const men = [[3.5, 0.6, 0], [0.5, -0.8, 1], [-4.2, 0.5, 2]].slice(0, crew).map(([x, z, i]) => { const p = polynesian(i); p.root.position.set(x, 0.93, z); p.root.rotation.y = Math.PI / 2; boat.add(p.root); return p; });
  fillLight(scene, [0.4, 0.5, 1], 0.5);
  return { scene, boat, men, waves };
}
const idle = (men, t) => men.forEach((m, i) => { standPose(m, t + i, {}); m.setMood('happy'); m.setMouth(0); m.blink(blinkK(t + i, [1.4, 3.6])); });

// ============ S0: the canoe alone on an empty ocean ============
function sAlone({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [0.3, 0.45, -0.84] });
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, t * 1.2, 0, 0, T, O.waves); idle(O.men, t);
      const k = easeInOut(range(t, 0, 7.2));
      place(c, [t * 1.2 + lerp(-50, -28, k), lerp(34, 12, k), lerp(40, 26, k)], [t * 1.2 + 2, 2, 0]);
      return { bloom: 0.55, flare: 0.8, warm: 1.1 };
    },
  };
}
// ============ S1: the navigator at the bow, looking ahead ============
function sNav({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [0.4, 0.4, -0.82] });
  const nav = O.men[0];
  const c = cam(34);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, 0, 0, 0, T, O.waves); idle(O.men.slice(1), t);
      standPose(nav, t, { head: [-0.1, 0, 0], lSh: [-0.4, 0, 0.3] }); nav.setMood('happy'); nav.setMouth(0); nav.blink(blinkK(t, [1.4]));
      O.scene.updateMatrixWorld(true); const hp = wpos(nav.j.head, V(0, 0, 0));
      const k = easeInOut(range(t, 0, 2.8));
      place(c, [hp.x + lerp(2.4, 1.8, k), hp.y + lerp(-0.2, -0.3, k), hp.z + lerp(1.6, 1.2, k)], [hp.x - 1.5, hp.y + 0.1, hp.z - 0.4]);
      return { bloom: 0.6, flare: 0.8, warm: 1.15, dof: dofTo([hp.x + 2, hp.y - 0.25, hp.z + 1.4], [hp.x, hp.y, hp.z], 0.003, 0.009) };
    },
  };
}
// ============ S2: a flyover past Hawaii, New Zealand and Rapa Nui (three islands in a row) ============
function sIslands({ makeStage, start: ST }) {
  const tH = at(2, 'hawaii') - ST, tN = at(2, 'new') - ST, tR = at(2, 'rapa') - ST;
  const scene = makeStage({ outdoor: 'tropic', sunDir: [-0.5, 0.5, 0.7], fog: 0.0035, shadowSize: 30, envI: 0.9 });
  sea(scene, { scale: 0.7, color: 0x1f5a8a });
  const I = [island({ kind: 'volcanic', seed: 3 }), island({ kind: 'hills', seed: 5 }), island({ kind: 'rapanui', seed: 7 })];
  I.forEach((g, i) => { g.position.set(i * 90, 0, 0); scene.add(g); });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const x = kf(t, [[0, -20], [tH + 0.3, 0], [tN + 0.2, 90], [tR + 0.3, 180], [6, 190]], easeInOut);
      place(c, [x - 30, 34, 55], [x, 4, 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
// ============ S3: the double-hulled canoe close, sails full ============
function sCanoe({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [-0.6, 0.45, 0.66] });
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, t * 1.5, 0, 0, T, O.waves); idle(O.men, t);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [t * 1.5 + lerp(14, 6, k), lerp(1.5, 3.5, k), lerp(9, 13, k)], [t * 1.5 - 1, 2.6, 0]);
      return { bloom: 0.55, flare: 0.7, warm: 1.15 };
    },
  };
}
// ============ S4: golden light, the navigator sits quietly reading the sea ============
function sNature({ makeStage }) {
  const O = ocean(makeStage, { preset: 'golden', sunDir: [0.5, 0.12, -0.86], color: 0x2a4a6a });
  const nav = O.men[0];
  const c = cam(36);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, 0, 0, 0, T, O.waves); idle(O.men.slice(1), t);
      standPose(nav, t, { lSh: [-0.2, 0, 0.15], rSh: [-0.5, 0, -0.2], rEl: [-0.6, 0, 0], head: [0.05, 0.25, 0] }); nav.setMood('happy'); nav.setMouth(0); nav.blink(0.9);
      O.scene.updateMatrixWorld(true); const hp = wpos(nav.j.head, V(0, 0, 0));
      place(c, [hp.x + 3.2, hp.y + 0.4, hp.z + 2.6], [hp.x, hp.y - 0.2, hp.z]);
      return { bloom: 0.7, flare: 1.0, warm: 1.35 };
    },
  };
}
// ============ S5/S6: night: stars rise on the horizon; the star compass ring appears around the canoe ============
function nightStage(makeStage) {
  const O = ocean(makeStage, { preset: 'pnight', sunDir: [-0.3, 0.4, -0.86], fog: 0.004, color: 0x14284a, envI: 0.5, hemi: 0.35 });
  const sky = starSky(); O.scene.add(sky);
  const moonLight = new THREE.DirectionalLight(0xb8c8ff, 1.6); moonLight.position.set(-6, 5, -3); O.scene.add(moonLight);
  const fillN = new THREE.DirectionalLight(0x6a80c0, 0.6); fillN.position.set(8, 3, 4); O.scene.add(fillN);
  sky.bright.forEach(s => s.scale.setScalar(s.scale.x * 0.45));
  return { ...O, sky };
}
function sStars({ makeStage }) {
  const N = nightStage(makeStage);
  const nav = N.men[0];
  const c = cam(38);
  return {
    scene: N.scene, camera: c,
    update(t, T) {
      rideWaves(N.boat, 0, 0, 0, T, N.waves); idle(N.men.slice(1), t);
      standPose(nav, t, { rSh: [-1.9, 0, -0.25], rEl: [-0.1, 0, 0], neck: [-0.15, 0, 0], head: [-0.15, 0.1, 0] }); nav.setMood('happy'); nav.setMouth(0);
      // bright stars climb out of the sea on slanted paths, the way they rise on the horizon
      N.sky.bright.forEach((s, i) => { const a = (i / 12) * 0.5 - 0.1 + (i % 2) * 0.03, h = ((t * 2.2 + i * 9) % 34) - 3; s.position.set(Math.cos(a) * 235 - h * 0.35, h, Math.sin(a) * 235); s.material.opacity = i < 6 ? Math.min(1, Math.max(0, (h + 1) / 4)) : 0; });
      N.scene.updateMatrixWorld(true); const hp = wpos(nav.j.head, V(0, 0, 0));
      const k = easeInOut(range(t, 0, 4.9));
      place(c, [hp.x + lerp(-2.0, -2.8, k), hp.y + lerp(0.12, 0.3, k), hp.z + 0.35], [hp.x + 40, hp.y + lerp(5, 6.5, k), hp.z]);
      return { bloom: 0.9, warm: 0.4, exposure: 1.9, sat: 0.95 };
    },
  };
}
function sCompass({ makeStage }) {
  const N = nightStage(makeStage);
  const ring = starCompass(14); ring.position.y = 0.4; N.scene.add(ring);
  const c = cam(44);
  return {
    scene: N.scene, camera: c,
    update(t, T) {
      rideWaves(N.boat, 0, 0, 0, T, N.waves); idle(N.men, t);
      ring.set(easeOut(range(t, 0.1, 1.6)));
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(12, 4, k), lerp(22, 34, k), lerp(26, 10, k)], [0, 0, 0]);
      return { bloom: 0.9, warm: 0.5, exposure: 1.4 };
    },
  };
}
// ============ S7: daytime swells, the navigator kneels with a hand on the hull ============
function sSwell({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [-0.5, 0.55, 0.66], waves: 1.25 });
  const nav = O.men[0];
  const c = cam(36);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, t * 1.0, 0, 0, T, O.waves); idle(O.men.slice(1), t);
      standPose(nav, t, { lSh: [-0.3, 0, 0.5], rSh: [-0.3, 0, -0.5], lHip: [-0.15, 0, 0.12], rHip: [0.1, 0, -0.12], lKn: [0.25, 0, 0], rKn: [0.15, 0, 0], head: [0.25, 0, 0] }); nav.setMood('happy'); nav.setMouth(0); nav.blink(blinkK(t, [1.2, 3.4]));
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [t * 1.0 + lerp(6.5, 4.5, k), lerp(2.3, 2.6, k), lerp(8.5, 7.5, k)], [t * 1.0 + 3.3, 1.7, 0.4]);
      return { bloom: 0.5, warm: 1.1 };
    },
  };
}
// ============ S8: fairy terns fly over the canoe toward an island at dusk ============
function sTerns({ makeStage }) {
  const O = ocean(makeStage, { preset: 'golden', sunDir: [-0.75, 0.32, -0.2], color: 0x2a4a6a });
  const I = island({ kind: 'volcanic', seed: 9, s: 0.8 }); I.position.set(40, 0, -150); O.scene.add(I);
  const b = birds(8, { from: [-8, 6, 6], to: [26, 9, -50], spread: 3, speed: 0.13, scale: 1.3, seed: 6 }); O.scene.add(b); O.scene.userData.updaters.push((t) => b.update(t));
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, 0, 0, -0.3, T, O.waves); idle(O.men, t);
      const k = easeInOut(range(t, 0, 6));
      place(c, [lerp(-9, -7, k), lerp(3.2, 4, k), lerp(12, 10, k)], [lerp(8, 22, k), lerp(6, 7, k), lerp(-10, -50, k)]);
      return { bloom: 0.5, flare: 0.3, warm: 1.25 };
    },
  };
}
// ============ S9: cumulus clouds piling over a hidden island beyond the horizon ============
function sClouds({ makeStage }) {
  const O = ocean(makeStage, { sunDir: [-0.4, 0.55, 0.73] });
  const cl = cumulus(26, 5); cl.position.set(10, 0, -240); O.scene.add(cl);
  const c = cam(40);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, 0, 0, Math.PI / 2, T, O.waves); idle(O.men, t);
      cl.scale.y = lerp(0.7, 1.0, easeOut(range(t, 0, 3.5)));
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-4, -3, k), lerp(4, 3.4, k), lerp(14, 12, k)], [lerp(4, 8, k), lerp(5, 10, k), -120]);
      return { bloom: 0.55, warm: 1.0 };
    },
  };
}
// ============ S10: an old canoe hull rotting under palms on a quiet beach ============
function sForgot({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.25, 0.6], fog: 0.005, shadowSize: 12, shadowAt: [-2, 0, -8], envI: 0.7 });
  sea(scene, { scale: 0.4, color: 0x2a4a6a });
  const I = island({ kind: 'hills', seed: 13, s: 1 }); I.position.set(0, 0, -22); scene.add(I);
  const old = canoe(); old.scale.setScalar(0.45); old.position.set(-1, 0.35, -9.5); old.rotation.set(0.04, 0.35, 0.1); old.sails.forEach(s => s.visible = false);
  old.traverse(o => { if (o.isMesh && o.material && o.material.color) { o.material = o.material.clone(); o.material.color.multiplyScalar(0.7); } });
  scene.add(old);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(5, 3, k), lerp(2.6, 2.0, k), lerp(4, 1, k)], [-1, 0.8, -10]);
      return { bloom: 0.45, warm: 0.9, sat: 0.65 };
    },
  };
}
// ============ S11: 1976: Mau at the stern at dawn; Hōkūleʻa sails for Tahiti ============
function sMau({ makeStage, start: ST }) {
  const tHk = at(11, 'hokulea') - ST;
  const O = ocean(makeStage, { preset: 'golden', sunDir: [-0.6, 0.15, -0.78] });
  const mau = O.men[2];
  mau.j.chest.children.forEach(o => { if (o.isMesh && o.geometry.type === 'TorusGeometry') o.visible = false; });
  mau.j.head.children.forEach(o => { if (o.isMesh && o.geometry.type === 'SphereGeometry' && o.position.z < -0.1) o.visible = false; }); // no hair bun
  mau.root.traverse(o => { if (o.isMesh && o.material && o.material.color && o.material.color.getHex() === 0xd89a2a) { o.material = o.material.clone(); o.material.color.set(0x7a2a1e); } });
  const c = cam(36);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, t * 1.4, 0, 0, T, O.waves); idle(O.men.slice(0, 2), t);
      standPose(mau, t, { lSh: [-0.25, 0, 0.12], lEl: [-0.35, 0, 0], head: [-0.05, 0.15, 0] }); mau.setMood('happy'); mau.setMouth(0); mau.blink(blinkK(t, [2.0, 5.0]));
      O.scene.updateMatrixWorld(true); const hp = wpos(mau.j.head, V(0, 0, 0));
      const f = easeInOut(range(t, tHk - 0.6, tHk + 1.2));
      const close = [hp.x + 0.6 + t * 0.04, hp.y - 0.12, hp.z + 2.5], wide = [t * 1.4 - 22, 9, 26];
      const pos = close.map((v, i) => lerp(v, wide[i], f)); pos[1] += Math.sin(f * Math.PI) * 4; pos[2] += Math.sin(f * Math.PI) * 3;
      const look = [lerp(hp.x, t * 1.4, f), lerp(hp.y - 0.1, 3, f), lerp(hp.z, 0, f)];
      place(c, pos, look);
      return { bloom: 0.5, flare: 0.5, warm: 1.25, dof: f < 0.5 ? dofTo(pos, [hp.x, hp.y, hp.z], 0.002, 0.008) : undefined };
    },
  };
}
// ============ S12: a crowd waits on the beach as the canoe arrives ============
function sCrowd({ makeStage }) {
  const scene = makeStage({ outdoor: 'tropic', sunDir: [-0.4, 0.55, 0.73], fog: 0.004, shadowSize: 16, shadowAt: [0, 0, 15], envI: 0.9 });
  sea(scene, { scale: 0.5, color: 0x1f6a8a });
  const I = island({ kind: 'hills', seed: 15, s: 1.4 }); I.position.set(0, 0, -4); scene.add(I);
  I.children.forEach(ch => { if (ch.position.z * 1.4 - 4 > 4) ch.visible = ch.geometry && ch.geometry.type !== undefined && !ch.isGroup ? ch.visible : false; });
  const boat = canoe(); boat.position.set(0, 0, 46); boat.rotation.y = Math.PI / 2; scene.add(boat);
  const people = [];
  for (let i = 0; i < 45; i++) { const row = Math.floor(i / 15), col = i % 15; const p = polynesian(i, { kid: i % 6 === 0 }); p.root.position.set(-13 + col * 1.85 + (row % 2) * 0.9 + Math.sin(i * 7.3) * 0.3, 0.4, 15.8 - row * 1.5 + Math.cos(i * 3.1) * 0.25); p.root.rotation.y = Math.sin(i * 1.7) * 0.25; scene.add(p.root); people.push(p); }
  const c = cam(40);
  return {
    scene, camera: c,
    update(t, T) {
      rideWaves(boat, 0, lerp(52, 34, easeOut(range(t, 0, 3.4))), Math.PI / 2, T, 0.5); boat.position.y -= 0.12;
      people.forEach((p, i) => { const w = Math.sin(t * 6 + i) * 0.4; standPose(p, t + i, { rSh: i % 3 ? [-2.6 + w, 0, -0.3 - (i % 3) * 0.1] : [-0.2, 0, -0.1] }); p.setMood('happy'); p.setMouth(0); });
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(-2.5, -1, k), lerp(3.0, 2.6, k), lerp(9.0, 10.0, k)], [0, lerp(1.6, 1.9, k), 40]);
      return { bloom: 0.5, flare: 0.4, warm: 1.15 };
    },
  };
}
// ============ S13: sunset into night, young wayfinders on deck as the first stars appear ============
function sEnd({ makeStage }) {
  const O = ocean(makeStage, { preset: 'golden', sunDir: [0.7, 0.1, -0.7], color: 0x2a3a5a });
  const sky = starSky(900, 9); O.scene.add(sky);
  const kid = polynesian(4, { kid: true }); kid.root.position.set(2.6, 0.93, 0.8); kid.root.rotation.y = Math.PI / 2 - 0.3; O.boat.add(kid.root);
  const c = cam(38);
  return {
    scene: O.scene, camera: c,
    update(t, T) {
      rideWaves(O.boat, 0, 0, 0, T, O.waves); idle(O.men, t);
      standPose(kid, t, { rSh: [-2.4, 0, -0.2], head: [-0.4, 0.2, 0], neck: [-0.2, 0, 0] }); kid.setMood('happy'); kid.setMouth(0);
      sky.children[0].material.opacity = easeIn(range(t, 0.5, 5)) * 0.9; sky.bright.forEach(s => s.material.opacity = easeIn(range(t, 1, 5)));
      const k = easeInOut(range(t, 0, 5.6));
      place(c, [lerp(-6, -12, k), lerp(2.5, 6, k), lerp(8, 14, k)], [2, lerp(3, 6, k), -2]);
      return { bloom: 0.38, flare: 0.3, warm: 1.2, exposure: 0.92 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sAlone], [ls(1), ls(2), sNav], [ls(2), ls(3), sIslands], [ls(3), ls(4), sCanoe], [ls(4), ls(5), sNature],
  [ls(5), ls(6), sStars], [ls(6), ls(7), sCompass], [ls(7), ls(8), sSwell], [ls(8), ls(9), sTerns], [ls(9), ls(10), sClouds],
  [ls(10), ls(11), sForgot], [ls(11), ls(12), sMau], [ls(12), ls(13), sCrowd], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
