// Style demo (v2 look): a farmer hauls a shaduf bucket into the Nile, lets go, and the mud counterweight lifts it.
// 7.5 s, 30 fps, motion blur. Every function of time here is pure: tables are computed once when a shot is built.
import * as THREE from 'three';
import { V, cam, place, clamp, lerp, smooth, easeInOut, range, springKeys, spring, handheld, camPath, noise1 } from './anim.js';
import { toon } from './toon.js';
import { birds } from './world.js';
import { LAND, WY, PIV, ROPE, PLAT, terrain, platform, shaduf, tipAt, grass, papyrus, palm, hut, jar, heightAt, rng } from './nile.js';
import { waterMaterial } from './world.js';
import { VO } from './vo_dm.js';

export const STYLE = { shadow: 'pcf', mb: 6, shutter: 0.5 };
const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z]/g, '') === word)[k][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(1) + 0.7) * 30) / 30;

const CHUNKS = [
  [['How do you', 3], ['*lift water*', 2], ['out of a *river*', 4], ['*all day*', 2], ['with just', 2], ['your *arms?*', 2]],
  [['But on', 2], ['the *Nile*', 2], ['a *lump*', 2], ['of *mud*', 2], ['did the', 2], ['*lifting*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ================= the action, as functions of global time =================
const CUT = VO[1].words[0][1] - 0.2;          // cut just before "But"
const T_REL = at(1, 'nile') + 0.3;             // he lets go at the end of "Nile"
const A_EQ = -0.3;                              // resting angle once the full bucket is up
// pole angle while hauling: spring-driven keys (heavy, little overshoot), a small lift before the first heave
const HAUL = [[0, -0.05], [0.12, -0.1], [0.32, 0.08], [0.72, 0.28], [1.1, 0.48], [1.45, 0.63], [T_REL - 0.45, 0.68]];
const A1 = (t) => springKeys(t, HAUL, 1.1, 0.9);
const A_R = A1(T_REL);
export function poleA(t) { return t < T_REL ? A1(t) : A_R + (A_EQ - A_R) * spring(t - T_REL, 0.42, 0.42); }
// times the bucket bottom crosses the water (in) and leaves it (out): bottom = tip.y - 2.455
const bottomY = (t) => tipAt(poleA(t)).y - (ROPE + 0.21 + 0.345);
function crossing(t0, t1, down) { let prev = bottomY(t0); for (let t = t0; t <= t1; t += 0.001) { const y = bottomY(t); if (down ? (prev >= WY && y < WY) : (prev <= WY && y > WY)) return t; prev = y; } return null; }
export const T_SPLASH = crossing(0, CUT, true);
export const T_OUT = crossing(T_REL, DURATION, false);
const rimUnder = (t) => tipAt(poleA(t)).y - (ROPE + 0.21) < WY - 0.02;
// bucket pendulum, simulated once at 1 kHz: driven by the tip's acceleration, damped by the farmer's grip while he
// holds the rope and heavily by the water while the bucket is under. phi = swing towards +z, psi = sideways (wind).
const PEND = (() => {
  const dt = 0.001, t0 = -1, n = Math.ceil((DURATION + 1.5 - t0) / dt), L = ROPE + 0.21;
  const tabA = new Float32Array(n), tabB = new Float32Array(n);
  let phi = 0, w = 0, psi = 0, wp = 0, maxHaul = 0, maxFree = 0;
  const tipT = (t) => tipAt(poleA(Math.max(0, t)));
  for (let i = 0; i < n; i++) {
    const t = t0 + i * dt, h = 0.002;
    const p0 = tipT(t - h), p1 = tipT(t), p2 = tipT(t + h);
    const ay = (p2.y - 2 * p1.y + p0.y) / (h * h), az = (p2.z - 2 * p1.z + p0.z) / (h * h);
    const sub = clamp((WY + 0.3 - bottomY(Math.max(0, t))) / 0.3);
    const c = (t < T_REL ? 3.0 : 0.7) + 9 * sub;
    const geff = 9.8 + ay;
    w += (-(geff / L) * Math.sin(phi) - (az / L) * Math.cos(phi) - c * w) * dt; phi += w * dt;
    const wind = noise1(t * 0.5, 12) * 0.25;
    wp += (-(geff / L) * Math.sin(psi) + wind / L - c * wp) * dt; psi += wp * dt;
    tabA[i] = phi; tabB[i] = psi;
    if (t > 0 && t < T_REL) maxHaul = Math.max(maxHaul, Math.abs(phi)); else if (t >= T_REL) maxFree = Math.max(maxFree, Math.abs(phi));
  }
  console.warn(`[dm] bucket swing max: hauling ${(maxHaul * 57.3).toFixed(1)} deg, after release ${(maxFree * 57.3).toFixed(1)} deg`);
  return (t) => { const i = Math.max(0, Math.min(n - 1, Math.round((t - t0) / dt))); return [tabA[i], tabB[i]]; };
})();
const swingAt = (t) => PEND(t);
const fillAt = (t) => { if (t < T_SPLASH) return 0; const k = clamp((t - T_SPLASH) / 1.1); return rimUnder(t) || t > T_REL ? Math.max(k, t > T_REL ? 1 : 0) : k * 0.7; };

// farmer on the platform, facing -x (towards the rope)
const FPOS = V(0.5, PLAT.y, 2.02);
// hand-over-hand: each hand grips the rope at a fixed distance s below the tip, is pulled down, then lets go and
// reaches up to grab higher while the other hand holds. Simulated once at 500 Hz into a table.
const ropeDir = (sw) => new THREE.Vector3(Math.sin(sw[1]), -Math.cos(sw[1]) * Math.cos(sw[0]), Math.sin(sw[0])).normalize();
const ropePoint = (t, s) => tipAt(poleA(t)).addScaledVector(ropeDir(swingAt(t)), s);
const HI = 2.15, LO = 1.74, REACH = 0.24;
function simulateHands() {
  const dt = 0.002, N = Math.ceil(T_REL / dt) + 2; const tab = { l: [], r: [] };
  const st = { l: { mode: 'grip', s: 1.72, t0: 0 }, r: { mode: 'grip', s: 1.84, t0: 0 } }; // just above the bucket's bail
  for (let i = 0; i < N; i++) {
    const t = i * dt;
    for (const h of ['l', 'r']) {
      const o = h === 'l' ? 'r' : 'l'; const S = st[h];
      if (S.mode === 'grip') {
        const y = ropePoint(t, S.s).y;
        if (y < LO && st[o].mode === 'grip' && t - st[o].t0 > 0.06 && t < T_SPLASH + 1.0) { S.mode = 'reach'; S.from = ropePoint(t, S.s); S.t0 = t; S.sNew = Math.min(1.84, Math.max(0.25, tipAt(poleA(t + REACH)).y - HI)); }
        tab[h].push({ mode: 1, s: S.s, g: 1 });
      } else {
        const k = (t - S.t0) / REACH;
        if (k >= 1) { S.mode = 'grip'; S.s = S.sNew; S.t0 = t; tab[h].push({ mode: 1, s: S.s, g: 1 }); }
        else tab[h].push({ mode: 0, k, from: S.from, s: S.sNew, g: 0 });
      }
    }
  }
  return (h, t) => tab[h][Math.max(0, Math.min(tab[h].length - 1, Math.round(t / dt)))];
}

// ================= scene =================
function world(makeStage) {
  const sunDir = [-0.72, 0.36, 0.6];
  const scene = makeStage({ outdoor: 'golden', sunDir, fog: 0.0045, shadowSize: 6, shadowAt: [0.2, 1.6, 0.6], envI: 0.85, hemi: 0.3 });
  const key = scene.userData.key; key.shadow.mapSize.set(4096, 4096); key.shadow.radius = 2.2; key.shadow.bias = -0.0002; key.shadow.normalBias = 0.015;
  // soft bounce light from the river side + a cool rim from behind
  const fill = new THREE.DirectionalLight(0xffe2c0, 0.55); fill.position.set(3, 2, 6); scene.add(fill);
  const rim = new THREE.DirectionalLight(0xbfd4ff, 0.7); rim.position.set(2, 4, -6); scene.add(rim);
  scene.add(terrain());
  const water = new THREE.Mesh(new THREE.PlaneGeometry(420, 60, 1, 1), waterMaterial({ color: 0x35604f, opacity: 1, ripple: 1.0 })); water.rotation.x = -Math.PI / 2; water.position.set(0, WY, 28); water.receiveShadow = true; scene.add(water);
  scene.add(platform());
  const S = shaduf(); scene.add(S);
  // vegetation: grass on the top of the bank (kept off the posts, path and channel), papyrus at the waterline
  const r = rng(11); const gs = [];
  for (let i = 0; i < 3200; i++) {
    const x = (r() - 0.5) * 26, z = -r() * r() * 14 - 0.05;
    if (Math.abs(x) < 1.1 && z > -1.4) continue; if (Math.abs(x + 1.3) < 0.45) continue; if (x > 0.2 && x < 1.8 && z > -0.6) continue;
    const y = heightAt(x, z); if (y < LAND - 0.25) continue; gs.push([x, y - 0.01, z, 0.8 + r() * 0.6]);
  }
  scene.add(grass(gs, { h: 0.34, seed: 5 }));
  const ps = [];
  for (let c = 0; c < 26; c++) {
    let cx = (r() - 0.5) * 24; if (cx > -5.5 && cx < 2.6) cx = cx < -1.5 ? cx - 4 : cx + 3.2;
    const cz = 0.95 + r() * 0.8; const n = 6 + Math.floor(r() * 7);
    for (let k = 0; k < n; k++) { const x = cx + (r() - 0.5) * 0.7, z = cz + (r() - 0.5) * 0.5; ps.push([x, Math.min(WY, heightAt(x, z)) - 0.05, z, 0.8 + r() * 0.5]); }
  }
  scene.add(papyrus(ps, 21));
  // irrigation channel from the shaduf back to the fields
  const ch = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 18), waterMaterial({ color: 0x4a7a6a, opacity: 1, ripple: 0.6 })); ch.rotation.x = -Math.PI / 2; ch.position.set(-1.3, LAND - 0.04, -9.2); scene.add(ch);
  for (const s of [-1, 1]) { const b = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 18, 4, 8), new THREE.MeshStandardMaterial({ color: 0x8a6a46, roughness: 1 })); b.rotation.x = Math.PI / 2; b.scale.y = 0.6; b.position.set(-1.3 + s * 0.27, LAND - 0.02, -9.2); b.receiveShadow = true; scene.add(b); }
  const basin = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.4, 0.12, 24), new THREE.MeshStandardMaterial({ color: 0x8a6a46, roughness: 1 })); basin.position.set(-1.3, LAND - 0.02, -0.15); scene.add(basin);
  const bw = new THREE.Mesh(new THREE.CircleGeometry(0.36, 24), waterMaterial({ color: 0x4a7a6a, opacity: 1, ripple: 0.8 })); bw.rotation.x = -Math.PI / 2; bw.position.set(-1.3, LAND + 0.045, -0.15); scene.add(bw);
  // palms, hut, jars, far bank, distant pyramid in the haze
  [[-4.2, -5, 7.5, 3], [3.6, -7.5, 8.5, 4], [-8.5, -11, 7, 5], [7.5, -4.2, 6.5, 6], [1, -15, 9, 7], [-13, -6, 8, 8]].forEach(([x, z, h, sd]) => { const p = palm(h, sd); p.position.set(x, heightAt(x, z) - 0.05, z); scene.add(p); });
  for (let i = 0; i < 16; i++) { const x = -60 + i * 8 + (r() - 0.5) * 4, z = 54 + r() * 6; const p = palm(7 + r() * 3, 30 + i); p.position.set(x, heightAt(x, z) - 0.1, z); scene.add(p); }
  const H = hut(); H.position.set(-7.5, heightAt(-7.5, -9) - 0.05, -9); H.rotation.y = 0.5; scene.add(H);
  [[-2.05, -0.45, 0.55, 1], [-2.45, -0.75, 0.45, 2]].forEach(([x, z, h, sd]) => { const j = jar(h, sd); j.position.set(x, heightAt(x, z) - 0.02, z); scene.add(j); });
  return { scene, S, water };
}

// splash, ripples and drips
function effects(scene, S) {
  const g = new THREE.Group(); scene.add(g);
  // droplets: soft specular only (clearcoat sun glints on dozens of drops bloomed into a white haze)
  const dropM = new THREE.MeshStandardMaterial({ color: 0xcfe3e0, roughness: 0.3, metalness: 0, transparent: true, opacity: 0.7, envMapIntensity: 0.6 });
  const N = 150; const drops = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 10, 8), dropM, N); drops.frustumCulled = false; g.add(drops);
  const ND = 70; const drips = new THREE.InstancedMesh(new THREE.SphereGeometry(1, 8, 6), dropM, ND); drips.frustumCulled = false; g.add(drips);
  const r = rng(77); const SP = []; for (let i = 0; i < N; i++) { const a = r() * Math.PI * 2, sp = 0.5 + r() * 1.3; SP.push({ a, vr: sp, vy: 0.8 + r() * 2.6 * (1 - sp / 2.2), s: 0.004 + r() * r() * 0.014, dt: r() * 0.1 }); }
  const DR = []; for (let i = 0; i < ND; i++) DR.push({ a: r() * Math.PI * 2, rr: 0.05 + r() * 0.13, s: 0.004 + r() * 0.006, j: r() });
  // crown sheet: open cylinder with a ragged lip
  const cg = new THREE.CylinderGeometry(1, 0.8, 1, 48, 4, true); const cp = cg.attributes.position;
  for (let i = 0; i < cp.count; i++) { const y = cp.getY(i); if (y > 0.4) { const a = Math.atan2(cp.getX(i), cp.getZ(i)); cp.setY(i, y + 0.25 * Math.abs(Math.sin(a * 7)) + 0.1 * Math.sin(a * 13)); } }
  cg.computeVertexNormals();
  const crownM = new THREE.MeshStandardMaterial({ color: 0xf4fbfa, roughness: 0.45, transparent: true, opacity: 0.45, side: THREE.DoubleSide, depthWrite: false });
  const crown = new THREE.Mesh(cg, crownM); g.add(crown);
  // ripples: rings drawn by a shader on a patch of the surface around the rope
  const ripM = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { uT: { value: 0 }, uS: { value: 0 }, uO: { value: 0 }, uHold: { value: 0 }, uC: { value: new THREE.Vector2() } },
    vertexShader: 'varying vec2 vP; void main(){ vP = (modelMatrix*vec4(position,1.)).xz; gl_Position = projectionMatrix*viewMatrix*modelMatrix*vec4(position,1.); }',
    fragmentShader: `uniform float uT, uS, uO, uHold; uniform vec2 uC; varying vec2 vP;
      float ring(float d, float age, float sp){ if (age < 0.0) return 0.0; float r = age * sp; float w = 0.018 + age * 0.025; return exp(-pow((d - r) / w, 2.0)) * exp(-age * 1.8); }
      void main(){ float d = distance(vP, uC); float a = 0.0;
        for (int i = 0; i < 4; i++) { float o = float(i) * 0.16; a += ring(d, uT - uS - o, 0.75 - o * 0.6) * (1.0 - float(i) * 0.2); }
        for (int i = 0; i < 3; i++) { float o = float(i) * 0.14; a += ring(d, uT - uO - o, 0.7) * 0.8; }
        float hold = uHold * (0.5 + 0.5 * sin(d * 40.0 - uT * 7.0)) * exp(-d * 5.0) * 0.35;
        a = clamp(a + hold, 0.0, 1.0) * smoothstep(1.6, 0.6, d);
        gl_FragColor = vec4(vec3(0.92, 0.96, 0.95), a * 0.32);
        #include <colorspace_fragment>
      }`,
  });
  const rip = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 3.4), ripM); rip.rotation.x = -Math.PI / 2; rip.position.y = WY + 0.004; g.add(rip);
  const M4 = new THREE.Matrix4(), Q = new THREE.Quaternion(), SC = new THREE.Vector3(), P = new THREE.Vector3(), VEL = new THREE.Vector3(), UP = new THREE.Vector3(0, 1, 0);
  const bucketAt = (t) => { const tp = tipAt(poleA(t)); return tp.addScaledVector(ropeDir(swingAt(t)), ROPE + 0.21); };
  return (t) => {
    const c0 = bucketAt(T_SPLASH); rip.position.x = c0.x; rip.position.z = c0.z;
    ripM.uniforms.uC.value.set(c0.x, c0.z); ripM.uniforms.uT.value = t; ripM.uniforms.uS.value = T_SPLASH; ripM.uniforms.uO.value = T_OUT ?? 99;
    ripM.uniforms.uHold.value = t > T_SPLASH + 0.3 && t < (T_OUT ?? 99) ? 1 : 0;
    // splash droplets: ballistic from the entry point, gone when back under the surface
    for (let i = 0; i < N; i++) {
      const d = SP[i]; const tau = t - T_SPLASH - d.dt; let vis = tau > 0 && tau < 1.3;
      let y = WY + 0.02 + d.vy * tau - 4.9 * tau * tau; if (y < WY - 0.01) vis = false;
      const rr = 0.16 + d.vr * tau; P.set(c0.x + Math.cos(d.a) * rr, y, c0.z + Math.sin(d.a) * rr);
      // stretch each drop along its velocity (falling water is a streak, not a ball)
      VEL.set(Math.cos(d.a) * d.vr, d.vy - 9.8 * tau, Math.sin(d.a) * d.vr); const sp = VEL.length(); Q.setFromUnitVectors(UP, VEL.normalize());
      const s = vis ? d.s * (1 - tau * 0.4) : 0; SC.set(s, s * (1 + sp * 0.8), s); M4.compose(P, Q, SC); drops.setMatrixAt(i, M4);
    }
    drops.instanceMatrix.needsUpdate = true;
    // crown: rises and thins in half a second
    const ct = t - T_SPLASH; crown.visible = ct > 0 && ct < 0.55;
    if (crown.visible) { const k = ct / 0.55; crown.position.set(c0.x, WY + 0.12 * Math.sin(Math.PI * Math.min(1, k * 1.3)) * 0.5, c0.z); crown.scale.set(0.2 + k * 0.32, 0.02 + 0.3 * Math.sin(Math.PI * k), 0.2 + k * 0.32); crownM.opacity = 0.42 * (1 - k) * (1 - k); }
    // drips from the bucket after it leaves the water: emitted every 25 ms with the bucket's velocity, then falling
    for (let i = 0; i < ND; i++) {
      const d = DR[i]; let s = 0;
      if (T_OUT != null && t > T_OUT) {
        const period = 0.025 * ND; const te = t - ((t - T_OUT - (i * 0.025)) % period + period) % period; // most recent emission of this drop
        const tau = t - te;
        if (te >= T_OUT && tau < 1.6) {
          const b0 = bucketAt(te), b1 = bucketAt(te + 0.01); const v = b1.clone().sub(b0).multiplyScalar(100);
          const p = b0.clone().add(new THREE.Vector3(Math.cos(d.a) * d.rr, -0.33, Math.sin(d.a) * d.rr));
          const heavy = Math.exp(-(te - T_OUT) * 1.2); // more water right after it leaves the river
          p.addScaledVector(v, tau); p.y -= 4.9 * tau * tau;
          if (p.y > WY && d.j < 0.35 + 0.65 * heavy) { s = d.s * (1 + heavy); P.copy(p); }
        }
      }
      Q.identity(); SC.set(s, s * 2.2, s); M4.compose(P, Q, SC); drips.setMatrixAt(i, M4);
    }
    drips.instanceMatrix.needsUpdate = true;
  };
}

function rig(makeStage) {
  const W = world(makeStage);
  const F = toon({ skin: 0x8a5232, cloth: 0xefe6d0, belt: 0x9a4a2a }); W.scene.add(F.root);
  if (window.DBG) { window._F = F; window._S = W.S; window._W = W; window._R = { ropePoint, poleA }; } // ?dbg: lets the probe scripts measure the scene
  F.root.position.copy(FPOS); F.root.rotation.y = -Math.PI / 2;
  const fx = effects(W.scene, W.S);
  const hands = simulateHands();
  const b = birds(5, { from: [-30, 11, -14], to: [30, 13, -22], spread: 4, speed: 0.06, scale: 1.3, seed: 6 }); W.scene.add(b);
  const bucketPos = () => W.S.bucketWorld();
  // the farmer's whole performance at global time t
  const act = (t) => {
    const a = poleA(t); const sw = swingAt(t);
    W.S.set(a, { swing: sw, fill: fillAt(t), slosh: -sw[0] * 0.8 });
    const rel = t > T_REL ? t - T_REL : -1;
    const effort = t < T_REL ? clamp(0.55 + 0.45 * Math.sin(Math.min(1, t / 1.4) * Math.PI * 0.5)) : Math.max(0, 1 - spring(rel, 1.2, 0.7));
    const breathe = Math.sin(t * 2.6) * 0.01;
    // trunk: crouched and leaning into the pull, then standing up (with a little overshoot) after letting go
    const up = rel > 0 ? spring(rel - 0.05, 1.0, 0.5) : 0;
    const strainShake = t < T_REL ? noise1(t * 9, 2) * 0.012 * clamp(t - 1.2) : 0;
    // twist the hips and spine towards the rope (it moves from his left to his right as the pole comes down); feet stay planted
    const rp = ropePoint(Math.min(t, T_REL), 1.0); const twist = Math.atan2(rp.z - FPOS.z, FPOS.x - rp.x) * (1 - up);
    // bend the knees when a gripping hand gets low (smoothed over a quarter second so regrabs don't pop)
    const crouch = (() => { if (t >= T_REL + 0.3) return 0; let acc = 0; for (let i = -4; i <= 4; i++) { const tt = Math.min(T_REL, Math.max(0, t + i * 0.03)); let lo = 9; for (const h of ['l', 'r']) { const H = hands(h, tt); if (H.mode) lo = Math.min(lo, ropePoint(tt, H.s).y); } acc += clamp((1.82 - lo) / 0.4); } return acc / 9; })();
    F.pose({
      hipsY: lerp(-0.07 - 0.03 * effort - 0.17 * crouch, -0.02, up) + breathe * 0.3, hipsZ: lerp(-0.06, 0, up), hipRot: [0, twist * 0.5, 0],
      spine: [lerp(0.28 + 0.06 * effort, 0.06, up) + strainShake, twist * 0.35, 0], chest: [lerp(0.16, -0.04, up) + breathe, twist * 0.15, 0],
    });
    const w = (lx, ly, lz) => F.root.localToWorld(V(lx, ly, lz));
    F.legIK('l', w(0.14, 0.075, -0.03), w(0.35, 0.5, 1.2)); F.legIK('r', w(-0.14, 0.075, -0.25), w(-0.25, 0.5, 1.2)); // both feet fully on the platform top
    // hands: on the rope (hauling) or reaching; after the release they drop to the sides
    const elbowPole = (s) => w(s * 0.6, 0.6, -0.2);
    for (const [h, s] of [['l', 1], ['r', -1]]) {
      if (t < T_REL + 0.02) {
        const H = hands(h, Math.min(t, T_REL)); let target;
        if (H.mode) target = ropePoint(t, H.s);
        else { const to = ropePoint(t, H.s), k = smooth(H.k); target = H.from.clone().lerp(to, k); const side = F.root.localToWorld(V(s, 0, 0)).sub(F.root.position).normalize(); target.addScaledVector(side, Math.sin(Math.PI * k) * 0.1); target.x += Math.sin(Math.PI * k) * 0.04; }
        target.x += 0.035; // palm centre sits just on the farmer's side of the rope
        F.armIK(h, target, elbowPole(s), V(0, 1, 0));
      } else {
        // let go: hands spring open and down, then rest by the hips
        const k = spring(rel, 1.3, 0.55);
        const from = ropePoint(T_REL, hands(h, T_REL).s).add(V(0.035, 0, 0));
        const rest = w(s * 0.22, 0.95, 0.12 + 0.05 * Math.sin(t * 2 + s));
        F.armIK(h, from.lerp(rest, k), w(s * 0.6, 0.9, -0.6), V(0, 1, 0));
      }
    }
    const Hl = hands('l', Math.min(t, T_REL)), Hr = hands('r', Math.min(t, T_REL));
    if (t < T_REL) F.grip(Hl.mode ? 1 : 0.15, Hr.mode ? 1 : 0.15); else { const k = clamp(rel / 0.25); F.grip(lerp(1, 0.3, k), lerp(1, 0.3, k)); }
    // head and eyes: on the rope while hauling, then follow the rising bucket
    const bp = bucketPos();
    if (t < T_REL + 0.25) {
      // eyes on the rope while hauling; once the bucket is down, a strained look up past the pole (towards the lens side)
      const k = smooth(range(t, 2.1, 2.6)) * (1 - smooth(range(t, CUT + 0.3, T_REL)));
      const up = V(-0.6, 3.1, 2.75); const tg = ropePoint(t, 0.15).add(V(0, 0.3, 0)).lerp(up, k);
      F.headAt(tg, 0.6 + 0.2 * k); F.look(ropePoint(t, 0.5).lerp(up, k));
    }
    else { const k = smooth(clamp((t - T_REL - 0.25) / 0.6)); F.headAt(bp.clone().lerp(ropePoint(t, 0.9), 1 - k), 0.75); F.look(bp); }
    // face: effort grimace while hauling, relief and a smile once the mud does the work
    const blink = Math.max(0, 1 - Math.abs(((t + 0.7) % 3.1) - 0.1) / 0.08);
    const relax = rel > 0 ? smooth(clamp((rel - 0.2) / 0.7)) : 0;
    F.face({ brow: lerp(-0.85, 0.35, relax), smile: lerp(-0.35, 0.65, relax), teeth: lerp(t < 1.0 ? 0.6 : 1, 0, relax), squint: lerp(0.55, 0.0, relax), open: lerp(0, 0.1, relax), blink });
    return { a };
  };
  return { ...W, F, fx, act, b };
}

// ================= shots =================
function sHaul({ makeStage }) {
  const R = rig(makeStage); const c = cam(38);
  return {
    scene: R.scene, camera: c,
    update(lt, t) {
      R.act(t); R.fx(t); R.b.update(t);
      c.fov = lerp(38, 34, easeInOut(range(t, 1.0, at(0, 'arms') + 0.3)));
      // low by the water looking up at the bucket plunging in, craning up to his straining face by "arms"
      const k = easeInOut(range(t, 1.0, at(0, 'arms') + 0.3));
      const p = camPath(k, [[-2.1, 1.25, 5.1], [-1.7, 1.55, 4.35], [-1.15, 1.88, 3.35], [-0.8, 2.02, 2.62]]);
      const look = V(0.25, 1.2, 2.0).lerp(V(0.5, 1.96, 2.0), smooth(range(t, 0.9, 2.45)));
      const hh = handheld(t, 1.2, 1); place(c, [p[0] + hh.p[0], p[1] + hh.p[1], p[2] + hh.p[2]], look.toArray(), hh.roll);
      return { bloom: 0.35, warm: 1.15, sat: 1.1, flare: 0.5, dof: { focus: c.position.distanceTo(look), aperture: 0.004, maxblur: 0.008 } };
    },
  };
}
function sLift({ makeStage }) {
  const R = rig(makeStage); const c = cam(36);
  return {
    scene: R.scene, camera: c,
    update(lt, t) {
      R.act(t); R.fx(t); R.b.update(t);
      // wide from the river: slow arc while the counterweight drops and the bucket rises
      const k = easeInOut(range(t, CUT, DURATION));
      const p = camPath(k, [[-4.6, 3.05, 10.3], [-4.3, 3.0, 9.85], [-4.0, 2.95, 9.4]]);
      const look = V(0.15, 2.5, 0.3).lerp(V(0.15, 2.55, 0.3), k);
      const hh = handheld(t, 0.8, 4); place(c, [p[0] + hh.p[0], p[1] + hh.p[1], p[2] + hh.p[2]], look.toArray(), hh.roll);
      return { bloom: 0.35, warm: 1.15, sat: 1.1, flare: 0.6, dof: { focus: c.position.distanceTo(V(0.3, 2.0, 1.2)), aperture: 0.0025, maxblur: 0.006 } };
    },
  };
}
export const SHOTS = [
  { start: 0, end: CUT, build: sHaul },
  { start: CUT, end: DURATION + 1, build: sLift },
];
console.warn(`[dm] duration ${DURATION.toFixed(3)} cut ${CUT.toFixed(3)} splash ${T_SPLASH?.toFixed(3)} release ${T_REL.toFixed(3)} out ${T_OUT?.toFixed(3)}`);
