// The Explainer: how fireworks get their colours. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { COL, burst, riser, skyline, shellCut, mortar, smoke, atom, std } from './firework2.js';
import { label } from './gps.js';
import { VO } from './vo_fk2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*Every colour*', 2], ['in a *firework*', 3], ['comes from', 2], ['*burning*', 1], ['a *different metal*', 3]],
  [['A firework *shell*', 3], ['is *fired*', 2], ['out of a *tube*', 4], ['by a charge', 3], ['of *black powder*', 3]],
  [['As it *climbs*', 3], ['a *slow fuse*', 3], ['burns inside', 2], ['At the *top*', 3], ['it reaches', 2], ['the *burst charge*', 3], ['and the shell', 3], ['*explodes*', 1]],
  [['That *flings out*', 3], ['*dozens*', 1], ['of small *pellets*', 3], ['called *stars*', 2], ['packed with', 2], ['*metal salts*', 2]],
  [['The *heat*', 2], ['*kicks electrons*', 2], ['in the metal *atoms*', 4], ['up to a', 3], ['*higher energy*', 2], ['When they', 2], ['*drop back down*', 3], ['they give off', 3], ['*light*', 1]],
  [['Each *metal*', 2], ['gives its own', 3], ['*colour*', 1], ['*Strontium*', 1], ['burns *red*', 2], ['*barium green*', 2], ['*sodium yellow*', 2], ['and *copper blue*', 3]],
  [['*Blue*', 1], ['is the *hardest*', 3], ['to make', 2], ['because', 1], ['*too much heat*', 3], ['*destroys* it', 2]],
  [['And the way', 3], ['the *stars*', 2], ['are *packed*', 2], ['inside the shell', 3], ['*decides*', 1], ['the *shape*', 2], ['from a *ring*', 3], ['to a *heart*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 38) => { const c = cam(fov); c.near = 0.01; c.far = 800; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 1.25, warm: 0.95, sat: 1.2, exposure: 1.05 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

function night(makeStage, city = true) {
  const scene = makeStage({ shadowSize: 6, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x03050f); u.mid.value.set(0x080c22); u.horizon.value.set(0x161a3a); u.floorC.value.set(0x04060a); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0x5a6ab0, 0x0a0a10, 0.45));
  const moon = new THREE.DirectionalLight(0x9ab0ff, 0.4); moon.position.set(-4, 8, 3); scene.add(moon);
  if (city) { const S = skyline(); S.position.z = -60; scene.add(S); }
  return scene;
}
function lab(makeStage) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x0a0e24); u.mid.value.set(0x121834); u.horizon.value.set(0x1a2244); u.floorC.value.set(0x05080e); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xdfe8ff, 0x101828, 0.9));
  const key = new THREE.DirectionalLight(0xffffff, 1.2); key.position.set(3, 5, 6); scene.add(key);
  return scene;
}
// mixed-colour burst from several single-colour bursts
function mixed(scene, pos, R, seed, colors = [COL.red, COL.green, COL.yellow, COL.blue], n = 26, o = {}) {
  const B = colors.map((c, i) => { const b = burst({ color: c, n, R, seed: seed + i, ...o }); b.group.position.set(...pos); scene.add(b.group); return b; });
  return { set(t, w) { B.forEach(b => b.set(t, w)); } };
}

// ============ S0 hook: the sky over a city fills with bursts of different colours ============
function sHook({ makeStage }) {
  const scene = night(makeStage);
  const P = [[COL.red, [-3.4, 21, -32], -0.6, 1], [COL.green, [3.4, 17, -34], -0.25, 2], [COL.yellow, [-2.6, 12.5, -30], 0.5, 3], [COL.blue, [3.0, 24, -36], 1.1, 4], [COL.pink, [0.4, 17.5, -28], 1.9, 5], [COL.gold, [-3.0, 21, -33], 2.7, 6], [COL.green, [3.2, 14, -31], 3.3, 7]];
  const B = P.map(([c, p, t0, s]) => { const b = burst({ color: c, R: 4, seed: s, n: 110 }); b.group.position.set(...p); scene.add(b.group); return [b, t0]; });
  const c = C(42);
  return {
    scene, camera: c,
    update(t) {
      B.forEach(([b, t0]) => b.set(t - t0));
      const k = easeInOut(range(t, 0, 4.2));
      orb(c, [0, 16, -32], lerp(36, 32, k), lerp(-4, 4, k), lerp(-4, -2, k));
      return POST;
    },
  };
}
// ============ S1: the shell sits in a mortar tube on black powder, then the lift charge fires it out ============
function sMortar({ makeStage }) {
  const scene = night(makeStage); const Mo = mortar(); scene.add(Mo.group);
  const sh = new THREE.Group(); const ball = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 20), std(0xc89a5a, 0.95)); sh.add(ball);
  const fz = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.5, 8), std(0x6a4a2a)); fz.position.y = 1.15; sh.add(fz); scene.add(sh);
  const Sm = smoke(14, 3); Sm.group.position.set(0, 4.6, 0); scene.add(Sm.group);
  const Ls = tag(scene, 'shell', 0.8, '#ffd28a', [0, 1.5, 1.4]), Lp = tag(scene, 'black powder', 0.8, '#e0e0e0', [0, 0.4, 1.7]);
  const c = C(38); const tl = at(1, 'powder');
  return {
    scene, camera: c,
    update(t, T) {
      const u = range(T, tl, tl + 0.5); sh.position.y = 1.4 + 22 * u * u; sh.visible = u < 1;
      Mo.set(T < tl ? 0 : Math.max(0, 1 - (T - tl) / 0.5) * (T < tl + 0.06 ? (T - tl) / 0.06 : 1), T > tl + 0.1);
      Sm.set(range(T, tl + 0.15, tl + 1.6), T > tl + 0.15 ? 1 : 0);
      pop(Ls, easeOut(range(T, at(1, 'shell') - 0.1, at(1, 'shell') + 0.2)) * (1 - range(T, tl, tl + 0.15)), 0.8);
      pop(Lp, easeOut(range(T, at(1, 'black') - 0.15, at(1, 'black') + 0.15)), 0.8);
      const k = easeInOut(range(t, 0, 4.4));
      orb(c, [0, 3.0, 0], lerp(12.5, 11, k), lerp(18, -4, k), 6);
      return POST;
    },
  };
}
// ============ S2: the shell climbs (cutaway); the time fuse burns down to the burst charge; it explodes ============
function sClimb({ makeStage }) {
  const scene = night(makeStage, false); const S = shellCut(); scene.add(S.group);
  const Sm = []; const sm = new THREE.MeshBasicMaterial({ color: 0xffb860, toneMapped: false });
  for (let i = 0; i < 26; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 4), sm); m.scale.y = 4; scene.add(m); Sm.push([m, i]); }
  const B = mixed(scene, [0, 0, 0], 2.4, 20, undefined, 26, { size: 0.55 });
  const Lf = tag(scene, 'time fuse', 0.4, '#ffb04a', [0.62, 1.55, 0.2]), Lb = tag(scene, 'burst charge', 0.4, '#ffffff', [0, 0.3, 0.25]);
  const c = C(38); const te = at(2, 'explodes');
  return {
    scene, camera: c,
    update(t, T) {
      S.set(smooth(range(T, at(2, 'slow'), at(2, 'burst'))), T); S.group.visible = T < te; S.group.rotation.z = 0.04 * Math.sin(T * 1.3);
      Sm.forEach(([m, i]) => { m.position.set(Math.sin(i * 2.3) * 0.25, -1.1 - ((T * 3 + i * 0.37) % 2.4), -0.2 + Math.cos(i * 1.7) * 0.2); m.visible = T < te; });
      B.set(T - te);
      pop(Lf, easeOut(range(T, at(2, 'fuse') - 0.15, at(2, 'fuse') + 0.15)) * (1 - range(T, at(2, 'top'), at(2, 'top') + 0.2)), 0.4);
      pop(Lb, easeOut(range(T, at(2, 'burst') - 0.15, at(2, 'burst') + 0.15)) * (1 - range(T, te - 0.1, te)), 0.4);
      const k = easeInOut(range(t, 0, 6.8));
      orb(c, [0, 0.25, 0], lerp(7.4, 6.8, k), lerp(-8, 8, k), 3);
      return POST;
    },
  };
}
// ============ S3: slow motion: the stars fly out, each a pellet of metal salts ============
function sStars({ makeStage }) {
  const scene = night(makeStage, false);
  const B = mixed(scene, [0, 0, 0], 3.6, 30, undefined, 30, { life: 9, trail: 8, size: 0.5 });
  const Ls = tag(scene, 'stars', 1.4, '#ffffff', [0, 4.4, 1]), Lm = tag(scene, 'metal salts', 1.2, '#ffd28a', [0, 3.0, 1]);
  const c = C(38); const t0 = ls(3) - 0.5;
  return {
    scene, camera: c,
    update(t, T) {
      B.set(0.12 + (T - t0) * 0.32);
      pop(Ls, easeOut(range(T, at(3, 'stars') - 0.15, at(3, 'stars') + 0.15)), 1.4);
      pop(Lm, easeOut(range(T, at(3, 'salts') - 0.25, at(3, 'salts') + 0.1)), 1.2);
      const k = easeInOut(range(t, 0, 4.9));
      orb(c, [0, 0.6, 0], lerp(13, 15, k), lerp(-10, 10, k), lerp(4, 8, k));
      return POST;
    },
  };
}
// ============ S4: an atom: heat kicks the electron to a higher orbit; it drops back and gives off light ============
function sAtom({ makeStage }) {
  const scene = lab(makeStage); const A = atom(); scene.add(A.group);
  const Le = tag(scene, 'electron', 1.2, '#9ad8ff', [-1.3, 3.3, 0]), Lh = tag(scene, 'heat', 1.3, '#ff8a3a', [1.5, 3.3, 0]), Ll = tag(scene, 'light', 1.3, '#ff5a6a', [1.5, 3.3, 0]);
  const c = C(38); const tk = at(4, 'kicks'), td = at(4, 'drop');
  return {
    scene, camera: c,
    update(t, T) {
      const jump = smooth(range(T, tk, tk + 0.5)) * (1 - smooth(range(T, td, td + 0.35)));
      const heat = smooth(range(T, at(4, 'heat') - 0.2, at(4, 'heat') + 0.3)) * (1 - smooth(range(T, td - 0.2, td + 0.3)));
      A.set(T, jump, range(T, td + 0.2, td + 2.6), heat * (0.8 + 0.2 * Math.sin(T * 14)));
      pop(Le, easeOut(range(T, at(4, 'electrons') - 0.15, at(4, 'electrons') + 0.15)), 1.2);
      pop(Lh, easeOut(range(T, at(4, 'heat') - 0.15, at(4, 'heat') + 0.15)) * (1 - range(T, td, td + 0.2)), 1.3);
      pop(Ll, easeOut(range(T, at(4, 'light') - 0.2, at(4, 'light') + 0.1)), 1.3);
      const k = easeInOut(range(t, 0, 7.0));
      orb(c, [0, -1.2, 0], lerp(16, 15, k), lerp(-6, 6, k), 2);
      return POST;
    },
  };
}
// ============ S5: each metal its own colour: strontium red, barium green, sodium yellow, copper blue ============
function sColours({ makeStage }) {
  const scene = night(makeStage);
  const g = burst({ color: COL.gold, R: 3.6, seed: 40, n: 110, life: 1.6 }); g.group.position.set(0, 20, -30); scene.add(g.group);
  const D = [['strontium', COL.red, '#ff5a6a', -2.4], ['barium', COL.green, '#6aff7a', 2.4], ['sodium', COL.yellow, '#ffd24a', -2.4], ['copper', COL.blue, '#7aa8ff', 2.4]];
  const B = D.map(([w, col, css, x], i) => { const t0 = at(5, w) - 0.2, nx = i < 3 ? at(5, D[i + 1][0]) - 0.2 : t0 + 3.2; const b = burst({ color: col, R: 3.4, seed: 41 + i, n: 110, life: nx - t0 + 0.1 }); b.group.position.set(x, 23.0, -30); scene.add(b.group); const L = tag(scene, w, 3.2, css, [0, 17.6, -29]); return { b, L, t0 }; });
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      g.set(T - ls(5) + 0.2);
      B.forEach(({ b, L, t0 }, i) => { const nx = i < 3 ? B[i + 1].t0 : 99; b.set(T < t0 ? -1 : T - t0); pop(L, easeOut(range(T, t0, t0 + 0.25)) * (1 - range(T, nx - 0.05, nx + 0.05)), 3.2); });
      const k = easeInOut(range(t, 0, 6.9));
      orb(c, [0, 16.5, -30], lerp(32, 30, k), lerp(-3, 3, k), -3);
      return POST;
    },
  };
}
// ============ S6: blue is hard: a blue burst washes out to white when it is too hot ============
function sBlue({ makeStage }) {
  const scene = night(makeStage, false);
  const b = burst({ color: COL.blue, R: 3.0, seed: 50, n: 130, life: 9, trail: 7, size: 0.55 }); scene.add(b.group);
  const L = tag(scene, 'too hot!', 1.3, '#ff8a3a', [0, 3.6, 1]);
  const c = C(38); const th = at(6, 'heat');
  return {
    scene, camera: c,
    update(t, T) {
      { const w = smooth(range(T, th - 0.3, th + 0.6)); b.set(0.15 + (T - ls(6)) * 0.45, w, 0.6 * smooth(range(T, th + 0.4, th + 1.6))); }
      pop(L, easeOut(range(T, at(6, 'destroys') - 0.2, at(6, 'destroys') + 0.1)), 1.3);
      const k = easeInOut(range(t, 0, 3.7));
      orb(c, [0, 0.6, 0], lerp(15, 13.5, k), lerp(8, -6, k), 4);
      return POST;
    },
  };
}
// ============ S7a: cutaway shell with the stars packed in a heart ============
function sPack({ makeStage }) {
  const scene = lab(makeStage); const S = shellCut({ pattern: 'heart', colors: [COL.red, COL.pink] }); scene.add(S.group);
  const c = C(38);
  return {
    scene, camera: c,
    update(t, T) {
      S.set(0); S.stars.forEach((m, i) => { m.scale.setScalar(1 + 0.35 * smooth(range(T, at(7, 'packed') - 0.1 + i * 0.02, at(7, 'packed') + 0.3 + i * 0.02))); });
      const k = easeInOut(range(t, 0, 3.0));
      orb(c, [0, 0.15, 0], lerp(7.6, 6.6, k), lerp(-14, 4, k), 4);
      return POST;
    },
  };
}
// ============ S7b: a ring burst, then a heart burst ============
function sShapes({ makeStage }) {
  const scene = night(makeStage);
  const tr = at(7, 'ring') - 0.25, th = at(7, 'heart') - 0.25;
  const ring = burst({ color: COL.yellow, R: 3.0, seed: 60, n: 70, shape: 'ring', life: 4 }); ring.group.position.set(-2.2, 22, -30); scene.add(ring.group);
  const heart = burst({ color: COL.red, R: 3.4, seed: 61, n: 80, shape: 'heart', life: 5 }); heart.group.position.set(1.8, 16.8, -29); scene.add(heart.group);
  const r1 = riser(), r2 = riser(); r1.group.position.set(-2.2, 6, -30); r2.group.position.set(1.8, 6, -29); scene.add(r1.group, r2.group);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      ring.set(T - tr); heart.set(T - th);
      r1.set(range(T, tr - 1.3, tr), 16); r2.set(range(T, th - 1.0, th), 10.8);
      const k = easeInOut(range(t, 0, 4.0));
      orb(c, [0, 17.0, -30], lerp(31, 29, k), lerp(-3, 2, k), -3);
      return POST;
    },
  };
}

const TS = [0, ls(1), ls(2), ls(3), ls(4), ls(5), ls(6), ls(7), at(7, 'decides') - 0.1, DURATION + 1];
const SH = [sHook, sMortar, sClimb, sStars, sAtom, sColours, sBlue, sPack, sShapes];
export const SHOTS = SH.map((build, i) => ({ start: i === 0 ? 0 : TS[i] - 0.12, end: i === SH.length - 1 ? TS[i + 1] : TS[i + 1] - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
