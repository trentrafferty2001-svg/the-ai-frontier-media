// detail kit for fireworks: soft glowing star sprites, textured skyline with rooftop details, city haze, stars
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as W from './firework.js';
export { COL, riser, shellCut, mortar, smoke, atom, std } from './firework.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
const sparkTex = () => cv(128, 128, (g, w, h) => { const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.18, 'rgba(255,255,255,0.9)'); gr.addColorStop(0.4, 'rgba(255,255,255,0.3)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.strokeStyle = 'rgba(255,255,255,0.5)'; g.lineWidth = 2; g.beginPath(); g.moveTo(64, 8); g.lineTo(64, 120); g.moveTo(8, 64); g.lineTo(120, 64); g.stroke(); });
export function burst(o) {
  const B = W.burst(o); const im = B.group.children.find(c => c.isInstancedMesh);
  if (im) { im.geometry = new THREE.PlaneGeometry(2.6, 2.6); im.material = new THREE.MeshBasicMaterial({ map: tx('spark', sparkTex), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }); }
  const fl = B.group.children.find(c => c.isMesh && !c.isInstancedMesh); if (fl) { fl.geometry = new THREE.PlaneGeometry(2.4, 2.4); fl.material.map = tx('spark', sparkTex); fl.material.blending = THREE.AdditiveBlending; fl.material.needsUpdate = true; }
  return B;
}
const facadeTex = (seed) => cv(256, 512, (g, w, h) => { g.fillStyle = '#0c1018'; g.fillRect(0, 0, w, h); const R = rnd(seed);
  g.strokeStyle = 'rgba(60,70,90,0.5)'; g.lineWidth = 2; for (let y = 0; y < h; y += 32) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); } for (let x = 0; x < w; x += 32) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); }
  for (let y = 8; y < h - 16; y += 32) for (let x = 6; x < w - 16; x += 32) { const lit = R() < 0.32; g.fillStyle = lit ? (R() < 0.7 ? '#ffc87a' : '#cfe0ff') : '#141a26'; g.fillRect(x, y, 20, 18); if (lit && R() < 0.4) { g.fillStyle = 'rgba(60,40,30,0.5)'; g.fillRect(x, y, 20, 6); } } });
export function skyline(seed = 3, width = 90) {
  const G = new THREE.Group(); const R = rnd(seed);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: 0x06080e, roughness: 1 })); ground.rotation.x = -Math.PI / 2; G.add(ground);
  const texs = [0, 1, 2, 3].map(k => facadeTex(seed * 10 + k)); const rm = new THREE.MeshStandardMaterial({ color: 0x1a2030, roughness: 0.6, metalness: 0.5 });
  const red = new THREE.MeshBasicMaterial({ color: 0xff3a2a, toneMapped: false });
  for (let x = -width / 2; x < width / 2;) { const w = 2 + R() * 4, h = 3 + R() * 14, d = 3 + R() * 3; const z = -R() * 4;
    const t = texs[Math.floor(R() * 4)].clone(); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(w / 4, h / 8); t.needsUpdate = true;
    const mat = new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: 0.9, roughness: 0.6, color: 0x404858 });
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); b.position.set(x + w / 2, h / 2, z); G.add(b);
    if (R() < 0.4) { const s = new THREE.Mesh(new THREE.BoxGeometry(w * 0.6, h * 0.25, d * 0.6), mat); s.position.set(x + w / 2, h + h * 0.125, z); G.add(s); }
    if (R() < 0.35) { const a = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.5, 6), rm); a.position.set(x + w / 2, h + 1.25 + (R() < 0.5 ? 0 : 0), z); G.add(a); const l = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), red); l.position.set(x + w / 2, h + 2.5, z); G.add(l); }
    if (R() < 0.25) { const tk = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.9, 12), rm); tk.position.set(x + w * 0.3, h + 0.7, z); G.add(tk); }
    x += w + 0.3; }
  // city glow haze on the horizon
  const hz = cv(64, 256, (g, w, h) => { const gr = g.createLinearGradient(0, h, 0, 0); gr.addColorStop(0, 'rgba(255,170,90,0.45)'); gr.addColorStop(0.5, 'rgba(120,90,140,0.15)'); gr.addColorStop(1, 'rgba(40,40,90,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
  const haze = new THREE.Mesh(new THREE.PlaneGeometry(260, 40), new THREE.MeshBasicMaterial({ map: hz, transparent: true, depthWrite: false })); haze.position.set(0, 14, -14); G.add(haze);
  // stars
  const st = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.4, 0.4), new THREE.MeshBasicMaterial({ map: tx('spark', sparkTex), color: 0xdfe8ff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }), 400); const M = new THREE.Matrix4();
  for (let i = 0; i < 400; i++) { M.compose(new THREE.Vector3((R() - 0.5) * 300, 25 + R() * 110, -40 - R() * 20), new THREE.Quaternion(), new THREE.Vector3(1, 1, 1).multiplyScalar(0.4 + R() * 1.2)); st.setMatrixAt(i, M); } G.add(st);
  return G;
}
