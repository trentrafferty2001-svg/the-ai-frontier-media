// Character test turntable (not a video).
import * as THREE from 'three';
import { V, cam, place } from './anim.js';
import { toon } from './toon.js';
export const DURATION = 6;
export const CAPTIONS = [];
export const FADES = [];
export const STYLE = { shadow: 'pcf' };
function stage(makeStage) {
  const scene = makeStage({ shadowSize: 2, sunDir: [-2, 5, 4], sun: 2.6 });
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: 0xb59a74, roughness: 0.9 })); fl.rotation.x = -Math.PI / 2; fl.receiveShadow = true; scene.add(fl);
  const F = toon(); scene.add(F.root);
  return { scene, F };
}
const mk = (camPos, look, posefn, fov = 30) => ({ makeStage }) => {
  const { scene, F } = stage(makeStage); const c = cam(fov);
  return { scene, camera: c, update(t) { F.pose(); if (posefn) posefn(F, scene); else { F.grip(0.3); F.face({ smile: 0.3 }); } place(c, camPos, look); return { bloom: 0.2 }; } };
};
const pullPose = (F) => {
  F.pose({ hipsY: -0.12, hipsZ: -0.04, spine: [0.25, 0, 0], chest: [0.15, 0, 0] });
  F.legIK('l', V(0.13, 0.06, 0.2), V(0.2, 0.5, 2)); F.legIK('r', V(-0.13, 0.06, -0.2), V(-0.2, 0.5, 2));
  F.armIK('l', V(0.03, 1.35, 0.55), V(1, 0.6, -0.5), V(0, 0, 1)); F.armIK('r', V(-0.03, 1.55, 0.55), V(-1, 0.6, -0.5), V(0, 0, 1));
  F.grip(1); F.face({ brow: -1, smile: -0.4, open: 0.2, teeth: 1, squint: 0.6 }); F.look(V(0, 1.5, 2));
};
const S = [
  [0, 1, mk([0, 1.0, 4.6], [0, 0.95, 0])],
  [1, 2, mk([3.1, 1.2, 3.3], [0, 0.95, 0])],
  [2, 3, mk([4.5, 1.0, 0.01], [0, 0.95, 0])],
  [3, 4, mk([0.25, 1.68, 0.85], [0, 1.63, 0], null, 26)],
  [4, 5, mk([2.6, 1.3, 2.6], [0, 0.9, 0.2], pullPose)],
  [5, 6, mk([0.6, 1.62, 1.0], [0, 1.55, 0], pullPose, 26)],
];
export const SHOTS = S.map(([s, e, build]) => ({ start: s, end: e, build }));
