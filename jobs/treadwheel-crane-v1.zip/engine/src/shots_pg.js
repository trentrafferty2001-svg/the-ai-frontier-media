// Pont du Gard reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, trees, ringSpots, birds, waterMaterial } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll, canvasTex, romanBuilder } from './rome.js';
import { VO } from './vo_pg.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This *giant bridge*', 3], ['was built', 2], ['to carry *water*', 3], ['not *people*', 2]],
  [["It's the", 2], ['*Pont du Gard*', 3], ['in *France*', 2], ['almost', 1], ['*2,000 years* old', 4]],
  [['At *49 meters*', 4], ["it's the tallest", 3], ['*water bridge*', 2], ['the Romans', 2], ['ever built', 2]],
  [['Its stone blocks', 3], ['weigh up to', 3], ['*6 tonnes*', 2], ["and they're", 2], ['stacked', 1], ['without any', 2], ['*mortar*', 1]],
  [['On top', 2], ['runs a', 2], ['*covered channel*', 2], ['that carried', 2], ['water', 1], ['to the city', 3], ['of *Nîmes*', 2]],
  [['The whole aqueduct', 3], ['winds for', 2], ['*50 kilometers*', 2], ['but drops', 2], ['only about', 2], ['*17 meters*', 2]],
  [['Across', 1], ['the bridge itself', 3], ['the channel', 2], ['falls just', 2], ['*2.5 centimeters*', 5]],
  [['That *gentle slope*', 3], ['moved', 1], ['*tens of thousands*', 3], ['of tonnes', 2], ['of water a day', 4], ['using only', 2], ['*gravity*', 1]],
  [['And the bridge', 3], ['*still stands*', 2], ['*2,000 years* later', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ---------- the bridge ----------
let BT = null;
function blockMat(rx = 1, ry = 1) {
  if (!BT) { BT = canvasTex(512, 256, (x) => { x.fillStyle = '#d8bf8a'; x.fillRect(0, 0, 512, 256); const R = (s => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296)(3); for (let r = 0; r < 4; r++) for (let c = -1; c < 5; c++) { const off = (r % 2) * 64; const g = 190 + R() * 40 | 0; x.fillStyle = `rgb(${g},${g - 22},${g - 70})`; x.fillRect(c * 128 + off + 2, r * 64 + 2, 124, 60); for (let k = 0; k < 40; k++) { x.fillStyle = 'rgba(80,60,30,0.12)'; x.fillRect(c * 128 + off + R() * 124, r * 64 + R() * 60, 3, 2); } } }); BT.wrapS = BT.wrapT = THREE.RepeatWrapping; }
  const t = BT.clone(); t.needsUpdate = true; t.repeat.set(rx, ry);
  return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 2, roughness: 0.92 });
}
// one arcade tier: a wall of length L, height H, depth D with n arches of radius r (spans may vary)
function tier(spans, H, D, archFrac = 0.62) {
  const L = spans.reduce((a, b) => a + b, 0);
  const sh = new THREE.Shape(); sh.moveTo(-L / 2, 0); sh.lineTo(L / 2, 0); sh.lineTo(L / 2, H); sh.lineTo(-L / 2, H); sh.lineTo(-L / 2, 0);
  let x = -L / 2;
  spans.forEach((s) => { const pier = s * 0.22; const w = s - pier; const r = w / 2; const cx = x + s / 2; const top = Math.min(H * archFrac, H - r - 0.6); const h = new THREE.Path(); h.moveTo(cx - r, 0.001); h.lineTo(cx - r, top - r); h.absarc(cx, top - r, r, Math.PI, 0, true); h.lineTo(cx + r, 0.001); h.lineTo(cx - r, 0.001); sh.holes.push(h); x += s; });
  const geo = new THREE.ExtrudeGeometry(sh, { depth: D, bevelEnabled: false, curveSegments: 18 }); geo.translate(0, 0, -D / 2);
  const m = new THREE.Mesh(geo, blockMat(L / 10, H / 5)); m.castShadow = m.receiveShadow = true; return { m, L };
}
export function pontDuGard() {
  const g = new THREE.Group();
  const low = tier([15.5, 19, 24.5, 21.5, 19, 15.5].map(s => s * 0.9), 22, 6.4, 0.85); g.add(low.m);
  const mid = tier([...Array(11)].map((_, i) => (i === 5 ? 24 : 19) * 0.95), 20, 4.6, 0.85); mid.m.position.y = 22; g.add(mid.m);
  const top = tier([...Array(35)].map(() => 4.6 * 1.65), 7, 3, 0.8); top.m.position.y = 42; g.add(top.m);
  // the covered channel on the very top
  const ch = new THREE.Mesh(new THREE.BoxGeometry(top.L, 1.8, 3), blockMat(top.L / 6, 1)); ch.position.y = 49 + 0.9 - 1.8; g.add(ch);
  const slabs = new THREE.Mesh(new THREE.BoxGeometry(top.L, 0.35, 3.2), blockMat(top.L / 3, 0.3)); slabs.position.y = 49.1; g.add(slabs);
  g.traverse(o => { if (o.isMesh) { o.castShadow = o.receiveShadow = true; } });
  g.topY = 49; g.L = top.L;
  return g;
}
function valley(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.35, 0.72], fog: 0.0022, shadowSize: 90, envI: 0.95, cloud: 0.3, ...opts });
  const river = new THREE.Mesh(new THREE.PlaneGeometry(1200, 70), waterMaterial({ color: 0x2a5a52, opacity: 1, ripple: 1.0 })); river.rotation.x = -Math.PI / 2; river.position.y = 0.5; scene.add(river);
  const M = new THREE.MeshStandardMaterial({ color: 0x8a8a52, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 5 });
  for (const s of [-1, 1]) { const bank = new THREE.Mesh(new THREE.BoxGeometry(1200, 30, 600), M); bank.position.set(0, 9, s * (75 + 300)); bank.receiveShadow = true; scene.add(bank); const slope = new THREE.Mesh(new THREE.BoxGeometry(1200, 30, 60), M); slope.position.set(0, 0, s * 58); slope.rotation.x = -s * 0.45; slope.receiveShadow = true; scene.add(slope); }
  scene.add(trees(ringSpots(160, 80, 300, 3, [0, 0, 0], 0, Math.PI * 2, 24).filter(([x, y, z]) => Math.abs(z) > 80), { seed: 5, scale: 3.5 }));
  scene.add(mountains({ rMin: 300, rMax: 600, height: 60, seed: 7, color: 0x7a8052 }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  const b = birds(4, { from: [-80, 60, -40], to: [80, 66, -60], spread: 10, speed: 0.03, scale: 3, seed: 6 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  return scene;
}
function bridgeIn(scene) { const p = pontDuGard(); p.rotation.y = Math.PI / 2; scene.add(p); return p; }

// ============ S0 hook: from the river, tilt up the giant arches ============
function sHook({ makeStage, start: ST }) {
  const tW = at(0, 'water') - ST;
  const scene = valley(makeStage);
  const p = bridgeIn(scene);
  const glow = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.2, p.L), new THREE.MeshBasicMaterial({ color: 0x8ad8ff, transparent: true, opacity: 0 })); glow.position.y = 49.35; scene.add(glow);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      glow.material.opacity = 0.8 * easeOut(range(t, tW - 0.2, tW + 0.4));
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(-36, -60, k), lerp(3, 8, k), lerp(30, 58, k)], [0, lerp(14, 34, k), lerp(0, -8, k)]);
      return { bloom: 0.55 + glow.material.opacity * 0.3, flare: 1.0, warm: 1.25 };
    },
  };
}
function sWide({ makeStage }) {
  const scene = valley(makeStage);
  bridgeIn(scene);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const a = lerp(-0.9, -0.6, easeInOut(range(t, 0, 4)));
      place(c, [Math.sin(a) * 210, lerp(70, 80, range(t, 0, 4)), Math.cos(a) * 210], [0, 18, 0]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2: people at the foot of a pier, camera tilts up 49 m ============
function sTall({ makeStage }) {
  const scene = valley(makeStage);
  bridgeIn(scene);
  const folk = [0, 1, 2].map(i => { const m = romanBuilder({ color: [0xd8c7a2, 0xa8402c, 0x6f8f5a][i] }); m.root.position.set(-6 + i * 1.2, 0.5, 18 + i * 0.8); m.root.rotation.y = 2.8; scene.add(m.root); return m; });
  const c = cam(46);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((m, i) => { standPose(m, t + i, { head: [-0.6, 0, 0], neck: [-0.3, 0, 0] }); m.setMood('happy'); });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-12, -16, k), lerp(1.6, 2.2, k), lerp(26, 34, k)], [0, lerp(4, 38, k), lerp(14, 4, k)]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S3: a block swung into place on a wooden crane, no mortar ============
function sBlocks({ makeStage, start: ST }) {
  const tM = at(3, 'mortar') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.4, 0.69], fog: 0.003, shadowSize: 6, envI: 0.95, cloud: 0.3 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(300, 32), new THREE.MeshStandardMaterial({ color: 0x9a9060, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const bm = blockMat(1, 1);
  for (let r = 0; r < 3; r++) for (let i = 0; i < 4 - (r === 2 ? 1 : 0); i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.9, 1.4), bm); b.position.set(-2.9 + i * 1.95 + (r % 2) * 0.95, 0.45 + r * 0.92, 0); scene.add(shadowAll(b)); }
  const blk = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.9, 1.4), bm); scene.add(shadowAll(blk));
  const A = archMats();
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.18, 7, 10), A.wood); mast.position.set(4.6, 3.5, -1.6); scene.add(shadowAll(mast));
  const boom = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 5, 8), A.wood); boom.rotation.z = Math.PI / 2 - 0.25; boom.position.set(2.4, 6.6, -1.2); scene.add(shadowAll(boom));
  const rope = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1, 6), new THREE.MeshStandardMaterial({ color: 0x8a7048 })); scene.add(rope);
  const men = [0, 1].map(i => { const m = romanBuilder({ color: [0xd8c7a2, 0x6f8f5a][i] }); m.root.position.set(i ? 2.6 : -0.6, 2.76, 1.0); m.root.rotation.y = Math.PI + (i ? 0.4 : -0.4); scene.add(m.root); return m; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const d = easeInOut(range(t, 0.2, tM - 0.4));
      blk.position.set(1.0, lerp(5.2, 0.45 + 2 * 0.92 + 0.0, d), 0); blk.rotation.y = lerp(0.4, 0, d);
      const ty = 6.2; rope.position.set(1.0, (ty + blk.position.y + 0.45) / 2, 0); rope.scale.y = ty - blk.position.y - 0.45;
      men.forEach((m, i) => { standPose(m, t + i, { spine: [0.2, 0, 0], lSh: [-1.0, 0, 0.3], rSh: [-1.0, 0, -0.3], lEl: [-0.5, 0, 0], rEl: [-0.5, 0, 0] }); m.setMood('happy'); m.setMouth(0); m.blink(blinkK(t, [1 + i])); });
      const k = easeInOut(range(t, 0, 3.6));
      const pos = [lerp(5.0, 4.0, k), lerp(4.4, 3.8, k), lerp(10, 8.5, k)], look = [lerp(0.8, 1.0, k), lerp(3.0, 2.6, k), 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.2, dof: dofTo(pos, look, 0.002, 0.008) };
    },
  };
}
// ============ S4/S6: the channel on top, cover slabs lifted off one stretch, water flowing ============
function channelScene(makeStage, opts = {}) {
  const scene = valley(makeStage, opts);
  const p = bridgeIn(scene);
  p.traverse(o => { if (o.isMesh && o.geometry.type === 'BoxGeometry' && Math.abs(o.geometry.parameters.height - 0.35) < 1e-6) o.visible = false; });
  const bm = blockMat(1, 0.3);
  for (let i = 0; i < 40; i++) { if (i > 12 && i < 26) continue; const s = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.3, 1.4), bm); s.position.set(0, 49.15, -100 + i * 1.45); scene.add(shadowAll(s)); }
  const water = new THREE.Mesh(new THREE.PlaneGeometry(1.15, 400), waterMaterial({ color: 0x3a7a8a, opacity: 1, ripple: 1.6 })); water.rotation.x = -Math.PI / 2; water.position.set(0, 48.45, 0); scene.add(water);
  const walls = [-1, 1].map(s => { const w = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.4, 400), bm); w.position.set(s * 1.0, 48.6, 0); scene.add(shadowAll(w)); return w; });
  const N = 60; const fl = new THREE.InstancedMesh(new THREE.BoxGeometry(0.04, 0.01, 0.6), new THREE.MeshBasicMaterial({ color: 0xe8f6ff, transparent: true, opacity: 0.6 }), N); scene.add(fl);
  const D = [...Array(N)].map((_, i) => [Math.sin(i * 12.9898) * 0.45, (i * 0.618) % 1]);
  const m4 = new THREE.Matrix4();
  scene.userData.flow = (t, sp = 0.6) => { D.forEach(([x, ph], i) => { const z = -60 + ((t * sp * 0.05 + ph) % 1) * 120; m4.makeTranslation(x, 48.47, z); fl.setMatrixAt(i, m4); }); fl.instanceMatrix.needsUpdate = true; };
  return scene;
}
function sChannel({ makeStage }) {
  const scene = channelScene(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.flow(t, 1.2);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(3.5, 2.4, k), lerp(52, 50.6, k), lerp(-72, -76, k)], [0, 48.5, lerp(-80, -84, k)]);
      return { bloom: 0.5, flare: 0.8, warm: 1.2 };
    },
  };
}
// ============ S5: the aqueduct's winding route across the hills, seen from high above ============
function sRoute({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.4, 0.69], fog: 0.00012, shadowSize: 200, envI: 0.95, cloud: 0.3 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(3000, 64), new THREE.MeshStandardMaterial({ color: 0x8a8a52, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 5 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 600, rMax: 1800, height: 120, seed: 4, color: 0x6a7a4a }));
  scene.add(trees(ringSpots(300, 20, 230, 9, [0, 0, 0], 0, Math.PI * 2, 0), { seed: 3, scale: 2 }));
  const pts = []; for (let i = 0; i <= 40; i++) { const u = i / 40; pts.push(V(-175 + u * 350, 0.6, Math.sin(u * 9) * 45 + Math.sin(u * 23) * 15)); }
  const curve = new THREE.CatmullRomCurve3(pts);
  const route = new THREE.Mesh(new THREE.TubeGeometry(curve, 400, 2.4, 6), new THREE.MeshStandardMaterial({ color: 0xd8bf8a, roughness: 0.9 })); route.scale.y = 0.5; scene.add(route);
  const water = new THREE.Mesh(new THREE.TubeGeometry(curve, 400, 1.5, 6), new THREE.MeshStandardMaterial({ color: 0x5ab8e8, emissive: 0x3a8aca, emissiveIntensity: 1.2, roughness: 0.2 })); water.position.y = 1.0; scene.add(water);
  const src = glowSprite(0x8ad8ff, 12); src.position.copy(pts[0]).add(V(0, 4, 0)); scene.add(src);
  const city = new THREE.Group(); for (let i = 0; i < 40; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(4, 2 + (i % 4), 3.5), new THREE.MeshStandardMaterial({ color: 0xe0d0b0 })); b.position.set(175 + (i % 8) * 5 - 15, 1.2, Math.floor(i / 8) * 5 - 10 + pts[40].z); city.add(b); } scene.add(shadowAll(city));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const n = 400 * clamp(easeInOut(range(t, 0, 4.4)) + 0.02);
      water.geometry.setDrawRange(0, Math.floor(n) * 6 * 6);
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(-170, -60, k), lerp(210, 240, k), lerp(110, 130, k)], [lerp(-80, 40, k), 0, 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S6: a surveyor's chorobates on the channel, the water barely sloping ============
function chorobates() {
  const A = archMats(); const g = new THREE.Group();
  const top = new THREE.Mesh(new THREE.BoxGeometry(6, 0.18, 0.4), A.wood); top.position.y = 1.0; g.add(top);
  const groove = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.04, 0.1), new THREE.MeshStandardMaterial({ color: 0x5ab8e8, roughness: 0.1, emissive: 0x1a4a6a, emissiveIntensity: 0.5 })); groove.position.y = 1.1; g.add(groove);
  for (const x of [-2.7, 2.7]) for (const z of [-0.15, 0.15]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.0, 0.12), A.wood); l.position.set(x, 0.5, z); g.add(l); }
  for (const x of [-2.2, 2.2]) { const pl = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.7, 6), new THREE.MeshStandardMaterial({ color: 0xd8c8a0 })); pl.position.set(x, 0.55, 0.25); g.add(pl); const bob = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.12, 8), new THREE.MeshStandardMaterial({ color: 0x8a6a3a, metalness: 0.8 })); bob.rotation.x = Math.PI; bob.position.set(x, 0.18, 0.25); g.add(bob); }
  return shadowAll(g);
}
function sSlope({ makeStage, start: ST }) {
  const scene = channelScene(makeStage, { sunDir: [-0.4, 0.4, 0.82] });
  const ch = chorobates(); ch.rotation.y = Math.PI / 2; ch.position.set(0, 49.3, -40); scene.add(ch);
  const surveyor = romanBuilder({ color: 0xa8402c }); surveyor.root.position.set(-1.0, 49.3, -40); surveyor.root.rotation.y = Math.PI / 2; scene.add(surveyor.root);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.flow(t, 0.6);
      standPose(surveyor, t, { spine: [0.35, 0, 0], head: [0.3, 0, 0], neck: [0.1, 0, 0] }); surveyor.setMood('happy'); surveyor.blink(blinkK(t, [1.2]));
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-3.5, -2.6, k), lerp(51.4, 50.8, k), lerp(-34, -35.5, k)], [0, lerp(50.2, 50.0, k), -40]);
      return { bloom: 0.5, warm: 1.2, dof: dofTo([-3, 51, -35], [0, 50, -40], 0.002, 0.008) };
    },
  };
}
// ============ S7: water arrives in Nîmes: the round distribution basin feeds the city's pipes ============
function sCastellum({ makeStage, start: ST }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.45, 0.74], fog: 0.003, shadowSize: 8, envI: 0.95, cloud: 0.3 });
  const A = archMats();
  const pave = new THREE.Mesh(new THREE.CircleGeometry(200, 48), A.stone); pave.rotation.x = -Math.PI / 2; pave.receiveShadow = true; scene.add(pave);
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 1.2, 40, 1, true), blockMat(4, 0.6)); rim.material.side = THREE.DoubleSide; rim.position.y = 0.6; scene.add(shadowAll(rim));
  const water = new THREE.Mesh(new THREE.CircleGeometry(2.95, 40), waterMaterial({ color: 0x3a8a9a, opacity: 1, ripple: 2.2 })); water.rotation.x = -Math.PI / 2; water.position.y = 0.9; scene.add(water);
  const inlet = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.4, 4), blockMat(1, 0.5)); inlet.position.set(0, 1.0, -4.8); scene.add(shadowAll(inlet));
  const fall = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.7), new THREE.MeshStandardMaterial({ color: 0xbfe6f4, transparent: true, opacity: 0.75, roughness: 0.05, side: THREE.DoubleSide })); fall.position.set(0, 1.2, -2.9); fall.rotation.x = 0.4; scene.add(fall);
  const pipes = [...Array(10)].map((_, i) => { const a = Math.PI * 0.15 + i / 9 * Math.PI * 0.7; const p = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 6, 10), new THREE.MeshStandardMaterial({ color: 0x5a5a5e, metalness: 0.6, roughness: 0.5 })); p.rotation.z = Math.PI / 2; p.rotation.y = -a; p.position.set(Math.cos(a) * 6, 0.3, Math.sin(a) * 6); scene.add(shadowAll(p)); return p; });
  const houses = [...Array(12)].map((_, i) => { const a = Math.PI * 0.1 + i / 11 * Math.PI * 0.8; const h = new THREE.Mesh(new THREE.BoxGeometry(5, 4, 5), new THREE.MeshStandardMaterial({ color: 0xe8dcc0 })); h.position.set(Math.cos(a) * 16, 2, Math.sin(a) * 16); h.rotation.y = -a; scene.add(shadowAll(h)); return h; });
  const spl = [...Array(16)].map((_, i) => { const s = glowSprite(0xe8f8ff, 0.12); scene.add(s); return { s, i }; });
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      spl.forEach(({ s, i }) => { const a = ((t * 1.5 + i / 16) % 1); s.position.set(Math.sin(i * 2) * 0.4, 0.95 + Math.sin(Math.PI * a) * 0.3, -2.7 + a * 0.8); s.material.opacity = 0.8 * (1 - a); });
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(4, 7, k), lerp(4, 9, k), lerp(7, 12, k)], [0, 0.6, lerp(-0.5, 1, k)]);
      return { bloom: 0.55, flare: 0.9, warm: 1.25 };
    },
  };
}
// ============ S8: golden end, visitors on the riverbank, camera rises ============
function sEnd({ makeStage }) {
  const scene = valley(makeStage, { sunDir: [-0.75, 0.22, 0.62] });
  bridgeIn(scene);
  const folk = [0, 1, 2, 3].map(i => { const m = romanBuilder({ color: [0x2a5a9a, 0xd84a3a, 0x3a8a5a, 0xe8c040][i] }); m.root.position.set(-30 + i * 1.3, 0.5, 40 + (i % 2)); m.root.rotation.y = 2.6; scene.add(m.root); return m; });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((m, i) => { standPose(m, t + i, { head: [-0.3, 0, 0] }); m.setMood('happy'); });
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(-34, -70, k), lerp(2.2, 30, k), lerp(46, 120, k)], [lerp(-10, 0, k), lerp(14, 26, k), 0]);
      return { bloom: 0.65, flare: 1.2, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sWide, 'wide'],
  [ls(2), ls(3), sTall, 'tall'],
  [ls(3), ls(4), sBlocks, 'blocks'],
  [ls(4), ls(5), sChannel, 'channel'],
  [ls(5), ls(6), sRoute, 'route'],
  [ls(6), ls(7), sSlope, 'slope'],
  [ls(7), ls(8), sCastellum, 'castellum'],
  [ls(8), DURATION + 1, sEnd, 'end'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
