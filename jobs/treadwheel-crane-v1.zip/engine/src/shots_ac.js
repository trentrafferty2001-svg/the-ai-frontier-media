// Claw of Archimedes reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { splash2 } from './farm2.js';
import { mountains } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { archMats, shadowAll, canvasTex } from './rome.js';
import { sea } from './norse.js';
import { greek, greekTemple } from './classic.js';
import { cityWall } from './rice.js';
import { galley, legionary, march } from './ancientkit.js';
import { VO } from './vo_ac.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This machine', 2], ['could *reportedly*', 2], ['*lift a warship*', 3], ['right out', 2], ['of the *sea*', 3]],
  [['More than', 2], ['*2,000 years* ago', 4], ['*Rome* attacked', 2], ['the Greek city', 3], ['of *Syracuse*', 2], ['in *Sicily*', 2]],
  [['Its defenses', 2], ['were designed by', 3], ['*Archimedes*', 1], ['the famous', 2], ['*mathematician*', 1]],
  [['Ancient writers', 2], ['describe', 1], ['a *huge crane*', 3], ['behind the walls', 3], ['called *the Claw*', 3]],
  [['A long *beam*', 3], ['swung out', 2], ['over the water', 3], ['and dropped', 2], ['an *iron hook*', 3], ["onto a ship's *bow*", 4]],
  [['Then a heavy', 3], ['*counterweight*', 1], ['pulled the beam down', 4], ['and the bow', 3], ['*rose* into the air', 4]],
  [['The ship', 2], ['*stood on its stern*', 4], ['then the hook', 3], ['was *released*', 2], ['and it *crashed*', 3], ['back down', 2]],
  [['*No plans* survive', 3], ['so *nobody knows*', 3], ['exactly', 1], ['how it looked', 3]],
  [['But *Syracuse*', 2], ['held out', 2], ['for about', 2], ['*2 years*', 2], ['before Rome', 2], ['finally *broke in*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ---------- props ----------
const wood = () => new THREE.MeshStandardMaterial({ color: 0x6a4626, roughness: 0.85, bumpMap: fabricTexture(13), bumpScale: 2 });
const iron = () => new THREE.MeshStandardMaterial({ color: 0x3a3a3e, metalness: 0.8, roughness: 0.4 });
function claw() {
  const g = new THREE.Group(); const M = iron();
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.06, 8, 16), M); ring.position.y = 0.35; g.add(ring);
  const shank = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.9, 10), M); shank.position.y = -0.1; g.add(shank);
  for (let i = 0; i < 4; i++) { const t = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.07, 8, 16, Math.PI * 0.9), M); t.rotation.set(0, i * Math.PI / 2, Math.PI * 1.05); t.position.set(Math.cos(i * Math.PI / 2) * 0.45, -0.55, -Math.sin(i * Math.PI / 2) * 0.45); g.add(t); }
  return shadowAll(g);
}
// the crane on the wall top: A-frame, a yaw turntable, a beam (long arm 10 toward local +x, short arm 5 with a lead counterweight)
function crane() {
  const W = wood(); const g = new THREE.Group();
  for (const z of [-1.2, 1.2]) for (const x of [-1.6, 1.6]) { const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.24, 6.4, 8), W); leg.position.set(x / 2, 3, z / 2); leg.rotation.set(z * -0.12, 0, x * 0.1); g.add(leg); }
  const base = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.5, 3.6), W); base.position.y = 0.25; g.add(base);
  const yaw = new THREE.Group(); yaw.position.y = 6.2; g.add(yaw);
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 2.0, 12), iron()); axle.rotation.x = Math.PI / 2; yaw.add(axle);
  const beam = new THREE.Group(); yaw.add(beam);
  const bm = new THREE.Mesh(new THREE.BoxGeometry(15.5, 0.55, 0.55), W); bm.position.x = 2.5; beam.add(bm);
  for (const x of [-3, 2, 6]) { const band = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.62, 0.62), iron()); band.position.x = x; beam.add(band); }
  const cw = new THREE.Group(); cw.position.x = -5; beam.add(cw);
  const cwRope = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.2, 6), new THREE.MeshStandardMaterial({ color: 0x8a7a5a })); cwRope.position.y = -0.6; cw.add(cwRope);
  const lead = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.4, 1.4), new THREE.MeshStandardMaterial({ color: 0x6a6e74, metalness: 0.5, roughness: 0.5 })); lead.position.y = -1.9; cw.add(lead);
  const tip = new THREE.Object3D(); tip.position.x = 10.2; beam.add(tip);
  g.yaw = yaw; g.beam = beam; g.tip = tip; g.cw = cw;
  return shadowAll(g);
}
function rope(mat) { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1, 6), mat); m.castShadow = true; m.set = (a, b) => { const d = b.clone().sub(a); m.position.copy(a).addScaledVector(d, 0.5); m.scale.set(1, Math.max(0.001, d.length()), 1); m.quaternion.setFromUnitVectors(V(0, 1, 0), d.normalize()); }; return m; }
function houses(scene, { x0 = -60, x1 = -10, z0 = -50, z1 = 50, n = 70, seed = 4 } = {}) {
  const R = R0(seed); const A = archMats();
  const walls = new THREE.MeshStandardMaterial({ color: 0xe8dcc4, roughness: 0.9 }); const roof = new THREE.MeshStandardMaterial({ color: 0xb85a3a, roughness: 0.85 });
  for (let i = 0; i < n; i++) { const w = 3 + R() * 3, d = 3 + R() * 3, h = 2.5 + R() * 3; const hx = lerp(x0, x1, R()), hz = lerp(z0, z1, R()); const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), walls); b.position.set(hx, h / 2, hz); scene.add(shadowAll(b)); const r = new THREE.Mesh(new THREE.ConeGeometry(Math.max(w, d) * 0.75, 1.2, 4), roof); r.rotation.y = Math.PI / 4; r.position.set(hx, h + 0.6, hz); r.scale.set(w / Math.max(w, d), 1, d / Math.max(w, d)); scene.add(shadowAll(r)); }
}
// the coastal scene: sea at x > 0, the wall along z at x in [-6, 0], the crane on top, a galley approaching bow-first
function clawScene(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.55, 0.45, 0.7], fog: 0.003, shadowSize: 40, envI: 0.95, cloud: 0.35, ...opts });
  sea(scene, { color: 0x2a5a6a });
  const land = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: 0xb8a070, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); land.rotation.x = -Math.PI / 2; land.position.set(-206, 0.5, 0); land.receiveShadow = true; scene.add(land);
  const wall = cityWall({ len: 120, h: 12, d: 6, gate: false }); wall.rotation.y = Math.PI / 2; wall.position.set(-3, -1, 0); scene.add(wall);
  houses(scene, { x0: -60, x1: -10, z0: -55, z1: 55 });
  const tp = greekTemple({ w: 8, d: 14, colH: 4.2 }); tp.position.set(-30, 0.5, -14); scene.add(tp);
  scene.add(mountains({ rMin: 220, rMax: 360, height: 14, seed: 6, color: 0x8a8a5a, thetaFrom: Math.PI * 0.6, thetaTo: Math.PI * 1.4 }));
  fillLight(scene, [-0.5, 0.4, 1], 0.6, 0xffe6c8);
  const cr = crane(); cr.position.set(-3, 11, 0); scene.add(cr);
  const pivot = new THREE.Group(); pivot.position.set(22, 0, 0); scene.add(pivot);
  const holder = new THREE.Group(); holder.position.set(-8, 0, 0); holder.rotation.y = Math.PI; pivot.add(holder);
  const ship = galley({ L: 16, sail: 0xa8302a }); holder.add(shadowAll(ship));
  const bowPt = new THREE.Object3D(); bowPt.position.set(7.2, 1.7, 0); holder.add(bowPt);
  const hook = claw(); scene.add(hook);
  const rp = rope(new THREE.MeshStandardMaterial({ color: 0x5a4a3a, roughness: 1 })); scene.add(rp);
  const drips = [...Array(40)].map((_, i) => { const s = glowSprite(0xd8eef8, 0.12); s.material.blending = THREE.NormalBlending; scene.add(s); return s; });
  const spl = splash2(4, 7); scene.add(spl);
  const tipW = V(0, 0, 0), bowW = V(0, 0, 0), up = V(0, 0.6, 0);
  // state: swing 0 (beam along the wall) -> 1 (out over the sea); drop 0 (hook at the tip) -> 1 (on the bow); lift = beam pitch; phi = ship pitch; free = hook released
  scene.userData.set = ({ swing = 1, drop = 1, lift = 0, phi = 0, release = 0, t = 0, shipX = 0 }) => {
    cr.yaw.rotation.y = lerp(Math.PI / 2, 0, swing);
    cr.beam.rotation.z = lift; cr.cw.rotation.z = -lift;
    pivot.position.x = 22 + shipX; pivot.rotation.z = -phi; pivot.position.y = Math.sin(t * 1.3) * 0.08 * (phi < 0.05 ? 1 : 0);
    scene.updateMatrixWorld(true);
    cr.tip.getWorldPosition(tipW); bowPt.getWorldPosition(bowW);
    const hp = release > 0 ? tipW.clone().add(V(0, -2 - release * 1.5, 0)) : tipW.clone().lerp(bowW.clone().add(up), drop);
    hook.position.copy(hp); hook.rotation.set(0, 0, release > 0 ? 0 : -phi * drop * 0.8);
    rp.set(tipW, hp.clone().add(V(0, 0.55, 0)));
    drips.forEach((s, i) => { const a = (t * 1.2 + i / 40) % 1; s.visible = phi > 0.2 && release === 0; s.position.set(bowW.x + 22 * 0 + (pivot.position.x - bowW.x) * ((i % 10) / 10), bowW.y * (1 - (i % 10) / 10) - a * 6, Math.sin(i * 2.3) * 1.2); s.material.opacity = 0.75 * (1 - a); });
  };
  scene.userData.splash = (t, on) => { spl.visible = on; if (on) { spl.position.set(14 + 0, 0.05, 0); spl.update(t); } };
  scene.userData.bowW = bowW; scene.userData.tipW = tipW;
  return scene;
}

// ============ S0 hook: a galley dangling bow-up from the claw, seen from the water ============
function sHook({ makeStage }) {
  const scene = clawScene(makeStage);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const phi = lerp(0.55, 1.05, easeInOut(range(t, 0, 3.6))) + Math.sin(t * 2.2) * 0.03;
      scene.userData.set({ swing: 1, drop: 1, lift: lerp(0.15, 0.42, easeInOut(range(t, 0, 3.6))), phi, t });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(34, 30, k), lerp(1.6, 2.4, k), lerp(20, 17, k)], [lerp(14, 12, k), lerp(9, 10, k), 0]);
      return { bloom: 0.5, flare: 1.0, warm: 1.2 };
    },
  };
}
// ============ S1: the Roman fleet rows toward the walls of Syracuse ============
function sFleet({ makeStage }) {
  const scene = clawScene(makeStage);
  scene.userData.set({ swing: 0, drop: 0, phi: 0, shipX: 30 });
  const fleet = [...Array(7)].map((_, i) => { const s = galley({ L: 16, sail: 0xa8302a }); s.rotation.y = Math.PI; s.position.set(60 + (i % 4) * 22, 0, -36 + i * 12); scene.add(shadowAll(s)); return s; });
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.set({ swing: 0, drop: 0, phi: 0, shipX: 30 - t * 1.2, t });
      fleet.forEach((s, i) => { s.position.x = 60 + (i % 4) * 22 - t * 2.0; s.position.y = Math.sin(t * 1.3 + i) * 0.1; });
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(140, 115, k), lerp(14, 11, k), lerp(46, 40, k)], [lerp(10, 0, k), lerp(6, 8, k), lerp(-4, 0, k)]);
      return { bloom: 0.5, flare: 1.0, warm: 1.2 };
    },
  };
}
// ============ S2: Archimedes draws circles in a sand tray ============
function sArchimedes({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.5, 0.7], fog: 0.004, shadowSize: 8, envI: 0.95, cloud: 0.3 });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.MeshStandardMaterial({ color: 0xd8c8a8, roughness: 0.9, bumpMap: fabricTexture(23), bumpScale: 2 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const A = archMats();
  for (let i = 0; i < 6; i++) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 4.2, 20), new THREE.MeshStandardMaterial({ color: 0xece4d4, roughness: 0.8 })); c.position.set(-5 + i * 2.2, 2.1, -4.5); scene.add(shadowAll(c)); }
  const ent = new THREE.Mesh(new THREE.BoxGeometry(14, 0.6, 1.2), new THREE.MeshStandardMaterial({ color: 0xece4d4 })); ent.position.set(0.5, 4.5, -4.5); scene.add(shadowAll(ent));
  const table = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.08, 1.0), wood()); table.position.set(0, 0.86, 0); scene.add(shadowAll(table));
  for (const x of [-0.7, 0.7]) for (const z of [-0.4, 0.4]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.82, 0.07), wood()); l.position.set(x, 0.41, z); scene.add(l); }
  const tray = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.06, 0.8), new THREE.MeshStandardMaterial({ color: 0xe0cc98, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 2 })); tray.position.set(0, 0.93, 0); scene.add(tray);
  const lines = new THREE.MeshBasicMaterial({ color: 0x8a6a3a });
  const circles = [[0.15, 0, 0.22], [-0.32, 0.12, 0.14], [0.36, -0.15, 0.1]].map(([x, z, r]) => { const m = new THREE.Mesh(new THREE.RingGeometry(r - 0.008, r + 0.008, 64, 1, 0, 0.01), lines); m.rotation.x = -Math.PI / 2; m.position.set(x, 0.962, z); scene.add(m); m.r = r; return m; });
  const arch = greek({ color: 0xf2ede0, beard: true }); arch.root.position.set(0, 0, 0.75); arch.root.rotation.y = Math.PI; scene.add(arch.root);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      circles.forEach((m, i) => { const k = range(t, 0.3 + i * 1.0, 1.2 + i * 1.0); m.geometry.dispose(); m.geometry = new THREE.RingGeometry(m.r - 0.008, m.r + 0.008, 64, 1, 0, Math.max(0.01, k * Math.PI * 2)); });
      standPose(arch, t, { spine: [0.45, 0, 0], head: [0.35, 0, 0], rSh: [-0.9, 0, -0.1], rEl: [-0.5, 0, 0], lSh: [-0.2, 0, 0.1] }); arch.setMood('happy'); arch.blink(blinkK(t, [1.5, 3.4]));
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-1.8, -1.2, k), lerp(1.8, 1.6, k), lerp(-2.2, -1.6, k)], [0, lerp(1.2, 1.3, k), 0.4]);
      return { bloom: 0.5, warm: 1.2, dof: dofTo([-1.5, 1.7, -1.9], [0, 1.3, 0.4], 0.003, 0.008) };
    },
  };
}
// ============ S3: the crane behind the walls ============
function sCrane({ makeStage }) {
  const scene = clawScene(makeStage);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.set({ swing: 0, drop: 0, phi: 0, shipX: 26 - t, t });
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-22, -18, k), lerp(19, 21, k), lerp(22, 18, k)], [-3, 14, -3]);
      return { bloom: 0.5, flare: 0.9, warm: 1.2 };
    },
  };
}
// ============ S4: the beam swings out and the hook drops onto the bow ============
function sDrop({ makeStage, start: ST }) {
  const tS = at(4, 'swung') - ST, tD = at(4, 'dropped') - ST, tB = at(4, 'bow') - ST;
  const scene = clawScene(makeStage);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.set({ swing: easeInOut(range(t, tS - 0.3, tS + 1.4)), drop: easeIn(range(t, tD, tB + 0.1)), phi: 0, t });
      const sh = range(t, tB + 0.1, tB + 0.4) > 0 && t < tB + 0.4 ? shake(t * 5, 2, 2) : [0, 0, 0];
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(20, 24, k) + sh[0] * 0.05, lerp(8, 6, k) + sh[1] * 0.05, lerp(30, 27, k)], [lerp(3, 7, k), lerp(12, 6, k), 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S5: the counterweight pulls the short arm down; the bow rises ============
function sLift({ makeStage, start: ST }) {
  const tC = at(5, 'counterweight') - ST, tR = at(5, 'rose') - ST;
  const scene = clawScene(makeStage);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const k1 = easeInOut(range(t, tC, tR + 0.8));
      scene.userData.set({ swing: 1, drop: 1, lift: 0.45 * k1, phi: 0.55 * k1, t });
      const k = easeInOut(range(t, 0, 4.8));
      place(c, [lerp(12, 8, k), lerp(4, 5, k), lerp(30, 32, k)], [lerp(4, 8, k), lerp(10, 9, k), 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S6: standing on its stern, released, crashing down ============
function sCrash({ makeStage, start: ST }) {
  const tR = at(6, 'released') - ST, tC = at(6, 'crashed') - ST;
  const scene = clawScene(makeStage);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const rel = t > tR ? 1 : 0;
      const up = lerp(0.55, 1.15, easeInOut(range(t, 0, tR - 0.2)));
      const fall = easeIn(range(t, tR, tC + 0.05));
      const phi = rel ? up * (1 - fall) + Math.max(0, Math.sin((t - tC) * 6) * 0.06 * (1 - range(t, tC, tC + 1.5))) * (t > tC ? 1 : 0) : up;
      scene.userData.set({ swing: 1, drop: 1, lift: rel ? lerp(0.5, 0.2, range(t, tR, tR + 1)) : lerp(0.45, 0.55, range(t, 0, tR)), phi, release: rel ? range(t, tR, tR + 0.6) : 0, t });
      const on = t > tC - 0.05 && t < tC + 1.8; scene.userData.splash(t - tC + 0.05, on);
      const sh = t > tC && t < tC + 0.5 ? shake(t * 5, 3, 5) : [0, 0, 0];
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(30, 34, k) + sh[0] * 0.15, lerp(3, 4, k) + sh[1] * 0.15, lerp(26, 30, k)], [lerp(14, 14, k), lerp(9, 4, k), 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S7: three guesses at the design, as ghostly models ============
function sGuess({ makeStage }) {
  const scene = makeStage({ shadowSize: 10, sunDir: [-2, 6, 4], envI: 0.9 });
  scene.background = new THREE.Color(0x1a2026);
  const floor = new THREE.Mesh(new THREE.CircleGeometry(30, 48), new THREE.MeshStandardMaterial({ color: 0x2a3036, roughness: 0.8 })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const ghost = new THREE.MeshStandardMaterial({ color: 0x8ac8f0, emissive: 0x2a6a9a, emissiveIntensity: 0.6, transparent: true, opacity: 0.55, roughness: 0.4 });
  const models = [0, 1, 2].map(i => {
    const g = new THREE.Group();
    const plinth = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.2, 0.5, 32), new THREE.MeshStandardMaterial({ color: 0x4a525a, roughness: 0.6 })); plinth.position.y = 0.25; g.add(plinth);
    const m = new THREE.Group(); m.position.y = 0.5; g.add(m);
    const box = (w, h, d, x, y, z, rz = 0) => { const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), ghost); b.position.set(x, y, z); b.rotation.z = rz; m.add(b); };
    if (i === 0) { box(0.15, 1.6, 0.15, 0, 0.8, 0); box(2.4, 0.1, 0.1, 0.5, 1.65, 0, 0.25); box(0.3, 0.3, 0.3, -0.6, 1.2, 0); box(0.03, 0.8, 0.03, 1.6, 1.6, 0); }
    if (i === 1) { box(0.6, 0.9, 0.6, 0, 0.45, 0); box(0.1, 1.2, 0.1, -0.2, 1.4, 0, -0.3); box(2.0, 0.1, 0.1, 0.6, 1.9, 0, -0.1); box(0.03, 1.0, 0.03, 1.55, 1.3, 0); box(0.4, 0.2, 0.4, -0.4, 1.0, 0); }
    if (i === 2) { box(0.12, 1.2, 0.12, -0.3, 0.6, 0.2); box(0.12, 1.2, 0.12, -0.3, 0.6, -0.2); box(2.6, 0.12, 0.12, 0.4, 1.3, 0, 0.45); box(0.25, 0.5, 0.25, -0.6, 0.6, 0); box(0.03, 0.6, 0.03, 1.5, 1.6, 0); }
    const q = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.035, 8, 20, Math.PI * 1.3), new THREE.MeshBasicMaterial({ color: 0xffd040 })); q.rotation.z = -0.6; q.position.set(0, 3.1, 0); g.add(q);
    const qd = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.18, 8), q.material); qd.position.set(0.02, 2.82, 0); g.add(qd);
    const dot = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), q.material); dot.position.set(0.02, 2.62, 0); g.add(dot);
    g.position.set([-1.0, 1.1, -0.8][i], 0, -i * 3.5); scene.add(g); g.m = m; return g;
  });
  const spot = new THREE.SpotLight(0xffffff, 40, 30, 0.6, 0.5); spot.position.set(0, 10, 6); scene.add(spot);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      models.forEach((g, i) => { g.m.rotation.y = t * 0.5 + i; g.m.children.forEach(b => b.material.opacity = 0.35 + 0.25 * Math.sin(t * 3 + i)); });
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(0.4, 0.8, k), lerp(4.5, 4.0, k), lerp(7.5, 6.5, k)], [0, 1.2, -3.8]);
      return { bloom: 0.7, warm: 1.0 };
    },
  };
}
// ============ S8: the siege drags on; Roman camp before the walls at sunset ============
function sSiege({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.7, 0.12, 0.7], fog: 0.004, shadowSize: 40, envI: 0.9, cloud: 0.5 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 48), new THREE.MeshStandardMaterial({ color: 0xb8a070, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const wall = cityWall({ len: 160, h: 12, d: 6, gate: false }); wall.position.set(0, 0, -30); scene.add(wall);
  houses(scene, { x0: -60, x1: 60, z0: -90, z1: -40, n: 60, seed: 9 });
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffd8b0);
  const tent = new THREE.MeshStandardMaterial({ color: 0xd8c8a8, roughness: 1, side: THREE.DoubleSide });
  const R = R0(3);
  for (let i = 0; i < 26; i++) { const tn = new THREE.Mesh(new THREE.ConeGeometry(1.6, 2, 4, 1, true), tent); tn.rotation.y = Math.PI / 4; tn.position.set(-30 + (i % 9) * 7 + R() * 2, 1, 12 + Math.floor(i / 9) * 6 + R() * 2); scene.add(shadowAll(tn)); }
  const L = []; for (let r = 0; r < 5; r++) for (let q = 0; q < 6; q++) { const m = legionary(); m.root.position.set(-4 + q * 1.4, 0, 2 - r * 1.5); m.root.rotation.y = Math.PI; scene.add(m.root); L.push({ m, r, q }); }
  const gs = new THREE.Shape(); gs.moveTo(-2.5, 0); gs.lineTo(2.5, 0); gs.lineTo(2.5, 4); gs.absarc(0, 4, 2.5, 0, Math.PI, false); gs.lineTo(-2.5, 0);
  const gate = new THREE.Mesh(new THREE.ShapeGeometry(gs, 24), new THREE.MeshStandardMaterial({ color: 0x3a2a1c, roughness: 1 })); gate.position.set(0, 0.01, -26.95); scene.add(gate);
  for (const x of [-10, 10]) { const tw = new THREE.Mesh(new THREE.BoxGeometry(6, 16, 8), wall.face); tw.position.set(x, 8, -30); scene.add(shadowAll(tw)); }
  const fires = [];
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      L.forEach(({ m, r, q }) => { march(m, t, r * 0.6 + q * 0.2); m.root.position.z = 2 - r * 1.5 - t * 1.4; });
      fires.forEach((s, i) => s.scale.setScalar(1.0 + 0.2 * Math.sin(t * 9 + i)));
      const k = easeInOut(range(t, 0, 5.6));
      place(c, [lerp(10, 4, k), lerp(5, 9, k), lerp(32, 34, k)], [0, lerp(4, 6, k), lerp(-8, -20, k)]);
      return { bloom: 0.6, flare: 1.2, warm: 1.35 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sFleet, 'fleet'],
  [ls(2), ls(3), sArchimedes, 'archimedes'],
  [ls(3), ls(4), sCrane, 'crane'],
  [ls(4), ls(5), sDrop, 'drop'],
  [ls(5), ls(6), sLift, 'lift'],
  [ls(6), ls(7), sCrash, 'crash'],
  [ls(7), ls(8), sGuess, 'guess'],
  [ls(8), DURATION + 1, sSiege, 'siege'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
