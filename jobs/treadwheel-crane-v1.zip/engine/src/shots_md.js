// Mohenjo-daro drains reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { mountains, trees, ringSpots, waterMaterial } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { shadowAll, romanBuilder, canvasTex, archMats } from './rome.js';
import { VO } from './vo_md.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*4,500 years* ago', 6], ['this city', 2], ['already had', 2], ['*bathrooms*', 1], ['and *sewers*', 2]],
  [["It's *Mohenjo-daro*", 3], ['in what is now', 4], ['*Pakistan*', 1], ['home to', 2], ['tens of thousands', 3], ['of people', 2]],
  [['Its streets', 2], ['ran in a *grid*', 4], ['built from', 2], ['*baked bricks*', 2], ['of *standard sizes*', 3]],
  [['Many houses had', 3], ['a *bathing floor*', 3], ['and a *toilet*', 3], ['linked to', 2], ['a *brick drain*', 3]],
  [['*Clay pipes*', 2], ['inside the walls', 3], ['even carried water', 3], ['down from', 2], ['*upstairs bathrooms*', 2]],
  [['It all ran into', 4], ['*covered drains*', 2], ['under the streets', 3], ['flowing by *gravity*', 3]],
  [['Every so often', 3], ['*removable bricks*', 2], ['let workers', 2], ['*open* the drain', 3], ['and *clean* it', 3]],
  [['Most houses had', 3], ['their *own well*', 3], ['and the city had', 4], ['over *700*', 3]],
  [["Rome's famous", 2], ['*great sewer*', 2], ['came almost', 2], ['*2,000 years later*', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;

// ---------- materials ----------
let BR_ = null;
function brickTex() {
  if (BR_) return BR_;
  BR_ = canvasTex(256, 256, (x) => { const R = R0(5); x.fillStyle = '#8a5a3a'; x.fillRect(0, 0, 256, 256); for (let r = 0; r < 8; r++) for (let c = -1; c < 5; c++) { const off = (r % 2) * 32; const g = R(); x.fillStyle = `rgb(${190 + g * 30 | 0},${118 + g * 22 | 0},${78 + g * 16 | 0})`; x.fillRect(c * 64 + off + 2, r * 32 + 2, 60, 28); for (let k = 0; k < 20; k++) { x.fillStyle = 'rgba(90,50,30,0.15)'; x.fillRect(c * 64 + off + R() * 60, r * 32 + R() * 28, 3, 2); } } });
  BR_.wrapS = BR_.wrapT = THREE.RepeatWrapping; return BR_;
}
// bricks in world units: each texture tile = 1.0 m wide, 0.5 m tall (16 courses ~ bricks 0.25 x 0.0625... stylized)
function brick(rx = 1, ry = 1, opts = {}) { const t = brickTex().clone(); t.needsUpdate = true; t.repeat.set(rx, ry); return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 3, roughness: 0.9, ...opts }); }
const soil = () => new THREE.MeshStandardMaterial({ color: 0x7a5a3e, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 });
const clay = () => new THREE.MeshStandardMaterial({ color: 0xb8643a, roughness: 0.8 });
const waterM = () => new THREE.MeshStandardMaterial({ color: 0x4aa8d8, roughness: 0.1, emissive: 0x0a4a7a, emissiveIntensity: 0.6, transparent: true, opacity: 0.9 });
function box(w, h, d, mat, x, y, z, parent) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; parent.add(m); return m; }
function tube(pts, r, mat, parent) { const c = new THREE.CatmullRomCurve3(pts.map(p => V(...p)), false, 'catmullrom', 0.01); const m = new THREE.Mesh(new THREE.TubeGeometry(c, 64, r, 10), mat); m.castShadow = true; parent.add(m); return m; }
// water streaks running along a polyline
function flowAlong(scene, pts, n = 24, { size = 0.12, speed = 0.6, color = 0x6ac8ff } = {}) {
  const P = pts.map(p => V(...p)); const L = []; let tot = 0; for (let i = 1; i < P.length; i++) { const d = P[i].distanceTo(P[i - 1]); L.push(d); tot += d; }
  const im = new THREE.InstancedMesh(new THREE.SphereGeometry(size, 8, 6), new THREE.MeshBasicMaterial({ color }), n); scene.add(im);
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), p = V(0, 0, 0);
  return (t, on = 1) => { for (let i = 0; i < n; i++) { let s = ((t * speed * 3 / tot + i / n) % 1) * tot; let k = 0; while (k < L.length - 1 && s > L[k]) { s -= L[k]; k++; } p.copy(P[k]).lerp(P[k + 1], Math.min(1, s / L[k])); m4.compose(p, q, V(1, 1, 1).multiplyScalar(on > 0.05 ? on : 1e-4)); im.setMatrixAt(i, m4); } im.instanceMatrix.needsUpdate = true; };
}
function person(color, skin = 0x9a6a48) { const h = romanBuilder({ color, skin }); return h; }

// ---------- the cutaway district: front cut at z = 0 ----------
// house A: x -8..2 (two storeys), street: x 2..8 with the covered drain at x 4.5..5.5 under it, house B: x 8..16
function district(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.45, 0.6, 0.66], fog: 0.004, shadowSize: 22, envI: 0.95, cloud: 0.3, ...opts });
  fillLight(scene, [0.4, 0.5, 1], 0.7, 0xffe6c8);
  const g = new THREE.Group(); scene.add(g);
  const S = soil(); const D = 12;
  const ground = (x0, x1, y0, y1) => { const m = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, y1 - y0, D), S); m.position.set((x0 + x1) / 2, (y0 + y1) / 2, -D / 2); m.receiveShadow = true; g.add(m); };
  ground(-60, 4.4, -8, -0.05); ground(5.6, 60, -8, -0.05); ground(4.4, 5.6, -8, -1.0);
  const far = new THREE.Mesh(new THREE.PlaneGeometry(400, 300), new THREE.MeshStandardMaterial({ color: 0xc8a878, roughness: 1 })); far.rotation.x = -Math.PI / 2; far.position.set(0, -0.05, -D - 150); g.add(far);
  // street surface (packed earth) and the drain: brick-lined channel with a brick cover; covers along z are separate so they can lift
  const street = new THREE.Mesh(new THREE.PlaneGeometry(6, D), new THREE.MeshStandardMaterial({ color: 0xb89a70, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); street.rotation.x = -Math.PI / 2; street.position.set(5, -0.04, -D / 2); street.receiveShadow = true; g.add(street);
  const B = brick(1, 1);
  box(0.25, 0.8, D, B, 4.55, -0.55, -D / 2, g); box(0.25, 0.8, D, B, 5.45, -0.55, -D / 2, g); box(1.1, 0.1, D, B, 5, -0.95, -D / 2, g);
  const covers = []; for (let i = 0; i < 12; i++) covers.push(box(1.3, 0.12, 0.95, brick(1.3, 0.25), 5, -0.09, -0.5 - i * 1.0, g));
  const water = new THREE.Mesh(new THREE.BoxGeometry(0.62, 1, D), waterM()); water.position.set(5, -0.85, -D / 2); g.add(water);
  scene.userData.drainLevel = (lv) => { water.scale.y = Math.max(0.01, lv); water.position.y = -0.9 + lv / 2; };
  scene.userData.drainLevel(0.15);
  // house A (cut open)
  const W = brick(2, 2); const wallsA = [];
  wallsA.push(box(0.5, 7.2, D, W, -7.75, 3.6, -D / 2, g)); wallsA.push(box(10, 7.2, 0.5, W, -3, 3.6, -D + 0.25, g));
  const sideA = box(0.5, 7.2, D, brick(2, 2, { transparent: true, opacity: 1 }), 1.75, 3.6, -D / 2, g); wallsA.push(sideA);
  box(0.4, 7.2, D - 4, W, -3, 3.6, -D / 2 - 2, g); // partition with a doorway at the front
  const floorM = brick(3, 3); box(10, 0.25, D, floorM, -3, 3.55, -D / 2, g); box(10, 0.3, D, new THREE.MeshStandardMaterial({ color: 0xb08a5a, roughness: 1 }), -3, 7.3, -D / 2, g);
  box(10, 0.1, D, brick(4, 4), -3, 0.0, -D / 2, g);
  // bathing floors (ground and upstairs) and a brick toilet seat, in the street-side room x -2.8..1.5
  const bath = (y) => { box(2.2, 0.12, 2.0, brick(2, 2), 0.2, y + 0.06, -1.1, g); const lip = box(0.12, 0.2, 2.0, B, -0.95, y + 0.1, -1.1, g); return lip; };
  bath(0.05); bath(3.68);
  const seat = new THREE.Group(); box(0.8, 0.5, 0.7, B, 0, 0.25, 0, seat); const hole = new THREE.Mesh(new THREE.CircleGeometry(0.16, 16), new THREE.MeshStandardMaterial({ color: 0x1a1008 })); hole.rotation.x = -Math.PI / 2; hole.position.y = 0.51; seat.add(hole); seat.position.set(0.9, 0.05, -3.2); g.add(seat);
  // clay pipes: from each bathing floor through the street wall; the upstairs one runs down inside the wall, then under the street to the drain
  const C = clay();
  tube([[1.0, 0.08, 0], [1.75, 0.0, 0], [3.0, -0.35, 0], [4.5, -0.7, 0]], 0.1, C, g);
  tube([[1.0, 3.72, 0], [1.75, 3.6, 0], [1.75, 0.5, 0], [1.8, -0.3, 0], [3.0, -0.48, 0], [4.5, -0.75, 0]], 0.1, C, g);
  scene.userData.flowLow = flowAlong(scene, [[0.2, 0.15, -1.0], [1.0, 0.1, 0.11], [1.75, 0.0, 0.11], [3.0, -0.35, 0.11], [4.6, -0.75, 0.11], [5.0, -0.82, 0.05]], 18, { size: 0.065 });
  scene.userData.flowUp = flowAlong(scene, [[0.2, 3.8, -1.0], [1.0, 3.72, 0.11], [1.75, 3.6, 0.11], [1.75, 0.5, 0.11], [1.8, -0.3, 0.11], [3.0, -0.48, 0.11], [4.6, -0.78, 0.11], [5.0, -0.84, 0.05]], 30, { size: 0.065 });
  scene.userData.flowDrain = flowAlong(scene, [[5.0, -0.8, -D + 0.2], [5.0, -0.8, 0.3]].reverse(), 40, { size: 0.07, speed: 0.9 });
  scene.userData.sideA = sideA;
  // house B: a simple block with a doorway, set back
  box(0.5, 4, D, W, 8.25, 2, -D / 2, g); box(8, 4, 0.5, W, 12, 2, -D + 0.25, g); box(8, 0.3, D, new THREE.MeshStandardMaterial({ color: 0xb08a5a }), 12, 4.1, -D / 2, g);
  // a well in house B's courtyard
  const well = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.9, 24, 1, true), brick(3, 0.6, { side: THREE.DoubleSide })); well.position.set(11.5, 0.45, -5); g.add(shadowAll(well));
  const wd = new THREE.Mesh(new THREE.CircleGeometry(0.72, 24), new THREE.MeshStandardMaterial({ color: 0x0a1a24 })); wd.rotation.x = -Math.PI / 2; wd.position.set(11.5, 0.3, -5); g.add(wd);
  scene.userData.covers = covers;
  return scene;
}
function cityGrid(scene, { n = 9, block = 14, street = 4, seed = 3 } = {}) {
  const R = R0(seed); const W = brick(3, 2); const roof = new THREE.MeshStandardMaterial({ color: 0xb89870, roughness: 1 });
  const span = n * (block + street);
  const grd = new THREE.Mesh(new THREE.PlaneGeometry(span + 200, span + 200), new THREE.MeshStandardMaterial({ color: 0xc8aa7a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); grd.rotation.x = -Math.PI / 2; grd.receiveShadow = true; scene.add(grd);
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    const cx = -span / 2 + i * (block + street) + block / 2, cz = -span / 2 + j * (block + street) + block / 2;
    if (i === 4 && j === 4) continue;
    for (let k = 0; k < 4; k++) { const w = block / 2 - 0.6, h = 3 + R() * 4; const hx = cx + (k % 2 ? 1 : -1) * block / 4, hz = cz + (k > 1 ? 1 : -1) * block / 4; const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), W); b.position.set(hx, h / 2, hz); b.castShadow = b.receiveShadow = true; scene.add(b); const r = new THREE.Mesh(new THREE.BoxGeometry(w + 0.1, 0.2, w + 0.1), roof); r.position.set(hx, h + 0.1, hz); scene.add(r); const ct = new THREE.Mesh(new THREE.BoxGeometry(w * 0.4, 0.22, w * 0.4), new THREE.MeshStandardMaterial({ color: 0xa88860 })); ct.position.set(hx, h + 0.12, hz); scene.add(ct); }
  }
  // the Great Bath in the middle block
  const mid = new THREE.Mesh(new THREE.BoxGeometry(block, 1.2, block), W); mid.position.set(-span / 2 + 4 * (block + street) + block / 2, 0.6, -span / 2 + 4 * (block + street) + block / 2); scene.add(shadowAll(mid));
  const pool = new THREE.Mesh(new THREE.PlaneGeometry(6, 9), waterMaterial({ color: 0x3a8aa8, opacity: 1, ripple: 0.6 })); pool.rotation.x = -Math.PI / 2; pool.position.set(mid.position.x, 1.22, mid.position.z); scene.add(pool);
  return span;
}

// ============ S0 hook: the cutaway house, water running from both bathrooms into the street drain ============
function sHook({ makeStage }) {
  const scene = district(makeStage);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.flowLow(t, 1); scene.userData.flowUp(t, 1); scene.userData.flowDrain(t, 1); scene.userData.drainLevel(0.22);
      const sd = scene.userData.sideA; sd.material.opacity = 0.3; sd.material.depthWrite = false;
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(3.2, 2.8, k), lerp(3.4, 2.4, k), lerp(13, 9.5, k)], [lerp(2.6, 2.8, k), lerp(1.6, 1.3, k), -1]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S1: the city from above ============
function sCity({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.45, 0.7], fog: 0.0025, shadowSize: 120, envI: 0.95, cloud: 0.3 });
  fillLight(scene, [0.4, 0.5, 1], 0.6, 0xffe6c8);
  cityGrid(scene);
  const riv = new THREE.Mesh(new THREE.PlaneGeometry(40, 600), waterMaterial({ color: 0x5a8a8a, opacity: 1, ripple: 1 })); riv.rotation.x = -Math.PI / 2; riv.position.set(130, 0.05, 0); scene.add(riv);
  scene.add(trees(ringSpots(60, 95, 160, 4), { seed: 4, scale: 2 }));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.6)); const a = lerp(0.6, 0.95, k);
      place(c, [Math.cos(a) * 110, lerp(70, 55, k), Math.sin(a) * 110], [0, 0, 0]);
      return { bloom: 0.5, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2: down into a grid street; bricks stack in standard sizes ============
function sGrid({ makeStage, start: ST }) {
  const tB = at(2, 'baked') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.55, 0.67], fog: 0.003, shadowSize: 40, envI: 0.95, cloud: 0.3 });
  fillLight(scene, [0.4, 0.5, 1], 0.6, 0xffe6c8);
  cityGrid(scene);
  const bm = brick(0.25, 0.25);
  const stack = [...Array(18)].map((_, i) => { const b = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.14, 0.28), bm); scene.add(shadowAll(b)); return b; });
  const folk = [0, 1].map(i => { const m = person([0xe8dcc0, 0xc8783a][i]); m.root.position.set(6.3 + i * 1.4, 0, 6); scene.add(m.root); return m; });
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      stack.forEach((b, i) => { const k = easeOut(range(t, tB - 0.4 + i * 0.07, tB + i * 0.07)); const row = Math.floor(i / 3), col = i % 3; b.visible = k > 0; b.position.set(6.4 + col * 0.6 + (row % 2) * 0.3, 0.07 + row * 0.15 + (1 - k) * 1.2, 11); });
      folk.forEach((m, i) => { const s = Math.sin(t * 5 + i); standPose(m, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07] }); m.setMood('happy'); m.root.position.z = 6 - t * 0.8; m.root.rotation.y = Math.PI; });
      const k = easeInOut(range(t, 0.6, tB));
      place(c, [lerp(7, 8.2, k), lerp(70, 2.2, k), lerp(20, 16, k)], [7, lerp(0, 0.8, k), lerp(0, 8, k)]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S3: a bathing floor and a toilet; water poured on the floor runs into the drain ============
function sBath({ makeStage, start: ST }) {
  const tT = at(3, 'toilet') - ST, tD = at(3, 'drain') - ST;
  const scene = district(makeStage);
  const m = person(0xe8dcc0); m.root.position.set(-0.4, 0.17, -1.1); m.root.rotation.y = Math.PI / 2; scene.add(m.root);
  const jar = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 12), clay()); jar.scale.y = 1.3; scene.add(shadowAll(jar));
  const pour = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.05, 1, 8), waterM()); scene.add(pour);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      standPose(m, t, { rSh: [-1.2, 0, 0.2], lSh: [-1.0, 0, -0.2], rEl: [-0.6, 0, 0], lEl: [-0.6, 0, 0], head: [0.3, 0, 0] }); m.setMood('happy'); m.blink(blinkK(t, [1.4]));
      jar.position.set(0.15, 1.35, -1.1); jar.rotation.z = -0.9; pour.position.set(0.4, 0.75, -1.1); pour.scale.y = 1.15;
      scene.userData.flowLow(t, 1); scene.userData.flowUp(t, 0); scene.userData.flowDrain(t, 0.6);
      const k = easeInOut(range(t, 0, tT)), k2 = easeInOut(range(t, tD - 0.6, tD + 0.8));
      const p0 = [lerp(-0.6, 0.2, k), lerp(2.0, 1.8, k), lerp(3.5, 2.8, k)], l0 = [lerp(0.2, 0.7, k), lerp(0.8, 0.4, k), lerp(-1.1, -2.6, k)];
      place(c, [lerp(p0[0], 3.4, k2), lerp(p0[1], 1.0, k2), lerp(p0[2], 5.0, k2)], [lerp(l0[0], 3.2, k2), lerp(l0[1], -0.3, k2), lerp(l0[2], 0, k2)]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S4: x-ray wall: the clay pipe brings water down from upstairs ============
function sPipe({ makeStage, start: ST }) {
  const tU = at(4, 'upstairs') - ST;
  const scene = district(makeStage);
  const side = scene.userData.sideA;
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      side.material.opacity = lerp(1, 0.25, easeInOut(range(t, 0.2, 1.2))); side.material.depthWrite = side.material.opacity > 0.9;
      scene.userData.flowUp(t, 1); scene.userData.flowLow(t, 0); scene.userData.flowDrain(t, 0.6);
      const k = easeInOut(range(t, 0, tU + 0.8));
      place(c, [lerp(4.5, 3.8, k), lerp(4.0, 2.0, k), lerp(5.5, 6.5, k)], [1.75, lerp(3.2, 1.0, k), -0.5]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S5: down at the street: the covered drain, water flowing downhill ============
function sDrain({ makeStage, start: ST }) {
  const tG = at(5, 'gravity') - ST;
  const scene = district(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.flowLow(t, 1); scene.userData.flowUp(t, 1); scene.userData.flowDrain(t, 1); scene.userData.drainLevel(0.25);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(7.0, 6.2, k), lerp(1.2, 0.5, k), lerp(5.0, 3.6, k)], [lerp(4.4, 4.8, k), -0.6, lerp(-0.5, -1.5, k)]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S6: workers lift the cover bricks and scoop out the drain ============
function sClean({ makeStage, start: ST }) {
  const tO = at(6, 'open') - ST, tC = at(6, 'clean') - ST;
  const scene = district(makeStage);
  const men = [0, 1].map(i => { const m = person([0xe8dcc0, 0x8a6a3a][i]); m.root.position.set(i ? 6.4 : 3.6, 0, -4.5 - i * 0.6); m.root.rotation.y = i ? -Math.PI / 2 : Math.PI / 2; scene.add(m.root); return m; });
  const basket = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.22, 0.3, 16, 1, true), new THREE.MeshStandardMaterial({ color: 0xc8a060, roughness: 1, side: THREE.DoubleSide })); basket.position.set(3.4, 0.15, -3.6); scene.add(shadowAll(basket));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const cv = scene.userData.covers; [3, 4, 5].forEach((i, j) => { const k = easeInOut(range(t, tO - 0.9 + j * 0.25, tO - 0.2 + j * 0.25)); cv[i].position.set(5 + k * (j % 2 ? 1.6 : -1.6), -0.09 + Math.sin(Math.PI * k) * 0.5 + k * 0.12, -0.5 - i * 1.0); cv[i].rotation.z = k * (j % 2 ? -0.1 : 0.1); });
      men.forEach((m, i) => { const s = Math.sin(t * 4 + i * 2) * (t > tC - 0.4 ? 1 : 0.3); standPose(m, t + i, { spine: [0.6 + s * 0.1, 0, 0], rSh: [-1.2 - s * 0.4, 0, 0], lSh: [-1.2 - s * 0.4, 0, 0], lKn: [0.6, 0, 0], rKn: [0.6, 0, 0], lHip: [-0.5, 0, 0], rHip: [-0.5, 0, 0], head: [0.3, 0, 0] }); m.setMood('happy'); m.root.position.y = -0.18; });
      scene.userData.flowDrain(t, 0.7);
      const k = easeInOut(range(t, 0, 4.8));
      place(c, [lerp(9, 8, k), lerp(4.5, 3.2, k), lerp(2.5, 1.0, k)], [5, -0.3, lerp(-4.5, -4.8, k)]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S7: a woman draws water from a brick well; then many wells across the city ============
function sWell({ makeStage, start: ST }) {
  const t7 = at(7, 'seven') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.5, 0.7], fog: 0.003, shadowSize: 60, envI: 0.95, cloud: 0.3 });
  fillLight(scene, [0.4, 0.5, 1], 0.6, 0xffe6c8);
  const span = cityGrid(scene, { seed: 7 });
  const wellAt = (x, z, s = 1) => { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.75 * s, 0.75 * s, 0.9, 24, 1, true), brick(3, 0.6, { side: THREE.DoubleSide })); w.position.set(x, 0.45, z); scene.add(shadowAll(w)); const d = new THREE.Mesh(new THREE.CircleGeometry(0.72 * s, 24), new THREE.MeshStandardMaterial({ color: 0x0a1a24 })); d.rotation.x = -Math.PI / 2; d.position.set(x, 0.3, z); scene.add(d); };
  const wx = -span / 2 + 2 * 18 + 16, wz = -span / 2 + 3 * 18 + 16; wellAt(wx, wz);
  const m = person(0xd84a3a); m.root.position.set(wx - 1.1, 0, wz); m.root.rotation.y = Math.PI / 2; scene.add(m.root);
  const pot = new THREE.Mesh(new THREE.SphereGeometry(0.2, 14, 10), clay()); scene.add(shadowAll(pot));
  const rp = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1, 6), new THREE.MeshStandardMaterial({ color: 0x8a7a5a })); scene.add(rp);
  const pins = []; const R = R0(4); for (let i = 0; i < 90; i++) { const s = glowSprite(0x6ad0ff, 3); s.position.set((R() - 0.5) * span, 2, (R() - 0.5) * span); scene.add(s); pins.push({ s, d: R() }); }
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const up = (Math.sin(t * 1.4) * 0.5 + 0.5); pot.position.set(wx, lerp(-0.4, 0.9, up), wz); rp.position.set(wx, lerp(-0.4, 0.9, up) / 2 + 0.6, wz); rp.scale.y = 1.2 - lerp(-0.4, 0.9, up);
      standPose(m, t, { rSh: [-1.0 - up * 0.6, 0, 0], lSh: [-1.0 - (1 - up) * 0.6, 0, 0], spine: [0.25, 0, 0], head: [0.25, 0, 0] }); m.setMood('happy'); m.blink(blinkK(t, [1.2]));
      pins.forEach(({ s, d }) => { const k = range(t, t7 - 1.6 + d * 1.2, t7 - 1.3 + d * 1.2); s.visible = k > 0; s.scale.setScalar(3 * easeOut(k)); });
      const k = easeInOut(range(t, 0.8, t7 - 0.6));
      place(c, [wx + lerp(2.4, 40, k), lerp(1.8, 120, k), wz + lerp(3.2, 60, k)], [lerp(wx, 0, k), lerp(0.6, 0, k), lerp(wz, 0, k)]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
// ============ S8: Rome's great sewer outlet into the Tiber, far later ============
function sRome({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.35, 0.72], fog: 0.004, shadowSize: 30, envI: 0.95, cloud: 0.35 });
  fillLight(scene, [0.4, 0.5, 1], 0.6, 0xffe6c8);
  const A = archMats();
  const riv = new THREE.Mesh(new THREE.PlaneGeometry(400, 60), waterMaterial({ color: 0x4a6a5a, opacity: 1, ripple: 1.2 })); riv.rotation.x = -Math.PI / 2; riv.position.set(0, 0, 18); scene.add(riv);
  const bank = new THREE.Mesh(new THREE.BoxGeometry(400, 8, 20), new THREE.MeshStandardMaterial({ color: 0xc8b898, roughness: 0.9, bumpMap: fabricTexture(23), bumpScale: 3 })); bank.position.set(0, 2, -10); scene.add(shadowAll(bank));
  const sh = new THREE.Shape(); sh.moveTo(-2.4, 0); sh.lineTo(2.4, 0); sh.lineTo(2.4, 2); sh.absarc(0, 2, 2.4, 0, Math.PI, false); sh.lineTo(-2.4, 0);
  const hole = new THREE.Mesh(new THREE.ShapeGeometry(sh, 32), new THREE.MeshStandardMaterial({ color: 0x140e0a })); hole.position.set(0, -0.5, 0.02); scene.add(hole);
  for (let i = 0; i < 11; i++) { const a = Math.PI * i / 10; const v = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.7, 0.5), new THREE.MeshStandardMaterial({ color: 0xb8a888, roughness: 0.9 })); v.position.set(Math.cos(a) * 2.75, 1.5 + Math.sin(a) * 2.75, 0.2); v.rotation.z = a - Math.PI / 2; scene.add(shadowAll(v)); }
  const outflow = flowAlong(scene, [[0, 0.1, -1], [0, 0.05, 0.5], [0, 0.02, 4]], 40, { size: 0.12, speed: 0.8, color: 0x9ac8d8 });
  const sheet = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 5), waterMaterial({ color: 0x6a8a7a, opacity: 1, ripple: 2.5 })); sheet.rotation.x = -Math.PI / 2; sheet.position.set(0, 0.06, 1.5); scene.add(sheet);
  for (let i = 0; i < 10; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(5, 4 + (i % 3) * 2, 5), new THREE.MeshStandardMaterial({ color: [0xe0c8a0, 0xd8b088, 0xe8d8b8][i % 3], roughness: 0.9 })); b.position.set(-30 + i * 7, 6 + (i % 3), -16); scene.add(shadowAll(b)); }
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      outflow(t, 1);
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(6, 10, k), lerp(2.2, 6, k), lerp(14, 22, k)], [0, lerp(1.8, 3.5, k), 0]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sCity, 'city'],
  [ls(2), ls(3), sGrid, 'grid'],
  [ls(3), ls(4), sBath, 'bath'],
  [ls(4), ls(5), sPipe, 'pipe'],
  [ls(5), ls(6), sDrain, 'drain'],
  [ls(6), ls(7), sClean, 'clean'],
  [ls(7), ls(8), sWell, 'well'],
  [ls(8), DURATION + 1, sRome, 'rome'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
