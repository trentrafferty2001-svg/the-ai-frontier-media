// shared ancient kit: Mediterranean galley, Roman legionary.
import * as THREE from 'three';
import { standPose } from './shots4.js';
import { fabricTexture } from './textures.js';
import { V } from './anim.js';
import { shadowAll, romanBuilder } from './rome.js';
import { longship } from './norse.js';

// a Mediterranean galley: the shared hull with the Viking details removed, a lateen sail and oars
export function galley({ L = 16, sail = 0xe8dcc0 } = {}) {
  const s = longship({ L, W: L * 0.22, D: 1.3 });
  s.traverse(o => { if (!o.isMesh) return; const p = o.geometry.parameters || {}; const ty = o.geometry.type;
    if (ty === 'CylinderGeometry' && Math.abs(p.radiusTop - 0.32) < 1e-6 && Math.abs(p.height - 0.04) < 1e-6) o.visible = false; // shields
    if (ty === 'ConeGeometry' && Math.abs(p.radius - 0.2) < 1e-6) o.visible = false; // dragon head
    if (ty === 'SphereGeometry' && Math.abs(p.radius - 0.045) < 1e-6) o.visible = false; // dragon eyes
    if (ty === 'TorusGeometry') o.visible = false; // stern curl
    if (ty === 'PlaneGeometry' && Math.abs(p.width - 6.2) < 1e-6) o.visible = false; // square sail
    if (ty === 'CylinderGeometry' && Math.abs(p.height - 6.4) < 1e-6) o.visible = false; // yard
  });
  const wood = new THREE.MeshStandardMaterial({ color: 0x5a3a20, roughness: 0.8 });
  const yardC = new THREE.LineCurve3(V(-L * 0.28, 2.6, 0.25), V(L * 0.22, 9.0, 0.25));
  s.add(new THREE.Mesh(new THREE.TubeGeometry(yardC, 4, 0.07, 6), wood));
  const sh = new THREE.Shape(); sh.moveTo(-L * 0.28, 2.6); sh.lineTo(L * 0.22, 9.0); sh.quadraticCurveTo(L * 0.12, 4.0, 0.4, 1.7); sh.lineTo(-L * 0.28, 2.6);
  const sl = new THREE.Mesh(new THREE.ShapeGeometry(sh, 16), new THREE.MeshStandardMaterial({ color: sail, roughness: 0.9, side: THREE.DoubleSide, bumpMap: fabricTexture(13), bumpScale: 2 })); sl.position.z = 0.3; s.add(sl);
  for (const z of [-1, 1]) for (let i = 0; i < 9; i++) { const x = -L * 0.32 + i * L * 0.075; const o = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 4.2, 6), wood); o.position.set(x, 0.6, z * (L * 0.11 + 1.2)); o.rotation.x = z * 1.15; s.add(o); }
  return s;
}
export function legionary(seed = 0) {
  const h = romanBuilder({ color: 0xa8281e });
  const bronze = new THREE.MeshStandardMaterial({ color: 0xb08a3a, metalness: 0.7, roughness: 0.35 });
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.165, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), bronze); helm.position.y = 0.06; helm.scale.set(1, 0.95, 1.08); h.j.head.add(helm);
  const crest = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.09, 0.26), new THREE.MeshStandardMaterial({ color: 0xc8281e, roughness: 0.9 })); crest.position.y = 0.23; h.j.head.add(crest);
  const sc = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.95, 20, 1, true, -0.55, 1.1), new THREE.MeshStandardMaterial({ color: 0xb02a1e, roughness: 0.7, side: THREE.DoubleSide }));
  sc.position.set(0.32, 0.72, -0.25); sc.rotation.y = Math.PI / 2 + 0.2; h.root.add(sc);
  const boss = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 8), bronze); boss.position.set(0.32 + 0.28, 0.72, 0.02); h.root.add(boss);
  const pil = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 2.0, 6), new THREE.MeshStandardMaterial({ color: 0x6a4a2a })); pil.position.set(-0.3, 1.05, 0.08); h.root.add(pil);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.18, 6), new THREE.MeshStandardMaterial({ color: 0x9a9a9a, metalness: 0.8, roughness: 0.3 })); tip.position.set(-0.3, 2.1, 0.08); h.root.add(tip);
  shadowAll(h.root); return h;
}
export const march = (m, t, ph, k = 1) => { const s = Math.sin(t * 6 + ph) * k; standPose(m, t + ph, { lHip: [s * 0.4, 0, 0.06], rHip: [-s * 0.4, 0, -0.06], lKn: [Math.max(0, -s) * 0.5, 0, 0], rKn: [Math.max(0, s) * 0.5, 0, 0], rSh: [-0.15, 0, -0.1], lSh: [-0.5, 0, 0.3], lEl: [-0.9, 0, 0] }); m.setMood('happy'); };
