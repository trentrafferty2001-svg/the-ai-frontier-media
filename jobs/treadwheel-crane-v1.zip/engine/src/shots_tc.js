// Roman treadwheel crane reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { mountains, trees, ringSpots } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { shadowAll, romanBuilder, canvasTex, archMats } from './rome.js';
import { greek } from './classic.js';
import { VO } from './vo_tc.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*Two men*', 2], ['walking inside', 2], ['this *wheel*', 2], ['could reportedly', 2], ['lift *6 tonnes*', 3], ['of stone', 2]],
  [["It's a *Roman*", 3], ['*treadwheel crane*', 2], ['described by', 2], ['the engineer', 2], ['*Vitruvius*', 1]],
  [['As the men walked', 4], ['the wheel turned', 3], ['an *axle*', 2], ['that *wound up*', 3], ['a rope', 2]],
  [['The rope ran', 3], ['through *pulleys*', 2], ['which *multiplied*', 2], ['their pulling force', 3]],
  [['The biggest version', 3], ['used *15 pulleys*', 3], ['in *3 sets*', 3], ['*of 5*', 2]],
  [['With a *hand winch*', 4], ['*4 men*', 2], ['could lift', 2], ['about *3 tonnes*', 3]],
  [['Swap in', 2], ['the *treadwheel*', 2], ['and modern estimates', 3], ['say *2 men*', 3], ['could lift *6*', 3]],
  [['A *carving*', 2], ['on a Roman', 3], ['family tomb', 2], ['the *Tomb of the Haterii*', 5], ['shows one', 2], ['at work', 2]],
  [['The same idea', 3], ['later helped build', 3], ["Europe's great", 2], ['*medieval cathedrals*', 2], ['long after', 2], ['*Rome fell*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ---------- materials & props ----------
const wood = (c = 0x7a5232) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.85, bumpMap: fabricTexture(13), bumpScale: 2 });
const ropeM = () => new THREE.MeshStandardMaterial({ color: 0xc8a870, roughness: 1 });
const marble = () => new THREE.MeshStandardMaterial({ color: 0xece6da, roughness: 0.6, bumpMap: fabricTexture(23), bumpScale: 1 });
function rope(mat, r = 0.03) { const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 1, 6), mat); m.set = (a, b) => { const d = b.clone().sub(a); m.position.copy(a).addScaledVector(d, 0.5); m.scale.set(1, Math.max(0.001, d.length()), 1); m.quaternion.setFromUnitVectors(V(0, 1, 0), d.normalize()); }; return m; }
function label(text, color = '#ffd040') { const t = canvasTex(256, 128, (x) => { x.clearRect(0, 0, 256, 128); x.font = 'bold 84px sans-serif'; x.textAlign = 'center'; x.lineWidth = 10; x.strokeStyle = '#1a1208'; x.strokeText(text, 128, 94); x.fillStyle = color; x.fillText(text, 128, 94); }); const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false })); s.scale.set(1.6, 0.8, 1); s.renderOrder = 10; return s; }
// pulley block with n sheaves side by side (along z)
function pulleyBlock(n = 5, W = wood(0x5a3a22)) {
  const g = new THREE.Group(); const sheaves = [];
  const cheek = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.6, 0.08 * n + 0.12), W); g.add(cheek); cheek.scale.x = 0.35;
  for (let i = 0; i < n; i++) { const s = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.06, 20), new THREE.MeshStandardMaterial({ color: 0x8a6a42, roughness: 0.7 })); s.rotation.x = Math.PI / 2; s.position.z = (i - (n - 1) / 2) * 0.08; g.add(s); sheaves.push(s); }
  g.sheaves = sheaves; return shadowAll(g);
}
// the treadwheel crane: wheel (radius 2.2) on an axle along z at x = 0; two masts lean toward +x to a head at (4.2, 11); the hoist rope runs from the drum up to the head and down to a pulley block over the load
function crane({ blocks = 3 } = {}) {
  const W = wood(); const g = new THREE.Group(); const R = 2.2, AY = 2.5;
  const wheel = new THREE.Group(); wheel.position.set(0, AY, 0); g.add(wheel);
  for (const z of [-0.65, 0.65]) { const ring = new THREE.Mesh(new THREE.TorusGeometry(R, 0.07, 8, 48), W); ring.position.z = z; wheel.add(ring); for (let i = 0; i < 8; i++) { const sp = new THREE.Mesh(new THREE.BoxGeometry(0.08, R * 2, 0.08), W); sp.rotation.z = i * Math.PI / 8; sp.position.z = z; wheel.add(sp); } }
  for (let i = 0; i < 40; i++) { const a = i * Math.PI * 2 / 40; const sl = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.04, 1.36), W); sl.position.set(Math.cos(a) * (R - 0.05), Math.sin(a) * (R - 0.05), 0); sl.rotation.z = a + Math.PI / 2; wheel.add(sl); }
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 3.4, 12), W); axle.rotation.x = Math.PI / 2; wheel.add(axle);
  const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.5, 20), new THREE.MeshStandardMaterial({ color: 0xc8a870, roughness: 1, bumpMap: fabricTexture(3), bumpScale: 3 })); drum.rotation.x = Math.PI / 2; drum.position.z = 1.1; wheel.add(drum);
  for (const z of [-1.5, 1.5]) { for (const x of [-0.9, 0.9]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.2, AY + 0.3, 0.2), W); p.position.set(x * 0.6, (AY + 0.3) / 2, z); p.rotation.z = -x * 0.25; g.add(p); } const sill = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.25, 0.25), W); sill.position.set(0, 0.12, z); g.add(sill); }
  // masts: from the frame base at (1.8, 0, ±1.4) to the head at (4.2, 11, 0)
  const head = V(4.2, 11, 0);
  for (const z of [-1.4, 1.4]) { const a = V(1.8, 0, z); const m = rope(W, 0.16); m.set(a, head.clone().add(V(0, 0, z * 0.08))); g.add(m); }
  const cross = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 2.4), W); cross.position.set(2.6, 4, 0); g.add(cross);
  const stay = rope(ropeM(), 0.03); stay.set(head, V(-6, 0, 0)); g.add(stay);
  const top = pulleyBlock(blocks > 1 ? 3 : 5); top.position.copy(head).add(V(0.3, -0.2, 0)); g.add(top);
  const low = new THREE.Group(); for (let i = 0; i < blocks; i++) { const pb = pulleyBlock(5); pb.position.z = (i - (blocks - 1) / 2) * 0.6; low.add(pb); } g.add(low);
  const lines = [...Array(blocks * 2)].map(() => { const r = rope(ropeM(), 0.025); g.add(r); return r; });
  const lead = rope(ropeM(), 0.03); g.add(lead);
  const load = new THREE.Group(); g.add(load);
  g.lines = lines; g.wheel = wheel; g.low = low; g.top = top; g.load = load; g.head = head; g.AY = AY; g.R = R;
  g.set = (alpha, h, x = 4.6) => { // alpha: wheel angle; h: hook height
    wheel.rotation.z = alpha;
    low.position.set(x, h + 1.0, 0); load.position.set(x, h, 0);
    lines.forEach((r, i) => { const z = (i - (lines.length - 1) / 2) * 0.12; const o = (i % 2 ? 1 : -1) * 0.2; r.set(V(head.x + 0.3 + o, head.y - 0.4, z), V(x - o, h + 1.25, z)); });
    lead.set(V(0.0, AY + 0.32, 1.1), V(head.x, head.y, 0.2));
  };
  return shadowAll(g);
}
function stone(w = 1.2, h = 0.9, d = 2.0) { const g = new THREE.Group(); const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), marble()); b.position.y = -h / 2 - 0.25; g.add(b); const lw = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.25, 0.12), new THREE.MeshStandardMaterial({ color: 0x5a5a5e, metalness: 0.7 })); lw.position.y = -0.12; g.add(lw); return shadowAll(g); }
function walker(color) { return romanBuilder({ color }); }
const walk = (m, t, ph, sp = 5) => { const s = Math.sin(t * sp + ph); standPose(m, t + ph, { lHip: [s * 0.35, 0, 0.06], rHip: [-s * 0.35, 0, -0.06], lKn: [Math.max(0, -s) * 0.4, 0, 0], rKn: [Math.max(0, s) * 0.4, 0, 0], spine: [0.15, 0, 0], lSh: [-0.6, 0, 0.2], rSh: [-0.6, 0, -0.2], lEl: [-1.0, 0, 0], rEl: [-1.0, 0, 0] }); m.setMood('happy'); };
function site(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.55, 0.5, 0.67], fog: 0.004, shadowSize: 16, envI: 0.95, cloud: 0.3, ...opts });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 48), new THREE.MeshStandardMaterial({ color: 0xb8a078, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 200, rMax: 340, height: 18, seed: 5, color: 0x8a9a62 }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe6c8);
  // the temple wall being built at x 6..9 (blocks), up to 8 m
  const M = marble(); const wall = new THREE.Group(); scene.add(wall);
  for (let r = 0; r < 8; r++) for (let i = 0; i < 6; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.95, 2.0), M); b.position.set(7.2, 0.475 + r * 1.0, -5 + i * 2.05 + (r % 2) * 1.0); if (b.position.z > 5.5) continue; b.castShadow = b.receiveShadow = true; wall.add(b); }
  const scaffold = new THREE.Group(); for (let i = 0; i < 5; i++) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 9, 6), wood()); p.position.set(9, 4.5, -5 + i * 2.5); scaffold.add(p); } scene.add(shadowAll(scaffold));
  return scene;
}

// ============ S0 hook: low angle, two men in the wheel, a huge block rising ============
function sHook({ makeStage }) {
  const scene = site(makeStage);
  const cr = crane(); scene.add(cr); const st = stone(1.4, 1.2, 2.4); cr.load.add(st);
  const men = [0, 1].map(i => { const m = walker([0xd8c7a2, 0xa8402c][i]); m.root.position.set(-0.35, cr.AY - cr.R + 0.12, -0.3 + i * 0.6); m.root.rotation.y = -Math.PI / 2; scene.add(m.root); return m; });
  const lb = label('6 t'); scene.add(lb);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const h = lerp(1.6, 5.5, easeInOut(range(t, 0, 4.4)));
      cr.set(-t * 1.1, h);
      men.forEach((m, i) => walk(m, t, i * 1.6));
      lb.position.set(3.4, h - 0.8, 1.8); lb.visible = t > 0.9; lb.material.opacity = easeOut(range(t, 0.9, 1.3));
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-4.5, -5.5, k), lerp(0.8, 1.4, k), lerp(13, 15, k)], [lerp(2.0, 2.4, k), lerp(4.2, 4.8, k), 0]);
      return { bloom: 0.5, flare: 1.1, warm: 1.25 };
    },
  };
}
// ============ S1: the whole crane at the site; an engineer with a scroll ============
function sWide({ makeStage }) {
  const scene = site(makeStage);
  const cr = crane(); scene.add(cr); cr.load.add(stone());
  const men = [0, 1].map(i => { const m = walker([0xd8c7a2, 0xa8402c][i]); m.root.position.set(-0.35, cr.AY - cr.R + 0.12, -0.3 + i * 0.6); m.root.rotation.y = -Math.PI / 2; scene.add(m.root); return m; });
  const vit = greek({ color: 0xf2ede0 }); vit.root.position.set(-3.5, 0, 3.2); vit.root.rotation.y = 0.6; scene.add(vit.root);
  const scroll = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.35, 10), new THREE.MeshStandardMaterial({ color: 0xe8dcb8 })); scroll.rotation.z = Math.PI / 2; vit.j.rWr.add(scroll); scroll.position.y = -0.08;
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      cr.set(-t * 1.1 - 4.8, lerp(5.5, 7.5, range(t, 0, 5)));
      men.forEach((m, i) => walk(m, t, i * 1.6));
      standPose(vit, t, { rSh: [-0.7, 0, -0.1], rEl: [-1.0, 0, 0], head: [-0.15, 0.4, 0] }); vit.setMood('happy'); vit.blink(blinkK(t, [1.1, 3.0]));
      const k = easeInOut(range(t, 0, 4.8));
      place(c, [lerp(-12, -10, k), lerp(4, 5, k), lerp(14, 16, k)], [lerp(0, 1, k), lerp(4.5, 5, k), 0]);
      return { bloom: 0.5, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2: inside the wheel: walking turns the axle, the rope winds onto the drum ============
function sWheel({ makeStage, start: ST }) {
  const tA = at(2, 'axle') - ST, tW = at(2, 'wound') - ST;
  const scene = site(makeStage);
  const cr = crane(); scene.add(cr); cr.load.add(stone());
  const men = [0, 1].map(i => { const m = walker([0xd8c7a2, 0xa8402c][i]); m.root.position.set(-0.35, cr.AY - cr.R + 0.12, -0.3 + i * 0.6); m.root.rotation.y = -Math.PI / 2; scene.add(m.root); return m; });
  const glow = glowSprite(0xffd060, 1.2); scene.add(glow);
  const arrow = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.05, 8, 32, Math.PI * 1.4), new THREE.MeshBasicMaterial({ color: 0xffd040 })); arrow.position.set(0, cr.AY, 1.45); scene.add(arrow);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      cr.set(-t * 1.1, 2 + t * 0.2);
      men.forEach((m, i) => walk(m, t, i * 1.6));
      arrow.visible = t > tA - 0.2; arrow.rotation.z = -t * 1.1; arrow.material.opacity = 1;
      glow.visible = t > tW - 0.3; glow.position.set(0, cr.AY + 0.32, 1.1); glow.scale.setScalar(0.8 + 0.2 * Math.sin(t * 8));
      const k = easeInOut(range(t, 0, tA)), k2 = easeInOut(range(t, tA, tW + 0.6));
      place(c, [lerp(-0.6, 1.2, k2), lerp(2.2, 3.0, k2), lerp(7.0, 4.0, k2)], [lerp(0, 0.1, k2), lerp(2.0, 2.8, k2), lerp(0, 1.1, k2)]);
      return { bloom: 0.55, warm: 1.2, dof: dofTo([0, 2.4, 4], [0, 2.2, 0.5], 0.003, 0.006) };
    },
  };
}
// ============ S3: the pulley blocks: rope glows as it runs; arrows show the force growing ============
function sPulley({ makeStage, start: ST }) {
  const tM = at(3, 'multiplied') - ST;
  const scene = site(makeStage);
  const cr = crane({ blocks: 3 }); scene.add(cr); cr.load.add(stone());
  const lit = new THREE.MeshStandardMaterial({ color: 0xffd040, emissive: 0xffa020, emissiveIntensity: 1.0 }); const m0 = cr.lines[0].material;
  const c = cam(32);
  return {
    scene, camera: c,
    update(t) {
      cr.set(-t * 1.1, lerp(3, 4.2, range(t, 0, 4)));
      cr.low.children.forEach(pb => pb.sheaves.forEach((s, i) => s.rotation.y = t * 3 * (i % 2 ? 1 : -1)));
      cr.top.sheaves.forEach((s, i) => s.rotation.y = t * 3);
      cr.lines.forEach((r, i) => r.material = t > tM - 0.3 + i * 0.1 ? lit : m0);
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(2.0, 2.6, k), lerp(7.5, 7.0, k), lerp(13, 15, k)], [4.4, lerp(7.6, 7.2, k), 0]);
      return { bloom: 0.5, warm: 1.2, dof: dofTo([2.3, 7.2, 14], [4.4, 7.4, 0], 0.002, 0.005) };
    },
  };
}
// ============ S4: three blocks of five sheaves light up, 1..15 ============
function sFifteen({ makeStage, start: ST }) {
  const tF = at(4, 'fifteen') - ST;
  const scene = site(makeStage);
  const cr = crane({ blocks: 3 }); scene.add(cr); cr.load.add(stone(1.6, 1.2, 2.6));
  const lit = new THREE.MeshStandardMaterial({ color: 0xffd040, emissive: 0xffa020, emissiveIntensity: 1.2 });
  const all = []; cr.low.children.forEach(pb => pb.sheaves.forEach(s => all.push([s, s.material])));
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      cr.set(-t * 0.5, 3.0);
      all.forEach(([s, m0], i) => { s.material = t > tF - 0.4 + i * 0.09 ? lit : m0; });
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(1.6, 2.2, k), lerp(4.8, 4.5, k), lerp(4.2, 3.4, k)], [4.6, 4.2, 0]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
// ============ S5: four men at a hand winch lift a 3 t block ============
function sWinch({ makeStage }) {
  const scene = site(makeStage);
  const cr = crane(); scene.add(cr); cr.wheel.visible = false; cr.load.add(stone(1.2, 0.8, 1.6));
  const W = wood(); const winch = new THREE.Group(); winch.position.set(0, 1.0, 0); scene.add(winch);
  const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 2.6, 12), W); bar.rotation.x = Math.PI / 2; winch.add(bar);
  const spokes = new THREE.Group(); winch.add(spokes); for (const z of [-1.1, 1.1]) for (let i = 0; i < 4; i++) { const h = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.6, 6), W); h.position.z = z; h.rotation.z = i * Math.PI / 4; spokes.add(h); }
  const men = [0, 1, 2, 3].map(i => { const m = walker([0xd8c7a2, 0xa8402c, 0x6a8a4a, 0xc8a050][i]); m.root.position.set(i % 2 ? 0.9 : -0.9, 0, i < 2 ? -1.5 : 1.5); m.root.rotation.y = i % 2 ? -Math.PI / 2 : Math.PI / 2; scene.add(m.root); return m; });
  const lb = label('3 t'); scene.add(lb);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const h = lerp(1.2, 2.4, range(t, 0, 4)); cr.set(0, h); spokes.rotation.z = -t * 0.6; bar.rotation.y = 0;
      men.forEach((m, i) => { const s = Math.sin(t * 2.4 + i); standPose(m, t + i, { spine: [0.4, 0, 0], rSh: [-1.4 - s * 0.3, 0, 0], lSh: [-1.4 - s * 0.3, 0, 0], rEl: [-0.4, 0, 0], lEl: [-0.4, 0, 0], lKn: [0.3, 0, 0], rKn: [0.3, 0, 0] }); m.setMood('happy'); });
      lb.position.set(4.6, h - 0.5, 1.5);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(-5, -6, k), lerp(4, 5, k), lerp(8, 10, k)], [lerp(1.5, 2, k), lerp(1.8, 2.4, k), 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S6: the treadwheel back in; two men; 6 t ============
function sSix({ makeStage }) {
  const scene = site(makeStage);
  const cr = crane(); scene.add(cr); cr.load.add(stone(1.6, 1.2, 2.6));
  const men = [0, 1].map(i => { const m = walker([0xd8c7a2, 0xa8402c][i]); m.root.position.set(-0.35, cr.AY - cr.R + 0.12, -0.3 + i * 0.6); m.root.rotation.y = -Math.PI / 2; scene.add(m.root); return m; });
  const lb = label('6 t'); scene.add(lb); const lb2 = label('2 men', '#ffffff'); lb2.scale.set(2.2, 1.1, 1); scene.add(lb2);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const h = lerp(1.4, 3.2, range(t, 0, 4.5)); cr.set(-t * 1.1, h);
      men.forEach((m, i) => walk(m, t, i * 1.6));
      lb.position.set(3.4, h - 0.7, 1.8); lb2.position.set(0, 5.2, 0.6);
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(-6, -5, k), lerp(4, 4.5, k), lerp(11, 12, k)], [lerp(1.6, 2.2, k), lerp(2.6, 3, k), 0]);
      return { bloom: 0.5, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S7: the crane carved in relief on the Haterii tomb ============
function sRelief({ makeStage }) {
  const scene = makeStage({ shadowSize: 8, sunDir: [-3, 2, 4], sun: 2.6, envI: 0.8 });
  const u = scene.userData.sky && scene.userData.sky.material.uniforms; if (u) { u.top.value.set(0x2a2622); u.mid.value.set(0x2e2a26); u.horizon.value.set(0x34302a); u.floorC.value.set(0x2a2622); }
  const st = new THREE.MeshStandardMaterial({ color: 0xd8d0c0, roughness: 0.8, bumpMap: fabricTexture(23), bumpScale: 2 });
  const slab = new THREE.Mesh(new THREE.BoxGeometry(9, 8, 0.6), st); slab.position.set(1.5, 5, -0.4); slab.receiveShadow = true; scene.add(slab);
  const frame = new THREE.Mesh(new THREE.BoxGeometry(9.6, 0.5, 0.9), st); frame.position.set(1.5, 9.1, -0.3); scene.add(frame); const frame2 = frame.clone(); frame2.position.y = 0.9; scene.add(frame2);
  const cr = crane(); cr.load.add(stone()); cr.set(0.3, 6); cr.scale.set(0.62, 0.62, 0.06); cr.position.set(-0.2, 1.2, 0.05);
  cr.traverse(o => { if (o.isMesh) { o.material = st; o.castShadow = true; } }); scene.add(cr);
  const figs = [0, 1, 2].map(i => { const m = romanBuilder({ color: 0xd8d0c0 }); m.root.traverse(o => { if (o.isMesh) o.material = st; }); m.root.scale.set(0.62, 0.62, 0.15); m.root.position.set(-1.8 + i * 0.7, 1.2, 0.1); scene.add(m.root); standPose(m, i, { rSh: [-1.6, 0, -0.3] }); return m; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5)); const a = lerp(-0.5, 0.25, k);
      place(c, [1.4 + Math.sin(a) * 17, lerp(5.2, 4.8, k), Math.cos(a) * 17], [1.4, 4.9, 0]);
      return { bloom: 0.4, warm: 1.1, sat: 0.9 };
    },
  };
}
// ============ S8: a medieval cathedral with a treadwheel crane on its unfinished tower ============
function sCathedral({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.35, 0.72], fog: 0.004, shadowSize: 40, envI: 0.95, cloud: 0.4 });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 48), new THREE.MeshStandardMaterial({ color: 0x8a9a5a, roughness: 1 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe6c8);
  const st = new THREE.MeshStandardMaterial({ color: 0xc8beac, roughness: 0.85, bumpMap: fabricTexture(23), bumpScale: 2 });
  const nave = new THREE.Mesh(new THREE.BoxGeometry(14, 16, 40), st); nave.position.set(0, 8, -10); scene.add(shadowAll(nave));
  const roofG = new THREE.Shape(); roofG.moveTo(-7.5, 0); roofG.lineTo(7.5, 0); roofG.lineTo(0, 8); roofG.lineTo(-7.5, 0);
  const roof = new THREE.Mesh(new THREE.ExtrudeGeometry(roofG, { depth: 40, bevelEnabled: false }), new THREE.MeshStandardMaterial({ color: 0x5a6a7a, roughness: 0.7 })); roof.position.set(0, 16, -30); scene.add(shadowAll(roof));
  for (const x of [-9, 9]) { const tw = new THREE.Mesh(new THREE.BoxGeometry(7, 30, 7), st); tw.position.set(x, 15, 12); scene.add(shadowAll(tw)); }
  const sp = new THREE.Mesh(new THREE.ConeGeometry(4.6, 18, 4), st); sp.rotation.y = Math.PI / 4; sp.position.set(9, 39, 12); scene.add(shadowAll(sp));
  const win = new THREE.MeshStandardMaterial({ color: 0x2a3a5a, roughness: 0.3, emissive: 0x1a2a4a, emissiveIntensity: 0.3 });
  const rose = new THREE.Mesh(new THREE.CircleGeometry(3, 32), win); rose.position.set(0, 14, 10.01); scene.add(rose);
  const front = new THREE.Mesh(new THREE.BoxGeometry(11, 20, 1), st); front.position.set(0, 10, 9.5); scene.add(shadowAll(front));
  rose.position.z = 10.02;
  for (const x of [-9, 9]) for (let r = 0; r < 3; r++) { const sh = new THREE.Shape(); sh.moveTo(-0.8, 0); sh.lineTo(0.8, 0); sh.lineTo(0.8, 3); sh.lineTo(0, 4.2); sh.lineTo(-0.8, 3); sh.lineTo(-0.8, 0); const w = new THREE.Mesh(new THREE.ShapeGeometry(sh), win); w.position.set(x, 4 + r * 8, 15.52); scene.add(w); }
  const cr = crane(); cr.scale.setScalar(0.55); cr.position.set(-11, 30, 12); cr.load.add(stone(1, 0.7, 1.4)); scene.add(cr);
  const men = [0, 1].map(i => { const m = walker([0x6a4a8a, 0x8a3a2a][i]); m.root.scale.setScalar(0.55); scene.add(m.root); return m; });
  scene.add(trees(ringSpots(40, 30, 90, 7), { seed: 4, scale: 1.4 }));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      cr.set(-t * 1.1, lerp(-24, -12, range(t, 0, 6)), 4.6);
      men.forEach((m, i) => { walk(m, t, i * 1.6); m.root.position.set(-11 - 0.35 * 0.55, 30 + (cr.AY - cr.R + 0.12) * 0.55, 12 + (-0.3 + i * 0.6) * 0.55); m.root.rotation.y = -Math.PI / 2; });
      const k = easeInOut(range(t, 0, 5.5));
      place(c, [lerp(-40, -50, k), lerp(16, 24, k), lerp(70, 84, k)], [-2, lerp(22, 24, k), 4]);
      return { bloom: 0.55, flare: 1.1, warm: 1.25 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sWide, 'wide'],
  [ls(2), ls(3), sWheel, 'wheel'],
  [ls(3), ls(4), sPulley, 'pulley'],
  [ls(4), ls(5), sFifteen, 'fifteen'],
  [ls(5), ls(6), sWinch, 'winch'],
  [ls(6), ls(7), sSix, 'six'],
  [ls(7), ls(8), sRelief, 'relief'],
  [ls(8), DURATION + 1, sCathedral, 'cathedral'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
