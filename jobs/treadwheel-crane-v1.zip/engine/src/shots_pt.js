// Petra water system reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, birds, waterMaterial } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll, canvasTex, romanBuilder } from './rome.js';
import { palm } from './persia.js';
import { VO } from './vo_pt.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This *desert city*', 3], ['got *almost no rain*', 4], ['yet it had', 3], ['*pools and gardens*', 3]],
  [["It's *Petra*", 2], ['in *Jordan*', 2], ['carved into the rock', 4], ['by the *Nabataeans*', 3]],
  [['It gets only', 3], ['about', 1], ['*15 centimeters*', 2], ['of rain', 2], ['a year', 2]],
  [['So they caught', 3], ['*every drop*', 2], ['*channels*', 1], ['cut into the rock', 4], ['led rainwater', 2], ['into *hundreds*', 2], ['of *cisterns*', 2]],
  [['*Clay pipes*', 2], ['along the', 2], ['*canyon walls*', 2], ['carried', 1], ['*spring water*', 2], ['into the city', 3]],
  [['But rare storms', 3], ['sent deadly', 2], ['*flash floods*', 2], ['*roaring* down', 2], ['the gorge', 2]],
  [['So they built', 3], ['a *dam*', 2], ['and a *tunnel*', 3], ['to send', 2], ['the *floodwater*', 2], ['*around* the city', 3]],
  [['In *1963*', 4], ['a *flash flood*', 3], ['killed tourists', 2], ['in that same canyon', 4]],
  [['*Engineers*', 1], ['then built', 2], ['a *new dam*', 3], ['following the old', 3], ['*Nabataean plan*', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;

// ---------- rose sandstone ----------
let ST_ = null;
function sandstone(rep = 1) {
  if (!ST_) { ST_ = canvasTex(256, 512, (x) => { const R = R0(4); for (let y = 0; y < 512; y += 2) { const b = Math.sin(y * 0.09) * 0.5 + Math.sin(y * 0.023) * 0.5; const r = 196 + b * 26 + R() * 8, g = 120 + b * 22 + R() * 6, bl = 98 + b * 18; x.fillStyle = `rgb(${r | 0},${g | 0},${bl | 0})`; x.fillRect(0, y, 256, 2); } for (let i = 0; i < 500; i++) { x.fillStyle = 'rgba(90,40,30,0.15)'; x.fillRect(R() * 256, R() * 512, 3, 2); } }); ST_.wrapS = ST_.wrapT = THREE.RepeatWrapping; }
  const t = ST_.clone(); t.needsUpdate = true; t.repeat.set(rep, rep);
  return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 4, roughness: 0.95 });
}
function rockWall(w, h, d, seed = 1, rep = 1) {
  const geo = new THREE.BoxGeometry(w, h, d, 24, 24, 4); const p = geo.attributes.position; const R = R0(seed); const ph = [R() * 6, R() * 6];
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i); const n = Math.sin(y * 0.35 + ph[0]) * 0.6 + Math.sin(x * 0.4 + y * 0.2 + ph[1]) * 0.4; p.setXYZ(i, x + n * 0.4, y, z + n * 0.5); }
  geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, sandstone(rep)); m.castShadow = m.receiveShadow = true; return m;
}
// the Treasury facade carved into a cliff
function treasury() {
  const g = new THREE.Group(); const S = sandstone(2);
  const cliff = rockWall(60, 50, 14, 3, 3); cliff.position.set(0, 25, -7); g.add(cliff);
  const fm = new THREE.MeshStandardMaterial({ color: 0xd88a6a, roughness: 0.85, bumpMap: fabricTexture(31), bumpScale: 2 });
  const back = new THREE.Mesh(new THREE.BoxGeometry(24, 38, 1), fm); back.position.set(0, 19, -0.3); g.add(back);
  for (let i = 0; i < 6; i++) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.65, 12, 16), fm); c.position.set(-8.5 + i * 3.4, 6.5, 1.2); g.add(c); }
  const ent1 = new THREE.Mesh(new THREE.BoxGeometry(22, 2, 2.4), fm); ent1.position.set(0, 13.5, 1.2); g.add(ent1);
  const tri = new THREE.Shape(); tri.moveTo(-7, 0); tri.lineTo(7, 0); tri.lineTo(0, 3.4); tri.lineTo(-7, 0);
  const ped = new THREE.Mesh(new THREE.ExtrudeGeometry(tri, { depth: 1.6, bevelEnabled: false }), fm); ped.position.set(0, 14.5, 0.4); g.add(ped);
  const thol = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 11, 24), fm); thol.position.set(0, 24, 0.8); g.add(thol);
  for (let i = 0; i < 6; i++) { const a = -0.9 + i * 0.36; const c = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.45, 10, 12), fm); c.position.set(Math.sin(a) * 3.6, 24, 0.8 + Math.cos(a) * 3.6); g.add(c); }
  const roof = new THREE.Mesh(new THREE.ConeGeometry(3.4, 3, 24), fm); roof.position.set(0, 31, 0.8); g.add(roof);
  const urn = new THREE.Mesh(new THREE.SphereGeometry(0.9, 16, 12), fm); urn.position.set(0, 33.3, 0.8); g.add(urn);
  for (const s of [-1, 1]) { const pav = new THREE.Mesh(new THREE.BoxGeometry(5, 10, 2), fm); pav.position.set(s * 8.5, 24, 0.6); g.add(pav); }
  const door = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 7), new THREE.MeshStandardMaterial({ color: 0x1a0e0a })); door.position.set(0, 3.5, 0.25); g.add(door);
  g.traverse(o => { if (o.isMesh) { o.castShadow = o.receiveShadow = true; } });
  return g;
}
function desert(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.55, 0.5, 0.67], fog: 0.0025, shadowSize: 30, envI: 0.95, cloud: 0.15, ...opts });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(500, 48), new THREE.MeshStandardMaterial({ color: 0xc8906a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 160, rMax: 360, height: 60, seed: 5, color: 0xb87a5a }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  return scene;
}
// the Siq: a narrow winding gorge along z, with a rock-cut channel on the left and a clay pipe on the right
function siq(scene, { len = 120, gap = 4, h = 60 } = {}) {
  const segs = 8;
  for (let i = 0; i < segs; i++) { const z = -i * len / segs; const off = 0; for (const s of [-1, 1]) { const w = rockWall(14, h, len / segs + 2, 10 + i * 2 + (s > 0 ? 1 : 0), 2); w.position.set(off + s * (gap / 2 + 7), h / 2, z - len / segs / 2); scene.add(w); } }
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(gap + 4, len + 20), new THREE.MeshStandardMaterial({ color: 0xb87a5a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 4 })); floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0.01, -len / 2); floor.receiveShadow = true; scene.add(floor);
}
function channelAndPipe(scene, len = 60, gap = 4) {
  const lip = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.9, len), sandstone(1)); lip.position.set(-gap / 2 + 0.15, 0.45, -len / 2); lip.castShadow = lip.receiveShadow = true; scene.add(lip);
  const water = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.04, len), new THREE.MeshStandardMaterial({ color: 0x5aa8c8, roughness: 0.05, emissive: 0x0a3a5a, emissiveIntensity: 0.4 })); water.position.set(-gap / 2 + 0.6, 0.91, -len / 2); scene.add(water);
  const ledge = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.15, len), sandstone(1)); ledge.position.set(gap / 2 - 0.15, 1.0, -len / 2); ledge.castShadow = ledge.receiveShadow = true; scene.add(ledge);
  const pipeM = new THREE.MeshStandardMaterial({ color: 0xb85a3a, roughness: 0.8 });
  const pipes = new THREE.Group(); for (let i = 0; i < len / 0.5; i++) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.5, 14), pipeM); p.rotation.x = Math.PI / 2; p.position.set(gap / 2 - 0.62, 1.2, -i * 0.5 - 0.25); pipes.add(p); const ring = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.02, 6, 16), pipeM); ring.position.set(gap / 2 - 0.62, 1.2, -i * 0.5); pipes.add(ring); } scene.add(shadowAll(pipes));
  const N = 50; const fl = new THREE.InstancedMesh(new THREE.BoxGeometry(0.03, 0.01, 0.4), new THREE.MeshBasicMaterial({ color: 0xe8f8ff, transparent: true, opacity: 0.7 }), N); scene.add(fl);
  const D = [...Array(N)].map((_, i) => [(Math.sin(i * 12.9) * 0.08), (i * 0.618) % 1]); const m4 = new THREE.Matrix4();
  return (t) => { D.forEach(([x, ph], i) => { m4.makeTranslation(-gap / 2 + 0.6 + x * 0.6, 0.94, -((t * 0.08 + ph) % 1) * len); fl.setMatrixAt(i, m4); }); fl.instanceMatrix.needsUpdate = true; };
}

// ============ S0 hook: a long garden pool in the red desert ============
function sHook({ makeStage, start: ST }) {
  const scene = desert(makeStage, { sunDir: [-0.5, 0.55, 0.67] });
  const cliff = rockWall(80, 40, 12, 7, 3); cliff.position.set(0, 20, -36); scene.add(cliff);
  const rim = new THREE.Mesh(new THREE.BoxGeometry(9, 1.2, 28), new THREE.MeshStandardMaterial({ color: 0xd8a888, roughness: 0.9 })); rim.position.set(0, 0.3, -10); scene.add(shadowAll(rim));
  const pool = new THREE.Mesh(new THREE.PlaneGeometry(7.6, 26.6), waterMaterial({ color: 0x3a8aa0, opacity: 1, ripple: 0.8 })); pool.rotation.x = -Math.PI / 2; pool.position.set(0, 0.95, -10); scene.add(pool);
  const isle = new THREE.Mesh(new THREE.BoxGeometry(4, 0.9, 4), new THREE.MeshStandardMaterial({ color: 0xd8a888 })); isle.position.set(0, 0.6, -14); scene.add(shadowAll(isle));
  const pm = new THREE.MeshStandardMaterial({ color: 0xe8c0a0 });
  const pav = new THREE.Group(); for (const [x, z] of [[-1.4, -1.4], [1.4, -1.4], [-1.4, 1.4], [1.4, 1.4]]) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.22, 3.2, 12), pm); c.position.set(x, 2.6, z); pav.add(c); } const roof = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.5, 3.6), pm); roof.position.y = 4.4; pav.add(roof); pav.position.set(0, 0, -14); scene.add(shadowAll(pav));
  const green = new THREE.MeshStandardMaterial({ color: 0x5a8a3a, roughness: 1, bumpMap: fabricTexture(17), bumpScale: 4 });
  for (const s of [-1, 1]) { const bed = new THREE.Mesh(new THREE.BoxGeometry(5, 0.5, 30), green); bed.position.set(s * 6.6, 0.25, -10); scene.add(shadowAll(bed)); }
  for (let i = 0; i < 6; i++) for (const s of [-1, 1]) { const p = palm(6 + ((i * 3 + (s > 0 ? 1 : 0)) % 4) * 0.6, i * 2 + (s > 0 ? 1 : 0) + 4); p.position.set(s * (5.9 + (i % 2) * 1.0), 0.5, 2 - i * 5); scene.add(p); }
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(0, 1.2, k), lerp(12, 9, k), lerp(24, 19, k)], [0, lerp(2, 3, k), -14]);
      return { bloom: 0.55, flare: 1.1, warm: 1.25 };
    },
  };
}
// ============ S1: the Treasury at the end of the Siq ============
function sTreasury({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [-0.3, 0.6, 0.74] });
  const tr = treasury(); tr.position.set(0, 0, -20); scene.add(tr);
  for (const s of [-1, 1]) { const w = rockWall(16, 60, 50, 21 + s, 3); w.position.set(s * 16, 30, 6); scene.add(w); }
  const folk = [0, 1].map(i => { const m = romanBuilder({ color: [0xd8c7a2, 0x8a3a2a][i] }); m.root.position.set(-1 + i * 1.6, 0, -6); scene.add(m.root); return m; });
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((m, i) => { standPose(m, t + i, { head: [-0.4, 0, 0] }); m.setMood('happy'); });
      const k = easeInOut(range(t, 0, 4.0));
      place(c, [lerp(0, 0, k), lerp(1.6, 3, k), lerp(26, 10, k)], [0, lerp(12, 17, k), -20]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S2: dry ground under a hard sun; a few drops vanish ============
function sDry({ makeStage, start: ST }) {
  const scene = desert(makeStage, { sunDir: [-0.2, 0.35, -0.9], cloud: 0.05 });
  for (let i = 0; i < 6; i++) { const r = rockWall(10 + i * 2, 6 + i, 8, 30 + i, 1); r.position.set(-30 + i * 12, 3, -24 - i * 6); scene.add(r); }
  const drops = [...Array(5)].map((_, i) => { const s = glowSprite(0xd8eef8, 0.05); s.material.blending = THREE.NormalBlending; scene.add(s); return { s, i }; });
  const spots = [...Array(5)].map((_, i) => { const m = new THREE.Mesh(new THREE.CircleGeometry(0.09, 16), new THREE.MeshStandardMaterial({ color: 0x5a2a1a, transparent: true, opacity: 0 })); m.rotation.x = -Math.PI / 2; m.position.set(-0.5 + i * 0.25, 0.012, 0.3 + Math.sin(i * 1.7) * 0.4); scene.add(m); return m; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      drops.forEach(({ s, i }, j) => { const t0 = 0.3 + i * 0.55; const a = range(t, t0, t0 + 0.45); s.visible = a > 0 && a < 1; s.position.set(spots[j].position.x, 2.2 - a * 2.2, spots[j].position.z); spots[j].material.opacity = 0.85 * easeOut(range(t, t0 + 0.45, t0 + 0.55)) * (1 - range(t, t0 + 0.7, t0 + 1.6)); });
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [0, lerp(0.8, 0.7, k), lerp(3.2, 2.8, k)], [0, 0, -4]);
      return { bloom: 0.7, flare: 1.2, warm: 1.4, sat: 1.05 };
    },
  };
}
// ============ S3: cutaway: rock channels feed bell-shaped cisterns that fill up ============
function bellShape(cx) { const s = new THREE.Shape(); s.moveTo(cx - 0.45, 0); s.lineTo(cx - 0.45, -1.4); s.absarc(cx, -3.9, 2.4, Math.PI / 2 + 0.19, Math.PI * 2.5 - 0.19, false); s.lineTo(cx + 0.45, 0); s.lineTo(cx - 0.45, 0); return s; }
function waterShape(cx, L) { const cy = -3.9, r = 2.4; const a0 = Math.asin(clamp((L - cy) / r, -1, 1)); const s = new THREE.Shape(); s.moveTo(cx + Math.cos(a0) * r, L); s.absarc(cx, cy, r, a0, Math.PI - a0, true); s.lineTo(cx + Math.cos(a0) * r, L); return s; }
function sCistern({ makeStage, start: ST }) {
  const tH = at(3, 'hundreds') - ST, tC = at(3, 'cisterns') - ST;
  const scene = desert(makeStage, { cloud: 0.8, sunDir: [-0.4, 0.6, 0.7] });
  const ground = scene.children.find(o => o.geometry && o.geometry.type === 'CircleGeometry'); if (ground) ground.visible = false;
  const back = new THREE.Mesh(new THREE.PlaneGeometry(800, 400), new THREE.MeshStandardMaterial({ color: 0xc8906a, roughness: 1 })); back.rotation.x = -Math.PI / 2; back.position.set(0, 0, -200); back.receiveShadow = true; scene.add(back);
  const slab = new THREE.Mesh(new THREE.BoxGeometry(80, 30, 10), sandstone(4)); slab.position.set(0, -15, -5); slab.receiveShadow = true; scene.add(slab);
  const cliff = rockWall(80, 16, 8, 41, 3); cliff.position.set(0, 8, -12); scene.add(cliff);
  const dark = new THREE.MeshStandardMaterial({ color: 0x2a140e, roughness: 1 });
  const wm = new THREE.MeshStandardMaterial({ color: 0x3a9ac0, roughness: 0.15, emissive: 0x0a3a5a, emissiveIntensity: 0.5 });
  const xs = [-14, -7, 0, 7, 14];
  const cis = xs.map((x, i) => { const h = new THREE.Mesh(new THREE.ShapeGeometry(bellShape(x), 32), dark); h.position.z = 0.04; scene.add(h); const w = new THREE.Mesh(new THREE.BufferGeometry(), wm); w.position.z = 0.1; scene.add(w); return { x, w, i }; });
  const chan = new THREE.Mesh(new THREE.BoxGeometry(32, 0.05, 0.5), new THREE.MeshStandardMaterial({ color: 0x5aa8c8, roughness: 0.05, emissive: 0x0a3a5a, emissiveIntensity: 0.4 })); chan.position.set(0, 0.02, -1.2); scene.add(chan);
  const streams = xs.map(x => { const m = new THREE.Mesh(new THREE.BoxGeometry(0.22, 1, 0.22), new THREE.MeshStandardMaterial({ color: 0x8ac8e0, transparent: true, opacity: 0.85 })); scene.add(m); return m; });
  const N = 260; const rain = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.012, 0.012, 0.5, 4), new THREE.MeshBasicMaterial({ color: 0xd4e4f2, transparent: true, opacity: 0.5 }), N); scene.add(rain);
  const D = [...Array(N)].map((_, i) => [Math.sin(i * 12.9898) * 16, -Math.abs(Math.cos(i * 78.233)) * 8, (i * 0.618) % 1]); const m4 = new THREE.Matrix4();
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      D.forEach(([x, z, ph], i) => { m4.makeTranslation(x, 9 - ((t * 1.6 + ph) % 1) * 9, z); rain.setMatrixAt(i, m4); }); rain.instanceMatrix.needsUpdate = true;
      cis.forEach(({ x, w, i }, j) => {
        const t0 = i === 2 ? 0.4 : tH - 0.4 + Math.abs(i - 2) * 0.15; const L = -6.25 + 4.0 * easeInOut(range(t, t0, (i === 2 ? tH : tC + 0.8)));
        w.geometry.dispose(); w.geometry = new THREE.ShapeGeometry(waterShape(x, L), 24);
        const on = t > t0 - 0.2; streams[j].visible = on; streams[j].scale.y = Math.max(0.01, -L); streams[j].position.set(x, L / 2, 0.16);
      });
      const k = easeInOut(range(t, tH - 0.6, tH + 0.8));
      place(c, [0, lerp(0.5, 1.5, k), lerp(10, 34, k)], [0, lerp(-2.8, -1.2, k), 0]);
      return { bloom: 0.45, warm: 1.0, sat: 0.95 };
    },
  };
}
// ============ S4: walking the Siq: the clay pipe on one wall, the channel on the other ============
function sSiq({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [-0.2, 0.9, 0.3] });
  siq(scene);
  const flow = channelAndPipe(scene);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      flow(t);
      const z = lerp(-6, -14, easeInOut(range(t, 0, 4.4)));
      place(c, [0, 1.7, z], [0, 1.2, z - 5]);
      return { bloom: 0.55, warm: 1.25 };
    },
  };
}
// ============ S5: a brown flash flood roars down the gorge ============
function floodScene(makeStage, ST, tEnd) {
  const scene = desert(makeStage, { cloud: 0.85, sunDir: [-0.3, 0.6, 0.74] });
  siq(scene);
  const fm = new THREE.MeshStandardMaterial({ color: 0x7a5a3a, roughness: 0.35, bumpMap: fabricTexture(23), bumpScale: 3 });
  const fw = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 140), fm); fw.rotation.x = -Math.PI / 2; scene.add(fw);
  const wall = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 0.8, 4.6, 16, 1, false, 0, Math.PI), fm); wall.rotation.z = Math.PI / 2; scene.add(wall);
  const front = [...Array(40)].map((_, i) => { const s = glowSprite(0xd8c0a0, 1.2); s.material.blending = THREE.NormalBlending; scene.add(s); return { s, i }; });
  return { scene, update(t, c) {
    const fz = lerp(-40, -3, easeInOut(range(t, 0.1, tEnd)));
    fw.position.set(0, 0.7, fz - 70); wall.position.set(0, 0.7, fz);
    front.forEach(({ s, i }) => { s.position.set(Math.sin(i * 2.3) * 2, 0.6 + ((t * 2.2 + i / 40) % 1) * 1.8, fz + 0.4 + Math.cos(i) * 0.5); s.material.opacity = 0.75; s.scale.setScalar(0.8 + 0.5 * Math.sin(i + t * 5)); });
    const sh = fz > -25 ? shake(t * 6, 1.6, 4) : [0, 0, 0];
    place(c, [0.2 + sh[0] * 0.06, 2.0 + sh[1] * 0.06, 9], [0, 1.4, -20]);
  } };
}
function sFlood({ makeStage, start: ST, end: EN }) {
  const f = floodScene(makeStage, ST, (EN - ST) * 0.8); const c = cam(44);
  return { scene: f.scene, camera: c, update(t) { f.update(t, c); return { bloom: 0.4, warm: 0.9, sat: 0.9 }; } };
}
// ============ S6: the diversion dam blocks the gorge mouth; the flood turns into a tunnel ============
function damScene(makeStage, { modern = false } = {}) {
  const scene = desert(makeStage, { cloud: modern ? 0.3 : 0.75, sunDir: [-0.4, 0.6, 0.7] });
  for (const s of [-1, 1]) { const w = rockWall(14, 22, 30, 50 + s, 2); w.position.set(s * 9, 11, -24); scene.add(w); }
  const ridge = rockWall(30, 18, 14, 61, 2); ridge.position.set(-26, 9, -6); scene.add(ridge);
  const tunnel = new THREE.Mesh(new THREE.CircleGeometry(2.4, 24), new THREE.MeshStandardMaterial({ color: 0x140a08 })); tunnel.position.set(-10.4, 2.4, -6); tunnel.rotation.y = Math.PI / 2; scene.add(tunnel);
  const damM = modern ? new THREE.MeshStandardMaterial({ color: 0xa8a8a0, roughness: 0.8 }) : sandstone(1);
  const dam = new THREE.Mesh(new THREE.BoxGeometry(7, modern ? 3 : 2.6, 1.6), damM); dam.position.set(0, modern ? 1.5 : 1.3, -9.4); dam.castShadow = dam.receiveShadow = true; scene.add(dam);
  const wm = waterMaterial({ color: 0x7a5a3a, opacity: 1, ripple: 3 });
  const wadi = new THREE.Mesh(new THREE.PlaneGeometry(40, 8), wm); wadi.rotation.x = -Math.PI / 2; wadi.position.set(13, 0.5, -5); scene.add(wadi);
  const bend = new THREE.Mesh(new THREE.PlaneGeometry(12, 7), wm); bend.rotation.x = -Math.PI / 2; bend.position.set(-5, 0.5, -5.5); scene.add(bend);
  const N = 80; const fl = new THREE.InstancedMesh(new THREE.BoxGeometry(0.8, 0.02, 0.08), new THREE.MeshBasicMaterial({ color: 0xe8dcc8, transparent: true, opacity: 0.75 }), N); scene.add(fl);
  const D = [...Array(N)].map((_, i) => [(i * 0.618) % 1, Math.sin(i * 12.9) * 3]); const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  scene.userData.flow = (t, on) => { D.forEach(([ph, off], i) => { const a = (t * 0.22 * on + ph) % 1; const x = lerp(32, -10.6, a), z = -5 + off * lerp(1, 0.6, a); m4.compose(V(x, 0.53, z), q.identity(), V(1, 1, 1).multiplyScalar(on > 0.05 ? 1 : 1e-4)); fl.setMatrixAt(i, m4); }); fl.instanceMatrix.needsUpdate = true; };
  if (modern) { scene.userData.folk = [0, 1, 2].map(i => { const m = romanBuilder({ color: [0x2a5a9a, 0xd84a3a, 0xe8c040][i] }); m.root.position.set(-0.8 + i * 0.8, 0, -12 - i * 1.2); m.root.rotation.y = Math.PI; scene.add(m.root); m.setMood('happy'); return m; }); }
  return scene;
}
function sDam({ makeStage, start: ST }) {
  const scene = damScene(makeStage);
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.flow(t, 1);
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(2, -3, k), lerp(44, 40, k), lerp(20, 18, k)], [lerp(-1, -4, k), 0, -6]);
      return { bloom: 0.45, warm: 1.05 };
    },
  };
}
// ============ S7: 1963: the flood surges down the same canyon (no people shown), drained of colour ============
function sSurge({ makeStage, start: ST, end: EN }) {
  const f = floodScene(makeStage, ST, (EN - ST) * 0.8); const c = cam(44);
  return { scene: f.scene, camera: c, update(t) { f.update(t, c); return { bloom: 0.3, warm: 0.75, sat: 0.45 }; } };
}
// ============ S8: today: a modern dam on the old line, visitors walk in safely ============
function sNewDam({ makeStage }) {
  const scene = damScene(makeStage, { modern: true });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      scene.userData.flow(t, 0.4);
      (scene.userData.folk || []).forEach((m, i) => { const s = Math.sin(t * 5 + i); standPose(m, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07] }); m.root.position.z = -12 - i * 1.2 - t * 0.5; });
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(1, -1, k), lerp(24, 42, k), lerp(10, 20, k)], [lerp(0, -2, k), 0, lerp(-10, -7, k)]);
      return { bloom: 0.55, flare: 0.9, warm: 1.25 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sTreasury, 'treasury'],
  [ls(2), ls(3), sDry, 'dry'],
  [ls(3), ls(4), sCistern, 'cistern'],
  [ls(4), ls(5), sSiq, 'siq'],
  [ls(5), ls(6), sFlood, 'flood'],
  [ls(6), ls(7), sDam, 'dam'],
  [ls(7), ls(8), sSurge, 'surge'],
  [ls(8), DURATION + 1, sNewDam, 'newdam'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
