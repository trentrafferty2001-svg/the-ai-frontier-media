// Roman roads reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { mountains, trees, ringSpots, birds } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { shadowAll, romanBuilder, canvasTex } from './rome.js';
import { VO } from './vo_rr.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(9) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This road is', 3], ['over *2,000 years* old', 5], ['and people', 2], ['*still walk* on it', 4]],
  [["It's the *Appian Way*", 4], ['the *first great*', 3], ['*Roman road*', 2], ['built to move', 3], ['*armies* fast', 2]],
  [['Workers dug', 2], ['a *trench*', 2], ['often a meter', 3], ['*or more* deep', 3]],
  [['At the bottom', 3], ['went *big stones*', 3], ['then *gravel*', 2], ['mixed with *lime*', 3]],
  [['Then came', 2], ['*finer* packed gravel', 3], ['and on top', 3], ['tightly fitted', 2], ['*stone slabs*', 2]],
  [['The surface', 2], ['was *curved*', 2], ['so *rain* ran off', 4], ['into *ditches*', 2], ['at the sides', 3]],
  [['Stone *milestones*', 2], ['marked the distance', 3], ['every *Roman mile*', 3]],
  [['On these roads', 3], ['an army could march', 4], ['about', 1], ['*30 kilometers*', 2], ['a day', 2]],
  [['At their peak', 3], ['the Romans had', 3], ['about', 1], ['*80,000 kilometers*', 3], ['of *paved roads*', 3]],
  [['Many *modern highways*', 3], ['*still follow*', 2], ['their routes', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;

// ---------- textures ----------
function cellTex(w, h, nx, ny, seed, { base = [72, 72, 76], vary = 18, edge = 3, mortar = [150, 140, 118] } = {}) {
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const x = cv.getContext('2d');
  const R = R0(seed); const cw = w / nx, ch = h / ny; const P = []; const C = [];
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) { P.push([(i + 0.15 + R() * 0.7) * cw, (j + 0.15 + R() * 0.7) * ch]); const v = (R() - 0.5) * 2 * vary; C.push([base[0] + v, base[1] + v, base[2] + v * 0.9]); }
  const img = x.createImageData(w, h); const D = img.data;
  for (let py = 0; py < h; py++) for (let px = 0; px < w; px++) {
    const ci = Math.floor(px / cw), cj = Math.floor(py / ch); let d1 = 1e9, d2 = 1e9, k1 = 0;
    for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) { const ii = (ci + di + nx) % nx, jj = (cj + dj + ny) % ny; const p = P[jj * nx + ii]; let dx = px - p[0], dy = py - p[1]; if (dx > w / 2) dx -= w; if (dx < -w / 2) dx += w; if (dy > h / 2) dy -= h; if (dy < -h / 2) dy += h; const d = Math.hypot(dx, dy); if (d < d1) { d2 = d1; d1 = d; k1 = jj * nx + ii; } else if (d < d2) d2 = d; }
    const o = (py * w + px) * 4; const n = (R() - 0.5) * 10;
    const c = d2 - d1 < edge ? mortar : C[k1]; const sh = d2 - d1 < edge * 3 ? 0.85 : 1;
    D[o] = c[0] * sh + n; D[o + 1] = c[1] * sh + n; D[o + 2] = c[2] * sh + n; D[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
let SLAB_ = null;
function slabMat(rx = 1, ry = 1) { if (!SLAB_) SLAB_ = cellTex(512, 512, 5, 5, 11); const t = SLAB_.clone(); t.needsUpdate = true; t.repeat.set(rx, ry); return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 3, roughness: 0.8 }); }
function speckMat(base, dots, seed, rx = 1, ry = 1, size = 2) {
  const t = canvasTex(256, 256, (x) => { const R = R0(seed); x.fillStyle = base; x.fillRect(0, 0, 256, 256); for (let i = 0; i < 2600; i++) { x.fillStyle = dots[(R() * dots.length) | 0]; const s = size * (0.5 + R()); x.fillRect(R() * 256, R() * 256, s, s); } });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry);
  return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 3, roughness: 0.95 });
}
function boulderMat(rx = 1, ry = 1) {
  const t = canvasTex(256, 128, (x) => { const R = R0(5); x.fillStyle = '#5a4a3c'; x.fillRect(0, 0, 256, 128); for (let i = 0; i < 70; i++) { const g = 110 + R() * 50 | 0; x.fillStyle = `rgb(${g},${g - 8},${g - 20})`; x.beginPath(); x.ellipse(R() * 256, R() * 128, 10 + R() * 14, 7 + R() * 9, R() * 3, 0, 7); x.fill(); x.strokeStyle = 'rgba(30,20,10,0.6)'; x.lineWidth = 2; x.stroke(); } });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry);
  return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 5, roughness: 0.95 });
}
const soilMat = () => speckMat('#7a5a3e', ['#6a4a30', '#8a6a4a', '#5a3e28'], 3, 0.35, 0.35, 3);

// ---------- road pieces ----------
function roadGeo(len, hw, camber = 0.12) {
  const g = new THREE.PlaneGeometry(hw * 2, len, 24, 1); g.rotateX(-Math.PI / 2);
  const p = g.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i); p.setY(i, camber * (1 - (x / hw) ** 2)); }
  g.computeVertexNormals(); return g;
}
function road(len = 200, hw = 2.2, { worn = false } = {}) {
  const g = new THREE.Group();
  const m = new THREE.Mesh(roadGeo(len, hw), slabMat(2, len / (hw * 2) * 2)); m.position.z = -len / 2 + 10; m.receiveShadow = true; g.add(m);
  const curbM = speckMat('#8a8478', ['#7a746a', '#9a9488'], 7, 1, 40);
  for (const s of [-1, 1]) { const c = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.22, len), curbM); c.position.set(s * (hw + 0.17), 0.08, -len / 2 + 10); c.castShadow = c.receiveShadow = true; g.add(c); }
  return g;
}
function countryside(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.45, 0.66], fog: 0.004, shadowSize: 30, envI: 0.95, cloud: 0.3, ...opts });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(500, 48), new THREE.MeshStandardMaterial({ color: 0x8a9a52, roughness: 1, bumpMap: fabricTexture(17), bumpScale: 4 })); ground.rotation.x = -Math.PI / 2; ground.position.y = -0.02; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 190, rMax: 340, height: 16, seed: 8, color: 0x6a7a52 }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe6c8);
  return scene;
}
function umbrellaPine(h = 9, seed = 1) {
  const g = new THREE.Group(); const R = R0(seed);
  const tr = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.3, h, 8), new THREE.MeshStandardMaterial({ color: 0x5a4030, roughness: 1 })); tr.position.y = h / 2; tr.rotation.z = (R() - 0.5) * 0.15; g.add(tr);
  const cm = new THREE.MeshStandardMaterial({ color: 0x3e5a2a, roughness: 1, bumpMap: fabricTexture(17), bumpScale: 4 });
  for (let i = 0; i < 5; i++) { const c = new THREE.Mesh(new THREE.SphereGeometry(2.2 + R(), 14, 10), cm); c.scale.y = 0.38; c.position.set((R() - 0.5) * 3, h + (R() - 0.3) * 0.6, (R() - 0.5) * 3); g.add(c); }
  return shadowAll(g);
}
function cypress(h = 8) { const g = new THREE.Group(); const c = new THREE.Mesh(new THREE.ConeGeometry(0.9, h, 10), new THREE.MeshStandardMaterial({ color: 0x2a4a22, roughness: 1, bumpMap: fabricTexture(17), bumpScale: 3 })); c.position.y = h / 2 + 0.4; g.add(c); return shadowAll(g); }
function tomb(r = 3, h = 4, seed = 2) {
  const g = new THREE.Group(); const brick = speckMat('#a8724e', ['#8a5a3a', '#b8825e', '#c8a080'], seed, 4, 2, 3);
  const base = new THREE.Mesh(new THREE.BoxGeometry(r * 2.4, h * 0.5, r * 2.4), brick); base.position.y = h * 0.25; g.add(base);
  const cyl = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 28), brick); cyl.position.y = h * 0.5 + h * 0.5; g.add(cyl);
  return shadowAll(g);
}
function legionary(seed = 0) {
  const h = romanBuilder({ color: 0xa8281e });
  const bronze = new THREE.MeshStandardMaterial({ color: 0xb08a3a, metalness: 0.7, roughness: 0.35 });
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.165, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), bronze); helm.position.y = 0.06; helm.scale.set(1, 0.95, 1.08); h.j.head.add(helm);
  const crest = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.09, 0.26), new THREE.MeshStandardMaterial({ color: 0xc8281e, roughness: 0.9 })); crest.position.y = 0.23; h.j.head.add(crest);
  const sc = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.95, 20, 1, true, -0.55, 1.1), new THREE.MeshStandardMaterial({ color: 0xb02a1e, roughness: 0.7, side: THREE.DoubleSide }));
  sc.position.set(0.32, 0.72, -0.25); sc.rotation.y = Math.PI / 2 + 0.2; h.root.add(sc);
  const boss = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 8), bronze); boss.position.set(0.32 + 0.28, 0.72, 0.02); h.root.add(boss);
  const pil = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 2.0, 6), new THREE.MeshStandardMaterial({ color: 0x6a4a2a })); pil.position.set(-0.3, 1.05, 0.08); h.root.add(pil);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.18, 6), new THREE.MeshStandardMaterial({ color: 0x9a9a9a, metalness: 0.8, roughness: 0.3 })); tip.position.set(-0.3, 2.1, 0.08); h.root.add(tip);
  shadowAll(h.root); return h;
}
const march = (m, t, ph, k = 1) => { const s = Math.sin(t * 6 + ph) * k; standPose(m, t + ph, { lHip: [s * 0.4, 0, 0.06], rHip: [-s * 0.4, 0, -0.06], lKn: [Math.max(0, -s) * 0.5, 0, 0], rKn: [Math.max(0, s) * 0.5, 0, 0], rSh: [-0.15, 0, -0.1], lSh: [-0.5, 0, 0.3], lEl: [-0.9, 0, 0] }); m.setMood('happy'); };
function milestone() {
  const g = new THREE.Group(); const st = speckMat('#d8d0c0', ['#c8c0b0', '#e0dace'], 9, 2, 2, 2);
  const tex = canvasTex(512, 512, (x) => { x.fillStyle = '#d8d0c0'; x.fillRect(0, 0, 512, 512); x.fillStyle = '#4a4238'; x.textAlign = 'center'; x.font = 'bold 70px serif'; x.fillText('M·P', 256, 230); x.font = 'bold 90px serif'; x.fillText('XII', 256, 340); });
  const col = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 2.0, 32), [new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9 }), st, st]); col.position.y = 1.2; col.rotation.y = Math.PI; g.add(col);
  const base = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.25, 0.9), st); base.position.y = 0.12; g.add(base);
  return shadowAll(g);
}

// ============ S0 hook: the Appian Way today, low over the worn slabs ============
function viaAppia(scene, { tourists = true } = {}) {
  scene.add(road(240, 2.2));
  const R = R0(3);
  for (let i = 0; i < 18; i++) { const s = i % 2 ? 1 : -1; const p = umbrellaPine(8 + R() * 3, i + 3); p.position.set(s * (7 + R() * 6), 0, 4 - i * 12 - R() * 6); scene.add(p); }
  for (let i = 0; i < 14; i++) { const s = i % 2 ? -1 : 1; const c = cypress(6 + R() * 3); c.position.set(s * (4.2 + R() * 1.2), 0, -3 - i * 15); scene.add(c); }
  const tb = tomb(3, 4, 4); tb.position.set(-11, 0, -40); scene.add(tb);
  const tb2 = tomb(2, 3, 6); tb2.position.set(10, 0, -75); scene.add(tb2);
  const ruins = speckMat('#b88a64', ['#9a6a4a', '#c8a07a'], 12, 2, 2, 3);
  for (let i = 0; i < 6; i++) { const w = new THREE.Mesh(new THREE.BoxGeometry(1 + R() * 2, 1 + R() * 2.5, 0.6), ruins); w.position.set((i % 2 ? 1 : -1) * (5 + R() * 2), 0.8, -20 - i * 22); w.castShadow = true; scene.add(w); }
  if (!tourists) return [];
  return [0, 1, 2].map(i => { const m = romanBuilder({ color: [0x2a5a9a, 0xe8c040, 0xd84a3a][i] }); m.root.position.set(-0.9 + i * 1.0, 0.12, -9 - i * 1.6); m.root.rotation.y = Math.PI; scene.add(m.root); return m; });
}
function sHook({ makeStage }) {
  const scene = countryside(makeStage, { sunDir: [-0.5, 0.3, -0.81] });
  const folk = viaAppia(scene);
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((m, i) => { const s = Math.sin(t * 5 + i * 2); standPose(m, t + i, { lHip: [s * 0.3, 0, 0.07], rHip: [-s * 0.3, 0, -0.07] }); m.setMood('happy'); m.root.position.z = -9 - i * 1.6 - t * 0.9; });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [0.4, lerp(0.35, 1.7, k), lerp(4, -1, k)], [0, lerp(0.1, 1.4, k), lerp(-4, -30, k)]);
      return { bloom: 0.6, flare: 1.2, warm: 1.25, sat: 1.05 };
    },
  };
}
// ============ S1: a legion marches down the new road ============
function sLegion({ makeStage }) {
  const scene = countryside(makeStage, { sunDir: [-0.6, 0.45, 0.66] });
  scene.add(road(260, 2.2));
  const R = R0(9);
  scene.add(trees(ringSpots(40, 14, 70, 4).filter(p => Math.abs(p[0]) > 8), { seed: 5, scale: 1.2 }));
  const ms = milestone(); ms.position.set(3.4, 0, -6); scene.add(ms);
  const L = []; for (let r = 0; r < 7; r++) for (let q = 0; q < 4; q++) { const m = legionary(r * 4 + q); m.root.position.set(-1.35 + q * 0.9, 0.12, -10 - r * 1.4); scene.add(m.root); L.push({ m, r, q }); }
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      L.forEach(({ m, r, q }) => { march(m, t, r * 0.7 + q * 0.2); m.root.position.z = -12 - r * 1.4 + t * 1.3; });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(3.8, 2.8, k), lerp(1.1, 1.6, k), lerp(4, 6, k)], [lerp(0, -0.4, k), 1.2, lerp(-12, -8, k)]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ cutaway: the road's layers in a trench (front face at z = 0) ============
const HW = 2.5, TD = 1.3;
function prof(x0, x1, y0, y1, camber = 0) { const s = new THREE.Shape(); s.moveTo(x0, y0); s.lineTo(x1, y0); s.lineTo(x1, y1); const N = 16; for (let i = 1; i < N; i++) { const x = x1 + (x0 - x1) * i / N; s.lineTo(x, y1 + camber * (1 - (x / x1) ** 2)); } s.lineTo(x0, y1); s.lineTo(x0, y0); return s; }
function slab(shape, mat, depth = 14) { const m = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false }), mat); m.position.z = -depth; m.castShadow = m.receiveShadow = true; return m; }
function cutawayStage(makeStage, opts = {}) {
  const scene = countryside(makeStage, { sunDir: [-0.5, 0.6, 0.62], fog: 0.003, ...opts });
  const gr = scene.children.find(o => o.geometry && o.geometry.type === 'CircleGeometry'); if (gr) gr.visible = false;
  const back = new THREE.Mesh(new THREE.PlaneGeometry(900, 450), new THREE.MeshStandardMaterial({ color: 0x8a9a52, roughness: 1 })); back.rotation.x = -Math.PI / 2; back.position.set(0, -0.02, -14 - 225); back.receiveShadow = true; scene.add(back);
  const soil = soilMat(); const grass = new THREE.MeshStandardMaterial({ color: 0x7a9048, roughness: 1 });
  // soil around the trench, with side ditches at x = ±(3.0..3.6)
  const add = (x0, x1, y1) => { const m = slab(prof(x0, x1, -12, y1), soil); scene.add(m); const top = new THREE.Mesh(new THREE.BoxGeometry(x1 - x0, 0.04, 14), grass); top.position.set((x0 + x1) / 2, y1 + 0.02, -7); top.receiveShadow = true; scene.add(top); };
  const bottom = slab(prof(-HW, HW, -12, -TD), soil); scene.add(bottom);
  for (const s of [-1, 1]) {
    const seg = (a, b, y) => s > 0 ? add(a, b, y) : add(-b, -a, y);
    seg(HW, 3.0, 0); seg(3.0, 3.6, -0.45); seg(3.6, 40, 0);
  }
  const dark = new THREE.MeshStandardMaterial({ color: 0x3a2a1c, roughness: 1 });
  const line = new THREE.Mesh(new THREE.PlaneGeometry(80, 0.03), dark); line.position.set(0, -12, 0.01); scene.add(line);
  return scene;
}
function layers(scene) {
  const L = {
    stat: slab(prof(-HW, HW, -TD, -TD + 0.5), boulderMat(0.5, 1.4)),
    rud: slab(prof(-HW, HW, -TD + 0.5, -TD + 0.78), speckMat('#b8b0a0', ['#8a8478', '#e8e4da', '#6a6458'], 21, 0.6, 0.6, 3)),
    nuc: slab(prof(-HW, HW, -TD + 0.78, -TD + 1.08), speckMat('#a89070', ['#8a7458', '#c8b090', '#e0d0b0'], 22, 0.8, 0.8, 1.5)),
    pav: slab(prof(-HW, HW, -TD + 1.08, -TD + 1.28, 0.16), slabMat(0.35, 0.35)),
  };
  for (const s of [-1, 1]) { const c = slab(prof(-0.18, 0.18, -TD + 0.78, 0.25), speckMat('#8a8478', ['#7a746a', '#9a9488'], 7, 1, 2)); c.position.x = s * (HW - 0.18); L['curb' + s] = c; }
  Object.values(L).forEach(m => { m.visible = false; scene.add(m); });
  return L;
}
const drop = (m, k, h = 3) => { m.visible = k > 0; m.position.y = (1 - easeOut(k)) * h; };
function shovel() { const g = new THREE.Group(); const hd = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1.1, 6), new THREE.MeshStandardMaterial({ color: 0x7a5a3a })); hd.position.y = -0.4; g.add(hd); const bl = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.26, 0.02), new THREE.MeshStandardMaterial({ color: 0x8a8a8a, metalness: 0.6, roughness: 0.4 })); bl.position.y = -1.05; g.add(bl); return shadowAll(g); }
function diggers(scene, n = 3) {
  return [...Array(n)].map((_, i) => { const m = romanBuilder({ color: [0xd8c7a2, 0x9a6a3a, 0xc8b890][i % 3] }); m.root.position.set(-1.5 + i * 1.5, 0, -1.6 - (i % 2) * 1.2); m.root.rotation.y = i % 2 ? -0.5 : 0.5; scene.add(m.root); const sv = shovel(); m.j.rWr.add(sv); return m; });
}
const dig = (m, t, ph) => { const s = Math.sin(t * 4 + ph); standPose(m, t + ph, { spine: [0.35 + s * 0.15, 0, 0], rSh: [-0.9 - s * 0.5, 0, -0.2], lSh: [-1.0 - s * 0.5, 0, 0.3], rEl: [-0.6, 0, 0], lEl: [-0.7, 0, 0], lKn: [0.3, 0, 0], rKn: [0.3, 0, 0], head: [0.3, 0, 0] }); m.setMood('happy'); };
function sTrench({ makeStage, start: ST }) {
  const tT = at(2, 'trench') - ST, tD = at(2, 'deep') - ST;
  const scene = cutawayStage(makeStage);
  const fill = slab(prof(-HW, HW, -TD, 0), soilMat()); scene.add(fill);
  const piles = [-1, 1].map(s => { const p = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), soilMat()); p.position.set(s * 5.2, 0, -5); scene.add(shadowAll(p)); return p; });
  const men = diggers(scene);
  const rule = new THREE.Group(); const rm = new THREE.MeshBasicMaterial({ color: 0xffffff }); const bar = new THREE.Mesh(new THREE.BoxGeometry(0.04, TD, 0.02), rm); bar.position.y = -TD / 2; rule.add(bar); for (const y of [0, -TD]) { const tk = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.04, 0.02), rm); tk.position.y = y; rule.add(tk); } rule.position.set(HW - 0.35, 0, 0.05); scene.add(rule);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0.2, tD + 0.2)); const top = -TD * k;
      fill.scale.y = Math.max(0.001, 1 - k); fill.position.y = top; fill.visible = k < 0.999;
      piles.forEach(p => p.scale.set(1.2 + k * 0.8, 0.2 + k * 0.9, 2.5));
      men.forEach((m, i) => { dig(m, t, i * 1.3); m.root.position.y = top; });
      rule.visible = t > tD - 0.6; rule.scale.y = easeOut(range(t, tD - 0.6, tD));
      const kc = easeInOut(range(t, 0, 4));
      place(c, [lerp(1.6, 1.0, kc), lerp(1.2, 0.4, kc), lerp(8, 6.5, kc)], [0.4, lerp(-1.0, -1.5, kc), -1.5]);
      return { bloom: 0.45, warm: 1.15 };
    },
  };
}
function sLayers1({ makeStage, start: ST }) {
  const tB = at(3, 'stones') - ST, tG = at(3, 'gravel') - ST, tL = at(3, 'lime') - ST;
  const scene = cutawayStage(makeStage); const L = layers(scene);
  const stones = [...Array(26)].map((_, i) => { const s = new THREE.Mesh(new THREE.DodecahedronGeometry(0.16 + (i % 3) * 0.04, 0), new THREE.MeshStandardMaterial({ color: 0x8a7a68, roughness: 1 })); s.castShadow = true; scene.add(s); return s; });
  const R = R0(4); const SP = stones.map(() => [(R() - 0.5) * 4.4, -0.3 - R() * 3, R() * 0.5]);
  const lime = [...Array(40)].map(() => { const s = glowSprite(0xf0ece0, 0.25); s.material.blending = THREE.NormalBlending; scene.add(s); return s; });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const ks = range(t, tB - 0.5, tB + 0.25); drop(L.stat, ks, 1.2);
      stones.forEach((s, i) => { const k = range(t, tB - 0.9 + i * 0.03, tB - 0.2 + i * 0.03); s.visible = k > 0 && ks < 0.99; s.position.set(SP[i][0], lerp(3, -TD + 0.2, easeIn(k)), SP[i][1]); s.rotation.set(i, t * 2, i * 2); });
      drop(L.rud, range(t, tG - 0.25, tG + 0.2), 0.8);
      lime.forEach((s, i) => { const k = range(t, tL - 0.2 + (i % 8) * 0.04, tL + 1.0); s.visible = k > 0 && k < 1; s.position.set(-2.2 + (i % 10) * 0.48, -TD + 0.85 + k * 0.7, -0.3 - (i % 4) * 0.8); s.material.opacity = 0.7 * (1 - k); });
      const kc = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(1.2, 0.5, kc), lerp(0.1, -0.2, kc), lerp(6.2, 5.4, kc)], [0, lerp(-1.8, -1.9, kc), -1]);
      return { bloom: 0.45, warm: 1.15 };
    },
  };
}
function sLayers2({ makeStage, start: ST }) {
  const tF = at(4, 'finer') - ST, tS = at(4, 'slabs') - ST, tT = at(4, 'tightly') - ST;
  const scene = cutawayStage(makeStage); const L = layers(scene);
  L.stat.visible = L.rud.visible = true;
  const ram = new THREE.Group(); const rh = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.2, 6), new THREE.MeshStandardMaterial({ color: 0x7a5a3a })); rh.position.y = 0.6; ram.add(rh); const rb = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.18, 12), new THREE.MeshStandardMaterial({ color: 0x5a4a3a })); ram.add(rb); scene.add(shadowAll(ram));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      drop(L.nuc, range(t, tF - 0.25, tF + 0.2), 0.8);
      const pk = range(t, tT - 0.6, tS + 0.2); drop(L.pav, pk, 1.0); L['curb1'].visible = L['curb-1'].visible = pk > 0.6;
      ram.visible = t > tF + 0.3 && t < tT - 0.5; ram.position.set(-0.5 + Math.sin(t * 2) * 1.2, -TD + 1.08 + Math.abs(Math.sin(t * 7)) * 0.35, -1.2);
      const kc = easeInOut(range(t, 0, 4.8));
      place(c, [lerp(0.5, 1.6, kc), lerp(-0.2, 0.8, kc), lerp(5.4, 7.6, kc)], [0, lerp(-1.9, -1.6, kc), -1]);
      return { bloom: 0.45, warm: 1.15 };
    },
  };
}
// ============ S5: rain runs off the curved surface into the side ditches ============
function sRain({ makeStage, start: ST }) {
  const tR = at(5, 'rain') - ST, tD = at(5, 'ditches') - ST;
  const scene = cutawayStage(makeStage, { cloud: 0.85 }); const L = layers(scene);
  Object.values(L).forEach(m => m.visible = true);
  const wm = new THREE.MeshStandardMaterial({ color: 0x4a9ac8, roughness: 0.1, emissive: 0x0a3a5a, emissiveIntensity: 0.5, transparent: true, opacity: 0.85 });
  const ditches = [-1, 1].map(s => { const d = new THREE.Mesh(new THREE.BoxGeometry(0.6, 1, 14), wm); d.position.set(s * 3.3, -0.45, -7); scene.add(d); return d; });
  const N = 60; const streaks = new THREE.InstancedMesh(new THREE.BoxGeometry(0.22, 0.02, 0.05), new THREE.MeshBasicMaterial({ color: 0x9ad8f8 }), N); scene.add(streaks);
  const D = [...Array(N)].map((_, i) => [i % 2 ? 1 : -1, (i * 0.618) % 1, -0.2 - ((i * 0.37) % 1) * 6]); const m4 = new THREE.Matrix4(), q = new THREE.Quaternion();
  const M = 300; const rain = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.01, 0.01, 0.4, 4), new THREE.MeshBasicMaterial({ color: 0xd4e4f2, transparent: true, opacity: 0.55 }), M); scene.add(rain);
  const RD = [...Array(M)].map((_, i) => [Math.sin(i * 12.9898) * 6, -Math.abs(Math.cos(i * 78.233)) * 7, (i * 0.618) % 1]);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      RD.forEach(([x, z, ph], i) => { m4.makeTranslation(x, 7 - ((t * 1.6 + ph) % 1) * 7.2, z); rain.setMatrixAt(i, m4); }); rain.instanceMatrix.needsUpdate = true;
      const on = range(t, tR - 0.3, tR + 0.3);
      D.forEach(([s, ph, z], i) => { const a = (t * 0.7 + ph) % 1; const x = s * a * (HW + 0.9); const y = -TD + 1.28 + 0.16 * (1 - Math.min(1, (x / HW) ** 2)) + 0.015 - (Math.abs(x) > HW ? (Math.abs(x) - HW) * 0.8 : 0); q.setFromAxisAngle(V(0, 0, 1), -s * 0.12); m4.compose(V(x, y, z), q, V(1, 1, 1).multiplyScalar(on > 0.05 ? 1 : 1e-4)); streaks.setMatrixAt(i, m4); }); streaks.instanceMatrix.needsUpdate = true;
      const lv = 0.05 + 0.3 * easeInOut(range(t, tR, tD + 0.8)); ditches.forEach(d => { d.scale.y = lv; d.position.y = -0.45 + lv / 2; });
      const kc = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(2.6, 1.0, kc), lerp(2.0, 1.4, kc), lerp(9, 10, kc)], [0, -1.4, -1.5]);
      return { bloom: 0.45, warm: 0.95, sat: 0.95 };
    },
  };
}
// ============ S6: a milestone beside the road ============
function sMile({ makeStage }) {
  const scene = countryside(makeStage, { sunDir: [-0.4, 0.5, 0.77] });
  scene.add(road(200, 2.2));
  const ms = milestone(); ms.position.set(3.4, 0, -2); scene.add(ms);
  const ms2 = milestone(); ms2.position.set(3.4, 0, -150); scene.add(ms2);
  scene.add(trees(ringSpots(30, 12, 60, 7).filter(p => Math.abs(p[0]) > 8), { seed: 6, scale: 1.2 }));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 3.6)); const a = lerp(-0.25, 0.3, k);
      place(c, [3.4 + Math.sin(a) * 4.6, lerp(1.4, 1.8, k), -2 + Math.cos(a) * 4.6], [lerp(3.4, 2.6, k), lerp(1.4, 1.2, k), lerp(-2, -8, k)]);
      return { bloom: 0.5, warm: 1.2, sat: 1.05 };
    },
  };
}
// ============ S7: a long column marches on, milestones flick past ============
function sMarch({ makeStage }) {
  const scene = countryside(makeStage, { sunDir: [-0.7, 0.35, 0.6] });
  scene.add(road(400, 2.2, {}));
  for (let i = 0; i < 4; i++) { const ms = milestone(); ms.position.set(3.4, 0, 10 - i * 30); scene.add(ms); }
  scene.add(trees(ringSpots(60, 12, 90, 11).filter(p => Math.abs(p[0]) > 8), { seed: 8, scale: 1.2 }));
  const L = []; for (let r = 0; r < 14; r++) for (let q = 0; q < 4; q++) { const m = legionary(); m.root.position.set(-1.35 + q * 0.9, 0.12, 0); m.root.rotation.y = Math.PI; scene.add(m.root); L.push({ m, r, q }); }
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const z0 = -t * 1.6;
      L.forEach(({ m, r, q }) => { march(m, t, r * 0.6 + q * 0.2); m.root.position.z = z0 - 2 - r * 1.4; });
      place(c, [lerp(5, 3.5, range(t, 0, 4)), lerp(4.5, 3.2, range(t, 0, 4)), z0 + 6], [0, 1, z0 - 10]);
      return { bloom: 0.55, flare: 1.0, warm: 1.3 };
    },
  };
}
// ============ S8: the network spreads across the empire ============
const LON0 = -10, LON1 = 42, LAT0 = 28, LAT1 = 56, MW = 2048, MH = Math.round(2048 * (LAT1 - LAT0) / (LON1 - LON0) * 1.25);
const mp = ([lo, la]) => [(lo - LON0) / (LON1 - LON0) * MW, (1 - (la - LAT0) / (LAT1 - LAT0)) * MH];
const SEA = [[-5.6, 36], [-2, 36.7], [0, 38.5], [0.5, 40.5], [3.2, 41.9], [3.1, 43.2], [4.5, 43.4], [6.5, 43.1], [8, 43.8], [8.9, 44.4], [10.2, 43.9], [11, 42.4], [12.5, 41.5], [14, 40.8], [15.6, 40], [15.8, 38.9], [16, 38], [16.6, 38.4], [17.1, 39], [16.6, 40.1], [17.2, 40.5], [18.5, 40.1], [18.4, 40.6], [16, 41.5], [14, 42.5], [13.6, 43.6], [12.3, 44.5], [12.3, 45.4], [13.7, 45.6], [14.5, 45.2], [15.2, 44.2], [16.4, 43.5], [18, 42.6], [19.4, 41.9], [19.5, 40.5], [20.2, 39.5], [21.1, 38.3], [21.7, 36.8], [22.5, 36.4], [23.2, 36.5], [23, 37.9], [24, 38], [22.9, 40.5], [24, 40.8], [26, 40.8], [26.4, 40.2], [26.8, 39.3], [27.2, 38.4], [27.3, 37], [28.2, 36.7], [30.7, 36.8], [33, 36.1], [36.1, 36.6], [35.8, 35], [35.5, 33.8], [34.9, 32.6], [34.3, 31.3], [32.3, 31.2], [30, 31.3], [29, 30.9], [25, 31.6], [20.1, 32], [19, 30.4], [15.6, 31.6], [13, 32.8], [11, 33.6], [10.2, 35.2], [11, 36.8], [10.2, 37.3], [8.6, 36.9], [3, 36.8], [0, 35.8], [-2, 35.1], [-5.6, 35.9]];
const ISLANDS = [[[12.4, 38.1], [15.6, 38.3], [15.1, 36.7], [12.4, 37.6]], [[8.2, 39], [9.8, 39.2], [9.8, 41.2], [8.2, 40.9]], [[8.6, 41.4], [9.5, 41.4], [9.5, 43], [8.6, 42.6]], [[23.5, 35.3], [26.3, 35.1], [26.2, 35.4], [23.6, 35.6]], [[32.3, 34.7], [34.5, 35.6], [34, 35.1], [32.4, 35.1]]];
const BLACK = [[28, 41.2], [28.6, 43.4], [29.7, 45.2], [30.8, 46.5], [32.6, 46.1], [33.6, 44.5], [36, 45.2], [37.7, 44.6], [39.8, 43.4], [41.6, 41.6], [40, 41], [37, 41.1], [35, 42], [33.3, 42], [31, 41.1], [29.2, 41.2]];
const OCEAN = [[-10, 28], [-9.8, 29.5], [-6, 35.8], [-6, 36.9], [-7.4, 37.2], [-8.9, 37], [-8.8, 38.7], [-9.4, 39.4], [-8.8, 41.8], [-9.3, 43], [-8, 43.7], [-4, 43.5], [-1.8, 43.4], [-1.2, 44.7], [-1.2, 46.2], [-2.2, 47.1], [-4.6, 48.3], [-1.6, 48.7], [1.5, 50.2], [3, 51.2], [4.5, 52.5], [5, 53.3], [8.5, 53.6], [8.6, 56], [-10, 56]];
const BRIT = [[-5.7, 50], [1.3, 51.1], [1.7, 52.7], [0.2, 53.5], [-0.5, 54.5], [-1.6, 55.6], [-2, 56], [-5.5, 56], [-4.8, 54.8], [-3, 54], [-4.6, 53.3], [-4.4, 52.3], [-5.2, 51.7], [-3, 51.3]];
const ROME = [12.5, 41.9];
const ROUTES = [
  [ROME, [14.25, 41.1], [16, 41], [17.9, 40.6]],
  [ROME, [12.6, 43], [12.6, 44.1], [11.3, 44.5], [9.2, 45.5], [7.7, 45.1], [6, 45.3], [4.8, 45.8], [4.5, 47], [2.35, 48.85], [1.6, 50.7]],
  [ROME, [11, 43.3], [8.9, 44.4], [7, 43.7], [5.4, 43.3], [3, 43.2], [2.2, 41.6], [1.25, 41.1], [-0.9, 41.65], [-3.7, 40.4], [-4.8, 37.9], [-6.3, 36.5]],
  [[-0.9, 41.65], [-5.6, 42.6], [-8.5, 42.9]],
  [[4.8, 45.8], [6.2, 47.2], [6.6, 49.75], [6.95, 50.9]],
  [[9.2, 45.5], [11.1, 46.1], [12, 47.9], [16.4, 48.2]],
  [[-0.1, 51.5], [-1.1, 54]], [[-0.1, 51.5], [-2.6, 52.6], [-2.9, 53.2]],
  [[17.9, 40.6], [19.45, 41.3], [21.1, 41.1], [22.9, 40.6], [25.5, 41], [29, 41]],
  [[29, 41], [30.4, 40.7], [32.9, 39.9], [35.5, 38.7], [36.2, 36.2], [36.3, 33.5], [35.2, 31.8], [32.5, 30.8], [29.9, 31.2]],
  [[29, 41], [27.4, 37.9]], [[22.9, 40.6], [22.4, 39.4], [23.7, 38]],
  [[10.3, 36.85], [8, 36.4], [5.4, 36.2], [3, 36.7], [0, 35.6], [-5.8, 35.8]],
  [[10.3, 36.85], [10.7, 34.7], [13.2, 32.9], [15.1, 32.3], [19.9, 31.4], [21.9, 32.8], [25, 31.6], [29.9, 31.2]],
];
function sMap({ makeStage, start: ST }) {
  const tK = at(8, 'eighty') - ST;
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.4, 0.8, 0.45], fog: 0.0, shadowSize: 20, envI: 1.0 });
  fillLight(scene, [0.3, 1, 0.6], 0.8, 0xfff2e0);
  const base = document.createElement('canvas'); base.width = MW; base.height = MH; const b = base.getContext('2d');
  const poly = (P, col) => { b.fillStyle = col; b.beginPath(); P.forEach((p, i) => { const [x, y] = mp(p); i ? b.lineTo(x, y) : b.moveTo(x, y); }); b.closePath(); b.fill(); };
  b.fillStyle = '#d8c39a'; b.fillRect(0, 0, MW, MH);
  const R = R0(2); for (let i = 0; i < 4000; i++) { b.fillStyle = `rgba(120,90,50,${0.05 + R() * 0.08})`; b.fillRect(R() * MW, R() * MH, 3, 3); }
  const sea = '#5a8aa8'; poly(SEA, sea); poly(BLACK, sea); poly(OCEAN, sea); poly(BRIT, '#d8c39a'); ISLANDS.forEach(I => poly(I, '#d8c39a'));
  const cv = document.createElement('canvas'); cv.width = MW; cv.height = MH; const x = cv.getContext('2d');
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  const PW = 20, PH = PW * MH / MW;
  const plane = new THREE.Mesh(new THREE.PlaneGeometry(PW, PH), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9 })); plane.rotation.x = -Math.PI / 2; plane.receiveShadow = true; scene.add(plane);
  const frame = new THREE.Mesh(new THREE.BoxGeometry(PW + 0.6, 0.3, PH + 0.6), new THREE.MeshStandardMaterial({ color: 0x5a3a24, roughness: 0.8 })); frame.position.y = -0.16; scene.add(frame);
  const table = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: 0x3a2a1c, roughness: 0.9 })); table.rotation.x = -Math.PI / 2; table.position.y = -0.31; scene.add(table);
  const RL = ROUTES.map(rt => { let L = 0; const seg = []; for (let i = 1; i < rt.length; i++) { const a = mp(rt[i - 1]), c = mp(rt[i]); const d = Math.hypot(c[0] - a[0], c[1] - a[1]); seg.push([a, c, d]); L += d; } return { seg, L }; });
  const rp = mp(ROME); const romeW = [(rp[0] / MW - 0.5) * PW, 0, (rp[1] / MH - 0.5) * PH];
  let last = -1;
  const draw = (k) => {
    x.drawImage(base, 0, 0); x.strokeStyle = '#b02a1e'; x.lineWidth = 9; x.lineCap = x.lineJoin = 'round';
    RL.forEach(({ seg, L }, ri) => { const kk = clamp(k * 1.25 - ri * 0.02); let rem = kk * L; x.beginPath(); x.moveTo(seg[0][0][0], seg[0][0][1]); for (const [a, c, d] of seg) { if (rem <= 0) break; const f = Math.min(1, rem / d); x.lineTo(a[0] + (c[0] - a[0]) * f, a[1] + (c[1] - a[1]) * f); rem -= d; } x.stroke(); });
    x.fillStyle = '#f0d040'; x.strokeStyle = '#5a3a10'; x.lineWidth = 5; x.beginPath(); x.arc(rp[0], rp[1], 20, 0, 7); x.fill(); x.stroke();
    tex.needsUpdate = true;
  };
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0.2, tK + 1.2)); if (Math.abs(k - last) > 1e-4) { draw(k); last = k; }
      const kc = easeInOut(range(t, 0, tK + 1.6));
      place(c, [romeW[0] + lerp(0, 1, kc), lerp(5, 14, kc), romeW[2] + lerp(4, 8, kc)], [romeW[0] + lerp(0, -1, kc), 0, romeW[2] + lerp(0, -0.5, kc)]);
      return { bloom: 0.4, warm: 1.1 };
    },
  };
}
// ============ S9: the old stone road becomes a modern highway on the same line ============
function sModern({ makeStage }) {
  const scene = countryside(makeStage, { sunDir: [-0.6, 0.45, 0.66] });
  const old = road(30, 2.2); old.position.z = 6; scene.add(old);
  const asph = new THREE.Mesh(new THREE.PlaneGeometry(9, 400), new THREE.MeshStandardMaterial({ color: 0x3a3a3e, roughness: 0.85, bumpMap: fabricTexture(23), bumpScale: 1 })); asph.rotation.x = -Math.PI / 2; asph.position.set(0, 0.03, -14 - 200); asph.receiveShadow = true; scene.add(asph);
  const lm = new THREE.MeshBasicMaterial({ color: 0xf0f0e8 });
  for (let i = 0; i < 70; i++) { const d = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 2.5), lm); d.rotation.x = -Math.PI / 2; d.position.set(0, 0.04, -16 - i * 6); scene.add(d); }
  for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 400), lm); e.rotation.x = -Math.PI / 2; e.position.set(s * 4.1, 0.04, -214); scene.add(e); }
  const cars = [...Array(10)].map((_, i) => { const g = new THREE.Group(); const col = [0xd83a2a, 0x2a6ad8, 0xf0f0f0, 0x2a2a2a, 0xe8c040][i % 5]; const body = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.7, 4.2), new THREE.MeshStandardMaterial({ color: col, roughness: 0.35, metalness: 0.4 })); body.position.y = 0.6; g.add(body); const cab = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.55, 2.2), new THREE.MeshStandardMaterial({ color: 0x1a2a3a, roughness: 0.1, metalness: 0.6 })); cab.position.set(0, 1.2, -0.2); g.add(cab); scene.add(shadowAll(g)); return { g, i, lane: i % 2 ? 1 : -1 }; });
  scene.add(trees(ringSpots(70, 12, 110, 13).filter(p => Math.abs(p[0]) > 9), { seed: 3, scale: 1.3 }));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      cars.forEach(({ g, i, lane }) => { const sp = lane > 0 ? 14 : -12; const z = -40 - ((i * 37 + t * Math.abs(sp)) % 220); g.position.set(lane * 2.1, 0, lane > 0 ? z : -260 - z); g.rotation.y = lane > 0 ? 0 : Math.PI; });
      const k = easeInOut(range(t, 0, 4.8));
      place(c, [lerp(2, 6, k), lerp(2.5, 22, k), lerp(14, 26, k)], [0, lerp(1, 0, k), lerp(-10, -50, k)]);
      return { bloom: 0.55, flare: 1.0, warm: 1.2 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sLegion, 'legion'],
  [ls(2), ls(3), sTrench, 'trench'],
  [ls(3), ls(4), sLayers1, 'layers1'],
  [ls(4), ls(5), sLayers2, 'layers2'],
  [ls(5), ls(6), sRain, 'rain'],
  [ls(6), ls(7), sMile, 'mile'],
  [ls(7), ls(8), sMarch, 'march'],
  [ls(8), ls(9), sMap, 'map'],
  [ls(9), DURATION + 1, sModern, 'modern'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
