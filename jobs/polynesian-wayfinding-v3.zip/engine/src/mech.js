// Antikythera reel: toothed bronze gears, the mechanism (case, front zodiac dial with sun/moon pointers and moon-phase
// ball, back spiral dials + Olympiad dial, crank), corroded lump, 1901 sponge diver, amphoras, scan look, planets.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { romanBuilder, shadowAll, canvasTex } from './rome.js';
import { glowSprite } from './props.js';

let MM = null;
export function mechMats() {
  if (MM) return MM;
  MM = {
    bronze: new THREE.MeshPhysicalMaterial({ color: 0xc8904a, metalness: 0.9, roughness: 0.32, clearcoat: 0.3 }),
    bronzeDark: new THREE.MeshPhysicalMaterial({ color: 0x8a5a2a, metalness: 0.85, roughness: 0.45 }),
    corroded: new THREE.MeshStandardMaterial({ color: 0x4a7a5a, roughness: 0.95, metalness: 0.2, bumpMap: fabricTexture(37), bumpScale: 8, flatShading: true }),
    wood: new THREE.MeshStandardMaterial({ color: 0x6a4424, roughness: 0.75, bumpMap: fabricTexture(5), bumpScale: 2 }),
    xray: new THREE.MeshBasicMaterial({ color: 0x7fd8ff, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false }),
  };
  return MM;
}
// toothed gear in the XY plane (axis +z), radius r, n teeth, thickness d
export function gear(r = 0.1, n = 40, d = 0.006, mat = null, { spokes = 4 } = {}) {
  const sh = new THREE.Shape(); const td = Math.min(0.012, r * 0.08);
  for (let i = 0; i <= n * 4; i++) { const a = i / (n * 4) * Math.PI * 2; const ph = i % 4; const rr = ph === 1 || ph === 2 ? r : r - td; const x = Math.cos(a) * rr, y = Math.sin(a) * rr; i === 0 ? sh.moveTo(x, y) : sh.lineTo(x, y); }
  if (spokes && r > 0.03) { for (let s = 0; s < spokes; s++) { const a0 = s / spokes * Math.PI * 2 + 0.25, a1 = a0 + Math.PI * 2 / spokes - 0.5; const h = new THREE.Path(); h.absarc(0, 0, r * 0.78, a0, a1, false); h.absarc(0, 0, r * 0.28, a1, a0, true); sh.holes.push(h); } }
  const geo = new THREE.ExtrudeGeometry(sh, { depth: d, bevelEnabled: false, curveSegments: 4 }); geo.translate(0, 0, -d / 2);
  const m = new THREE.Mesh(geo, mat || mechMats().bronze); m.castShadow = m.receiveShadow = true;
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.12, r * 0.12, d * 2.5, 16), mechMats().bronzeDark); hub.rotation.x = Math.PI / 2; m.add(hub);
  m.userData.n = n; m.userData.r = r;
  return m;
}
// gear train: a few meshing gears placed so their pitch circles touch; spin(angle) turns them with correct ratios
export function gearTrain(spec = [[0.12, 60], [0.05, 25], [0.09, 45], [0.035, 18], [0.07, 35]], { z = 0 } = {}) {
  const g = new THREE.Group(); let x = 0, y = 0, dir = 0;
  const gears = spec.map(([r, n], i) => { const m = gear(r, n); if (i > 0) { const prev = spec[i - 1][0]; dir += (i % 2 ? 0.55 : -0.85); x += Math.cos(dir) * (prev + r - 0.004); y += Math.sin(dir) * (prev + r - 0.004); } m.position.set(x, y, z + (i % 2) * 0.008); g.add(m); return m; });
  g.spin = (a) => { let ang = a; gears.forEach((m, i) => { if (i > 0) ang = -ang * spec[i - 1][1] / spec[i][1]; m.rotation.z = ang + (i % 2 ? Math.PI / spec[i][1] : 0); }); };
  g.gears = gears;
  return g;
}
// the mechanism: wooden case (0.33 x 0.18 x 0.09), front dial with zodiac ring + pointers, back dials, crank on the side
export function mechanism() {
  const M = mechMats(); const g = new THREE.Group();
  const W = 0.32, H = 0.2, D = 0.09;
  const box = new THREE.Mesh(new THREE.BoxGeometry(W, H, D), M.wood); g.add(box);
  // front face plate with zodiac/calendar rings
  const ftex = canvasTex(256, 256, (x) => {
    x.fillStyle = '#b07a40'; x.fillRect(0, 0, 256, 256);
    x.strokeStyle = '#3a2410'; x.lineWidth = 2; for (const r of [118, 98, 78]) { x.beginPath(); x.arc(128, 128, r, 0, 7); x.stroke(); }
    for (let i = 0; i < 365; i += 5) { const a = i / 365 * Math.PI * 2; x.beginPath(); x.moveTo(128 + Math.cos(a) * 112, 128 + Math.sin(a) * 112); x.lineTo(128 + Math.cos(a) * 118, 128 + Math.sin(a) * 118); x.stroke(); }
    for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; x.beginPath(); x.moveTo(128 + Math.cos(a) * 78, 128 + Math.sin(a) * 78); x.lineTo(128 + Math.cos(a) * 98, 128 + Math.sin(a) * 98); x.stroke(); x.fillStyle = '#3a2410'; x.font = 'bold 11px serif'; x.fillText('ΑΒΓΔΕΖΗΘΙΚΛΜ'[i], 124 + Math.cos(a + 0.26) * 88, 132 + Math.sin(a + 0.26) * 88); }
  });
  const face = new THREE.Mesh(new THREE.CircleGeometry(H * 0.46, 64), new THREE.MeshStandardMaterial({ map: ftex, metalness: 0.6, roughness: 0.4 })); face.position.set(0, 0, D / 2 + 0.001); g.add(face);
  const sunP = new THREE.Mesh(new THREE.BoxGeometry(0.004, H * 0.42, 0.002), M.bronzeDark); sunP.geometry.translate(0, H * 0.21, 0); sunP.position.set(0, 0, D / 2 + 0.004); g.add(sunP);
  const sunB = new THREE.Mesh(new THREE.SphereGeometry(0.008, 16, 12), new THREE.MeshStandardMaterial({ color: 0xffd040, emissive: 0xffa000, emissiveIntensity: 0.8 })); sunB.position.y = H * 0.36; sunP.add(sunB);
  const moonP = new THREE.Mesh(new THREE.BoxGeometry(0.003, H * 0.32, 0.002), M.bronzeDark); moonP.geometry.translate(0, H * 0.16, 0); moonP.position.set(0, 0, D / 2 + 0.006); g.add(moonP);
  // moon-phase ball: half silver half black, turns with phase
  const ballG = new THREE.Group(); ballG.position.y = H * 0.28; moonP.add(ballG);
  const silver = new THREE.Mesh(new THREE.SphereGeometry(0.009, 16, 12, 0, Math.PI), new THREE.MeshStandardMaterial({ color: 0xe8ecf0, metalness: 0.8, roughness: 0.2 })); ballG.add(silver);
  const black = new THREE.Mesh(new THREE.SphereGeometry(0.009, 16, 12, Math.PI, Math.PI), new THREE.MeshStandardMaterial({ color: 0x1a1a1e, roughness: 0.5 })); ballG.add(black);
  // back face: two spiral dials (upper Metonic, lower Saros) + small Olympiad dial
  const btex = canvasTex(256, 384, (x) => {
    x.fillStyle = '#a87440'; x.fillRect(0, 0, 256, 384); x.strokeStyle = '#3a2410'; x.lineWidth = 2;
    for (const cy of [100, 280]) { x.beginPath(); for (let a = 0; a < Math.PI * 10; a += 0.05) { const r = 20 + a * 2.6; x.lineTo(128 + Math.cos(a) * r, cy + Math.sin(a) * r); } x.stroke(); }
    x.beginPath(); x.arc(70, 100, 18, 0, 7); x.stroke(); for (let i = 0; i < 4; i++) { const a = i / 4 * Math.PI * 2; x.beginPath(); x.moveTo(70, 100); x.lineTo(70 + Math.cos(a) * 18, 100 + Math.sin(a) * 18); x.stroke(); }
    x.font = 'bold 10px serif'; x.fillStyle = '#3a2410'; ['ΙΣΘΜΙΑ', 'ΟΛΥΜΠΙΑ', 'ΝΕΜΕΑ', 'ΠΥΘΙΑ'].forEach((w, i) => x.fillText(w, 50, 70 + i * 12 + (i > 1 ? 50 : 0)));
  });
  const back = new THREE.Mesh(new THREE.PlaneGeometry(W * 0.9, H * 0.95), new THREE.MeshStandardMaterial({ map: btex, metalness: 0.6, roughness: 0.4 })); back.rotation.y = Math.PI; back.position.z = -D / 2 - 0.001; g.add(back);
  const olymp = new THREE.Mesh(new THREE.BoxGeometry(0.002, 0.016, 0.002), M.bronzeDark); olymp.geometry.translate(0, 0.008, 0); olymp.position.set(W * 0.2, H * 0.24, -D / 2 - 0.003); g.add(olymp);
  // crank
  const crank = new THREE.Group(); crank.position.set(W / 2 + 0.004, 0, 0); g.add(crank);
  const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.02, 10), M.bronzeDark); axle.rotation.z = Math.PI / 2; axle.position.x = 0.01; crank.add(axle);
  const arm = new THREE.Mesh(new THREE.BoxGeometry(0.004, 0.05, 0.006), M.bronzeDark); arm.position.set(0.02, 0.025, 0); crank.add(arm);
  const knob = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.025, 10), M.wood); knob.rotation.z = Math.PI / 2; knob.position.set(0.032, 0.048, 0); crank.add(knob);
  // gears visible through a cut window on the top (optional reveal)
  const train = gearTrain([[0.06, 60], [0.025, 25], [0.045, 45], [0.018, 18], [0.035, 35]]); train.position.set(-0.05, 0.0, D / 2 - 0.01); train.visible = false; g.add(train);
  g.set = (turn) => { // turn: crank rotations
    crank.rotation.x = turn * Math.PI * 2;
    sunP.rotation.z = -turn * 0.08; moonP.rotation.z = -turn * 1.07;
    ballG.rotation.y = turn * 1.0 * Math.PI * 2 * 0.15; olymp.rotation.z = -turn * 0.02;
    train.spin(turn * 2);
  };
  g.train = train; g.face = face; g.ball = ballG; g.sunBall = sunB; g.D = D; g.W = W; g.H = H;
  g.set(0);
  return shadowAll(g);
}
// corroded lump: rough green rock with a few gear arcs showing
export function corrodedLump() {
  const M = mechMats(); const g = new THREE.Group(); const R = rng(4);
  const geo = new THREE.IcosahedronGeometry(0.1, 3); const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) { const k = 0.85 + R() * 0.3; p.setXYZ(i, p.getX(i) * k * 1.4, p.getY(i) * k * 0.55, p.getZ(i) * k); }
  geo.computeVertexNormals();
  g.add(new THREE.Mesh(geo, M.corroded));
  const arc = gear(0.07, 50, 0.004, new THREE.MeshStandardMaterial({ color: 0x5a8a6a, roughness: 0.8, metalness: 0.3 }), { spokes: 0 }); arc.rotation.x = -Math.PI / 2 + 0.3; arc.position.set(0.02, 0.045, 0); g.add(arc);
  return shadowAll(g);
}
// 1901 sponge diver: dark suit, big brass helmet
export function diver() {
  const h = romanBuilder({ color: 0x3a3a40, skin: 0xb07a5a });
  const brass = new THREE.MeshPhysicalMaterial({ color: 0xc8a050, metalness: 0.9, roughness: 0.3 });
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.21, 24, 18), brass); helm.position.y = 0.04; h.j.head.add(helm);
  const glass = new THREE.Mesh(new THREE.CircleGeometry(0.08, 20), new THREE.MeshStandardMaterial({ color: 0x1a2a30, roughness: 0.1, metalness: 0.5 })); glass.position.set(0, 0.04, 0.205); h.j.head.add(glass);
  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.26, 0.08, 24), brass); collar.position.y = 0.34; h.j.chest.add(collar);
  return shadowAll(h.root), h;
}
export function amphora(s = 1) {
  const pts = [[0, 0], [0.06, 0.02], [0.13, 0.15], [0.14, 0.3], [0.09, 0.45], [0.04, 0.52], [0.045, 0.6], [0.05, 0.62]].map(([x, y]) => new THREE.Vector2(x * s, y * s));
  const m = new THREE.Mesh(new THREE.LatheGeometry(pts, 20), new THREE.MeshStandardMaterial({ color: 0x9a5a3a, roughness: 0.9 })); m.castShadow = true; return m;
}
// planets: five small spheres on circles
export function planets() {
  const g = new THREE.Group(); const cols = [0xb8b8b8, 0xf0e0a0, 0xd85a3a, 0xe0b080, 0xd8c890];
  const P = cols.map((c, i) => { const r = 0.08 + i * 0.05; const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.0015, 4, 96), new THREE.MeshBasicMaterial({ color: 0xffd43b, transparent: true, opacity: 0.4 })); ring.rotation.x = Math.PI / 2; g.add(ring); const s = new THREE.Mesh(new THREE.SphereGeometry(0.012 + (i === 3) * 0.006, 16, 12), new THREE.MeshStandardMaterial({ color: c, emissive: c, emissiveIntensity: 0.3 })); g.add(s); return { s, r, w: 1.6 / (1 + i * 0.7) }; });
  const sun = new THREE.Mesh(new THREE.SphereGeometry(0.03, 20, 16), new THREE.MeshStandardMaterial({ color: 0xffd040, emissive: 0xffa000, emissiveIntensity: 1 })); g.add(sun);
  g.update = (t) => P.forEach(({ s, r, w }, i) => s.position.set(Math.cos(t * w + i) * r, 0, Math.sin(t * w + i) * r));
  return g;
}
