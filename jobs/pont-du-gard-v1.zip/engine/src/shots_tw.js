// Tower of the Winds reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, wpos, blinkK } from './shots4.js';
import { mountains, birds } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake, ikArm } from './anim.js';
import { archMats, shadowAll, canvasTex } from './rome.js';
import { greek, greekTemple } from './classic.js';
import { VO } from './vo_tw.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(9) + 1.5) * 24) / 24;

const CHUNKS = [
  [['This tower', 2], ['told *Athens*', 2], ['the *time*', 2], ['even on', 2], ['*cloudy days*', 2]],
  [["It's the", 2], ['*Tower of the Winds*', 4], ['built over', 2], ['*2,000 years*', 3], ['ago', 1]],
  [['It has', 2], ['*eight sides*', 2], ['each facing', 2], ['one of the', 3], ['*eight winds*', 2]],
  [['Up top', 2], ['each wind', 2], ['is carved', 2], ['as a *god*', 3], ['like *Boreas*', 2], ['the *cold north wind*', 4]],
  [['On the roof', 3], ['a bronze', 2], ['*Triton*', 1], ['turned in', 2], ['the *breeze*', 2], ['and pointed at', 3], ['whichever wind', 2], ['was *blowing*', 2]],
  [['Below the gods', 3], ['*sundials*', 1], ['showed the *hour*', 3], ['when the sun', 3], ['was out', 2]],
  [['And on', 2], ['*cloudy days*', 2], ['a *water clock*', 3], ['inside', 1], ['ran on water', 3], ['from a spring', 3], ['near the', 2], ['*Acropolis*', 1]],
  [['Its *height*', 2], ['let shoppers', 2], ['in the *market*', 3], ['below', 1], ['read it', 2], ['from *far away*', 3]],
  [['Many call it', 3], ["the world's first", 3], ['*weather station*', 2]],
  [['It still stands', 3], ['in *Athens* today', 3], ['but the', 2], ['*bronze Triton*', 2], ['is *long gone*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ---------- the tower ----------
let TT = null;
function towerTex() {
  if (TT) return TT;
  const R = (s => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296)(5);
  const wall = (bump) => canvasTex(256, 512, (x) => {
    x.fillStyle = bump ? '#606060' : '#e6dccb'; x.fillRect(0, 0, 256, 512);
    for (let i = 0; i < 600; i++) { const g = bump ? 80 + R() * 40 | 0 : 200 + R() * 40 | 0; x.fillStyle = `rgb(${g},${g - 4},${g - 12})`; x.fillRect(R() * 256, R() * 512, 2 + R() * 4, 1 + R() * 3); }
    // course lines
    x.fillStyle = bump ? '#404040' : '#cfc3ad'; for (let y = 40; y < 512; y += 46) x.fillRect(0, y, 256, 2);
    // sundial: hour lines fanning down from the gnomon point (upper part of the wall)
    x.strokeStyle = bump ? '#303030' : '#8a7a62'; x.lineWidth = 3; for (let k = -5; k <= 5; k++) { x.beginPath(); x.moveTo(128, 70); x.lineTo(128 + k * 22, 200); x.stroke(); }
    x.beginPath(); x.arc(128, 70, 128, 0.25 * Math.PI, 0.75 * Math.PI); x.stroke();
  });
  const frieze = (bump) => canvasTex(256, 128, (x) => {
    x.fillStyle = bump ? '#505050' : '#e2d8c6'; x.fillRect(0, 0, 256, 128);
    x.fillStyle = bump ? '#d0d0d0' : '#d6caae'; x.strokeStyle = x.fillStyle; x.lineCap = 'round';
    // a flying wind god: a clear human figure, body tilted forward, legs trailing, arms out, cloak billowing behind
    x.save(); x.translate(128, 70); x.rotate(-0.5); x.lineCap = 'round'; x.lineJoin = 'round';
    x.beginPath(); x.moveTo(-6, -30); x.quadraticCurveTo(-70, -80, -110, -40); x.quadraticCurveTo(-60, -40, -20, 10); x.fill();
    x.beginPath(); x.arc(0, -46, 13, 0, 7); x.fill();
    x.beginPath(); x.moveTo(-12, -32); x.lineTo(12, -32); x.lineTo(16, 18); x.lineTo(-16, 18); x.closePath(); x.fill();
    x.lineWidth = 9; x.beginPath(); x.moveTo(-8, 16); x.lineTo(-20, 52); x.lineTo(-34, 70); x.stroke(); x.beginPath(); x.moveTo(8, 16); x.lineTo(6, 54); x.lineTo(-4, 74); x.stroke();
    x.lineWidth = 8; x.beginPath(); x.moveTo(10, -26); x.lineTo(44, -40); x.lineTo(70, -36); x.stroke(); x.beginPath(); x.moveTo(-10, -24); x.lineTo(-36, -4); x.stroke();
    x.beginPath(); x.moveTo(66, -44); x.quadraticCurveTo(92, -40, 88, -22); x.lineTo(70, -30); x.fill();
    x.restore();
  });
  TT = { wall: wall(false), wallB: wall(true), fr: frieze(false), frB: frieze(true) };
  for (const k in TT) { TT[k].wrapS = THREE.RepeatWrapping; }
  return TT;
}
export function tritonVane() {
  const g = new THREE.Group(); const B = new THREE.MeshStandardMaterial({ color: 0x8a6a3a, metalness: 0.85, roughness: 0.35 });
  const tail = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([V(0, 0.95, 0), V(-0.1, 0.65, 0), V(-0.45, 0.5, 0), V(-0.8, 0.62, 0), V(-1.0, 0.85, 0)]), 24, 0.13, 12), B); g.add(tail);
  for (const s of [-1, 1]) { const fl = new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 8), B); fl.scale.set(0.35, 0.9, 0.12); fl.position.set(-1.05, 1.05, s * 0.1); fl.rotation.set(s * 0.6, 0, 0.5); g.add(fl); }
  const hips = new THREE.Mesh(new THREE.SphereGeometry(0.17, 14, 10), B); hips.position.set(0, 1.0, 0); g.add(hips);
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.15, 0.55, 16), B); torso.position.set(0, 1.3, 0); g.add(torso);
  const chest = new THREE.Mesh(new THREE.SphereGeometry(0.21, 14, 10), B); chest.scale.set(1, 0.7, 0.8); chest.position.set(0, 1.55, 0); g.add(chest);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.12, 14, 10), B); head.position.set(0.02, 1.8, 0); g.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.13, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), B); hair.position.set(-0.01, 1.82, 0); g.add(hair);
  const armF = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.045, 0.5, 8), B); armF.rotation.z = Math.PI / 2 - 0.5; armF.position.set(0.24, 1.48, 0.12); g.add(armF);
  const armB = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.045, 0.42, 8), B); armB.rotation.z = -0.4; armB.position.set(-0.16, 1.32, -0.14); g.add(armB);
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1.1, 6), B); rod.rotation.z = -0.9; rod.position.set(0.86, 1.28, 0.12); g.add(rod);
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.95, 8), B); pole.position.y = 0.47; g.add(pole);
  return shadowAll(g);
}
export function tower({ triton = true, worn = false } = {}) {
  const g = new THREE.Group(); const T = towerTex();
  const R = 4.1, H = 9.5, A = archMats();
  const marble = new THREE.MeshStandardMaterial({ color: 0xe8dfcc, roughness: 0.6 });
  for (let i = 0; i < 3; i++) { const s = new THREE.Mesh(new THREE.CylinderGeometry(R + 0.9 - i * 0.3, R + 0.9 - i * 0.3, 0.3, 8), marble); s.rotation.y = Math.PI / 8; s.position.y = 0.15 + i * 0.3; g.add(s); }
  const wm = new THREE.MeshStandardMaterial({ map: T.wall.clone(), bumpMap: T.wallB.clone(), bumpScale: 2, roughness: 0.75, color: worn ? 0xc8bca8 : 0xffffff }); wm.map.repeat.set(8, 1); wm.bumpMap.repeat.set(8, 1); wm.map.needsUpdate = wm.bumpMap.needsUpdate = true;
  const body = new THREE.Mesh(new THREE.CylinderGeometry(R, R, H, 8, 1, true), wm); body.rotation.y = Math.PI / 8; body.position.y = 0.9 + H / 2; g.add(body);
  const fm = new THREE.MeshStandardMaterial({ map: T.fr.clone(), bumpMap: T.frB.clone(), bumpScale: 5, roughness: 0.7, emissive: 0x6a5a40, emissiveIntensity: 0 }); fm.map.repeat.set(8, 1); fm.bumpMap.repeat.set(8, 1); fm.map.needsUpdate = fm.bumpMap.needsUpdate = true;
  const fr = new THREE.Mesh(new THREE.CylinderGeometry(R + 0.08, R + 0.08, 1.5, 8, 1, true), fm); fr.rotation.y = Math.PI / 8; fr.position.y = 0.9 + H - 0.9; g.add(fr); g.frieze = fm;
  const corn = new THREE.Mesh(new THREE.CylinderGeometry(R + 0.3, R + 0.2, 0.35, 8), marble); corn.rotation.y = Math.PI / 8; corn.position.y = 0.9 + H + 0.1; g.add(corn);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(R + 0.25, 2.2, 8), new THREE.MeshStandardMaterial({ color: 0xdcd2bf, roughness: 0.65, bumpMap: fabricTexture(31), bumpScale: 2 })); roof.rotation.y = Math.PI / 8; roof.position.y = 0.9 + H + 1.35; g.add(roof);
  // gnomons: one bronze rod sticking out of each face at the sundial origin
  const B = new THREE.MeshStandardMaterial({ color: 0x8a6a3a, metalness: 0.8, roughness: 0.4 });
  g.faces = [];
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; const n = V(Math.sin(a), 0, Math.cos(a)); const d = R * Math.cos(Math.PI / 8); const gn = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.6, 6), B); gn.position.copy(n.clone().multiplyScalar(d + 0.25)).add(V(0, 0.9 + H * 0.86, 0)); gn.lookAt(gn.position.clone().add(n.clone().add(V(0, -0.8, 0)))); gn.rotateX(Math.PI / 2); g.add(gn); g.faces.push({ a, n, d }); }
  // two porches (NE, NW) and the round annexe (S)
  for (const a of [Math.PI * 0.75, Math.PI * 1.25]) {
    const p = new THREE.Group(); p.rotation.y = a; g.add(p);
    for (const s of [-1, 1]) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.2, 3.2, 14), marble); c.position.set(s * 0.9, 2.5, R + 1.0); p.add(c); }
    const ent = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.4, 1.4), marble); ent.position.set(0, 4.3, R + 0.6); p.add(ent);
    const tri = new THREE.Shape(); tri.moveTo(-1.3, 0); tri.lineTo(1.3, 0); tri.lineTo(0, 0.7); tri.lineTo(-1.3, 0);
    const ped = new THREE.Mesh(new THREE.ExtrudeGeometry(tri, { depth: 1.4, bevelEnabled: false }), marble); ped.position.set(0, 4.5, R - 0.1); p.add(ped);
    const door = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 2.6), new THREE.MeshStandardMaterial({ color: 0x2a221a })); door.position.set(0, 2.2, R * Math.cos(Math.PI / 8) + 0.02); p.add(door);
  }
  const annex = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, 5.5, 24, 1, false, -Math.PI / 2, Math.PI), marble); annex.position.set(0, 3.65, -R - 0.6); annex.rotation.y = Math.PI; g.add(annex);
  if (triton) { const tv = tritonVane(); tv.position.y = 0.9 + H + 2.4; g.add(tv); g.triton = tv; }
  g.top = 0.9 + H;
  g.traverse(o => { if (o.isMesh) { o.castShadow = o.receiveShadow = true; } });
  return g;
}
function agora(makeStage, opts = {}, { modern = false } = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.55, 0.45, 0.7], fog: 0.0025, shadowSize: 14, envI: 0.95, cloud: 0.35, ...opts });
  const pave = new THREE.Mesh(new THREE.CircleGeometry(300, 48), new THREE.MeshStandardMaterial({ color: 0xc8b898, roughness: 0.95, bumpMap: fabricTexture(31), bumpScale: 3 })); pave.rotation.x = -Math.PI / 2; pave.receiveShadow = true; scene.add(pave);
  const acro = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x9a8a68, roughness: 1, bumpMap: fabricTexture(37), bumpScale: 6 })); acro.scale.set(60, 26, 34); acro.position.set(-20, 0, -110); acro.receiveShadow = true; scene.add(acro);
  const temple = greekTemple({ w: 14, d: 30, colH: 7 }); temple.position.set(-20, 26, -110); temple.rotation.y = 1.4; scene.add(temple);
  // colonnade of the agora
  const marble = new THREE.MeshStandardMaterial({ color: 0xe8dfcc, roughness: 0.6 });
  for (let i = 0; i < 14; i++) { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.35, 5, 14), marble); c.position.set(-30 + i * 4, 2.5, -22); c.castShadow = true; scene.add(c); }
  const beam = new THREE.Mesh(new THREE.BoxGeometry(56, 0.7, 1), marble); beam.position.set(-4, 5.3, -22); scene.add(beam);
  scene.add(mountains({ rMin: 180, rMax: 340, height: 40, seed: 3, color: 0x8a8a62 }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe0bc);
  const b = birds(3, { from: [-40, 24, -30], to: [40, 28, -50], spread: 6, speed: 0.04, scale: 1.6, seed: 2 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  return scene;
}
function crowd(scene, n, { modern = false, r0 = 9, r1 = 16 } = {}) {
  const R = (s => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296)(8);
  return [...Array(n)].map((_, i) => { const m = greek({ color: modern ? [0x2a5a9a, 0xd84a3a, 0x3a8a5a, 0xe8c040][i % 4] : [0xf2ede0, 0x8a3a2a, 0x3a5a7a, 0xc8a860][i % 4], beard: !modern && i % 2 === 0 }); const a = R() * 6.28, r = r0 + R() * (r1 - r0); m.root.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); m.root.rotation.y = -a - Math.PI / 2 + (R() - 0.5); scene.add(m.root); return m; });
}

// ============ S0 hook: up the tower under racing clouds to the Triton ============
function sHook({ makeStage }) {
  const scene = agora(makeStage, { cloud: 0.75, sunDir: [-0.4, 0.5, 0.77] });
  const tw = tower(); scene.add(tw);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      tw.triton.rotation.y = 0.6 + Math.sin(t * 0.9) * 0.4;
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(5, 5, k), lerp(1.6, 7, k), lerp(24, 20, k)], [0, lerp(7, 12, k), 0]);
      return { bloom: 0.5, warm: 1.0 };
    },
  };
}
function sWide({ makeStage }) {
  const scene = agora(makeStage);
  const tw = tower(); scene.add(tw);
  const folk = crowd(scene, 10);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((m, i) => { standPose(m, t + i, {}); m.setMood('happy'); });
      const a = lerp(0.9, 0.6, easeInOut(range(t, 0, 3.8)));
      place(c, [Math.sin(a) * 34, lerp(6, 9, range(t, 0, 3.8)), Math.cos(a) * 34], [-4, 8, -20]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S2: from above: the octagon on an 8-ray compass in the paving ============
function sOctagon({ makeStage }) {
  const scene = agora(makeStage);
  const tw = tower(); scene.add(tw);
  const rayM = new THREE.MeshStandardMaterial({ color: 0x8a6a4a, roughness: 0.9 });
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; const r = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.02, 9), rayM); r.position.set(Math.sin(a) * 10, 0.01, Math.cos(a) * 10); r.rotation.y = a; r.receiveShadow = true; scene.add(r); }
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      tw.triton.rotation.y = t * 0.6;
      const a = t * 0.18;
      place(c, [Math.sin(a) * 4, lerp(40, 34, range(t, 0, 3)), Math.cos(a) * 4 + 6], [0, 0, 0]);
      return { bloom: 0.5, warm: 1.15 };
    },
  };
}
// ============ S3: the frieze: Boreas glows, a cold wind blows streaks past ============
function sFrieze({ makeStage, start: ST }) {
  const tB = at(3, 'boreas') - ST;
  const scene = agora(makeStage, { sunDir: [-0.3, 0.55, 0.78] });
  const tw = tower(); scene.add(tw);
  const streaks = [...Array(40)].map((_, i) => { const m = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.012, 0.012), new THREE.MeshBasicMaterial({ color: 0xe8f4ff, transparent: true, opacity: 0 })); scene.add(m); return { m, i }; });
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      tw.frieze.emissiveIntensity = 0.6 * Math.sin(Math.PI * range(t, tB - 0.3, tB + 1.3));
      streaks.forEach(({ m, i }) => { const a = ((t * 0.8 + i / 40) % 1); m.position.set(-8 + a * 16, 8.6 + Math.sin(i * 2.1) * 1.4, 4.6 + Math.cos(i * 1.3) * 1.2); m.material.opacity = 0.5 * Math.sin(Math.PI * a) * easeOut(range(t, tB - 0.5, tB + 0.4)); });
      const a = lerp(0.35, -0.25, easeInOut(range(t, 0, 4.8)));
      const pos = [Math.sin(a) * 9.5, lerp(9.0, 9.3, range(t, 0, 4.8)), Math.cos(a) * 9.5], look = [0, 9.4, 0];
      place(c, pos, look);
      return { bloom: 0.5, warm: 1.1 };
    },
  };
}
// ============ S4: the bronze Triton swings and points ============
function sTriton({ makeStage, start: ST }) {
  const tB = at(4, 'blowing') - ST, tP = at(4, 'pointed') - ST;
  const scene = agora(makeStage, { cloud: 0.55, sunDir: [-0.5, 0.4, 0.77] });
  const tw = tower(); scene.add(tw);
  const leaves = [...Array(24)].map((_, i) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.08), new THREE.MeshStandardMaterial({ color: 0x8a9a3a, side: THREE.DoubleSide })); scene.add(m); return { m, i }; });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      tw.triton.rotation.y = kf(t, [[0, -1.2], [1.5, 0.6], [tP, 1.4], [tP + 0.6, 1.25], [6, 1.3]], easeInOut) + Math.sin(t * 7) * 0.03;
      leaves.forEach(({ m, i }) => { const a = ((t * 0.5 + i / 24) % 1); m.position.set(-6 + a * 12, 11.5 + Math.sin(i + t * 3) * 1.5, 2 + Math.cos(i * 2) * 3); m.rotation.set(t * 3 + i, t * 2, i); });
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(3.5, 4.5, k), lerp(11.5, 12.0, k), lerp(6.5, 5.5, k)], [0, lerp(12.0, 11.8, k), 0]);
      return { bloom: 0.55, flare: 0.9, warm: 1.2, dof: dofTo([4, 11.8, 6], [0, 12, 0], 0.003, 0.008) };
    },
  };
}
// ============ S5: a sundial: the gnomon's shadow sweeps across the hour lines ============
function sSundial({ makeStage, start: ST }) {
  const scene = agora(makeStage, { sunDir: [-0.5, 0.6, 0.62] });
  const tw = tower(); scene.add(tw);
  const f = tw.faces[0];
  const gp = f.n.clone().multiplyScalar(f.d + 0.012).add(V(0, 0.9 + 9.5 * 0.86, 0));
  const shade = new THREE.Mesh(new THREE.PlaneGeometry(0.05, 1.6), new THREE.MeshBasicMaterial({ color: 0x3a2e22, transparent: true, opacity: 0.55, depthWrite: false })); shade.geometry.translate(0, -0.8, 0); shade.position.copy(gp); scene.add(shade);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      shade.rotation.z = lerp(-0.75, 0.75, range(t, 0, 3.6));
      const pos = [gp.x + 0.6, gp.y - 0.8, gp.z + 4.4], look = [gp.x, gp.y - 1.0, gp.z];
      place(c, pos, look);
      return { bloom: 0.45, warm: 1.15 };
    },
  };
}
// ============ S6: inside: the water clock fills, a float lifts a pointer up the hour marks ============
function sWaterClock({ makeStage, start: ST }) {
  const scene = makeStage({ shadowSize: 1.5, sunDir: [-1, 2.5, 1.5], sun: 0.9, hemi: 0.25 });
  const u = scene.userData.sky.material.uniforms; u.top.value.set(0x2a241c); u.mid.value.set(0x3a3024); u.horizon.value.set(0x4a3e2e); u.floorC.value.set(0x2a241c);
  const marble = new THREE.MeshStandardMaterial({ color: 0xd8cfbc, roughness: 0.7 });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), marble); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(10, 6), new THREE.MeshStandardMaterial({ color: 0xc8bea8, roughness: 0.9, bumpMap: fabricTexture(31), bumpScale: 2 })); wall.position.set(0, 3, -1.2); scene.add(wall);
  const glass = new THREE.MeshPhysicalMaterial({ color: 0xe8e0d0, roughness: 0.3, transparent: true, opacity: 0.35, side: THREE.DoubleSide });
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 1.8, 32, 1, true), glass); tank.position.set(0, 1.1, -0.3); scene.add(tank);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.6, 0.2, 32), marble); base.position.set(0, 0.1, -0.3); scene.add(base);
  const water = new THREE.Mesh(new THREE.CylinderGeometry(0.43, 0.43, 1, 32), new THREE.MeshStandardMaterial({ color: 0x4a8aa8, roughness: 0.1, transparent: true, opacity: 0.75 })); scene.add(water);
  const fl = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.08, 24), new THREE.MeshStandardMaterial({ color: 0x8a6a3a, roughness: 0.7 })); scene.add(fl);
  const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 1.4, 8), new THREE.MeshStandardMaterial({ color: 0x8a6a3a, metalness: 0.8, roughness: 0.3 })); scene.add(rod);
  const ptr = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.16, 8), new THREE.MeshStandardMaterial({ color: 0xc8a050, metalness: 0.9, roughness: 0.3 })); ptr.rotation.z = -Math.PI / 2; scene.add(ptr);
  const board = new THREE.Mesh(new THREE.BoxGeometry(0.5, 2.4, 0.05), marble); board.position.set(0.95, 2.1, -0.3); scene.add(shadowAll(board));
  for (let i = 0; i < 12; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(i % 3 ? 0.18 : 0.32, 0.02, 0.02), new THREE.MeshStandardMaterial({ color: 0x3a2a1a })); m.position.set(0.82 + (i % 3 ? 0 : 0.07), 1.1 + i * 0.17, -0.27); scene.add(m); }
  const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.2, 10), new THREE.MeshStandardMaterial({ color: 0x8a6a3a, metalness: 0.7, roughness: 0.4 })); pipe.rotation.z = Math.PI / 2; pipe.position.set(-0.7, 2.4, -0.3); scene.add(pipe);
  const stream = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1, 8), new THREE.MeshStandardMaterial({ color: 0x8ac0e0, transparent: true, opacity: 0.7, roughness: 0.05 })); scene.add(stream);
  const lamp = new THREE.PointLight(0xffb070, 1.5, 5, 2); lamp.position.set(-1, 2.6, 0.8); scene.add(lamp);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      const lv = 0.25 + 1.3 * easeInOut(range(t, 0.2, 5.0));
      water.scale.y = lv; water.position.set(0, 0.2 + lv / 2, -0.3);
      fl.position.set(0, 0.2 + lv + 0.04, -0.3); rod.position.set(0, 0.2 + lv + 0.74, -0.3);
      ptr.position.set(0.7, 0.2 + lv + 1.3 - 0.4, -0.3);
      stream.position.set(-0.12, (2.4 + 0.2 + lv) / 2, -0.3); stream.scale.y = 2.4 - 0.2 - lv; stream.visible = true;
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(1.6, 1.2, k), lerp(1.9, 2.1, k), lerp(3.2, 2.6, k)], [0.3, lerp(1.5, 1.9, k), -0.3]);
      return { bloom: 0.5, warm: 1.3 };
    },
  };
}
// ============ S7: the market: people glance up at the tower ============
function sMarket({ makeStage }) {
  const scene = agora(makeStage, { sunDir: [-0.6, 0.38, 0.7] });
  const tw = tower(); tw.position.set(0, 0, -16); scene.add(tw);
  const folk = crowd(scene, 12, { r0: 2, r1: 8 });
  const A = archMats();
  for (let i = 0; i < 4; i++) { const st = new THREE.Mesh(new THREE.BoxGeometry(2, 0.9, 1), A.wood); st.position.set(-6 + i * 4, 0.45, 3); scene.add(shadowAll(st)); const aw = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.4), new THREE.MeshStandardMaterial({ color: [0xb83a2a, 0xe8d8a0, 0x3a6a8a, 0xc87a3a][i], side: THREE.DoubleSide })); aw.rotation.x = -1.2; aw.position.set(-6 + i * 4, 2.2, 3.2); scene.add(aw); }
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((m, i) => { standPose(m, t + i, { head: [i % 3 === 0 ? -0.5 : 0.1, 0, 0] }); m.setMood('happy'); });
      const k = easeInOut(range(t, 0, 3.6));
      place(c, [lerp(2, 0, k), lerp(1.7, 1.5, k), lerp(11, 12, k)], [0, lerp(3, 7.5, k), -12]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S8: weather station: clouds race, the vane spins, orbit ============
function sStation({ makeStage }) {
  const scene = agora(makeStage, { cloud: 0.6 });
  const tw = tower(); scene.add(tw);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      tw.triton.rotation.y = Math.sin(t * 1.4) * 1.6;
      const a = 1.5 + t * 0.3;
      place(c, [Math.sin(a) * 20, 7, Math.cos(a) * 20], [0, 8, 0]);
      return { bloom: 0.55, flare: 0.9, warm: 1.2 };
    },
  };
}
// ============ S9: today: worn tower, no Triton, tourists ============
function sToday({ makeStage }) {
  const scene = agora(makeStage, { sunDir: [-0.7, 0.3, 0.65] });
  const tw = tower({ triton: false, worn: true }); scene.add(tw);
  const folk = crowd(scene, 8, { modern: true, r0: 7, r1: 12 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      folk.forEach((m, i) => { standPose(m, t + i, { head: [-0.4, 0, 0] }); m.setMood('happy'); });
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(6, 14, k), lerp(14, 6, k), lerp(8, 26, k)], [0, lerp(12, 7, k), 0]);
      return { bloom: 0.6, flare: 1.1, warm: 1.3 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sWide, 'wide'],
  [ls(2), ls(3), sOctagon, 'octagon'],
  [ls(3), ls(4), sFrieze, 'frieze'],
  [ls(4), ls(5), sTriton, 'triton'],
  [ls(5), ls(6), sSundial, 'sundial'],
  [ls(6), ls(7), sWaterClock, 'waterclock'],
  [ls(7), ls(8), sMarket, 'market'],
  [ls(8), ls(9), sStation, 'station'],
  [ls(9), DURATION + 1, sToday, 'today'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
