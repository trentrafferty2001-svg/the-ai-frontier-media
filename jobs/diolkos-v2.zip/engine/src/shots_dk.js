// Diolkos reel: timeline, captions, props and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { mountains, trees, ringSpots, waterMaterial } from './world.js';
import { glowSprite } from './props.js';
import { fabricTexture } from './textures.js';
import { kf, lerp, easeOut, easeIn, easeInOut, range, clamp, V, cam, place, shake } from './anim.js';
import { shadowAll, romanBuilder, canvasTex } from './rome.js';
import { sea } from './norse.js';
import { galley } from './ancientkit.js';
import { VO } from './vo_dk.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(8) + 1.5) * 24) / 24;

const CHUNKS = [
  [['Ancient Greeks', 2], ['dragged *whole warships*', 3], ['across *dry land*', 3], ['on a *stone road*', 4]],
  [["It's the *Diolkos*", 3], ['across the *Isthmus*', 3], ['*of Corinth*', 2], ['built about', 2], ['*26 centuries* ago', 4]],
  [['The Isthmus is', 3], ['a *narrow neck*', 3], ['of land', 2], ['between *two seas*', 3]],
  [['Sailing around it', 3], ['meant a long', 3], ['*dangerous voyage*', 2], ['around *southern Greece*', 3]],
  [['So ships were pulled', 4], ['out of the water', 4], ['and set on', 3], ['a *wheeled cart*', 3]],
  [['*Teams* hauled them', 3], ['along a *limestone track*', 4], ['*6 to 8 kilometers*', 4], ['long', 1]],
  [['*Grooves*', 1], ['cut into the stone', 4], ['about *1.5 meters*', 6], ['apart', 1], ['kept the wheels', 3], ['*on course*', 2]],
  [['Historians call it', 3], ['one of the', 3], ["world's *first railways*", 3]],
  [['It worked for', 3], ['*over 600 years*', 4], ['and today', 2], ['the *Corinth Canal*', 3], ['runs right beside it', 4]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];
const R0 = (s) => () => ((s = Math.imul(s ^ (s >>> 15), 2246822519) ^ Math.imul(s ^ (s >>> 13), 3266489917)) >>> 0) / 4294967296;
const dofTo = (pos, look, ap = 0.003, mb = 0.01) => ({ focus: Math.hypot(pos[0] - look[0], pos[1] - look[1], pos[2] - look[2]), aperture: ap, maxblur: mb });

// ---------- props ----------
const wood = (c = 0x7a5232) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.85, bumpMap: fabricTexture(13), bumpScale: 2 });
let LS_ = null;
function limestone(rx = 1, ry = 1) {
  if (!LS_) { LS_ = canvasTex(256, 256, (x) => { const R = R0(8); x.fillStyle = '#b8ac94'; x.fillRect(0, 0, 256, 256); for (let r = 0; r < 4; r++) for (let c = 0; c < 2; c++) { const g = R(); x.fillStyle = `rgb(${210 + g * 20 | 0},${200 + g * 18 | 0},${178 + g * 16 | 0})`; x.fillRect(c * 128 + 3, r * 64 + 3, 122, 58); for (let k = 0; k < 60; k++) { x.fillStyle = 'rgba(120,100,70,0.12)'; x.fillRect(c * 128 + R() * 122, r * 64 + R() * 58, 3, 2); } } }); LS_.wrapS = LS_.wrapT = THREE.RepeatWrapping; }
  const t = LS_.clone(); t.needsUpdate = true; t.repeat.set(rx, ry); return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 3, roughness: 0.9 });
}
// the trackway along z: limestone slabs 5 m wide with two grooves 1.6 m apart
function track(len = 200, z0 = 10) {
  const g = new THREE.Group();
  const road = new THREE.Mesh(new THREE.BoxGeometry(5, 0.3, len), limestone(2, len / 2.5)); road.position.set(0, 0.15, z0 - len / 2); road.receiveShadow = true; g.add(road);
  const gm = new THREE.MeshStandardMaterial({ color: 0x6a604e, roughness: 1 });
  for (const x of [-0.8, 0.8]) { const gr = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.02, len), gm); gr.position.set(x, 0.305, z0 - len / 2); g.add(gr); }
  return g;
}
// the wheeled carrier (olkos): a timber deck with four wheels running in the grooves, and a cradle
function cart() {
  const W = wood(); const g = new THREE.Group();
  const deck = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.3, 9), W); deck.position.y = 0.95; g.add(deck);
  for (const z of [-3.6, 3.6]) { const ax = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.2, 0.3), W); ax.position.set(0, 0.62, z); g.add(ax); }
  g.wheels = [];
  for (const x of [-0.8, 0.8]) for (const z of [-3.6, 3.6]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.18, 20), wood(0x5a3a22)); w.rotation.z = Math.PI / 2; w.position.set(x, 0.8, z); g.add(w); g.wheels.push(w); const hub = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.9, 0.12), wood(0x4a2a16)); w.add(hub); }
  for (const z of [-2.5, 0, 2.5]) for (const s of [-1, 1]) { const cr = new THREE.Mesh(new THREE.BoxGeometry(0.25, 1.0, 0.25), W); cr.position.set(s * 1.0, 1.5, z); cr.rotation.z = s * -0.35; g.add(cr); }
  return shadowAll(g);
}
function ship() { const s = galley({ L: 14, sail: 0xe8dcc0 }); s.traverse(o => { if (o.isMesh && o.material && o.material.side === THREE.DoubleSide && o.geometry.type === 'ShapeGeometry') o.visible = false; }); return shadowAll(s); } // sail struck for the haul
function hauler(color) { return romanBuilder({ color }); }
const pull = (m, t, ph) => { const s = Math.sin(t * 4 + ph); standPose(m, t + ph, { spine: [0.45, 0, 0], lHip: [s * 0.4 - 0.2, 0, 0.06], rHip: [-s * 0.4 - 0.2, 0, -0.06], lKn: [Math.max(0, -s) * 0.5, 0, 0], rKn: [Math.max(0, s) * 0.5, 0, 0], lSh: [-1.2, 0, 0.25], rSh: [-1.2, 0, -0.25], lEl: [-0.2, 0, 0], rEl: [-0.2, 0, 0], head: [-0.2, 0, 0] }); m.setMood('happy'); };
function rope(mat, r = 0.03) { const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 1, 6), mat); m.set = (a, b) => { const d = b.clone().sub(a); m.position.copy(a).addScaledVector(d, 0.5); m.scale.set(1, Math.max(0.001, d.length()), 1); m.quaternion.setFromUnitVectors(V(0, 1, 0), d.normalize()); }; return m; }
function landStage(makeStage, opts = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.45, 0.66], fog: 0.004, shadowSize: 20, envI: 0.95, cloud: 0.3, ...opts });
  const ground = new THREE.Mesh(new THREE.CircleGeometry(400, 48), new THREE.MeshStandardMaterial({ color: 0xb8a878, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 3 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  scene.add(mountains({ rMin: 160, rMax: 320, height: 24, seed: 9, color: 0x8a9a62 }));
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe6c8);
  return scene;
}
// a hauling party: cart + ship + team on two ropes, moving along -z; returns an updater
function haul(scene, { team = 12, z0 = 0 } = {}) {
  const ct = cart(); scene.add(ct); const sh = ship(); sh.rotation.y = -Math.PI / 2; sh.position.y = 1.55; ct.add(sh);
  const men = [...Array(team)].map((_, i) => { const m = hauler([0xd8c7a2, 0x9a6a3a, 0xc8b890, 0xa8402c][i % 4]); m.root.rotation.y = Math.PI; scene.add(m.root); return { m, i }; });
  const rm = new THREE.MeshStandardMaterial({ color: 0xc8a870, roughness: 1 }); const ropes = [-1, 1].map(() => { const r = rope(rm); scene.add(r); return r; });
  return (t, speed = 1.0) => {
    const z = z0 - t * speed; ct.position.set(0, 0.3, z); ct.wheels.forEach(w => w.rotation.x = -t * speed / 0.5);
    men.forEach(({ m, i }) => { pull(m, t, i * 0.7); m.root.position.set((i % 2 ? 1 : -1) * 1.3, 0.3, z - 6.5 - Math.floor(i / 2) * 1.3); });
    ropes.forEach((r, j) => { const s = j ? 1 : -1; r.set(V(s * 0.9, 1.4, z - 4.5), V(s * 1.3, 1.2, z - 6.5 - Math.floor((team - 1) / 2) * 1.3)); });
    return z;
  };
}
// ---------- the isthmus at map scale (1 unit = 100 m): north mainland, south peninsula, a 6 km neck ----------
function landH(x, z) {
  const north = THREE.MathUtils.smoothstep(-z, 20, 26);
  const ex = x / 60, ez = (z - 78) / 50; const south = THREE.MathUtils.smoothstep(1 - (ex * ex + ez * ez) - 0.08 * Math.sin(x * 0.11) * Math.cos(z * 0.09), 0, 0.12);
  const neck = THREE.MathUtils.smoothstep(1 - Math.abs(x) / (26 + 3 * Math.sin(z * 0.3)), 0, 0.25) * THREE.MathUtils.smoothstep(1 - Math.abs(z) / 30, -0.1, 0.1);
  const land = Math.max(north, south, neck);
  return land * (3.2 + 6 * Math.max(0, Math.sin(x * 0.05) * Math.cos(z * 0.04)) + 0.8 * Math.sin(x * 0.3 + z * 0.2)) - (1 - land) * 4;
}
function isthmus(makeStage) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.5, 0.6, 0.62], fog: 0.0003, shadowSize: 200, envI: 1.0, cloud: 0.3 });
  fillLight(scene, [0.4, 0.6, 1], 0.6, 0xffe6c8);
  const geo = new THREE.PlaneGeometry(600, 600, 240, 240); geo.rotateX(-Math.PI / 2);
  const p = geo.attributes.position; const col = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), z = p.getZ(i); const h = landH(x, z); p.setY(i, h); const c = h < 1.2 ? [0.85, 0.78, 0.6] : h < 6 ? [0.62, 0.66, 0.38] : [0.55, 0.5, 0.38]; col.set(c, i * 3); }
  geo.computeVertexNormals(); geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const land = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 })); land.receiveShadow = false; land.castShadow = false; scene.add(land);
  const water = new THREE.Mesh(new THREE.PlaneGeometry(8000, 8000), new THREE.MeshStandardMaterial({ color: 0x2a6a8a, roughness: 0.25, metalness: 0.1 })); water.rotation.x = -Math.PI / 2; water.position.y = -1.5; scene.add(water);
  return scene;
}

// ============ S0 hook: a warship rolling over land, the team straining on the ropes ============
function sHook({ makeStage }) {
  const scene = landStage(makeStage);
  scene.add(track(260, 40));
  const step = haul(scene, { team: 12, z0: 6 });
  scene.add(trees(ringSpots(40, 12, 80, 5).filter(p => Math.abs(p[0]) > 7), { seed: 5, scale: 1.3 }));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const z = step(t, 1.0);
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(11, 13, k), lerp(1.6, 3.0, k), z + lerp(6, 2, k)], [0, lerp(2.4, 2.0, k), z + lerp(-3, -6, k)]);
      return { bloom: 0.5, flare: 1.1, warm: 1.25 };
    },
  };
}
// ============ S1: the isthmus from high above, the trackway across it ============
function trackLine(scene, y = 0.6) {
  const pts = []; for (let i = 0; i <= 40; i++) { const u = i / 40; const x = lerp(-30, 30, u); const z = Math.sin(u * Math.PI) * 3 - 1; pts.push(V(x, Math.max(0.3, landH(x, z)) + y, z)); }
  const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 160, 0.5, 6), new THREE.MeshStandardMaterial({ color: 0xf0e0b0, emissive: 0xc0a060, emissiveIntensity: 0.5 })); scene.add(m);
  return m;
}
function sAerial({ makeStage }) {
  const scene = isthmus(makeStage);
  const tl = trackLine(scene);
  const c = cam(44); c.far = 3000; c.updateProjectionMatrix();
  return {
    scene, camera: c,
    update(t) {
      tl.geometry.setDrawRange(0, Math.floor(160 * clamp(easeInOut(range(t, 0.4, 3.6)) + 0.01)) * 6 * 6);
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(30, 10, k), lerp(120, 240, k), lerp(110, 160, k)], [0, 0, lerp(0, 10, k)]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S2: the narrow neck between two seas ============
function sNeck({ makeStage }) {
  const scene = isthmus(makeStage);
  const tl = trackLine(scene);
  const c = cam(42); c.far = 3000; c.updateProjectionMatrix();
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.4));
      place(c, [lerp(-20, 0, k), lerp(150, 130, k), lerp(120, 100, k)], [0, 0, 0]);
      return { bloom: 0.5, warm: 1.2 };
    },
  };
}
// ============ S3: the long way round the peninsula, then the shortcut ============
function sRoute({ makeStage, start: ST }) {
  const scene = isthmus(makeStage);
  const pts = []; for (let i = 0; i <= 60; i++) { const a = Math.PI - i / 60 * Math.PI; const x = Math.cos(a) * 74, z = 78 + Math.sin(a) * 66; pts.push(V(x, 2, z)); }
  pts.unshift(V(-60, 2, 0), V(-74, 2, 30)); pts.push(V(74, 2, 30), V(60, 2, 0));
  const long = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 400, 1.6, 6), new THREE.MeshBasicMaterial({ color: 0xd83a2a })); scene.add(long);
  const boat = galley({ L: 14 }); boat.scale.setScalar(1.6); scene.add(boat);
  const c = cam(44); c.far = 3000; c.updateProjectionMatrix();
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0.3, 4.4)); long.geometry.setDrawRange(0, Math.floor(400 * clamp(k + 0.01)) * 6 * 6);
      const cv = long.geometry.parameters.path; const p = cv.getPointAt(clamp(k, 0, 1)), d = cv.getTangentAt(clamp(k, 0.001, 0.999)); boat.position.set(p.x, 0.3, p.z); boat.rotation.y = Math.atan2(-d.z, d.x);
      const kc = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(10, 20, kc), lerp(300, 360, kc), lerp(220, 260, kc)], [0, 0, lerp(55, 60, kc)]);
      return { bloom: 0.45, warm: 1.15 };
    },
  };
}
// ============ S4: a ship hauled up a slipway and set on the cart ============
function sSlip({ makeStage, start: ST }) {
  const tC = at(4, 'cart') - ST;
  const scene = landStage(makeStage, { sunDir: [-0.5, 0.5, 0.7] });
  sea(scene, { color: 0x2a6a8a }); const gr = scene.children.find(o => o.geometry && o.geometry.type === 'CircleGeometry'); if (gr) gr.position.set(0, 0.25, -220), gr.scale.setScalar(0.5);
  const land = new THREE.Mesh(new THREE.BoxGeometry(400, 2, 200), new THREE.MeshStandardMaterial({ color: 0xb8a878, roughness: 1 })); land.position.set(0, 0.0, -100 - 6); land.receiveShadow = true; scene.add(land);
  const ramp = new THREE.Mesh(new THREE.BoxGeometry(5, 0.3, 14), limestone(2, 5)); ramp.rotation.x = -0.14; ramp.position.set(0, 0.2, 0); scene.add(shadowAll(ramp));
  const trk = track(60, -6); trk.position.y = 0.85; scene.add(trk);
  
  const ct = cart(); ct.position.set(0, 1.15, -12); scene.add(ct);
  const sh = ship(); sh.rotation.y = -Math.PI / 2; scene.add(sh);
  const men = [...Array(8)].map((_, i) => { const m = hauler([0xd8c7a2, 0x9a6a3a, 0xc8b890, 0xa8402c][i % 4]); m.root.rotation.y = Math.PI; scene.add(m.root); return { m, i }; });
  const c = cam(42);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0.2, tC + 0.3));
      const z = lerp(10, -12, k); const y = z > -6 ? lerp(0.2, 1.4, clamp((10 - z) / 16)) : 2.7 * clamp((-6 - z) / 6) + 1.4 * (1 - clamp((-6 - z) / 6));
      sh.position.set(0, z > -6 ? y : lerp(1.4, 2.7, clamp((-6 - z) / 6)), z); sh.rotation.x = z > -6 ? 0.1 : 0;
      men.forEach(({ m, i }) => { pull(m, t, i * 0.7); m.root.position.set((i % 2 ? 1 : -1) * 1.3, 1.15, z - 9 - Math.floor(i / 2) * 1.3 - (k > 0.98 ? 0 : 0)); });
      const kc = easeInOut(range(t, 0, 4.8));
      place(c, [lerp(12, 10, kc), lerp(4, 5, kc), lerp(10, 2, kc)], [0, 1.5, lerp(4, -8, kc)]);
      return { bloom: 0.5, flare: 1.0, warm: 1.2 };
    },
  };
}
// ============ S5: the team hauls on, the track winding over the hills ============
function sTeam({ makeStage }) {
  const scene = landStage(makeStage);
  scene.add(track(300, 40));
  const step = haul(scene, { team: 16, z0: 10 });
  scene.add(trees(ringSpots(60, 12, 100, 8).filter(p => Math.abs(p[0]) > 7), { seed: 8, scale: 1.3 }));
  const c = cam(44);
  return {
    scene, camera: c,
    update(t) {
      const z = step(t, 1.0);
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(10, 6, k), lerp(14, 26, k), z + lerp(16, 30, k)], [0, 0, z - lerp(6, 30, k)]);
      return { bloom: 0.5, flare: 1.0, warm: 1.25 };
    },
  };
}
// ============ S6: close on the grooves; a wheel rolls in one; a 1.6 m gauge marker ============
function sGroove({ makeStage, start: ST }) {
  const tM = at(6, 'meters') - ST;
  const scene = landStage(makeStage, { shadowSize: 6 });
  scene.add(track(80, 20));
  const ct = cart(); scene.add(ct);
  const bar = new THREE.Group(); const bm = new THREE.MeshBasicMaterial({ color: 0xffd040 }); const b = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.04, 0.04), bm); bar.add(b); for (const x of [-0.8, 0.8]) { const tk = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.25, 0.04), bm); tk.position.x = x; bar.add(tk); } bar.position.set(0, 0.45, 0.6); scene.add(bar);
  const lab = (() => { const t = canvasTex(256, 128, (x) => { x.font = 'bold 72px sans-serif'; x.textAlign = 'center'; x.lineWidth = 10; x.strokeStyle = '#1a1208'; x.strokeText('1.5 m', 128, 90); x.fillStyle = '#ffd040'; x.fillText('1.5 m', 128, 90); }); const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false })); s.scale.set(0.6, 0.3, 1); s.renderOrder = 10; return s; })(); lab.position.set(0, 0.8, 0.6); scene.add(lab);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const z = lerp(-14, -4, easeOut(range(t, 0, 5))); ct.position.set(0, 0.3, z); ct.wheels.forEach(w => w.rotation.x = z / 0.5);
      const kb = easeOut(range(t, tM - 0.6, tM)); bar.scale.x = Math.max(0.01, kb); bar.visible = kb > 0; lab.visible = kb > 0.9;
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(1.6, 1.2, k), lerp(1.4, 1.9, k), lerp(4.6, 4.2, k)], [0, 0.3, lerp(0, -1, k)]);
      return { bloom: 0.5, warm: 1.2, dof: dofTo([1.4, 1.6, 4.4], [0, 0.3, 1.5], 0.003, 0.006) };
    },
  };
}
// ============ S7: low along the grooves like rails, the cart coming on ============
function sRails({ makeStage }) {
  const scene = landStage(makeStage, { sunDir: [-0.4, 0.3, -0.86] });
  scene.add(track(300, 20));
  const step = haul(scene, { team: 10, z0: 10 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      step(t, 1.2);
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [-0.8, lerp(0.45, 0.6, k), -34], [-0.8, lerp(0.4, 1.2, k), 20]);
      return { bloom: 0.6, flare: 1.2, warm: 1.3 };
    },
  };
}
// ============ S8: the Corinth Canal today, with the old trackway at its edge ============
function sCanal({ makeStage }) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [-0.6, 0.45, 0.66], fog: 0.003, shadowSize: 60, envI: 0.95, cloud: 0.3 });
  fillLight(scene, [0.5, 0.4, 1], 0.6, 0xffe6c8);
  const rockM = new THREE.MeshStandardMaterial({ color: 0xc8b48a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 5 });
  for (const s of [-1, 1]) { const w = new THREE.Mesh(new THREE.BoxGeometry(200, 60, 2400), rockM); w.position.set(s * (12 + 100), 10, -1000); w.receiveShadow = true; scene.add(w); const top = new THREE.Mesh(new THREE.BoxGeometry(200, 0.3, 2400), new THREE.MeshStandardMaterial({ color: 0x8a9a5a, roughness: 1 })); top.position.set(s * 112, 40.2, -1000); scene.add(top); }
  const water = new THREE.Mesh(new THREE.PlaneGeometry(24, 2400), waterMaterial({ color: 0x2a7a9a, opacity: 1, ripple: 0.8 })); water.rotation.x = -Math.PI / 2; water.position.set(0, -15, -1000); scene.add(water);
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(28, 1.2, 4), new THREE.MeshStandardMaterial({ color: 0x8a8a8a, roughness: 0.6 })); bridge.position.set(0, 39, -120); scene.add(shadowAll(bridge));
  const boat = new THREE.Group(); const hull = new THREE.Mesh(new THREE.BoxGeometry(6, 2, 22), new THREE.MeshStandardMaterial({ color: 0xf0f0f0, roughness: 0.4 })); hull.position.y = 1; boat.add(hull); const cab = new THREE.Mesh(new THREE.BoxGeometry(5, 3, 6), new THREE.MeshStandardMaterial({ color: 0x2a4a7a })); cab.position.set(0, 3.5, 4); boat.add(cab); boat.position.set(0, -15, -60); scene.add(shadowAll(boat));
  const trk = track(80, 0); trk.position.set(17, 40.2, -40); trk.rotation.y = 0.05; scene.add(trk);
  const c = cam(44); c.far = 3000; c.updateProjectionMatrix();
  return {
    scene, camera: c,
    update(t) {
      boat.position.z = -60 - t * 3;
      const k = easeInOut(range(t, 0, 5.4));
      place(c, [lerp(6, 10, k), lerp(62, 80, k), lerp(30, 50, k)], [lerp(4, 2, k), lerp(-5, -10, k), lerp(-70, -90, k)]);
      return { bloom: 0.55, flare: 1.0, warm: 1.25 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook, 'hook'],
  [ls(1), ls(2), sAerial, 'aerial'],
  [ls(2), ls(3), sNeck, 'neck'],
  [ls(3), ls(4), sRoute, 'route'],
  [ls(4), ls(5), sSlip, 'slip'],
  [ls(5), ls(6), sTeam, 'team'],
  [ls(6), ls(7), sGroove, 'groove'],
  [ls(7), ls(8), sRails, 'rails'],
  [ls(8), DURATION + 1, sCanal, 'canal'],
];
export const SHOTS = S.map(([s, e, build, id], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build, id }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
