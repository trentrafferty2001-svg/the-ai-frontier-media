// Persian windcatcher reel: timeline, captions and shots.
import * as THREE from 'three';
import { fillLight, standPose, blinkK } from './shots4.js';
import { birds } from './world.js';
import { glowSprite } from './props.js';
import { lerp, easeOut, easeIn, easeInOut, range, V, cam, place } from './anim.js';
import { desertGround, palm, persianWorker } from './persia.js';
import { gardenPool } from './qanat.js';
import { house, tower, thermometer, skyline, modernBuilding } from './windcatcher.js';
import { VO } from './vo_wc.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase() === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(13) + 1.5) * 24) / 24;

const CHUNKS = [
  [['In a *desert city*', 4], ['where summer hits', 3], ['*40 degrees*', 2], ['how do you', 3], ['*cool a house*', 3], ['with *no electricity?*', 3]],
  [['But in *Iran*', 3], ['people built *towers*', 3], ['that *catch the wind*', 4]],
  [["They're called", 2], ['*badgirs*', 1], ['or *windcatchers*', 2]],
  [['*Openings* at the top', 4], ['face the *breeze*', 3], ['high above', 2], ['the dusty streets', 3]],
  [['*Wind blows in*', 3], ['and walls', 2], ['inside the tower', 3], ['*push it down*', 3], ['into the house', 3]],
  [['On the other side', 4], ['*warm air* inside', 3], ['is drawn', 2], ['*up and out*', 3]],
  [['So the rooms below', 4], ['get a *steady breeze*', 4]],
  [['Some houses', 2], ['sent the air', 3], ['past a *cool pool*', 4], ['or over *water*', 3], ['from an *underground canal*', 4]],
  [['The water', 2], ['*cooled the air*', 3], ['even more', 2], ['before it reached', 3], ['the rooms', 2]],
  [['Some sources say', 3], ['windcatchers can', 2], ['*lower the temperature*', 3], ['inside', 1], ['by up to', 3], ['*10 degrees*', 2]],
  [['The city of *Yazd*', 4], ['is *famous*', 2], ['for its *skyline*', 3], ['of *windcatchers*', 2]],
  [['In the *Dowlat Abad*', 4], ['garden', 1], ['one tower rises', 3], ['about *33 meters*', 4]],
  [['Some *modern architects*', 3], ['*borrow the idea*', 3], ['to cool buildings', 3], ['without *air conditioning*', 3]],
  [['*Air conditioning*', 2], ['made from *wind*', 3], ['*height* and *water*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
const TB = ls(1);
export const FADES = [[TB - 0.32, TB - 0.18, TB - 0.1, TB + 0.04]];

function desert(makeStage, { preset = 'desert', sunDir = [-0.4, 0.7, 0.6], shadowSize = 20, seed = 2, fog = 0.003, half = false } = {}) {
  const scene = makeStage({ outdoor: preset, sunDir, fog, shadowSize, shadowAt: [0, 4, 0], envI: 0.9 });
  desertGround(scene, { seed, half });
  fillLight(scene, [0.3, 0.4, 1], 0.5, 0xffe6c8);
  return scene;
}
function cutStage(makeStage, { half = false } = {}) {
  const scene = desert(makeStage, { sunDir: [-0.3, 0.8, 0.6], shadowSize: 14, half });
  if (half) { const earth = new THREE.Mesh(new THREE.BoxGeometry(60, 6, 0.3), new THREE.MeshStandardMaterial({ color: 0x9a7048, roughness: 1 })); earth.position.set(0, -3.05, -0.3); scene.add(earth); }
  const H = house(); H.cut(1); scene.add(H);
  return { scene, H };
}
const streaks = (scene, n = 20) => [...Array(n)].map(() => { const s = new THREE.Mesh(new THREE.PlaneGeometry(2.5, 0.04), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false })); scene.add(s); return s; });
const blow = (S, t, y0 = 8, y1 = 14) => S.forEach((s, i) => { const u = (t * 0.5 + i / S.length) % 1; s.position.set(-12 + u * 20, y0 + ((i * 7) % 10) / 10 * (y1 - y0), -2 + (i % 5)); s.material.opacity = 0.45 * Math.sin(u * Math.PI); });

// ============ S0: a hot desert city at noon ============
function sHook({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [0.3, 0.9, -0.3], shadowSize: 60 });
  skyline(scene, { n: 34 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 5.8));
      place(c, [lerp(-10, -4, k), lerp(24, 18, k), lerp(34, 24, k)], [0, 4, -30]);
      return { bloom: 0.7, flare: 1.3, warm: 1.45 };
    },
  };
}
// ============ S1: towers that catch the wind ============
function sTower({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [0.5, 0.6, 0.6] });
  const H = house(); scene.add(H);
  const S = streaks(scene);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      blow(S, t, 9, 13);
      const k = easeInOut(range(t, 0, 3.4));
      place(c, [lerp(4, 3, k), lerp(1.6, 2.2, k), lerp(12, 10, k)], [-2.5, lerp(7, 9, k), 0]);
      return { bloom: 0.55, flare: 0.8, warm: 1.3 };
    },
  };
}
// ============ S2: badgirs: a row of towers in silhouette ============
function sRow({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.0, 0.2, -1], seed: 5 });
  [-10, -3, 4, 11].forEach((x, i) => { const h = house({ seed: i }); h.position.set(x * 1.4, 0, -6 - (i % 2) * 6); scene.add(h); });
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 2.6));
      place(c, [lerp(-2, 2, k), 3, 24], [0, 6, -8]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}
// ============ S3: the openings at the top face the breeze ============
function sTop({ makeStage }) {
  const scene = desert(makeStage, { sunDir: [0.5, 0.6, 0.6] });
  const H = house(); scene.add(H);
  const S = streaks(scene, 26);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      blow(S, t, 10.2, 12); H.flow(1, t, { inOnly: true });
      const k = easeInOut(range(t, 0, 4.3));
      place(c, [lerp(-6, -5, k), lerp(12.5, 12, k), lerp(6, 5, k)], [-2.5, 11.2, 0]);
      return { bloom: 0.6, warm: 1.25 };
    },
  };
}
// ============ S4/S5/S6: cut-away: down the tower; across the rooms; warm air up and out ============
function sDown({ makeStage }) {
  const { scene, H } = cutStage(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      H.flow(1, t, { inOnly: true });
      const y = lerp(10, 3, easeInOut(range(t, 0, 4.6)));
      place(c, [1.5, y + 1.5, 13], [-2.5, y, 0]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
function sOut({ makeStage }) {
  const { scene, H } = cutStage(makeStage);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      H.flow(1, t);
      const k = easeInOut(range(t, 0, 4));
      place(c, [lerp(0, 2, k), lerp(3, 5, k), lerp(14, 15, k)], [lerp(0, 2, k), lerp(2.5, 4, k), 0]);
      return { bloom: 0.6, warm: 1.2 };
    },
  };
}
function sRooms({ makeStage }) {
  const { scene, H } = cutStage(makeStage);
  const fam = [persianWorker(), persianWorker({ color: 0xc8b8e0, capC: 0xe8e0f0 })]; fam.forEach((e, i) => { e.root.position.set(-0.6 + i * 1.6, 0, 0.6); e.root.rotation.y = 0.2 - i * 0.5; scene.add(e.root); });
  const cloth = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.6, 6, 6), new THREE.MeshStandardMaterial({ color: 0xc83a3a, side: THREE.DoubleSide, roughness: 0.9 })); cloth.position.set(2.4, 2.6, -2.5); scene.add(cloth);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      H.flow(1, t);
      fam.forEach((e, i) => { standPose(e, t + i, { head: [0, 0.2 - i * 0.4, 0] }); e.setMood('happy'); e.setMouth(0); e.blink(blinkK(t + i, [1.0, 2.6])); });
      cloth.rotation.x = Math.sin(t * 4) * 0.25 - 0.2;
      const k = easeInOut(range(t, 0, 3.2));
      place(c, [lerp(0.8, 0.4, k), lerp(2.2, 2.0, k), lerp(9, 7.5, k)], [0.4, 1.6, 0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S7/S8: past a pool and over qanat water; the air cools further ============
function sQanat({ makeStage }) {
  const { scene, H } = cutStage(makeStage); H.qanat(true);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      H.flow(1, t, { viaQanat: true });
      const k = easeInOut(range(t, 0, 5.5));
      place(c, [lerp(-1, 1, k), lerp(2.5, 1.0, k), lerp(16, 13, k)], [lerp(-1, 0, k), lerp(1.5, -0.3, k), 0]);
      return { bloom: 0.6, warm: 1.1 };
    },
  };
}
function sCool({ makeStage }) {
  const { scene, H } = cutStage(makeStage, { half: true }); H.qanat(true);
  const c = cam(36);
  return {
    scene, camera: c,
    update(t) {
      H.flow(1, t, { viaQanat: true });
      place(c, [lerp(-2, 0, easeInOut(range(t, 0, 4))), 1.2, 9], [-0.5, -0.2, 0]);
      return { bloom: 0.65, warm: 1.05 };
    },
  };
}
// ============ S9: up to ten degrees cooler: thermometers outside vs inside ============
function sTherm({ makeStage, start: ST }) {
  const tD = at(9, 'ten') - ST;
  const { scene, H } = cutStage(makeStage);
  const out = thermometer(); out.position.set(4.5, 0, 4.4); out.scale.setScalar(1.4); scene.add(out);
  const ins = thermometer(); ins.position.set(2.5, 0, 2.0); ins.scale.setScalar(1.4); scene.add(ins);
  const c = cam(38);
  return {
    scene, camera: c,
    update(t) {
      H.flow(1, t); out.set(1); ins.set(lerp(1, 0.55, easeInOut(range(t, 0.4, tD + 0.4))));
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(3.8, 3.5, k), lerp(2.4, 2.1, k), lerp(14, 12.5, k)], [3.5, 1.5, 3.0]);
      return { bloom: 0.55, warm: 1.2 };
    },
  };
}
// ============ S10: Yazd's skyline of windcatchers ============
function sYazd({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.6, 0.25, -0.75], shadowSize: 70, seed: 7 });
  skyline(scene, { n: 46, r: 70, seed: 9 });
  const b = birds(4, { from: [-30, 26, -40], to: [30, 28, -50], spread: 5, speed: 0.06, scale: 2, seed: 3 }); scene.add(b); scene.userData.updaters.push((t) => b.update(t));
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.2));
      place(c, [lerp(-20, 0, k), lerp(16, 14, k), lerp(20, 18, k)], [lerp(-10, 6, k), 6, -40]);
      return { bloom: 0.7, flare: 1.1, warm: 1.35 };
    },
  };
}
// ============ S11: Dowlat Abad: a ~33 m octagonal tower over a garden pool ============
function sDowlat({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.6, 0.35, 0.7], shadowSize: 30, seed: 11 });
  const T = tower({ w: 4, y0: 0, y1: 33, oct: true }); T.position.set(0, 0, -14); scene.add(T);
  const base = new THREE.Mesh(new THREE.BoxGeometry(12, 6, 8), T.children[0].material); base.position.set(0, 3, -14); scene.add(base);
  const G = gardenPool(); G.scale.setScalar(1.4); G.position.set(0, 0, 0); scene.add(G);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      G.update(t);
      const k = easeInOut(range(t, 0, 5));
      place(c, [lerp(2, 1, k), lerp(1.8, 3, k), lerp(14, 16, k)], [0, lerp(6, 16, k), -12]);
      return { bloom: 0.6, flare: 0.9, warm: 1.3 };
    },
  };
}
// ============ S12: a modern building borrowing the idea ============
function sModern({ makeStage }) {
  const scene = makeStage({ outdoor: 'day', sunDir: [-0.5, 0.6, 0.6], fog: 0.003, shadowSize: 30, envI: 0.95 });
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), new THREE.MeshStandardMaterial({ color: 0xc8c0b0, roughness: 0.9 })); ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);
  const M = modernBuilding(); scene.add(M);
  [[-12, 8, 6], [12, 8, 6]].forEach(([x, z, h], i) => { const p = palm(h, i + 9); p.position.set(x, 0, z); scene.add(p); });
  const S = streaks(scene);
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      blow(S, t, 18, 23);
      const k = easeInOut(range(t, 0, 4.6));
      place(c, [lerp(-14, -8, k), lerp(4, 6, k), lerp(34, 30, k)], [0, lerp(10, 13, k), 0]);
      return { bloom: 0.55, warm: 1.1 };
    },
  };
}
// ============ S13: sunset skyline ============
function sEnd({ makeStage }) {
  const scene = desert(makeStage, { preset: 'golden', sunDir: [0.75, 0.1, -0.6], shadowSize: 70, seed: 13 });
  skyline(scene, { n: 40, r: 60, seed: 11 });
  const c = cam(40);
  return {
    scene, camera: c,
    update(t) {
      const k = easeInOut(range(t, 0, 4.5));
      place(c, [lerp(0, -8, k), lerp(10, 22, k), lerp(16, 26, k)], [0, 6, -30]);
      return { bloom: 0.75, flare: 1.2, warm: 1.4 };
    },
  };
}

// ============ timeline ============
const S = [
  [0, ls(1), sHook], [ls(1), ls(2), sTower], [ls(2), ls(3), sRow], [ls(3), ls(4), sTop], [ls(4), ls(5), sDown],
  [ls(5), ls(6), sOut], [ls(6), ls(7), sRooms], [ls(7), ls(8), sQanat], [ls(8), ls(9), sCool], [ls(9), ls(10), sTherm],
  [ls(10), ls(11), sYazd], [ls(11), ls(12), sDowlat], [ls(12), ls(13), sModern], [ls(13), DURATION + 1, sEnd],
];
export const SHOTS = S.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
