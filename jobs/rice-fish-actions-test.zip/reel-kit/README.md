# Explainer reel kit

Everything behind **rice-fish-farming-v6-1080p-heart-voice** except the large downloads: the 3D engine and assets, the voice script, and the render, mix and assembly scripts. Restore it in a fresh Claude workspace to make new videos with the same look and voice.

## What's inside

| Path | What |
|---|---|
| `ricefish/` | The engine project: `index.html` + `src/main.js` (renderer, colour grade, captions, whip cuts, lens flare) and `render.mjs` (headless Chrome → frames → ffmpeg). |
| `ricefish/src/world.js` | Sky with sun and clouds, lighting and reflections from that sky, fields that mirror the sky, mountains, trees, hillside terraces, mist, birds, rippling water. |
| `ricefish/src/farm2.js` | Wind-swaying rice clumps with grain heads, koi-style carp, the farmer (fingers, work clothes, blinks), slow-motion splash. |
| `ricefish/src/uw.js` | Underwater world (surface seen from below, god rays, particles, bubbles) and rice stems with roots. |
| `ricefish/src/cutaway.js` | Soil cutaway: trench dug by a shovel, rising walls, water, bamboo inlet pipe. |
| `ricefish/src/props60.js` | Village houses, acacias, pesticide cans, fertiliser sacks, rice basket, cap, mud clouds. |
| `ricefish/src/shots60.js` | The 60 s rice-fish timeline, the example to copy (older shots in `shots4.js`). `main.js` imports it. |
| `ricefish/src/vo60.js`, `timeline60.js` | Word timings and block layout for that example. |
| `tts/kokoro_say.py` | Kokoro v1.0 text-to-speech on onnxruntime: one wav per sentence + word timings. Defaults to the Heart voice. |
| `tts/lines_all.json` | The rice-fish script, one sentence per entry. |
| `make_audio60.py` | Voice + music ducked under it + sound effects. The sound effects are timed to the rice-fish words; adapt them per video. |
| `render1080.sh` | Renders timeline blocks at native 1080×1920 into near-lossless masters. |
| `assemble1080.sh` | Joins the masters, encodes once, adds each soundtrack at -14 LUFS. |
| `r60/plan60.py` | Example of laying out a timeline from the voice timings. |

## Restore (paths assume /home/claude)

```bash
mkdir -p /home/claude/kit && cd /home/claude/kit && unzip -o <path to explainer-reel-kit.zip> && cp -R reel-kit/. /home/claude/
# three.js r169: only the folders the engine imports
mkdir -p /home/claude/deps && cd /home/claude/deps
git clone --depth 1 --branch r169 --filter=blob:none --sparse https://github.com/mrdoob/three.js.git three
cd three && git sparse-checkout set build examples/jsm/postprocessing examples/jsm/shaders examples/jsm/utils examples/jsm/geometries
# link the packages (Playwright and its Chromium are preinstalled globally)
mkdir -p /home/claude/ricefish/node_modules
ln -sfn /home/claude/deps/three /home/claude/ricefish/node_modules/three
cd /home/claude/ricefish && ln -sfn "$(npm root -g)/playwright" node_modules/playwright
# voice model, about 350 MB
cd /home/claude/tts && curl -sSL -o k.tar.bz2 https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-multi-lang-v1_0.tar.bz2 && tar xjf k.tar.bz2 && rm k.tar.bz2
# smoke test: one still of the rice-fish video
cd /home/claude/ricefish && node render.mjs stills 1.0 /home/claude/smoke
```

## Default look and voice

- Native 1080×1920 at 24 fps (`RES=1080`); canvas textures drawn at 2×; no animated grain.
- Voice: Kokoro v1.0 `af_heart` ("Heart") at speed 1.0.
- Captions: Poppins Bold, thick black outline, yellow keywords (`*word*` in a caption chunk), pop-in, 1–3 words, 60% of the way down the frame.
- Music ducked to 40% under the voice; final loudness -14 LUFS. Also export a copy without music.

## Making a new video

1. Script: about 2.4 words a second (60 s ≈ 145 words). Check every fact first.
2. Voice: `cd /home/claude/tts && python3 -I kokoro_say.py kokoro-multi-lang-v1_0 lines.json vo_new` writes `vo_new/lineNN.wav` and `vo_new/timing.json`. Write numbers and acronyms as words ("twelve hundred", "U N"); the script stops and names any word missing from its dictionary.
3. Lay the sentences on a timeline with ~0.3 s gaps, cutting on sentence starts, and write the word list as `src/vo_new.js` in the same shape as `vo60.js`.
4. Copy `shots60.js` to `src/shots_new.js`: caption chunks, one function per shot, the `SHOTS` list with start and end times; key actions to `at(line, 'word')`. Point the import at the top of `src/main.js` at it. `update(t)` must depend only on `t`.
5. Stills: `node render.mjs stills 1.2,4.0,7.5 /home/claude/stills_new` (720p by default; prefix `RES=1080` for final checks). Look at every shot.
6. Render in parts that finish within 2 hours: `PARTS=/home/claude/ricefish/parts_new bash /home/claude/render1080.sh "b1 0 96" "b2 96 210"` (frame numbers at 24 fps; block edges on cuts). Re-running skips finished blocks.
7. Sound: adapt `make_audio60.py` (it reads a plan JSON of `blocks` and `place` entries like `r60/plan60.py` writes; add `nomusic` for the copy without music).
8. Assemble: `BLOCKS="b1 b2" PARTS=/home/claude/ricefish/parts_new bash /home/claude/assemble1080.sh /home/claude/new.mp4 mix.wav /home/claude/new-no-music.mp4 mix_nomusic.wav`
9. Pull frames from the final file at word times to check the captions are in sync before sending.

## Workspace notes (November 2026)

- GitHub works; the npm registry and PyPI don't. Don't run the original engine's `install.sh` or downloaded binaries: the safety check blocks them.
- 2 CPU cores and software WebGL: roughly 10–20 s per 1080p frame, so a 60 s video renders in about 4–4.5 hours.
- Stop a stuck render by its process ID, not with `pkill -f` (the pattern can match your own shell).

## Credits and licences

- Engine based on [claude-animation-skills](https://github.com/artemnovitckii/claude-animation-skills) by Artem Novitckii, MIT licence: `ricefish/LICENSE-claude-animation-skills.txt`. Not affiliated with Zack D. Films.
- Poppins font, SIL Open Font Licence: `ricefish/fonts/OFL-poppins.txt`.
- three.js (MIT) and the Kokoro voice model (Apache 2.0) are downloaded at setup, not included.
