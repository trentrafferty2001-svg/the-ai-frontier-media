#!/bin/bash
# Render timeline blocks at native 1080x1920 into near-lossless masters (24 fps).
# usage: [ENGINE=/home/claude/ricefish] [PARTS=/home/claude/ricefish/parts1080] bash render1080.sh "id firstFrame endFrame" ...
#   e.g. bash render1080.sh "b1 0 96" "b2 96 210"
# A block is skipped when PARTS/id.done exists, so a part can be re-run after an interruption.
# Background commands stop after 2 hours: give each run only as many blocks as finish in ~100 minutes
# (about 10-20 s per frame here).
cd "${ENGINE:-/home/claude/ricefish}" || exit 1
mkdir -p "${PARTS:-parts1080}"
P=$(cd "${PARTS:-parts1080}" && pwd)
export RES=1080 CRF=10 PRESET=fast
for spec in "$@"; do
  set -- $spec
  [ -s "$P/$1.done" ] && continue
  from=$(python3 -c "print($2/24)"); to=$(python3 -c "print($3/24 + 0.0001)")
  if node render.mjs video "$P/$1.mp4" 24 $from $to > "$P/$1.log" 2>&1; then
    echo ok > "$P/$1.done"; echo "block $1 done $(date +%T)" >> "$P/progress.log"
  else
    echo "block $1 FAILED $(date +%T)" >> "$P/progress.log"
  fi
done
echo "PARTDONE $(date +%T)" >> "$P/progress.log"
