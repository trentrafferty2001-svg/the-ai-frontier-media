#!/bin/bash
# Join the 1080p masters in order (no re-encode), encode the picture once, then attach each soundtrack at -14 LUFS.
# usage: BLOCKS="b1 b2 b3" [PARTS=/home/claude/ricefish/parts1080] bash assemble1080.sh out1.mp4 mix1.wav [out2.mp4 mix2.wav ...]
set -e
[ -n "$BLOCKS" ] || { echo "set BLOCKS to the block ids in timeline order"; exit 1; }
P=$(cd "${PARTS:-/home/claude/ricefish/parts1080}" && pwd)
: > "$P/list.txt"
for b in $BLOCKS; do echo "file '$P/$b.mp4'" >> "$P/list.txt"; done
ffmpeg -v error -y -f concat -safe 0 -i "$P/list.txt" -c copy "$P/master.mp4"
echo "frames: $(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "$P/master.mp4")"
ffmpeg -v error -y -i "$P/master.mp4" -c:v libx264 -preset slow -crf 15 -profile:v high -pix_fmt yuv420p -movflags +faststart "$P/video.mp4"
while [ $# -ge 2 ]; do
  out="$1"; mix="$2"; shift 2
  M=$(ffmpeg -nostats -i "$mix" -af loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | python3 -c "import sys,json; t=sys.stdin.read(); j=json.loads(t[t.rindex('{'):t.rindex('}')+1]); print(f\"measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:measured_thresh={j['input_thresh']}:offset={j['target_offset']}\")")
  ffmpeg -v error -y -i "$P/video.mp4" -i "$mix" -map 0:v -map 1:a -c:v copy -af "apad,loudnorm=I=-14:TP=-1.5:LRA=11:$M:linear=true" -ar 44100 -c:a aac -b:a 192k -shortest -movflags +faststart "$out"
  echo "$out $(ffprobe -v error -show_entries format=duration -of csv=p=0 "$out")"
done
