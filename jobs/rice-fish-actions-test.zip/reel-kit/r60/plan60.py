"""Build the 60 s timeline: reused v4 segments + new blocks, frame exact at 24 fps.
Writes src/vo60.js (word timings, timeline order), src/timeline60.js (blocks) and r60/plan60.json (audio + assembly)."""
import json
FPS = 24
old = json.load(open('/home/claude/tts/placement.json'))           # L0..L7, global word times in the v4 edit
new = json.load(open('/home/claude/tts/vo60/timing.json'))         # N0..N6, word times relative to each clip
OLD_N0 = {1: 0, 2: 101, 3: 212, 4: 308, 5: 373, 6: 442, 7: 540, 8: 618}   # first frame of each v4 segment
OLD_LEN = {1: 100, 2: 111, 3: 96, 4: 65, 5: 68, 6: 98, 7: 78, 8: 85}       # s8 trimmed (no end hold)
GAP = 7
# timeline: ('seg', k, line) reuse v4 segment k for old line; ('new', name, n) new block for new line n
order = [('seg', 1, 0), ('seg', 2, 1), ('new', 'A', 0), ('new', 'H', 1), ('seg', 3, 2), ('seg', 4, 3), ('seg', 5, 4),
         ('new', 'B', 2), ('seg', 6, 5), ('new', 'C', 3), ('new', 'D', 4), ('seg', 7, 6), ('new', 'E', 5), ('seg', 8, 7), ('new', 'F', 6)]
total = 60 * FPS
fixed = sum(OLD_LEN[k] for kind, k, _ in order if kind == 'seg')
speech = {n: new[n]['words'][-1][2] - new[n]['words'][0][1] for n in range(7)}
lens = {}
for kind, name, n in order:
    if kind == 'new' and name != 'F':
        lens[name] = int(-(-((0.10 + speech[n]) * FPS) // 1)) + GAP
lens['F'] = total - fixed - sum(lens.values())
blocks, f, vo, place = [], 0, [], []
for kind, k, n in order:
    L = OLD_LEN[k] if kind == 'seg' else lens[k]
    start = f / FPS
    if kind == 'seg':
        line = old[n]
        off = line['words'][0][1] - OLD_N0[k] / FPS                   # speech start inside the segment
        shift = start + off - line['words'][0][1]
        words = [[w, round(a + shift, 3), round(b + shift, 3)] for w, a, b in line['words']]
        clip = line['clip_offset'] + shift
        wav = '/home/claude/tts/' + line['wav']
        blocks.append({'kind': 'seg', 'id': f's{k}', 'f0': f, 'f1': f + L, 'old_f0': OLD_N0[k], 'line': len(vo)})
    else:
        r = new[n]
        s0 = start + 0.10
        words = [[w, round(a - r['words'][0][1] + s0, 3), round(b - r['words'][0][1] + s0, 3)] for w, a, b in r['words']]
        clip = s0 - r['words'][0][1]
        wav = '/home/claude/tts/' + r['wav']
        blocks.append({'kind': 'new', 'id': k, 'f0': f, 'f1': f + L, 'line': len(vo)})
    vo.append({'start': words[0][1], 'words': words})
    place.append({'wav': wav, 'clip_offset': round(clip, 4), 'words': words})
    f += L
assert f == total, f
open('/home/claude/ricefish/src/vo60.js', 'w').write('export const VO = ' + json.dumps(vo) + ';\n')
open('/home/claude/ricefish/src/timeline60.js', 'w').write('export const BLOCKS = ' + json.dumps(blocks) + ';\n')
json.dump({'blocks': blocks, 'place': place}, open('/home/claude/r60/plan60.json', 'w'), indent=1)
for b in blocks:
    print(f"{b['id']:>3} {b['f0']/FPS:6.3f}-{b['f1']/FPS:6.3f} ({(b['f1']-b['f0'])/FPS:.2f}s)  line {b['line']}: {' '.join(w[0] for w in vo[b['line']]['words'])[:60]}")
