"""v3 sound: Kokoro voiceover + music ducked under the voice + sound effects on the new, voice-driven timeline.
usage: python3 -I make_audio3.py placement.json out.wav"""
import json, sys
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly

SR = 44100
DUR = 60.0
N = int(SR * DUR)
rng = np.random.default_rng(7)
plan = json.load(open(sys.argv[1]))
place = plan['place']
blocks = plan['blocks']
W = {}  # word -> list of global start times
for li, l in enumerate(place):
    for w, a, b in l['words']:
        W.setdefault((li, w.lower()), []).append((a, b))
at = lambda li, w, k=0: W[(li, w)][k][0]

def track():
    return np.zeros(N)

def add(buf, sig, t):
    i = int(round(t * SR))
    if i < 0:
        sig = sig[-i:]; i = 0
    j = min(N, i + len(sig))
    if i < N and j > i:
        buf[i:j] += sig[: j - i]

def env(n, a=0.005, d=0.4):
    t = np.arange(n) / SR
    return np.minimum(1, t / a) * np.exp(-t / d)

def pluck(f, dur=0.5, vol=0.12):
    n = int(dur * SR); t = np.arange(n) / SR
    s = np.sin(2 * np.pi * f * t) + 0.35 * np.sin(4 * np.pi * f * t) + 0.12 * np.sin(6 * np.pi * f * t)
    return s * env(n, 0.004, dur / 3) * vol

def pad(f, dur, vol=0.04):
    n = int(dur * SR); t = np.arange(n) / SR
    s = sum(np.sin(2 * np.pi * f * k * t + k) / k for k in (1, 2, 3)) + 0.5 * np.sin(2 * np.pi * f * 1.005 * t)
    e = np.minimum(1, t / 0.8) * np.minimum(1, (dur - t) / 0.8)
    return s * e * vol

def noise_burst(dur, lo, hi, vol, a=0.01, d=0.15):
    n = int(dur * SR)
    x = rng.standard_normal(n)
    X = np.fft.rfft(x); fr = np.fft.rfftfreq(n, 1 / SR)
    X[(fr < lo) | (fr > hi)] = 0
    x = np.fft.irfft(X, n); x /= np.abs(x).max() + 1e-9
    return x * env(n, a, d) * vol

def whoosh(vol=0.18, dur=0.45):
    n = int(dur * SR); t = np.arange(n) / SR
    x = rng.standard_normal(n)
    y = np.zeros(n); k = 0.0
    cut = 0.02 + 0.5 * (t / dur) ** 2
    for i in range(n):
        k += cut[i] * (x[i] - k); y[i] = k
    y /= np.abs(y).max() + 1e-9
    return y * np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2 * vol

def splash(vol=0.3):
    return noise_burst(0.6, 600, 7000, vol, 0.002, 0.12) + noise_burst(0.6, 80, 400, vol * 0.6, 0.002, 0.08)

def pop(vol=0.3, f0=900):
    n = int(0.12 * SR); t = np.arange(n) / SR
    f = f0 * np.exp(-t * 25) + 200
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, 0.001, 0.03) * vol

def chime(f, vol=0.06):
    return pluck(f, 0.9, vol)


# ---------------- voice ----------------
vo = track()
for l in place:
    sr, x = wavfile.read(l['wav'])
    x = x.astype(np.float32) / 32768
    x = resample_poly(x, SR, sr) if sr != SR else x
    add(vo, x, l['clip_offset'])
speech = np.abs(vo) > 0.01
vo *= 0.16 / (np.sqrt(np.mean(vo[speech] ** 2)) + 1e-9)
lvl = np.abs(vo)
duck = np.zeros(N); a_att, a_rel = np.exp(-1 / (0.03 * SR)), np.exp(-1 / (0.35 * SR))
acc = 0.0
for i in range(0, N, 64):
    v = lvl[i:i + 64].max() if i < N else 0
    acc = v + (acc - v) * (a_att ** 64 if v > acc else a_rel ** 64)
    duck[i:i + 64] = acc
duck = 1.0 - 0.6 * np.clip(duck / 0.08, 0, 1)

# ---------------- music ----------------
mus = track()
scale = [293.66, 329.63, 369.99, 440.0, 493.88, 587.33, 659.25]
beat = 60 / 100 / 2
pattern = [0, 3, 5, 3, 1, 4, 6, 4, 2, 4, 5, 3, 0, 3, 4, 2]
t = 0.0; i = 0
while t < DUR - 1.2:
    if not (3.9 < t < 4.2):
        add(mus, pluck(scale[pattern[i % len(pattern)]], 0.45, 0.06 if t < 4.17 else 0.085), t)
    t += beat; i += 1
roots = [146.83, 123.47, 98.0, 110.0]
for b, t0 in enumerate(np.arange(4.17, DUR, 4.8)):
    add(mus, pad(roots[b % 4] / 2, min(5.2, DUR - t0), 0.05), t0)
add(mus, pad(146.83 / 2, 4.0, 0.03), 0.0)
add(mus, pad(146.83 / 2, 2.5, 0.05), DUR - 2.6)      # resolve on the tonic at the end
mus *= duck
if len(sys.argv) > 3 and sys.argv[3] == 'nomusic':
    mus *= 0.0

# ---------------- effects ----------------
sfx = track()
W = {}
for li, l in enumerate(place):
    for w, a, b in l['words']:
        W.setdefault((li, w.lower()), []).append(a)
at = lambda li, w, k=0: W[(li, w)][k]
# reused v4 segments: map an old global time into the new edit
OLD_F0 = {'s1': 0, 's2': 101, 's3': 212, 's4': 308, 's5': 373, 's6': 442, 's7': 540, 's8': 618}
NEW_F0 = {b['id']: b['f0'] for b in blocks}
m = lambda seg, t_old: t_old - OLD_F0[seg] / 24 + NEW_F0[seg] / 24
cuts = [b['f0'] / 24 for b in blocks[1:]] + [m('s1', 2.17), m('s1', 2.75), at(14, 'is') - 0.06]
for c in cuts:
    add(sfx, whoosh(0.13), c - 0.25)
# hook (s1)
add(sfx, noise_burst(1.0, 60, 300, 0.18, 0.3, 0.4), 1.3)
add(sfx, splash(0.45), 1.61)
add(sfx, pluck(220, 0.5, 0.1), 2.19)
add(sfx, noise_burst(0.25, 150, 1500, 0.12, 0.002, 0.05), at(0, 'crop') + 0.05)
add(sfx, noise_burst(1.2, 40, 200, 0.25, 0.005, 0.5), 4.15)            # boom on the turn
# H swoop
add(sfx, whoosh(0.2, 0.9), NEW_F0['H'] / 24 + 0.2)
# s3 dig, s4 walls + flood, s5 release, s6 mechanism, s8 harvest (old shot-local timings)
for k in range(1, 5): add(sfx, noise_burst(0.25, 200, 2500, 0.1, 0.003, 0.05), m('s3', 8.85 + (k + 0.25) / 2.2))
add(sfx, noise_burst(0.8, 300, 3000, 0.05, 0.1, 0.4), at(4, 'so'))
add(sfx, noise_burst(0.5, 40, 180, 0.15, 0.01, 0.2), at(5, 'raise'))
add(sfx, noise_burst(1.6, 200, 3000, 0.06, 0.4, 0.9), at(5, 'flood'))
TT = at(6, 'release') + 0.05
for i in range(6): add(sfx, splash(0.1), TT + i * 0.18 + 0.65)
# B: water swish while the carp swims
add(sfx, noise_burst(3.2, 80, 700, 0.05, 0.6, 1.4), NEW_F0['B'] / 24 + 0.1)
add(sfx, noise_burst(0.3, 100, 900, 0.1, 0.003, 0.06), at(8, 'weeds'))
add(sfx, pop(0.25), at(8, 'pests') + 0.25)
for i in range(6): add(sfx, pop(0.06, 600), at(8, 'waste') + i * 0.16 + 0.4)
for k, f in enumerate([587.33, 739.99, 880.0]): add(sfx, chime(f, 0.035), at(8, 'feeds') + k * 0.12)
# C: bump, bugs plop, snap
add(sfx, noise_burst(0.35, 50, 250, 0.2, 0.004, 0.12), at(9, 'bump'))
for i in range(4): add(sfx, pop(0.09, 1300), at(9, 'knocking') - 0.12 + i * 0.1 + 0.3)
add(sfx, pop(0.25), at(9, 'water'))
# D: mud rumble and oxygen bubbles
add(sfx, noise_burst(2.0, 40, 220, 0.16, 0.2, 0.9), at(10, 'stir') - 0.15)
for i in range(18): add(sfx, pop(0.05, 1500 + (i % 5) * 300), at(10, 'oxygen') - 0.35 + i * 0.09 + 0.25)
# E: cans and a sack vanish
for k in range(7): add(sfx, pop(0.16, 700 + k * 60), at(12, 'pesticide') - 0.18 + k * 0.06 + 0.08)
add(sfx, pop(0.22, 450), at(12, 'fertilizer') - 0.05 + 0.08)
add(sfx, chime(880.0, 0.04), at(12, 'rice'))
# harvest sparkle and the ending
for k, f in enumerate([1174.7, 1318.5, 1480.0, 1760.0]): add(sfx, chime(f, 0.05), at(13, 'two') + k * 0.08)
for k, f in enumerate([587.33, 880.0, 1174.7]): add(sfx, chime(f, 0.045), at(14, 'africa') + k * 0.1)

mix = vo + mus + sfx
mix /= max(1.0, np.abs(mix).max() / 0.95)
wavfile.write(sys.argv[2], SR, (mix * 32767).astype(np.int16))
print('ok', len(mix) / SR)
