// Inca terraces reel: stone-wall terraces stepping up a hill (amphitheatre arcs), cut-away of one terrace's layers
// (big stones, gravel + sand, topsoil, crops), Moray's circular sunken terraces, rain + drainage particles, steep slope.
import * as THREE from 'three';
import { rng, fabricTexture } from './textures.js';
import { shadowAll, canvasTex } from './rome.js';
import { mountains } from './world.js';

let IM = null;
export function incaMats() {
  if (IM) return IM;
  const stones = canvasTex(256, 128, (x) => { x.fillStyle = '#6a6458'; x.fillRect(0, 0, 256, 128); const R = rng(4); for (let row = 0; row < 6; row++) for (let i = 0; i < 9; i++) { const w = 22 + R() * 14, h = 16 + R() * 6; const px = i * 29 + (row % 2) * 14 + R() * 4, py = row * 21 + R() * 3; const c = 120 + R() * 50; x.fillStyle = `rgb(${c},${c - 6},${c - 18})`; x.beginPath(); x.ellipse(px, py + 10, w / 2, h / 2, 0, 0, 7); x.fill(); } }, [8, 1]);
  const crops = canvasTex(128, 128, (x) => { x.fillStyle = '#4a7a2a'; x.fillRect(0, 0, 128, 128); const R = rng(8); for (let i = 0; i < 220; i++) { x.fillStyle = `rgba(${60 + R() * 60},${120 + R() * 70},${30 + R() * 30},0.9)`; x.beginPath(); x.arc(R() * 128, R() * 128, 2 + R() * 3, 0, 7); x.fill(); } }, [10, 2]);
  IM = {
    wall: new THREE.MeshStandardMaterial({ map: stones, roughness: 0.95, bumpMap: stones, bumpScale: 4 }),
    top: new THREE.MeshStandardMaterial({ map: crops, roughness: 0.9 }),
    soil: new THREE.MeshStandardMaterial({ color: 0x4a3420, roughness: 1, bumpMap: fabricTexture(9), bumpScale: 3 }),
    sand: new THREE.MeshStandardMaterial({ color: 0xb89a6a, roughness: 1, bumpMap: fabricTexture(13), bumpScale: 3 }),
    big: new THREE.MeshStandardMaterial({ color: 0x7a7468, roughness: 0.95, flatShading: true }),
    slope: new THREE.MeshStandardMaterial({ color: 0x6a7a4a, roughness: 1, bumpMap: fabricTexture(23), bumpScale: 5 }),
    rock: new THREE.MeshStandardMaterial({ color: 0x8a8274, roughness: 1, flatShading: true }),
  };
  return IM;
}
// terraced hill: level i at radius r0 - i*step, height i*rise, over angles thFrom..thTo (around the y axis)
export function terracedHill({ levels = 12, r0 = 40, step = 2.6, rise = 1.6, thFrom = -1.0, thTo = 1.0, build = 1 } = {}) {
  const M = incaMats(); const g = new THREE.Group(); const lv = [];
  for (let i = 0; i < levels; i++) {
    const L = new THREE.Group(); g.add(L); lv.push(L);
    const r = r0 - i * step, y = i * rise;
    const wall = new THREE.Mesh(new THREE.CylinderGeometry(r, r, rise, 64, 1, true, thFrom, thTo - thFrom), M.wall); wall.position.y = y + rise / 2; L.add(wall);
    const top = new THREE.Mesh(new THREE.RingGeometry(r - step, r, 64, 1, thFrom - Math.PI / 2, thTo - thFrom), M.top); top.rotation.x = -Math.PI / 2; top.position.y = y + rise; L.add(top);
  }
  const core = new THREE.Mesh(new THREE.ConeGeometry(r0 - levels * step + 2, 10, 32), M.slope); core.position.y = levels * rise + 5; g.add(core);
  g.build = (k) => lv.forEach((L, i) => { L.visible = k * levels > i; });
  g.build(build);
  return shadowAll(g);
}
// Moray: circular terraces sinking into a bowl
export function moray({ levels = 9, r0 = 30, step = 2.4, rise = 1.4 } = {}) {
  const M = incaMats(); const g = new THREE.Group();
  for (let i = 0; i < levels; i++) {
    const r = r0 - i * step, y = -i * rise;
    const wall = new THREE.Mesh(new THREE.CylinderGeometry(r, r, rise, 72, 1, true), M.wall); wall.material.side = THREE.DoubleSide; wall.position.y = y - rise / 2; g.add(wall);
    const top = new THREE.Mesh(new THREE.RingGeometry(r - step, r, 72), M.top); top.rotation.x = -Math.PI / 2; top.position.y = y - rise; g.add(top);
  }
  const rim = new THREE.Mesh(new THREE.RingGeometry(r0, r0 + 380, 72), M.slope); rim.rotation.x = -Math.PI / 2; g.add(rim);
  return shadowAll(g);
}
// cut-away of one terrace: wall at x=0 facing +x... (front face toward +z). layers(k) reveals 0..4: stones, gravel/sand, soil, crops
export function terraceSection() {
  const M = incaMats(); const g = new THREE.Group();
  const lower = new THREE.Mesh(new THREE.BoxGeometry(4, 0.3, 3), M.top); lower.position.set(2.0, 0.15, 0); g.add(lower);
  const wall = new THREE.Mesh(new THREE.BoxGeometry(0.6, 3.2, 3), M.wall); wall.position.set(0, 1.6, 0); g.add(wall);
  const W = 4, D = 3;
  const big = new THREE.Group(); g.add(big); const R = rng(5);
  for (let i = 0; i < 40; i++) { const s = new THREE.Mesh(new THREE.DodecahedronGeometry(0.22 + R() * 0.12, 0), M.big); s.position.set(-0.5 - R() * (W - 0.8), 0.25 + R() * 0.6, (R() - 0.5) * (D - 0.4)); s.rotation.set(R() * 3, R() * 3, 0); big.add(s); }
  const gravel = new THREE.Mesh(new THREE.BoxGeometry(W - 0.3, 0.9, D), M.sand); gravel.position.set(-W / 2 - 0.15, 1.55, 0); g.add(gravel);
  const soil = new THREE.Mesh(new THREE.BoxGeometry(W - 0.3, 0.9, D), M.soil); soil.position.set(-W / 2 - 0.15, 2.45, 0); g.add(soil);
  const plants = new THREE.Group(); g.add(plants);
  for (let i = 0; i < 24; i++) { const p = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.6, 6), new THREE.MeshStandardMaterial({ color: 0x5a9a2a })); p.position.set(-0.5 - (i % 6) * 0.6, 3.2, -1.1 + Math.floor(i / 6) * 0.7); plants.add(p); }
  const back = new THREE.Mesh(new THREE.BoxGeometry(W + 4, 6, 0.2), M.slope); back.position.set(0, 1.5, -D / 2 - 0.1); g.add(back);
  g.setLayers = (k) => { big.visible = k > 0; gravel.visible = k > 1; soil.visible = k > 2; plants.visible = k > 3; gravel.scale.y = Math.max(0.01, Math.min(1, k - 1)); gravel.position.y = 0.95 + 0.45 * gravel.scale.y + 0.15 * (1 - gravel.scale.y); soil.scale.y = Math.max(0.01, Math.min(1, k - 2)); soil.position.y = 2.0 + 0.45 * soil.scale.y; };
  g.setLayers(4);
  return shadowAll(g);
}
// steep bare mountainside (for the hook)
export function steepSlope(seed = 3) {
  const M = incaMats(); const g = new THREE.Group(); const R = rng(seed);
  const geo = new THREE.PlaneGeometry(80, 80, 40, 40); const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); p.setZ(i, y * 0.9 + Math.sin(x * 0.3) * 1.5 + Math.sin(x * 0.9 + y * 0.4) * 0.6); }
  geo.computeVertexNormals();
  const m = new THREE.Mesh(geo, M.slope); m.rotation.x = -Math.PI / 2; g.add(m);
  for (let i = 0; i < 30; i++) { const r = new THREE.Mesh(new THREE.DodecahedronGeometry(0.5 + R() * 1.2, 0), M.rock); const x = (R() - 0.5) * 60, y = (R() - 0.5) * 60; r.position.set(x, y * 0.9 + 0.3, -y); g.add(r); }
  return shadowAll(g);
}
