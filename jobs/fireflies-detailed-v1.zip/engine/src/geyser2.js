// detail kit for geysers: terraced sinter mound with mineral colours, hot pools, boardwalk railings, pine forest,
// rough steam puffs, layered rock cutaway
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as Y from './geyser.js';
export { steam, PIPE, std } from './geyser.js';
function cv(w, h, f, rep = true) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; if (rep) t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
// lathe uv: u around, v from rim (0) to top (1) after reverse(); rings of sinter terraces, tan-orange outer mats
const sinterTex = () => cv(512, 1024, (g, w, h) => { const gr = g.createLinearGradient(0, h, 0, 0); gr.addColorStop(0, '#8a6a3a'); gr.addColorStop(0.25, '#c88a3a'); gr.addColorStop(0.45, '#d8b878'); gr.addColorStop(0.75, '#e8e0d0'); gr.addColorStop(1, '#f2eee6'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  const R = rnd(5); for (let y = 0; y < h; y += 14 + R() * 18) { g.strokeStyle = `rgba(${120 + R() * 40 | 0},${90 + R() * 30 | 0},${60 + R() * 20 | 0},0.45)`; g.lineWidth = 2 + R() * 2; g.beginPath(); g.moveTo(0, y); for (let x = 0; x <= w; x += 16) g.lineTo(x, y + Math.sin(x * 0.05 + y) * 4); g.stroke(); }
  for (let i = 0; i < 4000; i++) { g.fillStyle = R() < 0.5 ? 'rgba(255,255,255,0.25)' : 'rgba(120,100,70,0.2)'; g.fillRect(R() * w, R() * h, 2, 2); } });
export function mound() {
  const g = Y.mound(); const st = tx('sinter', sinterTex);
  g.children[0].material = new THREE.MeshStandardMaterial({ map: st, bumpMap: st, bumpScale: 2, roughness: 0.9, side: THREE.DoubleSide });
  // glassy vent water with a pale-blue to deep-blue gradient
  const vt = cv(256, 256, (c, w, h) => { const gr = c.createRadialGradient(128, 128, 0, 128, 128, 128); gr.addColorStop(0, '#0a3a6a'); gr.addColorStop(0.6, '#2a8ab8'); gr.addColorStop(0.85, '#7ad0d8'); gr.addColorStop(1, '#d8c070'); c.fillStyle = gr; c.fillRect(0, 0, w, h); }, false);
  g.children[1].material = new THREE.MeshPhysicalMaterial({ map: vt, roughness: 0.05, clearcoat: 1, emissive: 0x0a3a5a, emissiveIntensity: 0.3 });
  return g;
}
// steaming hot pools around the geyser: blue centre, green-yellow-orange rings (bacterial mats)
export function pools(scene, R) {
  const pt = cv(256, 256, (c, w, h) => { const gr = c.createRadialGradient(128, 128, 0, 128, 128, 128); [[0, '#0a4a8a'], [0.45, '#2aa0c8'], [0.6, '#8ad0a0'], [0.72, '#e8d050'], [0.85, '#e8822a'], [0.95, '#a85a2a'], [1, 'rgba(168,90,42,0)']].forEach(([s, col]) => gr.addColorStop(s, col)); c.fillStyle = gr; c.fillRect(0, 0, w, h); }, false);
  const pm = new THREE.MeshPhysicalMaterial({ map: pt, transparent: true, roughness: 0.1, clearcoat: 1 });
  [[24, -10, 9], [-26, -6, 7], [10, -34, 11], [-14, 26, 6], [30, 18, 5]].forEach(([x, z, r]) => { const p = new THREE.Mesh(new THREE.CircleGeometry(r, 48), pm); p.rotation.x = -Math.PI / 2; p.position.set(x, 0.06, z); scene.add(p); });
}
// pines: stacked cones with a needle texture
export function pines(spots, { seed = 9, scale = 4 } = {}) {
  const G = new THREE.Group(); const R = rnd(seed);
  const nt = cv(128, 128, (c, w, h) => { c.fillStyle = '#2a4a2a'; c.fillRect(0, 0, w, h); for (let i = 0; i < 900; i++) { c.strokeStyle = `rgba(${40 + R() * 40 | 0},${90 + R() * 50 | 0},${40 + R() * 30 | 0},0.8)`; c.lineWidth = 1.2; const x = R() * w, y = R() * h; c.beginPath(); c.moveTo(x, y); c.lineTo(x + (R() - 0.5) * 8, y + 6); c.stroke(); } }); nt.repeat.set(3, 2);
  const nm = new THREE.MeshStandardMaterial({ map: nt, roughness: 0.9 }), bm = new THREE.MeshStandardMaterial({ color: 0x5a3a24, roughness: 0.95 });
  const cg = new THREE.ConeGeometry(1, 1.6, 10, 1, true); const tg = new THREE.CylinderGeometry(0.12, 0.18, 1, 6);
  const nC = spots.length * 4; const cones = new THREE.InstancedMesh(cg, nm, nC), trunks = new THREE.InstancedMesh(tg, bm, spots.length); const M = new THREE.Matrix4(), q = new THREE.Quaternion(), c = new THREE.Color(); let k = 0;
  spots.forEach(([x, y, z], i) => { const s = scale * (0.7 + R() * 0.6); M.compose(new THREE.Vector3(x, y + s * 0.6, z), q, new THREE.Vector3(s, s * 1.2, s)); trunks.setMatrixAt(i, M);
    for (let j = 0; j < 4; j++) { const r = s * (1.1 - j * 0.24); M.compose(new THREE.Vector3(x, y + s * (1.1 + j * 0.85), z), q, new THREE.Vector3(r, s, r)); cones.setMatrixAt(k, M); cones.setColorAt(k, c.setHSL(0.3 + R() * 0.05, 0.3, 0.55 + R() * 0.25)); k++; } });
  G.add(cones, trunks); return G;
}
export function people(n, seed) {
  const P = Y.people(n, seed); const wt = cv(256, 64, (c, w, h) => { c.fillStyle = '#8a6a4a'; c.fillRect(0, 0, w, h); for (let x = 0; x < w; x += 16) { c.fillStyle = 'rgba(50,30,16,0.8)'; c.fillRect(x, 0, 2, h); } }); wt.repeat.set(10, 1);
  const walk = P.children[0]; walk.material = new THREE.MeshStandardMaterial({ map: wt, roughness: 0.85 });
  const rm = new THREE.MeshStandardMaterial({ color: 0x6a4a2e, roughness: 0.8 });
  [-1, 1].forEach(s => { const rail = new THREE.Mesh(new THREE.BoxGeometry(34, 0.08, 0.08), rm); rail.position.set(0, 1.6, 18 + s * 1.05); P.add(rail); for (let x = -17; x <= 17; x += 2) { const post = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.0, 0.1), rm); post.position.set(x, 1.1, 18 + s * 1.05); P.add(post); } });
  return P;
}
export function column(seed) {
  const C = Y.column(seed); const geo = new THREE.IcosahedronGeometry(1, 4); const p = geo.attributes.position, nm = geo.attributes.normal, v = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) { v.fromBufferAttribute(p, i); const d = v.clone().normalize(); const n = 1 + 0.07 * Math.sin(d.x * 5 + d.y * 3) * Math.sin(d.z * 4 - d.y * 2) + 0.03 * Math.sin(d.x * 13 + d.z * 11); p.setXYZ(i, d.x * n, d.y * n, d.z * n); nm.setXYZ(i, d.x, d.y, d.z); }
  const mats = [0xffffff, 0xeef2f6, 0xdfe6ee].map(c => new THREE.MeshStandardMaterial({ color: c, roughness: 1, transparent: true, opacity: 0.85 }));
  const sm0 = C.group.children.find(o => o.isMesh && o.geometry.type === 'IcosahedronGeometry')?.material; let i = 0;
  C.group.children.forEach(o => { if (o.isMesh && o.geometry.type === 'IcosahedronGeometry') { o.geometry = geo; o.material = mats[i++ % 3]; } });
  if (sm0) { const up = C.set; if (up) C.set = (...a) => { up(...a); mats.forEach(m => { m.opacity = sm0.opacity; }); }; }
  return C;
}
const strataTex = () => cv(1024, 1024, (g, w, h) => { const R = rnd(31); const bands = ['#8a7a62', '#7a6a52', '#9a8a70', '#6e604a', '#857358'];
  let y = 0, k = 0; while (y < h) { const bh = 20 + R() * 40; g.fillStyle = bands[k++ % bands.length]; g.fillRect(0, y, w, bh + 2); y += bh; }
  for (let i = 0; i < 5000; i++) { g.fillStyle = R() < 0.5 ? 'rgba(40,30,20,0.35)' : 'rgba(200,180,150,0.3)'; g.beginPath(); g.ellipse(R() * w, R() * h, 0.8 + R() * 2.5, 0.6 + R() * 1.8, R() * 3, 0, 7); g.fill(); }
  const dk = g.createLinearGradient(0, h * 0.6, 0, h); dk.addColorStop(0, 'rgba(192,64,42,0)'); dk.addColorStop(1, 'rgba(192,64,42,0.7)'); g.fillStyle = dk; g.fillRect(0, h * 0.6, w, h * 0.4); }, false);
export function cutaway() {
  const C = Y.cutaway(); const face = C.group.children[0]; const st = tx('strata', strataTex);
  face.material = new THREE.MeshStandardMaterial({ map: st, bumpMap: st, bumpScale: 1.5, roughness: 0.95, side: THREE.DoubleSide });
  const uv = face.geometry.attributes.uv, p = face.geometry.attributes.position; for (let i = 0; i < p.count; i++) uv.setXY(i, (p.getX(i) + 30) / 60, (p.getY(i) + 40) / 40); uv.needsUpdate = true;
  return C;
}
export function crustMat() { const t = tx('crust', () => cv(512, 512, (g, w, h) => { g.fillStyle = '#c8b88a'; g.fillRect(0, 0, w, h); const R = rnd(14); for (let i = 0; i < 9000; i++) { const v = R(); g.fillStyle = v < 0.4 ? 'rgba(150,130,90,0.4)' : v < 0.8 ? 'rgba(235,225,200,0.4)' : 'rgba(200,140,70,0.35)'; g.fillRect(R() * w, R() * h, 1 + R() * 3, 1 + R() * 3); } for (let i = 0; i < 40; i++) { g.strokeStyle = 'rgba(120,100,70,0.35)'; g.lineWidth = 1.5; let x = R() * w, y = R() * h; g.beginPath(); g.moveTo(x, y); for (let s = 0; s < 6; s++) { x += (R() - 0.5) * 40; y += (R() - 0.5) * 40; g.lineTo(x, y); } g.stroke(); } })); t.repeat.set(120, 120); return new THREE.MeshStandardMaterial({ map: t, bumpMap: t, bumpScale: 1, roughness: 1 }); }
