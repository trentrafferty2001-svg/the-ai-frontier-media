// detail kit for fireflies: ridged elytra with pale margins, soft glowing swarm sprites, moonlit meadow with stars,
// leafy tree silhouettes, varied grass and pale wildflowers
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as F from './firefly.js';
import { leafyTrees } from './hummer2.js';
export { chemistry, bulb, lanternCut, GLOW, std } from './firefly.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
const TX = {}; const tx = (k, f) => TX[k] || (TX[k] = f());
const elytraTex = () => cv(256, 128, (g, w, h) => { g.fillStyle = '#3a3226'; g.fillRect(0, 0, w, h); g.strokeStyle = 'rgba(90,80,60,0.6)'; g.lineWidth = 2; for (let y = 10; y < h; y += 14) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  const R = rnd(3); for (let i = 0; i < 1400; i++) { g.fillStyle = 'rgba(20,16,10,0.5)'; g.fillRect(R() * w, R() * h, 1.5, 1.5); } g.fillStyle = '#d8c070'; g.fillRect(0, h - 10, w, 10); g.fillRect(0, 0, w, 6); });
export function firefly(o) {
  const B = F.firefly(o); const et = tx('elytra', elytraTex);
  B.group.traverse(m => { if (m.isMesh && m.material.color && m.material.color.getHex() === 0x3a3226) { m.material = new THREE.MeshPhysicalMaterial({ map: et, bumpMap: et, bumpScale: 0.6, roughness: 0.35, clearcoat: 0.6 }); } });
  return B;
}
const glowTex = () => cv(128, 128, (g, w, h) => { const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,230,1)'); gr.addColorStop(0.12, 'rgba(240,255,150,0.95)'); gr.addColorStop(0.3, 'rgba(200,240,90,0.22)'); gr.addColorStop(1, 'rgba(160,220,60,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); });
export function swarm(n, seed, area) {
  const S = F.swarm(n, seed, area); const im = S.mesh;
  im.geometry = new THREE.PlaneGeometry(n > 1000 ? 0.26 : 0.4, n > 1000 ? 0.26 : 0.4); im.material = new THREE.MeshBasicMaterial({ map: tx('glow', glowTex), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false });
  return S;
}
export function meadow() {
  const G = F.meadow(); const R = rnd(17);
  // drop the cone trees, add leafy silhouettes
  G.children.filter(o => o.isMesh && o.geometry.type === 'ConeGeometry' && o.position.y > 1).forEach(o => G.remove(o));
  const spots = []; for (let k = 0; k < 34; k++) { const a = -0.6 - (k / 34) * 1.9, r = 16 + R() * 18; spots.push([Math.cos(a) * r, 0, Math.sin(a) * r]); }
  const T = leafyTrees(spots, { seed: 3, leaves: 1200, scale: 2.2 }); T.traverse(o => { if (o.isMesh) { o.material = o.material.clone(); o.material.color = new THREE.Color(0x1a2a1c); } }); G.add(T);
  // grass: per-blade colour variation (moonlit tips)
  G.children.forEach(o => { if (o.isInstancedMesh) { const c = new THREE.Color(); for (let i = 0; i < o.count; i++) o.setColorAt(i, c.setHSL(0.3 + R() * 0.06, 0.45, 0.05 + R() * 0.06)); o.material = o.material.clone(); o.material.color.set(0xffffff); } });
  const M = new THREE.Matrix4();
  // moon + stars
  const moon = new THREE.Mesh(new THREE.CircleGeometry(2.2, 40), new THREE.MeshBasicMaterial({ color: 0xf2f0e0, toneMapped: false, fog: false })); moon.position.set(-14, 22, -60); G.add(moon);
  const halo = new THREE.Mesh(new THREE.PlaneGeometry(16, 16), new THREE.MeshBasicMaterial({ map: tx('glow', glowTex), color: 0x8aa0d0, transparent: true, opacity: 0.35, depthWrite: false, blending: THREE.AdditiveBlending, fog: false })); halo.position.copy(moon.position).add(new THREE.Vector3(0, 0, -0.1)); G.add(halo);
  const st = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.18, 0.18), new THREE.MeshBasicMaterial({ map: tx('glow', glowTex), color: 0xdfe8ff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }), 500);
  for (let i = 0; i < 500; i++) { const a = -2.6 + R() * 2.2, el = 0.15 + R() * 1.1, r = 70; M.compose(new THREE.Vector3(Math.cos(a) * Math.cos(el) * r, Math.sin(el) * r, Math.sin(a) * Math.cos(el) * r), new THREE.Quaternion(), new THREE.Vector3(1, 1, 1).multiplyScalar(0.5 + R() * 1.5)); st.setMatrixAt(i, M); } G.add(st);
  return G;
}
