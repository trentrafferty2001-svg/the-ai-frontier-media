// The Explainer: how a hot air balloon flies. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { balloon, airDots, moleculeBox, balance, windLayers, ENV_BOTTOM, ENV_H, std, countrysideDetail } from './balloon2.js';
import { rnd } from './bolt.js';
import { trees } from './world.js';
import { label } from './gps.js';
import { VO } from './vo_ba2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['A *hot air balloon*', 4], ['lifts a basket', 3], ['full of people', 3], ['using *nothing*', 2], ['but *heated air*', 3]],
  [['When air *heats up*', 4], ['its *molecules*', 2], ['*move faster*', 2], ['and *spread out*', 3], ['so the same space', 4], ['holds *less air*', 3]],
  [['That makes', 2], ['*hot air lighter*', 3], ['than the', 2], ['*cold air*', 2], ['around it', 2]],
  [['The *burner*', 2], ['blasts a', 2], ['*huge flame*', 2], ['into the balloon', 3], ['heating the air', 3], ['inside to around', 3], ['*a hundred*', 2], ['*degrees*', 1]],
  [['Now the balloon', 3], ['is full of air', 4], ['about *a quarter*', 3], ['*lighter*', 1], ['than outside', 2], ['enough to lift', 3], ['*several hundred*', 2], ['*kilograms*', 1]],
  [['To *go down*', 3], ['the pilot lets', 3], ['the air *cool*', 3], ['or opens a *vent*', 4], ['at the top', 3], ['to let', 2], ['*hot air out*', 3]],
  [["But there's", 2], ['*no steering wheel*', 3]],
  [['*Winds* blow', 2], ['in *different*', 2], ['*directions*', 1], ['at different', 2], ['*heights*', 1]],
  [['So pilots *steer*', 3], ['by *climbing*', 2], ['or *sinking*', 2], ['until they catch', 3], ['a *wind*', 2], ['going *their way*', 3]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.05; c.far = 1200; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.5, warm: 1.12, sat: 1.18, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

function countryside(makeStage) {
  const scene = makeStage({ outdoor: 'golden', sunDir: [0.8, 0.35, 0.5], fog: 0.0035, shadowSize: 20, envI: 1.0, cloud: 0.35 });
  countrysideDetail(scene);
  return scene;
}
function lab(makeStage) {
  const scene = makeStage({ shadowSize: 4, sunDir: [2, 6, 5] });
  const u = scene.userData.sky.material.uniforms; if (u.top) { u.top.value.set(0x2a3a5a); u.mid.value.set(0x34486a); u.horizon.value.set(0x3e567a); u.floorC.value.set(0x182030); }
  scene.children.filter(o => o.material && o.material.isShadowMaterial).forEach(o => scene.remove(o));
  scene.add(new THREE.HemisphereLight(0xeef6ff, 0x203040, 1.0));
  return scene;
}

// ============ S0 hook: dawn, the burner roars and a balloon full of people lifts off ============
function sHook({ makeStage }) {
  const scene = countryside(makeStage); const B = balloon(); scene.add(B.group);
  const others = []; const R = rnd(8); for (let i = 0; i < 4; i++) { const o = balloon(); o.group.scale.setScalar(0.8); o.group.position.set(-60 + i * 35, 30 + R() * 25, -90 - R() * 60); scene.add(o.group); others.push(o); }
  const c = C(42);
  return {
    scene, camera: c,
    update(t) {
      B.st.burn = t > 0.3 && t < 2.6 ? 1 : 0; B.st.heat = 1; B.update(t); B.group.position.y = 2.2 * easeIn(range(t, 0.6, 4.8));
      others.forEach((o, i) => { o.st.burn = (Math.sin(t * 2 + i) > 0.7) ? 1 : 0; o.update(t); });
      const k = easeInOut(range(t, 0, 4.8));
      orb(c, [0, lerp(8, 12, k), 0], lerp(30, 40, k), lerp(25, 40, k), lerp(4, 10, k));
      return POST;
    },
  };
}
// ============ S1: heat a box of air: molecules speed up and spread out ============
function sMolecules({ makeStage }) {
  const scene = lab(makeStage); const MB = moleculeBox(); scene.add(MB.group);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      MB.update(T, smooth(range(T, at(1, 'heats') - 0.3, at(1, 'spread') + 0.4)));
      const k = easeInOut(range(t, 0, 5.8));
      orb(c, [0, 0.2, 0], lerp(13.5, 12.5, k), lerp(20, 35, k), lerp(16, 22, k));
      return POST;
    },
  };
}
// ============ S2: same-sized boxes: the hot one is lighter, the balance tips ============
function sBalance({ makeStage }) {
  const scene = lab(makeStage); const Bl = balance(); scene.add(Bl.group);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      Bl.set(smooth(range(T, at(2, 'lighter') - 0.2, at(2, 'lighter') + 0.6)));
      const k = easeInOut(range(t, 0, 2.9));
      orb(c, [0, 2.4, 0], lerp(18, 17, k), lerp(-6, 6, k), 6);
      return POST;
    },
  };
}
// ============ S3: the burner blasts a huge flame into the envelope ============
function sBurner({ makeStage }) {
  const scene = countryside(makeStage); const B = balloon(); scene.add(B.group); B.group.position.y = 0;
  const L = tag(scene, '~100°C', 2.4, '#ffb347', [0, ENV_BOTTOM + 6.5, 0]);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      B.st.burn = T > at(3, 'blasts') - 0.2 && T < at(3, 'hundred') ? 1 : 0.0; B.st.heat = smooth(range(T, at(3, 'heating') - 0.3, at(3, 'degrees'))); B.st.xray = 0.7 * smooth(range(T, at(3, 'inside') - 0.3, at(3, 'inside') + 0.2)); B.update(T);
      pop(L, easeOut(range(T, at(3, 'hundred') - 0.2, at(3, 'hundred') + 0.2)), 2.4);
      const k = easeInOut(range(t, 0, 6.0));
      orb(c, [0, lerp(2.6, 7.0, k), 0], lerp(4.5, 20, k), lerp(20, 30, k), lerp(-14, 2, k));
      return POST;
    },
  };
}
// ============ S4: see-through: sparse hot air inside, dense cold air outside; it lifts off ============
function sLighter({ makeStage }) {
  const scene = countryside(makeStage); const B = balloon(); scene.add(B.group); const D = airDots(); scene.add(D.inside, D.outside);
  const L = tag(scene, '1/4 lighter', 3.0, '#ffb347', [0, ENV_BOTTOM + ENV_H + 2.5, 0]);
  const c = C(42);
  return {
    scene, camera: c,
    update(t, T) {
      B.st.xray = 1; B.st.heat = 1; B.st.burn = 0; B.update(T); D.update(T, 1);
      const lift = easeIn(range(T, at(4, 'enough') - 0.2, le(4) + 0.5)); B.group.position.y = lift * 3; D.inside.position.y = B.group.position.y;
      pop(L, easeOut(range(T, at(4, 'quarter') - 0.2, at(4, 'quarter') + 0.2)), 3.0); L.position.y = ENV_BOTTOM + ENV_H + 2.5 + B.group.position.y;
      const k = easeInOut(range(t, 0, 6.2));
      orb(c, [0, 11 + lift * 2, 0], lerp(34, 38, k), lerp(-10, 10, k), 6);
      return POST;
    },
  };
}
// ============ S5: to go down: let it cool, or open the top vent and let hot air out ============
function sVent({ makeStage }) {
  const scene = countryside(makeStage); const B = balloon(); scene.add(B.group); const D = airDots(5); scene.add(D.inside); D.outside.visible = false;
  const c = C(42); const tv = at(5, 'vent');
  return {
    scene, camera: c,
    update(t, T) {
      B.group.position.y = 40 - 6 * smooth(range(T, at(5, 'down') - 0.3, le(5) + 0.5)); B.st.vent = smooth(range(T, tv - 0.2, tv + 0.3)) * (1 - smooth(range(T, le(5), le(5) + 0.6)));
      B.st.xray = 0.6; B.st.heat = 1 - 0.5 * smooth(range(T, at(5, 'cool') - 0.2, at(5, 'cool') + 0.6)); B.update(T); D.update(T, 1, B.st.vent); D.inside.position.y = B.group.position.y;
      const k = easeInOut(range(t, 0, 5.3));
      orb(c, [0, B.group.position.y + 13, 0], lerp(30, 26, k), lerp(20, 34, k), lerp(14, 26, k));
      return POST;
    },
  };
}
// ============ S6: in the basket: no steering wheel ============
function sNoWheel({ makeStage }) {
  const scene = countryside(makeStage); const B = balloon(); B.group.position.y = 60; scene.add(B.group);
  const c = C(40);
  return {
    scene, camera: c,
    update(t, T) {
      B.st.burn = 0; B.update(T); B.group.position.x = T * 0.6;
      const k = easeInOut(range(t, 0, 1.8));
      orb(c, [B.group.position.x, 61.2, 0], lerp(4.5, 3.8, k), lerp(30, 50, k), lerp(28, 22, k));
      return POST;
    },
  };
}
// ============ S7: wind layers blow different ways at different heights ============
function sWinds({ makeStage }) {
  const scene = countryside(makeStage); const W = windLayers(); scene.add(W.group); const B = balloon(); B.group.scale.setScalar(0.5); scene.add(B.group);
  const c = C(42);
  return {
    scene, camera: c,
    update(t, T) {
      W.update(T, smooth(range(T, at(7, 'winds') - 0.2, at(7, 'winds') + 0.5))); B.group.position.set(-(T - ls(7)) * 0.5 + 4, 3, 0); B.update(T);
      const k = easeInOut(range(t, 0, 3.4));
      orb(c, [2, 17, 0], lerp(66, 60, k), lerp(0, 8, k), 4);
      return POST;
    },
  };
}
// ============ S8: climb into the upper wind and drift toward the target field ============
function sSteer({ makeStage }) {
  const scene = countryside(makeStage); const W = windLayers(); scene.add(W.group); const B = balloon(); B.group.scale.setScalar(0.5); scene.add(B.group);
  const target = new THREE.Mesh(new THREE.RingGeometry(3, 3.6, 40), new THREE.MeshBasicMaterial({ color: 0xffe14a, toneMapped: false })); target.rotation.x = -Math.PI / 2; target.position.set(13, 0.1, 0); scene.add(target);
  const c = C(42);
  return {
    scene, camera: c,
    update(t, T) {
      W.update(T, 0.7); const climb = smooth(range(T, at(8, 'climbing') - 0.3, at(8, 'catch'))); const x0 = 4 - (ls(8) - ls(7)) * 0.5;
      const drift = Math.max(0, T - at(8, 'catch')) * 4.5; B.st.burn = T > at(8, 'climbing') - 0.3 && T < at(8, 'catch') ? 1 : 0; B.update(T);
      B.group.position.set(x0 - climb * 2 + drift, 3 + climb * 12.5, 0);
      const k = easeInOut(range(t, 0, 5.4));
      orb(c, [lerp(4, 7, k), 14, 0], lerp(56, 52, k), lerp(4, 12, k), lerp(6, 10, k));
      return POST;
    },
  };
}

const SH = [sHook, sMolecules, sBalance, sBurner, sLighter, sVent, sNoWheel, sWinds, sSteer];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
