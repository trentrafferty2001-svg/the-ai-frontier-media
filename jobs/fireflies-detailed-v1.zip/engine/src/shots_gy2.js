// The Explainer: why geysers erupt. Timeline, captions and shots.
import * as THREE from 'three';
import { lerp, easeOut, easeIn, easeInOut, range, smooth, cam, place } from './anim.js';
import { mound, column, steam, people, cutaway, PIPE, std, pools, pines, crustMat } from './geyser2.js';
import { rnd } from './bolt.js';
import { trees } from './world.js';
import { groundMat } from './hummer2.js';
import { label } from './gps.js';
import { VO } from './vo_gy2.js';

const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z0-9']/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
const NL = VO.length;
export const DURATION = Math.round((le(NL - 1) + 1.5) * 24) / 24;

const CHUNKS = [
  [['*Old Faithful*', 2], ['blasts *boiling*', 2], ['water up to', 3], ['*fifty metres*', 2], ['high', 1], ['about every', 2], ['*ninety minutes*', 2]],
  [['A *geyser*', 2], ['needs *three things*', 3], ['*Water*', 1], ['*heat*', 1], ['and a *narrow*', 3], ['*twisting pipe*', 2], ['underground', 1]],
  [['Rain and', 2], ['*snowmelt*', 1], ['*seep* deep', 2], ['into the ground', 3], ['close to rock', 3], ['heated by *magma*', 3]],
  [['Deep down', 2], ['the *weight*', 2], ['of the water', 3], ['above', 1], ['*stops it boiling*', 3], ['so it gets', 3], ['*hotter* than', 2], ['*a hundred*', 2], ['degrees', 1]],
  [['Eventually', 1], ['a few', 2], ['*steam bubbles*', 2], ['rise', 1], ['and *push*', 2], ['some water', 2], ['*out of the top*', 4]],
  [['That *lowers*', 2], ['the *pressure*', 2], ['on the water', 3], ['underneath', 1]],
  [['*Suddenly*', 1], ['all that', 2], ['*superheated*', 1], ['water *flashes*', 2], ['*into steam*', 2], ['at once', 2], ['and *blasts*', 2], ['out of the ground', 4]],
  [['Then the pipe', 3], ['*refills*', 1], ['the water', 2], ['*heats up* again', 3], ['and the *cycle*', 3], ['*repeats*', 1]],
  [['About *half*', 2], ['of all the', 3], ["world's *geysers*", 2], ['are in', 2], ['*Yellowstone*', 1]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

const C = (fov = 40) => { const c = cam(fov); c.near = 0.05; c.far = 1200; return c; };
const orb = (c, tg, d, az, el) => { const a = az * Math.PI / 180, e = el * Math.PI / 180; place(c, [tg[0] + Math.sin(a) * Math.cos(e) * d, tg[1] + Math.sin(e) * d, tg[2] + Math.cos(a) * Math.cos(e) * d], tg); };
const POST = { bloom: 0.45, warm: 1.05, sat: 1.15, exposure: 1.0 };
function tag(scene, text, size, color, pos) { const L = label(text, { size, color }); L.sprite.material.depthTest = false; L.sprite.renderOrder = 30; L.sprite.position.set(...pos); scene.add(L.sprite); return L.sprite; }
const pop = (s, k, size) => { s.scale.set(size * 4 * k, size * k, 1); s.visible = k > 0.01; };

function park(makeStage, { many = false } = {}) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.5, 0.6, 0.6], fog: 0.004, shadowSize: 30, envI: 1.0, cloud: 0.3 });
  const g = new THREE.Mesh(new THREE.CircleGeometry(700, 64), crustMat()); g.rotation.x = -Math.PI / 2; scene.add(g);
  const grass = new THREE.Mesh(new THREE.RingGeometry(60, 700, 64), (() => { const m = groundMat(); m.map.repeat.set(200, 200); return m; })()); grass.rotation.x = -Math.PI / 2; grass.position.y = 0.02; scene.add(grass);
  const R = rnd(3); const spots = []; for (let k = 0; k < 220; k++) { const a = R() * 6.28, r = 70 + R() * 300; spots.push([Math.cos(a) * r, 0, Math.sin(a) * r]); } scene.add(pines(spots, { seed: 9, scale: 4 })); pools(scene, R);
  const M = mound(); scene.add(M); const Col = column(); scene.add(Col.group); const S = steam(); scene.add(S.group); scene.add(people());
  const extra = []; if (many) { for (let k = 0; k < 12; k++) { const m = mound(); const a = R() * 6.28, r = 40 + R() * 160; m.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); m.scale.setScalar(0.5 + R() * 0.6); scene.add(m); const s = steam(14, 20 + k); s.group.position.copy(m.position); s.group.scale.setScalar(2); scene.add(s.group); const col = column(30 + k); col.group.position.copy(m.position); col.group.scale.setScalar(0.5 + R() * 0.4); scene.add(col.group); extra.push({ s, col, ph: R() }); } }
  return { scene, Col, S, extra };
}
function under(makeStage) {
  const scene = makeStage({ outdoor: 'day', sunDir: [0.5, 0.6, 0.7], fog: 0.0, shadowSize: 30, envI: 0.9, cloud: 0.3 });
  const gd = new THREE.Mesh(new THREE.CircleGeometry(300, 48, 0, Math.PI), std(0xb8a878, 1, 0, { side: THREE.DoubleSide })); gd.rotation.x = -Math.PI / 2; scene.add(gd);
  const CA = cutaway(); scene.add(CA.group); const Col = column(); scene.add(Col.group);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x806040, 0.6));
  return { scene, CA, Col };
}
// cycle state for the cutaway by global time
function cycle(CA, T) {
  const s = CA.st;
  s.rain = smooth(range(T, ls(2) - 0.2, ls(2) + 0.6)) * (1 - smooth(range(T, ls(3), ls(3) + 0.5))) + smooth(range(T, at(7, 'refills') - 0.3, at(7, 'refills') + 0.4));
  s.heat = T < ls(6) ? smooth(range(T, ls(3), at(3, 'hundred'))) : T < ls(7) ? 1 : smooth(range(T, at(7, 'heats') - 0.3, at(7, 'again') + 0.3));
  s.bubbles = (T > at(4, 'steam') - 0.3 && T < ls(6) + 0.3) ? 1 : 0;
  s.overflow = smooth(range(T, at(4, 'push') - 0.2, at(4, 'top')));
  s.steam = T < ls(6) ? 0 : T < ls(7) ? smooth(range(T, at(6, 'flashes') - 0.2, at(6, 'flashes') + 0.6)) : 1 - smooth(range(T, ls(7), at(7, 'refills') + 0.5));
  s.fill = T < ls(6) ? 1 - 0.08 * smooth(range(T, at(5, 'lowers'), le(5))) : T < ls(7) ? 1 - 0.85 * smooth(range(T, at(6, 'blasts') - 0.4, le(6))) : 0.07 + 0.93 * smooth(range(T, at(7, 'refills') - 0.3, at(7, 'water') + 0.4));
}

// ============ S0 hook: Old Faithful erupts over a crowd; 50 m, ~90 min ============
function sHook({ makeStage }) {
  const W = park(makeStage);
  const L1 = tag(W.scene, '50 m', 6.0, '#ffffff', [0, 31, 0]), L2 = tag(W.scene, '~90 min', 5.0, '#ffe14a', [0, 31, 0]);
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t) {
      W.Col.set(easeOut(range(t, 0.1, 1.6)), t); W.S.update(t, 1);
      pop(L1, easeOut(range(t, at(0, 'fifty') - 0.2, at(0, 'fifty') + 0.2)) * (1 - range(t, at(0, 'about') - 0.1, at(0, 'about') + 0.1)), 6.0); pop(L2, easeOut(range(t, at(0, 'ninety') - 0.2, at(0, 'ninety') + 0.2)), 5.0);
      const k = easeInOut(range(t, 0, 5.8));
      orb(c, [0, lerp(14, 24, k), 0], lerp(55, 80, k), lerp(10, 22, k), lerp(4, 8, k));
      return POST;
    },
  };
}
function cutShot(cam0, cam1, fn) {
  return ({ makeStage }) => {
    const W = under(makeStage); const ex = fn ? fn(W) : null; const c = C(40);
    return {
      scene: W.scene, camera: c,
      update(t, T) {
        cycle(W.CA, T); W.CA.update(T); if (ex) ex(t, T);
        const k = easeInOut(range(t, 0, 4.8));
        orb(c, cam0.tg.map((v, i) => lerp(v, cam1.tg[i], k)), lerp(cam0.d, cam1.d, k), lerp(cam0.az, cam1.az, k), lerp(cam0.el, cam1.el, k));
        return POST;
      },
    };
  };
}
// S1: three things (water, heat, pipe)
const sThree = cutShot({ tg: [0, -12, 0], d: 58, az: 4, el: 2 }, { tg: [0, -14, 0], d: 52, az: -4, el: 2 }, (W) => {
  const Lw = tag(W.scene, 'water', 4.5, '#7fc8ff', [-5, -2.5, 1]), Lh = tag(W.scene, 'heat', 4.5, '#ff8a5a', [0, -31, 1]), Lp = tag(W.scene, 'pipe', 4.5, '#ffe14a', [5, -14, 1]);
  return (t, T) => { pop(Lw, easeOut(range(T, at(1, 'water') - 0.1, at(1, 'water') + 0.2)), 4.5); pop(Lh, easeOut(range(T, at(1, 'heat') - 0.1, at(1, 'heat') + 0.2)), 4.5); pop(Lp, easeOut(range(T, at(1, 'pipe') - 0.1, at(1, 'pipe') + 0.2)), 4.5); W.CA.st.fill = 1; };
});
const sSeep = cutShot({ tg: [0, -10, 0], d: 50, az: -6, el: 4 }, { tg: [0, -18, 0], d: 48, az: 6, el: 2 });
const sPressure = cutShot({ tg: [0.4, -18, 0], d: 26, az: 6, el: 2 }, { tg: [0.4, -20, 0], d: 22, az: -4, el: 2 }, (W) => {
  const L = tag(W.scene, '>100°C', 2.2, '#ffd0a0', [0.4, -15, 1.5]);
  return (t, T) => pop(L, easeOut(range(T, at(3, 'hundred') - 0.2, at(3, 'hundred') + 0.2)), 2.2);
});
const sBubbles = cutShot({ tg: [0, -8, 0], d: 30, az: -6, el: 4 }, { tg: [0, -4, 0], d: 24, az: 6, el: 6 }, (W) => {
  const spill = []; const R = rnd(6); const sm = new THREE.MeshBasicMaterial({ color: 0x6ab8ff, toneMapped: false }); for (let i = 0; i < 30; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), sm); W.scene.add(m); spill.push({ m, vx: (R() - 0.5) * 3, ph: R() }); }
  return (t, T) => { const k = W.CA.st.overflow; spill.forEach(o => { const u = ((o.ph + T * 0.8) % 1); o.m.visible = k > 0.05; o.m.position.set(o.vx * u, 0.3 + 2.5 * u - 3 * u * u, 0.6); }); };
});
const sLower = cutShot({ tg: [0, -12, 0], d: 40, az: 4, el: 2 }, { tg: [0, -14, 0], d: 36, az: -4, el: 2 }, (W) => {
  const L = tag(W.scene, 'pressure ↓', 3.0, '#ffffff', [0, -2.5, 1.5]);
  return (t, T) => pop(L, easeOut(range(T, at(5, 'pressure') - 0.15, at(5, 'pressure') + 0.2)), 3.0);
});
// S6: the flash to steam: cutaway with the column bursting above ground
const sFlash = cutShot({ tg: [0, -6, 0], d: 52, az: 4, el: 4 }, { tg: [0, 8, 0], d: 70, az: -4, el: 6 }, (W) => (t, T) => { W.Col.set(easeOut(range(T, at(6, 'blasts') - 0.6, at(6, 'blasts') + 0.6)), T); });
const sRefill = cutShot({ tg: [0, -12, 0], d: 50, az: -4, el: 2 }, { tg: [0, -14, 0], d: 46, az: 4, el: 2 }, (W) => (t, T) => { W.Col.set(Math.max(0, 1 - range(T, ls(7), ls(7) + 1.2)) * 0.8, T); });
// S8: Yellowstone: many geysers steaming across the basin
function sYellowstone({ makeStage }) {
  const W = park(makeStage, { many: true });
  const L = tag(W.scene, 'Yellowstone', 18, '#ffe14a', [0, 75, 0]);
  const c = C(42);
  return {
    scene: W.scene, camera: c,
    update(t, T) {
      W.Col.set(0.5 + 0.5 * Math.sin(T * 0.5), T); W.S.update(T, 1); W.extra.forEach((e, i) => { e.s.update(T, 1); e.col.set(0.35 + 0.45 * Math.max(0, Math.sin(T * 0.8 + e.ph * 6)), T); });
      pop(L, easeOut(range(T, at(8, 'yellowstone') - 0.2, at(8, 'yellowstone') + 0.2)), 18);
      const k = easeInOut(range(t, 0, 4.6));
      orb(c, [0, 10, 0], lerp(150, 210, k), lerp(20, 40, k), lerp(30, 38, k));
      return POST;
    },
  };
}

const SH = [sHook, sThree, sSeep, sPressure, sBubbles, sLower, sFlash, sRefill, sYellowstone];
const S_ = SH.map((b, i) => [i === 0 ? 0 : ls(i), i === SH.length - 1 ? DURATION + 1 : ls(i + 1), b]);
export const SHOTS = S_.map(([s, e, build], i) => ({ start: i === 0 ? 0 : s - 0.12, end: i === S_.length - 1 ? e : e - 0.12, build }));
SHOTS.forEach((s, i) => { if (i > 0) s.start = SHOTS[i - 1].end; });
