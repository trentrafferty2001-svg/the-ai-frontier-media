// detail kit for the hot air balloon: stitched gore panels with load tapes, woven wicker basket; patchwork countryside
import * as THREE from 'three';
import { rnd } from './bolt.js';
import * as B from './balloon.js';
import { leafyTrees } from './hummer2.js';
export { airDots, moleculeBox, balance, windLayers, ENV_BOTTOM, ENV_H, std } from './balloon.js';
function cv(w, h, f) { const c = document.createElement('canvas'); c.width = w; c.height = h; f(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
const envTex = () => cv(2048, 1024, (g, w, h) => { const cols = ['#e8402a', '#f2c21a', '#2a7ae0', '#f2f2f2']; const n = 16; const gw = w / n;
  for (let k = 0; k < n; k++) { g.fillStyle = cols[k % 4]; g.fillRect(k * gw, 0, gw + 1, h); }
  // a chevron band around the middle
  for (let k = 0; k < n; k++) { g.fillStyle = cols[(k + 2) % 4]; g.beginPath(); g.moveTo(k * gw, h * 0.55); g.lineTo(k * gw + gw / 2, h * 0.47); g.lineTo(k * gw + gw, h * 0.55); g.lineTo(k * gw + gw, h * 0.62); g.lineTo(k * gw + gw / 2, h * 0.54); g.lineTo(k * gw, h * 0.62); g.closePath(); g.fill(); }
  const R = rnd(3); for (let i = 0; i < 20000; i++) { g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,0.04)' : 'rgba(255,255,255,0.05)'; g.fillRect(R() * w, R() * h, 2, 2); }
  g.strokeStyle = 'rgba(40,30,20,0.55)'; g.lineWidth = 4; for (let k = 0; k <= n; k++) { g.beginPath(); g.moveTo(k * gw, 0); g.lineTo(k * gw, h); g.stroke(); }
  g.strokeStyle = 'rgba(40,30,20,0.35)'; g.lineWidth = 3; for (let y = h / 12; y < h; y += h / 12) { g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  g.strokeStyle = 'rgba(255,255,255,0.35)'; g.setLineDash([6, 6]); g.lineWidth = 1.5; for (let k = 0; k <= n; k++) { g.beginPath(); g.moveTo(k * gw + 6, 0); g.lineTo(k * gw + 6, h); g.stroke(); } g.setLineDash([]); });
const wickerTex = () => cv(256, 256, (g, w, h) => { g.fillStyle = '#7a4e26'; g.fillRect(0, 0, w, h); const s = 16;
  for (let y = 0; y < h; y += s / 2) for (let x = 0; x < w; x += s) { const ox = ((y / (s / 2)) & 1) * s / 2; const gr = g.createLinearGradient(0, y, 0, y + s / 2); gr.addColorStop(0, '#d8a868'); gr.addColorStop(0.5, '#b8844a'); gr.addColorStop(1, '#7a4e26'); g.fillStyle = gr; g.beginPath(); g.ellipse(x + ox + s / 2, y + s / 4, s * 0.48, s * 0.22, 0, 0, 7); g.fill(); }
  g.strokeStyle = 'rgba(60,36,16,0.8)'; g.lineWidth = 3; for (let x = 0; x < w; x += s) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); } });
export function balloon() {
  const Bl = B.balloon(); const et = envTex(); const wt = wickerTex(); wt.repeat.set(1, 1);
  Bl.group.traverse(o => { if (!o.isMesh) return; const m = o.material;
    if (m.vertexColors && o.geometry.type === 'LatheGeometry') { m.vertexColors = false; m.map = et; m.bumpMap = et; m.bumpScale = 0.3; m.roughness = 0.5; m.sheen = 0; m.needsUpdate = true; }
    else if (m.color && m.color.getHex() === 0x9a6a3a) { m.map = wt; m.bumpMap = wt; m.bumpScale = 2; m.color.set(0xffffff); m.needsUpdate = true; }
    else if (m.color && m.color.getHex() === 0x6a4422) { m.map = wt; m.color.set(0x8a6a4a); m.needsUpdate = true; } });
  return Bl;
}
// patchwork fields with hedgerows and lanes, leafy trees, a few farmhouses
export function countrysideDetail(scene) {
  const R = rnd(21);
  const ft = cv(2048, 2048, (g, w, h) => { const cols = ['#7aa84a', '#c8b05a', '#5a8a3a', '#9ab85a', '#b8a050', '#6a9a40', '#8a7a4a']; const n = 9; const cw = w / n;
    for (let j = 0; j < n; j++) for (let i = 0; i < n; i++) { const x = i * cw + (R() - 0.5) * 40, y = j * cw + (R() - 0.5) * 40; g.fillStyle = cols[Math.floor(R() * cols.length)]; g.fillRect(x, y, cw + 40, cw + 40);
      const dir = R() < 0.5; g.strokeStyle = 'rgba(0,0,0,0.07)'; g.lineWidth = 3; for (let k = 0; k < cw + 40; k += 10) { g.beginPath(); if (dir) { g.moveTo(x + k, y); g.lineTo(x + k, y + cw + 40); } else { g.moveTo(x, y + k); g.lineTo(x + cw + 40, y + k); } g.stroke(); } }
    g.strokeStyle = '#2f5a24'; g.lineWidth = 14; for (let i = 0; i <= n; i++) { g.beginPath(); g.moveTo(i * cw, 0); for (let y = 0; y <= h; y += 64) g.lineTo(i * cw + Math.sin(y * 0.01 + i) * 14, y); g.stroke(); g.beginPath(); g.moveTo(0, i * cw); for (let x = 0; x <= w; x += 64) g.lineTo(x, i * cw + Math.sin(x * 0.01 + i) * 14); g.stroke(); }
    g.strokeStyle = '#c8bca0'; g.lineWidth = 10; g.beginPath(); g.moveTo(0, h * 0.4); g.bezierCurveTo(w * 0.3, h * 0.2, w * 0.6, h * 0.8, w, h * 0.6); g.stroke(); });
  ft.repeat.set(3, 3);
  const g = new THREE.Mesh(new THREE.CircleGeometry(600, 64), new THREE.MeshStandardMaterial({ map: ft, roughness: 1 })); g.rotation.x = -Math.PI / 2; g.position.y = 0.05; scene.add(g);
  const spots = []; for (let k = 0; k < 110; k++) spots.push([(R() - 0.5) * 360, 0, (R() - 0.5) * 360]);
  scene.add(leafyTrees(spots.filter(([x, , z]) => Math.hypot(x, z) > 45), { seed: 5, leaves: 700, scale: 2.4 }));
  const wm = new THREE.MeshStandardMaterial({ color: 0xe8dcc8, roughness: 0.8 }), rm = new THREE.MeshStandardMaterial({ color: 0x8a3a2a, roughness: 0.7 });
  for (let k = 0; k < 10; k++) { const h = new THREE.Group(); const a = R() * Math.PI * 2, r = 40 + R() * 140; h.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); h.rotation.y = R() * 3;
    const b = new THREE.Mesh(new THREE.BoxGeometry(6, 4, 4), wm); b.position.y = 2; h.add(b); const rf = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 3.4, 2.6, 4, 1), rm); rf.rotation.y = Math.PI / 4; rf.scale.set(1.25, 1, 0.85); rf.position.y = 5.3; h.add(rf); scene.add(h); }
}
