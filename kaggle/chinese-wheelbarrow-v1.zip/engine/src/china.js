// Han China set for the wheelbarrow video: a dirt road through rice paddies, the centre-wheel barrow (with a sail),
// a European-style front-wheel barrow, Han clothing for toon.js characters, a straw hat, and a carved tomb relief.
// Road runs along +x at z = 0. Ground height is one function (groundAt) used by the mesh, the wheel and the feet.
import * as THREE from 'three';
import { fbm, rng } from './nile.js';
import { fields, mountains, trees } from './world.js';

export const SS = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const V3 = (x, y, z) => new THREE.Vector3(x, y, z);
const shadowAll = (o) => { o.traverse(m => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } }); return o; };

// ---------- features on the road (set per shot before building the terrain) ----------
// ruts: [x, depth, halfWidth] grooves across the road; stones: [x, z, r] (sphere caps, centre at y = r * 0.35)
export const FEAT = { ruts: [], stones: [] };
export const PADDY_Y = -0.3;
function roadNoise(x, z) { return (fbm(x * 1.7, z * 1.7, 3) - 0.5) * 0.012 + (fbm(x * 7, z * 7, 4) - 0.5) * 0.004; }
// bare ground (no stones): road, cart ruts, verges, drop to the paddies
export function groundBase(x, z) {
  const az = Math.abs(z);
  let y = roadNoise(x, z);
  for (const s of [-0.78, 0.78]) y -= 0.018 * Math.exp(-(((z - s) / 0.07) ** 2)); // old cart ruts along the road
  for (const [rx, d, hw] of FEAT.ruts) y -= d * SS(hw, hw * 0.45, Math.abs(x - rx)) * SS(1.5, 1.2, az);
  // verge: a low grassy shoulder, then a bank down into the flooded field
  const sh = 0.04 * SS(1.25, 1.7, az) * (1 - SS(2.2, 2.6, az));
  const drop = -0.62 * SS(2.25, 3.0, az + (fbm(x * 0.4, 5, 7) - 0.5) * 0.3);
  return y + sh + drop + (fbm(x * 0.5, z * 0.5, 9) - 0.5) * 0.05 * SS(1.4, 2.4, az);
}
export function groundAt(x, z) {
  let y = groundBase(x, z);
  for (const [sx, sz, r] of FEAT.stones) { const d2 = (x - sx) ** 2 + (z - sz) ** 2, cy = r * 0.35 + groundBase(sx, sz); if (d2 < r * r) y = Math.max(y, cy + Math.sqrt(r * r - d2)); }
  return y;
}
// axle height of a wheel of radius R whose centre is above (x, z): highest contact over the ground profile
export function axleAt(x, z, R) {
  let y = -9;
  for (let i = -24; i <= 24; i++) { const u = (i / 24) * R * 0.98; const g = groundAt(x + u, z); y = Math.max(y, g + Math.sqrt(R * R - u * u)); }
  return y;
}

// ---------- textures ----------
let _T = null;
function canvasTex(w, h, draw, repeat = [1, 1], srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); draw(x, w, h);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat); t.anisotropy = 8; if (srgb) t.colorSpace = THREE.SRGBColorSpace; return t;
}
export function TX() {
  if (_T) return _T;
  const r = rng(5);
  const wood = (base) => canvasTex(256, 256, (x, w, h) => {
    x.fillStyle = base; x.fillRect(0, 0, w, h);
    for (let i = 0; i < 90; i++) { const y = r() * h; x.strokeStyle = `rgba(${40 + r() * 40},${25 + r() * 20},${10},${0.15 + r() * 0.25})`; x.lineWidth = 0.6 + r() * 2; x.beginPath(); x.moveTo(0, y); for (let k = 0; k <= 8; k++) x.lineTo(k * w / 8, y + Math.sin(k * 0.9 + i) * 3 * r()); x.stroke(); }
    for (let i = 0; i < 4; i++) { const cx = r() * w, cy = r() * h; x.strokeStyle = 'rgba(50,30,12,0.35)'; for (let k = 1; k < 5; k++) { x.beginPath(); x.ellipse(cx, cy, k * 4, k * 1.6, 0, 0, 6.3); x.stroke(); } }
  });
  const burlap = canvasTex(256, 256, (x, w, h) => {
    x.fillStyle = '#b59a6a'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < w; i += 3) { x.fillStyle = `rgba(90,70,40,${0.18 + r() * 0.2})`; x.fillRect(i, 0, 1, h); x.fillRect(0, i, w, 1); }
    for (let i = 0; i < 300; i++) { x.fillStyle = `rgba(${r() < 0.5 ? '70,50,25' : '220,200,150'},0.15)`; x.fillRect(r() * w, r() * h, 2 + r() * 6, 1); }
  }, [3, 3]);
  const straw = canvasTex(256, 64, (x, w, h) => {
    x.fillStyle = '#c9a35e'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < w; i += 2) { x.fillStyle = `rgba(${120 + r() * 60},${85 + r() * 40},${30},${0.3 + r() * 0.3})`; x.fillRect(i, 0, 1, h); }
    for (let j = 0; j < h; j += 8) { x.fillStyle = 'rgba(90,60,20,0.35)'; x.fillRect(0, j, w, 1.5); }
  }, [6, 1]);
  const cloth = canvasTex(128, 128, (x, w, h) => {
    x.fillStyle = '#e9e1cc'; x.fillRect(0, 0, w, h);
    for (let i = 0; i < w; i += 2) { x.fillStyle = `rgba(120,100,70,${0.08 + r() * 0.1})`; x.fillRect(i, 0, 1, h); x.fillRect(0, i, w, 1); }
  }, [2, 3]);
  const ground = canvasTex(512, 512, (x, w, h) => {
    const img = x.createImageData(w, h);
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { const v = 128 + (fbm(i * 0.06, j * 0.06, 2) - 0.5) * 120 + (r() - 0.5) * 40; const k = (j * w + i) * 4; img.data[k] = img.data[k + 1] = img.data[k + 2] = v; img.data[k + 3] = 255; }
    x.putImageData(img, 0, 0);
    for (let i = 0; i < 260; i++) { x.fillStyle = `rgba(${r() < 0.5 ? 40 : 230},${r() < 0.5 ? 40 : 230},${r() < 0.5 ? 40 : 230},0.5)`; x.beginPath(); x.arc(r() * w, r() * h, 0.6 + r() * 2.2, 0, 6.3); x.fill(); }
  }, [1, 1], false);
  _T = { wood: wood('#8a6440'), woodDark: wood('#5e4128'), burlap, straw, cloth, ground };
  return _T;
}
export function MAT() {
  const t = TX();
  return {
    wood: new THREE.MeshStandardMaterial({ map: t.wood, roughness: 0.78, bumpMap: t.wood, bumpScale: 1.2 }),
    woodDark: new THREE.MeshStandardMaterial({ map: t.woodDark, roughness: 0.8, bumpMap: t.woodDark, bumpScale: 1.2 }),
    iron: new THREE.MeshStandardMaterial({ color: 0x3a3632, roughness: 0.55, metalness: 0.6 }),
    rope: new THREE.MeshStandardMaterial({ color: 0x9a7a4a, roughness: 0.9, bumpMap: t.straw, bumpScale: 1 }),
    burlap: new THREE.MeshStandardMaterial({ map: t.burlap, roughness: 0.95, bumpMap: t.burlap, bumpScale: 2.2 }),
    sail: new THREE.MeshStandardMaterial({ map: t.cloth, color: 0xfff6e4, roughness: 0.9, side: THREE.DoubleSide, bumpMap: t.cloth, bumpScale: 0.8 }),
    straw: new THREE.MeshStandardMaterial({ map: t.straw, roughness: 0.9, bumpMap: t.straw, bumpScale: 1.5, side: THREE.DoubleSide }),
  };
}

// ---------- terrain: one dense mesh around the road, coarse further out ----------
function axisMap(n, dense, step, far) { // symmetric coordinates: `dense` spacing `step` near 0, then to `far` in growing steps
  const out = []; for (let v = 0; v <= dense + 1e-6; v += step) out.push(v);
  let v = dense, s = step; while (v < far) { s = Math.min(s * 1.12, 2.5); v += s; out.push(v); }
  const neg = out.slice(1).map(v => -v).reverse(); return neg.concat(out);
}
export function terrain({ xDense = 24, zDense = 3.2, step = 0.04 } = {}) {
  const xs = axisMap(0, xDense, step, 70), zs = axisMap(0, zDense, 0.04, 16);
  const nx = xs.length, nz = zs.length; const pos = new Float32Array(nx * nz * 3), col = new Float32Array(nx * nz * 3), uv = new Float32Array(nx * nz * 2);
  const c = new THREE.Color(), dust = new THREE.Color(0xc2a272), dust2 = new THREE.Color(0xa88758), rut = new THREE.Color(0x8a6c48), grass = new THREE.Color(0x6f8c3a), grass2 = new THREE.Color(0x4f7030), mud = new THREE.Color(0x4a3a28);
  let k = 0;
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
    const x = xs[i], z = zs[j], y = groundBase(x, z), az = Math.abs(z);
    pos[k * 3] = x; pos[k * 3 + 1] = y; pos[k * 3 + 2] = z; uv[k * 2] = x / 3; uv[k * 2 + 1] = z / 3;
    c.copy(dust).lerp(dust2, fbm(x * 0.6, z * 0.6, 6));
    c.lerp(rut, SS(-0.004, -0.02, y) * SS(1.4, 1.1, az));                      // darker, packed ruts
    const gv = SS(1.15, 1.6, az + (fbm(x * 1.3, z, 8) - 0.5) * 0.5);              // grass on the shoulders
    c.lerp(grass.clone().lerp(grass2, fbm(x * 2, z * 2, 11)), gv);
    c.lerp(mud, SS(-0.15, -0.4, y));                                              // wet bank at the paddy edge
    col[k * 3] = c.r; col[k * 3 + 1] = c.g; col[k * 3 + 2] = c.b; k++;
  }
  const idx = new Uint32Array((nx - 1) * (nz - 1) * 6); let q = 0;
  for (let j = 0; j < nz - 1; j++) for (let i = 0; i < nx - 1; i++) { const a = j * nx + i, b = a + nx; idx[q++] = a; idx[q++] = b; idx[q++] = a + 1; idx[q++] = a + 1; idx[q++] = b; idx[q++] = b + 1; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.setAttribute('uv', new THREE.BufferAttribute(uv, 2)); g.setIndex(new THREE.BufferAttribute(idx, 1));
  g.computeVertexNormals();
  const t = TX().ground;
  const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, bumpMap: t, bumpScale: 1.6 }));
  m.receiveShadow = true; return m;
}
// stones on the road (FEAT.stones), shaped as low rounded rocks matching the groundAt caps
export function roadStones() {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0x8c8274, roughness: 0.8, bumpMap: TX().ground, bumpScale: 2 });
  FEAT.stones.forEach(([x, z, r], i) => {
    const geo = new THREE.IcosahedronGeometry(1, 3); const p = geo.attributes.position;
    for (let k = 0; k < p.count; k++) { const v = V3(p.getX(k), p.getY(k), p.getZ(k)); v.multiplyScalar(1 + (fbm(v.x * 2 + i, v.y * 2 + v.z * 2, 21) - 0.5) * 0.12); p.setXYZ(k, v.x, v.y, v.z); }
    geo.computeVertexNormals();
    const s = new THREE.Mesh(geo, m); s.scale.setScalar(r); s.position.set(x, r * 0.35 + groundBase(x, z), z); g.add(s);
  });
  return shadowAll(g);
}
export function scenery(scene, { seed = 3 } = {}) {
  const pad = fields(400, { cover: 0.62, spacing: 0.25, bundX: 18, bundZ: 12 }); pad.position.y = PADDY_Y; scene.add(pad);
  scene.add(mountains({ rMin: 90, rMax: 280, peaks: 54, height: 46, seed, color: 0x50703f }));
  const r = rng(seed + 4); const spots = [];
  for (let i = 0; i < 70; i++) { const side = r() < 0.5 ? -1 : 1; const x = (r() - 0.5) * 160, z = side * (14 + r() * 50); spots.push([x, PADDY_Y + 0.15, z]); }
  scene.add(trees(spots, { seed: seed + 1, scale: 1.25 }));
  return pad;
}

// ---------- the Chinese centre-wheel barrow ----------
// Local frame: origin at the axle centre, +x forward, y up. Wheel radius R. Handles end at HANDLE (each side +-z).
export const WB = { R: 0.42, HANDLE: V3(-1.32, 0.3, 0.27), RACK_Y: 0.07 };
export function barrow({ scale = 1, sacks = true, sail = true, seats = false } = {}) {
  const M = MAT(); const R = WB.R;
  const root = new THREE.Group(); root.scale.setScalar(scale);
  const body = new THREE.Group(); root.add(body);               // pitches about the axle
  // wheel: rim, spokes, hub
  const wheel = new THREE.Group(); body.add(wheel);
  { const rim = new THREE.Mesh(new THREE.TorusGeometry(R - 0.035, 0.035, 12, 72), M.woodDark); rim.scale.z = 1.35; wheel.add(rim);
    const tyre = new THREE.Mesh(new THREE.TorusGeometry(R - 0.012, 0.014, 8, 72), M.iron); tyre.scale.z = 2.2; wheel.add(tyre);
    for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; const s = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.019, R - 0.08, 8), M.wood); s.position.set(Math.cos(a) * (R - 0.04) / 2, Math.sin(a) * (R - 0.04) / 2, 0); s.rotation.z = a - Math.PI / 2; wheel.add(s); }
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.16, 20), M.woodDark); hub.rotation.x = Math.PI / 2; wheel.add(hub);
    const axle = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.5, 10), M.iron); axle.rotation.x = Math.PI / 2; body.add(axle); }
  // side rails: from the nose, past the axle, curving up into the splayed handles
  for (const s of [-1, 1]) {
    const c = new THREE.CatmullRomCurve3([V3(0.78, -0.02, s * 0.2), V3(0.3, 0.0, s * 0.2), V3(-0.4, 0.04, s * 0.205), V3(-0.85, 0.13, s * 0.23), V3(WB.HANDLE.x, WB.HANDLE.y, s * WB.HANDLE.z)]);
    const rail = new THREE.Mesh(new THREE.TubeGeometry(c, 48, 0.032, 10), M.wood); body.add(rail);
    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.2, 10), M.woodDark); // worn grip at the handle end
    const d = c.getTangent(1); grip.position.copy(c.getPoint(0.94)); grip.quaternion.setFromUnitVectors(V3(0, 1, 0), d); body.add(grip);
    // rear leg (the barrow rests on it when parked)
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.4, 8), M.wood); leg.position.set(-0.62, -0.12, s * 0.21); leg.rotation.z = -0.08; body.add(leg);
  }
  // cross bars, racks either side of the wheel, foot boards
  for (const x of [0.62, 0.3, -0.3, -0.62]) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.05, 1.3), M.wood); b.position.set(x, 0.02, 0); body.add(b); }
  for (const s of [-1, 1]) {
    for (let k = 0; k < 5; k++) { const p = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.025, 0.085), M.wood); p.position.set(0, WB.RACK_Y - 0.012, s * (0.255 + k * 0.095)); p.rotation.x = (k % 2 ? 0.01 : -0.01); body.add(p); }
    const lip = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.06, 0.03), M.woodDark); lip.position.set(0, WB.RACK_Y + 0.02, s * 0.665); body.add(lip);
  }
  // wheel frame: two thin arched ribs over the wheel joined by three slats (the wheel stays visible between them)
  { const rib = () => { const sh = new THREE.Shape(); sh.absarc(0, 0, R + 0.075, 0.12, Math.PI - 0.12, false); sh.absarc(0, 0, R + 0.035, Math.PI - 0.12, 0.12, true);
      return new THREE.ExtrudeGeometry(sh, { depth: 0.03, bevelEnabled: true, bevelSize: 0.006, bevelThickness: 0.006, bevelSegments: 2, curveSegments: 40 }); };
    for (const s of [-1, 1]) { const m = new THREE.Mesh(rib(), M.woodDark); m.position.set(0, WB.RACK_Y - 0.06, s * 0.105 - 0.015); body.add(m);
      for (const x of [-0.42, 0.42]) { const post = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.12, 0.03), M.woodDark); post.position.set(x, WB.RACK_Y - 0.01, s * 0.105); body.add(post); } }
    for (const a of [0.75, Math.PI / 2, Math.PI - 0.75]) { const sl = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.025, 0.25), M.wood); sl.position.set(Math.cos(a) * (R + 0.075), WB.RACK_Y - 0.06 + Math.sin(a) * (R + 0.075) + 0.01, 0); sl.rotation.z = a - Math.PI / 2; body.add(sl); } }
  // the load: rice sacks on both racks
  const load = new THREE.Group(); body.add(load); const sackList = [];
  if (sacks) {
    const r = rng(17);
    const place = [[-0.33, 0, 0.44], [0.33, 0, 0.44], [0, 1, 0.44]];
    for (const s of [-1, 1]) place.forEach(([x, lvl, z], i) => {
      const sk = sack(r); sk.position.set(x + (r() - 0.5) * 0.05, WB.RACK_Y + 0.13 + lvl * 0.24, s * z + (r() - 0.5) * 0.03); sk.rotation.y = (r() - 0.5) * 0.15; load.add(sk); sackList.push(sk);
    });
  }
  // sail: a mast at the nose and a batten sail across the road (filled by a following wind)
  const mast = new THREE.Group(); mast.position.set(0.66, 0, 0); body.add(mast); mast.visible = sail;
  const MH = 1.85, SW = 1.1, SH = 1.05, NU = 22, NV = 18;
  { const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.03, MH, 10), M.wood); pole.position.y = MH / 2; mast.add(pole);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.03, 12, 8), M.woodDark); knob.position.y = MH; mast.add(knob); }
  const sg = new THREE.PlaneGeometry(SW, SH, NU, NV); sg.rotateY(Math.PI / 2); // in the y-z plane, normal +x
  const sailMesh = new THREE.Mesh(sg, M.sail); mast.add(sailMesh); const s0 = sg.attributes.position.array.slice();
  const battens = []; for (let i = 0; i <= 5; i++) { const b = new THREE.Mesh(new THREE.BufferGeometry(), M.wood); b.castShadow = true; mast.add(b); battens.push(b); }
  const sheets = []; for (const s of [-1, 1]) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 1, 5), M.rope); mast.add(l); sheets.push([l, s]); }
  // hoist 0..1 (sail goes up the mast), fill 0..1 (bellies forward), time for flutter
  const billow = (u, v, fill, t) => fill * 0.34 * Math.sin(Math.PI * u) * (0.35 + 0.65 * Math.sin(Math.PI * Math.min(1, v * 1.1))) + 0.012 * Math.sin(t * 7 + u * 9 + v * 5) * (1.2 - fill);
  function setSail(hoist, fill, t) {
    mast.visible = hoist > 0.001 || sail === 'always';
    const top = 0.55 + SH * 0.12 + (SH * 0.88) * hoist, h = Math.max(0.03, SH * hoist); const p = sg.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const z0 = s0[i * 3 + 2], y0 = s0[i * 3 + 1]; const u = z0 / SW + 0.5, v = y0 / SH + 0.5;
      p.setXYZ(i, billow(u, v, fill * hoist, t) + 0.035, top - h + v * h, z0);
    }
    p.needsUpdate = true; sg.computeVertexNormals(); sailMesh.visible = hoist > 0.02;
    battens.forEach((b, i) => { const v = i / 5; const pts = []; for (let k = 0; k <= 16; k++) { const u = k / 16; pts.push(V3(billow(u, v, fill * hoist, t) + 0.035 + 0.012, top - h + v * h, (u - 0.5) * (SW + 0.04))); }
      b.geometry.dispose(); b.geometry = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.007, 6); b.visible = sailMesh.visible; });
    // sheets: from the bottom corners of the sail back to the handles
    sheets.forEach(([l, s]) => { const a = V3(0.035, top - h, s * SW / 2), bb = V3(WB.HANDLE.x - 0.66 + 0.1, WB.HANDLE.y + 0.02, s * WB.HANDLE.z); const d = bb.clone().sub(a); l.position.copy(a).addScaledVector(d, 0.5); l.scale.set(1, d.length(), 1); l.quaternion.setFromUnitVectors(V3(0, 1, 0), d.normalize()); l.visible = sailMesh.visible && hoist > 0.9; });
  }
  setSail(sail ? 1 : 0, 0.5, 0);
  shadowAll(root);
  // state: pitch (rad, + lifts the nose / lowers the handles), spin (wheel angle)
  function set({ pitch = 0, spin = 0 } = {}) { body.rotation.z = pitch; wheel.rotation.z = spin; root.updateMatrixWorld(true); }
  // world position of a point given in barrow-local coords
  const toWorld = (p) => body.localToWorld(p.clone());
  return { root, body, wheel, load, sacks: sackList, mast, setSail, set, toWorld, scale };
}
// a lumpy, tied rice sack (about 0.5 x 0.24 x 0.36 m)
export function sack(r = Math.random) {
  const M = MAT(); const g = new THREE.SphereGeometry(1, 28, 18); const p = g.attributes.position;
  const sd = r() * 50;
  for (let i = 0; i < p.count; i++) { let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const k = 1 + (fbm(x * 1.5 + sd, y * 1.5 + z * 1.5, 31) - 0.5) * 0.18; // lumps
    const box = 1 / Math.pow(Math.abs(x) ** 3 + Math.abs(y) ** 3 + Math.abs(z) ** 3, 1 / 3); // pillow: between a sphere and a box
    const f = 0.55 + 0.45 * box; x *= f * k; z *= f * k; y *= (y < 0 ? 0.92 : 1) * f * k; p.setXYZ(i, x * 0.26, y * 0.12, z * 0.18); }
  g.computeVertexNormals();
  const m = new THREE.Mesh(g, M.burlap); const grp = new THREE.Group(); grp.add(m);
  const tie = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.008, 6, 16), M.rope); tie.position.set(0.25, 0, 0); tie.rotation.y = Math.PI / 2; grp.add(tie);
  const ear = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.07, 10), M.burlap); ear.position.set(0.3, 0, 0); ear.rotation.z = -Math.PI / 2; grp.add(ear);
  return shadowAll(grp);
}

// ---------- a front-wheel barrow (the "normal" kind): small wheel at the nose, tray between the handles ----------
export const EB = { R: 0.19, HANDLE: V3(-1.42, 0.38, 0.27) }; // local: origin at the wheel axle
export function euroBarrow() {
  const M = MAT(); const R = EB.R; const root = new THREE.Group(); const body = new THREE.Group(); root.add(body);
  const wheel = new THREE.Group(); body.add(wheel);
  { const rim = new THREE.Mesh(new THREE.TorusGeometry(R - 0.02, 0.025, 10, 48), M.woodDark); rim.scale.z = 1.6; wheel.add(rim);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; const s = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, R - 0.04, 6), M.wood); s.position.set(Math.cos(a) * (R - 0.02) / 2, Math.sin(a) * (R - 0.02) / 2, 0); s.rotation.z = a - Math.PI / 2; wheel.add(s); }
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.1, 14), M.woodDark); hub.rotation.x = Math.PI / 2; wheel.add(hub); }
  for (const s of [-1, 1]) {
    const c = new THREE.CatmullRomCurve3([V3(0, 0, s * 0.07), V3(-0.3, 0.12, s * 0.17), V3(-0.8, 0.26, s * 0.24), V3(EB.HANDLE.x, EB.HANDLE.y, s * EB.HANDLE.z)]);
    body.add(new THREE.Mesh(new THREE.TubeGeometry(c, 40, 0.028, 10), M.wood));
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.026, 0.3, 8), M.wood); leg.position.set(-0.95, 0.12, s * 0.24); body.add(leg);
  }
  // tray: a sloping wooden box between the handles
  const tray = new THREE.Group(); tray.position.set(-0.62, 0.38, 0); tray.rotation.z = 0.12; body.add(tray);
  const box = (w, h, d, x, y, z, rz = 0) => { const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), M.wood); b.position.set(x, y, z); b.rotation.z = rz; tray.add(b); };
  box(0.8, 0.03, 0.5, 0, -0.12, 0); box(0.8, 0.25, 0.03, 0, 0, 0.25); box(0.8, 0.25, 0.03, 0, 0, -0.25); box(0.03, 0.25, 0.5, -0.4, 0, 0); box(0.03, 0.3, 0.5, 0.42, 0.02, 0, -0.35);
  const r = rng(23); const load = new THREE.Group(); tray.add(load);
  [[-0.15, 0, -0.05], [0.18, 0, 0.06], [0.0, 1, 0], [-0.2, 1, 0.08], [0.15, 2, -0.02]].forEach(([x, l, z]) => { const s = sack(r); s.scale.setScalar(0.85); s.position.set(x, -0.02 + l * 0.17, z); s.rotation.y = (r() - 0.5) * 1.2; load.add(s); });
  shadowAll(root);
  function set({ pitch = 0, spin = 0 } = {}) { body.rotation.z = pitch; wheel.rotation.z = spin; root.updateMatrixWorld(true); }
  return { root, body, set, toWorld: (p) => body.localToWorld(p.clone()) };
}

// ---------- Han clothing for a toon.js character ----------
// Tunic (cross-collared, right lapel over left), wide sleeves to the forearm, trousers to the ankle; the toon's kilt
// becomes the tunic's skirt (pass cloth: tunic colour to toon()). Clothes are skinned to the same skeleton.
export function dress(F, { tunic = 0x5d6f8a, collar = 0x2e3a4c, trousers = 0x6b5a44, hat = true, band = 0x2b2420 } = {}) {
  const sk = []; F.root.traverse(o => { if (o.isSkinnedMesh) sk.push(o); });
  const skeleton = sk[0].skeleton;
  const weave = F.M.cloth.bumpMap;
  const mat = (c) => new THREE.MeshStandardMaterial({ color: 0xffffff, vertexColors: true, roughness: 0.92, bumpMap: weave, bumpScale: 0.6, side: THREE.DoubleSide });
  const bb = (m) => { m.geometry.computeBoundingBox(); return m.geometry.boundingBox; };
  const torso = sk.find(m => m.name === 'torso');
  const kilt = sk.find(m => m.name === 'kilt'); if (kilt) kilt.material.color.set(tunic);
  const limbs = sk.filter(m => m !== torso && m !== kilt && m.name === '');
  const arms = limbs.filter(m => { const b = bb(m); return b.max.y > 1.3 && Math.abs((b.min.x + b.max.x) / 2) > 0.1; });
  const legs = limbs.filter(m => { const b = bb(m); return b.max.y < 1.06 && b.min.y < 0.3; });
  const cT = new THREE.Color(tunic), cC = new THREE.Color(collar), cP = new THREE.Color(trousers);
  function shell(src, offFn, keepFn, colFn) {
    const g = src.geometry.clone(); const p = g.attributes.position, n = g.attributes.normal; const col = new Float32Array(p.count * 3); const c = new THREE.Color();
    for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i); const o = offFn(x, y, z); p.setXYZ(i, x + n.getX(i) * o, y + n.getY(i) * o, z + n.getZ(i) * o); colFn(x, y, z, c); col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const ix = g.index.array, keep = []; for (let i = 0; i < ix.length; i += 3) { const a = ix[i], b = ix[i + 1], d = ix[i + 2]; if (keepFn(p.getY(a), p.getY(b), p.getY(d))) keep.push(a, b, d); }
    g.setIndex(keep); g.computeVertexNormals();
    const m = new THREE.SkinnedMesh(g, mat()); m.castShadow = m.receiveShadow = true; m.frustumCulled = false; F.root.add(m); m.bind(skeleton, new THREE.Matrix4()); return m;
  }
  // collar line: from the left of the neck down across the chest to the wearer's right side (toon -x)
  const collarD = (x, y, z) => { if (z < 0) return 9; const lx = 0.045 - (1.49 - y) * 0.62; return Math.abs(x - lx); };
  shell(torso, (x, y) => 0.016 + 0.006 * SS(1.2, 1.0, y), (a, b, c) => Math.max(a, b, c) < 1.495, (x, y, z, c) => {
    c.copy(cT); const d = collarD(x, y, z); if (y > 1.13 && d < 0.022) c.copy(cC); if (y > 1.455) c.copy(cC); // lapel edge and neck band
    c.multiplyScalar(0.94 + 0.06 * Math.sin(x * 60 + y * 20));
  });
  arms.forEach(a => { const top = bb(a).max.y; shell(a, (x, y) => 0.012 + 0.026 * SS(top - 0.22, top - 0.46, y), (p, q, r) => Math.min(p, q, r) > top - 0.5, (x, y, z, c) => { c.copy(top - y > 0.44 ? cC : cT); }); });
  legs.forEach(l => { shell(l, (x, y) => 0.014 + 0.014 * SS(0.6, 0.25, y) - 0.012 * SS(0.2, 0.13, y), (p, q, r) => Math.min(p, q, r) > 0.105, (x, y, z, c) => { c.copy(y < 0.2 ? cC : cP); }); });
  // straw hat (rigid on the head)
  if (hat) { const h = strawHat(); h.position.set(0, 0.075 + 0.105, 0.012); h.rotation.x = -0.12; F.bones.head.add(h); F.hat = h; }
  else { // topknot and a head band
    const k = new THREE.Mesh(new THREE.SphereGeometry(0.045, 16, 12), F.M.hair); k.position.set(0, 0.075 + 0.14, -0.01); F.bones.head.add(k);
    const b = new THREE.Mesh(new THREE.TorusGeometry(0.128, 0.012, 8, 40), new THREE.MeshStandardMaterial({ color: band, roughness: 0.9 })); b.rotation.x = Math.PI / 2 - 0.25; b.position.set(0, 0.075 + 0.075, 0.0); b.scale.set(1, 1.1, 1); F.bones.head.add(b); }
  return F;
}
export function strawHat() {
  const M = MAT(); const g = new THREE.Group();
  const prof = []; for (let i = 0; i <= 24; i++) { const k = i / 24; prof.push(new THREE.Vector2(0.001 + k * 0.29, 0.13 * (1 - k) ** 1.15)); }
  const top = new THREE.Mesh(new THREE.LatheGeometry(prof.slice().reverse(), 64), M.straw); g.add(top);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.29, 0.007, 6, 64), M.rope); rim.rotation.x = Math.PI / 2; g.add(rim);
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.016, 10, 8), M.rope); knob.position.y = 0.13; g.add(knob);
  return shadowAll(g);
}

// ---------- a carved Han tomb relief: a man pushing a wheelbarrow, a figure riding on it ----------
export function relief() {
  const W = 1024, H = 1536;
  const draw = (x, mode) => { // mode 'h': height map, 'c': colour
    const hi = mode === 'h' ? '#ffffff' : '#a79a86', lo = mode === 'h' ? '#000000' : '#6f6555', mid = mode === 'h' ? '#9a9a9a' : '#958873';
    x.fillStyle = lo; x.fillRect(0, 0, W, H);
    // raised frame bands with a lozenge pattern
    x.fillStyle = hi; x.fillRect(40, 40, W - 80, 70); x.fillRect(40, H - 110, W - 80, 70); x.fillRect(40, 40, 60, H - 80); x.fillRect(W - 100, 40, 60, H - 80);
    x.fillStyle = mid; for (let i = 0; i < 18; i++) { const cx = 90 + i * 50; for (const cy of [75, H - 75]) { x.beginPath(); x.moveTo(cx, cy - 22); x.lineTo(cx + 18, cy); x.lineTo(cx, cy + 22); x.lineTo(cx - 18, cy); x.fill(); } }
    x.fillStyle = hi; x.strokeStyle = hi; x.lineCap = 'round'; x.lineJoin = 'round';
    // ground line
    x.fillRect(110, 1180, W - 220, 26);
    // wheel (big, centre of the barrow)
    x.lineWidth = 26; x.beginPath(); x.arc(560, 1040, 140, 0, Math.PI * 2); x.stroke();
    x.lineWidth = 12; for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; x.beginPath(); x.moveTo(560, 1040); x.lineTo(560 + Math.cos(a) * 135, 1040 + Math.sin(a) * 135); x.stroke(); }
    x.beginPath(); x.arc(560, 1040, 26, 0, 6.3); x.fill();
    // barrow frame and handles (to the pusher on the left)
    x.lineWidth = 24; x.beginPath(); x.moveTo(760, 940); x.lineTo(470, 930); x.lineTo(270, 840); x.stroke();
    x.beginPath(); x.moveTo(470, 932); x.lineTo(440, 1170); x.stroke();
    const poly = (pts) => { x.beginPath(); x.moveTo(...pts[0]); pts.slice(1).forEach(p => x.lineTo(...p)); x.closePath(); x.fill(); };
    const limb = (pts, w) => { x.lineWidth = w; x.beginPath(); x.moveTo(...pts[0]); pts.slice(1).forEach(p => x.lineTo(...p)); x.stroke(); };
    // a seated rider on the barrow (the father): robe, head with a cap, a staff
    poly([[612, 700], [688, 700], [745, 935], [575, 935]]);
    x.beginPath(); x.arc(650, 645, 44, 0, 6.3); x.fill();
    poly([[612, 615], [690, 615], [682, 585], [622, 585]]);
    limb([[628, 745], [585, 805], [560, 830]], 20); limb([[548, 650], [598, 975]], 12);
    // the pusher: leaning forward, arms down to the handles, mid-stride
    x.beginPath(); x.arc(312, 610, 42, 0, 6.3); x.fill();            // head
    x.beginPath(); x.arc(292, 556, 19, 0, 6.3); x.fill();            // topknot
    poly([[270, 655], [335, 668], [262, 880], [182, 858]]);           // torso, leaning forward
    poly([[182, 850], [262, 872], [292, 965], [150, 962]]);           // tunic skirt
    limb([[318, 690], [338, 775], [300, 846]], 24);                   // arm to the handle
    limb([[190, 950], [140, 1060], [104, 1176]], 30);                 // back leg
    limb([[262, 950], [306, 1060], [318, 1176]], 30);                 // front leg
    x.beginPath(); x.ellipse(96, 1178, 30, 12, 0, 0, 6.3); x.fill(); x.beginPath(); x.ellipse(336, 1178, 30, 12, 0, 0, 6.3); x.fill();
    // a tree and birds in the background, as on Han bricks
    x.lineWidth = 18; x.beginPath(); x.moveTo(860, 1180); x.lineTo(860, 760); x.stroke();
    for (let i = 0; i < 7; i++) { x.beginPath(); x.ellipse(860 + (i % 3 - 1) * 55, 700 - Math.floor(i / 3) * 70, 52, 34, 0, 0, 6.3); x.fill(); }
    x.lineWidth = 10; for (const [bx, by] of [[380, 330], [480, 290], [600, 350], [430, 420]]) { x.beginPath(); x.moveTo(bx - 40, by); x.quadraticCurveTo(bx - 15, by - 26, bx, by); x.quadraticCurveTo(bx + 15, by - 26, bx + 40, by); x.stroke(); }
    // weathering: pits and cracks
    const r = rng(41); for (let i = 0; i < 900; i++) { x.fillStyle = mode === 'h' ? `rgba(0,0,0,${0.08 + r() * 0.15})` : `rgba(40,34,26,${0.1 + r() * 0.2})`; x.beginPath(); x.arc(r() * W, r() * H, 1 + r() * 5, 0, 6.3); x.fill(); }
    x.strokeStyle = mode === 'h' ? 'rgba(0,0,0,0.6)' : 'rgba(40,34,26,0.6)'; x.lineWidth = 3; for (let i = 0; i < 5; i++) { x.beginPath(); let px = r() * W, py = r() * H; x.moveTo(px, py); for (let k = 0; k < 8; k++) { px += (r() - 0.5) * 80; py += r() * 60; x.lineTo(px, py); } x.stroke(); }
  };
  const blur = (src, px) => { const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d'); x.filter = `blur(${px}px)`; x.drawImage(src, 0, 0); return c; };
  const hc = document.createElement('canvas'); hc.width = W; hc.height = H; draw(hc.getContext('2d'), 'h');
  const hb = blur(hc, 5); // rounded carved edges
  const cc = document.createElement('canvas'); cc.width = W; cc.height = H; draw(cc.getContext('2d'), 'c');
  const hTex = new THREE.CanvasTexture(hb), cTex = new THREE.CanvasTexture(blur(cc, 1.5)); cTex.colorSpace = THREE.SRGBColorSpace;
  const geo = new THREE.PlaneGeometry(1.0, 1.5, 360, 540);
  const m = new THREE.MeshStandardMaterial({ map: cTex, displacementMap: hTex, displacementScale: 0.022, bumpMap: TX().ground, bumpScale: 0.8, roughness: 0.92 });
  const panel = new THREE.Mesh(geo, m); panel.castShadow = panel.receiveShadow = true;
  return panel;
}
