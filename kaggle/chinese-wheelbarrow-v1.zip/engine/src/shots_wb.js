// Ancient Explained: the Chinese wheelbarrow (centre wheel, load over the axle). 3d-style v1.0.0, 30 fps, motion blur.
// Every function of time here is pure.
import * as THREE from 'three';
import { V, cam, place, clamp, lerp, smooth, easeInOut, easeOut, range, spring, springKeys, handheld, camPath, noise1 } from './anim.js';
import { toon } from './toon.js';
import { birds } from './world.js';
import { grass, rng } from './nile.js';
import { riceClumps } from './farm2.js';
import { glowSprite } from './props.js';
import { FEAT, PADDY_Y, SS, groundAt, axleAt, terrain, roadStones, scenery, barrow, WB, euroBarrow, EB, dress, relief, MAT } from './china.js';
import { VO } from './vo_wb.js';

export const STYLE = { shadow: 'pcf', mb: 4, shutter: 0.5 };
const at = (line, word, k = 0) => VO[line].words.filter(w => w[0].toLowerCase().replace(/[^a-z]/g, '') === word)[k][1];
const ls = (line) => VO[line].words[0][1];
const le = (line) => VO[line].words[VO[line].words.length - 1][2];
export const DURATION = Math.round((le(9) + 0.6) * 30) / 30;

const CHUNKS = [
  [['If you *pushed*', 3], ['*300 kilos*', 3], ['of *rice*', 2], ['in a *wheelbarrow*', 3], ['your *arms*', 2], ['would hold up', 3], ['*half* of it', 3]],
  [['But *Chinese*', 2], ['*porters* moved', 2], ['loads like that', 3], ['with *almost no*', 3], ['*lifting* at all', 3]],
  [['They put', 2], ['the *wheel*', 2], ['in the *middle*', 3]],
  [['The *cargo*', 2], ['sits on *racks*', 3], ['on *both sides*', 3], ['right over', 2], ['the *axle*', 2]],
  [['So the *wheel*', 3], ['carries', 1], ['almost *all*', 2], ['the *weight*', 2]],
  [["The porter's", 2], ['*hands*', 1], ['only *steer*', 2], ['and keep', 2], ['it *level*', 2]],
  [['And the', 2], ['*big wheel*', 2], ['rolls *easily*', 2], ['over *ruts*', 2], ['and *stones*', 2]],
  [['Some porters', 2], ['even raised', 2], ['a *sail*', 2], ['on a little *mast*', 4], ['and let', 2], ['the *wind*', 2], ['do the *pushing*', 3]],
  [['Chinese *tomb art*', 3], ['shows these', 2], ['*wheelbarrows*', 1], ['by the year', 3], ['*118 AD*', 4], ['more than', 2], ['a *thousand years*', 3], ['before *Europe*', 2], ['had any', 2]],
  [['And the *biggest* ones', 4], ['could carry', 2], ['*six passengers*', 2], ['at once', 2]],
];
export const CAPTIONS = [];
CHUNKS.forEach((chunks, li) => {
  let wi = 0;
  chunks.forEach(([text, n], ci) => {
    const w0 = VO[li].words[wi], wl = VO[li].words[wi + n - 1];
    if (!w0 || !wl) throw new Error(`caption words out of range line ${li} chunk ${ci}`);
    CAPTIONS.push(ci === chunks.length - 1 ? [w0[1] - 0.04, text, wl[2] + 0.3] : [w0[1] - 0.04, text]);
    wi += n;
  });
  if (wi !== VO[li].words.length) throw new Error(`line ${li}: captions cover ${wi} of ${VO[li].words.length} words`);
});
export const FADES = [];

// ================= road features (fixed in the world; the rut + stone shot rolls over them) =================
const RUT_X = 2.0, STONE_X = 2.86;
FEAT.ruts.push([RUT_X, 0.05, 0.17]);
FEAT.stones.push([STONE_X, 0.0, 0.085]);

// cuts: just before each line
const CUT = [0, ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map(i => ls(i) - 0.2)];

// ================= shared world =================
function world(makeStage, { sunDir = [-0.55, 0.42, 0.72], shadowAt = [0, 0.8, 0], shadowSize = 4, fog = 0.006 } = {}) {
  const scene = makeStage({ outdoor: 'golden', sunDir, fog, shadowSize, shadowAt, envI: 0.85, hemi: 0.32 });
  const key = scene.userData.key; key.shadow.mapSize.set(4096, 4096); key.shadow.radius = 2.2; key.shadow.bias = -0.0002; key.shadow.normalBias = 0.015;
  const fill = new THREE.DirectionalLight(0xffe2c0, 0.5); fill.position.set(3, 2, 6); scene.add(fill);
  const rim = new THREE.DirectionalLight(0xbfd4ff, 0.65); rim.position.set(2, 4, -6); scene.add(rim);
  const bounce = new THREE.DirectionalLight(0xd9a068, 0.4); bounce.position.set(-0.6, -1, 0.5); scene.add(bounce);
  scene.add(terrain()); scene.add(roadStones()); scenery(scene);
  // grass on the shoulders, rice plants along the paddy edges, pebbles scattered on the road edges
  const r = rng(13); const gs = [];
  for (let i = 0; i < 5200; i++) { const x = (r() - 0.5) * 60, s = r() < 0.5 ? -1 : 1, z = s * (1.3 + r() * 1.05); const y = groundAt(x, z); if (y < PADDY_Y + 0.02) continue; gs.push([x, y - 0.01, z, 0.6 + r() * 0.6]); }
  scene.add(grass(gs, { h: 0.3, seed: 5 }));
  const rc = []; for (let i = 0; i < 2600; i++) { const x = (r() - 0.5) * 60, s = r() < 0.5 ? -1 : 1, z = s * (3.1 + r() * 4.5); rc.push([x, PADDY_Y - 0.02, z]); }
  scene.add(riceClumps(rc, { h: 0.55, hVar: 0.15, blades: 9, sway: 0.04, seed: 8 }));
  const b = birds(5, { from: [-40, 12, -30], to: [40, 15, -38], spread: 5, speed: 0.05, scale: 1.3, seed: 6 }); scene.add(b);
  scene.userData.updaters.push((t) => b.update(t));
  return scene;
}

// ================= characters =================
const LOOKS = [
  { skin: 0xb07a52, tunic: 0x5d6f8a, collar: 0x2e3a4c, trousers: 0x6b5a44, belt: 0x3a2a1c, hat: true },   // the porter
  { skin: 0xa8734c, tunic: 0x8a5a3a, collar: 0x4a2e1e, trousers: 0x55503f, belt: 0x2a2018, hat: true },   // "you"
  { skin: 0xb98058, tunic: 0x7b8a5a, collar: 0x3e4a2c, trousers: 0x6a5c48, belt: 0x30261a, hat: false },
  { skin: 0xa06c48, tunic: 0xa0783e, collar: 0x5a3e1e, trousers: 0x4f4a40, belt: 0x2a2018, hat: true },
  { skin: 0xc08a60, tunic: 0x6a5a7a, collar: 0x2e2840, trousers: 0x5a5040, belt: 0x30261a, hat: false },
  { skin: 0xa8764e, tunic: 0x9a4a3a, collar: 0x4a1e18, trousers: 0x5a5244, belt: 0x2a2018, hat: false },
  { skin: 0xb27c54, tunic: 0x4f7a7a, collar: 0x23403f, trousers: 0x665a48, belt: 0x30261a, hat: true },
  { skin: 0xba845a, tunic: 0xc2b08a, collar: 0x6a5a3a, trousers: 0x5a5040, belt: 0x30261a, hat: false },
];
function person(i, seed = 0) { const L = LOOKS[i]; const F = toon({ skin: L.skin, cloth: L.tunic, belt: L.belt, seed }); return dress(F, L); }

// walking gait from distance walked d (m): feet planted in the world, swinging forward 40% of each cycle
const SL = 0.5;
function gait(d) {
  const out = {};
  for (const [s, off] of [['l', 0], ['r', 0.5]]) {
    const u = d / (2 * SL) + off, f = u - Math.floor(u), base = 2 * SL * Math.floor(u), c = 0.3 - 2 * SL * off;
    const k = f < 0.6 ? 0 : smooth((f - 0.6) / 0.4);
    out[s] = { x: base + c + 2 * SL * k, lift: f < 0.6 ? 0 : 0.085 * Math.sin(Math.PI * k), heel: f < 0.6 ? 0 : Math.sin(Math.PI * k) };
  }
  const u = d / (2 * SL);
  out.bob = 0.014 * Math.cos(4 * Math.PI * u + 0.6); out.sway = 0.012 * Math.sin(2 * Math.PI * u);
  return out;
}
// distance at which both feet are planted (for standing still)
const standD = (d) => { const u = d / (2 * SL); return (Math.floor(u) + 0.55) * 2 * SL; };

// pose a walking/standing pusher. root faces +x. d = distance along x of the root (gait), hands to world points.
function pushPose(F, { rootX, gaitD, z = 0, handL, handR, lean = 0.2, look, grip = 0.85, face = {}, t = 0, breathe = 0.012, free = false, crouch = 0 }) {
  const g = gait(gaitD);
  F.root.position.set(rootX, 0, z); F.root.rotation.y = Math.PI / 2;
  const br = Math.sin(t * 2.4) * breathe;
  F.pose({ hipsY: -0.085 - crouch + g.bob, hipsX: g.sway, spine: [lean, 0, -g.sway * 2], chest: [0.06 + br, 0, g.sway * 1.5] });
  F.kilt(-0.08 - g.bob * 2, g.sway * 3);
  const w = (lx, ly, lz) => F.root.localToWorld(V(lx, ly, lz));
  for (const [s, sx] of [['l', 1], ['r', -1]]) {
    const fx = g[s].x + (gaitD - rootX) * 0 + rootX - gaitD + (rootX - rootX); // world x of this foot (gait is relative to d; root at rootX)
    const wx = rootX + (g[s].x - gaitD), wz = z - sx * 0.11; void fx;
    F.legIK(s, V(wx, groundAt(wx, wz) + 0.075 + g[s].lift, wz), w(sx * 0.12, 0.5, 1.4));
  }
  if (free) { handL = w(0.24, 0.86 + 0.01 * Math.sin(t * 2), 0.1); handR = w(-0.24, 0.86 + 0.01 * Math.sin(t * 2 + 1), 0.1); F.armIK('l', handL, w(0.6, 1.0, -0.3), V(0, 0, 1)); F.armIK('r', handR, w(-0.6, 1.0, -0.3), V(0, 0, 1)); }
  else { F.armIK('l', handL, w(0.55, 0.95, -0.45), V(0, 1, 0)); F.armIK('r', handR, w(-0.55, 0.95, -0.45), V(0, 1, 0)); }
  F.grip(grip, grip);
  if (window.DBG) { // QA: reach errors of the IK (hands vs grips, ankles vs targets) and planted feet vs the ground
    const B = F.bones, m = (window._meas = window._meas || []);
    for (const [s, tgt] of [['l', handL], ['r', handR]]) { const e = B[s + 'El'].getWorldPosition(V(0, 0, 0)), wr = B[s + 'Wr'].getWorldPosition(V(0, 0, 0)); const palm = wr.clone().add(wr.clone().sub(e).normalize().multiplyScalar(0.07)); m.push({ t, k: 'hand' + s, err: palm.distanceTo(tgt) }); }
    for (const [s, sx] of [['l', 1], ['r', -1]]) { const a = B[s + 'An'].getWorldPosition(V(0, 0, 0)); const wz = a.z; m.push({ t, k: 'foot' + s, err: a.y - 0.075 - groundAt(a.x, wz), lift: g[s].lift }); }
  }
  if (look) { F.headAt(look, 0.7); F.look(look); }
  F.face({ smile: 0.35, cheek: 0.3, brow: 0.1, ...face });
}

// the Chinese barrow pushed along the road. ax(t) = axle x. Handles held at hand height hh (unless parked).
const GRIP_X = WB.HANDLE.x + 0.08, GRIP_Z = 0.262, REACH = 0.43;
function pitchFor(B, axY, hh, scale = 1) { // pitch so the handle grips sit at height hh
  const hx = GRIP_X * scale, hy = WB.HANDLE.y * scale; let p = 0;
  for (let i = 0; i < 30; i++) { const y = axY + hx * Math.sin(p) + hy * Math.cos(p); const dy = hx * Math.cos(p) - hy * Math.sin(p); p -= (y - hh) / dy; }
  return p;
}
function parkPitch(axY, scale = 1) { // rear legs on the ground
  let p = 0; for (let i = 0; i < 30; i++) { const lx = -0.6 * scale, ly = -0.32 * scale; const x = lx * Math.cos(p) - ly * Math.sin(p), y = axY + lx * Math.sin(p) + ly * Math.cos(p); const gy = groundAt(x, 0.21); const dy = lx * Math.cos(p) - ly * Math.sin(p); p -= (y - gy) / dy; } return p;
}
function barrowRig(scene, { ax, hh = () => 0.83, lift = () => 1, sail = false, sailState = null, porter = 0, scale = 1, sacks = true, lean = () => 0.2, look = null, face = () => ({}), grip = () => 0.85, standing = () => false, free = () => false, rootOff = 0 }) {
  const B = barrow({ scale, sail: !!sail, sacks }); scene.add(B.root);
  const F = person(porter); scene.add(F.root);
  const R = WB.R * scale;
  const state = (t) => {
    const x = ax(t), axY = axleAt(x, 0, R);
    const p = lerp(parkPitch(axY, scale), pitchFor(B, axY, hh(t), scale), lift(t));
    return { x, axY, p, spin: -x / R };
  };
  function update(t) {
    const S = state(t);
    if (window.DBG) (window._meas = window._meas || []).push({ t, k: 'axle', x: S.x, y: S.axY, R });
    B.root.position.set(S.x, S.axY, 0); B.set({ pitch: S.p, spin: S.spin });
    if (sailState) { const s = sailState(t); B.setSail(s.hoist, s.fill, t); }
    const gl = B.toWorld(V(GRIP_X, WB.HANDLE.y + 0.03, -GRIP_Z)), gr = B.toWorld(V(GRIP_X, WB.HANDLE.y + 0.03, GRIP_Z));
    const rootX = (gl.x + gr.x) / 2 - REACH - rootOff;
    const d = standing(t) ? standD(rootX) : rootX;
    if (window.DBG) window._meas.push({ t, k: 'root', x: rootX, ax: S.x, d });
    pushPose(F, { rootX, gaitD: d, handL: gl, handR: gr, lean: lean(t), look: look ? look(t, S) : V(rootX + 6, 1.3, 0), grip: grip(t), face: face(t), t, free: free(t) });
    return S;
  }
  return { B, F, update, state };
}

// gold arrows (load paths)
function arrow(color = 0xffc23a) {
  const m = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.9, roughness: 0.4, transparent: true, depthWrite: false, depthTest: false });
  const g = new THREE.Group(); const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1, 12), m); const head = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.11, 16), m);
  g.add(shaft, head); shaft.renderOrder = head.renderOrder = 50;
  g.set = (from, to, k, alpha = 1) => {
    const d = to.clone().sub(from); const L = d.length() * clamp(k); g.visible = k > 0.01 && alpha > 0.01; if (!g.visible) return;
    const dir = d.normalize(); g.position.copy(from); g.quaternion.setFromUnitVectors(V(0, 1, 0), dir);
    shaft.scale.set(1, Math.max(0.001, L - 0.1), 1); shaft.position.y = Math.max(0.001, L - 0.1) / 2; head.position.y = L - 0.055; m.opacity = alpha;
  };
  return g;
}

// ================= SHOT A: "you" and a front-wheel barrow full of rice =================
function sYou({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [-30, 0.8, 0] });
  const EBr = euroBarrow(); scene.add(EBr.root); const F = person(1); scene.add(F.root);
  const X0 = -30; const a1 = arrow(0xff5a3a), a2 = arrow(0xff5a3a); scene.add(a1, a2);
  const T_UP = 0.6, T_SAG = at(0, 'arms'), T_HALF = at(0, 'half');
  const c = cam(34);
  return { scene, camera: c, update(lt, t) {
    // he heaves the handles up (strain), they creep forward a little, then sag on "half of it"
    const up = springKeys(t, [[0, 0], [T_UP, 0.1], [T_UP + 0.6, 0.75], [T_SAG, 0.85], [T_HALF + 0.1, 0.72]], 2.0, 0.6) + noise1(t * 10, 3) * 0.02 * clamp(t - T_UP);
    const x = X0 + 0.25 * smooth(range(t, T_UP + 0.4, T_HALF));
    const axY = EB.R + groundAt(x, 0);
    const hh = lerp(0.72, 0.84, clamp(up));
    let p = 0; for (let i = 0; i < 20; i++) { const hx = EB.HANDLE.x + 0.08, hy = EB.HANDLE.y; const y = axY + hx * Math.sin(p) + hy * Math.cos(p); p -= (y - hh) / (hx * Math.cos(p) - hy * Math.sin(p)); }
    EBr.root.position.set(x, axY, 0); EBr.set({ pitch: p, spin: -(x - X0) / EB.R });
    const gl = EBr.toWorld(V(EB.HANDLE.x + 0.08, EB.HANDLE.y + 0.03, -0.262)), gr = EBr.toWorld(V(EB.HANDLE.x + 0.08, EB.HANDLE.y + 0.03, 0.262));
    const rootX = (gl.x + gr.x) / 2 - 0.39;
    const strain = clamp(up * 1.3);
    pushPose(F, { rootX, gaitD: standD(X0 - 1.84) + (rootX - (X0 - 1.84)), handL: gl, handR: gr, lean: 0.32 + 0.08 * strain, look: c.position.clone().lerp(V(rootX + 3, 1.0, 0), 0.6), grip: 1, t, breathe: 0.02, crouch: 0.05 * (1 - clamp(up)) + 0.03,
      face: { brow: -0.85 * strain, smile: -0.35 * strain, teeth: strain, squint: 0.6 * strain, flare: 0.8 * strain, blink: Math.max(0, 1 - Math.abs(t - 1.9) / 0.07) } });
    // red arrows: the load pushing down on his arms
    const ka = smooth(range(t, T_HALF - 0.25, T_HALF + 0.25));
    a1.set(gl.clone().add(V(0, 0.45, 0)), gl.clone().add(V(0, 0.06, 0)), ka); a2.set(gr.clone().add(V(0, 0.45, 0)), gr.clone().add(V(0, 0.06, 0)), ka);
    // camera: low three-quarter from the front, push in from the load to his face
    const k = easeInOut(range(t, 0, CUT[1]));
    const P = camPath(k, [[X0 + 1.2, 1.25, 3.0], [X0 + 0.5, 1.3, 2.4], [X0 - 0.4, 1.38, 1.85]]);
    const look = V(X0 - 1.0, 0.95, 0).lerp(V(rootX + 0.1, 1.3, 0), smooth(range(t, 2.0, 4.2)));
    const hh2 = handheld(t, 1.1, 2); place(c, [P[0] + hh2.p[0], P[1] + hh2.p[1], P[2] + hh2.p[2]], look.toArray(), hh2.roll);
    return { bloom: 0.3, warm: 1.1, sat: 1.08, flare: 0.4, dof: { focus: c.position.distanceTo(look), aperture: 0.003, maxblur: 0.007 } };
  } };
}

// ================= SHOT B: a Han porter strolls past with a far bigger load =================
function sStroll({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [-12, 0.8, 0] });
  const t0 = CUT[1];
  const R = barrowRig(scene, { ax: (t) => -14 + 1.05 * (t - t0), look: (t, S) => V(S.x + 5, 1.3, 0.4).lerp(c.position, smooth(range(t, at(1, 'no'), at(1, 'no') + 0.5)) * 0.8),
    face: (t) => ({ smile: 0.55, cheek: 0.6, blink: Math.max(0, 1 - Math.abs(t - 7.4) / 0.07) }) });
  const c = cam(32);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t);
    // wide side tracking shot, drifting in to a medium as he looks at the lens on "no lifting"
    const k = easeInOut(range(t, t0, CUT[2]));
    const P = camPath(k, [[S.x + 3.4, 1.55, 4.6], [S.x + 2.6, 1.45, 3.9], [S.x + 1.9, 1.4, 3.3]]);
    const look = V(S.x - 0.75, 0.85, 0).lerp(V(S.x - 1.2, 1.05, 0), k);
    const hh = handheld(t, 0.8, 5); place(c, [P[0] + hh.p[0], P[1] + hh.p[1], P[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.3, warm: 1.12, sat: 1.1, flare: 0.5, dof: { focus: c.position.distanceTo(look), aperture: 0.002, maxblur: 0.006 } };
  } };
}

// ================= SHOT C: the wheel, right in the middle =================
function sWheel({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [-6, 0.8, 0] });
  const t0 = CUT[2];
  const R = barrowRig(scene, { ax: (t) => -6 + 0.9 * (t - t0), face: () => ({ smile: 0.5, cheek: 0.5 }) });
  const glow = glowSprite(0xffd27a, 1.4); scene.add(glow);
  const c = cam(36);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t);
    // low orbit from the front quarter to straight on as the wheel is named, then a rise on "middle"
    const k = easeInOut(range(t, t0, CUT[3]));
    // stays over the road (|z| < 1.2: clear of the verge grass), low front quarter swinging to straight on
    const P = [S.x + lerp(1.7, 2.3, k), lerp(0.5, 0.85, smooth(range(t, at(2, 'middle') - 0.3, CUT[3]))), lerp(1.15, 0.35, k)];
    const look = V(S.x - 0.05, 0.5, 0);
    const kg = Math.sin(Math.PI * range(t, at(2, 'wheel') - 0.1, CUT[3] + 0.2)); glow.position.set(S.x, S.axY, 0.25); glow.material.opacity = 0.35 * kg; glow.visible = kg > 0.01;
    const hh = handheld(t, 0.7, 7); place(c, [P[0] + hh.p[0], P[1] + hh.p[1], P[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.35, warm: 1.12, sat: 1.1, flare: 0.4, dof: { focus: c.position.distanceTo(look), aperture: 0.004, maxblur: 0.008 } };
  } };
}

// ================= SHOT D: racks on both sides, load straight over the axle (front view) =================
function sRacks({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [4, 0.8, 0] });
  const X = 6.0; const t0 = CUT[3];
  const R = barrowRig(scene, { ax: () => X, lift: () => 0, standing: () => true, free: () => true, rootOff: 0.15, lean: () => 0.04, grip: () => 0.3, face: () => ({ smile: 0.6, cheek: 0.6 }),
    look: (t) => V(X + 0.2, 0.6, 0) });
  // sacks drop onto the racks, left side then right side, landing with a squash
  const drops = R.B.sacks.map((s, i) => ({ s, home: s.position.clone(), t: at(3, i < 3 ? 'both' : 'sides') - 0.35 + (i % 3) * 0.12 + (i >= 3 ? 0.05 : 0) }));
  const arrows = [arrow(), arrow()]; scene.add(...arrows);
  const c = cam(34);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t);
    drops.forEach(({ s, home, t: td }) => {
      const k = (t - td) / 0.38; const y = k < 1 ? 0.9 * (1 - clamp(k) ** 2) : 0; const land = t > td + 0.38 ? spring(t - td - 0.38, 3.2, 0.3) : 0;
      s.position.set(home.x, home.y + y, home.z); s.visible = t > td - 0.02 || t < t0; s.scale.set(1 + 0.15 * (1 - land) * (t > td + 0.38 ? 1 : 0), 1 - 0.2 * (1 - land) * (t > td + 0.38 ? 1 : 0), 1);
      if (t < td - 0.02) s.visible = false;
    });
    // arrows from each stack down to the axle on "right over the axle"
    const ka = smooth(range(t, at(3, 'right') - 0.1, at(3, 'axle') + 0.1));
    const ax = R.B.toWorld(V(0, 0, 0));
    [-1, 1].forEach((s, i) => arrows[i].set(R.B.toWorld(V(0, WB.RACK_Y + 0.55, s * 0.44)), ax.clone().add(V(0, 0.06, s * 0.06)), ka));
    // front view, slightly high, a slow push in
    const k = easeInOut(range(t, t0, CUT[4]));
    const P = [X + lerp(3.4, 2.7, k), lerp(1.45, 1.3, k), lerp(0.55, 0.35, k)];
    const look = V(X - 0.2, 0.62, 0);
    const hh = handheld(t, 0.6, 9); place(c, [P[0] + hh.p[0], P[1] + hh.p[1], P[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.3, warm: 1.1, sat: 1.08, flare: 0.3, dof: { focus: c.position.distanceTo(look), aperture: 0.0015, maxblur: 0.005 } };
  } };
}

// ================= SHOT E: he lifts the handles; the weight goes down into the wheel =================
function sWeight({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [10, 0.8, 0] });
  const X = 10.0, t0 = CUT[4];
  const T_LIFT = at(4, 'wheel') - 0.1;
  const R = barrowRig(scene, { ax: () => X, lift: () => 1, hh: (t) => 0.84 + 0.03 * smooth(range(t, T_LIFT, T_LIFT + 0.6)), standing: () => true, lean: () => 0.14,
    face: (t) => ({ smile: 0.55, cheek: 0.55, brow: 0.25 }), look: (t, S) => c.position });
  const arrows = [arrow(), arrow(), arrow(), arrow()]; scene.add(...arrows); const small = [arrow(0xff5a3a), arrow(0xff5a3a)]; scene.add(...small);
  const c = cam(36);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t);
    const ka = smooth(range(t, at(4, 'carries') - 0.1, at(4, 'all') + 0.1));
    const contact = V(S.x, groundAt(S.x, 0) + 0.02, 0.0);
    [[-0.33, -1], [0.33, -1], [-0.33, 1], [0.33, 1]].forEach(([x, s], i) => arrows[i].set(R.B.toWorld(V(x, WB.RACK_Y + 0.62, s * 0.44)), contact.clone().add(V(x * 0.15, 0.05 + 0.02 * i, s * 0.05)), ka));
    // tiny arrows at the hands: almost nothing
    const kb = smooth(range(t, at(4, 'weight') - 0.1, at(4, 'weight') + 0.3));
    const gl = R.B.toWorld(V(GRIP_X, WB.HANDLE.y + 0.03, -GRIP_Z)), gr = R.B.toWorld(V(GRIP_X, WB.HANDLE.y + 0.03, GRIP_Z));
    small[0].set(gl.clone().add(V(0, 0.2, 0)), gl.clone().add(V(0, 0.07, 0)), kb); small[1].set(gr.clone().add(V(0, 0.2, 0)), gr.clone().add(V(0, 0.07, 0)), kb);
    const k = easeInOut(range(t, t0, CUT[5]));
    const P = [X + lerp(2.5, 2.2, k), lerp(2.0, 1.85, k), lerp(2.9, 2.6, k)];
    const look = V(X - 0.65, 0.55, 0);
    const hh = handheld(t, 0.6, 11); place(c, [P[0] + hh.p[0], P[1] + hh.p[1], P[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.3, warm: 1.1, sat: 1.08, flare: 0.3, dof: { focus: c.position.distanceTo(look), aperture: 0.0015, maxblur: 0.005 } };
  } };
}

// ================= SHOT F: his hands only steer =================
function sHands({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [-20, 0.8, 0] });
  const t0 = CUT[5];
  const T_LEVEL = at(5, 'level');
  // a gentle wobble he corrects with a light touch (pitch spring around his hand height)
  const hh = (t) => 0.855 + 0.025 * Math.sin((t - t0) * 2.1) * Math.exp(-Math.max(0, t - T_LEVEL + 0.4) * 2);
  const R = barrowRig(scene, { ax: (t) => -21 + 1.0 * (t - t0), hh, grip: (t) => 0.55 + 0.1 * Math.sin(t * 1.3), face: () => ({ smile: 0.6, cheek: 0.6 }), lean: () => 0.16 });
  const c = cam(30);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t);
    const gr = R.B.toWorld(V(GRIP_X, WB.HANDLE.y, GRIP_Z));
    const k = easeInOut(range(t, t0, CUT[6]));
    // close on the right hand on the grip, then pull back to show the barrow riding level
    const P = [gr.x + lerp(-0.25, -0.9, k), gr.y + lerp(0.22, 0.4, k), gr.z + lerp(0.62, 1.5, k)];
    const look = gr.clone().lerp(V(S.x - 0.6, 0.75, 0), smooth(range(t, at(5, 'keep') - 0.3, T_LEVEL + 0.2)));
    const h2 = handheld(t, 0.5, 13); place(c, [P[0] + h2.p[0], P[1] + h2.p[1], P[2] + h2.p[2]], look.toArray(), h2.roll);
    return { bloom: 0.3, warm: 1.1, sat: 1.08, flare: 0.4, dof: { focus: c.position.distanceTo(look), aperture: 0.004, maxblur: 0.008 } };
  } };
}

// ================= SHOT G: over a rut and a stone, ground level =================
function sRut({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [2, 0.6, 0] });
  const t0 = CUT[6];
  // axle x: the wheel reaches the rut on "ruts" and climbs the stone on "stones"
  const V0 = 1.05; const xr = RUT_X - (at(6, 'ruts') + 0.05) * V0;
  const R = barrowRig(scene, { ax: (t) => xr + V0 * t, face: () => ({ smile: 0.5, cheek: 0.5 }) });
  const c = cam(36);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t);
    const k = easeInOut(range(t, t0, CUT[7]));
    // low, almost on the ground, beside the wheel's path ahead of the stone; tracks with the wheel
    const P = [lerp(RUT_X + 0.4, STONE_X + 0.8, k), 0.22, 1.12];
    const look = V(lerp(S.x + 0.1, S.x + 0.3, k), 0.2, 0);
    const hh = handheld(t, 0.6, 15); place(c, [P[0] + hh.p[0], P[1] + hh.p[1], P[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.3, warm: 1.12, sat: 1.1, flare: 0.5, dof: { focus: c.position.distanceTo(look), aperture: 0.004, maxblur: 0.009 } };
  } };
}

// ================= SHOT H: a sail goes up and the wind pushes =================
function sSail({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [12, 1.0, 0] });
  const t0 = CUT[7]; const T_H = at(7, 'raised') - 0.1, T_W = at(7, 'wind') - 0.15;
  // speed: walking, then the wind picks up and he strides faster
  const v = (t) => lerp(0.9, 1.5, smooth(range(t, T_W, T_W + 1.2)));
  const X0 = 10; const xs = (t) => { let x = X0, tt = t0; const dt = 1 / 120; while (tt < t) { x += v(tt) * dt; tt += dt; } return x; };
  const R = barrowRig(scene, { ax: xs, sail: true, sailState: (t) => ({ hoist: easeOut(range(t, T_H, T_H + 0.9)), fill: smooth(range(t, T_W - 0.3, T_W + 0.6)) }),
    face: (t) => ({ smile: lerp(0.5, 0.95, smooth(range(t, T_W, T_W + 0.6))), cheek: lerp(0.5, 0.9, smooth(range(t, T_W, T_W + 0.6))) }),
    look: (t, S) => V(S.x + 1, 2.0, 0).lerp(V(S.x + 5, 1.3, 0), smooth(range(t, T_W + 0.4, T_W + 1.2))) });
  const c = cam(34);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t);
    const k = easeInOut(range(t, t0, CUT[8]));
    // rear three-quarter (the wind's view), rising to show the full sail
    const P = [S.x + lerp(4.4, 4.8, k), lerp(1.5, 1.7, k), lerp(3.6, 4.2, k)];
    const look = V(S.x + 0.15, lerp(1.05, 1.3, k), 0);
    const hh = handheld(t, 0.8, 17); place(c, [P[0] + hh.p[0], P[1] + hh.p[1], P[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.32, warm: 1.12, sat: 1.1, flare: 0.6, dof: { focus: c.position.distanceTo(look), aperture: 0.0015, maxblur: 0.005 } };
  } };
}

// ================= SHOT I: a carved tomb relief by torchlight =================
function sRelief({ makeStage }) {
  const scene = makeStage({ shadowSize: 2, sunDir: [-2, 3, 4], sun: 0.0 });
  scene.children.filter(o => o.isMesh && o.material && o.material.isShadowMaterial).forEach(o => { o.visible = false; });
  scene.userData.sky.visible = false; scene.background = new THREE.Color(0x0a0806); scene.environmentIntensity = 0.08;
  scene.traverse(o => { if (o.isLight && !o.isDirectionalLight) o.intensity *= 0.15; if (o.isDirectionalLight) o.intensity = 0; });
  // wall of stone blocks with the relief set in it
  const wall = new THREE.Group(); scene.add(wall);
  const stoneM = new THREE.MeshStandardMaterial({ color: 0x8a7e6c, roughness: 0.95, bumpMap: MAT().burlap.bumpMap, bumpScale: 0.6 });
  const r = rng(71);
  for (let j = 0; j < 7; j++) for (let i = -3; i <= 3; i++) {
    const w = 0.62, h = 0.42; const x = i * w + (j % 2) * w / 2, y = j * h - 0.2; if (Math.abs(x) < 0.62 && y > -0.2 && y < 1.9) continue;
    const b = new THREE.Mesh(new THREE.BoxGeometry(w - 0.02, h - 0.02, 0.3), stoneM.clone()); b.material.color.offsetHSL(0, 0, (r() - 0.5) * 0.08); b.position.set(x, y + h / 2, -0.15 - r() * 0.01); b.receiveShadow = b.castShadow = true; wall.add(b);
  }
  const P = relief(); P.position.set(0, 0.95, 0.0); wall.add(P);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(8, 6), new THREE.MeshStandardMaterial({ color: 0x3a3228, roughness: 1 })); floor.rotation.x = -Math.PI / 2; floor.position.set(0, -0.2, 2); floor.receiveShadow = true; scene.add(floor);
  // torch: a warm flickering light held off to the left, grazing the carving so it casts shadows
  const torch = new THREE.PointLight(0xffc488, 6, 7, 1.6); torch.castShadow = true; torch.shadow.mapSize.set(2048, 2048); torch.shadow.bias = -0.0008; torch.shadow.radius = 3; scene.add(torch);
  const flame = glowSprite(0xffb055, 0.5); scene.add(flame); const flame2 = glowSprite(0xffe2a0, 0.18); scene.add(flame2);
  const t0 = CUT[8];
  const dust = new THREE.Points(new THREE.BufferGeometry(), new THREE.PointsMaterial({ color: 0xffd8a0, size: 0.006, transparent: true, opacity: 0.5, depthWrite: false }));
  { const n = 300, a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { a[i * 3] = (r() - 0.5) * 2.4; a[i * 3 + 1] = r() * 2.2; a[i * 3 + 2] = 0.1 + r() * 1.6; } dust.geometry.setAttribute('position', new THREE.BufferAttribute(a, 3)); } scene.add(dust);
  const c = cam(34);
  return { scene, camera: c, update(lt, t) {
    const fl = 1 + 0.12 * noise1(t * 8, 4) + 0.06 * noise1(t * 21, 5);
    const k = easeInOut(range(t, t0, CUT[9]));
    // the torch moves slowly across, as if someone walks along the wall holding it
    const tp = V(lerp(-0.75, -0.35, k), lerp(1.55, 1.35, k), 0.55 + 0.03 * noise1(t * 2, 6)); torch.position.copy(tp); torch.intensity = 5.2 * fl;
    flame.position.copy(tp); flame.scale.setScalar(0.45 * fl); flame2.position.copy(tp); flame2.scale.setScalar(0.16 * fl);
    dust.position.y = -0.02 * (t - t0);
    // start wide on the panel, push in to the barrow and its wheel
    const Pc = camPath(k, [[0.25, 0.95, 2.6], [0.12, 0.85, 1.9], [0.05, 0.78, 1.45]]);
    const look = V(0, 0.95, 0).lerp(V(0.03, 0.72, 0), k);
    const hh = handheld(t, 0.5, 19); place(c, [Pc[0] + hh.p[0], Pc[1] + hh.p[1], Pc[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.4, warm: 1.0, sat: 0.85, flare: 0.0, dof: { focus: c.position.distanceTo(look), aperture: 0.002, maxblur: 0.005 } };
  } };
}

// ================= SHOT J: six passengers =================
function sixSeat(scene, B, scale) {
  const ppl = [];
  [[-1, 0], [-1, 1], [-1, 2], [1, 0], [1, 1], [1, 2]].forEach(([s, i], n) => {
    const F = person(2 + (n % 6), n + 3); scene.add(F.root);
    ppl.push({ F, s, x: (i - 1) * 0.6 * scale / 1.3, phase: n * 1.7 });
  });
  return (t, cpos) => {
    ppl.forEach(({ F, s, x, phase }) => {
      const seat = B.toWorld(V(x / B.scale, WB.RACK_Y + 0.005, s * 0.5));
      const yaw = s > 0 ? 0 : Math.PI;
      F.root.position.set(seat.x, seat.y - 0.86, seat.z); F.root.rotation.set(0, yaw, 0);
      const bump = 0.008 * Math.sin(t * 9 + phase);
      F.pose({ hipsY: bump, spine: [-0.06, 0, 0], chest: [0.02 + 0.01 * Math.sin(t * 2.3 + phase), 0, 0] });
      F.kilt(-0.9, 0);
      const w = (lx, ly, lz) => F.root.localToWorld(V(lx, ly, lz));
      for (const [h, sx] of [['l', 1], ['r', -1]]) {
        F.legIK(h, w(sx * 0.12, 0.5 + 0.01 * Math.sin(t * 3 + phase + sx), 0.47), w(sx * 0.12, 1.2, 1.2));
        F.armIK(h, w(sx * 0.14, 0.97, 0.3), w(sx * 0.5, 1.0, -0.2), V(0, 1, 0));
      }
      F.grip(0.4, 0.4);
      F.headAt(cpos, 0.55); F.look(cpos);
      F.face({ smile: 0.7 + 0.2 * Math.sin(phase), cheek: 0.6, brow: 0.2, blink: Math.max(0, 1 - Math.abs(((t + phase) % 3.1) - 1.5) / 0.07) });
    });
  };
}
function sSix({ makeStage }) {
  const scene = world(makeStage, { shadowAt: [-20, 1.0, 0], shadowSize: 5 });
  const t0 = CUT[9]; const SC = 1.3;
  const R = barrowRig(scene, { ax: (t) => -21 + 0.75 * (t - t0), scale: SC, sacks: false, hh: () => 0.86, lean: () => 0.3, face: () => ({ smile: 0.55, cheek: 0.5, brow: -0.1 }), porter: 0 });
  const c = cam(34);
  const seats = sixSeat(scene, R.B, SC);
  return { scene, camera: c, update(lt, t) {
    const S = R.update(t); seats(t, c.position);
    const k = easeInOut(range(t, t0, DURATION));
    const P = [S.x + lerp(4.3, 3.8, k), lerp(2.6, 2.5, k), lerp(2.3, 2.6, k)];
    const look = V(S.x - 0.45, 0.75, 0);
    const hh = handheld(t, 0.7, 21); place(c, [P[0] + hh.p[0], P[1] + hh.p[1], P[2] + hh.p[2]], look.toArray(), hh.roll);
    return { bloom: 0.3, warm: 1.12, sat: 1.1, flare: 0.5, dof: { focus: c.position.distanceTo(look), aperture: 0.0015, maxblur: 0.005 } };
  } };
}

export const SHOTS = [
  { start: 0, end: CUT[1], build: sYou },
  { start: CUT[1], end: CUT[2], build: sStroll },
  { start: CUT[2], end: CUT[3], build: sWheel },
  { start: CUT[3], end: CUT[4], build: sRacks },
  { start: CUT[4], end: CUT[5], build: sWeight },
  { start: CUT[5], end: CUT[6], build: sHands },
  { start: CUT[6], end: CUT[7], build: sRut },
  { start: CUT[7], end: CUT[8], build: sSail },
  { start: CUT[8], end: CUT[9], build: sRelief },
  { start: CUT[9], end: DURATION + 1, build: sSix },
];
console.warn(`[wb] duration ${DURATION.toFixed(3)} cuts ${CUT.map(c => c.toFixed(2)).join(' ')}`);
